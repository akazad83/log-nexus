# Phase 2 — Schema Mechanics + Deliverable 1 (Design-Quality Findings, Ranked)

Source of truth: `d:/103_RnD/psm_v1/d1.sql` (33,392 lines, authoritative Ingres DDL/dump).
Derived from the verified analyses: `analysis/verified/schema-mechanics.md`, `analysis/verified/metamodel-core.md`, `analysis/verified/dbproc-logic.md`. Every count below was re-derived in those passes and carries their verification stamps. Claims tagged `[FACT - file->object]`, `[INFERENCE - reasoning]`, `[UNKNOWN]`.

**One-line verdict:** PSM is a metamodel-driven, **integrity-in-code** Ingres database with **zero declared RI/CHECK/PK/FK**, **flat all-to-`public` security**, **zero secondary indexes**, and a validate-and-log (not reject-at-write) correctness model. `[FACT]`

---

## 1. Storage / Index

### 1.1 Structure tally — exactly one storage structure per base table (450/450) `[FACT - d1.sql ^modify lines]`

| Structure | Count | %     | Role |
|---|---:|---:|---|
| btree | 367 | 81.6% | default; range + equality access |
| hash  | 42  | 9.3%  | exact-match keys (`cac_lastkey`, `fms_3manomaly`) |
| heap  | 26  | 5.8%  | unkeyed scratch/queue (`ddb_recoverytimeout`, `egis_nfload`, `udb_temp$*`; all `with extend=16`) |
| isam  | 15  | 3.3%  | static lookup/config (`allapp_systemparameters`, `ddb_status`) |
| **total** | **450** | | 1:1 with 450 base tables |

`modify ... unique on` = **377** of 450 `[FACT]`. The remaining 73 are non-unique keyed (`to btree on` without `unique`) — deliberately append-heavy log/audit tables that must allow duplicate keys: `cfg_group`, `fms_audittrail`, `fms_archivecard`, `fms_archivelog`. `[FACT]`

### 1.2 Key strategy — the `unique on (...)` clause IS the de-facto primary key `[INFERENCE]`

No declared PK exists. Each table's clustering/primary key is the column list of its `modify ... unique on`. Examples `[FACT]`: `udb_object`→`object` (single surrogate int); `udb_type`→`type,name` (composite); `cac_lastkey`→`tablename`; `cac_cardtype`→`type,cardtype`; `allapp_systemparameters`→`rowkey`.

### 1.3 Secondary indexes: ZERO `[FACT]`

- `create index` count = **0**.
- No base table has more than one `modify` — all 450 `modify` targets are distinct (verified). The previously-suspected "`udb_temp` with 3 modifies" was a misread of three *separate* heap tables (`udb_temp$audittrail`, `udb_temp$objectlist`, `udb_temp$terminallist`). `[FACT - corrected in verified pass]`
- **Consequence:** every non-key lookup is a full table scan. On the large operational modules (`fms_` 114 tables, `soa_` 86 tables, `ir_` 38) this is a structural performance ceiling. `[INFERENCE - High]`

---

## 2. Keys — `lastkey`-driven surrogate-int pattern

Consistent surrogate-int identity centered on `udb_object.object integer not null not default` (the only `not null not default` column; btree-unique-clustered on `object`). `[FACT - DDL + modify read verbatim]`

- **Sequence allocators = `*_lastkey` tables** (one row per logical table), NO Ingres sequence objects: `udb_lastkey`, `cac_lastkey`, `tc_lastkey`, `msg_lastkey`, `soa_joblastkey`, `soa_loglastkey` (6 confirmed). `[FACT]`
  - `udb_lastkey(lastkey char(40) not null not default, value integer not null not default)` — created `heap/nojournaling`, then `modify ... to hash unique on lastkey ... concurrent_updates` + `set journaling on`. `[FACT]`
- **Allocation idiom = increment-then-read-back, guarded:** `UPDATE *_lastkey SET value=value+1 WHERE lastkey=:K; SELECT :NewKey=value ...; IF iierrornumber=0 AND iirowcount=1 THEN RETURN :NewKey ELSE RETURN -1`. Canonical: `Udb_NextKey` (line 32630). `[FACT - body read verbatim]`
- The `=1` rowcount guard is the only concurrency/uniqueness safety on key allocation. `[FACT]`
- **Duplication smell:** `CAC_KeyGenerator1..8` (lines 27839+) are 8 near-identical bodies each hard-wired to one log/archive table (`fms_archivelog`, `soa_archivelog`, `tc_archivelog`, `soa_log`, `tc_log`, ...) — copy-paste of one table-driven proc. The allocation idiom is ALSO **inlined** in dozens of business procs (`object$insert` line 30459, `SOA_ISPRequestCopy` line 31303, `CAC_InsertRelayType`, `FMS_SaveEquipJob`) instead of calling `Udb_NextKey`. `[FACT]`
- `udb_nextkey` exists as both a stub and the real allocator; the per-module `CAC_KeyGenerator*` are the rule/internal allocators. `~152` `lastkey` references → surrogate keys are pervasive. `[FACT/INFERENCE]`

---

## 3. Declared-vs-App Integrity — VERDICT: 100% in-code

### 3.1 Declared integrity: NONE `[FACT - decisive]`

| Construct | Raw grep | Real declared constraints | Verdict |
|---|---:|---:|---|
| `references` | 450 | **0** | all 450 are `grant references ... to public` (privilege), not FK clauses |
| `foreign key` | 0 | 0 | no declared FKs |
| `primary key` | 0 | 0 | no declared PKs |
| `check (` | 25 | **0** | all 25 are table/proc *names* containing "check" (`fms_phasecheck`, `*DelayCheck`) |
| declarative `unique` | 0 | 0 | uniqueness lives only in `modify ... unique` storage statements |

`not null` appears 4,727× — the **only** declared integrity in the schema (column nullability). Most columns are sentinel-defaulted (`not null default ' '` / `default 0`); a handful of date/coord columns are genuinely nullable. `[FACT]`

### 3.2 Integrity-in-code: PROVEN (validate-and-log, not reject-at-write)

All RI/cascade/validation lives in 1,225 real procedures + 290 rules + 208 dbevents. Load-bearing proof (all bodies read verbatim in verified pass) `[FACT]`:

- **Cascade delete, hand-coded:** `CAC_CO_GroupingDel` (line 27789) deletes from 7 child tables in sequence with manual `IF iierrornumber<>0 THEN return -1` after each (`CAC_CO_Circuit, _Feeder, _Info, _Note, _Note_Link, _Status, _Attachment`). No `ON DELETE CASCADE` exists. `[FACT]`
- **FK-existence validation, post-hoc:** rules like `FMS_JobClassCtrl$Insert1` call `FMS_ValidateEquipClass(...)` *after* insert — parent-existence checked, violation **recorded** not rejected. `[FACT]`
- **Domain validation → exception ("grass-catcher") tables:** `Conductor$Validate` (line 27992): `IF (X/R)<5 THEN INSERT INTO Udb_GrassCatcher(Object,Problem) VALUES(:Object,'Conductor_001')`. Bad data lands; it is flagged after the fact. `[FACT]`
- Exception sinks: `udb_grasscatcher(object, problem char(20), text char(20), known integer)`, `udb_problem(problem char(20), severity char(1), description char(60))`, plus `fms_mhproblem`, `soa_connectivityproblem`, `tc_problemtracker`, `pvl_xref_exception`. `udb_grasscatcher.problem → udb_problem.problem` is the undeclared severity lookup. **31** `INSERT INTO Udb_GrassCatcher` sites exist (verified; earlier "56" was an overcount conflating textual mentions). `[FACT]`

**Verdict:** PSM is a **detective, not preventive** integrity model. Bad/orphan data can be committed; rules/procs surface it into problem tables for later cleanup. Correctness depends entirely on (a) every rule firing and (b) the client honoring grass-catcher rows. `[INFERENCE - Critical]`

---

## 4. Security / Grant Model — VERDICT: flat, no privilege separation

### 4.1 Grants (4,835) — 100% to `public` `[FACT]`

Grantee tally: **`public` = 4,835 (100%)**. Zero named roles/users (grep of all `^grant` lines not ending `to public` = 0). `[FACT]`

| Privilege | Count | Target |
|---|---:|---|
| execute | 1,225 | procedures (1:1 with real procs) |
| references | 450 | tables |
| select | 449 | tables |
| update / insert / delete | 448 each | tables |
| copy_into / copy_from | 448 each | tables |
| register | 208 | dbevents |
| raise | 202 | dbevents |
| modify | 49 | tables |

Per table, a standard 7-grant block goes to `public`: `select, update, delete, insert, references, copy_into, copy_from`. **Net effect: any connected client has full DML + `modify`/`copy`/`references` (DDL-ish) + execute on everything.** `[INFERENCE - Critical: no privilege separation]`

### 4.2 Revokes (180) — the ONLY access control `[FACT]`

100% are `revoke execute on procedure X from public cascade` (180/180, zero exceptions). These lock down **trigger-only / sequence-only** procs so they fire solely via the rule engine: `cac_keygenerator1..8`, `cardtype$delete/$insert/$typedelete`, `cascadetype$change`, `conductor$validate`, `consumer$updateloadmodel`, `csd_message$ins`, `ddb_logentry`. **Pattern: grant execute to all, then revoke the rule-internal procs.** `[FACT/INFERENCE]`

### 4.3 Dbevent security `[FACT]`

`grant register` = 208 (all dbevents); `grant raise` = 202. The 6 **register-only** (server-raised, clients may subscribe but not publish): `ddb_logentry, fms_deadmovescount, fms_estimateduptime, fms_invalidcard, fms_update_grounds, sds_dbunload`. `[FACT]`

---

## 5. Archive / Temporal / Audit Pattern — hand-rolled, no DBMS temporal

### 5.1 Archive twin tables — 35 `<module>_archive*` `[FACT]`

Manual soft-history: `INSERT INTO X_Archive SELECT ... FROM X WHERE ...` then `DELETE` inside procs (e.g. `FMS_ArchivePhaseCheck` ~line 28435). **No system-versioning / temporal feature is used.** Several archive tables are `to btree on` (NON-unique) = append-only history. Archival is also fired async via `RAISE DBEVENT SOA_ArchiveTrigger :ControlText`. Full 35-table list verified (`cac_archive*` ×2, `fms_archive*` ×9, `soa_archive*` ×6, `tc_archive*` ×7, `tfms_archive*` ×4, plus `gta/msg/oa/slc` archives). `[FACT — population proven on a sampled subset; uniform pattern INFERENCE for all 35]`

### 5.2 Per-row audit columns — centralized on `udb_object`, sparse elsewhere `[FACT]`

`udb_object` carries the full audit/lock set: `created/createdby, lastchanged/lastchangedby, validated/validatedby, locked/lockedby` (dates = nullable `ingresdate`; `*by` = `char(24) not null default ' '`). `created/createdby` set in `object$insert` (`Created='Now', CreatedBy=VARCHAR(User)`). Prevalence elsewhere is thin: `createdby` on only ~4 tables. **Audit is NOT a universal row pattern** — it lives on the central object table + a few feature tables. `[FACT/INFERENCE]`

### 5.3 Audit-trail + history tables `[FACT]`

- One dedicated field-level change log: `fms_audittrail(rowkey, entity, handle, logtime, operator, item, old varchar(200), new varchar(200), operatorname, handlename)` — `modify ... to btree on (entity, handle, ...)` NON-unique. Classic (entity, item, old→new, operator, time) audit row, populated in code. `[FACT - DDL; population path INFERENCE]`
- Domain history tables written by rules: `fms_groundhistory, fms_highpothistory, soa_hipothistory, soa_scenariohistory, tv_bogeyhistory, udb_groupinghistory, cac_relay_groupinghistory`. E.g. rules `FMS_GroundHistory1/2/3` append before/after counts on `FMS_ObjectStatus` changes where `Status IN (10016,10053)`. `[FACT]`

---

## 6. Concurrency Model

- **`set lockmode` = 0 in d1.sql** (decisive). The Phase-0 "8 set lockmode" usages are NOT in the server schema — they live in the OpenROAD `.dmt` client 4GL. **The server DB does zero explicit lock-mode tuning.** `[FACT — contradiction with Phase-0 confirmed real]`
- **Optimistic-lock token:** `systemversion integer not null default 0` on **exactly 3 tables** — `udb_object, udb_grouping, udb_groupinghistory`. Intended as a version token on core metamodel rows, but **NOT enforced by any constraint**; whether it is checked on UPDATE is `[UNKNOWN]` (not visible in sampled proc bodies). `[FACT — 3 tables; enforcement UNKNOWN]`
- **Pessimistic / app-level locks:** `udb_object.locked (ingresdate) / lockedby (char(24))` = application-level row-checkout/edit-lock, distinct from DBMS locks; `validated/validatedby` = approval-workflow stamp. `[INFERENCE - DDL]`
- **Key-allocation serialization:** relies on the `UPDATE *_lastkey SET value=value+1` write-lock under Ingres default locking — no sequence object, no explicit lockmode. **Each single-row `*_lastkey` is a contention hotspot under load.** `[INFERENCE - Medium]`
- **Transaction model:** procs contain NO explicit transaction control (`COMMIT` appears exactly once, in `SetSesameLockCardFormID` line 30678, as an intra-loop lock-release; `ROLLBACK` = 0). Procs run inside the **caller's** transaction; success/failure is signalled by `RETURN 0 / RETURN -1` (1,396 `iierrornumber` checks drive this). **Partial-write hazard:** multi-statement procs (`SOA_ISPRequestStatusUpd`) `RETURN -1` *after* a successful first UPDATE with no compensating rollback — the client must roll back or partial state persists. `[FACT - Medium]`
- `readlock/nolock` referenced in only ~5 lines. `[FACT]`

---

## 7. Sentinel / Overload Bloat (quantified)

- **Sentinel-default bloat:** on `udb_object` (30 cols), **20/30 (66.7%)** are `not null` + sentinel default (`default ' '` or `default 0`); 9/30 genuinely nullable (the dates + `source` + 2 GIS floats); 1/30 is the `not null not default` PK. This sentinel convention recurs schema-wide (`not null default ' '`/`default 0` is the house style; `not null` appears 4,727×). `[FACT]`
- **Why it is worse than NULL** `[INFERENCE, structurally grounded]`: (a) cannot distinguish "unknown" from "blank/N-A" (`serialnumber=' '`, `basetype=0`); (b) magic-value coupling — code must test `=0`/`=' '` everywhere (`object$insert`: `IF BaseType=0 THEN ...Object_012`); (c) `udb_object.object=0` is so dangerous it is **banned by trigger** `Object$NullObjectProtect → reject('Object_014')` — direct evidence the sentinel-zero leaks a forbidden value into a meaningful column; (d) joins silently match sentinels instead of NULL-eliminating; (e) the engine can never report "value not supplied," so presence is enforced reactively via grass-catcher problems (`Object_012`, `Type_010`). `[FACT - branches read verbatim]`
- **Column overload (god-table):** `udb_object` carries 5 reusable tag slots (`ownernumber, serialnumber, specnumber, combination, locknumber` — char(20)/varchar(40)) whose meaning varies by object type. `[FACT - DDL; reuse INFERENCE]`
- **Denormalized-cache bloat:** `basetype`, `typename`, `primarygroupingname` on `udb_object` and `membertype`/`groupingtype` on `udb_grouping` are redundant derivations of `udb_type`/parent rows, kept consistent only by trigger discipline. `[FACT]`

---

## 8. Naming Conventions

- **Tables:** `<module>_<entity>` lowercase, strict module prefix (fms_ 114, soa_ 86, udb_ 53, ir_ 38, tc_ 33, cac_ 24, ...). Archive twins = `<module>_archive<entity>`; sequence tables = `<module>_lastkey`; subtype/STI side tables = `udb_<typename>` with `object` as first column. `[FACT]`
- **Procedures:** two families. (1) **CRUD wrappers** `<Module>_<Entity><Verb>` with `Ins/Upd/Del` suffix — 65% (`*Upd`/`*Update` 310, `*Ins`/`*Insert` 268, `*Del`/`*Delete` 211, `*Validate` 7 = 796 of 1,225). (2) **Rule-target procs** `<Type>$<Event>` (`object$insert`, `CardType$Delete`, `SuperType$Insert`) — fired by rules, mostly revoked from public. `[FACT]`
- **Inconsistencies (noisy but harmless to case-insensitive Ingres):** mixed case for the same logical proc (`CAC_*` vs `cac_*`; stubs lowercase, real bodies MixedCase); inconsistent verb placement (`TC_InsertCard` AND `tc_cardins` both exist) — no single grep finds "all inserts." Real bodies sometimes written `create or replace procedure  ingres.<Name>` (schema-prefixed, double space). `[FACT]`

---

## 9. Rules (290) + Dbevents (208) — the automation spine

### 9.1 Rules — thin rule → fat proc `[FACT]`

All rules: `AFTER {INSERT|UPDATE(col)|DELETE} ON <t> [WHERE ...] EXECUTE PROCEDURE <proc>(args=New./Old.cols)`. Verbs (case-combined): UPDATE ~119, INSERT ~112, DELETE ~59. Hottest targets (re-tally, approximate ±1): `Udb_Grouping` ~29, `FMS_ObjectStatus` ~25, `FMS_Card` ~23, `Udb_Object` ~19, `SOA_Job` ~17, `TC_Job` ~11. The metamodel grouping/object tables + FMS status/card tables carry the bulk of trigger logic. `[FACT - relative ranking sound; exact per-table count needs a disambiguated parser]`

**Rule taxonomy** `[INFERENCE from sampled bodies]`: (a) cascade/RI enforcement (`CardType$Delete`); (b) **denormalized-cache sync** (`CascadeType$Change` line 27983 keeps `udb_grouping.membertype/groupingtype` aligned to `udb_object.type`; `DDB_RepStatusDescUpd` keeps status-label text current); (c) validation-to-exception-table (`Conductor$Validate`, `FMS_JobClassCtrl$Insert1/2`); (d) history capture (`FMS_GroundHistory1/2/3`); (e) derived-state/resequencing (`FMS_Feeder_Cutout1/2` where `Status=10110`; `FMS_JobClassResequence`); (f) rule→dbevent async fan-out (`CSD_Message$Ins → RAISE DBEVENT`).

Hardcoded **magic ints** are embedded in rule WHERE clauses — these are the absent seed-row enums: status `10016` (14×), `10053` (8×), `10110`, operatingstep `10147` (16×), relationship `52`, supertype `10093`/`26`/`21`/`05`/`15028`, obsolete types `999/22173/22174`. Meanings `[UNKNOWN]` without seed rows. `[FACT - values present; meanings UNKNOWN]`

### 9.2 Dbevents — async pub/sub notification backbone (208) `[FACT]`

Mechanism: server procs/rules `RAISE DBEVENT "ingres".<name> [:payload]`; clients `register`/wait. Ingres queues dbevents and delivers on commit (no nested-txn issue). 60 raise sites across ~33 procs. Busiest channels: `SOA_ActiveListChange` (10 sites), `FMS_Status_Change` (4). Payload idiom = `;`/`:`-delimited string built with `VARCHAR(...)` casts (e.g. `Varchar(:ActiveCard)+':'+Varchar(:NewStatus)+':'+:NewStatusName`). `[FACT]`

By module prefix: fms 44, ir 35, soa 29, tc 27, soo 11, opnet 9, xa 8, dmz 7, ddb 5, report/msg 4, fra 3. **Semantic clusters:** outage/switching state machine (`soa/tc/ir`), real-time SCADA/EMS bridge (`xa/qgis_realtimeupdate/fms_status_change`), replication/HA (`ddb/opnet/dmz/replicator_status`), messaging (`msg/csd_messagesend`), monitor lifecycle (`*_startmonitor/*_stopmonitor`). **The real-time automation spine: DB state change → dbevent → background monitor / SCADA bridge / UI reacts.** `[FACT/INFERENCE - high confidence]`

### 9.3 The double-declaration mechanic `[FACT]`

`d1.sql` has **2,450** `create or replace procedure` = **1,225 stubs** (`as begin return; end`, forward-declarations so rules/grants bind) + **1,225 real bodies**. "2,450 procedures" = 1,225 distinct procs each declared twice. Risk: a stub left un-replaced = a silent no-op trigger. `[FACT]`

---

## 10. DESIGN-QUALITY FINDINGS — ranked by severity

| # | Severity | Finding | Evidence | Impact |
|---|---|---|---|---|
| 1 | **Critical** | **Zero declared referential integrity** — no FK, CHECK, PK, or UNIQUE *constraints*. All RI/cascade/validation is imperative (1,225 procs + 290 rules). Model is detective (validate-and-log to grass-catcher), not preventive. | `[FACT]` references=450 all grants; FK=0; CHECK-constraints=0; PK=0; 31 `INSERT INTO Udb_GrassCatcher` sites | Orphan/invalid data commits successfully and is only flagged later. Correctness hinges on every rule firing AND the client honoring problem rows. Any direct SQL bypasses all integrity. |
| 2 | **Critical** | **Flat security: 4,835 grants → `public` only, no roles.** Every client gets full DML + `modify`/`copy`/`references` + execute on everything. Sole mitigation = 180 `revoke execute ... cascade` on trigger-only procs. | `[FACT]` grantee tally 100% public (0 non-public) | No least-privilege, no separation of duties, no read-only role. Any authenticated session can DROP-equivalent (`modify`), bulk-`copy`, or mutate any table. |
| 3 | **High** | **No secondary indexes** (`create index`=0); one clustering structure per table (450/450). | `[FACT]` | Every non-key predicate is a full scan. Structural performance ceiling on large operational tables (`fms_`/`soa_`/`ir_`). No tuning lever short of schema change. |
| 4 | **High** | **Denormalized caches kept consistent only by rules** — `udb_object.basetype/typename`, `udb_grouping.membertype/groupingtype`, status-label text. | `[FACT]` `CascadeType$Change` body verbatim | Rule disablement or direct-SQL write silently desyncs `udb_object` vs `udb_grouping`. **Confirmed latent bug:** NO `AFTER UPDATE(BaseType) ON Udb_Type` rule and nothing writes `udb_object.basetype` outside `object$insert` → changing a type's basetype leaves all existing instances pointing at the stale/wrong STI table. |
| 5 | **High** | **Integrity logic double-maintained** — 1,225 stubs vs 1,225 real bodies; rules bind by name; some real bodies are case/whitespace-variant. | `[FACT]` | Drift risk; an un-replaced stub = silent no-op trigger. Mixed-case binding tripped verification greps — real maintenance hazard. (Also: `' Generator'` leading-space literal in `object$insert` ladder is a live dispatch bug.) |
| 6 | **Medium** | **Key-allocation hotspot + duplication** — single-row `UPDATE *_lastkey SET value+1` per insert, no sequence object, no explicit lockmode; idiom inlined in dozens of procs; `CAC_KeyGenerator1..8` = 8 copy-paste bodies. | `[FACT]` `Udb_NextKey`/`CAC_KeyGenerator1` bodies | Serialization point on each `*_lastkey` single row under concurrent inserts. Maintenance cost: one logic change must be applied in many inlined copies. |
| 7 | **Medium** | **Partial-write hazard under caller-managed transactions** — procs have no `COMMIT`/`ROLLBACK` (1 COMMIT total, 0 ROLLBACK); multi-statement procs `RETURN -1` after a successful first UPDATE with no compensation. | `[FACT]` `SOA_ISPRequestStatusUpd` returns -1 mid-body | If the OpenROAD client fails to roll back on a `-1`, the DB is left in a partially-mutated, inconsistent state. |
| 8 | **Medium** | **Hand-rolled archival, no DBMS temporal** — 35 twin tables via `INSERT…SELECT…+DELETE` in procs; some archive tables non-unique. | `[FACT]` 35 confirmed | History correctness depends entirely on proc code; no point-in-time/system-versioning guarantee; archival failures are silent. |
| 9 | **Medium** | **Sentinel-default overload (66.7% of `udb_object`)** + god-table tag slots. `0`/`' '` conflate unknown/blank/N-A; `object=0` had to be trigger-banned. | `[FACT]` 20/30 sentinel; `Object$NullObjectProtect` | Cannot enforce "required"; joins/aggregates silently include sentinels; presence checked reactively via grass-catcher only. Data-quality blind spots. |
| 10 | **Medium** | **`systemversion` optimistic-lock token present but unenforced** and only on 3 tables; `locked/lockedby/validated*` are app-level, not DBMS. | `[FACT]` 3 tables; enforcement `[UNKNOWN]` | If UPDATE doesn't actually check `systemversion` (not visible in sampled bodies), lost-update protection is illusory. |
| 11 | **Low / Data-quality** | **Magic ints throughout rule/proc WHERE clauses** (10016/10053/10110/10147, 91/26/21/05, 52, 999/22173/22174, 15028) — semantics live in absent seed rows. | `[FACT]` values present; meanings `[UNKNOWN]` | Unreadable business logic; any reimplementation cannot recover code meanings without the `.ingres` seed data. |
| 12 | **Doc-discrepancy** | **Phase-0 "8 set lockmode" is 0 in d1.sql** — those usages are in `.dmt` client 4GL, not the server schema. | `[FACT]` 0 in d1.sql | Server has no explicit lock-mode tuning; any concurrency tuning lives client-side. |

---

## 11. Control-flow (integrity / automation)

```mermaid
flowchart TD
  C[Client / OpenROAD frame] -->|execute proc| P[Server procedure 1,225 real]
  P -->|UPDATE *_lastkey +1| K[(udb/cac/tc *_lastkey)]
  P -->|INSERT/UPDATE/DELETE| T[(Base table e.g. udb_object)]
  T -->|AFTER trigger| R[Ingres rule 290]
  R -->|EXECUTE PROCEDURE New./Old.| P2[Trigger proc revoked from public]
  P2 -->|cascade DELETE children| T2[(child tables)]
  P2 -->|denorm sync MemberType/GroupingType| G[(udb_grouping cache)]
  P2 -->|validation fail| X[(udb_grasscatcher / *_problem)]
  P2 -->|history INSERT| H[(fms_groundhistory / *_history)]
  P2 -->|archive INSERT..SELECT + DELETE| A[(*_archive 35 tables)]
  P2 -->|RAISE DBEVENT :payload| E((dbevent 208))
  E -->|register/wait| M[Background monitor / UI / SCADA bridge]
  M -->|reacts: refresh, automate, push| C
```

---

## 12. Gaps / UNKNOWN

- Meaning of all status/type/relationship integer codes (10016, 10053, 10110, 10147, 91/26/21/05, 52, 15028, 999/22173/22174) — require absent seed rows. `[UNKNOWN]`
- Whether `systemversion` is actually checked on UPDATE — not in sampled bodies. `[UNKNOWN]`
- Whether all 35 archive tables are actively populated — subset proven, uniform pattern inferred. `[INFERENCE]`
- Exact location/intent of the 8 `set lockmode` — almost certainly `psm.dmt`/`psm_4glprocs.dmt` 4GL. `[UNKNOWN]`
- Full per-table key-column catalog (450 rows) and ±1-exact per-table rule counts — method given; sampled only. `[partial]`
