# Deliverable 4 — Modernization & Optimization Assessment

**Target:** SQL Server 2025 + .NET 9/10, on-premises, regulated OT/IT (NERC-CIP-adjacent), 24/7 grid-critical. Data stays in-enterprise; GIS/Esri, SCADA/EMS, planning integrations are first-class.

**Method:** every recommendation is `problem → evidence (cited to the verified sections) → change → benefit → risk & effort (S/M/L)`. Claims tagged `[FACT - file→object]`, `[INFERENCE]`, `[UNKNOWN]`. I do not re-derive counts; I cite the synthesis sections (`10-metamodel`, `20-schema-mechanics`, `30-applogic-business`, `d3-job-deepdive`, `50-how-udb-works`) and the verified docs (`metamodel-subtypes`, `peripheral-modules`).

**The central tension, stated once:** UDB was attractive because **a new equipment type is a data row, not a DDL migration** — `udb_object.type → udb_type → udb_basetype.tablename` plus a CTI subtype table `[FACT - 10-metamodel §1-2]`. That metadata-driven flexibility is the single property a 24/7 grid-critical schema must preserve. BUT the flexibility is **half-fake**: dispatch is a hard-coded 22-branch `IF/ELSEIF` ladder in `object$insert`, and adding a base type needs **both** a `udb_basetype` row **and** a code edit `[FACT - 10-metamodel §2.1]`. So the real requirement is narrower than the legend: **adding a new TYPE under an existing BASETYPE is already DDL-free; adding a new BASETYPE (new attribute shape) is not.** Every model option below is judged against that actual requirement, not the myth.

---

## 0. Executive ranking (value vs effort)

Ranked by (operational value ÷ effort), gating items first.

| Rank | Recommendation | Value | Effort | Section |
|---|---|---|---|---|
| 1 | **Recover the absent `.ingres` seed data from the live DB before anything else** (type/basetype/supertype/problem/status catalogs) | Blocking | S | §4.1 |
| 2 | **Add declared PK + UNIQUE constraints** matching the 377 `modify … unique on` de-facto keys | High | S | §2.1 |
| 3 | **Hybrid data model: keep metadata-driven typing (STI-ish root + per-basetype subtype tables), NOT pure STI, NOT graph-as-storage** | High | M | §1.5 |
| 4 | **Add FKs for the high-traffic join keys** (`object`, `card`, `job`, `permitjobid`, `node`) as NOT-ENFORCED→ENFORCED in stages | High | M | §2.2 |
| 5 | **Replace the 35 archive twins + audit columns with system-versioned temporal tables** | High | M | §1.2, §2.5 |
| 6 | **Ledger tables for the regulated audit trail** (switching-order/clearance/permit history) | High (compliance) | M | §1.3 |
| 7 | **Anti-corruption boundary services for GIS/Esri, SCADA/EMS, planning** (no shared tables; map to CIM vocabulary only at the boundary) | High | L | §3 |
| 8 | **Move integrity-in-code into CHECK/computed/FK where SAFE; keep the grasscatcher detective layer for soft rules** | Medium-High | L | §2.3, §2.4 |
| 9 | **Replace `*_lastkey` single-row allocators with SEQUENCE objects** | Medium | S | §2.6 |
| 10 | **SQL Server graph tables for connectivity (terminal/node + grouping) as a query/trace layer, not the equipment store** | Medium | M | §1.4 |
| 11 | **Strangler-fig migration sequencing; re-home the OpenROAD client 4GL into a .NET service tier** | Gating for cutover | L | §4 |

---

## 1. TARGET DATA-MODEL OPTIONS

### 1.1 The three storage options, judged against the schema-stability requirement

| Option | What it is | DDL-free new TYPE? | DDL-free new BASETYPE (attr shape)? | Query perf | Integrity-in-schema | Verdict |
|---|---|---|---|---|---|---|
| **A. Pure STI** | one wide `Equipment` table, all subtype columns nullable/sparse, discriminator column | Yes | Yes (add sparse column = online metadata op) | Best (no joins) | Weak — can't NOT-NULL a column that only applies to one type | **Reject as sole model** — recreates the `udb_object` god-table + sentinel-default anti-pattern `[FACT - 20-schema-mechanics §7]` |
| **B. Pure per-type subtype tables (CTI, today's model)** | root + one rigid table per basetype, 1:1 on key | Yes (new type under existing basetype) | **No — new table = DDL** | Good (1 join) | Strong per-table | **Reject as sole model** — fails the "new shape = no DDL" half of the requirement; this is exactly today's pain |
| **C. Hybrid (RECOMMENDED)** | root table + per-**basetype** subtype tables for the ~22 stable shapes + a JSON/sparse extension column on root for long-tail/new shapes | Yes | **Yes** for long-tail via JSON; DDL only when you choose to promote a hot JSON attribute to a typed column | Good; hot path typed, cold path JSON | Strong on typed cols, schema-validated JSON on the rest | **Adopt** |

**Evidence the hybrid fits the real data:** the model already IS a hybrid — `udb_object` is a wide root with 5 overloaded `char(20)` tag slots (STI-like overloading) PLUS 22 enumerated CTI subtype tables PLUS a legal `tablename=''` no-op branch for root-only types `[FACT - 10-metamodel §1.1, §2.1]`. The 22 subtype shapes are stable physics (transformer windings, conductor impedance, switch normal-open) `[FACT - metamodel-subtypes §2]` and deserve **real typed tables with real CHECK constraints**. The long tail (`tablename=''` types, the ≥19 base types with no insert branch, future equipment) belongs in a **schema-validated `nvarchar(max)` JSON column** on the root with a SQL Server 2025 JSON type / `ISJSON`+`JSON_PATH` CHECK constraints, so a genuinely new attribute shape is a metadata row, not a migration.

### 1.2 Temporal tables — replace the 35 archive twins + audit columns

- **Problem:** history is hand-rolled. 35 `<module>_archive*` twin tables populated by `INSERT…SELECT…+DELETE` inside procs; correctness depends entirely on every proc firing; archival failures are silent; some archive tables are non-unique append-only `[FACT - 20-schema-mechanics §5.1]`. Audit columns (`created/createdby/lastchanged/lastchangedby/validated/validatedby/locked/lockedby`) live centrally on `udb_object` and are sparse elsewhere `[FACT - 20-schema-mechanics §5.2]`.
- **Change:** make the operational tables **SYSTEM_VERSIONED TEMPORAL** (`ValidFrom/ValidTo` + history table). Drop the 35 twins; the engine maintains history transactionally. Keep `createdby/lastchangedby` as the actor columns (temporal records *when*, not *who* — you still need the who).
- **Benefit:** point-in-time queries (`FOR SYSTEM_TIME AS OF`), zero hand-rolled archival, no silent archive-failure class, automatic consistency with the source row. Eliminates ~35 tables + the proc code that maintained them.
- **Risk & effort: M.** Risk: the legacy archive tables sometimes carry a *different/older column shape* (e.g. `fms_archivejob` is the only place the FMS job-row shape survives `[FACT - d3-job-deepdive §b.1]`) — temporal history mirrors the live shape exactly, so any "archive-only" columns must be reconciled first. Bus-fault/outage capture tables (`soa_busfaultoutage`, 67 cols `[FACT - d3-job-deepdive §4.3]`) are append telemetry, not versioned rows — leave those as plain tables.

### 1.3 Ledger tables — tamper-evident audit for the regulated surface

- **Problem:** in a NERC-CIP-adjacent setting the switching-order, clearance/LOTO, and permit records are the compliance record-of-record, yet today they have **zero tamper-evidence** and the whole DB is writable by `public` (4,835 grants, 100% to public; any session can `modify`/`copy`/mutate any table) `[FACT - 20-schema-mechanics §4]`. The clearance card (`fms_sesamelockcard`) is **descriptive, not enforcing** — no proc gates a move on it `[FACT - d3-job-deepdive §8.4]`.
- **Change:** put the **append-only regulated facts** on SQL Server **updatable ledger tables**: switching-order state transitions, in-service-permit approvals (`SOA_ISPStatusUpd` 18-state machine `[FACT - d3-job-deepdive §6.3]`), work-permit issue/return (`IR_ReturnWorkPermit` permitstatus=50 `[FACT - d3-job-deepdive §7.3]`), and clearance/sesame-lock entries. Ledger gives cryptographic tamper-evidence + database-level digest you can attest to auditors.
- **Benefit:** provable, immutable audit chain for the regulated workflow without a separate audit subsystem; directly answers the CIP "who did what, provably" question that flat `public` security cannot.
- **Risk & effort: M.** Ledger tables are append-friendly but the legacy model *updates rows in place* (a permit row's `permitstatus` flips to 50). You must model these as **event/transition rows** (one append per state change) rather than mutate-in-place — a real schema redesign for those few tables. Do NOT ledger the high-churn operational tables (job render caches, active lists) — overhead and append-only semantics don't fit. Scope ledger to the compliance record-of-record only.

### 1.4 Graph tables — connectivity, as a query layer, NOT the equipment store

- **Problem:** two instance graphs sit on `udb_object`: electrical connectivity (`udb_terminal.node` — two objects connected ⟺ shared node) and containment (`udb_grouping`, relationship-typed, ~295k edge estimate, the largest in the metamodel) `[FACT - 50-how-udb-works §2; metamodel-subtypes §6]`. The outage-detection connectivity trace walks the terminal/node graph; that trace algorithm is **client/monitor 4GL, body absent from all artifacts** `[FACT - 50-how-udb-works §2.1, UNKNOWN body]`.
- **Change:** model node/terminal adjacency and grouping containment as SQL Server **graph NODE/EDGE tables** and express the trace as `MATCH`/`SHORTEST_PATH`, OR keep relational tables and use recursive CTEs. Graph tables earn their place ONLY for the trace/grouping-rollup queries.
- **Benefit:** the de-energization trace ("if I open this switch, what loses power?") becomes a first-class, server-side, set-based query instead of opaque client 4GL — recoverable, testable, and consistent across callers. Grouping roll-up (consumer load aggregation up the containment tree, `BaseType=21` `[FACT - 50-how-udb-works §2.2]`) maps naturally to graph traversal.
- **Risk & effort: M.** Caveat: there are **two coexisting connectivity models** — TOMS/DSO use the QGIS geometry model (`dso_object`/`dso_connection`), only SMS/FMS-3G/Staten-Island-33kV use the Udb terminal/node model `[FACT - metamodel-subtypes §6; peripheral-modules §3.1]`. Graph tables solve the *terminal/node* model; the QGIS model is a separate render cache (see §3). Do **not** make graph tables the equipment store — equipment lives in §1.5's hybrid; the graph references it by key.

### 1.5 The recommended target model (synthesis)

```
Equipment (root, system-versioned temporal)
  ├─ EquipmentType  (type, basetype, name, …)         ← metadata; new TYPE = INSERT
  ├─ Basetype       (basetype, subtype_table, editor)  ← metadata; subtype_table nullable
  ├─ per-basetype typed subtype tables (Transformer, Switch, Conductor, … ~22)
  │     1:1 on equipment_id, REAL CHECK/FK constraints, sparse where appropriate
  ├─ ExtensionJson  nvarchar(max)  CHECK (ISJSON(...)=1)  ← long-tail / new shapes, DDL-free
  ├─ Node / Terminal      → SQL graph EDGE for electrical connectivity trace
  └─ Grouping (typed edges)→ SQL graph EDGE for containment / roll-up
Regulated facts (switching order, ISP, work permit, clearance) → LEDGER (append, tamper-evident)
```

- **New TYPE under existing BASETYPE:** `INSERT` into `EquipmentType` — DDL-free, preserves the property that justified UDB `[FACT - the 22-branch ladder already dispatches by basetype, not type — 10-metamodel §2.1]`.
- **New BASETYPE / attribute shape:** land it in `ExtensionJson` (DDL-free); promote to a typed subtype table later if it becomes hot. This **fixes** the half-fake flexibility: today a new basetype needs a code edit to `object$insert`; here it needs neither code nor DDL.
- **Replace the `object$insert` hard-coded ladder** with a metadata-driven dispatch (the subtype_table is selected from `Basetype`, not an `IF/ELSEIF`), eliminating the "add a basetype = edit a stored proc" trap and the latent stale-basetype desync bug (no `AFTER UPDATE(BaseType)` rule today `[FACT - 10-metamodel §5.4`, CONFIRMED latent bug]).

---

## 2. CRITICAL DB OPTIMIZATIONS

### 2.1 Declare PK + UNIQUE constraints (the de-facto keys are already known)

- **Problem:** zero declared PK/UNIQUE constraints; uniqueness lives only in `modify … unique on` storage statements; 377 of 450 tables have one `[FACT - 20-schema-mechanics §1.1, §3.1]`.
- **Change:** generate `PRIMARY KEY`/`UNIQUE` constraints directly from the 377 `modify … unique on` column lists; the 73 deliberately non-unique log/audit tables stay heap/non-unique.
- **Benefit:** the optimizer gets real cardinality/uniqueness; lost-update and duplicate-key bugs become engine-enforced instead of relying on the `iirowcount=1` guard in key allocators `[FACT - 20-schema-mechanics §2]`; self-documenting schema.
- **Risk & effort: S.** Mechanical transform; the only risk is data that violates the de-facto key today (possible, since nothing enforced it) — surface violations before applying.

### 2.2 Add FKs on the hot join keys, staged NOT-ENFORCED → ENFORCED

- **Problem:** **zero declared FKs**; all RI is post-hoc proc checks fired by AFTER rules that **log, not reject** (`FMS_ValidateEquipClass` pattern) `[FACT - 20-schema-mechanics §3]`. The `permitjobid↔job` and `card↔job` joins are name/value with no FK — a stale `permitjobid` silently orphans a permit `[FACT - d3-job-deepdive §7.5]`.
- **Change:** add FKs on the load-bearing keys — `equipment_id` (root↔subtype, root↔terminal/grouping/grasscatcher), `card`, `job`, `permitjobid`, `node`. Roll out as `NOT FOR REPLICATION`/initially `WITH NOCHECK` (validate existing data offline), then `WITH CHECK` once clean. Keep `ON DELETE` as `NO ACTION` and replace the hand-coded cascade ladders (`CAC_CO_GroupingDel` deletes 7 child tables sequentially `[FACT - 20-schema-mechanics §3.2]`) with declared `ON DELETE CASCADE` only where the legacy proc already cascades unconditionally.
- **Benefit:** orphan/invalid data is **rejected at write** instead of detected later; eliminates a whole class of the "bad data committed, flagged afterward" failures `[FACT - 30-applogic-business §e.2]`.
- **Risk & effort: M.** Risk: the detective model means orphans **already exist** in production data — enforcing FKs will reject loads until cleaned; the `udb_object` delete-ban rule (`Object$Delete → Reject` `[FACT - metamodel-subtypes §1]`) and re-type-to-Historical(998) pattern must be preserved (model as soft-delete/status, not physical delete + cascade).

### 2.3 Move SAFE integrity from the 1,225 procs into CHECK/computed columns

- **Problem:** ~1,225 procs + 290 rules carry all integrity; much of it is trivially declarable. Examples that are pure column predicates: `Object$Validate` rejects `InService > OutService` (→ `Object_001`); `Conductor$Validate` flags `(X/R) < 5` (→ `Conductor_001`) `[FACT - metamodel-subtypes §5]`; `object=0` is banned by a trigger `[FACT - 20-schema-mechanics §7]`.
- **Change:** express row-local invariants as `CHECK` constraints (`CHECK (OutService >= InService)`, `CHECK (object <> 0)`); express denormalized caches (`udb_object.basetype/typename`, `udb_grouping.membertype/groupingtype`) as **computed columns** or indexed views so they cannot desync — this directly kills the confirmed stale-basetype latent bug `[FACT - 10-metamodel §5.4]`.
- **Benefit:** fewer procs to port, integrity that direct SQL cannot bypass, self-documenting schema; computed columns make the denormalization-desync class of bugs structurally impossible.
- **Risk & effort: L.** Risk: NOT every validator is row-local — the X/R<5 conductor check is a **soft warning** (severity-driven), and many checks are cross-row/cross-table; do not force those into CHECK (see §2.4).

### 2.4 Keep the grasscatcher as the DETECTIVE layer for soft/cross-row rules

- **Problem:** the integrity model is **detective with selective rejection**, not preventive: validators `INSERT INTO udb_grasscatcher(object, problem)`, then `GrassCatcher$Insert` looks up `udb_problem.severity` and only `severity='F'` raises `RAISE ERROR -1` (rejects); everything else is logged and committed `[FACT - 10-metamodel §5.2; metamodel-subtypes §5]`. This is a deliberate operational choice (a 24/7 grid system cannot hard-reject every imperfect field entry).
- **Change:** preserve this two-tier model. Promote `severity='F'` rules to real constraints/triggers (preventive); keep non-fatal rules as a **data-quality exception table** written by triggers or a validation service. The `severity` lookup becomes a constraint-vs-warning routing table.
- **Benefit:** you get hard prevention where the business wants rejection AND keep the "log-and-continue" behavior operators depend on — without re-litigating which is which (the `udb_problem.severity` seed rows already encode the answer, once recovered — §4.1).
- **Risk & effort: L.** Gated on recovering `udb_problem` seed rows (§4.1) — until then which problems are `'F'` is `[UNKNOWN-seed]`.

### 2.5 Self-documenting schema + secondary indexes

- **Problem:** **zero secondary indexes** (`create index` = 0); one clustering structure per table; every non-key predicate is a full scan — a structural ceiling on the large operational modules (`fms_` 114, `soa_` 86, `ir_` 38 tables) `[FACT - 20-schema-mechanics §1.3]`. Magic ints (10016/10053/10110/10147, 52, 05/21/26, 998/22173/22174) are uninterpretable without seed rows `[FACT - 20-schema-mechanics §10.11]`.
- **Change:** add nonclustered indexes on the proven hot predicates (status bands, card/job/desk filters, `node` joins, `relationship=52` grouping lookups); add `MS_Description` extended properties / a code-table-backed enum layer so `status=10016` reads as `STATION_GROUND_ON` once seed data is recovered.
- **Benefit:** removes the full-scan ceiling; turns magic ints into readable, FK-checked enum references; self-documenting.
- **Risk & effort: S** for indexing, **M** for the enum layer (gated on §4.1).

### 2.6 Replace `*_lastkey` allocators with SEQUENCE objects

- **Problem:** surrogate keys come from single-row `UPDATE *_lastkey SET value=value+1` allocators (6 confirmed tables), no sequence objects; each single row is a write-lock contention hotspot under concurrent inserts; the idiom is also inlined in dozens of procs and copy-pasted as `CAC_KeyGenerator1..8` `[FACT - 20-schema-mechanics §2, §10.6]`.
- **Change:** replace with SQL Server `SEQUENCE` objects (cache-able, lock-free); centralize, delete the 8 copy-paste generators and the inlined idioms.
- **Benefit:** removes the per-row contention point, removes maintenance duplication, eliminates the `iirowcount=1`-guard fragility.
- **Risk & effort: S.** Risk: callers pass `-1` to request a key `[FACT - metamodel-subtypes §4]` — that convention must be re-homed into the insert path.

---

## 3. INTEGRATION ARCHITECTURE — anti-corruption boundaries

**Principle:** the modernized PSM data model is the **system of record**; every external system gets an explicit anti-corruption layer (ACL) — a .NET integration service that translates the external vocabulary/shape into PSM's, with **no shared tables**. Benchmark the PSM vocabulary against IEC CIM (61970/61968) **for naming/mapping only — never store CIM**. The data stays in-enterprise (no cloud), satisfying the OT/IT constraint.

### 3.1 GIS / Esri (eGIS) and the pvl/QGIS feeder model

- **Problem:** three GIS surfaces already exist as *load/cross-ref* tables, not authorities: `egis_xreference` (Esri structure→object/feeder/xy) + `egis_nfload`; `pvl_*` daily 3-step feeder-diagram load; `dso_object`/`dso_connection` = a **derived render cache** of `Udb_Object` keyed per diagram (pocket), explicitly "different from the Udb Object/Terminal/Node model" `[FACT - peripheral-modules §2, §3.1]`. So GIS is already an inbound-cross-reference pattern — good.
- **Change:** formalize each as an ACL service. The PSM equipment id is canonical; eGIS/pvl bring geometry + their own names, the ACL resolves to PSM `equipment_id` via the xreference tables. Keep `dso_object` as a read-projection (materialized view / cache), never an independent authority. Map PSM types to CIM `61968` (GIS/asset) and `61970` (network) classes **in the ACL mapping table only**: e.g. `udb_switch → cim:Switch/Breaker`, `udb_conductor → cim:ACLineSegment`, `udb_transformer → cim:PowerTransformer`, `udb_winding → cim:PowerTransformerEnd`, `udb_node → cim:ConnectivityNode`, `udb_terminal → cim:Terminal`, `udb_consumer → cim:EnergyConsumer` `[INFERENCE - structural class match; subtype columns in metamodel-subtypes §2 align to these CIM classes]`.
- **Benefit:** GIS edits never corrupt the operational model; CIM mapping gives a stable interchange vocabulary for the GIS/planning boundary without paying CIM's storage-normalization cost.
- **Risk & effort: M-L.** Risk: `pvl_XRefIns` and the QGIS bridge today write through to `udb_object`-adjacent tables; the ACL must intercept those write paths. The QGIS bridge is bidirectional (UI↔DB via dbevents `[FACT - peripheral-modules §2 QGIS row]`) — preserve the push channel.

### 3.2 SCADA / EMS (XA/21, RTU, telemetry)

- **Problem:** `xa21_outagereport` is a **bare INSERT, no transform**; the XA21 bridge is **partly manual** (new excluded breaker types trigger an *email to XA21 support staff* `[FACT - peripheral-modules §3.3]`); `udb_telemetry`/`udb_scanblock` are SCADA point-map config with **no ingest proc in the dump** (runtime ingest is an external EMS scanner) `[FACT - peripheral-modules §3.4]`; RTU provisioning writes through to `udb_TelephoneCircuit` `[FACT - peripheral-modules §2 RTU row]`.
- **Change:** put an EMS/SCADA ACL service in front. Inbound outage device reports land in a staging shape, are validated/correlated, then written to the operational model (replacing the bare INSERT). The point-map (`udb_telemetry`/`udb_scanblock`) is config the ACL owns and publishes to the scanner. Automate the XA21 equip-type exclusion sync (replace the email step with a queued change feed). Map to CIM `61970` measurement classes (`udb_measurementtype → cim:Measurement`, `udb_telemetry → cim:MeasurementValue/Analog/Discrete`) at the boundary only `[INFERENCE - metamodel-subtypes §2 sensor columns]`.
- **Benefit:** removes the manual email hop, gives a typed/validated SCADA boundary, decouples the EMS scanner from the schema.
- **Risk & effort: L.** Risk: the live EMS contract (XA/21 GE/ABB) is external and the runtime ingest binary is not in artifacts `[UNKNOWN]` — the ACL contract must be reverse-engineered from the live interface, not the dump. This is the highest-uncertainty integration.

### 3.3 Planning + the ddb dual-target replication

- **Problem:** there is a **home-grown statement-shipping replication layer** (`*ddb_log`/`*ddb_logobject` spool + `DDB_LogEntry → RAISE DBEVENT`, external replicator daemon) that **coexists with native Ingres Replicator** — two replication mechanisms (status code 20 = "Ingres Replication is Incomplete") `[FACT - peripheral-modules §3.5, §5.2]`. Planning (NWP Network Planner) appears only as `nwp_jobclass` `[FACT - peripheral-modules §1]`.
- **Change:** on SQL Server, replace **both** replication mechanisms with one supported HA path (Always On availability groups for the dual hot target), retiring the `ddb_*` spool tables and the daemon entirely. Planning gets a read-replica + an ACL export (CIM `61970` network model for power-flow/planning tools) — never direct table access.
- **Benefit:** one supported, transactional HA mechanism instead of two hand-rolled ones; removes the `ddb_*` control-plane and its silent-failure modes; planning exports become a versioned contract.
- **Risk & effort: L.** Risk: the dual-target topology is load-bearing for 24/7 availability — the cutover from custom statement-shipping to Always On must be proven under failover before retiring the old path; daemon behavior is `[UNKNOWN - external binary]`.

---

## 4. MIGRATION SEQUENCING

**Strategy: strangler-fig, NOT big-bang.** A 24/7 grid-critical, NERC-CIP-adjacent system with two replication paths and irreplaceable client-side logic cannot take a flag-day cutover. Stand the new SQL Server model beside Ingres, migrate module-by-module behind ACLs, and keep the old DB as the authority until each slice is proven.

### 4.1 FIRST (do before any schema work) — risk S, but BLOCKING

1. **Recover the absent `.ingres` seed data from the live production DB.** Every semantic that matters is in absent files: full `udb_type`/`udb_basetype`/`udb_supertype` catalogs, `udb_problem` severity dictionary, all status/jobclass/movecategory/movetype/outagetype enumerations, the LastKey counter list `[FACT - all sections, residual UNKNOWN ledgers]`. **Nothing downstream — enum layer, severity→constraint routing, FK targets, type→subtype map — can be specified without these.** Extract them from the running Ingres instance (not the dump).
   - *Risk:* if the live DB is gone, large parts of the model stay `[UNKNOWN]` and must be reconstructed from operations — a project-existential risk. Confirm data availability first.
2. **Inventory the OpenROAD client 4GL behavioral surface.** ~40% of decision logic is client-side: 872 `ON` handlers in `psm.dmt` + 67 dual-write wrappers; `Switch.NotifyXA21()`, `Switch.SplitCombo()`, `LoadTypeList()`, `SOA_DetermineMoveSequence`/`CheckDeloadComplete` (absent from ALL artifacts), and the COMMIT/ROLLBACK + dual-session replication orchestration `[FACT - 30-applogic-business §a, §e.1; d3-job-deepdive §0]`. Catalog every handler before designing the .NET service tier — these are the true behavioral spec, not the 1,225 procs.

### 4.2 NEXT — risk M

3. **Build the metamodel + UDB core on SQL Server** (§1.5 hybrid): root + typed subtype tables + JSON extension + metadata-driven dispatch + temporal + the connectivity graph. This is the foundation every operational module sits on (every object insert funnels through the metamodel engine `[FACT - 30-applogic-business §a`, "disproportionately load-bearing"]).
4. **Add declared PK/UNIQUE (§2.1), then staged FKs (§2.2), then SAFE CHECK/computed (§2.3)** — in that order, so the optimizer and RI are real before any module migrates.
5. **Re-home the client 4GL into a .NET service tier** with **explicit transaction boundaries** — this is the single highest-risk re-host: procs are caller-managed, not auto-atomic; `COMMIT`=1 / `ROLLBACK`=0 in 33k lines; several procs `RETURN -1` *after* a successful first write with no compensation `[FACT - 20-schema-mechanics §6; 30-applogic-business §b.3]`. A naive service that doesn't wrap each unit-of-work in an explicit transaction **will corrupt state**. Wrap; do not copy the partial-write hazard forward.
6. **Migrate the operational modules behind ACLs**, lowest-coupling first: peripheral/reference modules (`cac_`, `tm_`, `gta_`, messaging) → then the switching core (`soa_`/`fms_`/`ir_`) as one coordinated slice because of their tight cross-module rule cascades (FMS→SOA card mirror with `RAISE ERROR` rollback; IR↔SOA job sync; the shared active-card registry) `[FACT - 30-applogic-business §b.2]`. **TC is special:** all 127 TC procs are stubs `[FACT - d3-job-deepdive §0]` — its server logic must be reconstructed from rules+DDL+guide, so budget extra discovery.

### 4.3 DEFER — risk L

7. **Ledger tables for the regulated surface (§1.3)** — high compliance value but requires the event-sourced redesign of permit/clearance state; do it once the operational model is stable, not during the lift-and-shift.
8. **Replace both replication mechanisms with Always On (§3.3)** — defer until module migration is far enough that you can prove failover; retiring the `ddb_*` path early would remove HA before the new path is trusted.
9. **Graph-table connectivity trace (§1.4)** — defer behind seed-data recovery and the QGIS-vs-Udb "which connectivity model is live now" contradiction `[FACT - 50-how-udb-works §5, unresolved]`; reconstruct the trace algorithm (absent 4GL body) from operations first.
10. **Retire the 6 OpenROAD editors with no server proc** (`udb_dsovalveupd`/`udb_lineupd`/`udb_tankupd`/`udb_pumpupd`/`udb_pumpplantupd`/`udb_reliefvalveupd` have no server body — dead frames or incomplete dump) `[FACT - 30-applogic-business §D12]` — resolve against the live system before assuming they're dead.

### 4.4 Carrying the absent data + re-homing client logic (the two hard parts)

- **Absent `.ingres` data:** there is **no row data in the dump** — it is all `copy … from '/home/ingres/Downloads/*.ingres'` against absent files `[FACT - every section]`. Migration data MUST come from the **live Ingres instance via a one-time export per table**, transformed by the ACL into the new shape. The dump gives structure; the live DB gives content. Treat the live extract as a hard dependency on a date you control (freeze window).
- **Re-homing 4GL:** the 872 client handlers + the absent move-sequencing 4GL are the irreplaceable logic. Port them into the .NET service tier as explicit, tested services — NOT as a thin pass-through over the old procs (which would carry the partial-write hazard and the caller-managed-transaction trap forward). The skill-gate, XA21 sync, phase-combo parsing, and connectivity trace are individually small but operationally critical and have **no server equivalent today**.

---

## 5. Residual UNKNOWNs that gate this plan

`[UNKNOWN-seed / UNKNOWN]` and their blast radius:
- **All seed catalogs** (type/basetype/supertype/problem/status/jobclass) — gates §1.5 type map, §2.4 severity routing, §2.5 enum layer. **Recoverable only from the live DB (§4.1.1).**
- **The move-sequencing + connectivity-trace 4GL** (`SOA_DetermineMoveSequence`, `CheckDeloadComplete`, the Outage Monitor trace) — absent from d1.sql AND both `.dmt` files `[FACT - d3-job-deepdive §10.5]`; gates §1.4 and the SOA migration slice.
- **The live EMS/XA21 ingest contract** and the **ddb replicator daemon** — external binaries, not in artifacts; gate §3.2 and §3.3.
- **Which connectivity model is authoritative now** (Udb terminal/node vs rebuilt-on-QGIS) — unresolved contradiction `[FACT - 50-how-udb-works §5]`; gates §1.4 scope.

Until §4.1 closes the seed-data gap, the model *shape* (this document) is specifiable but the *semantics* (which status means what, which problems reject) are not.
