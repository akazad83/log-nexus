# Phase 3 — Application Logic + Phase 4 — Business Model

**Subject:** Con Edison OMS / PSM (Power System Model) — JOB / JOB CLASS / SWITCHING ORDER / OUTAGE subsystems across data + server code + client UI + user guide.
**Sources (all verified):** `analysis/verified/{soa-switching-orders, tc-jobs-cards, fms-field-mgmt, ir-orders-permits, dbproc-logic, ui-frames-4gl, ug-vocab-outages, ug-switching-lifecycle, peripheral-modules}.md`. Primary artifacts behind those: `d1.sql` (33,392 lines), `psm.dmt`, `psm_4glprocs.dmt`, `ug.html`.
Every material claim is tagged `[FACT - source]`, `[INFERENCE]`, or `[UNKNOWN]`. Tags reference the verified analysis docs (themselves grep/body-verified against `d1.sql`/`ug.html` on 2026-06-12), not re-derived here unless noted.

> **READ-FIRST CAVEAT — a live cross-document contradiction in Ground Truth.** The verified docs disagree on the stub/real proc split. See §0.1. It does not change any architectural conclusion but the headline number "2,450 procedures" is **double-counted** and must be halved before reasoning about logic volume.

---

## 0. Headline facts that govern everything below

1. **"2,450 procedures" is a 2× over-count.** `d1.sql` declares each procedure **twice**: a forward-declaration **stub** (`create or replace procedure NAME as begin return; end`) in the upper block, then the **real body** (`create or replace procedure  NAME ( args ) = BEGIN … END`, terminated by a `\p\g` line) in the lower block (real bodies start ~line 27758). **Read only the second occurrence (NR > 27757).** `[FACT - dbproc-logic, fms-field-mgmt, soa-switching-orders, peripheral-modules — all five docs concur on the two-block structure]`

2. **The real server logic is ~1,225 distinct procedure bodies, not 2,450** `[FACT - dbproc-logic (1,225/1,225 exact grep), corroborated by tc-jobs-cards, ui-frames-4gl, ug-switching-lifecycle, peripheral-modules]`. The DB-proc layer is a **write/command layer**: fine-grained `*Ins`/`*Upd`/`*Del` wrappers (65% are CRUD-suffixed) + a thin layer of state-transition and event-raising commands. **Querying is client-side SQL** (the 4,835 grants include broad `select` on base tables; almost no reader procs exist server-side). `[FACT - dbproc-logic §2]`

3. **No row data exists.** Every table is `copy <t> () from '/home/ingres/Downloads/<t>.ingres'` and those files are absent. Therefore **every status-code enumeration, type/basetype/supertype list, jobclass list, movetype/movecategory list, and outagetype code is `[UNKNOWN]`** except the specific literals hard-coded inside proc/rule bodies. This is stated once here and assumed throughout. `[FACT - Ground Truth + all nine docs]`

4. **`psm_dbprocs.dmt` is a 22-line stub** (includes `core.plb` only) — irrelevant; ignore it. `[FACT - ui-frames-4gl §0, fms-field-mgmt §10]`

### 0.1 CONTRADICTION (cross-document, unresolved) — stub count

| Doc | Stub count | Real count |
|---|---|---|
| `dbproc-logic.md` | **1,225** | 1,225 (clean 1:1) |
| `tc-jobs-cards.md` | **1,225** | 1,225 |
| `ui-frames-4gl.md` | **1,225** (implied by 2,450 total) | 1,225 |
| `ug-switching-lifecycle.md` | **1,225** | 1,225 |
| `peripheral-modules.md` | **1,225** | 1,225 |
| `soa-switching-orders.md` | **1,163** | ~1,287 distinct |
| `ug-vocab-outages.md` | **1,163** (47.5%) | — |

`[CONTRADICTION]` Five docs say **1,225 stubs / 1,225 real (exact 1:1)**; two docs say **1,163 stubs**. The Ground-Truth prompt also says "1,163." `[INFERENCE]` The **1,225/1,225 figure is the better-evidenced one** (five independent verifier passes, each citing an exact `grep -c 'as begin return; end' = 1225`). The 1,163 figure likely counts a narrower stub regex (e.g. excluding `$`-named rule-helper stubs or no-arg stubs). **Resolution for downstream work: treat distinct procedure bodies as ≈1,225; do not trust "2,450" as a logic-volume metric.** The discrepancy (~62 procs) is immaterial to architecture but must be flagged because the section brief inherited the 1,163 number from Ground Truth.

---

## (a) WHERE BUSINESS RULES LIVE — four tiers, with proportions

There are **four** logic tiers. The headline finding (consistent across all nine docs): **decision logic is split — persistence + state machines + cross-module cascades are server-side; validation, type resolution, cross-system notification, and transaction/replication orchestration are client-side.** `[INFERENCE - ui-frames-4gl §7, synthesized]`

| Tier | Artifact | Volume | What lives here | Evidence |
|---|---|---|---|---|
| **1. Server DB procedures** | `d1.sql` real-body block | **~1,225 procs** (~12,000–16,000 logical LOC) | CRUD wrappers; numeric→string status decoders; cross-module cascades (FMS→SOA, IR→SOA/FMS/TC); key generation; `RAISE DBEVENT` broadcasts; soft validators that log to `Udb_GrassCatcher` | `[FACT - dbproc-logic §1,§2,§7]` |
| **2. Server Ingres RULES** | `d1.sql` rules block (lines ~32780–33366) | **290 rules** | AFTER INSERT/UPDATE/DELETE triggers that fire the procs with `Old.`/`New.` bindings + WHERE guards; the ONLY recoverable server behavior for modules whose procs are stubs (esp. TC — all 127 TC proc bodies are stubs) | `[FACT - tc-jobs-cards §1,§7; dbproc-logic §6]` |
| **3. Server DBEVENTS** | `d1.sql` dbevent decls | **208 dbevents** | Bare async pub/sub signals (no bodies); delivered on commit; how the DB notifies OpenROAD clients/daemons | `[FACT - peripheral-modules; soa-switching-orders §9]` |
| **4. Client OpenROAD 4GL** | `psm.dmt` (872 `ON` handlers), `psm_4glprocs.dmt` (67 dual-write wrappers) | **872 event handlers + 67 wrappers** | Input validation, type/supertype filtering, XA21/EMS sync decision, phase-combo parsing, audit-trail capture, **COMMIT/ROLLBACK boundaries**, dual-session replication | `[FACT - ui-frames-4gl §6,§7]` |

### Proportion of the *real server logic mass* by module `[FACT - dbproc-logic §1]`
- **fms 352 + soa 240 + tc 127 + tfms 31 = 750 procs (61%)** = the switching-order / outage-card operational core.
- **udb 70 + ~40 `$`-named rule procs** = the metamodel engine (small count, disproportionately load-bearing — every object insert funnels through `object$insert`).
- **ir 134** — large but shallow (mostly board-refresh + issue/return feed writers).
- Remainder: cac 42, fra 35, slc 29, dso 26, pvl 16, csd 14, rtu/qgis 10 each, msg 9, tm 6.

### The decisive architectural facts
- **Integrity is in code, not constraints.** No hard FK/CHECK constraints in the DDL (copy-loaded Ingres dump); referential rules live in ~290 rules + ~31 `Udb_GrassCatcher`-writing soft validators that **log violations and keep going** rather than rejecting. **Bad data is logged, not blocked.** `[FACT - dbproc-logic §8, §4 (GrassCatcher inserts = 31, corrected down from 56)]`
- **Transactions are caller-managed.** `COMMIT` appears **exactly once** in 33,392 lines (`SetSesameLockCardFormID`, an intra-loop lock-release commit); `ROLLBACK` = 0. Procs signal failure by `RETURN -1` / `RAISE ERROR -n`; rollback is the **client's** responsibility. `iierrornumber` is checked 1,396 times; `RAISE ERROR` 92×; `RAISE DBEVENT` 60×. `[FACT - dbproc-logic §3,§4]`
- **Client tier holds irreplaceable logic.** `Switch.NotifyXA21()` (EMS sync for renamed/added load-break switches), `Switch.SplitCombo()` (phase-combination parsing), `LoadTypeList()` (type-hierarchy resolution), and the dual-write COMMIT/ROLLBACK orchestration exist **only** in `psm.dmt`/`psm_4glprocs.dmt` — no server equivalent. Migrating off OpenROAD requires re-homing all of these. `[FACT - ui-frames-4gl §6.1]`

---

## (b) END-TO-END SUBSYSTEM MAP — JOB / JOB CLASS / SWITCHING ORDER / OUTAGE

### b.0 The unit-of-work model (resolves the prompt's premise)
- **There is NO single "SwitchingOrder" entity.** The order container is the **CARD**; a card holds **MOVES (= jobs)** organized into **STEPS (step pairs)**. `[FACT - ug-switching-lifecycle §0; soa-switching-orders §2]`
- **"Move" and "job" are synonymous** per the guide: *"A Job Class defines the 'move'… The term 'move' and 'job' are synonymous."* `[FACT - ug-vocab-outages §2 (ug.html:5130-5132); tc-jobs-cards §0]`
- **A JOB CLASS is the move TEMPLATE** (move rules + job checks + job actions); a JOB is the per-object INSTANCE. The guide collapses class↔instance; the schema separates them. `[FACT - ug-vocab-outages §4]`
- **A card = an ordered list of jobs = the printable switching order.** `soa_jobcontrol(card,job,switchingitem)` attaches jobs to a card in `steppair`/`steplevel`/`seq` order; server-driven sequencing via rules `SOA_DetermineSequence`/`SOA_ControlResequence`. `[FACT - soa-switching-orders §2]`

### b.1 THE THREE-JOB-TABLE RECONCILIATION (`soa_job` / `tc_job` / `fms_job`)

This is the prompt's central question. **Resolved:**

| Table | Exists? | Cols | Key | Role | Domain |
|---|---|---|---|---|---|
| `soa_job` | **YES** | 31 | btree unique on `job` | **JOB INSTANCE** | TOMS/SOA = Substations (SLC) + Transmission Feeders (TFMS) |
| `tc_job` | **YES** | 37 | btree on `(card,seq,job)` | **JOB INSTANCE** | TLS = Telephone circuits (electronic ticket to Verizon) |
| `fms_job` | **NO — DOES NOT EXIST** | — | — | — | — |
| `fms_jobclass` | YES | — | PK `jobclass` | **JOB CLASS / TEMPLATE** (shared move library) | FMS + shared |
| `nwp_jobclass` | YES | 1 | `jobclass` | class-key registry (single col) | NWP (Network Planner) |
| `fms_archivejob` | YES | — | — | archived job-row shape (the only place the FMS job-row *shape* is visible) | FMS |

`[FACT - fms-field-mgmt §1 (no fms_job table; grep confirmed); ug-vocab-outages §4; soa-switching-orders §1; tc-jobs-cards §4]`

**The reconciliation:**
- The prompt (and Ground Truth) hypothesized three parallel job tables `soa_job`/`tc_job`/`fms_job`. **`fms_job` does not exist.** `[FACT - fms-field-mgmt §1,§10 (1); ug-vocab-outages §4 contradiction-watch]`
- There are **exactly two job-INSTANCE tables**: `soa_job` (substation/transmission) and `tc_job` (telephone). `[FACT]`
- **FMS does not author or store per-feeder job instances in a table named `fms_job`.** FMS's job model = `fms_card` (the live operating card, 47 cols) + the move-template tables (`fms_jobclass`, `fms_jobaction`, `fms_jobcheck`, `fms_jobclasscontrol`, `fms_jobclasslink`, `fms_jobobjective`, `fms_jobtoskill`). The canonical FMS job-ROW shape only appears in the **archive twin** `fms_archivejob` (job, card, seq, status, jobclass, equip, steppair, move/restore operator+time). `[FACT - fms-field-mgmt §1]`
- `[INFERENCE]` FMS distribution-feeder switching is recorded against `fms_card` + operating-step/object-status tables and executed in the field; where it shares the switching-order data model with SOA is via the `SOA_Card`/`SOA_Job` cascade (FMS writes back into `SOA_Job.Grounds`, `SOA_Card.Status` — see b.3). `soa_job` is effectively the shared job-instance store; FMS is the executor/state-overlay, not a separate job-instance owner. `[INFERENCE - fms-field-mgmt §1,§7]`
- **Same shape, three prefixes:** `soa_job`, `tc_job`, and `fms_archivejob` all carry the identical **TO (TakeOut/issue) half + RS (Restore) half** column pattern (`tomove/tooperator/toissued/tocomplete` and `rsmove/rsoperator/rsissued/rscomplete`). The two-phase out-of-service-then-in-service move is the universal primitive. `[FACT - soa-switching-orders §2; tc-jobs-cards §4; ug-vocab-outages §2]`

> **Contradiction flagged:** the section brief title says "Reconcile the THREE job tables (soa_job/tc_job/fms_job)" — but **only two exist**. The third is `fms_jobclass` (a template, not an instance) or, if instance-shape is meant, `fms_archivejob`. `[CONTRADICTION - brief premise vs d1.sql]`

### b.2 The FMS / SOA / IR / TC division of labor

`[INFERENCE - synthesized from all four subsystem docs; each edge is FACT-cited below]`

| Module | Acronym (best evidence) | Owns | Writes into (cross-module) | Reads/reacts to |
|---|---|---|---|---|
| **SOA** (= TOMS) | Switching Order Application / TOMS | The switching-order data model: `soa_card`, `soa_job`, `soa_jobcontrol`, in-service permits (`soa_inservicepermit`+`soa_ispermitrequest`), planned outage requests (`soa_outagerequest`), bus-fault capture (`soa_busfaultoutage`). **System of record for in-service/outage permits + switching jobs (regulatory: NYISO/NYPA/compliance).** | reads `FMS_Card`/`TFMS_CardToObject` for active-list; repoints `SOA_WorkPermit`/`TC_WorkPermit` on ISP withdraw | FMS object-status pushes; IR completion write-backs |
| **FMS** | Field Management Subsystem | **Real-time field-execution + object-status state machine.** Largest (114 tbl, ~352 procs). `fms_objectstatus` (current) + `…audit` (history) + `…queue` (inbound) CQRS triple; automation control loop; `fms_card`; clearance/LOTO (`fms_sesamelockcard`). **Executes** orders in the field; maintains live equipment STATE. | `UPDATE SOA_Card SET Status` (card mirror); `UPDATE SOA_Job SET Grounds` (sums status 10016); invalidates `Udb_Object` validation | `fms_objectstatusqueue` (fed by SOA/SLC with job/tors/switchingitem provenance); SCADA/SOCCS `fms_sx*` confirmations |
| **IR** | Issue/Return (inferred — guide never expands it) | **The order-issue / field-return state machine.** 38 tbl, 134 procs. Drives jobs to the field across feeder/in-service/telephone/FOD channels; tracks ack/reject/return/rescind. Operating orders (`ir_operatingorder`), FCR work permits (`ir_workpermit`), RFPs (`ir_requestforpermit`), telephone orders (`ir_telephoneorder`), relay-target returns (`ir_returnrelay`). | `UPDATE SOA_Job` (RSComplete/RSOperator/Response via `IR_CompletePermit`); `UPDATE FMS_Workpermit` (AcknowledgedByFCR via `IR_WorkPermitUpdate`); `UPDATE TC_Job` (via `IR_TLSCompleteJob`) | rules on `SOA_Job` TO/RS timestamps fire `IR_FMSJobUpdate` |
| **TC** (= TLS) | Telephone Line System | **Telephone/telecom-circuit trouble-ticket switching**, on the FMS DB. 33 tbl, **all 127 procs are stubs** (logic recoverable only from rules+DDL+guide). `tc_card`, `tc_job`, electronic trouble-ticket to **Verizon** (`tc_troublereportorder` + poll/status). | participates in shared `soa_activecard` registry (discriminated by `application char(4)`) | reacts to `fms_objectstatus` changes (`tc_status_change1/2/3` rules) |

**Key cross-module edges (all FACT, body-verified in the cited docs):**
1. **FMS → SOA (card status mirror):** `FMS_CardStatusChange` → `UPDATE SOA_Card SET Status WHERE Card`, rule-fired by `FMS_Card$StatusChange`; `RAISE ERROR -1` rolls back the whole transaction if the SOA cascade fails (transactional coupling). `[FACT - fms-field-mgmt §7 (1)]`
2. **FMS → SOA (grounds):** `FMS_UpdateGrounds` sums `fms_objectstatus.StatusCount WHERE Status=10016` → `UPDATE SOA_Job SET Grounds … WHERE C.Status<50`, then raises `FMS_Update_Grounds`. `[FACT - fms-field-mgmt §7 (2)]`
3. **SOA/SLC → FMS (job enqueue):** the producer proc that INSERTs into `fms_objectstatusqueue` with `job/tors/switchingitem/fromapp` provenance lives in SOA's ~240 procs (not located/read; the queue's provenance columns prove the cross-module producer). `[UNKNOWN - exact proc; fms-field-mgmt §7]`
4. **IR → SOA/FMS/TC (completion write-back):** `IR_CompletePermit`→`SOA_Job`; `IR_WorkPermitUpdate`→`FMS_Workpermit`; `IR_TLSCompleteJob`→`TC_Job`. `[FACT - ir-orders-permits §1,§4]`
5. **SOA ↔ IR (job timestamp sync):** rules `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` on `SOA_Job` fire `IR_FMSJobUpdate(Action='RC'|'RI'|'TC'|'TI')`, which raises dbevent `IR_FeederBoardUpd`. `[FACT - soa-switching-orders §4c,§10; ir-orders-permits §8]`
6. **SOA ↔ SLC (long-term clearances):** rules `SLC_NewItemActivated`(switemstatus=20, movecat 2/3), `SLC_ItemClosed`(≥50), `SLC_ArchiveItem`/`SLC_PurgeItem`(movecat 2,3,6). `[FACT - soa-switching-orders §3,§10]`
7. **Shared active-card registry:** `soa_activecard.application char(4)` discriminates FMS/SLC/TC/TFMS; `TFMS_NewCardActivated AFTER INSERT INTO SOA_ActiveCard WHERE New.Application <> 'FMS'` routes any non-FMS card into TFMS activation. `[FACT - tc-jobs-cards §10]`

### b.3 Transaction boundaries (the migration-critical truth)
- **Each proc = one logical unit, NOT auto-atomic.** Multi-step procs `RETURN -1` on any `iierrornumber<>0` but Ingres DB procs are not transactional containers; **rollback is the caller's responsibility.** Several multi-statement procs (`SOA_ISPRequestStatusUpd`, `SOA_ISPRequestCopy`, `SOA_CloseSwitchItem`) `RETURN -1` *after* a successful first write with no compensating rollback → **real partial-write hazard.** `[FACT - soa-switching-orders §10; dbproc-logic §8 (transaction risk MEDIUM)]`
- **Rules execute synchronously inside the triggering transaction** (Ingres AFTER rules): e.g. FMS_Card status update + the SOA_Card cascade + the dbevent raise are ONE transaction; SOA-cascade failure rolls back the card change via `RAISE ERROR`. `[FACT - fms-field-mgmt §8]`
- **dbevents are delivered on commit** (queued, decoupled from the writing txn). `[FACT - fms-field-mgmt §8; dbproc-logic §3]`
- **The real transaction boundary is the OpenROAD client** (`psm.dmt`: 392 `DDB_ROLLBACK` + 280 `DDB_COMMIT` calls; dual-session replication). The DB tier cannot reproduce application transactional behavior alone. `[FACT - ui-frames-4gl §4,§7]`

### b.4 End-to-end map (Mermaid)
```mermaid
flowchart TD
  subgraph CLIENT["OpenROAD client tier (psm.dmt + per-app frames)"]
    UI[DO desk frames: Issue Moves / Return Moves / permit screens]
    DW[psm_4glprocs dual-write wrappers<br/>Session.One + Session.Two]
  end
  subgraph SOA["SOA = TOMS (order authoring + permits)"]
    CARD[soa_card status 10->20->50]
    JOB[soa_job: TO half / RS half<br/>switemstatus 0..20..50]
    JC[soa_jobcontrol card<->job<->step]
    ISP[soa_inservicepermit + ispermitrequest<br/>Status 2..100 decoder SOA_ISPStatusUpd]
    OR[soa_outagerequest 10..100]
    BF[soa_busfaultoutage 67 cols<br/>SOA_BFIns -1 sentinels]
  end
  subgraph FMS["FMS (field execution + status state machine)"]
    Q[fms_objectstatusqueue inbound]
    CUR[fms_objectstatus UNIQUE obj,term,status<br/>statuscount=refcount]
    AUD[fms_objectstatusaudit history]
    FC[fms_card FeederStatus/StationGround/GroundsOn]
    AUTO[automation loop: fms_automationcontrol/block]
  end
  subgraph IR["IR = Issue/Return (drive to field)"]
    OO[ir_operatingorder]
    WP[ir_workpermit + RFP]
    TO[ir_telephoneorder]
    RR[ir_returnrelay]
  end
  subgraph TC["TC = TLS (telephone, all procs stubbed)"]
    TCC[tc_card]
    TCJ[tc_job]
    TRO[tc_troublereportorder -> Verizon poll]
  end
  UI --> DW --> CARD & JOB & ISP & OR
  JC --- JOB
  JOB -->|SOA->FMS enqueue job/tors/switchingitem| Q
  Q -->|dequeue+purge| CUR --> AUD
  CUR -->|status 10044/10053/10016| FC
  FC -->|FMS_CardStatusChange rule| CARD
  CUR -->|FMS_UpdateGrounds sum 10016| JOB
  IR -->|IR_CompletePermit| JOB
  IR -->|IR_WorkPermitUpdate| WP
  IR -->|IR_TLSCompleteJob| TCJ
  JOB -->|rules IR_FMSJob RC/RI/TC/TI| IR
  TC -->|reacts tc_status_change1/2/3| CUR
  TC -->|application<>'FMS'| SOA
  BF -->|SCADA xa_busoutage| CUR
  AUTO -->|FMS_AutomationGo dbevent| ExtAuto[External automation daemon]
```

---

## (c) RECONSTRUCTED OPERATIONAL WORKFLOWS

> Caveat: the user guide is a **DBM admin guide**, not an operator switching manual; the narrated operator workflow is deferred to absent SOA / Job-Class guides. Workflows below are reconstructed from DDL timestamps + real proc bodies + rules + guide prose. State **labels** are reconstructed; only numeric/string literals embedded in procs are authoritative. `[INFERENCE - ug-switching-lifecycle §0,§7]`

### c.1 PLANNED outage / switching order (operator-built)

| # | Step | Tables | Procs (real bodies) | Rules / dbevents | Frame |
|---|---|---|---|---|---|
| 1 | DO builds card | `soa_card` (status 10 = built) | `SOA_CardUpd` | dbevent `soa_loadcommoncard`/`loadfmscard` | `[UNKNOWN - psm.dmt frame]` |
| 2 | Add moves by step | `soa_job`, `soa_jobcontrol`, `fms_steppair` | `SOA_ItemIns`/`SOA_JobIns` (switemstatus<20) | rules `SOA_DetermineSequence`/`SOA_ControlResequence` (server); **`SOA_DetermineMoveSequence` is client 4GL — location UNKNOWN, absent from d1.sql AND the .dmt slice** | Job Class / Step Heading screens |
| 3 | Activate card | `soa_card.status=20` (sets `Activated`), `soa_activecard` | `SOA_CardStatusUpd` (10→20) | rules `SOA_CardActivate`(New=20,Old<20)→`SOA_ActiveListInsert`→**RAISE dbevent `SOA_ActiveListChange`** | — |
| 4 | Activate switch item | `soa_job.switemstatus=20`, `Response='Active'` | `SOA_ActivateSwitchItem(item,time,activestatus)` — sets `TOIssued`, cascades status to child jobs via jobcontrol | rule `SLC_NewItemActivated`(switemstatus=20) for SLC items | — |
| 5 | Issue TakeOut (isolate) | `soa_job.toissued/tooperator` | `SOA_IssueMove(Status='TO')` — sets `TOIssued/TOOperator` | rule `IR_FMSJobTOIssued`→`IR_FMSJobUpdate('TI')`; **skill check** (`FMS_JobToSkill` vs `FMS_PersonToSkill`) | Issue Moves screen |
| 6 | Complete TakeOut → CutOut | `soa_job.tocomplete`, `soa_card.cutout` | `SOA_CompleteMove(Status='TO')` | rule `IR_FMSJobTOComplete`→`IR_FMSJobUpdate('TC')`; dbevents `fms_sxcutout` | Return Operator Moves |
| 7 | Establish protection / grounds | `fms_workpermitprotection`, `fms_groundhistory`, `fms_card.stationground` | `FMS_UpdateCardHeader` (status **10044**=station-ground On/Off, **10053**=grounds→`GroundsOn`); `FMS_UpdateGrounds` (status **10016** sum→`SOA_Job.Grounds`) | rules `FMS_CardHeader1`(status IN 10044,10053), `FMS_GroundHistory1`(10016,10053); dbevents `fms_card_grounds`, `fms_update_grounds` | Establish Work Permit Protection (Sequence **600** step, a global constant) |
| 8 | Make safe / lock | `fms_sesamelockcard` (~71 cols, descriptive only), `fms_regtag`, `ir_fodtag`, `ir_worklocationtag` | `FMS_SesameLockCardIns`/`…Upd` (only lifecycle bit = `processed 0→1`) — **NOT an enforcement gate** | dbevents `ir_processingtags`→`ir_reviewtags`→`ir_tagsreviewed` | `[UNKNOWN]` |
| 9 | Issue work permit | OSWP/ISWP: `fms_workpermit`/`soa_workpermit`; ISP: `soa_inservicepermit`; FCR: `ir_workpermit` | `IR_IssueFCRWorkPermit(TargetFCR,DOName,PermitStatus,ProtectionMoveCount,WorkPermit)`; `SOA_IssueISP`; ISP approval via `SOA_ISPStatusUpd` (18-state decoder, §c.3) | dbevent `ir_processingpermit`; **target-ground protection-distance check at issue** (Green/Yellow/Red; DO alerted on Red) | Aged Work Permits / permit screens |
| 10 | Field work (skill-gated) | — | — | mismatch → "The Operator is not qualified for this move. Do you wish to continue?" | — |
| 11 | Permit return | `ir_workpermit.permitstatus=50`, `soa_workpermit.returnstatus` | `IR_ReturnWorkPermit` (hardcodes `PermitStatus=50`); `IR_CompletePermit`→`SOA_Job` | dbevents `ir_returnpermit`, `ir_permitcomplete` | Issue/Return Moves |
| 12 | Issue Restore (re-energize) | `soa_job.rsissued/rsoperator/rscomplete`, `soa_card.cutin` | `SOA_IssueMove(Status='RS')`, `SOA_CompleteMove(Status='RS')` | rules `IR_FMSJobRSIssued/RSComplete`→`IR_FMSJobUpdate('RI'/'RC')`; dbevent `fms_sxcutin` | Issue Moves |
| 13 | Close switch item / card | `soa_job.switemstatus≥50`; `soa_card.status=50` (sets `Closed`) | `SOA_CloseSwitchItem` (sets ClosureStatus; un-hides ISP child jobs if MoveCategory=6); `SOA_CardStatusUpd` (→50) | rule `SOA_CardDelete`(New≥50)→`SOA_ActiveListDelete`; `FMS_RemoveCardReport2`; `ir_closecard` | — |
| 14 | Archive | `soa_archivejob`, `soa_archivelog`, `*_archivecard`/`*_archiveworkpermit` | `SOA_ArchiveJob`; archive copy = client-orchestrated (proc bodies not surfaced) | — | — |

**Parallel: PLANNED OUTAGE REQUEST (OSS-driven)** `[FACT - soa-switching-orders §7; ug-vocab-outages §5a]`
`soa_outagerequest` state machine via `SOA_ORStatusUpd`: **10 IMPORTED** (from OSS) → **20 PERMIT** → **50 CLOSED** → **70 RECALLED** → **100 ARCHIVED**. Carries scheduled-vs-actual date pairs (`sked*`/`actual*` for outage/start/return/in-service) = the planned-outage timeline. Linked to permit jobs via `soa_outagerequestpermit`; cascade-delete via `SOA_OutageRequest$Del`→`SOA_ORCascadeDel`.

### c.2 AUTOMATIC / FORCED outage (event-driven)

| # | Step | Tables | Procs / mechanism | Evidence |
|---|---|---|---|---|
| 1 | Breaker operates (open/close) | `xa21_outagereport` (EMS feed) | `XA21_OutageReportIns` (bare INSERT, no transform) | `[FACT - peripheral-modules §3.3; soa-switching-orders §6]` |
| 2 | Outage Monitor waits "Delay to Evaluate" seconds | — | `allapp_systemparameters.outagemonitordelay` | `[FACT - ug-vocab-outages §5b]` |
| 3 | Connectivity trace | `Udb_Terminal`/`Udb_Node` (legacy) **or** QGIS model (modern) | Outage Monitor background process | `[FACT - ug-vocab-outages §5b]` |
| 4 | Outage identified | `soa_outagesummary` (object,type,voltage,card,switchingitem,job,**outagetype int**,outservicestart/end,**latentflag**,outagekey) | — | `[FACT - ug-vocab-outages §5b]` |
| 5 | Late identification | — | asterisk on TOMS Outage Summary (`allapp_systemparameters.outagelatentperiod`) | `[FACT - ug-vocab-outages §5b]` |
| 6 | Open-Auto / relay capture | `fms_openautoequip` ("switches/breakers that open automatically when faults occur"); relays recorded via `cac_relaytypes` | — | `[FACT - ug-vocab-outages §2,§5b]` |
| 7 | Bus-fault telemetry capture | `soa_busfaultoutage` (67 cols, widest table in DB) | `SOA_BFIns(Substation,BusSection,SwitchingItem,…)` inserts all 22 flag/target cols = **-1 sentinel**; 16 `SOA_BF*Upd` procs each patch one protection-element group | `[FACT - soa-switching-orders §6]` |
| 8 | Correlate → recommend action | `soa_busfaultcorrelationmatrix`, `correlationaction varchar(160)`; **Peak Load Bus Fault Correlation matrix** applied when load > threshold | `SOA_BFCMatrixIns/Del` | `[FACT - soa-switching-orders §6; ug-vocab-outages §5b]` |
| 9 | Visual outage | — | `qgis_setoutage` (stub body — behavior UNKNOWN) | `[FACT - ug-vocab-outages §5b]` |
| 10 | Rapid-Restore electronic order (substation forced path) | `ir_operatingorder`, `ir_opordersteps`, `ir_downloadmove` | lifecycle **issued → downloaded → ack/reject (by SSO) → return → rescind** (`IR_OrderStatusUpd`, `IR_DownloadTimeUpd`, `IR_OpOrderAckRejUpd`, `IR_CompletedTimeUpd`, `IR_OpOrderRescindUpd`) | `[FACT - ir-orders-permits §4.1; ug-switching-lifecycle §7.2]` |

### c.3 PERMIT / IN-SERVICE-PERMIT approval (parallel state machine)
`soa_inservicepermit.Status` decoded by `SOA_ISPStatusUpd` (verified verbatim, 18 states): **2 REQUEST → 10 OPEN → 15 PENDTO (pending Transmission Operator) → 20 PENDSO (pending System Operator) → 40 APPRV / 35 A-COND / 25 DENIED → 45/50 ISSUED → 54 PULLRQ → 55 PULLED → 60 COMPL / 65 INCOMPL → 70 LOCAL → 100 archived.** Auto-close sweep (`SOA_ISPArchive`): `Status IN (25,55,60,65,70)` or aging drafts → 100. `[FACT - soa-switching-orders §5a]`

> **Note a second, DIFFERENT ISP decoder exists:** `SOA_ISPRequestStatusUpd` decodes Status **1/2/4/8 → REQ_OPEN/RCC_APPRV/PENDING/REQ_DENIED** for the *request* side (`soa_ispermitrequest`), distinct from the permit-side `SOA_ISPStatusUpd` decoder above. `[FACT - dbproc-logic §5b]` These are two coupled-but-distinct status vocabularies on the request vs the permit — do not conflate.

### c.4 Move lifecycle (the universal primitive, both paths)
**drafted → TO issued → TO complete → (work) → RS issued → RS complete → closed.** The four nullable `ingresdate` columns (`toissued,tocomplete,rsissued,rscomplete`) ARE the per-move micro-state (null = not-yet, non-null = done). Driven by `SOA_IssueMove`/`SOA_CompleteMove` (action selector `'TO'`/`'RS'`), NOT free SQL. Numeric lifecycle band: `switemstatus` **<20 created / =20 active / 20–49 in-progress / ≥50 closed**. `[FACT - soa-switching-orders §4]`

---

## (d) GUIDE-vs-SCHEMA CONTRADICTIONS (consolidated)

| # | Contradiction | Resolution | Source |
|---|---|---|---|
| **D1** | Brief/Ground-Truth says reconcile **`fms_job`**; guide implies an FMS job instance table | **`fms_job` does NOT exist.** Only `soa_job` + `tc_job` are instance tables; FMS uses `fms_card` + `fms_jobclass`* templates; instance shape only in `fms_archivejob` | `[FACT - fms-field-mgmt §1; ug-vocab-outages §4]` |
| **D2** | Ground-Truth "2,450 procedures" = real logic | **Double-counted.** ~1,225 distinct bodies; read NR>27757 only | `[FACT - dbproc-logic §0]` |
| **D2b** | Verified docs disagree: **1,225 vs 1,163 stubs** | Five docs say 1,225/1,225 (exact grep) — preferred; two say 1,163. Immaterial to architecture but the headline numbers conflict | `[CONTRADICTION - unresolved; §0.1]` |
| **D3** | Guide names **`SOA_OSWPEquipType`** table (ug.html:11596/11692) | **NOT in d1.sql.** Only `soa_iswpequiptype` exists. OSWP equip-type storage unaccounted-for (missing/renamed table or absent data). One doc had originally mis-cited it as a FACT table — corrected to fabrication | `[CONTRADICTION - ug-vocab-outages §6(1); ug-switching-lifecycle §11.10 (flagged as fabricated citation)]` |
| **D4** | Guide names **`fms_highpottesthistory`** (ug.html:6735) | Schema has **`fms_highpothistory`** (no "test"). Guide name inexact | `[CONTRADICTION - ug-vocab-outages §6(2)]` |
| **D5** | Guide describes proc behavior (e.g. `FMS_AmmClearMaintP` deletes oldest hi-pot result; `soa_issuemove`/`soa_completemove`) | Those proc **bodies are stubs** in the cited block — behavior unverifiable at code level. (Note: the *real* bodies exist in the second block for SOA; but TC's 127 procs are stubs end-to-end with NO real bodies anywhere) | `[CONTRADICTION/UNKNOWN - ug-vocab-outages §6(3); tc-jobs-cards §1]` |
| **D6** | "**TLS**" is overloaded in the guide | §3 TOC "TLS Menu" = **Transmission Line System**; body prose "TLS = **Telephone Lines**" switching app. Internally inconsistent — keep separate | `[CONTRADICTION - ug-vocab-outages §1]` |
| **D7** | "**DSO**" assumed = Distribution System Operator | = **Dielectric Switching Operations** (standalone DSO DB, separate `DSO_DBM` image). `dso_object`/`dso_connection` = QGIS render cache of `Udb_Object`, NOT an independent object authority | `[CONTRADICTION - peripheral-modules §5(1)]` |
| **D8** | Guide narrates an active "Outage Monitor" with timing params | Version history says Outage Monitor was **disabled then rebuilt on QGIS visual model**; yet timing-param docs still present. Which path is live now = ambiguous | `[CONTRADICTION - ug-vocab-outages §5c]` |
| **D9** | `SOA_DetermineMoveSequence` / `CheckDeloadComplete` named in guide as move-ordering/completion logic | **Absent from d1.sql AND from psm.dmt/psm_4glprocs.dmt slice.** Location UNKNOWN (likely compiled OpenROAD frame not exported as plaintext). DB stores results only. (Note: a SAME-NAMED but DIFFERENT server proc `SOA_DetermineSequence` does exist — do not conflate) | `[CONTRADICTION/UNKNOWN - ug-switching-lifecycle §0,§11.3; soa-switching-orders §2]` |
| **D10** | Guide: "move=job synonymous" | Schema has BOTH instance (`soa_job`,`tc_job`) AND template (`fms_jobclass`); the guide's loose synonymy collapses class↔instance | `[CONTRADICTION - ug-vocab-outages §6(9)]` |
| **D11** | Column-count mismatches: brief said `ir_operatingorder` 34 / `ir_workpermit` 36 / `ir_telephoneorder` 31; `tc_job` 43 / `tc_card` 35 | Authoritative DDL: IR = **28 / 30 / 25**; TC = **37 / 29**. Both brief AND original analyses mis-counted; DDL is authoritative | `[CONTRADICTION - ir-orders-permits §10; tc-jobs-cards §11]` |
| **D12** | Client tier (6 editors) calls server procs absent from d1.sql | `udb_dsovalveupd`/`udb_lineupd`/`udb_tankupd`/`udb_pumpupd`/`udb_pumpplantupd`/`udb_reliefvalveupd` have **no server proc** (DSOValve even has a live table). Either dead frames or incomplete server dump — undisambiguable. Regenerating the server tier from d1.sql will break these editors | `[CONTRADICTION - ui-frames-4gl §6.2]` |

---

## (e) MIGRATION-CRITICAL SYNTHESIS (the load-bearing takeaways)

1. **The dbprocs alone cannot reproduce application behavior.** ~40% of decision logic (validation, type resolution, XA21/EMS sync, phase parsing, transaction/replication orchestration, audit capture) lives in the **OpenROAD client** (`psm.dmt` 872 `ON` handlers + `psm_4glprocs.dmt` 67 dual-write wrappers). The 872 handlers are the true behavioral surface and must be ported, not just the ~1,225 dbprocs. `[FACT - ui-frames-4gl §7]`
2. **Integrity-in-code, not constraints** → any new schema needs ~290 rules + ~31 soft validators re-expressed as real constraints/triggers, or bad data that today is *logged* (`Udb_GrassCatcher`) will silently flow. `[FACT - dbproc-logic §8]`
3. **Caller-managed transactions + partial-write hazard** → procs that `RETURN -1` mid-body leave partial writes; the client must roll back. A naive service-layer re-host without explicit transaction wrapping will corrupt state. `[FACT - dbproc-logic §8; soa-switching-orders §10]`
4. **Two job-instance tables, one shared model** → `soa_job` is the de-facto shared switching-job store; `tc_job` is the telephone specialization; FMS is the state-overlay/executor with no `fms_job`. Model the job once with a domain discriminator, not three tables. `[INFERENCE - b.1]`
5. **All status/type/jobclass enumerations are UNKNOWN** (seed `.ingres` files absent). Any migration must recover `udb_type`/`fms_jobclass`/status-catalog seed data from the live system before the state machines can be fully specified. The proc-embedded literals (ISP 2–100, OR 10–100, card 10/20/50, switemstatus bands, FMS status 10016/10044/10053/10110/>10100) are the only ground truth available. `[FACT - all nine docs, residual UNKNOWNs]`

---

## (f) RESIDUAL [UNKNOWN] (carried forward, legitimately unrecoverable from artifacts)
- All seed/enum domains: jobclass list, movetype/movecategory codes, `soa_job.status` full domain (only `' '`/`'NIS'`/`'Hid'` proven), `outagetype`/`latentflag` planned-vs-forced discriminator values, ISP/OR/card/order/permit/RFP/tag status catalogs.
- The SOA proc that enqueues into `fms_objectstatusqueue` (lives in SOA's procs, not located).
- `SOA_DetermineMoveSequence`/`CheckDeloadComplete` location (absent from all provided artifacts).
- Whether any proc *enforces* clearance via `fms_sesamelockcard` before a move (none found — it is descriptive).
- TC statement-level logic (all 127 procs stubbed; only rules + DDL + guide recoverable).
- "IR" acronym expansion (Issue/Return is inference); FGO/FOT/FOD/FCR/ACDO expansions partly UNKNOWN.
- OpenROAD frame↔type binding (`udb_basetype.editorname`/`tablename` values are absent seed rows).
- The exact stub count (1,225 vs 1,163 — cross-doc contradiction, §0.1).
