# Section 50 — Synthesis: "How UDB Works" (Deliverable 2)

**Scope:** one coherent narrative unifying (1) object resolution, (2) the network-connectivity graph (terminal/node/grouping), and (3) the end-to-end **lifecycle of one representative planned switching order** — from card creation to equipment restoration — naming the exact tables/procs/rules/dbevents/frames touched at each step.

**Sources (verified):** `analysis/sections/{10-metamodel,20-schema-mechanics,30-applogic-business,d3-job-deepdive}.md`; `analysis/verified/{metamodel-core,soa-switching-orders,fms-field-mgmt,ir-orders-permits,tc-jobs-cards,schema-mechanics}.md`; direct DDL re-reads of `udb_grouping`/`udb_node`/`udb_terminal` this pass.
**Tagging:** every material claim `[FACT - file→object]`, `[INFERENCE]`, or `[UNKNOWN]`. Enum **labels** that live in absent `*.ingres` seed files are `[UNKNOWN-seed]`; only proc/rule-embedded literals are authoritative.

---

## 0. The three layers, one sentence each
1. **Object resolution** = "what kind of thing is object N, and where do its subclass columns live?" → answered by the `udb_object.type → udb_type → udb_basetype` join + a hard-coded dispatch ladder in `object$insert`. `[FACT - d1.sql:30457-30471]`
2. **Network graph** = "what is electrically/structurally connected to what?" → answered by `udb_terminal.node` (electrical adjacency: two objects connected ⟺ shared `node`) and `udb_grouping` (containment/hierarchy edges, relationship-typed). `[FACT - udb_terminal/udb_node/udb_grouping DDL]`
3. **Switching order** = "isolate equipment, work, restore" → a `soa_card` of ordered `soa_job` moves (TO half / RS half) driven through state machines by `SOA_*` procs, fired by Ingres rules, fanned out to FMS field-execution and IR permit issue/return via `RAISE DBEVENT`. `[FACT - d3-job-deepdive.md; soa-switching-orders.md]`

These layers are **stacked**: a switching order operates on objects (layer 1) whose connectivity (layer 2) defines what an "outage" even is, and every write is governed by the integrity-in-code model (zero declared FK/PK/CHECK; 290 rules + ~1,225 procs + grasscatcher). `[FACT - 20-schema-mechanics.md §3]`

---

## 1. OBJECT RESOLUTION — the metamodel engine

### 1.1 The five core tables
`[FACT - metamodel-core.md §1, all DDL/row_estimate verified]`
- `udb_object(object PK, type, basetype*, primarygrouping*, typename*, status, terminals, …30 cols)` — universal root, btree unique on `object`, load estimate 105,880 rows. `*`=denormalized caches.
- `udb_type(type, basetype, name, description)` — concrete-type catalog, btree unique on `(type,name)`, est. 2,054.
- `udb_basetype(type, editorname, tablename)` — base-type→physical wiring, btree unique on `type`, est. 41.
- `udb_supertype(type, supertype)` — class graph as direct edges, est. 3,577.
- `udb_extendedtype(type, supertype)` — materialized **transitive closure** (+ reflexive self-edge), est. 15,441 (4.32× supertype). `[FACT - metamodel-core.md §1.4-1.5]`

### 1.2 The resolution path (server dispatch)
At insert, `object$insert` runs the identity join `[FACT - d1.sql:30457-30458, verbatim]`:
```
udb_object.type → udb_type (T.type) → T.basetype, T.name
                              → udb_basetype (T.basetype = BT.type) → BT.tablename (server), BT.editorname (client)
```
- `BT.tablename` ('Switch'→`udb_switch`, etc.) selects the **class-table-inheritance (CTI)** subclass table; `object$insert` then `INSERT INTO Udb_<Subtype>(Object) VALUES(:Object)` — **two rows, two tables, same `object` id**. `[FACT - 10-metamodel.md §1; d1.sql:30462-30471]`
- **CONTRADICTION (carried, resolved):** dispatch is *designed* data-driven but *implemented* as a **hard-coded 22-branch IF/ELSEIF ladder** — adding a base type needs both a `udb_basetype` row AND a code edit. ≥19 of 41 base types (e.g. Location, Rating, Winding, TapSetting, ScanBlock, LoadCurve, DsoValve) get **no** insert-time stub row. `[FACT - 10-metamodel.md §2.1]`
- `BT.editorname` is **never read server-side** (1 occurrence in d1.sql = its DDL at line 13365); it is the OpenROAD editor-frame binding consumed only by `psm.dmt`. `[FACT - metamodel-core.md §3, verified]`
- `object$insert` also writes caches `basetype/typename/primarygroupingname`, audit `created/createdby='Now'/User`, fans out `terminals` rows into `udb_terminal`, and inserts the relationship-**52** primary-grouping edge into `udb_grouping`. `[FACT - metamodel-core.md §5; d1.sql:30460]`

### 1.3 Polymorphic "is-a-kind-of" test
Runtime type tests do **not** walk the supertype graph; they do a single closure lookup: `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)`. Proven uses: FMS card-class must descend from supertype `10093` (d1.sql:29552); node-membership test on supertype `05` in `Object$PrimaryGrouping`. Closure maintained by `SuperType$Insert/$Delete` (wipe→self-edge→inherit ancestors' closure). `[FACT - metamodel-core.md §4, verified]` Magic-id human labels `[UNKNOWN-seed]`.

### 1.4 Integrity posture (governs every write below)
Zero declared FK/PK/CHECK/UNIQUE constraints; uniqueness is only in `modify … unique on`. RI/cascade/validation = imperative (290 rules + ~1,225 procs). Validation is **detective**: soft validators `INSERT INTO udb_grasscatcher(object, problem)`; `GrassCatcher$Insert` looks up `udb_problem.severity` and only `severity='F'` rejects the txn — everything else is logged and committed. `udb_object` rows can't be SQL-deleted (`Object$Delete → Reject('Object_006')`). `[FACT - 10-metamodel.md §5; 20-schema-mechanics.md §3]`

---

## 2. NETWORK-GRAPH TRAVERSAL — terminal / node / grouping

Two **orthogonal** graphs sit on `udb_object`. The *class* hierarchy (§1.3, `udb_supertype`) is a type graph; the two below are **instance** graphs. `[INFERENCE - structural]`

### 2.1 Electrical connectivity = the terminal/node graph
`[FACT - d1.sql:14359-14365, 14997-15004, re-read this pass]`
- `udb_node(node PK, name, kvlevel, primarygrouping, seq)` — hash unique on `node`, est. 21,459. A node = an electrical bus/connection point at a kV level.
- `udb_terminal(object, basetype, terminal, node, inservice, outservice)` — heap, one row per object terminal; `object$insert` fans out `udb_object.terminals` rows as `(Object, BaseType, Terminal=1..N)`, leaving `node` to be wired later. `[FACT - metamodel-core.md §5 fan-out]`
- **Adjacency rule:** two objects are electrically connected **⟺ two of their `udb_terminal` rows share the same `node`**. A node aggregates all terminals plugged into that bus point. `[INFERENCE - high confidence, from the terminal.node FK shape]` `[FACT - terminal.node column exists; the join is the only connectivity mechanism in the udb_ schema]`
- **Traversal** (e.g. the Outage Monitor's connectivity trace) = a node-hopping walk: from a switch's terminal → its node → all other terminals on that node → their objects → their other terminals/nodes, bounded by open switches. `[INFERENCE - ug-vocab-outages §5b: "connectivity trace (Udb terminal/node OR QGIS model)"; the trace algorithm itself is client/monitor 4GL, location of body UNKNOWN]`
- `Object$PrimaryGrouping` writes `udb_node.primarygrouping` for terminals whose object is of node-supertype `05`, tying the electrical node to a containment grouping. `[FACT - metamodel-core.md §4; d1.sql:30477-30484]`

### 2.2 Containment / hierarchy = the grouping graph
`[FACT - d1.sql:14003-14034, re-read this pass]`
- `udb_grouping(grouping, member, relationship, groupingtype, membertype, reference, systemversion)` — heap→**btree unique on (grouping, relationship, member)**, est. **295,316** (the single largest est. in the metamodel). It is a typed edge list: `grouping` (parent object) —[`relationship`]→ `member` (child object), with denormalized `groupingtype`/`membertype` caches kept aligned by rule `CascadeType$Change`. `[FACT - metamodel-core.md §5]`
- **relationship = 52** is the **primary-grouping (containment) edge**, inserted by `object$insert` and maintained by `Object$PrimaryGrouping`. Other relationship ids exist but are `[UNKNOWN-seed]`. `[FACT - metamodel-core.md §5,§7]`
- `udb_object.primarygrouping` (self-ref to a parent `udb_object.object`) + cache `primarygroupingname` is the denormalized "my parent container" pointer; the authoritative edges are the `udb_grouping` rows. `[FACT - metamodel-core.md §2]`
- **Load roll-up:** when `BaseType=21` (consumer/load), `Object$PrimaryGrouping` arithmetically subtracts load (Pfixed/Pnom/Qfixed/Qnom from `udb_consumer`) from the old grouping and adds it to the new — the grouping graph carries aggregated electrical load up the containment tree. `[FACT - metamodel-core.md §5, verified]`
- History: `udb_groupinghistory` (one of only 3 tables with `systemversion`) captures grouping changes. `[FACT - 20-schema-mechanics.md §6]`

### 2.3 Why both graphs matter to switching
`[INFERENCE - synthesized]` The **terminal/node graph** answers "if I open this switch, what loses power?" (the de-energization set) — the basis of outage identification. The **grouping graph** answers "what station/feeder/network does this object belong to?" — the basis for routing a card to the right desk (`soa_job.deskname/substation`) and rolling up status. A switching order's *effect* is computed on graph 2.1; its *organization* (which feeder/station) is computed on graph 2.2.

---

## 3. LIFECYCLE OF ONE REPRESENTATIVE PLANNED SWITCHING ORDER

**Scenario** `[INFERENCE - representative composite; each step's tables/procs/rules/events are FACT-cited]`: a District Operator (DO) builds a planned switching order to take a distribution feeder switch out of service, work it under permit, then restore. This is the SOA (TOMS) planned path (`30-applogic-business.md §c.1`), specialized at field-execution by FMS and at permit issue/return by IR. **There is no `switchingorder` entity — the order = a `soa_card` + its ordered `soa_job` moves.** `[FACT - d3-job-deepdive.md §0]`

Vocabulary invariants `[FACT - d3-job-deepdive.md §0]`: **job == move** (one operate instruction on one object, with a TakeOut half + Restore half); **card == the printable order**; **StepPair == layout grouping of moves on the card** (Work-Permits = fixed Sequence 600); `'TO'`/`'RS'` are **action selectors** passed to `SOA_IssueMove`/`SOA_CompleteMove`, not status codes.

### 3.1 Step-by-step (tables → procs → rules → dbevents → frame)

| # | Operator action | Tables written | Proc(s) (real body, NR>27757) | Rule(s) fired | Dbevent raised | Frame |
|---|---|---|---|---|---|---|
| 1 | DO opens/builds card | `soa_card` (status **10**=built, sets `Opened`) | `SOA_CardUpd` | — | `soa_loadcommoncard`/`soa_loadfmscard` (client-load) | DO desk card frame `[UNKNOWN - psm.dmt name]` |
| 2 | Add moves by step | `soa_job` (switemstatus<20, status `' '`/`'NIS'`), `soa_jobcontrol(card,job,switchingitem; steppair/seq)`, `fms_steppair` | `SOA_JobIns`/`SOA_ItemIns`, `SOA_JobControlIns` (sets `ActivityIdentifier='S'` shared) | `SOA_DetermineSequence` (AFTER INSERT soa_jobcontrol WHERE New.Seq=0); `SOA_ControlResequence` (AFTER UPDATE(Seq) WHERE New.Seq<>0 AND Old.Seq=0) | — | Job Class / Step Heading screens. **Client `SOA_DetermineMoveSequence` location `[UNKNOWN]`** |
| 3 | Move text from class template | reads `fms_jobclass`(7c) + `fms_jobclasscontrol`(placement) + `fms_jobcheck`/`fms_jobaction`(~24k rows each) + `fms_jobtoskill` | reader procs are client 4GL / stubbed `[UNKNOWN-body]` | — | — | — |
| 4 | Activate card | `soa_card.status=`**20** (sets `Activated`), `soa_activecard(application char(4))` | `SOA_CardStatusUpd` (10→20) | `SOA_CardActivate`(New≥20,<50)→`SOA_ActiveListInsert` (reads `FMS_Card`/`TFMS_CardToObject`) | **`SOA_ActiveListChange`** (payload `INSERT;…`) | — |
| 5 | Activate switch item | `soa_job.switemstatus=`**20**, `TOIssued`, `Response='Active'`; cascades to child jobs via jobcontrol | `SOA_ActivateSwitchItem(item,time,activestatus)` | `SLC_NewItemActivated` (if movecat 2/3) | — | — |
| 6 | **Issue TakeOut** (isolate) | `soa_job.toissued/tooperator` | `SOA_IssueMove(Status='TO')` | `IR_FMSJobTOIssued`→`IR_FMSJobUpdate('TI')` | `IR_FeederBoardUpd` (via IR proc) | Issue Moves screen. **Skill gate** `FMS_JobToSkill` vs `FMS_PersonToSkill` |
| 7 | Field executes TakeOut → status flows to FMS | `fms_objectstatusqueue`(inbound, carries job/tors/switchingitem) → `fms_objectstatus`(current, statuscount=refcount) → `fms_objectstatusaudit`(history) | SOA-side enqueue proc `[UNKNOWN - exact proc]`; FMS dequeue/apply procs | FMS status rules | — | — |
| 8 | Complete TakeOut → CutOut | `soa_job.tocomplete`, `soa_card.cutout`, `fms_card.feederstatus` | `SOA_CompleteMove(Status='TO')`; `FMS_CardStatusChange` mirrors `fms_card.status`→`SOA_Card.status` (`RAISE ERROR -1` rolls back on cascade failure — transactional coupling) | `IR_FMSJobTOComplete`→`IR_FMSJobUpdate('TC')`; `FMS_Card$StatusChange` | `fms_sxcutout`, `FMS_Status_Change` | Return Operator Moves |
| 9 | Establish protection / grounds | `fms_groundhistory`, `fms_card.stationground/groundson`, `fms_workpermitprotection` | `FMS_UpdateCardHeader` (status **10044** station-ground, **10053** grounds); `FMS_UpdateGrounds` (sums `fms_objectstatus` status **10016** → `SOA_Job.Grounds` WHERE card Status<50) | `FMS_CardHeader1`(status IN 10044,10053); `FMS_GroundHistory1`(10016,10053) | `fms_card_grounds`, `fms_update_grounds` | Establish Work Permit Protection (Seq **600**) |
| 10 | Issue work permit | `ir_workpermit`(FCR, 30c) / `soa_workpermit` / `fms_workpermit`; ISP path: `soa_inservicepermit`(33c)+`soa_ispermitrequest`(37c) | `IR_IssueFCRWorkPermit(TargetFCR,…,ProtectionMoveCount)`; ISP via `SOA_ISPStatusUpd` (18-state decoder: REQUEST→PENDTO→PENDSO→APPRV→ISSUED→…→100) | — | `ir_processingpermit` | Aged Work Permits / permit screens. Protection-distance gate Green/Yellow/**Red** on issue |
| 11 | Field work, permit return | `ir_workpermit.permitstatus=`**50**(returned); `soa_workpermit.returnstatus` | `IR_ReturnWorkPermit` (hardcodes 50); `IR_CompletePermit`→`SOA_Job`; `IR_WorkPermitUpdate`→`FMS_Workpermit` | — | `ir_returnpermit`, `ir_permitcomplete` | Issue/Return Moves |
| 12 | **Issue Restore** (re-energize) | `soa_job.rsissued/rsoperator`, then `rscomplete`; `soa_card.cutin` | `SOA_IssueMove('RS')`, `SOA_CompleteMove('RS')` | `IR_FMSJobRSIssued/RSComplete`→`IR_FMSJobUpdate('RI'/'RC')` | `fms_sxcutin` | Issue Moves |
| 13 | Close switch item / card | `soa_job.switemstatus≥`**50**; `soa_card.status=`**50**(sets `Closed`); un-hides ISP child jobs if `movecategory=6` | `SOA_CloseSwitchItem`; `SOA_CardStatusUpd`(→50) | `SOA_CardDelete`(New≥50)→`SOA_ActiveListDelete` | `SOA_ActiveListChange`(payload `DELETE;…`); `ir_closecard` | — |
| 14 | Archive | `soa_archivejob`, `soa_archivelog`, `*_archivecard` (INSERT…SELECT + DELETE) | `SOA_ArchiveJob`; archive copy client-orchestrated | — | `SOA_ArchiveTrigger` | — |

### 3.2 The universal move primitive
`[FACT - d3-job-deepdive.md §1.4; soa-switching-orders.md §4]` Every move advances: **drafted → TO issued → TO complete → (work) → RS issued → RS complete → closed.** The four nullable `ingresdate` columns (`toissued, tocomplete, rsissued, rscomplete`) ARE the per-move micro-state (null=not-yet). The numeric band `switemstatus` (<20 drafted / =20 active / 20–49 in-progress / ≥50 closed) is the item lifecycle. Granular intra-band values and `status char(3)` beyond `' '/'NIS'/'Hid'/'Del'/'Xfr'` are `[UNKNOWN-seed]`.

### 3.3 Transaction & coupling reality
`[FACT - 30-applogic-business.md §b.3]` Procs are **not** auto-atomic: `COMMIT`=1 total in 33,392 lines, `ROLLBACK`=0; multi-statement procs `RETURN -1` on `iierrornumber<>0` and **rollback is the OpenROAD client's responsibility** (`psm.dmt`: 392 `DDB_ROLLBACK` + 280 `DDB_COMMIT`). Ingres AFTER rules execute synchronously inside the triggering txn (so the FMS→SOA card-status cascade + its `RAISE ERROR` rollback are one txn); **dbevents are delivered on commit** (decoupled). Several procs (`SOA_ISPRequestStatusUpd`, `SOA_CloseSwitchItem`) `RETURN -1` *after* a successful first write → **real partial-write hazard** if the client fails to roll back.

### 3.4 Forced/automatic outage (contrast, brief)
`[FACT - d3-job-deepdive.md §4; soa-switching-orders.md §6]` The event-driven path skips card authoring: breaker operates → `xa21_outagereport`(EMS feed) → Outage Monitor waits `allapp_systemparameters.outagemonitordelay` → connectivity trace on the **§2.1 terminal/node graph** → `soa_outagesummary(outagetype, latentflag)` + wide `soa_busfaultoutage`(67c, `SOA_BFIns` writes 22 cols=`-1` sentinel, 16 `SOA_BF*Upd` patch groups) → `soa_busfaultcorrelationmatrix` recommends corrective switching. No approval lifecycle (capture, not workflow). Planned-vs-forced discriminator = `soa_outagesummary.outagetype` `[UNKNOWN-seed codes]`.

### 3.5 Sequence diagram — one planned switching order

```mermaid
sequenceDiagram
    autonumber
    actor DO as DO / OpenROAD frame
    participant SOA as SOA procs (SOA_*)
    participant CARD as soa_card / soa_job / soa_jobcontrol
    participant RULE as Ingres rules (AFTER)
    participant FMS as FMS (fms_objectstatus* / fms_card)
    participant IR as IR (ir_workpermit / IR_*)
    participant EV as dbevent bus
    participant AUTO as Desks / SCADA bridge / archiver

    Note over DO,CARD: BUILD
    DO->>SOA: SOA_CardUpd (open card)
    SOA->>CARD: soa_card.status=10 (Opened)
    DO->>SOA: SOA_JobIns + SOA_JobControlIns (add moves)
    SOA->>CARD: soa_job(switemstatus<20) + soa_jobcontrol(steppair,seq)
    CARD-->>RULE: AFTER INSERT soa_jobcontrol (Seq=0)
    RULE->>SOA: SOA_DetermineSequence (order moves)

    Note over DO,EV: ACTIVATE
    DO->>SOA: SOA_CardStatusUpd (10->20)
    SOA->>CARD: soa_card.status=20 (Activated) + soa_activecard
    CARD-->>RULE: SOA_CardActivate
    RULE->>SOA: SOA_ActiveListInsert (reads FMS_Card/TFMS_CardToObject)
    SOA->>EV: RAISE DBEVENT SOA_ActiveListChange (INSERT;)
    EV->>AUTO: all DO desks refresh active list
    DO->>SOA: SOA_ActivateSwitchItem
    SOA->>CARD: soa_job.switemstatus=20, Response='Active'

    Note over DO,FMS: TAKE OUT (isolate)
    DO->>SOA: SOA_IssueMove('TO')  [skill gate FMS_JobToSkill]
    SOA->>CARD: soa_job.toissued/tooperator
    CARD-->>RULE: IR_FMSJobTOIssued
    RULE->>IR: IR_FMSJobUpdate('TI')
    IR->>EV: RAISE DBEVENT IR_FeederBoardUpd
    SOA->>FMS: enqueue -> fms_objectstatusqueue (job/tors/switchingitem)
    FMS->>FMS: apply -> fms_objectstatus (statuscount) -> fms_objectstatusaudit
    DO->>SOA: SOA_CompleteMove('TO')  (CutOut)
    SOA->>CARD: soa_job.tocomplete, soa_card.cutout
    FMS->>CARD: FMS_CardStatusChange -> UPDATE soa_card.status (RAISE ERROR -1 = rollback)
    FMS->>EV: RAISE DBEVENT fms_sxcutout / FMS_Status_Change

    Note over DO,FMS: PROTECT (grounds)
    DO->>FMS: FMS_UpdateCardHeader (10044 station-ground / 10053 grounds)
    FMS->>FMS: FMS_UpdateGrounds (sum status 10016)
    FMS->>CARD: UPDATE soa_job.Grounds (WHERE card status<50)
    FMS->>EV: RAISE DBEVENT fms_update_grounds

    Note over DO,IR: PERMIT
    DO->>IR: IR_IssueFCRWorkPermit (ProtectionMoveCount) [protection-distance gate]
    IR->>EV: RAISE DBEVENT ir_processingpermit
    DO->>IR: IR_ReturnWorkPermit (permitstatus=50)
    IR->>CARD: IR_CompletePermit -> soa_job (RSComplete/Operator)
    IR->>FMS: IR_WorkPermitUpdate -> fms_workpermit (AcknowledgedByFCR)
    IR->>EV: RAISE DBEVENT ir_permitcomplete

    Note over DO,AUTO: RESTORE (re-energize)
    DO->>SOA: SOA_IssueMove('RS') ; SOA_CompleteMove('RS')
    SOA->>CARD: soa_job.rsissued/rscomplete, soa_card.cutin
    CARD-->>RULE: IR_FMSJobRSComplete
    RULE->>IR: IR_FMSJobUpdate('RC')
    FMS->>EV: RAISE DBEVENT fms_sxcutin

    Note over DO,AUTO: CLOSE + ARCHIVE
    DO->>SOA: SOA_CloseSwitchItem (switemstatus>=50) ; SOA_CardStatusUpd(->50)
    SOA->>CARD: soa_card.status=50 (Closed)
    CARD-->>RULE: SOA_CardDelete (>=50)
    RULE->>SOA: SOA_ActiveListDelete
    SOA->>EV: RAISE DBEVENT SOA_ActiveListChange (DELETE;)
    SOA->>AUTO: SOA_ArchiveJob -> soa_archivejob (+ RAISE SOA_ArchiveTrigger)
```

---

## 4. How the three layers interlock (the load-bearing synthesis)

`[INFERENCE - synthesized from all four sections; each edge FACT-cited above]`
1. **Resolution underpins everything:** the switch operated in step 6 is a `udb_object` whose `type→basetype` resolved (step §1.2) to `udb_switch`, giving its `normalopen/currentlyopen/relaytype`. Without resolution there is no equipment to switch.
2. **The graph defines the outage:** opening that switch changes the energization of its `udb_node`(s); the terminal/node walk (§2.1) is exactly what the Outage Monitor traces to populate `soa_outagesummary`. The card's desk/feeder routing comes from the grouping graph (§2.2, relationship 52).
3. **The order drives state through code, not constraints:** each move's progress is four timestamps + a status band, advanced only by `SOA_IssueMove`/`SOA_CompleteMove`/`SOA_*` procs, fired by rules, with cross-module truth (FMS field status, IR permit return) flowing back via rule cascades and `RAISE DBEVENT`. Integrity is detective (grasscatcher + `severity='F'` rejection), transactions are caller-managed, and ~40% of decision logic (validation, type filtering, the connectivity trace, COMMIT/ROLLBACK) lives in the **OpenROAD client** — not in `d1.sql`. `[FACT - 30-applogic-business.md §e.1]`

## 5. Residual `[UNKNOWN]` carried into this synthesis
`[FACT - all four sections]` All status/type/jobclass/movecategory/movetype enumerations beyond proc-embedded literals (seed `.ingres` files absent); human meaning of magic ids (10016/10044/10053/10110, 05/21/26/52/10093/15028); the exact SOA proc that enqueues into `fms_objectstatusqueue`; the connectivity-trace / `SOA_DetermineMoveSequence` 4GL body (absent from d1.sql and both .dmt files); the `udb_basetype.editorname→psm.dmt` frame bindings; whether `systemversion` is enforced on UPDATE; the live outage-detection path (Udb-trace vs rebuilt-on-QGIS — unresolved contradiction).
