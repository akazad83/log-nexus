# Section 10 — Metamodel Reconstruction (Deliverable 1: Metamodel & Integrity)

**Scope:** the UDB / PSDM (Power System Data Model) metamodel core — implicit class hierarchy, the object-resolution mechanism, and the integrity model (declared vs. enforced).
**Sources (verified):** `analysis/verified/metamodel-core.md`, `analysis/verified/metamodel-subtypes.md`, `analysis/verified/schema-mechanics.md`, cross-checked against `d1.sql` proc/rule bodies read in this pass.
**Tagging:** every material claim is `[FACT - file->object]`, `[INFERENCE]`, or `[UNKNOWN]`. Magic ints whose human meaning lives in absent seed rows are flagged `[UNKNOWN-seed]`.

---

## 1. The inheritance pattern — resolved precisely: CLASS-TABLE INHERITANCE, not STI

The Phase-0 ground truth and `metamodel-core.md` repeatedly call this "single-table inheritance (STI)." **That label is wrong, and `metamodel-subtypes.md` §0 already corrects it.** The two verified analyses contradict each other on the name; I resolve it here against the textbook definition.

- **STI (single-table inheritance)** = ONE table holds every subclass; subclass-specific columns are nullable columns on that one table; a discriminator column selects the class. There is exactly one row per object, in one table.
- **CTI (class-table inheritance / "class-table-per-subclass")** = a root table holds common attributes; each subclass has its OWN table holding only that subclass's attributes; the subclass row shares the root's PK 1:1. There are TWO rows per object — one in the root, one in the subclass table.

**PSM is unambiguously CTI** `[FACT - d1.sql:30457 object$insert + 28 subtype-table DDLs]`:
- Common attributes live in `udb_object` (30 cols, PK `object`) `[FACT - d1.sql:14388-14419]`.
- Subclass attributes live in **separate per-type tables** (`udb_switch`, `udb_transformer`, `udb_conductor`, …), each PK'd 1:1 on `object` `[FACT - all `modify udb_<subtype> to {btree|hash} unique on object`]`.
- `object$insert` writes the `udb_object` row, then `INSERT INTO Udb_<Subtype>(Object) VALUES (:Object)` — **two rows, two tables, same `object` id** `[FACT - d1.sql:30462-30471, read verbatim this pass]`.

That is the defining shape of class-table inheritance. The "single table" hypothesis is falsified by the existence of 28 separate subtype tables each keyed on `object`.

### 1.1 But it is a HYBRID — three subtleties that make the label imprecise either way
1. **The discriminator is normalized out into a 3-table type metamodel**, not a single discriminator column. The "class" of an object is not a string on `udb_object`; it is `udb_object.type` → `udb_type.basetype` → `udb_basetype.tablename`. `[FACT - object$insert resolution join, §2]`
2. **`udb_object` is itself a wide god-table** (5 overloaded `char(20)` tag slots: `ownernumber, serialnumber, specnumber, combination, locknumber`, reused per type) — so it carries STI-like overloading on top of the CTI split `[FACT - d1.sql:14388-14419; INFERENCE - reuse-per-type]`.
3. **Not every type has a subtype table.** `udb_basetype.tablename = ''` is a legal no-op branch in `object$insert` — such objects exist ONLY as a `udb_object` row (pure root, no subclass row). So PSM is CTI *for the ~22 enumerated subtypes* and *root-only* for the rest `[FACT - d1.sql:30462 `IF (TableName = '') THEN TableName = TableName` no-op]`.

**Precise verdict:** `[INFERENCE - high confidence, grounded in the DDL + insert engine]` PSM uses **data-driven class-table inheritance**: a normalized 3-table type/basetype/supertype metamodel as the discriminator, a wide common root (`udb_object`), and optional per-base-type extension tables joined 1:1 on `object`. It is NOT single-table inheritance.

### 1.2 Subtype-table inventory (28 CTI extension tables) `[FACT - d1.sql DDL, line cites verified this pass]`
`udb_bwrsteamsupply`(13421), `udb_capacitor`(13460), `udb_circuitroute`(13489), `udb_combustionturbine`(13516), `udb_communicationlink`(13546), `udb_computer`(13579), `udb_conductor`(13607), `udb_conductortype`(13642), `udb_consumer`(13672), `udb_dsovalve`(13714), `udb_fossilsteamsupply`(13867), `udb_generator`(13922), `udb_hydroturbine`(14105), `udb_location`(14285), `udb_measurementtype`(14320), `udb_person`(14443), `udb_pwrsteamsupply`(14501), `udb_rating`(14547), `udb_reactor`(14581), `udb_scanblock`(14610), `udb_steamturbine`(14640), `udb_switch`(14707), `udb_tapsetting`(14767), `udb_telemetry`(14834), `udb_telephonecircuit`(14875), `udb_towertype`(15027), `udb_transformer`(15069), `udb_winding`(15132).
- 1:1 on `object` (one subclass row): most of the above.
- **1:N on `object`** (NOT pure subtype — multi-row extension): `udb_winding`(object,winding), `udb_tapsetting`(object,winding-pair), `udb_rating`(object,type), `udb_terminal`(object,terminal) `[FACT - their `modify ... unique on` is composite, not `object` alone]`.
- **No unique index** (HEAP): `udb_dsovalve` — `object` uniqueness is declared (`not null`) but NOT enforced by an index `[FACT - `modify udb_dsovalve to heap`]`.

---

## 2. The object-resolution mechanism (the "what is this object?" path)

Resolution is hard-coded in `object$insert` `[FACT - d1.sql:30457-30458, read verbatim this pass]`:

```sql
SELECT :BaseType = BT.Type, :TableName = BT.TableName
FROM "ingres".Udb_Type T, "ingres".Udb_BaseType BT
WHERE :Type = T.Type AND T.BaseType = BT.Type;
```

```
udb_object.type
  └─> udb_type   (T.type = :type)              → T.basetype, T.name
        └─> udb_basetype (T.basetype = BT.type) → BT.tablename  (which subtype table  — SERVER dispatch)
                                                → BT.editorname (which OpenROAD frame — CLIENT only)
```

- `udb_basetype.tablename` → the per-type subtype table (e.g. `'Switch'` → `udb_switch`). **Server-side dispatch.** `[FACT - object$insert ladder]`
- `udb_basetype.editorname` → the OpenROAD editor frame. **Client-only**: `editorname` appears EXACTLY ONCE in `d1.sql` — its DDL at line 13365 — and in NO server proc and NO grant `[FACT - metamodel-core.md §3 VERIFIED; corrected the earlier "and in grants" claim]`.
- `udb_object.basetype`, `udb_object.typename`, `udb_object.primarygroupingname` are **denormalized caches** written at insert time and refreshed by rules `[FACT - object$insert UPDATE at d1.sql:30460]`.

### 2.1 CONTRADICTION — "data-driven" dispatch is actually HARD-CODED
Although `udb_basetype.tablename` is *designed* as a data-driven dispatch key, `object$insert` does **no dynamic SQL**. After reading `TableName`, it runs a **hard-coded `IF/ELSEIF` string ladder** with exactly 22 named branches; only those base types get an automatic subclass stub row `[FACT - d1.sql:30462-30471, all 22 branches read verbatim]`:

`Conductor, Generator, Consumer, Capacitor, Reactor, Switch, Transformer, Telemetry, TowerType, ConductorType, Computer, MeasurementType, Person, CombustionTurbine, HydroTurbine, SteamTurbine, FossilSteamSupply, BWRSteamSupply, PWRSteamSupply, CommunicationLink, TelephoneCircuit (also seeds Udb_CircuitRoute(Object,0)), EquipTemplate (→ SLC_EquipTemplate, outside udb_ namespace)`.

Implications `[INFERENCE - structurally certain]`:
- `udb_basetype` row_estimate = 41 base types `[FACT]`, but only 22 have an insert-time branch → **≥19 base types get NO automatic subclass row** (e.g. `Location, Rating, Winding, TapSetting, ScanBlock, LoadCurve, DsoValve`). Their extension rows must be created by other paths. Exact identities need absent seed data `[UNKNOWN-seed]`.
- **Adding a base type requires BOTH a `udb_basetype` data row AND a code edit to `object$insert`.** The "data-driven metamodel" claim is half-true.

### 2.2 CONTRADICTION SURFACED — the `'Generator'` branch literal (corrected from metamodel-core.md)
`metamodel-core.md` §3.1 raises a "NEW FINDING": the Generator branch literal is `' Generator'` **with a leading space**, a latent dispatch bug. **I re-read the raw bytes this pass and that characterization is incorrect.** `cat -A` on d1.sql:30462-30463 shows the line ends `... TableName = '$` (the `$` is the EOL marker) and the next line begins `Generator')`. So the stored literal is `'<newline>Generator'` — it contains an **embedded newline from dump line-wrapping**, NOT a leading space `[FACT - d1.sql:30462-30463 raw-byte inspection this pass]`.

Honest assessment `[INFERENCE]`: this is almost certainly an **Ingres unload/dump line-wrap artifact** (the dumper wraps long proc text at ~75 cols mid-token), and the *loaded* procedure likely has the clean literal `'Generator'`. I cannot prove the loaded form without the loader's whitespace-folding behavior, which is `[UNKNOWN]`. **Net:** do NOT assert a live "Generator dispatch bug" as fact; it is an unverified dump artifact. The other 21 branches wrap identically (e.g. `'Reactor'`, `'Transformer'`, `'TowerType'` all span line breaks) and no one calls those bugs — consistency says this is formatting, not a defect. This corrects an over-claim in the verified source.

### Diagram 1 — Metamodel resolution path
```mermaid
flowchart LR
  OBJ["udb_object<br/>(PK object, 30 cols)<br/>type, basetype*, typename*,<br/>primarygrouping, status, terminals"]
  TYP["udb_type<br/>(type, basetype, name, desc)<br/>~2054 rows [UNKNOWN-seed]"]
  BT["udb_basetype<br/>(type, tablename, editorname)<br/>~41 rows [UNKNOWN-seed]"]
  SUP["udb_supertype<br/>(type, supertype)<br/>direct edges ~3577"]
  EXT["udb_extendedtype<br/>(type, supertype)<br/>TRANSITIVE CLOSURE +self ~15441"]
  SUB["per-type subtype table<br/>udb_switch / _transformer / _conductor ...<br/>PK object (1:1 CTI)"]
  FRAME["OpenROAD editor frame<br/>(psm.dmt — CLIENT ONLY)"]
  GC["udb_grasscatcher<br/>(object, problem)<br/>soft-validation sink"]

  OBJ -->|"type = T.type"| TYP
  TYP -->|"T.basetype = BT.type"| BT
  BT -.->|"tablename → IF/ELSEIF ladder<br/>(HARD-CODED, 22 branches)"| SUB
  BT -.->|"editorname (never read server-side)"| FRAME
  TYP --> SUP
  SUP -.->|"SuperType$Insert maintains"| EXT
  SUB -->|"object 1:1"| OBJ
  OBJ -.->|"validation failures"| GC
  EXT -.->|"polymorphic is-a-kind-of test<br/>WHERE Type IN (SELECT Type FROM udb_extendedtype WHERE SuperType=X)"| TYP

  classDef cache fill:#fff3cd,stroke:#856404;
  classDef seed fill:#e2e3e5,stroke:#383d41;
  class TYP,BT seed;
```
\* `basetype`, `typename` on `udb_object` are denormalized caches derived at insert time. `[FACT]`

---

## 3. The equipment class hierarchy (implied) + operating domains

`udb_supertype(type, supertype)` stores the is-a/part-of class graph **as data**; `udb_extendedtype` is its materialized transitive closure (reflexive self-edge + all ancestors), maintained by `SuperType$Insert`/`$Delete` rules `[FACT - metamodel-core.md §4, verified]`. **The actual edges live in absent seed data** `[UNKNOWN-seed]` — so the hierarchy below is reconstructed from (a) subtype-table column semantics, (b) the steamturbine→steamsupply FK, and (c) operating-domain grouping evident in the table families. It is `[INFERENCE]`, not a transcription of `udb_supertype` rows.

**Grounded edges (FACTs that constrain the hierarchy):**
- `udb_steamturbine.steamsupply integer` is an object FK to one of the three steamsupply subtype tables `[FACT - d1.sql:14642, read this pass]` → turbine *uses* a steamsupply (generation/dynamics domain).
- `udb_winding`(1:N), `udb_tapsetting`(1:N) hang off transformer objects `[FACT - composite keys]` → part-of, not is-a.
- `udb_conductor` references `towertype`, `phaseconductortype` (→ `udb_conductortype`) `[FACT - metamodel-subtypes.md §2]` → line equipment composed of type specs.
- `Object$PrimaryGrouping` does consumer-load arithmetic roll-up only when `BaseType = 21` `[FACT - metamodel-core.md §5, verified]` → ties `udb_consumer` to the load/distribution domain.
- Node-supertype test uses literal supertype `05`; FMS card-class descendants tested against supertype `10093`; FMS equip-class basetype `26` `[FACT - magic ids verified in proc/rule bodies]` `[UNKNOWN-seed - human labels]`.

### Diagram 2 — Equipment class hierarchy by operating domain (inferred)
```mermaid
classDiagram
  class Object["udb_object (ROOT — every equipment is one)"]

  %% ---- TRANSMISSION / NETWORK (electric) ----
  class Conductor
  class ConductorType
  class TowerType
  class Switch
  class Transformer
  class Winding
  class TapSetting
  class Capacitor
  class Reactor
  class Rating
  Object <|-- Conductor : CTI
  Object <|-- Switch : CTI
  Object <|-- Transformer : CTI
  Object <|-- Capacitor : CTI
  Object <|-- Reactor : CTI
  Conductor ..> ConductorType : phaseconductortype
  Conductor ..> TowerType : towertype
  Transformer *-- Winding : 1:N part-of
  Transformer *-- TapSetting : 1:N part-of
  Object ..> Rating : thermal ratings (object,type)

  %% ---- GENERATION / DYNAMICS (SMS/Steam remnant) ----
  class Generator
  class CombustionTurbine
  class HydroTurbine
  class SteamTurbine
  class FossilSteamSupply
  class BWRSteamSupply
  class PWRSteamSupply
  Object <|-- Generator : CTI
  Object <|-- CombustionTurbine : CTI
  Object <|-- HydroTurbine : CTI
  Object <|-- SteamTurbine : CTI
  Object <|-- FossilSteamSupply : CTI
  Object <|-- BWRSteamSupply : CTI
  Object <|-- PWRSteamSupply : CTI
  SteamTurbine ..> FossilSteamSupply : steamsupply FK
  SteamTurbine ..> BWRSteamSupply : steamsupply FK
  SteamTurbine ..> PWRSteamSupply : steamsupply FK

  %% ---- DISTRIBUTION / LOAD ----
  class Consumer["Consumer (BaseType=21 → load roll-up)"]
  class LoadCurve
  class LoadValue
  Object <|-- Consumer : CTI
  Consumer ..> LoadCurve : load shape
  LoadCurve *-- LoadValue : 1:N time-series

  %% ---- SUBSTATION / SCADA / MEASUREMENT ----
  class Telemetry
  class MeasurementType
  class ScanBlock
  Object <|-- Telemetry : CTI
  Object <|-- MeasurementType : CTI
  Object <|-- ScanBlock : CTI

  %% ---- TELEPHONIC / COMMS ----
  class TelephoneCircuit
  class CircuitRoute
  class CommunicationLink
  class Computer
  Object <|-- TelephoneCircuit : CTI
  Object <|-- CommunicationLink : CTI
  Object <|-- Computer : CTI
  TelephoneCircuit *-- CircuitRoute : auto-seeded (object,0)

  %% ---- NON-ELECTRIC / SUPPORT ----
  class DsoValve["DsoValve (gas/distribution — OUTSIDE electric model)"]
  class Person
  class Location
  Object <|-- DsoValve : CTI (HEAP, no uniq idx)
  Object <|-- Person : CTI
  Object <|-- Location : CTI
```
**Caveats on Diagram 2** `[INFERENCE / UNKNOWN]`: the domain partitions (transmission / generation / distribution / substation-SCADA / telephonic) are inferred from table-family semantics, NOT read from `udb_supertype`. The actual `udb_supertype` is-a edges (~3577) and the type names (~2054) are in absent `.ingres` files `[UNKNOWN-seed]`. `udb_terminal`/`udb_node` electrical connectivity (two objects connected ⟺ shared `udb_node`) is the runtime graph; it is orthogonal to this *class* hierarchy and covered in the connectivity section.

---

## 4. Closure mechanics (how is-a is tested at runtime)

`udb_extendedtype` is the **polymorphic is-a-kind-of test surface** `[FACT - metamodel-core.md §4, verified]`:
- `SuperType$Insert`: (1) wipe the type's closure rows; (2) insert reflexive self-edge `(Type,Type)`; (3) inherit every ancestor's already-closed supertypes; (4) validate basetype consistency → grasscatcher `Type_008`. Also raises `Type_004/005/009`. `[FACT - d1.sql:31831, verified verbatim in source analysis]`
- Closure ratio 15441/3577 = **4.32×** — consistent with self-edge + ancestor expansion `[FACT]`.
- **Consumed** as `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)` — single closure-table lookup instead of recursive graph walk. Confirmed uses: FMS card-class must descend from `10093` (d1.sql:29552); node-membership test on supertype `05` `[FACT - verified]`.

---

## 5. The integrity model — DECLARED vs. ENFORCED

This is the single most important architectural fact of the schema.

### 5.1 Declared integrity: effectively ZERO `[FACT - schema-mechanics.md §3.1, all counts re-verified]`
| Construct | Raw hits | Real constraints | Note |
|---|---:|---:|---|
| `references` | 450 | **0** | all are `grant references … to public` (privileges), NOT FK clauses |
| `foreign key` | 0 | 0 | no declared FKs anywhere |
| `primary key` | 0 | 0 | no declared PKs |
| `check (` | 25 | **0** | all are table/proc NAMES containing "check" |
| declarative `unique` | 0 | 0 | uniqueness is in `modify … unique`, not constraints |
| `not null` | 4,727 | (used) | the ONLY declared integrity; mostly `not null default ' '`/`0` (sentinel) |

- **De-facto PK** of each table = the `modify <t> to <struct> unique on <cols>` clause. 377 of 450 tables have a unique structure; the rest (logs/audit/archive) are deliberately non-unique `[FACT]`.
- **Zero secondary indexes** (`create index` = 0); one clustering structure per table, 450/450. Non-key lookup = full scan `[FACT - schema-mechanics.md §1.3, corrected: no table has >1 modify]`.

### 5.2 Enforced integrity: ALL in code (1,225 real procs + 290 rules + 208 dbevents) `[FACT]`
- **FK enforcement** → post-hoc proc checks fired by AFTER-INSERT rules (e.g. `FMS_ValidateEquipClass`); violations **logged, not rejected** `[FACT - schema-mechanics.md §3.2]`.
- **Cascade delete** → hand-coded sequential `DELETE` ladders with manual `IF iierrornumber <> 0 THEN return -1` (e.g. `CAC_CO_GroupingDel` deletes 7 child tables) `[FACT - body verified]`.
- **Domain validation** → `INSERT INTO udb_grasscatcher(object, problem)` (e.g. `Conductor$Validate`: `IF (X/R)<5 THEN … 'Conductor_001'`; `Object$Validate`: `IF InService>OutService THEN … 'Object_001'`) `[FACT - bodies verified]`.
- **The grasscatcher IS the integrity layer.** `GrassCatcher$Insert` dedupes, looks up `udb_problem.severity`; `IF Severity='F' THEN RAISE ERROR -1 (reject) ELSE MESSAGE (warn)`. So `severity='F'` problems DO block the txn — the model is detective-with-selective-rejection, not preventive `[FACT - metamodel-subtypes.md §5, verified verbatim]`.
- **Delete protection** → `udb_object` rows cannot be SQL-deleted: rule `Object$Delete AFTER DELETE ON Udb_Object EXECUTE PROCEDURE Reject(Problem='Object_006')`; `Object$NullObjectProtect` rejects `object=0` (`Object_014`) `[FACT - d1.sql:33131, 33137, verified]`. Deletion is done offline (annual script bypassing the rule) or by re-typing to "Historical Object" (type 998) `[FACT - ug.html]`.

### 5.3 The sentinel-default anti-pattern (20 of 30 `udb_object` columns) `[FACT - schema-mechanics.md §5.2 + metamodel-core.md §6]`
20/30 columns are `not null default ' '`/`default 0`; 9 are genuinely nullable (dates + 2 GIS floats + source); 1 is the `not null not default` PK. Consequence: `0`/`' '` cannot be distinguished from "unknown"/"not-applicable", forcing magic-value tests (`IF BaseType=0`, `IF PrimaryGrouping!=0`) everywhere, and `object=0` had to be banned by a trigger — direct evidence the sentinel-zero convention leaks a forbidden value into a meaningful key column `[FACT/INFERENCE]`.

### 5.4 Denormalization desync — confirmed latent bug `[FACT - metamodel-core.md §10, CONFIRMED]`
`udb_object.basetype` is written ONLY by `object$insert` (at insert time). There is **NO** `AFTER UPDATE(BaseType) ON Udb_Type` rule and NO other statement that writes `udb_object.basetype`. Therefore changing `udb_type.basetype` for an existing type silently leaves all already-inserted instances pointing at a stale basetype / wrong subtype table. Real latent integrity gap.

### 5.5 Security & concurrency (integrity-adjacent) `[FACT]`
- **Flat security:** 4,835 grants, 100% to `public`, no roles. 180 `revoke execute … from public cascade` lock down trigger-only/key-gen procs so they fire solely via rules `[FACT - schema-mechanics.md §4, re-verified]`.
- **No explicit concurrency control in the server schema:** `set lockmode` = 0 occurrences in d1.sql (the Phase-0 "8 usages" are in the `.dmt` client 4GL, not the server) `[FACT]`. `systemversion` optimistic token exists on exactly 3 tables (`udb_object, udb_grouping, udb_groupinghistory`) but its enforcement on UPDATE is not visible in sampled procs `[FACT / UNKNOWN]`. Key allocation serializes on a single-row `UPDATE *_lastkey SET value+1` — a contention hotspot, no sequence object `[FACT/INFERENCE]`.

### Diagram note (integrity control flow)
The integrity/automation control-flow diagram (client → proc → base table → AFTER rule → trigger proc → {cascade delete | grasscatcher | history | archive | RAISE DBEVENT}) is rendered in `schema-mechanics.md §10` and not duplicated here.

---

## 6. Contradictions surfaced (this pass)
1. **STI vs CTI naming** — `metamodel-core.md` (and Phase-0) say STI; `metamodel-subtypes.md` §0 says CTI. **CTI is correct** (§1). Resolved.
2. **`'Generator'` branch literal** — `metamodel-core.md` §3.1 claims a leading-space `' Generator'` dispatch bug. Raw-byte inspection shows an **embedded newline from dump line-wrapping**, not a space, and the other 21 branches wrap identically → almost certainly a formatting artifact, NOT a live bug. Over-claim corrected (§2.2).
3. **"data-driven dispatch"** — schema implies data-driven (`udb_basetype.tablename`), code is a hard-coded 22-branch ladder. Half-true (§2.1).

---

## 7. Residual UNKNOWNs (seed-data dependent — genuinely unresolvable)
- Full `udb_type` (~2054), `udb_basetype` (~41 incl. all `tablename`/`editorname`), `udb_supertype` edges (~3577), `udb_object.status` char(16) enumeration — all in absent `/home/ingres/Downloads/*.ingres` files `[UNKNOWN-seed]`.
- Human meaning of magic ids `05, 21, 26, 52, 10, 10093, 15028, 998, 999/22173/22174` — ids are real in proc/rule bodies; labels need seed rows `[UNKNOWN-seed]`.
- Exact identities of the ≥19 base types with no `object$insert` dispatch branch `[UNKNOWN-seed]`.
- Whether the dump's mid-token line-wraps survive loading (the `'Generator'` question) `[UNKNOWN]`.
- `systemversion` optimistic-lock enforcement on UPDATE `[UNKNOWN]`.
