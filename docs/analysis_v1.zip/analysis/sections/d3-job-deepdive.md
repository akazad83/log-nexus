# Deliverable 3 — Critical Components Deep-Dive: JOB & JOB CLASS (and peer constructs)

> **Synthesis section.** Built from the six verified analyses (`tc-jobs-cards.md`, `soa-switching-orders.md`, `fms-field-mgmt.md`, `ir-orders-permits.md`, `ug-switching-lifecycle.md`, `ug-vocab-outages.md`) plus direct DDL re-reads of `d1.sql` for the job-class family, `fms_sesamelockcard`, and `soa_busfaultoutage`. Every material claim tagged `[FACT - file->object]`, `[INFERENCE - reasoning]`, or `[UNKNOWN]`. Honors the "## Verification" footers of the source docs.

---

## 0. Read-first contradictions & invariants (do not re-litigate downstream)

1. **`job` == `move`.** [FACT - ug.html:5130-5132] "A Job Class defines the 'move'... **The term 'move' and 'job' are synonymous.**" A *job* is one switching MOVE (one operate instruction on one object). It is **not** "a switching order." [FACT - tc-jobs-cards.md, soa-switching-orders.md]
2. **The order container is the CARD, not the job.** [FACT - soa-switching-orders.md §2; ug-switching-lifecycle.md §0] A *switching order* in this system ≈ **card + its ordered jobs(moves)**. There is **no single `switchingorder` entity/table**. [FACT - ug-switching-lifecycle.md §0]
3. **CARD → ordered JOBS(moves) → TO/RS two-phase** is the shared framework across FMS, SOA, TC (and TFMS/SLC/FRA). Each app specializes it. [FACT - tc-jobs-cards.md §10]
4. **There is no `fms_job` table.** [FACT - fms-field-mgmt.md §1; ug-vocab-outages.md §4] FMS holds the **job CLASS library** (`fms_jobclass`) shared by all apps; the **job INSTANCE** tables are `soa_job` and `tc_job` only. The canonical FMS job-row shape survives in the archive twin `fms_archivejob`. [FACT - fms-field-mgmt.md §1, d1.sql:1484]
5. **Job class = template; job = instance.** [INFERENCE - ug-vocab-outages.md §4] The guide's loose "move=job" synonymy collapses class↔instance; the schema separates them cleanly. `jobclass` is an integer FK on every job row.
6. **All server-side proc bodies in TC and the FMS/SOA/IR *stub* region are empty (`as begin return; end`).** The real bodies are the **second** proc population in d1.sql (`create or replace procedure  NAME ( args ) = BEGIN ... END`). TC is the exception: **all 127 TC procs are stubs even in the real region.** [FACT - tc-jobs-cards.md §1; fms-field-mgmt.md §0; soa-switching-orders.md §0]
7. **CONTRADICTION across source docs — global stub count.** `soa-switching-orders.md` / `tc-jobs-cards.md` / `ug-switching-lifecycle.md` assert **1,163 stubs** / 1,287 distinct; `ug-vocab-outages.md` verifier says **1,163 (47.5%)**; `tc-jobs-cards.md` §1 verifier says **1,225 stubs**; `ug-switching-lifecycle.md` says **1,225 stubs + 1,225 bodies (1:1)**. **The two verified figures in circulation are 1,163 and 1,225 — they disagree by 62.** [CONTRADICTION - source docs]. Not load-bearing for this section (both ≈half of 2,450); flagged, not resolved here. The module-level splits ARE consistent: SOA 240 stub/240 body, IR 134/134, FMS 354 stub/351 body, **TC 127/127 (all stubs).**
8. **No seed/row data anywhere** (all tables `copy ... from '/home/ingres/Downloads/<t>.ingres'`, files absent). Therefore **every status/type/category enumeration is `[UNKNOWN]` except integer/string literals hardcoded in proc/rule bodies.** Do not fabricate a status or job-class list. [FACT - ground truth + all six docs]
9. **Status enums DIVERGE per application — they are NOT shared.** SOA card: 10/20/50. FMS card: <20/20/50/55/99. TC card: 4. [FACT - ug-switching-lifecycle.md §2]. Any synthesis MUST treat them per-app.

---

# CONSTRUCT 1 — JOB (the switching MOVE)

## 1.1 Purpose
A **job = one switching MOVE**: a discrete operate instruction on one equipment object, carrying a paired **Take-Out (TO)** and **Restore (RS)** half. [FACT - ug.html:5130-5132; soa_job/tc_job DDL]. It is the atomic unit of switching work; N jobs in `seq`/`steppair` order on a card = the printable switching order. [FACT - soa-switching-orders.md §2]

## 1.2 Schema — `soa_job` (31 cols, PK `job`, btree unique on `job`) [FACT - soa-switching-orders.md §2, DDL-verified]
| Group | Columns | Meaning |
|---|---|---|
| Identity | `job`, `jobclass`, `basekey`, `controlcard`, `shadowlink` | move id; class template ref; control/shadow links |
| Object operated | `equip`, `equipname`, `equipclass`, `equipclassname`, `grounds`, `substation`, `deskname` | what is switched |
| **Two status fields** | `status char(3)` (text), `switemstatus integer` (numeric) | see §1.4 — TWO independent state fields |
| Move classification | `movetype char(4)` (e.g. `'Dead'`), `movecategory integer` | operation code; order-type discriminator (§1.5) |
| **TO half** | `tomove varchar(160)`, `tomoverules`, `tooperator`, `toissued`, `tocomplete`, `groundon` | take-out instruction + issue/complete state |
| **RS half** | `rsmove varchar(160)`, `rsmoverules`, `rsoperator`, `rsissued`, `rscomplete`, `response varchar(40)` | restore instruction + issue/complete state |
| Display | `activityidentifier char(1)` (`'S'`=shared move), `movefgcolor`, `movebgcolor` | UI |

`soa_jobcontrol(card, job, switchingitem)` (8 cols, btree unique) attaches a job to a card in `steppair`/`steplevel`/`seq` order; `printid` selects the printout. [FACT - soa-switching-orders.md §2]. `soa_job_to_soo(job, seq, ordernumber)` (btree unique, 3-col PK) bridges a job to an IR operating order. [FACT - soa-switching-orders.md §10, d1.sql:10168 — NOT a heap]

## 1.3 Schema — `tc_job` (37 cols, btree on `(card, seq, job)`) [FACT - tc-jobs-cards.md §4]
Same TO/RS two-phase shape, specialized for telephone circuits: identity `(job, card, seq, jobclass, jobclassseq, steppair)`; `status char(3)` (known value `'Xfr'`=move transferred); topology (`circuit, linenumber, circuitclass, substation, organization`); TO half (`movetype char(4)`, `tomove, tostep, tomoverules, tooperator, toissued, tocomplete`); RS half (`rsmove, rsmoverules, rsstep, rsoperator, rsissued, rscomplete`); service (`inservice, outservice` — drive outage stats); switch position (`initialswitchpos, finalswitchpos`); results (`results, resultscode`). **`tc_job` has NO `workpermit`/`permitjobid` column** [FACT - tc-jobs-cards.md §6 VERIFIER FIX]. Sentinels: `job=-1` (staged/new), `job=2147483647` (max-int), `seq=-1`. [FACT - tc-jobs-cards.md §4]

## 1.4 State machine — `soa_job` (the canonical job lifecycle)
`soa_job` carries **two orthogonal state fields**:

**(a) `switemstatus integer` — the switching-item lifecycle** (the real state machine). Only threshold BANDS are code-proven; granular values inside bands are `[UNKNOWN]` (seed-dependent). [FACT - soa-switching-orders.md §4a]
- `<20` = drafted/inactive (default 0)
- `=20` = active/activated (`SOA_ActivateSwitchItem` sets `SWItemStatus=:ActiveStatus`, `Response='Active'`; queries gate `>=20 AND <50` for active) [FACT - SOA_ActivateSwitchItem body; SLC_NewItemActivated rule fires on `=20`]
- `>=20 AND <50` = active/in-progress range
- `>=50` = closed/complete (`SOA_CloseSwitchItem` sets `:ClosureStatus`; `SLC_ItemClosed` rule fires `>=50 AND Old<50`) [FACT - soa-switching-orders.md §4a]

**(b) `status char(3)` — text move-status.** Confirmed literals only: `' '` (normal), `'NIS'` (not-in-service), `'Hid'`/`'HID'` (hidden — suppresses ISP child jobs), `'Del'` (delete move → cascade-deletes `FMS_WorkPermitProtection`), `'Xfr'` (transferred/shared). [FACT - soa-switching-orders.md §4b; ug-switching-lifecycle.md §3]. Full domain `[UNKNOWN]`.

**(c) Per-move TO/RS micro-states** = the four nullable timestamps. null=not-yet, non-null=done. [FACT - soa-switching-orders.md §4c]
- `SOA_IssueMove(Job, Status, Issued, Operator)`: `Status='TO'`→set `TOIssued/TOOperator`; `'RS'`→set `RSIssued/RSOperator`; else `message 'Unknown action requested.'` [FACT - body verbatim, soa-switching-orders.md §4c]
- `SOA_CompleteMove(Job, Status, Complete)`: `'TO'`→`TOComplete`; `'RS'`→`RSComplete`. [FACT - body verbatim]
- **`'TO'`/`'RS'` are ACTION SELECTORS passed to these procs, NOT job-status codes.** [FACT - ug-switching-lifecycle.md §3]

```mermaid
stateDiagram-v2
  direction LR
  [*] --> Drafted: SOA_ItemIns/SOA_JobIns<br/>(switemstatus<20, status=' '/'NIS')
  Drafted --> Active: SOA_ActivateSwitchItem<br/>(switemstatus=20, Response='Active')
  Active --> TOIssued: SOA_IssueMove('TO')<br/>set TOIssued/TOOperator
  TOIssued --> TOComplete: SOA_CompleteMove('TO')<br/>set TOComplete
  TOComplete --> RSIssued: SOA_IssueMove('RS')<br/>set RSIssued/RSOperator
  RSIssued --> RSComplete: SOA_CompleteMove('RS')<br/>set RSComplete
  RSComplete --> Closed: SOA_CloseSwitchItem<br/>(switemstatus>=50)
  Active --> Purged: SOA_CloseSwitchItem<br/>(ClosureRemark='Purge')
  Closed --> Archived: -> soa_archivejob
  Archived --> [*]
  note right of Drafted
    LABELS Drafted/Active/Closed are INFERENCE.
    NUMERIC bands (<20 / =20 / 20-49 / >=50) are FACT.
    status char(3) granular codes = UNKNOWN (seed rows absent).
  end note
```
[INFERENCE - labels; FACT - numeric bands & proc bindings, soa-switching-orders.md §11]

## 1.5 `movecategory` — the order-TYPE discriminator on a job [FACT - soa-switching-orders.md §3, all values code-proven]
`0`=normal · `1`=special(FgColor=8) · `2,3`=**SLC** long-term clearance items (`SLC_NewItemActivated`/`SLC_ArchiveItem`/`SLC_PurgeItem` fire on these) · `4,5`=substation kV-rated moves · `6`=**In-Service Permit** move (`SOA_CloseSwitchItem` checks `=6` to un-hide child jobs). Full enum `[UNKNOWN]`; these six are proven by code.

## 1.6 Readers & writers
- **Writers (real bodies):** `SOA_ActivateSwitchItem`, `SOA_CloseSwitchItem`, `SOA_IssueMove`, `SOA_CompleteMove`, `SOA_JobStatusUpd`, `SOA_JobControlIns`, `SOA_DetermineSequence`, `SOA_ControlResequence`, `SOA_JobColor`. [FACT - soa-switching-orders.md §2,§4,§8]
- **Sequencing is server-driven:** rule `SOA_DetermineSequence` (AFTER INSERT `soa_jobcontrol` WHERE `New.Seq=0`); rule `SOA_ControlResequence` (AFTER UPDATE(Seq) WHERE `New.Seq<>0 AND Old.Seq=0`). [FACT - d1.sql:33212/33214]
  - **CAVEAT:** the guide-named `SOA_DetermineMoveSequence` and `CheckDeloadComplete` are **client OpenROAD 4GL — absent from d1.sql AND from psm.dmt/psm_4glprocs.dmt (0 matches). Location `[UNKNOWN]`.** [FACT - ug-switching-lifecycle.md §0,§11.3]
- **Cross-module readers/writers of `soa_job`:**
  - IR rules `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` fire `IR_FMSJobUpdate(Action='RC'|'RI'|'TC'|'TI')` on TO/RS timestamp changes → raises `IR_FeederBoardUpd`. [FACT - d1.sql:33097-33103; ir-orders-permits.md §0.2,§8]
  - `IR_CompletePermit` writes `SOA_Job` (RSComplete/RSOperator/Response). [FACT - ir-orders-permits.md §4.2, d1.sql:29903]
  - `FMS_UpdateGrounds` sums `fms_objectstatus` status 10016 → `SOA_Job.Grounds` (WHERE card `Status<50`). [FACT - fms-field-mgmt.md §7, d1.sql:29523]
  - `IR_DelOrderSubJobs`/`IR_DelCompleteSubJobs` DELETE from `SOA_Job`. [FACT - ir-orders-permits.md §4.1]

## 1.7 Design rationale [INFERENCE]
The TO/RS two-phase split in **one row** (vs two rows) lets the card render as a two-column sheet (TakeOut left / Restore right per StepPair) and lets each half be independently issued/completed by different operators at different times — the physical reality of switching: isolate now, work, restore later. The dual `status char(3)` + `switemstatus integer` separates *display/move-text state* from *lifecycle band state*. Denormalized `*name` cache columns avoid metamodel joins on the hot render path.

## 1.8 Failure modes [INFERENCE unless cited]
- Per-move issue/complete is **null→timestamp**, idempotency not enforced in the proc; double-issue would overwrite operator/time silently. [INFERENCE - SOA_IssueMove body has no guard]
- `SOA_IssueMove`/`SOA_CompleteMove` with an action other than `'TO'`/`'RS'` → `message` (warning), no state change. [FACT - bodies]
- Ingres DB procs are **not auto-atomic**; multi-step procs `RETURN -1` on `iierrornumber<>0` and rollback is the **caller's** responsibility. No `COMMIT`/`ROLLBACK` in proc bodies. [FACT - soa-switching-orders.md §10]
- `switemstatus` granular values (e.g. between 20 and 49) are not decoded by any single proc → a UI relying on a specific intra-band code has `[UNKNOWN]` ground truth here.

---

# CONSTRUCT 2 — JOB CLASS (the move TEMPLATE)

## 2.1 Purpose
A **Job Class** is the reusable **template defining a move**: its move rules, job checks, and job actions, for each OMS switching application. [FACT - ug.html:5128-5132]. Every job instance references a `jobclass`. The concrete taxonomy (the named classes/codes) is deferred by the guide to a separate "Job Class Maintenance User Guide" and lives in absent seed rows → **`[UNKNOWN]`.** [FACT - ug-vocab-outages.md §4]

## 2.2 Schema — `fms_jobclass` (7 cols, btree unique on `jobclass`) [FACT - d1.sql:3264-3294, re-read this pass]
```
jobclass    integer  not null            -- PK
movetype    char(4)  default ' '         -- 4-char operation code (e.g. 'Dead'); enum UNKNOWN
conditional integer  default 0
tomove      varchar(160) default ' '     -- TakeOut instruction-text template
tomoverules integer  default 0
rsmove      varchar(160) default ' '     -- Restore instruction-text template
rsmoverules integer  default 0
```
**No human-readable class-name column** — the label lives in the `udb_type` hierarchy (seed-dependent, `[UNKNOWN]`). [FACT - ug-vocab-outages.md §4]. Loader `row_estimate = 1202`. [FACT - d1.sql:3282 — loader estimate, NOT an actual count]

## 2.3 The job-class family — how a class drives card processing [FACT - d1.sql:3180-3453, re-read this pass]
The class is **multi-dimensional**: a job class behaves differently per equipment class, step pair, card type, and TO-vs-RS leg. The rule/check/action tables are all keyed on the same compound dimension:

| Table | Cols | Key dimensions | Role | row_estimate |
|---|---|---|---|---|
| `fms_jobclass` | 7 | `jobclass` | move-text + rules template | 1202 |
| `fms_jobaction` | 9 | `(jobclass, equipclass, steppair, typeofcard, tors, issuecompl, action, status, feederequip)` | **status-setting actions** fired when a move is issued/completed | 24676 |
| `fms_jobcheck` | 9 | `(jobclass, equipclass, steppair, typeofcard, tors, issuecompl, jobcheck, status, feederequip)` | **validation checks** (yellow-warning gating) | 24102 |
| `fms_jobclasscontrol` | 6 | `(jobclass, typeofcard, steppair, equipclass)` + `seq, preferredstep` | step-pair **sequencing/placement** of the class on the card | 6922 |
| `fms_jobclasslink` | 11 | source `(jobclass,typeofcard,steppair,equipclass,tors)` → link `(...)` + `seq` | **chains** one class's leg to another's (auto-generated companion moves) | 715 |
| `fms_jobobjective` | 3 | `(jobclass, objective, tors)` | class → Rapid-Restore objective per TO/RS leg | 85 |
| `fms_jobtoskill` | 2 | `(jobclass, skill)` | class → required operator skill group | 178 |

[FACT - d1.sql DDL keys verbatim]. `tors` = the TakeOut/Restore leg discriminator; `issuecompl` = the issue-vs-complete event; `action`/`jobcheck`/`status` are integer codes into the (absent-seed) type hierarchy. [INFERENCE - column semantics; ug.html:6122-6125 binds Object Statuses to "Job Checks and Actions"]

## 2.4 State machine
**None.** A job class is **static configuration data**, not a stateful entity. It has no status column and no lifecycle; it is read at move-build/issue/complete time to drive the *job's* state. [FACT - fms_jobclass DDL has no status/timestamp column]. The relevant state machine is the JOB's (§1.4).

## 2.5 Readers & writers
- **Writers:** maintained via the DBM admin tool + the separate Job Class Maintenance guide (out of artifact scope). The `fms_jobclass*` procs exist but are **stubs** (`fms_validatejobclass` = `as begin return; end`). [FACT - ug-vocab-outages.md §6 item 3]
- **Readers (runtime):** the move-build/issue/complete path reads `fms_jobclasscontrol` (placement), `fms_jobclass` (move text), `fms_jobcheck`/`fms_jobaction` (validation + status actions), `fms_jobtoskill` (skill gate), `fms_jobobjective` (Rapid Restore order decoration). The actual reader procs are client 4GL / stubbed → statement-level logic `[UNKNOWN]`. [INFERENCE - guide prose + stub procs]
- **Skill gate:** at Issue Moves and permit return, operator skill must match (`FMS_JobToSkill` vs `FMS_PersonToSkill`); mismatch → "The Operator is not qualified for this move." [FACT - ug.html:6209-6258]

## 2.6 Design rationale [INFERENCE]
Classes are a **data-driven rules engine**: rather than hardcode per-equipment switching procedures, the system expresses them as `(jobclass × equipclass × typeofcard × steppair × tors × issuecompl)` rows in jobaction/jobcheck (≈24k rows each per loader estimate). This lets non-programmers author switching rules in the DBM tool. `fms_jobclasslink` enables one move to auto-spawn companion moves (e.g. a ground move chained to an isolation move). The cost: the actual rule semantics are entirely in seed data + client 4GL, so they are **opaque in this artifact set.**

## 2.7 Failure modes [INFERENCE]
- A class with no matching `fms_jobclasscontrol` row for a given `(typeofcard, steppair, equipclass)` → move has no defined placement (build-time gap). [INFERENCE - key structure]
- `fms_jobclasslink` cycles or bad `seq` would mis-order auto-generated companion moves. [INFERENCE]
- Because `fms_jobclass.jobclass` carries no name and `action`/`jobcheck`/`status` are bare integers into absent seed rows, a corrupt or missing `udb_type` seed makes the entire rules layer uninterpretable. [INFERENCE]

---

# CONSTRUCT 3 — SWITCHING ORDER (card + jobs; and the IR electronic operating order)

## 3.1 Purpose
"Switching order" maps to **two different schema objects** [INFERENCE - ug-switching-lifecycle.md §11.6]:
- **(A) Operator-built order = a CARD + its ordered jobs(moves)** — `soa_card`/`fms_card`/`tc_card` + `soa_job`/`tc_job` via `*_jobcontrol`. [FACT]
- **(B) Electronic operating order = `ir_operatingorder`** — the issue/return wrapper downloaded to the field (Rapid Restore / SSO), the AUTOMATIC/substation path. [FACT - ir-orders-permits.md §3.1; ug-switching-lifecycle.md §7.2]

## 3.2 Schema — Card (`soa_card`, the generic container) [FACT - ug-switching-lifecycle.md §1.1, DDL read in full]
`card` (PK), `status integer`, `application varchar(10)` (FMS/SLC/TC/TFMS discriminator), `typeofcard`/`cardclass`/`cardclassname`, lifecycle timestamps `opened`/`activated`/`closed` + `cutout`/`cutin` (de-energize/energize) + `esttimecomplete`/`esttimeinservice`, `workpermitflag`, `validated`. Per-app twins add fields (`fms_card`: 47 cols incl. `feederstatus`, `stationground char(3)`, `groundson`, `tv_bogey`). [FACT - fms-field-mgmt.md §3]. **TC participates in the shared `soa_activecard` registry**, discriminated by `application char(4)`; any non-FMS active card flows into TFMS activation (`TFMS_NewCardActivated ... WHERE New.Application <> 'FMS'`, d1.sql:33358). [FACT - tc-jobs-cards.md §10]

## 3.3 Schema — `ir_operatingorder` (28 cols, btree on `substation` non-unique, identity `ordernumber`) [FACT - ir-orders-permits.md §3.1, DDL read in full]
`application char(4)`, `card`, `switchingitem`, `ordertarget char(4)`, `ordertype varchar(14)`, `orderstatus int`, `priority int` (proc forces `=100` on insert), plus timestamp/actor quads: issue (`issuedbydo`,`bydesk`,`issuetime`), `downloadtime`, ack/reject (`ackrejecttime`,`ackrejectbysso`,`ackrejectcomment`), return (`returntime`,`returnbysso`,`returncomment`), rescind quad, `msgkey`. Child: `ir_oporderjobs(job,seq,tors,ordernumber)`, `ir_opordersteps(ordernumber,seq,operatingstep,starttime,status)`, `ir_oporderfeeders.ispermit` (the only structural link to SOA in-service permits). [FACT - ir-orders-permits.md §2,§7]

## 3.4 State machine — Card status (per-app, divergent) [FACT - ug-switching-lifecycle.md §2]
- **SOA** (`SOA_CardStatusUpd`): `10`(built) → `20`(active, sets `Activated`) → `>=50`(closed, sets `Closed`). Active window `20..<50`. [FACT - body verbatim, d1.sql:30986]
- **FMS** (rules): `<20`(build) → `20`(active; `FMS_ActivateCardInserted`/`FMS_NewCardActivated`) → `50`(closed; `FMS_RemoveCardReport2 WHERE Status>=50`); FRA adds `55`(delete), `99`(terminal); `-1`=key-gen sentinel; `cardclass 10099`=special re-activation. [FACT - fms-field-mgmt.md §3; ug-switching-lifecycle.md §2.2]
- **TC** (`TC_CloseCard`): `status=4`=closed (also blanks `tc_job.status` to `'   '`). [FACT - d1.sql:31953; tc-jobs-cards.md §3]

## 3.5 State machine — `ir_operatingorder.orderstatus` (electronic order) [FACT/INFERENCE - ir-orders-permits.md §4.1; ug-switching-lifecycle.md §7.2]
Lifecycle stages proven by the writer procs (the integer `orderstatus` codes themselves are `[UNKNOWN]` — the only literal seen is column default `0`):
```mermaid
stateDiagram-v2
  direction LR
  [*] --> Inserted: IR_OperatingOrderIns (Priority=100 forced)
  Inserted --> StatusSet: IR_OrderStatusUpd (+IssueTime)
  StatusSet --> Downloaded: IR_DownloadTimeUpd (set DownloadTime)
  Downloaded --> AckRejected: IR_OpOrderAckRejUpd (by SSO)
  AckRejected --> Returned: IR_CompletedTimeUpd (ReturnBySSO)
  StatusSet --> Rescinded: IR_OpOrderRescindUpd (any point)
  Downloaded --> Rescinded
  Returned --> [*]
  Rescinded --> [*]
  note right of Downloaded
    Stage transitions = FACT (proc bodies).
    orderstatus integer codes = UNKNOWN (only default 0 seen).
    DO issues/rescinds; SSO acks/returns.
  end note
```

## 3.6 Readers & writers
- **Card:** `SOA_CardStatusUpd`, `SOA_CardUpd`, `FMS_CardStatusChange` (mirrors `fms_card.status`→`SOA_Card.status`, `RAISE ERROR -1` rolls back on failure — transactional coupling, d1.sql:28490), `TC_CloseCard`. Active-list materialization via `SOA_ActiveListInsert/Delete`/`SOA_ActiveLStatusChange` → all RAISE DBEVENT `SOA_ActiveListChange`. [FACT - fms-field-mgmt.md §7; soa-switching-orders.md §8]
- **Electronic order:** `IR_OperatingOrderIns`, `IR_OrderStatusUpd`, `IR_DownloadTimeUpd`, `IR_OpOrderAckRejUpd`, `IR_CompletedTimeUpd`, `IR_OpOrderRescindUpd`. [FACT - ir-orders-permits.md §4.1]
- **Events:** client-raised `active_order_change` (no server proc raises it; OpenROAD distributor); `soa_jobupdated`; IR `processing*`/`return*`/`*complete` triplet per channel. [FACT - soa-switching-orders.md §9; ir-orders-permits.md §8]

## 3.7 Design rationale & failure modes [INFERENCE unless cited]
The card-as-container + per-app twin pattern lets one switching framework serve feeders (FMS), substations/transmission (SOA/SLC/TFMS), and telephone circuits (TC) with shared sequencing, archive, and active-list machinery while specializing fields. The `ir_operatingorder` layer decouples *authoring* (SOA card) from *field issue/return* (IR), enabling electronic download to remote operators. **Failure modes:** card-status mirror (`FMS_CardStatusChange`) is transactionally coupled to SOA — a failed SOA_Card update rolls back the FMS card change. [FACT - d1.sql:28490]. Per-app status divergence (10/20/50 vs <20/20/50/55/99 vs 4) is a maintenance hazard: no unified status table, so cross-app status logic must special-case each. [FACT - contradiction, ug-switching-lifecycle.md §11.5]

---

# CONSTRUCT 4 — OUTAGE (planned & bus-fault/automatic)

## 4.1 Purpose
Two distinct outage modes with separate data paths. [FACT - soa-switching-orders.md §6; ug-vocab-outages.md §5]
- **Planned outage** = request-driven, scheduled, executed via moves/permits/orders.
- **Bus-fault / automatic (forced)** = event-driven from SCADA/relay operation, captured & correlated reactively.

## 4.2 Schema — Planned: `soa_outagerequest` (21 cols, btree unique on `ornumber`) [FACT - soa-switching-orders.md §7; ug-vocab-outages.md §5a]
`ornumber varchar(20)`, `title`, `ossstatus varchar(40)` (free external status from OSS), `currentstatus varchar(20)`, `status integer`, `jurisdiction varchar(20)`, and **four scheduled-vs-actual date pairs**: `skedoutagedate/actualoutagedate`, `skedstartdate/actualstartdate`, `skedreturndate/actualreturndate`, `skedinservicedate/actualinservicedate` (+ `actualworkissuedate`). Linked to permit jobs via `soa_outagerequestpermit(ornumber, workitem, permitjobid, workgroup)`. [FACT - DDL]. **Note two state fields**: `ossstatus` (external) AND `currentstatus`/`status` (internal). [FACT - ug-vocab-outages.md §5a verifier]

## 4.3 Schema — Bus-fault: `soa_busfaultoutage` (67 cols, btree unique on `switchingitem`) [FACT - soa-switching-orders.md §6, DDL-verified; **widest table in the DB**, next is fms_sesamelockcard at 65]
One wide row per bus-fault event = a denormalized **telemetry capture form**. Each protection element gets a quad of (flag, value/relayname, lastupd, lastupdby): bus differential (`bd*`), bus overcurrent (`boc*`), backup timer (`but*`), feeder target (`ft*`), closed feeder breaker (`clfdrbkr*`), visible-break fault (`vbf*`), power-quality nodes (`pq*`, `pqrms*`), front/back-bus MPR/LOR relays (`fbmpr/fblor/bbmpr/bblor`), manhole event (`mhevent`), vault-fault FOD (`vffod`), `correlationaction varchar(160)`, `importstatus`. Correlation lives in `soa_busfaultcorrelationmatrix`. [FACT - soa-switching-orders.md §6]

Forced-outage summary tables (cross-cutting): `soa_outagesummary(object, type, voltage, card, switchingitem, job, outagetype integer, outservicestart/end, latentflag integer, outagekey)`; `fms_bussectionoutage`, `fms_networkoutage`, `xa21_outagereport` (EMS/SCADA feed), `qgis_setoutage` proc (visual). [FACT - ug-vocab-outages.md §5b]

## 4.4 State machine — Planned outage request (`SOA_ORStatusUpd`) [FACT - soa-switching-orders.md §7, body verbatim]
`10`=IMPORTED (from OSS) → `20`=PERMIT (issued/linked) → `50`=CLOSED → `70`=RECALLED → `100`=ARCHIVED. Cascade delete via rule `SOA_OutageRequest$Del → SOA_ORCascadeDel`.

```mermaid
stateDiagram-v2
  direction LR
  [*] --> IMPORTED: Status=10 (OSS import)
  IMPORTED --> PERMIT: Status=20 (permit linked)
  PERMIT --> CLOSED: Status=50
  CLOSED --> ARCHIVED: Status=100
  IMPORTED --> RECALLED: Status=70
  PERMIT --> RECALLED
  RECALLED --> ARCHIVED
  ARCHIVED --> [*]
  note right of IMPORTED
    CurrentStatus labels + numeric codes = FACT (SOA_ORStatusUpd body).
    ossstatus (external OSS status) = separate free-text field, UNKNOWN domain.
  end note
```

## 4.5 State machine — Bus-fault outage (capture, not approval) [INFERENCE - soa-switching-orders.md §6]
No approval lifecycle. `SOA_BFIns(Substation, BusSection, SwitchingItem, CreationTime, CreatedByDO)` inserts the row with **all 22 flag/target columns = -1** (sentinel "unknown/not-yet-determined"); then 16 targeted `SOA_BF*Upd` procs each patch one protection-element group; `importstatus` tracks ingest. [FACT - SOA_BFIns body verbatim; 16 SOA_BF*Upd procs confirmed]. State = `importstatus` + per-element flags transitioning from `-1` to actual readings, NOT a status enum.

## 4.6 Planned vs bus-fault — discriminator
[INFERENCE - structural, soa-switching-orders.md §6; ug-vocab-outages.md §5b] `soa_outagesummary.outagetype integer` (+ likely `latentflag`) distinguishes planned from forced, but **the actual codes are `[UNKNOWN]`** (seed rows absent). The forced path is triggered by EMS/SCADA dbevents (`xa_busoutage`, `xa_tfmsoutage`, `xa21_*`, `rtu_*`); the **Outage Monitor** background process waits "Delay to Evaluate" seconds after a breaker operates, then runs a connectivity trace (Udb terminal/node OR QGIS model). [FACT - ug-vocab-outages.md §5b]

## 4.7 Readers/writers, rationale, failure modes
- **Planned writers:** `SOA_ORStatusUpd`, `SOA_ORPermitIns`, `SOA_ORCascadeDel`. **Bus-fault writers:** `SOA_BFIns`, 16× `SOA_BF*Upd`, `SOA_BFCMatrixIns/Del`. [FACT - soa-switching-orders.md §6,§7]
- **Rationale:** planned outages are a workflow (approval + scheduling), so they get a status state machine + sked/actual date pairs; bus faults are an *incident capture* (the operator doesn't pre-approve a fault), so they get a wide telemetry form + correlation matrix instead of a lifecycle. [INFERENCE]
- **Failure modes:** [INFERENCE] (a) bus-fault row left with `-1` sentinels if `SOA_BF*Upd` patches never arrive → correlation matrix can't recommend an action; (b) **Outage Monitor contradiction** — version history says the Udb-trace Outage Monitor was *disabled and rebuilt on QGIS*, yet timing-parameter docs still describe it as live; which path is authoritative now is `[UNKNOWN]`. [FACT - contradiction, ug-vocab-outages.md §5c]; (c) `ossstatus` (external) and internal `status` can drift out of sync (two independent state fields).

---

# CONSTRUCT 5 — SWITCHING STEP / CARD (StepPair)

## 5.1 Purpose & resolution of the card↔step relationship
**CONTRADICTION resolved:** the prompt's premise "is a card a switching step within a job?" is **inverted.** [FACT - tc-jobs-cards.md §0] The CARD is the parent container; the **STEP (StepPair) groups jobs(moves) on the card**; the JOB(move) is the unit; the step is the *layout grouping*. Hierarchy: **Card → StepPairs (ordered) → Jobs(moves), each move split TakeOut(left)/Restore(right).** [FACT - ug.html:6369-6371 "Step is often referred to as StepPair... TakeOut on the left... Restore on the right"; tc_job btree on `(card, seq, job)`]

## 5.2 Schema
- `fms_steppair(steppair, typeofcard, name)` — stores the step headings (card layout rows). [FACT - d1.sql:4646; ug-switching-lifecycle.md §1.3]. FMS cards are **preloaded** with all step headings at creation; SLC inserts a heading only when a move exists in that step. [FACT - ug.html:6392-6394]
- **Globally-fixed sequence:** the **Work Permits step = Sequence 600** (a global constant). [FACT - ug.html:6387]
- `soa_jobcontrol(card, job, switchingitem)` carries `steppair`/`steplevel`/`seq` ordering a job within its step. [FACT - soa-switching-orders.md §2]
- **Operating-step timing:** `fms_operatingstepstatus`/`tc_operatingstepstatus`/`*_archiveoperatingstep` track per-step `starttime`/`endtime`/`durationmins`. [FACT - fms-field-mgmt.md §2.1; tc-jobs-cards.md §2]

## 5.3 State machine — operating-step timing [FACT - rules; tc-jobs-cards.md §7; ug-switching-lifecycle.md §1.4]
Duration is rule-computed: `FMS_CalculateDuration`/`TC_CalculateDuration` AFTER UPDATE(EndTime) computes `EndTime - StartTime`. TC adds delay tracking: `TC_DelayCheck` (INSERT WHERE OperatingStep NOT IN (10147,10134)), `TC_DODelayAdj` (OperatingStep=10134, EndTime='' → DO-delay). The step **codes** `10134`/`10147` are observed in rules but their full enumeration is `[UNKNOWN]` (seed rows absent). [FACT - tc-jobs-cards.md §7]

## 5.4 Readers/writers, rationale, failure modes
- **Writers:** `SOA_DetermineSequence`/`SOA_ControlResequence` (server, place/reorder); `SOA_DetermineMoveSequence` (client 4GL, location `[UNKNOWN]`); `FMS_CalculateDuration`/`TC_CalculateDuration` (timing). [FACT - soa-switching-orders.md §2; ug-switching-lifecycle.md §0]
- **Rationale:** [INFERENCE] StepPairs impose a print layout and an execution order on an otherwise flat job set; the fixed Seq=600 Work-Permits step guarantees protection/permit moves land in a known place on every card. Preloading all step headings on FMS cards makes the feeder card a templated near-automatic switching script.
- **Failure modes:** [INFERENCE] a job with `seq=0` not picked up by `SOA_DetermineSequence` stays unsequenced; mis-set `preferredstep` in `fms_jobclasscontrol` mis-places a move; operating-step `EndTime` left null → no duration computed (open delay).

---

# CONSTRUCT 6 — IN-SERVICE PERMIT (ISP / ISWP)

## 6.1 Purpose
A permit to work on equipment **while the system is in service**, approved by Transmission Operator or District Operator. [FACT - ug.html:11556-11563]. Contrast OSWP (out-of-service): "Before a DO issues an OSWP, the DO has to switch on the electric system to take equipment out of service" — i.e. OSWP is preceded by isolation switching, ISWP is not. [FACT - ug.html:11651-11667]

## 6.2 Schema
Two coupled headers, same PK `ispermit` (hash): `soa_inservicepermit` (33 cols, the permit) + `soa_ispermitrequest` (37 cols, the request/hazard form: relaycalibration, lossofcontrol, ownisolation, liveconnections, asbestos, tripout...). Plus `soa_ispjob` (TO/RS operator+time), `soa_ispcondition`, `soa_isprestriction(+item)` (`handsoff`=hold flag, `lifttime`=release), `soa_isplog`, `soa_ispwithdrawevent/permit`, `soa_ispattachment/binaryfile`. [FACT - soa-switching-orders.md §5; ug-switching-lifecycle.md §4.2]. **OSWP note:** `soa_iswpequiptype` IS a real table (d1.sql:10069); **`soa_oswpequiptype` is NOT in d1.sql** — guide-prose only (a verified fabrication risk; in-schema status `[UNKNOWN]`). [FACT - ug-switching-lifecycle.md §11.10; ug-vocab-outages.md §6 item 1]

## 6.3 State machine — the MASTER DECODER `SOA_ISPStatusUpd` [FACT - soa-switching-orders.md §5a, body read line-by-line; the most fully-decoded enum in the system]
| Status | CurrentStatus | RequestStatus | Meaning |
|---|---|---|---|
| 1 | (request) | — | request created |
| 2 | REQUEST | REQUEST | submitted |
| 8 | (interim) | — | aging draft (auto-closed +4 days) |
| 10 | OPEN | — | opened |
| 15 | PENDTO | — | pending Transmission Operator |
| 20 | PENDSO | — | pending System Operator |
| 25 | DENIED | DENIED | denied |
| 30 | PEND | — | pending (reason) |
| 35 | A/COND | — | approved w/ conditions |
| 40 | APPRV | APPROVED* | approved (Request→APPROVED only if ObjectType 0 or 1) |
| 45 | ISSUED | — | issued |
| 50 | ISSUED | APPROVED | issued (approved) |
| 54 | PULLRQ | — | pull requested |
| 55 | PULLED | PULLED | pulled |
| 60 | COMPL | COMPL | returned complete |
| 65 | INCOMPL | INCOMPL | returned incomplete |
| 70 | LOCAL | LOCAL | under local authorization |
| 100 | (archived) | — | archived/closed (sets CloseTime) |

```mermaid
stateDiagram-v2
  direction LR
  [*] --> REQUEST: SOA_ISPRequestSubmit (2)
  REQUEST --> OPEN: 10
  OPEN --> PENDTO: 15
  PENDTO --> PENDSO: 20
  PENDSO --> APPRV: 40
  PENDSO --> ACOND: 35 (A/COND)
  REQUEST --> DENIED: 25
  APPRV --> ISSUED: 45/50
  ACOND --> ISSUED: 45/50
  ISSUED --> PULLED: 54->55
  ISSUED --> COMPL: 60
  ISSUED --> INCOMPL: 65
  ISSUED --> LOCAL: 70
  COMPL --> ARCHIVED: 100
  INCOMPL --> ARCHIVED
  PULLED --> ARCHIVED
  DENIED --> ARCHIVED
  ARCHIVED --> [*]
  note right of PENDTO
    ALL numeric codes + CurrentStatus labels = FACT (SOA_ISPStatusUpd, full 18-state decoder).
    This is the ONE fully-seeded-in-code enum.
    TO=Transmission Operator, SO=System Operator (dual jurisdiction).
  end note
```

## 6.4 Readers/writers
- **Decode/transition:** `SOA_ISPStatusUpd`. **Submit/reset:** `SOA_ISPRequestSubmit`, `SOA_ISPResetToRequest`. **Issue/complete/withdraw:** `SOA_IssueISP` (upserts `soa_ispjob` TO side), `SOA_CompleteISP` (RS side + ReturnStatus), `SOA_ISPWithdrawJob` (repoints underlying work permit: `Application='SLC'`→`SOA_WorkPermit.PermitJobID`, `'TLS'`→`TC_WorkPermit.PermitJobID`). **Auto-close sweep:** `SOA_ISPArchive` sets `Status=100, CloseTime` WHERE `Status IN (25,55,60,65,70) OR (Status=8 AND StatusTime <= now-'4 days')`; requests where `Status IN (1,2)` and `EnterTime <= now-'6 months'`. [FACT - soa-switching-orders.md §5, bodies verbatim]
- **Events:** `soa_loadisp`/`tc_loadisp`. [FACT - ug-switching-lifecycle.md §4.2]

## 6.5 Design rationale & failure modes
- **Rationale:** [FACT/INFERENCE] the 18-state machine encodes a real **dual-jurisdiction approval workflow** (Transmission Operator + System Operator both must clear) with conditional approval (A/COND), pull/recall (PULLRQ/PULLED), and complete/incomplete returns — regulatory rigor (NYISO/NYPA notification fields, compliance, denycategory). [FACT - soa-switching-orders.md §5; ir-orders-permits.md §7]
- **Failure modes:** [INFERENCE/FACT] (a) aging drafts (Status=8) auto-close after 4 days, abandoned requests (Status 1/2) after 6 months — silent expiry; (b) `SOA_ISPWithdrawJob` cross-module repoint (SLC vs TLS) is a fragile name/value join — wrong `Application` value repoints to the wrong permit table; (c) the `ObjectType 0/1` gate on Status=40 means some object types never reach RequestStatus=APPROVED (intentional but easy to misread). The ISP `jurisdiction='DO'` for specific ObjectTypes was **downgraded to `[UNKNOWN]`** by the SOA verifier (not re-read). [FACT - soa-switching-orders.md §5a verifier note]

---

# CONSTRUCT 7 — WORK PERMIT (FCR / out-of-service / per-module)

## 7.1 Purpose & the FOUR distinct permit flavors
"Work permit" is **module-specific**, NOT one entity. [FACT - ir-orders-permits.md §7; ug-switching-lifecycle.md §4.1]
- **`ir_workpermit`** (30 cols, btree unique on `workpermit`) — the **FCR (Field Crew Rep) work permit** issue/return transaction (feeder-level). [FACT - ir-orders-permits.md §3.2]
- **`soa_workpermit`** (17 cols, hash unique on `permitjobid`) — SLC work-permit detail (adds sequence, suspendedpermit, returnstatus, preissued, allrelaysnormal). [FACT - soa-switching-orders.md §1; ug-switching-lifecycle.md §4.1]
- **`fms_workpermit`** — FMS feeder permit (permitjobid, restoration, esttimecomplete, protectionrequired, acknowledgedbyfcr, acknowledgedtime, phasecheckindicator). [FACT - ug-switching-lifecycle.md §4.1]
- **`tc_workpermit`** (12 cols, hash unique on `permitjobid`) — TLS circuit permit; links `rtuworkissue`. [FACT - tc-jobs-cards.md §2]

These are **distinct layers, not duplicates** — SOA owns the in-service permit data model (regulatory), IR owns the issue/return transaction; they overlap only at `ispermit`/`job`/`permitjobid` join keys. [FACT - ir-orders-permits.md §7]

## 7.2 Schema — `ir_workpermit` (30 cols) [FACT - ir-orders-permits.md §3.2, DDL read in full]
`workpermit` (PK), `replacespermitid`/`revisionnumber`/`revisiondate` (revisioned), `targetfcr char(1)`/`doname`/`fcremployeeobjectid` (FCR ownership), return block (`returnedtime`, `backfromworkstatus char(3)`, `continuity char(3)`, `caution char(3)`, `urgentrestoration char(3)`), high-pot block (`highpottype char(8)`, `highpotkv`, `highpotduration`, `highpotauthorization`, `highpotwaivednyse`), equip dropped/picked descriptors, return-reject block (`returnrejecttime/do/reason`), `permitstatus int`, `protectionmovecount int`, `msgkey int`.

**Protection linkage:** `fms_workpermitprotection(permitcard, permitjobid, protectioncard, protectionjobid, seq, prepost)` ties a permit job to the protective (isolation/ground) jobs required before/after. [FACT - d1.sql:4956; ug-switching-lifecycle.md §4.1]. `SOA_JobStatusUpd Status='Del'` cascade-deletes these. [FACT]

## 7.3 State machine — `ir_workpermit.permitstatus` (request → issue → return) [FACT/INFERENCE - ir-orders-permits.md §4.2; ug-switching-lifecycle.md §4.3]
Only one literal code is proven: **`IR_ReturnWorkPermit` hardcodes `PermitStatus = 50` = returned.** All other `permitstatus`/`rfpstatus` codes are `[UNKNOWN]`. [FACT - d1.sql:30215]

```mermaid
stateDiagram-v2
  direction LR
  [*] --> RFP: IR_RFPIns (revisioned RFP)
  RFP --> Acknowledged: IR_AcknowledgeRFP (DO ack/reject/revise)
  Acknowledged --> Created: IR_NewFCRWorkPermit
  Created --> Issued: IR_IssueFCRWorkPermit (TargetFCR, ProtectionMoveCount)
  Issued --> LocationAcked: IR_WorkPermitAck (per-location, skip 'TAG LATER')
  LocationAcked --> Returned: IR_ReturnWorkPermit (permitstatus=50) + ReturnFCRWPLocation/Tags/Equip
  Returned --> Rejected: IR_RejectPermit (returns to issued)
  Rejected --> Issued
  Returned --> Completed: IR_CompletePermit (->SOA_Job) / IR_WorkPermitUpdate (->FMS_Workpermit)
  Completed --> [*]
  note right of Issued
    permitstatus=50 (Returned) = FACT (IR_ReturnWorkPermit body).
    All other permitstatus/rfpstatus codes = UNKNOWN (seed rows absent).
    'TAG LATER' bulk-ack skip = FACT.
  end note
```

## 7.4 Readers/writers
- **RFP:** `IR_RFPIns`, `IR_LinkRFPCard`, `IR_AcknowledgeRFP`. **Permit:** `IR_NewFCRWorkPermit`, `IR_IssueFCRWorkPermit`, `IR_IssuePermitMsgUpd`, `IR_WorkPermitAck`, `IR_ReturnWorkPermit`, `IR_ReturnFCRWPLocation/Tags/WorkEquip`, `IR_RejectPermit`, `IR_WorkPermitStatusUpd`, `IR_WPRevisionUpd`. **Cross-module:** `IR_CompletePermit`→`SOA_Job`; `IR_WorkPermitUpdate`→`FMS_Workpermit` (AcknowledgedByFCR/Time WHERE PermitJobID). **Cascade:** `IR_CascadeWPLocDel` (deletes tags then location; raises `IR_FCRDBEvent`). [FACT - ir-orders-permits.md §4.2,§8]
- **Protection trace at issue:** Feeder Diagram compares actual vs suggested protections; target ground = Green(OK)/Yellow(beyond Acceptable Protection Distance)/Red(Missing); DO alerted to red **when attempting to issue**. [FACT - ug.html:6627-6637]
- **Aging:** permit past ETC + `FMS ETC Deadband` → Task Monitor writes `itc_eetccard`, reddens button; past ETC by `FMS Inactivity OTW Alarm` days = "Aged". [FACT - ug.html:6508-6587]

## 7.5 Design rationale & failure modes
- **Rationale:** [INFERENCE] separating the SOA permit *data model* (regulatory record-of-record) from the IR *issue/return transaction* (field-facing state machine) lets the same permit be driven across feeder/in-service/circuit/field channels. Revisioning (`replacespermitid`/`revisionnumber`) supports re-issue without losing history. The protection-trace gate enforces safety (no issue on a red/missing-ground condition).
- **Failure modes:** [INFERENCE/FACT] (a) the `permitjobid`↔`job` join across modules is name/value-based with **no declared FK** (copy-loaded DB) — a stale `permitjobid` orphans the permit; (b) `IR_RejectPermit` resets `ir_downloadequip.ReturnPermit=0` — partial-return states possible; (c) `'TAG LATER'` locations skipped by bulk-ack can be silently left un-acked; (d) ETC/aging is timer-driven (Task Monitor) — if the monitor is down, no reddening/aging alerts fire.

---

# CONSTRUCT 8 — SESAME LOCK / CLEARANCE

## 8.1 Purpose
A **"sesame lock"** = an electronic/combination lock ("open sesame") applied to field equipment to enforce **clearance / lockout-tagout (LOTO)**. [INFERENCE - fms-field-mgmt.md §4]. The card is the **records-of-record data-entry artifact** capturing who locked what, with which lock/combo/serial, on which phase(s)/component(s), authorized by whom, and when. **NB:** the word "clearance" is NOT a defined vocabulary term in ug.html; OSWP/permit is the guide's nearest concept. [FACT - ug-vocab-outages.md §6 item 7]

## 8.2 Schema — `fms_sesamelockcard` (**65 cols**, btree unique on `(division, received, feeder, equip)`) [FACT - d1.sql:4384-4466, re-read & re-counted this pass]
> **CONTRADICTION (resolved):** `fms-field-mgmt.md §4` states **71 cols**; `soa-switching-orders.md` states **65** ("next is fms_sesamelockcard at 65"). **Direct DDL count this pass = 65 columns** (lines 4385-4449). The FMS doc's "71" is an **error**; 65 is authoritative. The 4-col unique key and "second-widest table" claim are correct.

Structure: provenance (`received` date, `division`, `feeder`, `equip`, `fdrandstruct`, `location`, `enteredby`, `bydo`, `installedby`, `installdate`, `supervisor`, `approvaldate`, `updatetime`, `processed`, `formid`, `formtype`); lock identity (`combono`, `serialno`, `lockno`, `sesamelock`, `unitlocked`, `switchlocked`, `camopslocked`, `dmbadging`); per-phase locks (`phasea/b/c` + `phase{a,b,c}serial` + `phase{a,b,c}lock`); equipment-type flags (`nwtrans`, `radial`, `reactor`, `groundsw`, `fdrandvault`, `neutralinstalled`, `anodesinstalled`); component-lock triples (serial/lock/combo) for `powersupply`, `handheld`, `scada`, `manual`, and three CAM units `cama/camb/camc`; ratings `kv`/`kva`/`kv2`; `remarks varchar(300)`. [FACT - DDL verbatim]. Loader `row_estimate = 6572`. [FACT - d1.sql:4458]

## 8.3 State machine — none (descriptive, NOT a live state machine) [FACT - fms-field-mgmt.md §4]
The only lifecycle bit is `processed integer` (0→1). No status enum, no transition procs.
```mermaid
stateDiagram-v2
  direction LR
  [*] --> Entered: FMS_SesameLockCardIns (FormType 0=full / else=component variant)
  Entered --> Processed: FMS_SesameLockCardUpd (Processed=1, set Equip/UpdateTime/ByDO)
  Processed --> Deleted: FMS_SesameLockCardDel (by FormID)
  Deleted --> [*]
  note right of Entered
    INSERT/UPDATE(processed 0->1)/DELETE only. No clearance state machine.
    Timestamp columns (received/installdate/approvaldate) imply received->installed->approved
    but NO transition procs enforce it (INFERENCE).
  end note
```

## 8.4 Readers/writers, rationale, CRITICAL failure mode
- **Writers:** `FMS_SesameLockCardIns` (branches on `FormType`: 0=full lock-card w/ phase+equip flags, else=component-lock variant), `FMS_SesameLockCardUpd` (Processed=1), `FMS_SesameLockCardDel`, `SetSesameLockCardFormID` (back-fills sequential FormID across all rows in a WHILE loop with **per-row COMMIT** — non-atomic batch). [FACT - fms-field-mgmt.md §4, bodies verbatim]
- **Rationale:** [INFERENCE] a flat wide form mirrors a physical paper LOTO card; per-phase and per-component lock triples capture the full make-safe state of one equipment in one row for audit.
- **CRITICAL failure mode / `[UNKNOWN]`:** **Clearance ENFORCEMENT is NOT visible** — no proc cross-checks `fms_sesamelockcard` before allowing a switching move. The card is **descriptive, not enforcing.** [FACT/INFERENCE - fms-field-mgmt.md §4,§10]. Operational lock-state that *gates* moves lives elsewhere (`udb_object.lockNumber`/`combination`, live `fms_objectstatus` grounds status 10016/10053). Whether ANY proc enforces a clearance before a move is `[UNKNOWN]` — none found. The `SetSesameLockCardFormID` per-row COMMIT means a crash mid-loop leaves FormIDs partially assigned (non-atomic). [FACT]

---

## 9. Cross-construct relationships (one-page map)

```
                         fms_jobclass (TEMPLATE, 7 cols)
                         + jobaction/jobcheck/jobclasscontrol/jobclasslink/jobobjective/jobtoskill
                                 │ drives (read at build/issue/complete)
                                 ▼
CARD (soa_card/fms_card/tc_card) ──contains──> StepPair (fms_steppair, Seq 600=permits)
   │  status: SOA 10/20/50 · FMS <20/20/50/55/99 · TC 4          │ orders
   │                                                              ▼
   │                                          JOB / MOVE (soa_job 31c / tc_job 37c)
   │                                          switemstatus <20/=20/20-49/>=50
   │                                          status char(3): ' '/NIS/Hid/Del/Xfr
   │                                          TO half ─── RS half (issue->complete each)
   │                                                 │
   ├──> ir_operatingorder (electronic order, issue->download->ack->return->rescind)
   ├──> WORK PERMIT (ir_workpermit 30c · soa_workpermit 17c · fms_workpermit · tc_workpermit)
   │       permitstatus=50=Returned; fms_workpermitprotection ties to isolation/ground jobs
   ├──> IN-SERVICE PERMIT (soa_inservicepermit 33c + soa_ispermitrequest 37c)
   │       SOA_ISPStatusUpd 18-state: REQUEST->PENDTO->PENDSO->APPRV->ISSUED->COMPL->100
   ├──> OUTAGE: planned soa_outagerequest (10/20/50/70/100) | bus-fault soa_busfaultoutage (67c, -1 sentinels)
   └──> SESAME LOCK (fms_sesamelockcard 65c, processed 0/1, DESCRIPTIVE not enforcing)
```

---

## 10. Consolidated `[UNKNOWN]` ledger (what absent seed data hides)
[FACT - all six docs, ground truth]
1. **All status/type/category enums** except code-literals: `soa_card.status` (per-app), `soa_job.status char(3)` (beyond `' '`/`NIS`/`Hid`/`Del`/`Xfr`), `soa_job.switemstatus` (intra-band), `movetype char(4)` (beyond `'Dead'`), `movecategory` (beyond 0-6), `ir_operatingorder.orderstatus` (only default 0 seen), `permitstatus`/`rfpstatus` (only 50=returned), `outagetype`/`latentflag`, operating-step codes (beyond 10134/10147), tag `tagtype`/`tagstatus`/`tagdisposition`.
2. **The job-class taxonomy** (concrete class names/codes/meanings) — deferred to absent "Job Class Maintenance User Guide"; `fms_jobclass` seed rows absent.
3. **`jobaction`/`jobcheck` semantics** — the integer `action`/`jobcheck`/`status` codes index absent `udb_type` seed rows.
4. **All TC server logic** — 127/127 TC procs are stubs; only rule guards + names recoverable.
5. **Move-sequencing/completion-check 4GL** (`SOA_DetermineMoveSequence`, `CheckDeloadComplete`) — absent from d1.sql AND both .dmt files; location `[UNKNOWN]`.
6. **Clearance enforcement** — no proc gates a move on `fms_sesamelockcard`; if enforcement exists it's in client 4GL or `udb_object` lock fields.
7. **Sesame-lock/tag/archive transition logic** — client-orchestrated; only storage tables + timestamp columns survive.
8. **Currently-live outage-detection path** — Udb-trace Outage Monitor "disabled and rebuilt on QGIS" vs still-documented timing params (unresolved contradiction).
9. **`soa_oswpequiptype`** — named in guide, absent from schema.

## 11. Surfaced contradictions
1. **Global stub count: 1,163 vs 1,225** across the verified docs (differ by 62; both ≈half of 2,450). [CONTRADICTION - source docs §0.7 above]
2. **`fms_sesamelockcard` col count: FMS doc says 71, SOA doc says 65; DDL = 65.** FMS doc is wrong. [CONTRADICTION resolved this pass, §8.2]
3. **Card↔step direction:** prompt premise (card = step within job) is inverted; correct is Card→StepPair→Job(move). [CONTRADICTION - §5.1, tc-jobs-cards.md §0]
4. **`fms_job` does not exist** despite the `fms_` prefix dominance; instance tables are `soa_job` + `tc_job` only; FMS owns the job CLASS library. [CONTRADICTION vs prompt premise - §0.4]
5. **Per-app status divergence** (SOA 10/20/50 vs FMS <20/20/50/55/99 vs TC 4) — no unified status table. [CONTRADICTION - §0.9, §3.4]
6. **"TLS" overloaded** — Telephone Lines (switching app, body) vs Transmission Line System (§3 TOC). [CONTRADICTION - ug-vocab-outages.md §1]

---

## Provenance
Source: the six verified analyses under `d:/103_RnD/psm_v1/analysis/verified/` plus direct re-reads of `d:/103_RnD/psm_v1/d1.sql` for the job-class family (3180-3453), `fms_sesamelockcard` (4384-4473, re-counted to 65 cols), and table-locations for `soa_busfaultoutage`/`soa_inservicepermit`/`fms_workpermitprotection`. Verifier-footer corrections from all six docs honored. `row_estimate` values are loader estimates, not actual row counts (no row data exists).
