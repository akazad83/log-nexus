export const meta = {
  name: 'udb-legacy-deepdive',
  description: 'Exhaustive deep-dive + SQL Server/.NET modernization assessment of legacy Ingres/OpenROAD UDB utility outage & switching-order system',
  phases: [
    { title: 'Deep Read' },
    { title: 'Verify' },
    { title: 'Synthesize' },
    { title: 'Modernize' },
    { title: 'Assemble' },
  ],
}

const BASE = 'd:/103_RnD/psm_v1'
const RAW = BASE + '/analysis/raw'
const VER = BASE + '/analysis/verified'
const SEC = BASE + '/analysis/sections'

const PERSONA = `You are a senior utility-systems data architect and SME (T&D operations, outage management systems, switching-order management) who ships production SQL Server/.NET and is fluent in Actian Ingres SQL and OpenROAD 4GL idioms.
RULES (non-negotiable): Brutally honest, terse, implementation-ready. No hedging, praise, filler, or restating the prompt. Evidence-bound: tag EVERY material claim [FACT - file->object], [INFERENCE - reasoning], or [UNKNOWN]. NEVER invent tables, columns, procedures, statuses, or workflow steps - if the artifacts don't show it, it's [UNKNOWN]. Surface contradictions between artifacts the moment you find them. Quantify wherever possible.`

const GROUND = `GROUND TRUTH (Phase 0, already computed - trust these, do not recompute):
- Artifacts in ${BASE}: d1.sql (33,392 lines - AUTHORITATIVE Ingres DDL/dump), psm.dmt (30,734 lines - OpenROAD frames/UI/menus), psm_4glprocs.dmt (8,496 lines - shared client 4GL procs), psm_dbprocs.dmt (632 bytes / 22 lines - a METADATA STUB that only includes core.plb; it contains NO procedure bodies), ug.html (12,878 lines - user guide / business semantics).
- d1.sql contains: 450 base tables; 2,450 database procedures (syntax: "create or replace procedure NAME ... as ..."); 290 Ingres rules ("create rule"); 208 Ingres dbevents ("create dbevent"); 1 view; 4,835 grants; 180 revokes; 450 "modify <t> to btree|isam|hash ... on ..." storage/index statements; 35 archive twin tables (<module>_archive*).
- CRITICAL CONSTRAINT: every table is loaded via "copy <t> () from '/home/ingres/Downloads/<t>.ingres'" - those external .ingres data files are NOT present. Therefore NO row data exists in the dump: no seed rows, no type/basetype/supertype catalog rows, no status-code enumerations, no row counts. Reconstruct all semantics from DDL STRUCTURE + procedure/rule/dbevent bodies + ug.html ONLY. Anything that would require the absent seed rows is [UNKNOWN] - say so explicitly; never fabricate a type list or status list.
- The REAL server-side business logic is the 2,450 procedures inside d1.sql (NOT psm_dbprocs.dmt).
- Core metamodel = udb_ family (53 tables). Big table: udb_object (30 columns; 20 sentinel-defaulted "default ' '"/"default 0", 9 nullable=dates/coords/source; PK=object). Type metamodel: udb_type(type,basetype,name,description), udb_supertype(type,supertype), udb_basetype(type,editorname,tablename), udb_extendedtype. udb_basetype.tablename names the per-type subtype table; udb_basetype.editorname names the OpenROAD editor frame.
- Module table counts: fms_ 114, soa_ 86, udb_ 53, ir_ 38, tc_ 33, cac_ 24, tfms_ 14, slc_ 11, pvl_ 10, fra_ 10, rtu_ 6, ddb_ 6, oa_ 5, csd_ 4, sds_ 3, qgis_ 3, msg_ 3, dso_ 3, plus singles incl GIS (nodes_xy, objects_xy, egis_ 2, qgis_ 3) and EMS/SCADA (xa21_ 1, rtu_ 6).
- Procedure counts by prefix (approx, case-combined): fms ~704, soa ~480, ir ~268, tc ~254, udb ~138, cac ~82, fra ~70, tfms ~62, slc ~58, dso ~52, pvl ~32.`

const EXTRACT = `HOW TO READ (the files are huge - DO NOT Read them whole). Use the Bash tool with grep/awk to extract only your slice:
- A table's DDL: awk '/^create table TBL\\(/{f=1} f{print} f&&/^\\)/{exit}' ${BASE}/d1.sql
- List a module's tables: grep -iE '^create table PFX_' ${BASE}/d1.sql
- A table's storage/index: grep -iE '^modify TBL ' ${BASE}/d1.sql
- A procedure body: awk '/create or replace procedure PROC/{f=1} f{print} f&&/^\\\\g/{exit}' ${BASE}/d1.sql  (proc bodies typically terminate at a line with \\g or the next "create or replace"; inspect a sample first to learn the delimiter).
- Find procs by topic: grep -inE 'create or replace procedure [a-z0-9_]*(KEYWORD)' ${BASE}/d1.sql
- Rules/dbevents: grep -inE '^create (rule|dbevent)' ${BASE}/d1.sql
- ug.html sections: grep -inE 'KEYWORD' ${BASE}/ug.html then Read targeted line ranges.
Verify object existence before asserting it. Read actual proc/rule bodies before describing logic - do not guess from names alone.`

const READER_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['key', 'headline', 'citedObjects', 'keyFindings', 'gaps'],
  properties: {
    key: { type: 'string' },
    headline: { type: 'string', description: '2-4 sentence dense summary of what this domain is and how it works' },
    tablesCovered: { type: 'integer' },
    procsExamined: { type: 'integer' },
    citedObjects: { type: 'array', items: { type: 'string' }, description: 'Up to 60 exact table/column/proc/rule/dbevent/frame names you ASSERT exist (favor any you are less than fully certain about) - used for fabrication audit' },
    keyFindings: { type: 'array', items: { type: 'string' }, description: 'Top 6-12 findings, each terse' },
    gaps: { type: 'array', items: { type: 'string' }, description: 'UNKNOWNs / data not present / contradictions found' },
  },
}

const VERIFY_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['key', 'verdict', 'fabricated', 'corrections'],
  properties: {
    key: { type: 'string' },
    verdict: { type: 'string', enum: ['clean', 'minor-issues', 'major-issues'] },
    confirmedCount: { type: 'integer' },
    fabricated: { type: 'array', items: { type: 'string' }, description: 'Cited objects that do NOT exist in the source files' },
    corrections: { type: 'array', items: { type: 'string' }, description: 'Specific factual corrections the synthesis MUST honor' },
    notes: { type: 'string' },
  },
}

// ---------- DOMAIN DEFINITIONS (deep readers) ----------
const DOMAINS = [
  {
    key: 'metamodel-core', group: 'metamodel', file: 'd1.sql',
    scope: 'The UDB metamodel CORE: udb_object (big table) + the type system tables udb_type, udb_supertype, udb_basetype, udb_extendedtype, udb_type-related control tables.',
    tasks: `Read full DDL of udb_object and every udb_*type table. Explain the single-table-inheritance-over-a-hand-rolled-metamodel design. Resolve precisely HOW "what is this object?" is answered: object.basetype/type -> udb_type -> udb_basetype.tablename (which per-type subtype table) + editorname (which OpenROAD frame). Explain udb_supertype as the class-hierarchy-as-data (edges). Characterize udb_object's 30 columns by role: identity/FK (object, source, systemversion, basetype, type, primarygrouping), DENORMALIZED name caches (typename, primarygroupingname), generic-overloaded identity (ownernumber, serialnumber, specnumber, combination, locknumber), lifecycle/state (status char(16), inservice, outservice, terminals), GIS coords (positionx/y f4), and 4 audit pairs (validated/by, locked/by, created/by, lastchanged/by). Quantify the sentinel-default pattern (20/30) and argue why sentinel defaults are WORSE than NULL for integrity (cannot distinguish unknown from blank/not-applicable). Note the data files are absent so the actual type catalog is [UNKNOWN] - but infer the type universe from the set of per-type subtype tables and from procs/rules that branch on type. Render a draft Mermaid classDiagram or erDiagram of the metamodel resolution path.`,
  },
  {
    key: 'metamodel-subtypes', group: 'metamodel', file: 'd1.sql',
    scope: 'UDB per-type SUBTYPE tables (equipment extension attributes), graph CONNECTIVITY tables, and REFERENCE/control tables.',
    tasks: `Enumerate and characterize the per-equipment subtype tables: udb_transformer, udb_switch, udb_capacitor, udb_conductor/udb_conductortype, udb_generator, udb_reactor, udb_winding, udb_telephonecircuit, udb_communicationlink, udb_combustionturbine, udb_hydroturbine, udb_steamturbine, udb_pwrsteamsupply, udb_fossilsteamsupply, udb_bwrsteamsupply, udb_consumer, udb_computer, udb_dsovalve, udb_grasscatcher, and any others. For each: row-key linkage back to udb_object (the 'object' FK), and 3-6 signature columns. CONNECTIVITY/GRAPH: udb_node, udb_terminal, udb_grouping, udb_groupinghistory, udb_groupingvalidation, udb_circuitroute - reconstruct the network graph model (objects connect via terminals to nodes; groupings = feeders/circuits). REFERENCE/CONTROL: udb_kvlevel, udb_rating, udb_measurementtype, udb_tapsetting, udb_loadcurve, udb_loadvalue, udb_telemetry, udb_scanblock, udb_location, udb_person, udb_problem, udb_systemparameters, udb_lastkey (key generation), udb_image, udb_bitmap, udb_export*, udb_temp$* (session temp). Confirm whether subtype tables = class-table inheritance (object split across udb_object + subtype) vs pure STI - this CORRECTS the prompt's 'one big table holds everything' hypothesis. Map the graph traversal path for network connectivity.`,
  },
  {
    key: 'schema-mechanics', group: 'schema', file: 'd1.sql',
    scope: 'Cross-cutting schema mechanics: storage/indexing, keys, declared-vs-app integrity, security/grants, archive/temporal pattern, concurrency, rules+dbevents.',
    tasks: `STORAGE/INDEX: from the 450 "modify <t> to <struct> ... on <cols>" lines, tally btree vs isam vs hash; identify primary key columns (the 'on' columns of unique structures) and any secondary indexes (modify ... to ... ; or separate index modifies). KEYS: is there a consistent surrogate-key pattern (udb_lastkey-driven 'object' ids)? INTEGRITY: DISAMBIGUATE - grep for actual "references"/"foreign key"/"check" CONSTRAINT clauses inside create-table bodies vs "grant references" (the 450 'references' hits are likely grants). State definitively whether DECLARED referential integrity exists; if absent, that proves integrity-in-code. SECURITY: characterize the 4,835 grants / 180 revokes (grant what, to whom - public? named roles?). TEMPORAL/AUDIT: explain the 35 <module>_archive twin tables (manual archival/soft-history) + the per-row audit columns (created/lastchanged/by) + any *audittrail tables - this is hand-rolled history. CONCURRENCY: the 8 'set lockmode' usages, optimistic-lock signals (systemversion column, locked/lockedby). RULES (290) + DBEVENTS (208): sample 8-10 rule bodies and classify (cascade, audit, denormalized-cache maintenance e.g. keeping typename in sync, validation); explain dbevents as the async pub/sub notification backbone for real-time automation. Quantify everything. Rank the resulting design-mechanics findings by severity.`,
  },
  {
    key: 'soa-switching-orders', group: 'subsystem', file: 'd1.sql',
    scope: 'SOA subsystem = Switching Order Application (86 tables, ~480 procs). The core of switching-order management.',
    tasks: `Enumerate soa_ tables (grep -iE '^create table soa_'). Deep-read schema of the central ones: soa_job, soa_busfaultoutage (73 cols - the largest table in the DB; characterize why), soa_inservicepermit, soa_ispermitrequest, soa_outageequiptype, soa_scenario*, soa_activeobject, soa_archivejob, soa_cfgequiptype, soa_connectivityprobequip, soa_hipottestequip, soa_iswpequiptype, soa_scenarioequip. Determine the SWITCHING ORDER data model: what is a "job" in SOA, its status/state column(s), and the permit constructs (in-service permit, in-service-work-permit request). Read 6-10 representative soa_ procs (look for state-transition verbs: approve, issue, activate, complete, restore, cancel, void) and quote 2-3 short excerpts proving the state machine. Identify the dbevent 'active_order_change' and related soa/order events and how they propagate. Map readers/writers and transaction boundaries. Distinguish PLANNED switching orders from BUS FAULT / automatic outage handling (soa_busfaultoutage). Derive the switching-order STATE SET from status columns + procs (label [INFERENCE] where the enum values themselves are in absent seed data).`,
  },
  {
    key: 'tc-jobs-cards', group: 'subsystem', file: 'd1.sql',
    scope: 'TC subsystem (33 tables, ~254 procs) - jobs, cards, trouble report orders.',
    tasks: `Enumerate tc_ tables. Deep-read tc_job (43 cols), tc_card (35 cols), tc_troublereportorder (36 cols), tc_archivejob/tc_archivecard and the archive pattern. Determine what TC is (trouble-call / trouble-order handling? job ticketing?) and how it relates to SOA and FMS. Clarify the JOB vs CARD distinction here - is a card a switching step / instruction within a job? Read 5-8 tc_ procs and quote the lifecycle. Map the troublereportorder -> job -> card chain if present. Bind to ug.html vocabulary where possible.`,
  },
  {
    key: 'fms-field-mgmt', group: 'subsystem', file: 'd1.sql',
    scope: 'FMS subsystem (114 tables - LARGEST; ~704 procs) - field/automation/dispatch + object status + clearance(sesame) locks.',
    tasks: `Enumerate fms_ tables. Deep-read fms_card (47), fms_sesamelockcard (71 - largest single equipment/lock table; characterize the clearance/tagging model), fms_job, fms_objectstatus / fms_objectstatusaudit / fms_objectstatusqueue (the real-time object STATUS state machine), fms_droppedequipjobs, fms_openautoequip, fms_phasecheckequip, fms_jobobjective. Determine FMS's role: it appears to be the real-time field-operations / automation / object-status engine. Map the fms_objectstatus state machine (status + queue + audit triple = event-sourced status?). Examine the fms_ dbevents (fms_automationgo, fms_automationstopped, fms_card_control_taken, fms_card_grounds, fms_card_request, fms_feeder_change, fms_faultcorrelation, fms_delaycleared, etc.) and explain the automation control loop. Explain "sesame lock" (hold/clearance/lockout-tagout) semantics from schema + procs. Read 6-10 fms_ procs; quote 2-3 excerpts. Map transaction boundaries and how FMS consumes/produces SOA orders and udb_object status.`,
  },
  {
    key: 'ir-orders-permits', group: 'subsystem', file: 'd1.sql',
    scope: 'IR subsystem (38 tables, ~268 procs) - operating orders, work permits, telephone (carrier) orders. Binds the Telephonic Line Systems domain.',
    tasks: `Enumerate ir_ tables. Deep-read ir_operatingorder (34), ir_workpermit (36), ir_telephoneorder (31), ir_returnrelay, ir_returnequipstatus, ir_workequipment, ir_rfpequipment, ir_downloadequip, ir_oporderobjectives. Determine IR's role (Information/Issue/Instruction Request? operating-order + work-permit lifecycle). Map the work-permit lifecycle (request -> issue -> return) and operating-order lifecycle. ir_telephoneorder + relay return = the TELEPHONIC LINE SYSTEMS / leased-carrier (Verizon) circuit handling - bind to udb_telephonecircuit and rtu_ tables. Read 5-8 ir_ procs; quote lifecycle excerpts. Relate IR permits to SOA in-service permits (overlap? different layer?).`,
  },
  {
    key: 'peripheral-modules', group: 'subsystem', file: 'd1.sql',
    scope: 'All remaining modules + INTEGRATION surfaces. Breadth over depth: one-liner per table family, deep only on integration tables.',
    tasks: `One-line purpose for each family: cac_ (24), tfms_/tfmsddb_ (16), slc_/slcddb_ (13), pvl_ (10), fra_ (10 incl fra_relay), dso_ (3, dso_object - a SECOND object model?), rtu_ (6), csd_ (4), sds_ (3), msg_ (3), oa_ (5), tm_ (2), itc_ (2), gta_ (2), tv_ (1), soo_ (1), nwp_ (1), cfg_ (1), allapp_ (1), xa21_ (1). FLAG and deep-read INTEGRATION tables: GIS/Esri (qgis_*, egis_*, nodes_xy, objects_xy - coordinate/geometry sync); SCADA/EMS (xa21_* - XA/21 is a GE/ABB EMS; rtu_*, udb_telemetry, udb_scanblock - real-time measurement ingest); REPLICATION/distribution (ddb_, fmsddb_, tcddb_, slcddb_, tfmsddb_ - the *ddb* families look like a distributed-DB / replication or message-spooling layer; confirm from DDL/dbevents like ddb_commit_failure, ddb_reconnect). Identify dso_object: is it a parallel/derived object store (Distribution System Operator view)? Produce an INTEGRATION SURFACE inventory: each external system, the tables/events bridging to it, and the sync direction if inferable.`,
  },
  {
    key: 'dbproc-logic', group: 'subsystem', file: 'd1.sql',
    scope: 'Macro-analysis of the 2,450 database procedures - where business logic lives, patterns, transactions, error handling.',
    tasks: `First, learn the proc body delimiter by reading one full proc. Classify the 2,450 procs by prefix AND by verb (get/select, insert/add/create, update/set, delete/remove, validate/check, calc, status/state-transition, notify/raise-event). Quantify the distribution. Identify WHERE business logic concentrates (which modules have the most/largest procs). Read and QUOTE SHORT EXCERPTS (5-15 lines each) of 5-7 representative high-value procs: (a) one that creates a udb_object and resolves type->subtype table (proves the metamodel insert path), (b) a SOA switching-order state-transition proc, (c) an FMS object-status update proc that raises a dbevent, (d) a validation proc that enforces an integrity rule the schema does NOT (proves integrity-in-code), (e) a key-generation proc using udb_lastkey. Document the transaction pattern (explicit commit/rollback? raise dbevent inside txn?), the error-handling idiom (iierrornumber, raise error, return codes), and message/notification idiom. Estimate total procedural LOC. Assess maintainability (duplication, naming discipline, length).`,
  },
  {
    key: 'ug-vocab-outages', group: 'business', file: 'ug.html',
    scope: 'User guide: domain vocabulary, job / job class definitions, planned vs automatic (forced) outage handling.',
    tasks: `Skim ug.html structure (grep headings: <h1>..<h4>, <title>, table-of-contents). Extract: (1) the controlled VOCABULARY/glossary - job, job class, switching order, outage (planned vs automatic/forced), permit, clearance, feeder, grouping, terminal, node, object, relay, etc. - with the guide's definitions. (2) The OPERATING DOMAINS as the guide frames them (transmission, substation, distribution, telephonic). (3) ROLES/actors (operator, dispatcher, switchman, approver...). (4) JOB CLASS taxonomy - what job classes exist and what each means. (5) PLANNED outage workflow steps and AUTOMATIC/forced outage workflow steps, as narrated. Bind each named concept to the schema tables/procs found by other agents WHERE the name maps (e.g., guide 'job' -> soa_job/tc_job/fms_job - note the THREE job tables and reconcile which the guide means). Flag every place the guide's described model CONTRADICTS the schema. Quote short guide passages as evidence with their context.`,
  },
  {
    key: 'ug-switching-lifecycle', group: 'business', file: 'ug.html',
    scope: 'User guide: the switching-order lifecycle, permits, clearances/tagging, isolation->make-safe->repair->restore->energize sequence.',
    tasks: `From ug.html derive the ACTUAL switching-order lifecycle STATES and transitions as documented (do not invent - quote the guide). Document: order creation/build, review/approval, issue, execution/step-by-step switching, in-service permit vs work permit vs request-for-permit, sesame lock / clearance / hold / tag application and removal, grounds application, restoration and de-energize/energize, completion/archival. Document PLANNED vs AUTOMATIC(forced) divergence in the lifecycle. Document the SWITCHING STEP / CARD model (each step = a discrete operate/tag instruction on an object). Bind each lifecycle stage to its tables/procs/frames (cross-reference SOA/FMS/IR/TC findings). Produce a state list suitable for a Mermaid stateDiagram. Explicitly call out any lifecycle detail that is [UNKNOWN] because it depends on absent seed/enum data, and any guide-vs-schema contradiction.`,
  },
  {
    key: 'ui-frames-4gl', group: 'ui', file: 'psm.dmt',
    scope: 'OpenROAD application: frames/menus (psm.dmt) + shared 4GL procs (psm_4glprocs.dmt). Where business rules live: client vs server.',
    tasks: `From psm.dmt: extract the application/menu/frame structure - top-level menus, major frames, and how navigation maps to subsystems (UDB editor, SOA switching, FMS, IR, TC). Identify the per-type EDITOR FRAMES referenced by udb_basetype.editorname (the frames that edit each equipment type). Count frames, menus, fields, procedures. From psm_4glprocs.dmt: characterize the ~335 shared 4GL procedures and the heavy use of Globals (3,799 Global refs) - what shared client-side state/logic exists. From psm_dbprocs.dmt: CONFIRM it is a 22-line stub with no bodies (only includes core.plb) - so client-side 4GL + server dbprocs in d1.sql are the two real logic tiers. ASSESS the split: how much business logic is in client 4GL frames/procs vs server dbprocs vs rules? This drives migration risk (client logic must be re-homed). Identify any logic that exists ONLY client-side (a modernization hazard). Quote 2-3 short 4GL excerpts.`,
  },
]

// ---------- STAGE 1+2: deep read -> verify (pipeline, no barrier) ----------
phase('Deep Read')
const readPrompt = (d) => `${PERSONA}

${GROUND}

YOUR DOMAIN: ${d.key} (group: ${d.group}). Primary file: ${BASE}/${d.file}.
SCOPE: ${d.scope}
TASKS: ${d.tasks}

${EXTRACT}

DELIVERABLE: Write a thorough, terse, evidence-tagged markdown analysis to ${RAW}/${d.key}.md. Use tables for catalogs, short DDL/proc/guide excerpts only where they prove a point, and include any Mermaid you were asked for. This is raw analysis for downstream synthesis - be COMPLETE and PRECISE, every claim tagged, every object name exact. Then return the JSON summary. citedObjects must list the exact names you assert exist (for fabrication audit).`

const verifyPrompt = (d, reader) => `${PERSONA}

You are the ADVERSARIAL VERIFIER for domain "${d.key}". A prior analyst wrote ${RAW}/${d.key}.md and claims these objects exist: ${JSON.stringify((reader && reader.citedObjects) || [])}.
Their stated gaps: ${JSON.stringify((reader && reader.gaps) || [])}.

YOUR JOB - default to skepticism:
1) For each cited object, confirm it EXISTS in ${BASE}/${d.file} (or other artifacts) via grep/awk. List any that do NOT exist as fabricated.
2) Spot-check the 3-4 most load-bearing CLAIMS in the file by reading the actual DDL/proc/guide text. Catch: wrong column names, invented status values, claims that need the absent seed data but are stated as FACT, name/schema mismatches, and any proc behavior described without reading the body.
3) Read ${RAW}/${d.key}.md fully. Produce a CORRECTED, verification-stamped version and write it to ${VER}/${d.key}.md: keep all correct content verbatim, fix errors inline (mark fixes), append a "## Verification" footer listing what was confirmed, what was corrected, and residual UNKNOWNs. Preserve all evidence tags and Mermaid.
Use ${EXTRACT}
Then return the JSON verdict.`

const readers = await pipeline(
  DOMAINS,
  (d) => agent(readPrompt(d), { label: `read:${d.key}`, phase: 'Deep Read', agentType: 'general-purpose', schema: READER_SCHEMA }),
  (reader, d) => agent(verifyPrompt(d, reader), { label: `verify:${d.key}`, phase: 'Verify', agentType: 'general-purpose', schema: VERIFY_SCHEMA })
    .then(v => ({ key: d.key, group: d.group, reader, verify: v }))
)
const ok = readers.filter(Boolean)
log(`Deep read + verify complete: ${ok.length}/${DOMAINS.length} domains. Verdicts: ${ok.map(r => r.key + '=' + (r.verify ? r.verify.verdict : '?')).join(', ')}`)
const fab = ok.flatMap(r => (r.verify && r.verify.fabricated) || [])
if (fab.length) log(`Fabrication flags caught (${fab.length}): ${fab.slice(0, 20).join(', ')}`)

// ---------- STAGE 3: synthesis wave 1 (parallel barrier) ----------
phase('Synthesize')
const verifiedList = DOMAINS.map(d => `${VER}/${d.key}.md`).join(', ')
const synBase = `${PERSONA}\n\n${GROUND}\n\nAll verified domain analyses are on disk in ${VER}/ : ${verifiedList}. READ the ones relevant to your section (use Read/grep). Honor every correction in their "## Verification" footers. Quantify. Tag claims. Surface contradictions.`

const wave1 = await parallel([
  () => agent(`${synBase}

SECTION: Phase 1 - Metamodel Reconstruction + Deliverable 1 (metamodel & integrity portion).
Read ${VER}/metamodel-core.md, ${VER}/metamodel-subtypes.md, ${VER}/schema-mechanics.md.
Produce a definitive reconstruction of the implicit class hierarchy and object-resolution mechanism. Resolve the STI-vs-class-table question precisely (udb_object root + per-type subtype tables = which inheritance pattern, exactly). Render TWO Mermaid diagrams: (1) the metamodel resolution path (udb_object -> type/basetype -> subtype table + editor frame), (2) the equipment class hierarchy as implied by subtype tables + udb_supertype + operating domains (transmission/substation/distribution/telephonic). Include the integrity model: declared (schema) vs enforced (code) with the verified facts on FKs/rules/grants. Write to ${SEC}/10-metamodel.md and return a 3-sentence summary.`,
    { label: 'syn:metamodel', phase: 'Synthesize', agentType: 'general-purpose' }),

  () => agent(`${synBase}

SECTION: Phase 2 - Schema Mechanics + Deliverable 1 (design-quality findings, ranked).
Read ${VER}/schema-mechanics.md plus skim ${VER}/metamodel-core.md, ${VER}/dbproc-logic.md.
Produce: storage/index summary (btree/isam/hash tallies, key strategy), declared-vs-app integrity verdict, security/grant model, archive/temporal/audit pattern, concurrency model, sentinel/overload bloat quantified, naming conventions, rules+dbevents role. Then a DESIGN-QUALITY FINDINGS table: each finding = evidence -> severity (Critical/High/Med/Low) -> impact, ranked by severity. Write to ${SEC}/20-schema-mechanics.md and return a 3-sentence summary.`,
    { label: 'syn:schema', phase: 'Synthesize', agentType: 'general-purpose' }),

  () => agent(`${synBase}

SECTION: Phase 3 - Application Logic + Phase 4 - Business Model (combined data+code+UI+guide).
Read ${VER}/soa-switching-orders.md, ${VER}/tc-jobs-cards.md, ${VER}/fms-field-mgmt.md, ${VER}/ir-orders-permits.md, ${VER}/dbproc-logic.md, ${VER}/ui-frames-4gl.md, ${VER}/ug-vocab-outages.md, ${VER}/ug-switching-lifecycle.md, ${VER}/peripheral-modules.md.
Produce: (a) WHERE business rules live (dbprocs vs rules vs client 4GL vs frames) with proportions. (b) End-to-end map of the JOB / JOB CLASS / SWITCHING ORDER / OUTAGE subsystems across data+code+UI, including transaction boundaries and the FMS/SOA/IR/TC division of labor. (c) Reconstructed OPERATIONAL WORKFLOWS: planned vs automatic outage handling, each step bound to its tables/procs/frames. (d) Every guide-vs-schema CONTRADICTION found. Reconcile the THREE job tables (soa_job/tc_job/fms_job). Write to ${SEC}/30-applogic-business.md and return a 3-sentence summary.`,
    { label: 'syn:applogic', phase: 'Synthesize', agentType: 'general-purpose' }),

  () => agent(`${synBase}

SECTION: Deliverable 3 - Critical components deep-dive: JOB & JOB CLASS (plus peer constructs: outage, switching order, switching step/card, permit, sesame lock).
Read ${VER}/soa-switching-orders.md, ${VER}/fms-field-mgmt.md, ${VER}/tc-jobs-cards.md, ${VER}/ir-orders-permits.md, ${VER}/ug-switching-lifecycle.md, ${VER}/ug-vocab-outages.md.
For EACH construct (job, job class, switching order, outage [planned & bus-fault/automatic], switching step/card, in-service permit, work permit, sesame lock/clearance): purpose; schema (key tables+columns); state machine/lifecycle (Mermaid stateDiagram where states are derivable, with [INFERENCE]/[UNKNOWN] tags where enum values are in absent seed data); readers & writers (procs/events); design rationale; failure modes. Write to ${SEC}/d3-job-deepdive.md and return a 3-sentence summary.`,
    { label: 'syn:jobclass', phase: 'Synthesize', agentType: 'general-purpose' }),
])
log('Synthesis wave 1 done (metamodel, schema, applogic+business, job deep-dive).')

// ---------- STAGE 3b: synthesis wave 2 - "How UDB works" (needs wave1 sections) ----------
const wave2 = await parallel([
  () => agent(`${synBase}

SECTION: Phase 5 - Synthesis "How UDB works" (Deliverable 2).
Read the wave-1 sections: ${SEC}/10-metamodel.md, ${SEC}/20-schema-mechanics.md, ${SEC}/30-applogic-business.md, ${SEC}/d3-job-deepdive.md (and any ${VER}/*.md you need).
Produce ONE coherent narrative unifying object resolution, network-graph traversal (node/terminal/grouping), and the LIFECYCLE OF ONE REPRESENTATIVE SWITCHING ORDER from creation to restoration - naming the exact tables/procs/events/frames touched at each step. Include a Mermaid sequenceDiagram of that switching order (operator/frame -> dbproc -> udb_object/soa_*/fms_* -> dbevent -> automation). Terse, dense, no fluff. Write to ${SEC}/50-how-udb-works.md and return a 3-sentence summary.`,
    { label: 'syn:howitworks', phase: 'Synthesize', agentType: 'general-purpose' }),
])
log('Synthesis wave 2 done (how UDB works).')

// ---------- STAGE 4: modernization (needs all sections) ----------
phase('Modernize')
await agent(`${PERSONA}

Modernization target: SQL Server 2025 + .NET 9/10, on-premises, regulated OT/IT (NERC-CIP-adjacent), 24/7 grid-critical. Data stays in-enterprise; internal integrations (GIS/Esri, SCADA/EMS, planning) are first-class design constraints. ${GROUND}

Read ALL synthesis sections: ${SEC}/10-metamodel.md, ${SEC}/20-schema-mechanics.md, ${SEC}/30-applogic-business.md, ${SEC}/d3-job-deepdive.md, ${SEC}/50-how-udb-works.md (and ${VER}/*.md as needed).

Produce Deliverable 4 - Modernization & optimization assessment:
1) TARGET DATA-MODEL OPTIONS: keep STI vs per-type subtype tables vs hybrid; evaluate SQL Server 2025 graph tables (for node/terminal/grouping connectivity), temporal tables (replace the 35 archive twins + audit columns), and Ledger tables (for tamper-evident switching-order/clearance audit in a regulated setting). JUDGE EACH against the 24/7 schema-stability requirement that made UDB attractive (new equipment type = data row, not DDL migration) - this is the central tension; address it head-on (e.g., metadata-driven subtype + sparse columns/JSON vs rigid per-type tables).
2) CRITICAL DB OPTIMIZATIONS: manageability, usability, self-documenting schema, query performance, integrity-in-schema vs integrity-in-code (move the 2,450-proc integrity into constraints/CHECK/FK/computed columns where safe).
3) INTEGRATION ARCHITECTURE: anti-corruption boundaries for GIS/Esri, SCADA/EMS (xa21/rtu/telemetry), planning; benchmark vocabulary against IEC CIM (61970/61968) as a REFERENCE only - do NOT propose CIM-as-storage; map UDB types to CIM classes where useful.
4) MIGRATION SEQUENCING: first / next / defer, with per-step risk; strangler-fig vs big-bang; how to carry the absent .ingres data and re-home client-side 4GL logic.
Every recommendation: problem -> evidence (cite the verified findings) -> proposed change -> benefit -> risk & effort (S/M/L). Rank recommendations by value vs effort. Write to ${SEC}/60-modernization.md and return a 4-sentence summary.`,
    { label: 'syn:modernization', phase: 'Modernize', agentType: 'general-purpose' })
log('Modernization section done.')

// ---------- STAGE 5: assemble final report ----------
phase('Assemble')
const finalPath = `${BASE}/analysis/UDB_Deep_Dive_and_Modernization.md`
const assembled = await agent(`${PERSONA}

You are the REPORT ASSEMBLER. Combine the section files into ONE coherent, single markdown report and write it to ${finalPath}.
Section files (read all): ${SEC}/10-metamodel.md, ${SEC}/20-schema-mechanics.md, ${SEC}/30-applogic-business.md, ${SEC}/d3-job-deepdive.md, ${SEC}/50-how-udb-works.md, ${SEC}/60-modernization.md.

REPORT STRUCTURE (headings mirror the method's Phases 0-6 and Deliverables 1-4):
- Title + 1-paragraph orientation.
- Phase 0 - Inventory: a tight catalog using the GROUND TRUTH counts below (artifacts table; module table-count table; object-type counts: 450 tables / 2,450 procs / 290 rules / 208 dbevents / 1 view / 4,835 grants / 35 archive twins). State the SAMPLING/COVERAGE caveat prominently: the external .ingres DATA FILES ARE ABSENT, so no seed rows / type catalogs / status enums / row counts were analyzable; psm_dbprocs.dmt is a stub; all semantics derived from DDL+proc/rule/dbevent bodies+ug.html. Name exactly what was and was not analyzed.
- Deliverable 1 (Phases 1-2): comprehensive database analysis = metamodel reconstruction (with Mermaid), integrity model, schema mechanics, dominant access patterns, design-quality findings ranked by severity. Pull from sections 10 & 20.
- Phase 3-4 / business: application-logic + operational workflows (pull from section 30).
- Deliverable 2 (Phase 5): "How UDB works" (pull from section 50).
- Deliverable 3: job & job-class deep-dive (pull from section d3).
- Deliverable 4 (Phase 6): modernization & optimization (pull from section 60).
RULES: Preserve all Mermaid diagrams, evidence tags, and severity/effort rankings. Keep it TERSE and dense - cut redundancy across sections, do not pad. Fix any cross-section inconsistency you notice (prefer the more evidence-backed claim). Do not drop quantification. Produce a clickable table of contents at the top.

GROUND TRUTH for Phase 0:
${GROUND}

After writing, return: the absolute report path, a markdown table of contents (section headings), the total word count, and the count of Critical+High severity findings.`,
    { label: 'assemble:report', phase: 'Assemble', agentType: 'general-purpose' })

return {
  reportPath: finalPath,
  assemblerSummary: assembled,
  domains: ok.map(r => ({ key: r.key, verdict: r.verify && r.verify.verdict, fabricated: (r.verify && r.verify.fabricated) || [] })),
  fabricationFlags: fab,
}
