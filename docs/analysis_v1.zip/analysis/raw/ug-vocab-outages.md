# ug-vocab-outages — Domain Vocabulary, Job/Job-Class, Planned vs Automatic Outage Handling

Primary source: `d:/103_RnD/psm_v1/ug.html` (12,878 lines). Schema cross-checks: `d:/103_RnD/psm_v1/d1.sql`.
Cleaned plaintext working copy generated at `d:/103_RnD/psm_v1/analysis/raw/_ug_clean.txt` (sed-stripped HTML; line numbers below cite THIS clean file unless noted).

## 0. What this guide actually is (scope correction — read first)

[FACT - ug.html title block L2693-2730] The document is **"Con Edison OMS Application Database Maintenance (Feedercard DBM) User Guide, February 2020"**. It is an **administrator/data-maintenance** guide for the DBM (Feedercard DBM) tool, NOT an operations/switching narrative.

[FACT - _ug_clean.txt:5028-5035] "(FeederCard_DBM) supports all administrative data entry functions that control OMS applications. This User Guide describes the purpose of each button on the DBM Menu and how the data behind the button is used by the OMS applications."

[INFERENCE] Consequence for this task: the guide gives **definitions and the data-model bindings** for the controlled vocabulary, but it **explicitly defers the operational workflows** (issue/return/complete moves, switching-order execution, job-class detail) to OTHER guides it names but that are NOT in our artifact set:
- [FACT - L5135] "There is a stand-alone **Job Class Maintenance User Guide** that describes how to maintain Job Class information." → job-class taxonomy detail is OUT OF SCOPE of ug.html.
- [FACT - L5103-5110] "There is a hardcopy User Guide provided by the original vendor that describes how to use the Udb / PSDM screens… Documentation for **Udb Access is outside the scope** of this User Guide."
- [FACT - L11700] "**SOA User Guide Section 8.9.4** describes the end-user aspect for how Return Phases works." [FACT - L10492, L10525] "**SOA User Guide section 5.12** provides detail definitions for Relay Classes and Relay Types."

[INFERENCE] So ug.html is the wrong primary source for a *narrated* planned-vs-forced outage workflow; the genuine workflow lives in SOA/Job-Class guides not provided. What ug.html DOES give, and what is extracted below, is: the vocabulary with definitions, the operating-domain framing, the role list, and the schema bindings — all of which reconcile cleanly with d1.sql.

## 1. Operating domains (as the guide frames them)

[FACT - _ug_clean.txt:5064-5072] Verbatim: "There are five switching applications that use DBM. 1) **FMS - Distribution Feeders**, 2) **TOMS (or SOA)** — for **Substations SLC and Transmission Feeders TFMS**, and 3) **TLS - Telephone Lines** use the 'FMS' database. 4) **SMS - Steam Management System**, uses the standalone 'SDS' database. 5) **DSO - Dielectric Switching Operations**, uses the standalone 'DSO' database. DSO has a separate DBM image called DSO_DBM…"

| App (guide) | Operating domain | Object type handled | Backing DB (guide) | Schema prefix [INFERENCE from d1.sql counts] |
|---|---|---|---|---|
| **FMS** | Distribution feeders | Distribution Feeder | "FMS" database | `fms_` (114 tbl, ~704 proc) |
| **TOMS / SOA** | Substations (SLC) + Transmission Feeders (TFMS) | Substation; Transmission Feeder (Line) | "FMS" database | `soa_` (86), `slc_` (11), `tfms_` (14) |
| **TLS** | Telephone lines/circuits | Telephone Circuit | "FMS" database | `tc_` (33) [INFERENCE: tc_=Telephone Circuit] |
| **SMS** (Steam) | Steam | (steam stations) | standalone "SDS" | `sds_` (3) |
| **DSO** | Dielectric switching operations | (cable/dielectric) | standalone "DSO" | `dso_` (3) |

[FACT - L5786-5789] The four card/incident object types the guide enumerates: "the type of object, **Distribution Feeder, Transmission Feeder (Line), Substation, or Telephone Circuit**." → these four are the canonical OMS object domains; Steam/DSO are in separate databases.

[FACT - L6066-6068, L6072-6073] "Two Operator Confirm logic is not developed for TLS and should not be used in DSO or SMS which are **in separate databases from the OMS applications**." → confirms DSO/SMS are out-of-band; FMS/SLC/TFMS/TLS are the in-database OMS core.

[CONTRADICTION — terminology] The TOC headings name the substation/transmission tabs **"TLS Menu"** (transmission, §3) and **"TOMS Menu"** (§4), but the body L5065 says **TLS = Telephone Lines**. Resolution [INFERENCE]: "TLS" is overloaded — §3 "TLS Menu" headings cover **Transmission Line** items (Circuit Documents, Substations Supported by PST, TLS/Verizon line conversion), while body prose uses "TLS" for the **Telephone Line** switching application. The guide is internally inconsistent on the "TLS" acronym; treat §3 as Transmission-Line-System and the body "TLS=Telephone Lines" as the switching-app name. Downstream synthesis must not merge these.

### Connectivity model split (relevant to outage detection)
[FACT - L6877-6881] "The Equipment Terminal Mismatch validation… is only useful for **Udb connectivity model using terminal and nodes**. **TOMS and DSO use the QGIS model**, while **SMS (Steam) still uses the Udb model**. **FMS 3G connectivity and Staten Island 33kV connectivity also use the Udb model**." → Two connectivity substrates coexist: legacy **Udb terminal/node** vs newer **QGIS diagram** model.

## 2. Controlled vocabulary / glossary (guide definitions + schema binding)

Every term below is quoted/paraphrased from ug.html with its clean-file line, then bound to the schema object the guide itself names. All named tables verified present in d1.sql unless flagged.

| Term | Guide definition (cited) | Schema binding (guide-named; verified in d1.sql) |
|---|---|---|
| **Move** / **Job** | [FACT - L5130-5132] "A Job Class defines the 'move' with all the move rules, job checks and actions for each OMS switching application. **The term 'move' and 'job' are synonymous**." | `soa_job`, `tc_job` (instance); `fms_jobclass` (template). All [FACT - d1.sql]. |
| **Job Class** | [FACT - L5128-5132] "A Job Class defines the 'move' with all the move rules, job checks and actions…" | `fms_jobclass` (PK jobclass; cols movetype, conditional, tomove/rsmove, tomoverules/rsmoverules) [FACT]. Supporting: `fms_jobclasscontrol`, `fms_jobclasslink` [FACT]. |
| **Job Check / Job Action** | [FACT - L5128-5130] part of the job-class def: "with all the move rules, **job checks and actions**". [FACT - L6122-6125] "Object Statuses are used by **Job Checks and Actions** to control card processing and produce yellow warning screens." | `fms_jobcheck`, `fms_jobaction` [FACT - d1.sql job-table listing]. |
| **Job Prompt** | [FACT - L6018-6021] "Job Prompts are custom software components that perform special Job Actions when moves are **issued or completed**. Some Job Prompt actions can be reversed and some cannot." | `FMS_CustomPrompt` [FACT - L6028 names it; verified `fms_customprompt` in d1.sql]. |
| **Job Objective** | [FACT - L12089-12096] "13kV Job Objectives provide information to Rapid Restore… Individual **moves in FMS are linked to Job Objectives**… objectives become part of the order downloaded to Rapid Restore." [FACT - L12112] "select a job and then choose an objective for the **TakeOut move**, and/or, an objective for the **Restore move**." | `FMS_JobObjective` [FACT - L12116; verified]. Also `fms_jobobjective` join. |
| **TakeOut move** / **Restore move** | [FACT - L12112] each job has a TakeOut move (out-of-service) and a Restore move (return-to-service). | `soa_job.tooperator/toissued/tocomplete/tomove` (TakeOut) + `rsoperator/rsissued/rscomplete/rsmove` (Restore) [FACT - d1.sql soa_job DDL]. Same pair in `tc_job`. |
| **Switching order** / **Operating order** / **Electronic order** | [FACT - L12089-12097] "Substation Operating Order detail tasks from the **order issued from the District Operator**… the order downloaded to Rapid Restore when move is downloaded." [FACT - L6222] "If an operator is not qualified they are not able to receive an **electronic order**." [FACT - L12334-12335] "When a move is issued against an excluded type, the **Issue Move** screen will not present any electronic order…" | No single "switching_order" table named in guide; orders are assembled from moves + `fms_jobobjective`. `soa_outagerequest` (`ornumber` = order/request number) is the OSS-side request record [FACT - d1.sql]. Exclusions: §5.5 Electronic Order Exclusions. |
| **Permit** (ISWP / OSWP) | [FACT - L11556-11563] "**In-Service Work Permits (ISWP)** are permits approved by Transmission Operator or District Operator for working groups to work on equipment **while the associated electric system is in service**. **Out-of-Service Work Permits (OSWP)** are permits approved by District Operator to work on equipment **while the associated electric system is out of service**. Before a DO issues an OSWP, **the DO has to switch on the electric system to take equipment out of service**." | `SOA_ISWPEquipType` [FACT - L11595; verified `soa_iswpequiptype`]. **`SOA_OSWPEquipType` [FACT - L11596 names it] — NOT FOUND in d1.sql.** See §6 contradictions. Permit lifecycle also: `soa_outagerequestpermit` [FACT - d1.sql]. |
| **Clearance** | NOT defined in ug.html. [UNKNOWN] The word "clearance" does not appear as a vocabulary term in the guide. Permit/OSWP is the guide's equivalent concept for taking equipment out of service. |
| **Feeder** | [FACT - L7355-7361] "Distribution substations are substation objects that have a kV Rating of 33kV or less." [FACT - L7380-7383] "A Distribution Feeder is **Primary Grouped** with a Substation object. A feeder must only be associated with one substation, … the **feeder source substation**." [FACT - L10242-10258] required groupings: Feeder 'member of' Substation + Primary Grouped to Substation; 'member of' Division; 'member of' Network (optional). | `udb_object` (the feeder object) + `udb_grouping` (membership) [FACT - d1.sql]. Feeder validation flags in `udb_object.inservice`/`validatedby` [FACT - L7394-7405]. |
| **Grouping** | [FACT - L7409-7410] "a row is inserted in **Udb_Grouping** making an equipment object a **member of** the feeder." Relationship types named: **member of**, **Primary Grouped**, **rated as** (kV rating), **Source Breaker**, **Source Position**, **controlled by** (Desk). | `Udb_Grouping` [FACT - L5092, L7409; verified `udb_grouping`]. |
| **Object** | [FACT - L5092] core data model "Udb tables like **Udb_Type, Udb_Object, Udb_Grouping**…" supported by Udb/PSDM (Power System Data Model). | `udb_object` (PK object) [FACT - d1.sql, 30 cols per ground truth]. |
| **Terminal** | [FACT - L6890-6897] "The Udb_Object table has a **Terminals** attribute that indicates the number of valid connections… drives how many rows are inserted into **Udb_Terminal** table… If the terminals value is two, then two rows are inserted… indicating that two devices should be connected." | `Udb_Object.Terminals` + `Udb_Terminal` [FACT; verified `udb_terminal`]. Per-type expected counts: `FMS_TypeTerminals` [FACT - L6899; verified `fms_typeterminals`]. |
| **Node** | [FACT - L6889] "The Udb connectivity model involves the following tables: **Udb_Object, Udb_Terminal, and Udb_Node**." | `Udb_Node` [FACT; verified `udb_node`]. (Detailed node semantics not narrated in guide.) |
| **Relay** | [FACT - L10495-10497] "**Relays are devices in the substation that 'trip' when equipment opens auto**. The Relays screen on each OMS application is used to record the relays that tripped." | Relay Class = a `Udb_Type` entry [FACT - L10499]. Relay Type list = `CAC_RelayTypes` [FACT - L10501; verified `cac_relaytypes`]. Equipment's relay class stored in **`Udb_Switch.RelayType`** (attribute "inappropriately named") [FACT - L10519-10521; verified `udb_switch`]. |
| **Relay Class vs Relay Type** | [FACT - L10499-10502] "A 'Relay Class' corresponds one-to-one with a Udb Type… A 'Relay Type' is **not** a Udb Type. Relay Types are defined for Relay Classes and are saved in a separate table 'CAC_RelayTypes'." | as above. |
| **Open Auto equipment** | [FACT - L11622] "**Open Auto equipment are switches and breakers that open automatically when faults occur**." Stored in `FMS_OpenAutoEquip` [FACT - L11625; verified `fms_openautoequip`]. | Drives Relay Summary, Open Auto SLC items, CutOut Breakers displays [FACT - L11627-11631]. |
| **Object Status** | [FACT - L6122-6125] "Object Statuses are used by Job Checks and Actions to control card processing and produce yellow warning screens… defined in the type hierarchy under Specification -> Application -> Object Status." Dual-supertype (also typed by Type-of-Card) to limit status pick-lists [FACT - L6126-6135]. | `udb_type`/`udb_supertype` hierarchy; per-feeder status in `FMS_ObjectStatus` [FACT - L7523 names it; verified `fms_objectstatus`]. |
| **Skill Group** | [FACT - L6176-6181] "Skill Groups are used to qualify operators to perform certain tasks. There are **two sides to a Skill Group, a person and a job (move)**… defined in the Type Hierarchy under Specification->Application." | Person side: `FMS_PersonToSkill` [FACT - L6188; verified `fms_persontoskill`]. Job side: `FMS_JobToSkill` [FACT - L6193; verified `fms_jobtoskill`]. |
| **Card / Feedercard** | [FACT - L7396] "A new feeder is marked InService when a **feedercard is activated** on it for the first time." Card = the active switching document per object; reports generated for "active cards in FMS, TLS, TOMS and Steam" [FACT - L6137-6141]. | (card identity is `controlcard`/`card` integer on `soa_job`/`tc_job`) [INFERENCE - d1.sql columns]. |
| **Source Breaker / Source Position / CutOut-CutIn / Station Ground** | [FACT - L7508-7524] "A feeder must have one and only one **source breaker** equipment… identify whether a feeder is **CutOut or CutIn** based on 'CurrentlyOpen' status of the source breaker… maintained in the 'Udb_Switch' table." "**Source Position**… identify whether the feeder **Station Ground** is 'ON' or 'Off'… maintained in 'FMS_ObjectStatus'." | `udb_switch` (CurrentlyOpen), `fms_objectstatus` (Ground) [FACT; verified]. |
| **Network / Jeopardy Rank** | [FACT - L10143-10146] "each distribution network is assigned an integer value called 'Rank' in the Jeopardy Model… range of Ranks is assigned a color… background color for the network on the **Active Feeder Summary**." Rank 1–60, 5 preset ranges [FACT - L10157-10162]. | `fms_networkoutage` (network outage), `nwp_jobclass` (network prefix) [INFERENCE - d1.sql]. |
| **Desk** | [FACT - L10280-10282] "Feeder 'controlled by' Desk, to be based on Division memberships." Desk owns work-permit timing [FACT - L6466-6468]. | grouping relationship in `udb_grouping`; desk name surfaces as `soa_job.deskname` [FACT - d1.sql]. |
| **Division / Network / Substation membership** | [FACT - L10247-10258] feeder must be 'member of' Substation, Division (≥1), Network (optional). | `udb_grouping` [FACT]. |

## 3. Roles / actors (as named in the guide)

| Role / actor | Guide evidence (clean-file line) | Notes |
|---|---|---|
| **DO — District Operator** | [FACT - L5303, L11561, L12091, L6201] "send breaker status information to FMS to notify the **District Operator**"; "the **DO** has to switch on the electric system"; "order issued from the **District Operator**". | Primary distribution switching actor; issues OSWP, issues orders. |
| **Transmission Operator** | [FACT - L11557] "ISWP are permits approved by **Transmission Operator** or District Operator". | Transmission-domain approver. |
| **Operator (field) / person** | [FACT - L6178-6179] "The person is typically a **field operator** that is issued a move or returns a permit." | Receives moves, returns permits; qualified via Skill Group. |
| **Substation Operator** | [FACT - L6221, L11865] "qualified **Substation Operator**, FOD, or FCR"; marks individual phases complete/incomplete. | Rapid Restore qualification. |
| **FOD** | [FACT - L6221] one of the Rapid-Restore qualifications. | [UNKNOWN] expansion not given in guide. |
| **FCR** | [FACT - L6221-6223, L10236] "qualified… or **FCR**"; "The interface message to **Lift a Caution** may only be sent by an **FCR-qualified operator**"; "minimum feeder data… for an **FCR** to generate an **RFP**". | Field/Restore role; gated capability. [UNKNOWN] expansion. |
| **ACDO** | [FACT - L6227-6228] "When an access request is granted by the **ACDO**, the requested skill group will be automatically established." | Access-control DO; grants skill groups. |
| **OMS Staff** | [FACT - L7398-7399, L10214] "**OMS Staff** can validate proper feeder setup"; performs feeder validation. | Data-validation role. |
| **Administrator** | [FACT - L6783, L6930] "appear on the **administrator's** view of TOMS Outage Summary"; "Required Terminals field… can be changed by the **Administrator**." | DBM admin (audience of this guide). |
| **Working group** | [FACT - L11559-11562] "for **working groups** to work on equipment… can be requested by working groups on the FMS Online application." | Permit requestors. |
| **OMS application developers / programmers** | [FACT - L6029-6031] maintain `FMS_CustomPrompt` via SQL scripts. | Not operational. |

[UNKNOWN] No "switchman", "approver" (as a distinct titled role beyond DO/TO), or "dispatcher" term appears verbatim in ug.html. The approval actors are DO and Transmission Operator; the qualification/grant actor is ACDO. Do not assert a "dispatcher" role from this guide.

## 4. Job-class taxonomy — what the guide actually provides

[FACT - L5128-5135] The guide defines what a Job Class *is* (the move template carrying move rules + job checks + actions) but **explicitly defers the enumerated taxonomy** to the separate "Job Class Maintenance User Guide." 

[CRITICAL / UNKNOWN] **The list of concrete job classes (the actual class names/codes and their meanings) is NOT in ug.html, and the seed rows that would populate `fms_jobclass`/`udb_type` are absent from d1.sql** (all tables loaded via missing external `.ingres` files per ground truth). Therefore: **the job-class taxonomy is [UNKNOWN]** — do not fabricate a class list.

What CAN be asserted about job-class structure (from schema + guide):
- [FACT - d1.sql] `fms_jobclass(jobclass int PK, movetype char(4), conditional int, tomove varchar(160), tomoverules int, rsmove varchar(160), rsmoverules int)` — a job class is keyed by integer `jobclass`, carries a 4-char `movetype`, and a TakeOut/Restore move-text + rules pair. **No human-readable class name column in this table** → the class name/label lives in `udb_type`/`udb_object` (the type hierarchy), which is seed-row-dependent and thus [UNKNOWN] here.
- [FACT - L6122-6125] Object Statuses (also seed-row-dependent) parameterize the job checks/actions inside each class.
- [FACT - L12114-12116] Job↔objective linkage is per-job in `fms_jobobjective`; "Not all jobs have objectives."
- [INFERENCE] `movetype char(4)` on `fms_jobclass`/`soa_job`/`tc_job` is the closest thing to a job-class *category code*, but its value domain (the 4-char codes) requires absent seed data → [UNKNOWN] which codes exist.

[FACT - d1.sql] **THREE distinct job/jobclass table families exist** — reconciliation:
| Table | Domain (per prefix) | Role |
|---|---|---|
| `soa_job` | TOMS/SOA = Substation + Transmission Feeder | **job INSTANCE** (per switching item; TakeOut/Restore operators, timestamps, status, movetype, substation, deskname, switemstatus) |
| `tc_job` | TLS = Telephone Circuit | **job INSTANCE** for telephone circuits (card, seq, circuit, steppair, in/outservice, switch positions) |
| `fms_jobclass` | FMS (shared class library) | **job CLASS / template** (no per-job instance) |
| `nwp_jobclass` | NWP (network?) | minimal: `nwp_jobclass(jobclass int)` only — a class-key registry [FACT - d1.sql] |

[INFERENCE] **Which "job" does the guide mean?** When ug.html says "job (move)" in the FMS/Skill-Group/Objective context (L6178, L12112) it means the **per-object switching job instance** that gets issued to an operator — i.e. `soa_job` for substation/transmission and `tc_job` for telephone. When it says "Job Class" (L5128) it means the **template** = `fms_jobclass` (shared across apps). There is **no `fms_job` instance table** despite the `fms_` prefix dominance; FMS distribution-feeder job instances are [UNKNOWN] in table form here (likely `soa_job`/another table — the guide does not name an `fms_job`). **Contradiction-watch: the prompt hypothesizes `fms_job`/three job tables; d1.sql has `soa_job`, `tc_job`, `fms_jobclass`, `nwp_jobclass` — there is NO table literally named `fms_job` or `tc_job`/`soa_job` triplet of instances; the instance tables are `soa_job` + `tc_job` only.** [FACT - d1.sql: only soa_job and tc_job match `*_job(` instance shape.]

## 5. Outage handling — planned vs automatic/forced (what the guide narrates)

The guide does NOT give a step-by-step operator switching narrative (deferred to SOA guide). It DOES expose the data-side mechanisms for both outage modes.

### 5a. PLANNED outage path (request-driven, via moves/permits/orders)
[FACT - d1.sql] `soa_outagerequest` is the planned-outage REQUEST record:
`ornumber varchar(20)` (order/request #), `title`, `ossstatus`, scheduled-vs-actual date pairs: `skedoutagedate/actualoutagedate`, `skedstartdate/actualstartdate`, `skedreturndate/actualreturndate`, `skedinservicedate/actualinservicedate`, `currentstatus`, `jurisdiction`.
[INFERENCE] The sked/actual date pairing = a **scheduled (planned) outage workflow**: requested → scheduled → started → returned → in-service. `ossstatus`/`currentstatus` carry the state machine, but the **state code values are [UNKNOWN]** (seed rows absent).

[FACT - L5063 (ug raw), L12089-12097] The planned execution chain narrated: DO issues an **operating order** assembled from **moves**; each move has a **TakeOut** (out-of-service) and **Restore** move; **Job Objectives** decorate the order; order is **downloaded to Rapid Restore** as an **electronic order** to qualified operators.

[FACT - L11556-11563] Planned outage to *work on* equipment uses **permits**: ISWP (work while in service) or **OSWP** (work while out of service — "Before a DO issues an OSWP, the DO has to switch on the electric system to take equipment out of service"). Permit↔outage link: `soa_outagerequestpermit` [FACT - d1.sql].

Planned-outage move lifecycle states (narrated):
[FACT - L6018-6025] A move is **Issued** (Issue Move screen) → then either **Completed** (Return Operator Moves screen) → or **Aborted** (on Issue Move screen) → or marked **Incomplete** (Return Operator Moves) → or **Undone** (Undo button, triggers Job-Prompt reversal). [FACT - d1.sql] `soa_job.status char(3)` holds these states (values [UNKNOWN] — seed-dependent), with timestamps `toissued/tocomplete/rsissued/rscomplete`.

```mermaid
stateDiagram-v2
  [*] --> Issued: Issue Move screen
  Issued --> Completed: Return Operator Moves (complete)
  Issued --> Aborted: Issue Move screen (abort)
  Completed --> Incomplete: marked Incomplete (Return Operator Moves)
  Completed --> Undone: Undo button (reverses Job Prompts)
  Aborted --> [*]
  Incomplete --> [*]
  Undone --> [*]
  Completed --> [*]
  note right of Issued
    soa_job/tc_job: status char(3) (values UNKNOWN - seed rows absent)
    TakeOut(to*) then Restore(rs*) operator+timestamps
  end note
```

### 5b. AUTOMATIC / FORCED outage path (event-driven, connectivity trace)
[FACT - L6773-6783] The **Outage Monitor** background process detects forced/automatic outages from breaker operate events:
- "**Delay to Evaluate Equipment Outages after a Breaker Operates** — The number of seconds the Outage Monitor background process will wait before beginning the **connectivity trace** to evaluate a potential outage after receiving an indication that a breaker operated (was opened or closed)."
- "**Highlight Outage with an Asterisk if Outage Not Identified Within** — … from the time a breaker operates to the time the Outage Monitor begins the connectivity trace… an asterisk will appear on the administrator's view of **TOMS Outage Summary** next to the names of the feeder or equipment identified during the trace."
[FACT - L10495-10497, L11622] **Open Auto equipment** ("switches and breakers that open automatically when faults occur", `fms_openautoequip`) + **Relays** ("devices in the substation that 'trip' when equipment opens auto") are the forced-outage primitives; the Relays screen records relays that tripped.
[FACT - d1.sql] Forced-outage data tables: `soa_outagesummary` (object, type, voltage, card, switchingitem, job, **outagetype int**, outservicestart/end, est dates, **latentflag**, outagekey); `fms_bussectionoutage`, `fms_networkoutage`, `xa21_outagereport` (EMS/SCADA feed), `qgis_setoutage` proc (visual outage on QGIS).

[FACT - L6789-6793] Forced-outage decision support: "When the system load exceeds this value, the **Peak Load Bus Fault Correlation matrix** will be applied to recommend actions for **bus section outages**. Otherwise, a Normal Load matrix may be applied." → `fms_bussectionoutage`, Bus Fault Correlation Matrix (§4.2).

[INFERENCE] **Planned vs Automatic discriminator** = `soa_outagesummary.outagetype` (integer FK into a type table) and likely `latentflag`. **The actual enum values that distinguish "planned" from "automatic/forced" are [UNKNOWN]** — they are catalog/seed rows loaded from the absent `.ingres` files. Do NOT assert the specific outagetype codes.

```mermaid
flowchart LR
  BK[Breaker operates open/close<br/>XA21/SCADA -> xa21_outagereport] --> DLY[Wait 'Delay to Evaluate' seconds]
  DLY --> TR[Outage Monitor connectivity trace<br/>Udb_Terminal/Udb_Node or QGIS model]
  TR --> ID{Outage identified<br/>within window?}
  ID -->|yes| SUM[soa_outagesummary row<br/>outagetype=forced?* latentflag]
  ID -->|no/late| AST[Asterisk on TOMS Outage Summary]
  RLY[Open Auto equip opens<br/>fms_openautoequip] --> RELAY[Relays trip recorded<br/>cac_relaytypes / Relays screen]
  RELAY --> SUM
  SUM --> QG[qgis_setoutage -> visual outage on QGIS]
```

### 5c. Outage Monitor status (CONTRADICTION — version history vs param docs)
[FACT - L2798-2799] Version history: "TOMS Menu **Outage Monitor updated to indicate that it has been disabled**."
[FACT - L2820-2822] "TOMS Menu removed Outage Monitor Target Types that was tied to **original Outage Monitor before Outage Monitor was rebuilt to manage visual outages on QGIS**."
[CONTRADICTION] Yet §1.15.3 (Outage Monitor params at L6773-6783) still documents the live "Delay to Evaluate…"/"Highlight…Asterisk" parameters as if active. Reconciliation [INFERENCE]: the **original Udb-trace Outage Monitor was disabled/removed and rebuilt on QGIS visual model**; the documented timing parameters describe the original/trace mechanism that may now be partially superseded. Downstream synthesis must not assume the Udb-trace Outage Monitor is currently live — the guide says it was disabled then rebuilt on QGIS.

## 6. Contradictions & gaps (schema vs guide) — flag list

1. [CONTRADICTION] **`SOA_OSWPEquipType` named in guide (L11596) is NOT in d1.sql.** Only `soa_iswpequiptype` exists. OSWP equip-type storage is unaccounted-for in the dump (possibly a missing table, a renamed table, or in absent data). 
2. [CONTRADICTION] **`FMS_AmmClearMaintP` / high-pot table naming.** Guide L6735 names `fms_highpottesthistory`; d1.sql has `fms_highpothistory` (no "test"). Guide L6720 names `fms_ammetercleartest` — verified present. The high-pot table name in the guide is inexact.
3. [CONTRADICTION — severe] **Server-logic procedures are STUBS in d1.sql.** `soa_issuemove`, `soa_completemove`, `fms_ammclearmaintp`, `fms_validatejobclass`, all `fms_jobclass*` procs etc. are declared as `create or replace procedure NAME as begin return; end` — empty bodies. **1,225 of 2,450 procedures (50%) are empty stubs.** The guide describes behavior (e.g., L6722-6727 "a database trigger fires and the FMS_AmmClearMaintP database procedure will delete the oldest test result") that **cannot be verified against the dump** because the proc body is absent. Treat all guide-narrated procedure behavior as [UNKNOWN at code level] in this artifact set.
4. [CONTRADICTION — terminology] "**TLS**" overloaded: §3 TOC = Transmission Line System; body L5065 = Telephone Lines switching app. (See §1.)
5. [GAP] **Job-class taxonomy [UNKNOWN]** — deferred to absent "Job Class Maintenance User Guide"; seed rows absent. No concrete class list extractable.
6. [GAP] **All status/type enumerations [UNKNOWN]** — `soa_job.status char(3)`, `soa_job.movetype char(4)`, `soa_outagesummary.outagetype int`, `soa_outagerequest.ossstatus/currentstatus`, Object Statuses, Skill Group types, Relay Types: every value domain depends on absent `.ingres` seed/catalog data. Cannot enumerate planned-vs-forced outage codes, move states, or job classes.
7. [GAP] **"Clearance" not in guide.** No clearance concept; OSWP/permit is the nearest analog.
8. [GAP] No "dispatcher"/"switchman"/generic "approver" role term in ug.html; approval = DO + Transmission Operator; grant = ACDO.
9. [INFERENCE/GAP] Guide says "move=job synonymous" but schema has BOTH instance (`soa_job`,`tc_job`) and template (`fms_jobclass`) — the guide's loose synonymy collapses class↔instance; the schema separates them. No literal `fms_job` instance table exists.
10. [FACT - L6886-6914] Two connectivity substrates (Udb terminal/node vs QGIS); outage tracing semantics differ per app (TOMS/DSO=QGIS, SMS/FMS-3G/SI-33kV=Udb). A single "outage workflow" does NOT exist across all domains.

## 7. Schema objects asserted to exist (all verified in d1.sql unless flagged)
Tables: `udb_object`, `udb_type`, `udb_grouping`, `udb_terminal`, `udb_node`, `udb_switch`, `soa_job`, `tc_job`, `fms_jobclass`, `nwp_jobclass`, `fms_jobclasscontrol`, `fms_jobclasslink`, `fms_jobcheck`, `fms_jobaction`, `fms_jobobjective`, `fms_jobtoskill`, `fms_persontoskill`, `fms_customprompt`, `fms_objectstatus`, `fms_openautoequip`, `fms_typeterminals`, `fms_systemparameters`, `fms_ammetercleartest`, `fms_highpothistory`, `fms_bussectionoutage`, `fms_networkoutage`, `soa_iswpequiptype`, `soa_outagerequest`, `soa_outagerequestpermit`, `soa_outagesummary`, `soa_outageequiptype`, `soa_outageisolink`, `soa_jobcontrol`, `soa_job_to_soo`, `cac_relaytypes`, `cac_softwarelevel`, `itc_reportlogistics`, `xa21_outagereport`.
Flagged NOT FOUND: `soa_oswpequiptype` (named in guide L11596), `fms_highpottesthistory` (guide name; actual = `fms_highpothistory`).
Procs (exist as names; bodies are STUBS in dump): `soa_issuemove`, `soa_completemove`, `fms_ammclearmaintp`, `fms_validatejobclass`, `qgis_setoutage`.
