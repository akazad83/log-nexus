# TC Subsystem — Jobs, Cards, Trouble Report Orders (TLS / Telephone Line System)

Primary artifact: `d:/103_RnD/psm_v1/d1.sql`. Vocabulary bound to `ug.html`. Every material claim tagged.

---

## 0. HEADLINE — What TC actually is

**TC = TLS = "Telephone Line System"** — ConEd's trouble-call / telecom-circuit trouble-ticket switching application, one of the OMS switching applications that share the **FMS database**.

- [FACT - ug.html:5093-5095] "There are five switching applications that use DBM. 1) FMS - Distribution Feeders, 2) TOMS (or SOA) ... TFMS, and **3) TLS - Telephone Lines** use the 'FMS' database." → TC tables physically live in the FMS Ingres database alongside fms_/soa_/tfms_.
- [FACT - ug.html:11061] "These numbers are saved in the **TC_TroubleType table in the FMS database**." → confirms TC_* = TLS and resides in FMS DB.
- [FACT - ug.html:10790,10796,10815] UI is the "**telephonecard** main screen"; cards are loaded per "telephone circuit." TC manages telephone/telecom circuit cards.
- [FACT - ug.html:10976-10977] "To create an electronic ticket for a Verizon circuit, the TLS system has to send the Verizon name... **TC_VerizonCircuit** table stores the mapping." → TC issues electronic trouble tickets to **Verizon** (the telco carrier).
- [INFERENCE] TC is NOT a generic job-ticketing system and NOT a power-feeder switching system. It is the telephone/telecom-line trouble-order subsystem: a DO (District Operator) opens a card on a telephone circuit, performs switching moves (jobs), and issues trouble report orders downloaded to Verizon's TLS, polling status back.

### JOB vs CARD vs MOVE (resolved from the guide)
- [FACT - ug.html:5160-5163] "A **Job Class** defines the 'move' with all the move rules, job checks and actions for each OMS switching application. **The term 'move' and 'job' are synonymous.**"
- [INFERENCE - ug.html:5162 + tc_job/tc_card DDL] Therefore in TC: a **CARD** is the work container (one telephone circuit's switching/trouble card); a **JOB = a single switching MOVE/step on that card**. `tc_job` is keyed `(card, seq, job)` — i.e. ordered steps within a card. A card holds N jobs (moves) in `seq` order. This is the identical card→ordered-steps pattern used by FMS (fms_card/fms_job) and SOA.

> CONTRADICTION vs prompt premise: prompt asked "is a card a switching step within a job?" — **No, it is the inverse.** Card is the parent container; job is the step/move. Evidence: `tc_job` btree index on `(card, seq, job)` [FACT - d1.sql:12045-12047] and ug.html:5162.

---

## 1. CRITICAL CONSTRAINT — All TC procedure bodies are STUBS

[FACT - d1.sql] All **127** `create or replace procedure tc*` statements are empty stubs of the form `... as begin return; end`. Verified: 122 match the bare `as begin return; end` regex; the other 5 (`tc_relayprotection$chk`, `tc_reportln$upd`, `tc_reportnoorg$ins`, `tc_reportos$ins`, `tc_reportstats$ins`) are also `as begin return; end` (just `$`-suffixed rule helpers). **Zero TC procedure bodies exist in this dump.**

- [FACT - d1.sql:25707] `create or replace procedure tc_insertcard as begin return; end` — representative.
- [FACT - d1.sql] Globally ~1,225 procs have real bodies and ~1,163 are stubs; **TC falls entirely in the stubbed set.**
- [INFERENCE] Server-side TC logic (insert/issue/complete/archive flows) is **[UNKNOWN] at the statement level** — cannot be quoted from proc bodies. The recoverable behavior comes from **Ingres RULES** (present in full, lines 33272-33352) which fire these procs with explicit WHERE-clause guards and parameter bindings, plus DDL structure and ug.html.

This is the single most important fact for downstream synthesis: **do not expect TC business logic from proc bodies; reconstruct from rules + DDL + guide only.**

---

## 2. TC TABLE CATALOG (33 tables)

[FACT - d1.sql grep `^create table tc_`]. Column counts verified by AWK over DDL blocks.

| # | Table | Cols | Storage / Key | Role (INFERENCE unless cited) |
|---|-------|------|---------------|------|
| 1 | `tc_card` | 29 | btree **unique** on `(card,circuit)` | Trouble/switching card header per telephone circuit |
| 2 | `tc_job` | 37 | btree on `(card,seq,job)` | Ordered switching **move** (step) within a card |
| 3 | `tc_troublereportorder` | 30 | btree on `(circuit,workpermit)` | Electronic trouble ticket order sent to Verizon/TLS |
| 4 | `tc_troublereportstatus` | 6 | btree unique | Status-history rows per order (`ordernumber,sequenceid`) |
| 5 | `tc_troubletype` | 3 | btree unique | Verizon report-type code catalog [FACT ug.html:11060] |
| 6 | `tc_troublestatus` | 4 | btree unique | Verizon status-number catalog [FACT ug.html:11076] |
| 7 | `tc_cardlock` | 3 | btree unique | Card control lock (user/desk owns the card) |
| 8 | `tc_cardnote` | 2 | hash unique | Free-text note attached to a card |
| 9 | `tc_circuitslog` | 4 | btree unique | Timestamped circuit log entries per card |
| 10 | `tc_circuitdocument` | 3 | hash unique | Circuit doc registry [FACT ug.html:10789 "Docs"] |
| 11 | `tc_circuitdocumentlink` | — | btree unique | Links circuit→document |
| 12 | `tc_circuittoreportmapping` | 2 | btree unique | `circuittype → reporttype` mapping |
| 13 | `tc_verizoncircuit` | 2 | btree unique | ConEd circuit ↔ Verizon line-name map [FACT ug.html:10977] |
| 14 | `tc_workpermit` | 12 | hash unique | Work-permit detail (keyed `permitjobid`) |
| 15 | `tc_operatingstepstatus` | 10 | btree unique | Live operating-step timing per card/circuit |
| 16 | `tc_reportstats` | 16 | btree | Outage/restoration statistics rows (hours out) |
| 17 | `tc_reportmanager` | 7 | btree unique | Per-circuit "report needed" flag / last access |
| 18 | `tc_problemtracker` | 5 | btree unique | Circuit problem-tracking notes |
| 19 | `tc_workgrouprequest` | 19 | btree unique | Work-group dispatch request (`requestid`) |
| 20 | `tc_wgrequestrecipient` | 10 | btree unique | Recipients of a work-group request + responses |
| 21 | `tc_wgrequestack` | 1 | heap | Acknowledgement stub (`requestid` only) |
| 22 | `tc_specialpstsubstation` | — | btree unique | Special PST substation list |
| 23 | `tc_systemparameters` | 4 | isam unique | TLS tunables (telcardactivity, responsetimeout, minimumdodelayrecorded) |
| 24 | `tc_lastkey` | 2 | btree unique | Manual sequence generator (`table_name,last_key`) |
| 25 | `tc_log` | 10 | btree | Card/job change audit log |
| 26 | `tc_tempgroupertransfer` | — | btree unique | Scratch table for grouper move transfer |
| **Archive twins (8)** | | | | |
| 27 | `tc_archivecard` | 28 | btree unique | Archived card (drops `priority` vs live) |
| 28 | `tc_archivejob` | 37 | btree | Archived job/move |
| 29 | `tc_archivelog` | — | btree | Archived log |
| 30 | `tc_archivecircuitslog` | — | btree unique | Archived circuit log |
| 31 | `tc_archiveoperatingstep` | 10 | btree unique | Archived operating-step timing (mirror of tc_operatingstepstatus) |
| 32 | `tc_archivereportstats` | — | btree | Archived report stats (drives report-rollup rules) |
| 33 | `tc_archiveworkpermit` | — | hash unique | Archived work permit |

[FACT] 8 archive twins (`tc_archive*`), consistent with the 35 archive twins counted dump-wide. Archive twins are near-structural copies of their live tables, used for closed/historical cards.

---

## 3. DEEP-READ: `tc_card` (29 cols)

[FACT - d1.sql:11773-11801] Header per telephone circuit. Notable columns:

| Column | Type | Notes [INFERENCE unless cited] |
|--------|------|------|
| `card` | int PK-part | Card id; unique with `circuit` |
| `circuit` | int | The telephone circuit (a udb_object); FK to circuit object |
| `linenumber` | varchar(40) | Circuit line number; **empty→nonempty transition activates the card** (see rule below) |
| `circuitstatus`/`circuitstatusname` | int/varchar | Circuit operating status (set from fms_objectstatus via tc_circuitstatuschange) |
| `status` | int **not default** | Card lifecycle status (integer codes — values are **[UNKNOWN]**, no seed rows; rule shows `status=4` = closeable/report-removal) |
| `username` | char(24) nullable | Current owner/controller |
| `cardtype`,`linetype`,`linetypename`,`functionarea`,`troublecategory`,`carrier` | int+name pairs | Classification (name columns are denormalized caches) |
| `opened`/`closed` | ingresdate | Card open/close timestamps |
| `validatedby` | varchar(24) | Validation actor |
| `reasonforfailure` | varchar(120) | Trouble reason text |
| `priority` | int NULL | Present in live, **absent in tc_archivecard** [FACT - DDL diff] |
| `altline1`,`altline2`,`routename`,`substationnames`,`feedernames` | varchar | Denormalized routing/topology strings |

Storage: `btree unique on (card,circuit)`, page 8192, journaling on [FACT - d1.sql:11815].

---

## 4. DEEP-READ: `tc_job` (37 cols) — the switching MOVE

[FACT - d1.sql:11995-12031]. Key=`(card,seq,job)`. A job is one move; columns split into a **TO (issue/take-out)** half and an **RS (restore)** half — classic two-phase switching move (out-of-service then in-service):

| Group | Columns | Meaning [INFERENCE] |
|-------|---------|------|
| Identity | `job`, `card`, `seq`, `jobclass`, `jobclassseq`, `steppair` | job id; parent card; sequence within card; job-class (=move definition, ug.html:5161); steppair links TO/RS halves |
| Status | `status char(3)` | Move status code; **known value: `'Xfr'` = "Move transferred"** [FACT - rule TC_LogJob_XfrStatus] |
| Topology | `circuit`, `linenumber`, `circuitclass`, `circuitclassname`, `substation`, `substationname`, `organization`, `organizationname` | what is being switched |
| TO half | `movetype char(4)`, `tomove`, `tostep`, `tomoverules`, `tooperator`, `tooperatorname`, `toissued`, `tocomplete` | take-out / issue side of the move |
| RS half | `rsmove`, `rsmoverules`, `rsstep`, `rsoperator`, `rsoperatorname`, `rsissued`, `rscomplete` | restore side of the move |
| Service | `inservice`, `outservice` | service-interruption timestamps — **drive report-stats rules** |
| Switch pos | `initialswitchpos`, `finalswitchpos` | device position before/after |
| Results | `results`, `resultscode`, `resultscodename` | move outcome |

[INFERENCE] `tomoverules`/`rsmoverules` > 1 trigger move-rule expansion (rule `TC_JobInsMoveRules`). `inservice`/`outservice` null↔notnull transitions are the hooks for outage statistics and relay-protection checks.

Sentinel value seen: `job = -1` (placeholder/new), `job = 2147483647` (max-int sentinel), `seq = -1` — used as insert-staging markers (rules `TC_JobInsert2`, `TC_GrouperSeqUpd`).

---

## 5. DEEP-READ: `tc_troublereportorder` (30 cols) — electronic ticket to Verizon

[FACT - d1.sql:12350-12380]. Key path: `(circuit, workpermit)` index; identity `ordernumber`.

| Phase | Columns |
|-------|---------|
| Identity/link | `ordernumber`, `orderstatus`, `card`, `circuit`, `workpermit`, `msgkey` |
| Issue | `issuecomment`, `troubletype` (→tc_troubletype), `issuedbydo`, `dophone`, `issuetime`, `downloadtime`, `reportid` |
| Report state | `reportstate`, `reportstatus` (→tc_troublestatus), `statustime`, `lastpoll`, `pollrate` |
| Ack/Reject | `ackrejecttime`, `ackrejectby`, `ackrejectcomment` |
| Rescind | `rescindtime`, `rescindtype`, `rescinddo`, `rescindreasontype`, `rescindreasontypename`, `rescindcomment` |
| Verify | `verification`, `verifydo`, `verifycomment` |

[FACT - ug.html:11070-11077] "During the processing of trouble tickets, **Verizon communicates the progress to TLS by sending a status number**... The status information is stored in the **TC_TroubleStatus** table." → `reportstatus`/`reportstate` are Verizon-returned codes; `pollrate`/`lastpoll` implement polling for ticket progress.
[FACT] `row_estimate = 8228` on the copy statement — the busiest TC table (vs tc_card row_estimate=206, tc_job=3595).

**Status history twin:** `tc_troublereportstatus(ordernumber, sequenceid, reportstate, reportstatus, statustime, statuscomment)` [FACT - d1.sql:12406] — one row per status transition of an order. [INFERENCE] `ordernumber` joins to `tc_troublereportorder.ordernumber`; `sequenceid` orders the history.

---

## 6. The TRO → JOB → CARD chain (reconstructed)

[INFERENCE from FK-shaped columns + rules; no proc bodies to confirm]

```
tc_card (card, circuit)                     ← work container, one telephone circuit
   │ 1:N  (card, seq)
   ▼
tc_job (card, seq, job)                      ← ordered switching MOVE/step
   │ references workpermit, circuit
   ▼
tc_workpermit (permitjobid)                  ← permit covering the move
   │
tc_troublereportorder (ordernumber)          ← electronic ticket, links card+circuit+workpermit
   │ 1:N (ordernumber, sequenceid)
   ▼
tc_troublereportstatus                       ← Verizon status history per order
```

Supporting links: `tc_workgrouprequest(card, job, tors, circuit)` carries `tors` (=trouble-order/report sequence) tying a work-group dispatch to a card+job [FACT - d1.sql workgrouprequest DDL has columns card,job,tors,circuit].

---

## 7. RECOVERABLE BUSINESS LOGIC — Ingres RULES (the real behavior)

[FACT - d1.sql:33272-33352] All TC rules present in full. These are the only place TC server logic survives. Each fires a (stubbed) proc with explicit guards:

### Card lifecycle
| Rule | Trigger / Guard | Action |
|------|-----------------|--------|
| `tccard$insert` | AFTER INSERT tc_card | `TC_CardIns(Card)` |
| `tccardnote$ins` / `$del` | INSERT/DELETE tc_card | `TC_CardNoteIns` / `TC_CardNoteDel` |
| `TC_ActivateCardInserted` | UPD(LineNumber) tc_card WHERE Old=''  AND New<>'' | `TC_NewActiveCard(Card,Circuit,LineNumber)` → **card activation when line number first set** |
| `tccard$anyupd` | AFTER UPDATE tc_card | `TC_CardAnyUpd(Card)` |
| `tccard$typeupd` | UPD(linetype) WHERE changed | `TC_CardTypeUpd` |
| `tccard$funcareaupd` | UPD(functionarea) WHERE changed | `TC_CardFuncAreaUpd` |
| `tccard$carrierupd` | INSERT udb_grouping WHERE relationship=15013 AND groupingtype=3 | `TC_CardCarrierUpd(circuit,carrier)` — carrier from UDB grouping |
| `TC_RemoveCardReport2` | UPD(Status) tc_card WHERE **New.Status=4** | `TC_RemoveCardReport(Card)` → status 4 = report removal/close |

### Card control / lock → report flag
| `TC_CardControlTaken` | AFTER INSERT tc_cardlock | `TC_SetReportFlag(Card,UserName)` |
| `TC_ControlLifted` | AFTER DELETE tc_cardlock | `TC_ClearReportUserName(Card)` |

### Job (move) lifecycle
| `TC_JobInsert2` | INSERT tc_job WHERE **New.Job=-1** | `TC_JobInsert2` — assign real job id to staged row |
| `TC_GrouperSeqUpd` | UPD(Job) WHERE Old.Job=-1 AND New.Job>1 AND Old.Seq=-1 | `TC_GrouperSeq(StepPair,Job)` |
| `TC_JobInsMoveRules1` | UPD(Job) WHERE TOMoveRules>1 OR RSMoveRules>1 | `TC_JobInsMoveRules` — expand move rules |
| `TC_JobInsMoveRules2` | INSERT WHERE (rules>1) AND Job<>-1 AND Job<>2147483647 | same |
| `tcjob$insupd` | UPD,INSERT tc_job | `TC_JobInsUpd(Card,Job)` |
| `tcjob$substationupd` | UPD(substation) WHERE changed | `TC_JobSubstationUpd` |
| `TC_LogJob_XfrStatus` | UPD(Status) WHERE **New.Status='Xfr'** | `TC_LogInsert(... Item='Move transferred')` |
| `TC_LogJob_XfrStatus1` | INSERT WHERE Status='Xfr' | same |

### Service / outage statistics (the report engine)
| `TC_ReportStats$Ins` | UPD(OutService) tc_job WHERE New notnull, Old null | `TC_ReportStats$Ins(...)` — open an outage stat when move goes out of service |
| `TC_ReportStats$Upd` | UPD(InService) tc_job WHERE New notnull, Old null | restore → close outage stat |
| `TC_ReportUpdAdj` | INSERT tc_reportstats | `TC_ReportUpdAdj` |
| `TC_CalculateHoursOut` | UPD(Inservice) tc_reportstats WHERE New notnull, Old null, Sequence=1 | `TC_CalculateHoursOut` |
| `TC_ReportLN$Upd` / `TC_ReportNoOrg$Ins` / `TC_ReportOS$Ins` | INSERT tc_archivereportstats WHERE Sequence IN(2,3)/Org=''/Seq=3 | report rollups fire off the **archive** table |

### Operating-step timing
| `TC_CalculateDuration` | UPD(EndTime) tc_operatingstepstatus | `TC_CalculateDuration(Card,OperatingStep,Start,End)` |
| `TC_DelayCheck` | INSERT tc_operatingstepstatus WHERE OperatingStep NOT IN (10147,10134) | `TC_DelayCheck` |
| `TC_DODelayAdj` | INSERT WHERE OperatingStep=10134 AND EndTime='' | `TC_DODelayAdj(Card)` — **10134 = a DO-delay step code** |

### Relay protection
| `TC_RelayProtection$Chk` | UPD tc_job WHERE OutService/InService null↔notnull flips | `TC_RelayProtection$Chk(Circuit)` — recheck relay protection on service change |

### Circuit status integration with FMS
| `tc_status_change1/2/3` | INSERT/DELETE/UPDATE **fms_objectstatus** | `TC_CircuitStatusChange(circuit,circuitstatus)` — **TC reacts to FMS object-status changes** (TC and FMS share the DB) |

### Key generation (manual sequences)
[FACT] `TC_Log$Ins`, `TC_ArchiveLog$Ins`, `TC_ReportStats$Ins2`, `TC_ArchiveReportStats$Ins` all fire `CAC_KeyGeneratorN(TableName, RowTID=new.tid)` on insert → surrogate keys are minted by the shared **CAC_KeyGenerator** family (cross-module key service), plus `tc_lastkey` for table-scoped counters and `tc_lastkeyupd`/`tc_newseq` procs.

---

## 8. DBEVENTS — the async client signalling layer

[FACT - d1.sql:27510-27666] **28 TC dbevents** (each with `grant register`+`grant raise to public`). These push notifications to the TLS client (a separate Tcl/Java app, not the OpenROAD psm.dmt frames — no `tc_`/telephonecard references in psm.dmt or psm_4glprocs.dmt [FACT - grep returned empty]).

Notable: `tc_cardcontroltaken`, `tc_cardrequest`, `tc_cardupdate`, `tc_cardrouteupd`, `tc_jobupdated`, `tc_reloadjob`, `tc_loadcard`, `tc_loadisp`, `tc_statuschange`, `tc_checkoutservice`, `tc_checkrelayprotection`, `tc_defectiverelay`, `tc_protectionupd`, `tc_dodelay`, `tc_delaycleared`, `tc_completeorders`, `tc_processingtrorders`, `tc_returntrorders`, `tc_trordercomplete`, `tc_rtucircuitcomplete`, `tc_rtucircuitpermit`, `tc_processingrtucircuit`, `tc_processingwgresponse`, `tc_returnwgresponse`, `tc_tlswgresponsecomplete`, `tc_refresh_otherdesk`, `tc_systemparameters`.

[INFERENCE] The trouble-order roundtrip with Verizon and the RTU/work-group response handling are event-driven: a daemon raises `tc_processingtrorders`/`tc_returntrorders`/`tc_trordercomplete` as tickets move through Verizon; `tc_refresh_otherdesk` keeps multiple DO desks in sync.

---

## 9. ARCHIVE PATTERN

[FACT] 8 `tc_archive*` tables structurally mirror their live counterparts (`tc_archivecard`↔`tc_card`, `tc_archivejob`↔`tc_job`, etc.). Differences are minor (e.g. live `tc_card` has `priority` and `shownote`; `tc_archivecard` drops `priority`; column ordering of `initialswitchpos`/`finalswitchpos` differs between `tc_job` and `tc_archivejob`).

- [INFERENCE] On card close/completion, the (stubbed) `tc_cardarchiver` proc copies the card and its child rows (`tc_deletecard`, `tc_deletecardjobs`, `tc_deletecardlog`, `tc_deletecardoperstep`, `tc_deletecardreportstats`, `tc_cascadecarddel` procs exist as stubs) into the archive twins and removes the live rows. **Exact logic [UNKNOWN]** — bodies stubbed.
- [FACT] Reporting rollups (`TC_ReportLN$Upd`, `TC_ReportNoOrg$Ins`, `TC_ReportOS$Ins`) trigger off `tc_archivereportstats` INSERTs, confirming report statistics are finalized at archive time.

---

## 10. RELATION TO SOA, FMS, TFMS

| System | Relationship to TC [evidence] |
|--------|------|
| **FMS** | Same Ingres DB [FACT ug.html:5095]. TC reacts to `fms_objectstatus` changes via `tc_status_change1/2/3` rules [FACT d1.sql:33324-33328]. ug.html ties TC tunables to "FMS ETC Deadband" for work-permit alerting [FACT ug.html:6690,6737]. |
| **SOA (=TOMS)** | Shares the `soa_activecard` registry. `SOA_RemoveCardReport2` rule mirrors `TC_RemoveCardReport2` [FACT]. SOA_ActiveCard has an `application char(4)` discriminator [FACT d1.sql DDL]. |
| **TFMS** | `TFMS_NewCardActivated AFTER INSERT INTO SOA_ActiveCard WHERE New.Application <> 'FMS'` [FACT d1.sql:33358] — any non-FMS active card (incl. TLS-origin) flows into TFMS activation. **TC participates in the shared SOA_ActiveCard card registry**, discriminated by `application`. |
| **Common pattern** | TC = FMS = SOA all use the **card → ordered jobs(moves) → workpermit** model with TO/RS two-phase moves, denormalized name caches, archive twins, CAC_KeyGenerator surrogate keys, and dbevent client signalling. TC is the **telephone-line specialization** of that shared switching framework, adding the Verizon electronic-ticket layer (`tc_troublereportorder` + poll/status). |

---

## 11. GAPS / [UNKNOWN]

- **All TC proc bodies are stubbed** → no statement-level lifecycle (insert/issue/complete/archive/undo) recoverable. Only rule guards + param bindings + names are evidence.
- **No seed rows** (external `.ingres` files absent): `tc_card.status` integer codes (only `4`=report-removal observed via rule), `tc_job.status char(3)` codes (only `'Xfr'` observed), `tc_troubletype.type` (Verizon numbers), `tc_troublestatus.status`/`action` enumerations, `cardtype`/`linetype`/`troublecategory`/`functionarea` code lists, `operatingstep` codes (only `10134`,`10147` observed in rules) — all **[UNKNOWN]**.
- `tc_wgrequestack` is a single-column (`requestid`) heap — purpose beyond an ack marker is [UNKNOWN].
- `tc_tempgroupertransfer`, `tc_specialpstsubstation` DDL not fully read here (small; flagged for completeness) — column detail [UNKNOWN beyond name].
- Exact `tc_workpermit.permitjobid` → `tc_job` linkage is [INFERENCE] (name-based), unconfirmed by FK/proc body.
- TLS client UI is **not** in psm.dmt/psm_4glprocs (OpenROAD) — it is an external app; its frame logic is outside these artifacts.
- Prompt's stated column counts (job 43 / card 35 / TRO 36) **do not match the dump** (job 37 / card 29 / TRO 30). Using DDL-verified counts.
