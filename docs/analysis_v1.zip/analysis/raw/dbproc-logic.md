# dbproc-logic — Macro-analysis of the database procedures in d1.sql

Primary artifact: `d:/103_RnD/psm_v1/d1.sql` (33,392 lines). All line numbers below refer to this file.
Every material claim is tagged `[FACT - file->object]`, `[INFERENCE - reasoning]`, or `[UNKNOWN]`.

---

## 0. Headline correction to Ground Truth: 2,450 = 1,225 stubs + 1,225 real bodies

The "2,450 procedures" figure double-counts. The dump defines each procedure **twice**:

1. **Stub pass** (lines 21611–~27757): 1,225 procedures of the exact form
   `create or replace procedure <lowercase_name> as begin return; end` — empty bodies.
   `[FACT - d1.sql:21611 allapp_systemparmsupd / 21615 cac_addrelayopcontrol …]`
2. **Real-body pass** (lines 27758–32778): 1,225 procedures with actual logic, MixedCase/`$`/`_`
   names, body introduced with `=` (or `AS`), terminated by the line `\p\g`.
   `[FACT - d1.sql:27758 ALLAPP_SystemParmsUpd … 32776 XA21_OutageReportIns]`

Counts (mechanical): `create or replace procedure` appears 2,450× total; 1,225 match
`as begin return; end`, 1,225 do not. `[FACT - d1.sql grep/awk over all 2,450 decls]`

**Interpretation** `[INFERENCE]`: the stub pass is a forward-declaration / dependency-bootstrap
section (so rules and inter-proc references resolve at load time); the second pass replaces each
stub with its real body via `create OR REPLACE`. **All business logic lives in the 1,225 real
bodies.** Only the real bodies are analyzed below. `psm_dbprocs.dmt` (the 22-line stub) is
irrelevant, as Ground Truth states.

### Proc body delimiter (learned by reading)
- Header: `create or replace procedure  <Name> ( <params> ) = <body>` — note **two spaces** after
  `procedure`, and `=` (not `AS`) is the usual body operator; a minority use `AS` (e.g.
  `SOA_JobLastKey AS DECLARE…`, `TFMS_CardCheckListInsert … AS BEGIN…`). `[FACT - d1.sql:31449, 32355]`
- Body: optional `DECLARE <vars>;` then `BEGIN … END`.
- Terminator: a line containing exactly `\p\g`. There are 9,770 `\p\g` lines total in the file
  (they also terminate grants/rules/dbevents). `[FACT - d1.sql grep '^\p\g$']`
- Frequently followed by `revoke execute on procedure <name> from public cascade` then `\p\g`
  (internal/rule-only procs); client-callable procs instead get `grant execute … to public`.
  `[FACT - d1.sql:30440 fms_status_change revoke; 21613 allapp grant]`

---

## 1. Distribution by module prefix (1,225 real procs)

Prefix = token before first `_` or `$`, case-folded. `[FACT - awk over 1,225 real proc names]`

| Prefix | Real procs | Notes |
|---|---:|---|
| fms | 352 | Feeder/outage-card mgmt — **largest logic mass** |
| soa | 240 | Switching-order administration (switching orders, in-service permits) |
| ir | 134 | (incident/restoration board feeds) |
| tc | 127 | trouble/tag-card mgmt |
| udb | 70 | core metamodel (object/grouping/terminal/type/key) |
| cac | 42 | relay/card-config + 8 key generators |
| fra | 35 | |
| tfms | 31 | transmission FMS twin |
| slc | 29 | |
| dso | 26 | distribution switching object/geo |
| pvl | 16 | |
| csd | 14 | desk messaging |
| rtu / qgis | 10 / 10 | SCADA RTU; GIS realtime |
| msg | 9 | message routing (raises Msg_* dbevents) |
| tm | 6 | bogey/alert timers |
| sds / oa | 6 / 5 | |
| **Object$/Winding$/CardType$/Grouping$/MemberType$/Terminal$/Type$/SuperType$/…** | ~40 | `$`-named **rule-target** procs (metamodel triggers), not a module — see §5 |

Note: this differs from Ground Truth's *stub-or-combined* counts (fms ~704 etc.) because those
counted **both** passes. Real-body fms = **352**, exactly half of 704. `[INFERENCE - 352×2=704]`

**Where logic concentrates** `[INFERENCE from counts + body reads]`:
- **fms (352) + soa (240) + tc (127) + tfms (31) = 750 procs (61%)** = the switching-order /
  outage-card operational core. This is where the real state machines, dbevent raises, and
  cross-table cascades live.
- **udb (70) + the ~40 `$` rule procs** = the metamodel engine (object lifecycle, grouping/type
  integrity). Small in count, disproportionately load-bearing — every object insert funnels here.
- ir (134) is large but shallow: mostly board-refresh feed writers. `[INFERENCE - names + samples]`

---

## 2. Distribution by verb

### 2a. By name suffix (mechanical, exact) `[FACT - awk over 1,225 names]`

| Class | Count | %  |
|---|---:|---:|
| `*Upd` / `*Update` | 299 + 11 = **310** | 25% |
| `*Ins` / `*Insert` | 247 + 21 = **268** | 22% |
| `*Del` / `*Delete` | 196 + 15 = **211** | 17% |
| `*Validate` | **7** | 0.6% |
| **CRUD-suffixed total** | **796** | **65%** |
| **non-suffixed (verb in name middle / action procs)** | **429** | **35%** |

### 2b. Semantic verb (sampling the 429 non-CRUD procs) `[INFERENCE from name+body reads]`
The non-suffixed 429 hold nearly all the *interesting* logic:
- **status / state-transition**: `SOA_ISPRequestStatusUpd`, `SOA_ISPRequestAccept`,
  `FMS_CardStatusChange`, `FMS_Status_Change`, `TC_UpdateJobStatus`, `FMS_ActivateCard`,
  `FMS_CloseCard`, `FMS_CompleteFGO`, `SOA_IssueISP/IssueMove`, `SOA_ToggleOpenClosed`,
  `tc_completejob/incompletejob/undojob`. `[FACT - d1.sql:31318, 31294, 28490, 29433]`
- **notify / raise-event**: 60 `RAISE DBEVENT` call-sites across ~33 procs (§4). `[FACT]`
- **calc**: `FMS_CalculateDuration`, `TC_CalculateDuration`, `TC_CalculateHoursOut`,
  `Consumer$UpdateLoadModel/LoadPct` (power-flow load math). `[FACT - names; 27996/28003 bodies]`
- **key-gen**: `Udb_NextKey`, `SOA_JobLastKey`, `CAC_KeyGenerator1..8`,
  `CAC_InsertRelayType`, `TC_NewSeq`, `TC_GrouperSeq`, `Udb_NextKey`. `[FACT - 32630, 31449, 27839]`
- **get/select**: essentially **none** server-side. Almost no proc is a pure reader; the few
  that "select" do so into a local var to drive a mutation. `[INFERENCE]` Reads are done by the
  OpenROAD client via direct SELECT (the 4,835 grants include broad `select` on base tables).
  `[INFERENCE - grant pattern + absence of reader procs]`

**Architecture conclusion** `[INFERENCE]`: the DB-proc layer is a **write/command layer** — a
table-access API of fine-grained Ins/Upd/Del wrappers plus a thin layer of state-transition and
event-raising commands. Querying is client-side SQL. This is classic Ingres/OpenROAD "stored
mutation procedure per table operation" style.

---

## 3. Transaction pattern

- **No explicit transaction control in procedures.** `COMMIT`/`ROLLBACK` appears **exactly once**
  in all 33,392 lines: `FMS_SesameLockCard … WHILE … IF iiRowCount=1 THEN FormID=FormID+1; COMMIT;`
  — a deliberate intra-loop commit to release row locks while stamping FormIDs. `[FACT - d1.sql:30679]`
- Therefore procs run inside the **caller's transaction** under Ingres autocommit/session
  semantics; a proc is one logical unit and errors are signalled by **return code**, leaving
  commit/rollback to the client. `[INFERENCE - single COMMIT + ubiquitous RETURN -1 idiom]`
- **dbevents ARE raised inside the (implicit) transaction**, mid-body, after the mutation and
  inside `IF/ENDIF` guards (e.g. `FMS_Status_Change` raises after the `FMS_Card` UPDATE; line
  28572 raises `FMS_Status_Change` then `SOA_ArchiveTrigger` before `RETURN 0`). `[FACT - 29435-29438, 28572]`
  Ingres dbevents are queued and delivered on commit, so there is no nested-txn issue. `[INFERENCE]`

---

## 4. Error-handling & notification idioms (quantified)

| Idiom | Occurrences | Meaning |
|---|---:|---|
| `iierrornumber` | **1,396** | post-statement error check; the dominant control primitive |
| `iirowcount` | 46 | affected-row guard (esp. key-gen `=1` checks) |
| `RETURN 0 / RETURN -1` | pervasive | success/failure contract to OpenROAD caller |
| `RAISE ERROR -<n> :Msg` | **92** | hard abort (rolls back caller txn); `-1`, `-99` common |
| `MESSAGE :Msg` | rare (≈1 std-alone) + inline before RAISE ERROR | pushes text to client session |
| `INSERT INTO Udb_GrassCatcher` | **56** | **soft** validation failure: log a problem row, keep going |
| `RAISE DBEVENT "ingres". <Event> [:payload]` | **60** | async notify other sessions/apps |

Canonical idioms `[FACT]`:
- **Standard CRUD tail**: `… IF iierrornumber = 0 THEN RETURN 0; ELSE RETURN -1; ENDIF; END`
  (or `<>0 THEN RETURN -1`). Seen in the overwhelming majority of Ins/Upd/Del procs.
  `[FACT - e.g. 29403, 28495, 27768]`
- **Hard error**: build `ErrorMsg`, `MESSAGE :ErrorMsg;`, `RAISE ERROR -99 :ErrorMsg;`
  (key generators). `[FACT - d1.sql:27840-27842 CAC_KeyGenerator1]`
- **Cross-module cascade error**: `RAISE ERROR -1 :Msg` with literal text
  `'Error cascading card status change from FMS to SOA.'`. `[FACT - d1.sql:28490-28491 FMS_CardStatusChange]`
- **Soft validation (integrity-in-code)**: write `Udb_GrassCatcher(Object, Problem[, Text])` with a
  symbolic problem code (`'Object_001'`, `'Transformer_003'`, `'Conductor_001'`) instead of
  rejecting. The problem-code→message text mapping requires the **absent** seed rows. `[UNKNOWN - text of each code]`

### dbevent inventory (distinct events raised by procs) `[FACT - grep 'raise dbevent']`
`CSD_MessageSend, DDB_LogEntry, FMS_AutomationGo, FMS_Status_Change, SOA_ArchiveTrigger,
FMS_Feeder_Change, FMS_PhaseCheckCompl, FMS_DeadMovesCount, FMS_DelayCleared, FMS_EstimatedUptime,
FMS_Feeder_Cutout, FMS_DODelay, TM_BogeyAlertCheck, FMS_Card_Grounds, FMS_Update_Grounds,
FRA_DownLoadTimer, IR_FCRDBEvent, IR_FODDBEvent, IR_FeederBoardUpd, Msg_4kvUpdateMsg,
Msg_PriorityUpd, MSG_SendMsg, MSG_MsgAck, QGIS_RealTimeUpdate, SDS_DBUnload, SOA_ActiveListChange,
SOA_CardValidation, SOA_CautionUpd, TC_DelayCleared, TC_Refresh_OtherDesk, tc_statuschange,
TC_DODelay, TC_CheckRelayProtection, TC_CheckOutService, TC_SystemParameters, TC_CardUpdate`.
`SOA_ActiveListChange` is raised from 9 sites and `FMS_Status_Change` from 4 — these are the busiest
broadcast channels. `[FACT - line cluster 30798-31511; 28572/29436/29438/30605]`
**Payload idiom**: a `;`-delimited string built with `VARCHAR(...)` casts, e.g.
`EventText = Varchar(:ActiveCard) + ':' + Varchar(:NewStatus) + ':' + :NewStatusName`. `[FACT - 29437]`

---

## 5. Representative high-value procs (quoted excerpts)

### (a) Metamodel insert resolving Type→subtype table — `object$insert` (rule target) `[FACT - d1.sql:30457]`
Proves the udb_object insert path: resolve `Type → BaseType + TableName` via `Udb_Type`+`Udb_BaseType`,
auto-key from `Udb_LastKey` when `Object=-1`, loop-create `Udb_Terminal`, then dispatch into the
per-type subtype table by `TableName`.
```
create or replace procedure object$insert( Tid INTEGER, Object INTEGER, SystemVersion INTEGER,
 Type INTEGER, PrimaryGrouping INTEGER, Terminals INTEGER ) = DECLARE BaseType INTEGER;
 TableName VARCHAR(20); Loop INTEGER; AddGrouping INTEGER; BEGIN
 SELECT :BaseType = BT.Type, :TableName = BT.TableName FROM "ingres".Udb_Type T,
   "ingres".Udb_BaseType BT WHERE :Type = T.Type AND T.BaseType = BT.Type;
 IF(BaseType = 0) THEN INSERT INTO "ingres".Udb_GrassCatcher (Object,Problem)
   VALUES (:Object,'Object_012'); ENDIF;
 IF (Object = -1) THEN UPDATE "ingres".Udb_LastKey K SET Value = K.Value + 1
   WHERE K.LastKey = 'Object'; SELECT :Object = K.Value FROM ... ; ENDIF;
 ... Loop=1; WHILE Loop<=Terminals DO INSERT INTO "ingres".Udb_Terminal (Object,BaseType,Terminal)
   VALUES (:Object,:BaseType,:Loop); Loop=Loop+1; ENDWHILE;
 IF (TableName='') THEN TableName=TableName;
 ELSEIF (TableName='Conductor') THEN INSERT INTO "ingres".Udb_Conductor (Object) VALUES (:Object);
 ELSEIF (TableName='Generator') THEN INSERT INTO "ingres".Udb_Generator (Object) VALUES (:Object);
 ... [~25 ELSEIF branches: Switch, Transformer, Telemetry, Consumer, Capacitor, Reactor,
       TelephoneCircuit(+Udb_CircuitRoute), EquipTemplate→SLC_EquipTemplate, …] ENDIF; END
```
The `ELSEIF TableName=…` chain is a **hard-coded mirror of `Udb_BaseType.TableName`**; the metadata
that should drive it (the subtype-table list) is duplicated as code. `[INFERENCE]` The actual set of
basetypes/tablenames is seed-row data → not all enumerable here, but the branches above are literal.
`[FACT - 30457-30471]`. `Udb_ObjectIns` (32638) is a *plain* single-table insert wrapper — the
type-resolving logic is in `object$insert`, fired as a rule on `Udb_Object` insert. `[INFERENCE - rule wiring §6]`

### (b) SOA switching-order / permit state-transition — `SOA_ISPRequestStatusUpd` `[FACT - d1.sql:31318]`
Integer status code → status-string constant, dual-table update, audit-log insert. The status
**string** vocabulary is hard-coded in the proc (not seed data):
```
... IF Status = 1 THEN CurrentStatus='REQ_OPEN'; RequestStatus='OPEN'; ...
ELSEIF Status = 2 THEN CurrentStatus='RCC_APPRV'; RequestStatus='RCC_APPRV';
   LogText='Request Approved by '+UpdateByName+'(RCC). Status Changed to '+CurrentStatus;
ELSEIF Status = 4 THEN CurrentStatus='PENDING'; RequestStatus='PENDING'; ...
ELSEIF Status = 8 THEN CurrentStatus='REQ_DENIED'; RequestStatus='DENIED'; ... ENDIF;
UPDATE "ingres".SOA_InServicePermit SET ... Status=:Status, CurrentStatus=:CurrentStatus ...;
IF iierrornumber<>0 THEN RETURN -1; ENDIF;
UPDATE "ingres".SOA_ISPermitRequest SET CurrentStatus=:RequestStatus, ProcessByName=:UpdateByName,
   Remark=:StatusReason WHERE ISPermit=:ISPermit; IF iierrornumber<>0 THEN RETURN -1; ENDIF;
INSERT INTO "ingres".SOA_ISPLog (ISPermit,LogTime,LogUpdateBy,LogItem,LogText,LogType)
   VALUES (:ISPermit,:StatusTime,:StatusUpdateBy,'Request',:LogText,:LogType);
```
Companion `SOA_ISPRequestAccept` (31294) does REQ→ACK: sets `SOA_InServicePermit.CurrentStatus='OPEN'`,
`SOA_ISPermitRequest.CurrentStatus='ACK'`, writes `SOA_ISPLog`. `[FACT - 31295-31298]`
The numeric→string status decode (1/2/4/8 ↔ OPEN/RCC_APPRV/PENDING/DENIED) is the only place these
codes are defined in artifacts; broader status enums elsewhere need seed rows → `[UNKNOWN]`.

### (c) FMS object-status update that raises a dbevent — `FMS_Status_Change` `[FACT - d1.sql:29433]`
Reads latest applicable status from `FMS_ObjectStatus`, resolves its name via `Udb_Type`, conditionally
updates `FMS_Card.FeederStatus`, broadcasts:
```
... SELECT :MaxTimeSet = ifnull(Max(TimeSet),'') FROM "ingres".FMS_ObjectStatus
     WHERE Object=:Object AND Status>10100 AND StatusCount>0;
 IF :MaxTimeSet='' THEN UPDATE "ingres".FMS_Card SET FeederStatus=0, FeederStatusName=''
     WHERE Card=:ActiveCard;
   EventText = Varchar(:ActiveCard)+':'+'0'+':'+'';
   RAISE DBEVENT "ingres".FMS_Status_Change :EventText;
 ELSE SELECT :NewStatus=O.Status, :NewStatusName=T.Name FROM "ingres".FMS_ObjectStatus O,
     "ingres".Udb_Type T WHERE O.Object=:Object AND O.TimeSet=:MaxTimeSet AND O.Status=T.Type ...;
   IF NewStatus<>CurrentStatus THEN UPDATE "ingres".FMS_Card SET FeederStatus=:NewStatus,
     FeederStatusName=:NewStatusName WHERE Card=:ActiveCard;
     EventText=Varchar(:ActiveCard)+':'+Varchar(:NewStatus)+':'+:NewStatusName;
     RAISE DBEVENT "ingres".FMS_Status_Change :EventText; ENDIF; ENDIF; END
```
Magic numbers `Status>10100`, `10031`, `10032`, type-id 10100-band are status-type IDs;
their labels live in seed rows → `[UNKNOWN]`. Pattern (mutate → build delimited payload → raise) is
the template for all status broadcasters. `[INFERENCE]`

### (d) Validation enforcing an integrity rule the schema lacks — `Grouping$Validate` `[FACT - d1.sql:29850]`
The DDL has **no** constraint asserting which (groupingType, memberType, relationship) triples are
legal; this proc enforces it against a **data-driven** catalog `Udb_GroupingValidation`, writing a
GrassCatcher row on violation rather than rejecting:
```
create or replace procedure Grouping$Validate (GroupingType INTEGER, MemberType INTEGER,
 Relationship INTEGER, Member INTEGER) = DECLARE Refs INTEGER; RelationshipName VARCHAR(20); BEGIN
 Refs=0; SELECT Refs = COUNT(*) FROM "ingres".Udb_GroupingValidation GV
   WHERE GV.GroupingType IN (SELECT ET.SuperType FROM "ingres".Udb_ExtendedType ET WHERE :GroupingType=ET.Type)
     AND GV.MemberType   IN (SELECT ET.SuperType FROM "ingres".Udb_ExtendedType ET WHERE :MemberType=ET.Type)
     AND GV.Relationship IN (SELECT ET.SuperType FROM "ingres".Udb_ExtendedType ET WHERE :Relationship=ET.Type);
 IF Refs = 0 THEN SELECT :RelationshipName=T.Name FROM "ingres".Udb_Type T WHERE :Relationship=T.Type;
   INSERT INTO "ingres".Udb_GrassCatcher (Object,Problem,Text) VALUES (Member,'Object_013',RelationshipName);
 ENDIF; END
```
Sibling code-only integrity checks: `MemberType$Validate` (30381, repairs `Udb_Grouping.MemberType`
to the object's true type), `Conductor$Validate` (X/R<5 → 'Conductor_001'), `Winding$Validate`
(8 transformer tap rules → 'Transformer_001..008'), `Object$Validate` (InService>OutService →
'Object_001'), `TapSetting$Validate`, `Terminal$Validate`. **Integrity is overwhelmingly in code,
not constraints.** `[FACT - 30381, 27992, 32767, 30492, 31839, 32330]`

### (e) Key generation via udb_lastkey — `Udb_NextKey` `[FACT - d1.sql:32630]`
`Udb_LastKey(lastkey char(40) not null, value integer not null)`, storage `hash unique`, journaled.
`[FACT - d1.sql:14194-14218]`
```
create or replace procedure Udb_NextKey ( KeyName CHAR(40) NOT NULL ) = DECLARE NewKey INTEGER NOT NULL;
 BEGIN UPDATE "ingres".Udb_LastKey SET Value = Value + 1 WHERE LastKey = :KeyName;
 IF iierrornumber = 0 AND iirowcount = 1 THEN
   SELECT :NewKey = Value FROM "ingres".Udb_LastKey WHERE LastKey = :KeyName;
   IF iierrornumber = 0 and iirowcount = 1 THEN RETURN :NewKey; ELSE RETURN -1; ENDIF;
 ELSE RETURN -1; ENDIF; END
```
Allocation = **UPDATE …+1 then SELECT back**, both guarded by `iierrornumber=0 AND iirowcount=1`
(the `=1` guard is the concurrency/uniqueness safety, since the table is `hash unique`). Variants:
`SOA_JobLastKey` (31449, single-row table, no WHERE), `CAC_KeyGenerator1..8` (27839+, against
`CAC_LastKey` with `MESSAGE`+`RAISE ERROR -99` on failure), inline copies inside business procs
(e.g. `SOA_ISPRequestCopy` does its own `UPDATE Udb_LastKey … 'InServicePermit'` at 31303,
`object$insert` inlines the `'Object'` key at 30459). `[FACT - 31449, 27839, 31303, 30459]`

---

## 6. Rule/dbevent wiring (how these procs fire) `[FACT - d1.sql:32780+]`
The `$`-named procs are **rule action procedures**, not client-called. Example wiring:
```
create rule CardType$Delete AFTER DELETE ON Cac_CardType EXECUTE PROCEDURE "ingres".CardType$Delete(...)
create rule CardType$Insert AFTER INSERT, UPDATE ON Cac_CardType EXECUTE PROCEDURE ...CardType$Insert(...)
create rule CardType$SuperTypeInsert AFTER INSERT, UPDATE ON Udb_SuperType EXECUTE PROCEDURE ...(...)
```
So metamodel integrity (`object$insert`, `*$Validate`, `*$Delete`) is triggered by Ingres rules on
the udb_ tables (290 rules total per Ground Truth), passing `Old.`/`New.` column values as proc args.
`[FACT - 32781-32783]` Full rule catalog is the rules domain's job; noted here to explain *why* so
many procs `revoke execute … from public` (they must only run via the rule engine). `[INFERENCE]`

---

## 7. Procedural LOC estimate

- Real-body region spans lines **27758–32778 ≈ 5,020 physical lines** for 1,225 procs. `[FACT]`
- Physical lines are hard-wrapped at ~200–230 chars; a typical proc body occupies 1–4 physical
  lines. Average ≈ **4.1 physical lines/proc**, but each carries multiple logical statements.
  `[INFERENCE - 5020/1225]`
- Normalizing to conventional ~80-char "logical" statements: the median CRUD proc is ~6–10 logical
  statements; the largest (`object$insert`, `SOA_ISPRequestCopy`, `SOA_ItemIns`, `FMS_Status_Change`,
  the KeyGenerators) are ~25–60 logical statements. `[INFERENCE - body reads]`
- **Estimated total procedural logic: ≈ 12,000–16,000 logical LOC** (≈5k physical wrapped lines
  un-wrapped). The stub pass adds 1,225 trivial lines (ignore). `[INFERENCE]`

Largest individual procs (by un-wrapped statement count, from body reads): `object$insert` (~25
INSERT branches), `SOA_ISPRequestCopy` (31300, two big column-list INSERT…SELECT + log + attachment
copy), `SOA_ItemIns` (31395, ~30 params), `Object$PrimaryGrouping` (30496, load-model arithmetic),
`SOA_ISPRequestStatusUpd` (31318). `[FACT - line spans + reads]`

---

## 8. Maintainability assessment `[INFERENCE unless tagged FACT]`

**Naming discipline — GOOD/mixed.**
- Strong convention: `<Module>_<Entity><Verb>` with `Ins/Upd/Del` suffix; rule procs use
  `<Type>$<Event>`. 65% of procs follow the CRUD-suffix convention mechanically. `[FACT]`
- **Case is inconsistent** (`CAC_*` vs `cac_*`, `tc_cardins` vs `TC_InsertCard`,
  `dso_object$del` vs `DSO_ObjectIns`) — harmless to Ingres (case-insensitive) but noisy. `[FACT - name list]`
- Verb placement inconsistent: both `TC_InsertCard` and `tc_cardins`, `TC_DeleteCard` and
  `tc_undojob` coexist → no single grep finds "all inserts". `[FACT]`

**Duplication — HIGH.**
- `CAC_KeyGenerator1..8` are 8 near-identical bodies differing only in the `ELSEIF TableName='…'`
  branch — textbook copy-paste; should be one table-driven proc. `[FACT - 27839-27895]`
- The key-allocation idiom (`UPDATE Udb_LastKey +1 / SELECT back`) is **inlined** in dozens of procs
  instead of calling `Udb_NextKey` (e.g. `object$insert`, `SOA_ISPRequestCopy`, `CAC_InsertRelayType`,
  `FMS_SaveEquipJob`). `[FACT - 30459, 31303, 27836, 29352]`
- The CRUD-tail `IF iierrornumber=0 THEN RETURN 0; ELSE RETURN -1; ENDIF` is repeated ~hundreds of
  times. `[FACT - 1,396 iierrornumber sites]`
- `FMS_Validate*` family (29546-29588: Card/CardClass/Equip/EquipClass/Feeder/JobClass/Operator/StepPair)
  share an identical `SELECT COUNT(*) … IF i=0 …` skeleton. `[FACT - 29546+]`
- `*_archiver`/`*ArchiveCard` and `Validate*FeederEquip` appear duplicated across fms/tc/tfms/soa
  (e.g. `FMS_ValidateFeederEquip` 29573 vs `TFMS_ValidateFeederEquip` 32453 — same body, extra param). `[FACT]`

**Length — GOOD.** Procs are short and single-purpose; no monolithic 500-line procedures. Worst
cases stay under ~60 statements. Cyclomatic complexity is concentrated in the `ELSEIF`-ladder
dispatchers (`object$insert`, `SOA_ISPRequestStatusUpd`, `TFMS_CheckListUpd` field-name switch). `[INFERENCE]`

**Integrity-in-code risk — HIGH.** With ~290 rules + ~56 GrassCatcher-writing validators + only
soft logging on violation, **bad data is logged, not blocked**; correctness depends entirely on the
client honoring GrassCatcher and on rules firing. Hard FK/CHECK constraints are largely absent from
the DDL (per Ground Truth: no view/constraint emphasis), pushing all referential logic into procs
and rules. `[INFERENCE - 56 GrassCatcher inserts + rule-driven validation]`

**Transaction risk — MEDIUM.** Reliance on caller-managed transactions + autocommit means a proc
that returns `-1` midway (after a successful first UPDATE) leaves partial writes unless the *client*
rolls back. Several multi-statement procs `RETURN -1` between writes with no compensating rollback
(e.g. `SOA_ISPRequestStatusUpd`, `SOA_ISPRequestCopy`). `[FACT - 31296/31307 return -1 after prior inserts]`

---

## 9. Gaps / UNKNOWNs
- All status-code → label mappings, type/basetype/supertype enumerations, GrassCatcher problem-code
  text, relationship codes (52=member-of, 53=…) require the absent `*.ingres` seed rows. `[UNKNOWN]`
- `Udb_BaseType.TableName` full value set: only the ~25 literals hard-coded in `object$insert` are
  observable; the catalog's complete row set is unknown. `[UNKNOWN]`
- Whether the 1,225 stubs map **1:1** onto the 1,225 real bodies was confirmed only by equal counts
  and matching name prefixes, not a full diff. `[INFERENCE - count parity + spot checks]`
- Magic status thresholds (`Status>10100`, `10031/10032`, `Status=20`, `Relationship=52/53`) are
  used but their semantic definitions are seed-data. `[UNKNOWN]`
