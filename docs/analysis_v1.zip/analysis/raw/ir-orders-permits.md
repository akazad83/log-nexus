# IR Subsystem — Operating Orders, Work Permits, Telephone (Carrier) Orders

Domain: `ir-orders-permits` (group: subsystem). Primary artifact: `d:/103_RnD/psm_v1/d1.sql`.
Scope: 38 `ir_` tables, 134 distinct `IR_*` procedures. Cross-refs: `ug.html` (business semantics), `tc_`/`udb_`/`rtu_` (Telephonic Line Systems binding), `soa_`/`fms_` (permit/job layers), `msg_` (messaging spine).

---

## 0. CRITICAL ARTIFACT FINDINGS (read first)

1. **Two proc-definition blocks exist in d1.sql.** [FACT - d1.sql]
   - **Stub block** (~lines 23591-24115): `create or replace procedure ir_NAME as begin return; end` — ALL 134 IR procs appear here as empty placeholders, each followed by `grant execute on procedure ir_NAME to public`. These contain ZERO logic. [FACT - d1.sql:23591-24115]
   - **Real block** (~lines 29868-30357): `create or replace procedure  IR_PascalName ( params ) = BEGIN ...real body... END` — Ingres parameterized-procedure syntax with actual SQL. THIS is where IR server logic lives. [FACT - d1.sql:29868-30357]
   - Global count: of 2,450 procs in d1.sql, **1,163 are one-line stubs**; ~1,287 carry real bodies. IR's logic is fully present in the real block. The ground-truth "psm_dbprocs.dmt is a stub" warning ALSO applies to the stub block inside d1.sql itself. [FACT - d1.sql grep counts]

2. **IR procs do NOT raise IR dbevents.** `raise dbevent ir_*` count in d1.sql proc bodies = **0**. The 35 `ir_*` dbevents (declared at d1.sql:26888-27092) are raised from the OpenROAD client (psm.dmt) and/or via FMS rules, not from server procs. [FACT - d1.sql grep `raise dbevent ir_`]

3. **No row data anywhere** (per ground truth — all tables `copy ... from '/home/ingres/Downloads/*.ingres'`, files absent). Therefore every `orderstatus`/`permitstatus`/`rfpstatus`/`ordertype`/`ordertarget` integer code enumeration is **[UNKNOWN]** — no seed rows to decode them. Only literal codes hard-wired in proc bodies are known (see §6). [INFERENCE - ground truth + DDL]

---

## 1. IR ROLE

IR = **Issue/Return orchestration layer** for switching-order execution. It is NOT a standalone metamodel; it is the *server-side write API + state machine* that the OpenROAD switching applications (FMS=feeder, SOA=in-service, TC=telephone-circuit, FOD=field-operations) call to **issue operating orders to the field, track acknowledgement/rejection, and process the return** of completed work. Evidence: IR procs write across module boundaries —
- `IR_CompletePermit` updates **`SOA_Job`** (RSComplete/RSOperator/Response). [FACT - d1.sql:29903]
- `IR_WorkPermitUpdate` updates **`FMS_Workpermit`** (AcknowledgedByFCR/AcknowledgedTime). [FACT - d1.sql:30351]
- `IR_TLSCompleteJob` updates **`TC_Job`** (TOComplete/RSComplete + ResultsCode). [FACT - d1.sql:30260-30262]
- `IR_FMSJobUpdate` is invoked by rules on **`SOA_Job`** TO/RS Issued/Complete timestamps. [FACT - d1.sql:33097-33103]

So "IR" most plausibly = **Issue/Return** (operating-order issue → field execution → return), spanning three order classes: operating orders (FMS/SOA), FOD field orders, and telephone/TLS carrier orders. The literal expansion of the acronym is **[UNKNOWN]** (ug.html TOC uses "TLS Menu", "Work Permit", "Operating Order" but never expands "IR"). [INFERENCE]

---

## 2. TABLE CATALOG (38 tables)

Storage: every IR table is `btree` (PK unique except `ir_operatingorder` btree on `substation`, `ir_telephoneorder` btree on `circuit` — both non-unique secondary-key storage), page_size 8192, journaling on. [FACT - d1.sql modify statements]

| # | Table | line | Cols | PK / storage key | Role |
|---|-------|------|------|------------------|------|
| 1 | ir_operatingorder | 6190 | 28 | btree on **substation** (non-unique) | SSO operating order header |
| 2 | ir_oporderfeeders | 6243 | 6 | — | feeders/equip on an order; **ispermit** links SOA in-service permit |
| 3 | ir_oporderjobs | 6277 | 6 | (job,seq,tors,ordernumber) | order→job linkage (tors=ToRs leg) |
| 4 | ir_oporderobjectives | 6311 | 5 | (objective,seq,ordernumber) | order objectives |
| 5 | ir_opordersteps | 6343 | 7 | — | operating steps + status + starttime |
| 6 | ir_workpermit | 6980 | 31 | btree unique on **workpermit** | FCR work-permit header (request→issue→return) |
| 7 | ir_worklocation | 6890 | 17 | (workpermit,wplocation) | permit work locations; links rfp/requestforpermit |
| 8 | ir_worklocationtag | 6933 | 19 | — | tags placed at permit locations |
| 9 | ir_workequipment | 6832 | 5 | (workpermit,equip) | equip under a permit |
| 10 | ir_downloadequip | 5670 | 6 | (workpermit,equip) | equip downloaded to permit; returnfgo/returnpermit |
| 11 | ir_downloadmove | 5702 | 20 | — | per-move download checklist (backfeed/highpot/phaseground/ammeterclear) |
| 12 | ir_downloadmove… engagelastdownload | 5749 | 2 | — | last ISWP/OR download timestamps (singleton) |
| 13 | ir_requestforpermit | 6452 | 19 | (rfp,revisionnumber) | RFP header (revisioned) |
| 14 | ir_rfplocation | 6610 | 8 | (rfp,revisionnumber,…) | RFP locations |
| 15 | ir_rfplocationtag | 6645 | 16 | — | tags requested at RFP locations |
| 16 | ir_rfpequipment | 6579 | 4 | (rfp,revisionnumber,equipname) | equip on RFP |
| 17 | ir_telephoneorder | 6689 | 24 | btree on **circuit** (non-unique) | TLS/carrier order header |
| 18 | ir_tlsorderjob | 6739 | 5 | (job,seq,tors,ordernumber) | TLS order→job |
| 19 | ir_tlsorderjobresult | 6772 | 5 | — | TLS job result codes/text |
| 20 | ir_returnrelay | 6526 | 27 | btree unique on **job** | relay-target return readings (5051/67/46 phase A/B/C/N inst/time) |
| 21 | ir_returnequipstatus | 6497 | 3 | (msgkey,equipstatus) | equip status text on return msg |
| 22 | ir_relaytargets | 6409 | 16 | — | relay-target instructions (typea/b/c/time/inst, isverbal) |
| 23 | ir_phases | 6377 | 8 | — | phase A/B/C dead checks + final phases |
| 24 | ir_hvphases | 6128 | 6 | — | HV phase checks |
| 25 | ir_highpottestresults | 6095 | 8 | — | high-pot test results |
| 26 | ir_backfeed | 5612 | 2 | — | per-job backfeed status |
| 27 | ir_commonlocation | 5639 | 6 | — | common-location conflict/TC/phase |
| 28 | ir_locationxferlink | 6158 | 6 | — | permit↔ISO/RFP location transfer link |
| 29 | ir_faultchange | 5775 | 10 | — | FOD fault response/ack |
| 30 | ir_fgorejection | 5809 | 10 | — | FGO (field-generated order?) rejection/ack |
| 31 | ir_fodorder | 5878 | 22 | — | FOD field-ops order header |
| 32 | ir_fodorderjobs | 5925 | 23 | — | FOD order jobs |
| 33 | ir_fodcrewassign | 5844 | 8 | — | FOD crew assignment |
| 34 | ir_fodtag | 5975 | 17 | — | FOD-placed tags |
| 35 | ir_fodtaglocation | 6020 | 18 | — | FOD tag locations + ack/replacement |
| 36 | ir_fotcount | 6064 | 7 | — | FOT (feeder-out-test?) counts |
| 37 | ir_workinggroup | 6863 | 2 | (jobclass,workinggroup) | jobclass→working group map |
| 38 | ir_typetranslation | 6805 | 2 | (type,rrtype) | type→relay-return type map |

Column counts verified by DDL read; the assignment-stated counts (operatingorder 34 / workpermit 36 / telephoneorder 31) do **not** match the actual DDL: ir_operatingorder=**28**, ir_workpermit=**31**, ir_telephoneorder=**24** columns. [FACT - d1.sql DDL] — flagging contradiction with the task brief.

---

## 3. KEY TABLE DEEP-READS

### 3.1 ir_operatingorder (28 cols) [FACT - d1.sql:6190]
PK-ish identity `ordernumber`; `application char(4)`, `card`, `switchingitem`, `substation`, `ordertarget char(4)`, `ordertype varchar(14)`, `busconfiguration`, `orderstatus int`, `priority int`. Lifecycle timestamp/actor quads:
- issue: `issuedbydo`, `bydesk`, `issuetime`
- download: `downloadtime`
- ack/reject: `ackrejecttime`, `ackrejectbysso`, `ackrejectcomment(1500)`
- return: `returntime`, `returnbysso`, `returncomment(1500)`
- rescind: `rescindtime`, `rescindtype varchar(7)`, `rescinddo`, `rescindreasontype int`, `rescindreasontypename`, `rescindcomment(500)`
- `msgkey int` → messaging spine.
Note: "by**SSO**" on ack/return ⇒ the field/substation operator (SSO) acknowledges; "by**DO**" on issue/rescind ⇒ the dispatcher (DO). [INFERENCE - column naming, DO vs SSO]

### 3.2 ir_workpermit (31 cols) [FACT - d1.sql:6980]
Identity `workpermit`; `replacespermitid`, `revisionnumber`, `revisiondate`, `revisioncomment` ⇒ revisioned. `targetfcr char(1)`, `doname`, `fcremployeeobjectid` ⇒ FCR (Field Crew Representative) ownership. Return block: `returnedtime`, `backfromworkstatus char(3)`, `continuity char(3)`/`continuityequipment`, `caution char(3)`, `urgentrestoration char(3)`. High-pot block: `highpottype char(8)`, `highpotkv`, `highpotduration`, `highpotauthorization`, `highpotwaivednyse char(3)`. Equip dropped/picked descriptors. Return-reject block: `returnrejecttime`, `returnrejectdo`, `returnrejectreason(400)`. `permitstatus int`, `protectionmovecount int`, `msgkey int`.

### 3.3 ir_telephoneorder (24 cols) [FACT - d1.sql:6689]
Identity `ordernumber`; **`circuit int`** (storage key) → the telephone circuit object; `card`, `substation`, `ordertype varchar(20)`, `ordertarget varchar(20)`, `orderstatus`, `priority`. Same issue/download/ack-reject/return/rescind quads as operatingorder but narrower comments (varchar(400)). `msgkey int`. **This is the leased-carrier (Verizon) circuit order header.** [FACT + INFERENCE — see §5]

### 3.4 ir_returnrelay (27 cols) [FACT - d1.sql:6526]
Keyed by `job` (btree unique). 8 relay-element groups, each {indicator `*i`, target `*t`, timestamp `*ts`}: `rt5051a/b/c/n` (50/51 overcurrent phase+neutral), `rt67a/b/c/n` (67 directional o/c), `rt46to`+`rt46tts` (46 negative-sequence). + `relaycomment(60)`. ⇒ structured capture of **relay targets that operated**, returned with the permit/order. [INFERENCE — ANSI device-number convention 50/51/67/46]

### 3.5 ir_returnequipstatus (3 cols): `(msgkey,equipstatus)` + `equipdesc(1500)` — equip status lines attached to a return message. [FACT - d1.sql:6497]
### 3.6 ir_workequipment (5 cols): `(workpermit,equip)` + `type`,`groupname`,`source char(2)`. [FACT - d1.sql:6832]
### 3.7 ir_rfpequipment (4 cols): `(rfp,revisionnumber,equipname)` + `type`. [FACT - d1.sql:6579]
### 3.8 ir_downloadequip (6 cols): `(workpermit,equip)` + `type`,`returnfgo`,`returnpermit`,`source char(2)` — tracks which permit/FGO the equip was returned to. [FACT - d1.sql:5670]
### 3.9 ir_oporderobjectives (5 cols): `(objective,seq,ordernumber)` + `description(40)`,`comment(500)`. [FACT - d1.sql:6311]

---

## 4. LIFECYCLES (proc-body evidence)

### 4.1 Operating-order lifecycle
- **Insert/Issue**: `IR_OperatingOrderIns(...) = BEGIN INSERT INTO IR_OperatingOrder (...,Priority) VALUES (...,100); ...END` — note hard-coded **Priority=100** on insert. [FACT - d1.sql:30127-30130]
- **Status advance**: `IR_OrderStatusUpd(OrderNumber,OrderStatus,IssueTime) = ... IF IssueTime is NULL OR ='' THEN UPDATE ... SET OrderStatus ... ELSE UPDATE ... SET OrderStatus, IssueTime=IFNULL(:IssueTime,IssueTime)`. [FACT - d1.sql:30160-30161]
- **Download**: `IR_DownloadTimeUpd` sets `DownloadTime` + `OrderStatus`. [FACT - d1.sql:29948]
- **Ack/Reject**: `IR_OpOrderAckRejUpd` sets `AckRejectTime/Comment/BySSO + OrderStatus`. [FACT - d1.sql:30132-30134]
- **Return/Complete**: `IR_CompletedTimeUpd(OrderNumber,OrderStatus,ReturnTime,ReturnBySSO,ReturnComment)` updates IR_OperatingOrder. [FACT - d1.sql:29900]
- **Rescind**: `IR_OpOrderRescindUpd` sets OrderStatus + rescind quad. [FACT - d1.sql:30148]
- **Priority change**: `IR_OpOrderPriorityUpd` → and rule `Msg_PriorityUpd$1` propagates to Msg_Message. [FACT - d1.sql:30146, 33123]
- Child writers: `IR_InsertOpOrderJobs`, `IR_OpOrderFeedersIns/Del/Upd`, `IR_OpOrderStepsIns/Del/Upd`, `IR_OpOrderObjectiveIns`, `IR_DelOrderSubJobs`/`IR_DelCompleteSubJobs` (DELETE FROM SOA_JOB where job in IR_OpOrderJobs). [FACT - d1.sql:30108,30135-30157,29923-29928]

```
ir_operatingorder.orderstatus path (codes UNKNOWN — no seed rows):
  Ins(prio=100) -> OrderStatusUpd(+IssueTime) -> DownloadTimeUpd -> OpOrderAckRejUpd
     -> CompletedTimeUpd(ReturnBySSO)   |  (OpOrderRescindUpd at any point)
```

### 4.2 Work-permit lifecycle (request → issue → return)
- **Request (RFP)**: `IR_RFPIns` inserts revisioned RFP (real body not separately quoted; companion `IR_LinkRFPCard` sets Card, RequestForPermit=0). [FACT - d1.sql:30116]
- **RFP acknowledge/reject/revise**: `IR_AcknowledgeRFP(RFP,RevisionNumber,AcknowledgedByDO,RejectedByDO,RevisionRequestedByDO,MsgKey,DOComment) = BEGIN UPDATE IR_RequestForPermit SET ... WHERE RFP=:RFP AND RevisionNumber <= :RevisionNumber`. [FACT - d1.sql:29871-29873]
- **Create permit**: `IR_NewFCRWorkPermit(WorkPermit,ReplacesPermitID,RevisionNumber) = INSERT INTO IR_WorkPermit(...)`. [FACT - d1.sql:30124-30125]
- **Issue permit**: `IR_IssueFCRWorkPermit(TargetFCR,DOName,PermitStatus,ProtectionMoveCount,WorkPermit) = UPDATE IR_WorkPermit SET TargetFCR,DOName,PermitStatus,ProtectionMoveCount`. [FACT - d1.sql:30111-30112]; `IR_IssuePermitMsgUpd` stamps MsgKey. [FACT - d1.sql:30114]
- **Ack at location**: `IR_WorkPermitAck(WorkPermit,WPLocation,LocationStatus)` — if WPLocation=0 updates all locations except `'TAG LATER'`; else one location. [FACT - d1.sql:30343-30344]
- **Return**: `IR_ReturnWorkPermit(...)` updates IR_WorkPermit return/continuity/highpot/equip-dropped-picked fields; `IR_ReturnFCRWPLocation` sets LocationStatus/WorkSummary/XferToIso/XferToRFP; `IR_ReturnFCRWPTags` sets TagDisposition; `IR_ReturnWorkEquip` flips DownloadEquip.ReturnFGO or ReturnPermit. [FACT - d1.sql:30215,30193,30196,30212-30214]
- **Reject return**: `IR_RejectPermit(WorkPermit,ReturnRejectTime,ReturnRejectDO,ReturnRejectReason,MsgKey,PermitStatus) = UPDATE IR_WorkPermit SET reject-quad,PermitStatus; ... UPDATE IR_DownloadEquip SET ReturnPermit=0 WHERE ReturnPermit=:WorkPermit`. [FACT - d1.sql:30174-30177]
- **Status/comment/revision**: `IR_WorkPermitStatusUpd`, `IR_WorkPermitCommentUpd`, `IR_WPRevisionUpd`. [FACT - d1.sql:30348,30354]
- **Cross-module completion**: `IR_CompletePermit(Job,RSComplete,RSOperator,Response) = UPDATE SOA_Job SET RSComplete,RSOperator,Response`; `IR_WorkPermitUpdate(Job,AcknowledgedByFCR,AcknowledgedTime) = UPDATE FMS_Workpermit`. [FACT - d1.sql:29903,30351]
- Cascade: `IR_CascadeWPLocDel` deletes WorkLocationTag then WorkLocation (rule-fired). [FACT - d1.sql:29888 + rule 33091]
- Tag copy helpers: `IR_CopyRFPTagsToWP`, `IR_CopyWPTagsToRFP`, `IR_CopyBTLocationTags`, `IR_TransferRFPTags`. [FACT - d1.sql:29913,29917,29906]

```
RFP (revisioned) --AcknowledgeRFP/Reject/RevisionRequest--> NewFCRWorkPermit
   --IssueFCRWorkPermit(TargetFCR,ProtectionMoveCount)--> DownloadEquip
   --WorkPermitAck(per-location, skip 'TAG LATER')--> [field work]
   --ReturnWorkPermit + ReturnFCRWPLocation + ReturnFCRWPTags + ReturnWorkEquip--> 
        --> (RejectPermit -> back) | CompletePermit(SOA_Job) / WorkPermitUpdate(FMS_Workpermit)
```

### 4.3 Telephone (carrier) order + relay-return lifecycle
- **Insert/Issue**: `IR_TelephoneOrderIns(OrderNumber,Card,Circuit,Substation,OrderTarget,OrderType,IssuedByDo,IssueComment,IssueTime,OrderStatus) = INSERT INTO IR_TelephoneOrder(...,Priority) VALUES(...,100)` — Priority=100 hard-coded. [FACT - d1.sql:30256-30258]
- **Download**: `IR_TLSDownloadTimeUpd`. [FACT - d1.sql:30264]
- **Ack/Reject**: `IR_TLSOrderAckRejUpd` (AckRejectBySSO). [FACT - d1.sql:30272-30273]
- **Return**: `IR_TLSOrderReturned(OrderNumber,OrderStatus,ReturnTime,ReturnBySSO,ReturnComment)`. [FACT - d1.sql:30284-30285]
- **Status/Priority/Rescind**: `IR_TLSOrderStatusUpd`, `IR_TLSOrderPriorityUpd` (+ rule Msg_PriorityUpd$2), `IR_TLSOrderRescindUpd`. [FACT - d1.sql:30287,30278,30280, rule 33125]
- **Jobs/results**: `IR_TLSOrderJobIns`, `IR_TLSJobResultIns` (→ IR_TLSOrderJobResult). [FACT - d1.sql:30275,30267]
- **Complete job → TC_Job**: `IR_TLSCompleteJob(Job,TORS,...) = IF (TORS=0) THEN UPDATE TC_Job SET TOComplete,TOOperator,ResultsCode... ELSE UPDATE TC_Job SET RSComplete,RSOperator,ResultsCode...`. **TORS toggles the TO (issue/Take-Out) vs RS (Restore) leg.** [FACT - d1.sql:30260-30262]
- **Relay return**: `IR_ReturnRelayIns(Job, RT5051*, RT67*, RT46*, RelayComment) = INSERT INTO IR_ReturnRelay(...)`. [FACT - d1.sql:30205-30207]

```
TLS order: TelephoneOrderIns(circuit,prio=100) -> TLSDownloadTimeUpd -> TLSOrderAckRejUpd
   -> TLSCompleteJob(TORS:0=TO,else=RS -> TC_Job) -> TLSOrderReturned(ReturnBySSO)
   relay readings captured via ReturnRelayIns -> IR_ReturnRelay
```

---

## 5. TELEPHONIC LINE SYSTEMS / Verizon binding

- `ir_telephoneorder.circuit` (storage key) → a **telephone circuit object**, modeled in `udb_telephonecircuit` (PK `object`), which carries RTU/EMS plumbing: `rtucircuittype`, `rtunumber`, `rtuaddress`, `eccemschannel`, `eccfep`, `ecctcpport`, `accemschannel`, `accfep`, plus `rtu2*` for dual-RTU, and `altlinetype1/2`+`altline1/2`. [FACT - d1.sql udb_telephonecircuit DDL]
- `IR_TLSCompleteJob` writes **`TC_Job`** (the TC/telephone-circuit job table, with `circuit`, `linenumber`, `tomove/rsmove`, `inservice/outservice`, `resultscode`). The IR telephone order is the *issue/return wrapper* around TC jobs. [FACT - d1.sql:30260 + tc_job DDL]
- **Verizon/leased-carrier**: `tc_verizoncircuit(circuit, linename)` exists — explicit leased-carrier line registry. ug.html TOC sections: "TLS / Verizon Line Conversion", "TLS / Verizon Substation Access", "TLS / Verizon Types and Statuses". [FACT - d1.sql tc_verizoncircuit; ug.html:4443,4467,4491]
- ug.html narrative: Task Monitor handles a **PSTN operating step** in TLS — set when the "PST Support Request" move is issued; sends email to groups; on Bogey Alert resends to non-responders. [FACT - ug.html ~10709-10760]
- **RTU binding**: `rtu_circuitmapping(circuit,pvc,cc,t1,label,...)`, `rtu_circuitprovider(provider)`, `rtu_circuitrouter`, `rtu_substation`, `rtu_workissue(workissueid,rtucircuit,workissuetext,currentstatus,...,dogenerated,msgid)`, `rtu_workissuelog`. `tc_workpermit.rtuworkissue`+`dogeneratedwi` link TC permits to `rtu_workissue`. [FACT - d1.sql rtu_* + tc_workpermit DDL]
- EMS/SCADA: `udb_telephonecircuit.eccemschannel/eccfep` + `xa21_*` (SCADA) — the leased circuit is the telemetry path to RTUs; IR telephone orders coordinate taking that circuit out / restoring it. [INFERENCE - column names + ground-truth EMS/SCADA note]

`ir_typetranslation(type,rrtype)` and `ir_relaytargets`/`ir_returnrelay` tie relay-target *instructions* (issued) to relay-target *returns* (operated) — the relay-protection content of a telephone/operating order. [INFERENCE - table pairing]

---

## 6. KNOWN literal codes (only what's hard-wired in proc bodies)

| Source | Literal | Meaning (proc-evident) |
|--------|---------|------------------------|
| `IR_OperatingOrderIns`, `IR_TelephoneOrderIns` | `Priority = 100` | default priority on insert [FACT - d1.sql:30130,30258] |
| `IR_WorkPermitAck` | `LocationStatus <> 'TAG LATER'` | bulk-ack skips locations pending tagging [FACT - d1.sql:30343] |
| `IR_FODTagDODel` | `TagStatus = 'REMOVED BY DO'` | DO removes a FOD tag [FACT - d1.sql:30057] |
| `IR_TLSCompleteJob` | `TORS = 0` → TO leg, else RS leg | take-out vs restore [FACT - d1.sql:30260] |
| `IR_LinkRFPCard` | `RFPStatus`/`RequestForPermit = 0` | unlink on card link [FACT - d1.sql:30116] |

All numeric `orderstatus`/`permitstatus`/`rfpstatus`/`ordertype`/`ordertarget` enumerations: **[UNKNOWN]** — require absent seed rows. Do not fabricate.

---

## 7. IR vs SOA permits — overlap / layering

These are **distinct layers, not duplicates**:
- **SOA** owns the *permit data model* for in-service work: `soa_inservicepermit` (32 cols — ispermit, job, division, substation, workgroup, jurisdiction, currentstatus/status, NYISO/NYPA notification, compliance, denycategory), `soa_workpermit`, `soa_ispermitrequest`, `soa_ispwithdrawpermit`, `soa_outagerequestpermit`, `soa_archiveworkpermit`. [FACT - d1.sql soa_* DDL]
- **IR** owns the *issue/return transaction* for the **FCR work permit** flavor (field-crew, feeder-level): `ir_workpermit` + `ir_worklocation`/`ir_worklocationtag`/`ir_workequipment`/`ir_downloadequip`. Different PK (`workpermit` vs SOA `ispermit`/`permitjobid`), different columns (FCR/continuity/highpot/relay focus vs NYISO/jurisdiction/compliance focus). [FACT - DDL comparison]
- **Bridge**: `ir_oporderfeeders.ispermit` is the **only structural link to SOA in-service permits** — an operating order's feeders can reference an `ispermit` (SOA in-service permit id). `IR_OpOrderFeedersUpd(OrderNumber,ISPermit)` rewires it; `IR_OpOrderFeedersDel` deletes by ISPermit OR OrderNumber. [FACT - d1.sql:6243 col `ispermit`; 30135-30141]
- **Job bridge**: IR procs read/write `SOA_Job` (`IR_CompletePermit`, `IR_DelOrderSubJobs`, `IR_DelCompleteSubJobs`) and rules `IR_FMSJob*` fire on `SOA_Job` TO/RS Issued/Complete. So SOA holds the switching jobs; IR issues/returns them and writes back completion. [FACT - d1.sql:29903,29923-29928,33097-33103]
- `fms_workpermit` (9 cols) and `tc_workpermit` (12 cols) are yet-different per-module permit extensions (FMS feeder, TC circuit) — IR also writes `FMS_Workpermit` via `IR_WorkPermitUpdate`. [FACT - d1.sql fms_workpermit/tc_workpermit DDL]

**Conclusion**: SOA = system-of-record for in-service/outage permits + switching jobs (regulatory: NYISO/NYPA/compliance). IR = the order-issue/field-return state machine that drives those jobs to the field across feeder (FMS), in-service (SOA), telephone-circuit (TC), and field-ops (FOD) channels, writing completion back into SOA_Job/FMS_Workpermit/TC_Job. They overlap only at the `ispermit`/`job` join keys; no column duplication of the permit body. [INFERENCE - evidence above]

---

## 8. Rules & dbevents touching IR

Rules (d1.sql:33091-33366) [FACT]:
- `IR_CascadeWPLocDel` AFTER DELETE ON `IR_WorkLocation` → cascade-deletes tags+location.
- `ir_closecard` AFTER UPDATE(status) of `fms_card` (new.status>=50, old<50, cardclass<>'TEST') → `ir_closecard`.
- `IR_FeederTCOff` AFTER DELETE FROM `FMS_ObjectStatus` WHERE Old.Status=20104 → `IR_FeederTCOff(Feeder)`. (status 20104 = some feeder TC state; meaning [UNKNOWN] beyond literal). 
- `IR_FMSJobRSComplete/RSIssued/TOComplete/TOIssued` AFTER UPDATE on `SOA_Job` → `IR_FMSJobUpdate(Action='RC'|'RI'|'TC'|'TI')`.
- `Msg_PriorityUpd$1` on `IR_OperatingOrder`, `Msg_PriorityUpd$2` on `IR_TelephoneOrder` (Priority change, MsgKey<>0) → `Msg_PriorityUpd` → updates `Msg_Message` and `RAISE DBEVENT Msg_PriorityUpd 'MsgKey;Priority;'`. [FACT - d1.sql:33123-33125,30404-30405]
- Task-Manager alert rules: `TM$OpOrderStatusUpd` (IR_OperatingOrder.OrderStatus change), `TM$WPStatusUpd` (IR_WorkPermit.PermitStatus change), `TM$FODOrderStatusUpd` (IR_FODOrderJobs.JobStatus change) → `TM$AlertUpdate`. [FACT - d1.sql:33362-33366]

dbevents declared (d1.sql:26888-27092, 35 total) [FACT] — e.g. `ir_processingorders`, `ir_returnorders`, `ir_orderscomplete`, `ir_processingpermit`, `ir_returnpermit`, `ir_permitcomplete`, `ir_processingtlsssoorders`, `ir_returntlsssoorders`, `ir_tlsssoordercomplete`, `ir_reviewrfp`, `ir_processingfodorders`, `ir_returnfodorders`, `ir_completefodorders`, `ir_liftcaution`/`ir_completecaution`/`ir_processingcaution`, `ir_processingfault`/`ir_reviewfault`/`ir_faultreviewed`, `ir_processingfgo`/`ir_fgocomplete`/`ir_ackfgorejection`-path, `ir_feederboardsyn`/`ir_feederboardupd`, plus per-app channels `ir_fcrdbevent`/`ir_foddbevent`/`ir_fssdbevent`/`ir_soodbevent`/`ir_tlsdbevent`. **None raised from d1.sql proc bodies** — raised by OpenROAD client / FMS rules. The naming triplet pattern `processing*`/`return*`/`*complete` mirrors the issue→return→complete lifecycle and is the client-notification spine. [FACT names; INFERENCE pattern]

---

## 9. Messaging spine (msgkey)

`ir_operatingorder.msgkey`, `ir_workpermit.msgkey`, `ir_telephoneorder.msgkey`, `ir_returnequipstatus.msgkey`, `ir_fodorder.msgkey`, `ir_requestforpermit.msgkey`, `ir_faultchange.msgkey`, `ir_fgorejection.rejectmsgkey` all FK→ `msg_message` (PK MsgKey). IR stamps MsgKey via `IR_MsgKeyUpd`/`IR_IssuePermitMsgUpd`/`IR_TLSMsgKeyUpd`/`IR_FaultChangeMsgKeyUpd`/`IR_FODOrderMsgKeyUpd`. Priority changes on order/telephone-order propagate into `msg_message` via the `Msg_PriorityUpd` rules. ⇒ Every issued IR order/permit has an associated inter-application message (`msg_message`) that carries it between DO and field apps. [FACT - DDL msgkey cols + procs + rules]

---

## 10. GAPS / CONTRADICTIONS

- Column-count contradiction: task brief says operatingorder 34 / workpermit 36 / telephoneorder 31; actual DDL = 28 / 31 / 24. [CONTRADICTION - d1.sql DDL authoritative]
- All status/type/target code enumerations [UNKNOWN] (no seed rows).
- "IR" acronym expansion [UNKNOWN] (Issue/Return inferred from behavior, not stated in artifacts).
- Real bodies of `IR_RFPIns`, `IR_ReturnWorkPermit`, `IR_FaultIns`, `IR_FODOrderIns` etc. exist (real block) but only headers quoted here; full multi-statement bodies not fully transcribed (they span the ` = BEGIN ... END \p\g` ranges shown by line number).
- The 35 `ir_*` dbevent producers live outside d1.sql (psm.dmt OpenROAD client / psm_4glprocs.dmt) — not analyzable from d1.sql alone. [UNKNOWN - client-side]
- `tc_circuitslog`, `tc_troublereportorder` and FOD-fault flow (`ir_fgorejection`, FGO = field-generated order?) semantics partially inferred; FGO acronym [UNKNOWN].
