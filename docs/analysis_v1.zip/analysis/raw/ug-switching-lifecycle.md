# ug-switching-lifecycle — Switching-Order Lifecycle (raw analysis)

Primary source: `d:/103_RnD/psm_v1/ug.html` ("DBM User Guide"). Cross-bound to schema/procs/rules/dbevents in `d1.sql`.

## 0. Critical framing (read first)

- **The guide is a DBM (Database Maintenance) ADMIN guide, NOT an operator switching manual.** Its TOC is config screens: §1 DBM User Guide, §2 FMS Menu, §3 TLS Menu, §4 TOMS Menu, §5 Interfaces Menu [FACT - ug.html->headings L5052-12835]. There is **no linear "switching order lifecycle" chapter**. The lifecycle is reconstructed from scattered admin descriptions + schema DDL + real proc bodies. [INFERENCE - heading survey]
- **There is no single "SwitchingOrder" entity.** The unit of work is a **CARD** (`soa_card` / per-app `fms_card`, `tc_card`, `slc_card`, `tfms_card`, `fra_card`). A card holds **MOVES (= jobs)** organized into **STEPS (step pairs)**. "Switching order" in this system ≈ the **card + its issued moves**, and for the substation/Rapid-Restore side, the electronic **operating order** (`ir_operatingorder`). [INFERENCE - DDL + guide]
- **CRITICAL: the named lifecycle DB procs are STUBS in d1.sql.** d1.sql declares each proc twice: forward-declaration stubs `create or replace procedure NAME as begin return; end` (1,163 of them, lines ~22000-26000) and the REAL bodies (full param lists + `BEGIN...END`, starting ~line 27759). [FACT - d1.sql: 2,450 total procs; 1,163 match `as begin return; end`].
- **`SOA_DetermineMoveSequence` and custom job check `CheckDeloadComplete` — named in the guide as the move-ordering / completion logic — DO NOT EXIST in d1.sql** (0 matches). They are **client-side OpenROAD 4GL**, not DB procs. [FACT - guide L6366-6394 names them; grep d1.sql = 0]. So the authoritative move-sequencing algorithm is in `psm.dmt`/`psm_4glprocs.dmt`, NOT recoverable here. [INFERENCE]
- **NO seed/enum data exists** (all tables `copy from` absent `.ingres` files). Therefore the full status code lists for `soa_card.status`, `soa_job.status`, `ir_operatingorder.orderstatus`, `*.permitstatus`, `soa_inservicepermit.status` are **[UNKNOWN]** except where a literal integer/string is hardcoded in a proc/rule body (enumerated below).

---

## 1. The CARD / MOVE / STEP / PERMIT object model

### 1.1 Card (the order container)

`soa_card` (generic) columns prove the card-level lifecycle timestamps [FACT - d1.sql->soa_card]:

| column | role |
|---|---|
| `card` (PK) | order id |
| `status integer` | numeric state (enum [UNKNOWN]; literals below) |
| `application varchar(10)` | owning app (FMS/SLC/TC/TFMS/...) |
| `typeofcard`, `cardclass`, `cardclassname` | card type/classification |
| `opened` / `activated` / `closed` | build → active → closed timestamps |
| `cutout` / `cutin` | de-energize / energize timestamps |
| `esttimecomplete` / `esttimeinservice` | ETC / ETIS |
| `workpermitflag` | permit present on card |
| `validated`, `note`, `notifications`, `relays` | misc |

Per-app card twins add domain fields. `fms_card` adds `feederstatus`, `stationground char(3)`, `groundson`, `openautoplus`, `tv_bogey` [FACT - d1.sql->fms_card].

### 1.2 Move / Job (`soa_job`) — the per-object switching instruction

"A Job Class defines the **move**... The term **move** and **job** are synonymous." [FACT - ug.html §1.2 L5158]. `soa_job` is the discrete operate instruction on one object [FACT - d1.sql->soa_job]:

| column | role |
|---|---|
| `job` (PK), `jobclass` | move id, rule set |
| `status char(3)` | move state (enum [UNKNOWN]; literals below) |
| `equip`, `equipname`, `equipclass` | **the object operated** |
| `grounds integer` | grounds count/link |
| `movetype char(4)` | e.g. `'Dead'` [FACT - 5× `MoveType = 'Dead'` in d1.sql] |
| `movecategory`, `controlcard`, `basekey` | grouping/control |
| **TakeOut side** | `tomove varchar(160)` (instruction text), `tomoverules`, `tooperator`, `toissued`, `tocomplete`, `groundon` |
| **Restore side** | `rsmove varchar(160)`, `rsmoverules`, `rsoperator`, `rsissued`, `rscomplete`, `response` |

**This is the SWITCHING STEP / CARD model**: each `soa_job` row = one discrete operate/tag instruction, paired into a **TakeOut (left of card) / Restore (right of card)** "StepPair". [FACT - ug.html §1.14 L6366-6371: "Step is often referred to as StepPair... TakeOut on the left side... Restore on the right side"]. The takeout and restore halves are columns of the SAME job row, each independently **issued** (`*issued`,`*operator`) and **completed** (`*complete`). [FACT - soa_job DDL + SOA_IssueMove/SOA_CompleteMove bodies].

### 1.3 Step Headings (`fms_steppair`, `soa_*` step) — card layout

"Step Headings control placement of moves on the card based on a Step... Each step heading has a numerical **Sequence**... organized by `SOA_DetermineMoveSequence`." [FACT - ug.html §1.14 L6366]. Globally-fixed sequences (never change): **Works Permits step = Sequence 600** [FACT - ug.html L6386-6388]. `fms_steppair(steppair, typeofcard, name)` stores the headings [FACT - d1.sql->fms_steppair]. FMS cards are **preloaded** with all step headings at creation; SLC switching items insert a heading only when a move exists in that step. [FACT - ug.html L6392-6394].

### 1.4 Operating-step status / timing (`fms_operatingstepstatus`, `*_operatingstepstatus`)

Tracks per-step `starttime`/`endtime`/`durationmins`; rule `FMS_CalculateDuration AFTER UPDATE(EndTime)` computes duration [FACT - d1.sql->fms_operatingstepstatus + rule L32862]. Delays recorded in `FMS_OperatingStep` [FACT - ug.html L6516 "Delays are recorded in the FMS_OperatingStep table"].

---

## 2. Card status state machine (numeric enum from PROC/RULE literals only)

Full enum is seed-dependent = **[UNKNOWN]**, but these integer literals are **hardcoded** in proc/rule bodies and are authoritative:

### 2.1 SOA generic card (`soa_card.status`) — from `SOA_CardStatusUpd` [FACT - d1.sql L30986]
```
IF Status = 20 AND OldStatus = 10 THEN SET Status=20, Activated=TimeUpdate   -- 10 -> 20 (activate)
ELSEIF Status = 50 THEN SET Status=50, Closed=TimeUpdate                      -- -> 50 (close)
```
| value | meaning | evidence |
|---|---|---|
| `10` | built / not-yet-active | [FACT - SOA_CardStatusUpd: `OldStatus = 10`] |
| `20` | **active / issued** (sets `Activated`) | [FACT - SOA_CardStatusUpd; rules `SOA_CardActivate WHERE New.Status=20 AND Old.Status<20`, `SOA_CardINSERT WHERE Status>=20 AND <50` L33188/33196] |
| `>=50` / `50` | **closed** (sets `Closed`) | [FACT - SOA_CardStatusUpd; rule `SOA_CardDelete WHERE Old.Status<50 AND New.Status>=50` L33194] |
| range `20..<50` | active operating window | [FACT - rule `SOA_CardStatChange WHERE Old/New.Status>=20 AND <50` L33198] |

### 2.2 FMS card (`fms_card.status`) — from rules + `FMS_CardClass*` procs [FACT - d1.sql]
| value | meaning | evidence |
|---|---|---|
| `<20` | build/pending ("OldFMSStatus=1") | [FACT - proc L29689 `IF Status < 20`] |
| `20` | **active** (creates active card) | [FACT - rules `FMS_ActivateCardInserted/FMS_CardActivatedIns/FMS_NewCardActivated WHERE New.Status=20` L32846/32872/32968] |
| `50` | closed | [FACT - rules `FMS_RemoveCardReport2 WHERE New.Status>=50`, `ir_closecard WHERE new.status>=50` L33000/33093; `FRA_CardClosedUpd WHERE Status=50 OR 99`] |
| `55` | delete (FRA) | [FACT - rule `FRA_CardStatusDel WHERE New.Status=55` L33048] |
| `99` | closed/terminal | [FACT - rule `FRA_CardClosedUpd ... New.Status=99` L33030] |

### 2.3 TC card (`tc_card.status`) [FACT - d1.sql]
| value | meaning | evidence |
|---|---|---|
| `4` | closed (`TC_CloseCard` sets status=4, Closed) | [FACT - proc L31953; rule `TC_RemoveCardReport2 WHERE New.Status=4` L33308] |

**CONTRADICTION / divergence:** card status enums are **per-application and NOT shared** (SOA uses 10/20/50; FMS uses <20/20/50/55/99; TC uses 4). Any synthesis MUST treat them per-app. [INFERENCE - literal comparison across rules].

---

## 3. Move (job) status — `soa_job.status char(3)` (largely [UNKNOWN])

Full enum = seed-dependent = **[UNKNOWN]**. Hardcoded literals found in DB proc bodies (these are the ONLY confirmable values) [FACT - grep d1.sql]:

| literal | count | role | evidence |
|---|---|---|---|
| `'Del'` | 3 | delete move (also purges `FMS_WorkPermitProtection`) | [FACT - SOA_JobStatusUpd L31458 `IF Status='Del' THEN DELETE ... FMS_WorkPermitProtection`] |
| `'Xfr'` | 5 | move transferred (shadow/shared) | [FACT - d1.sql; soa_log Item='Move transferred'] |
| `'Hid'`/`'HID'` | 4 | hidden move | [FACT - d1.sql] |
| `'TO'` / `'RS'` | — | **action selectors, NOT job statuses** — passed to `SOA_IssueMove`/`SOA_CompleteMove` to choose TakeOut vs Restore column | [FACT - SOA_IssueMove L31387 `IF Status='TO' THEN SET TOIssued... ELSEIF 'RS' THEN SET RSIssued`] |
| `'OPEN'`,`'PEND'`,`'ACK'`,`'NIS'` | 1-4 each | appear as status literals (context not all soa_job) — likely permit/order states, NOT confirmable to soa_job | [FACT - literal grep; INFERENCE - table binding uncertain] |

**The displayed move statuses (e.g. issued/complete/normal) and the `movetype` list (only `'Dead'` is confirmable) are [UNKNOWN] — they live in absent seed rows of the `udb_*` type hierarchy (Object Status hierarchy, §1.11).** [FACT - ug.html §1.11 L6123: "Object Statuses are defined in the type hierarchy under Specification->Application->Object Status"; INFERENCE - those rows are seed data, absent].

### Per-move issue/complete is the operate event (the real lifecycle transition)
- **Issue**: `SOA_IssueMove(Job, Status, Issued, Operator)` sets `TOIssued+TOOperator` (Status='TO') or `RSIssued+RSOperator` (Status='RS'). [FACT - d1.sql L31387]
- **Complete**: `SOA_CompleteMove(Job, Status, Complete)` sets `TOComplete` or `RSComplete`. [FACT - d1.sql L31039]
- **Audit**: `soa_log.item` records `'TOIssued'`,`'TOComplete'`,`'RSIssued'`,`'RSComplete'`,`'Move transferred'`,`'Prevent Delay'`,`'FeederStatus'`. [FACT - 2× each literal in d1.sql]
- **Skill check at issue/return**: at Issue Moves and at permit return, operator must match the move's skill group (`FMS_JobToSkill` vs `FMS_PersonToSkill`); mismatch → "The Operator is not qualified for this move. Do you wish to continue?" [FACT - ug.html §1.13 L6209-6258].

---

## 4. Permit types — three distinct constructs

### 4.1 Work Permit (out-of-service / in-service) — FMS/SOA/TC
- "**In-Service Work Permits (ISWP)** are approved by Transmission/District Operator to work on equipment while the system **is in service**. **Out-of-Service Work Permits (OSWP)** are approved by DO to work while system **is out of service**. **Before a DO issues an OSWP, the DO has to switch on the electric system to take equipment out of service.**" [FACT - ug.html §4.5 L11651-11667]. → OSWP is preceded by isolation switching; ISWP is not.
- Included equipment types: `SOA_ISWPEquipType` / `SOA_OSWPEquipType` (non-hierarchical, manually curated). [FACT - ug.html §4.5; d1.sql->soa_iswpequiptype/soa_oswpequiptype].
- Tables: `fms_workpermit`(permitjobid, restoration, esttimecomplete, protectionrequired, acknowledgedbyfcr, acknowledgedtime, phasecheckindicator), `soa_workpermit`(adds sequence, suspendedpermit, suspendedorder, returnstatus, preissued, returntoservice, allrelaysnormal, defectrelaycomment), `tc_workpermit`. [FACT - d1.sql].
- **Protection linkage**: `fms_workpermitprotection(permitcard, permitjobid, protectioncard, protectionjobid, seq, prepost)` ties a work-permit job to the protective (isolation/ground) jobs that must be in place before/after. [FACT - d1.sql->fms_workpermitprotection]. `SOA_JobStatusUpd Status='Del'` cascades-deletes these. [FACT - L31458].
- **Target ground / protection-distance check at issue**: Feeder Diagram Work Location Protection Trace compares actual vs computer-suggested protections; per path target ground = Green(Acceptable) / Yellow(Questionable, beyond Acceptable Protection Distance) / Red(Missing). "The DO will be alerted to a red condition **when attempting to issue the work permit**." [FACT - ug.html §1.15.1 L6627-6637].
- **ETC / aging**: when permit ETC + `FMS ETC Deadband` (hours) expires, Task Monitor writes `ITC_EETCCard`, app reddens the work-permit button. Permit past ETC by `FMS Inactivity OTW Alarm` days = "Aged" (OTW button pink, "Aged Work Permits" screen). [FACT - ug.html §1.15.1 L6508-6587]. SLC/TFMS ETC deadband params are unused — FMS ETC deadband applies to all card types. [FACT - ug.html §1.15.2/1.15.3].

### 4.2 In-Service Permit (ISP) — substation, request→grant→withdraw chain
`soa_ispermitrequest` (request, by working group via FMS Online) → `soa_inservicepermit` (granted permit) with full hazard fields (relaycalibration, lossofcontrol, ownisolation, liveconnections, asbestos, tripout...) [FACT - d1.sql]. Lifecycle fields: `currentstatus varchar(10)`, `status integer` (enum [UNKNOWN]), `statustime`, `closetime`, `preissued`, `nyisonotified`, `localauthorization`, `compliance`, `denycategory`. Withdraw: `soa_ispwithdrawevent`/`soa_ispwithdrawpermit`. Audit: `soa_isplog(ispermit, logtime, logitem, logtext, logtype)`. Restrictions/holds: `soa_isprestriction(restriction, starttime, endtime, status, lifttime, handsoff)` — `handsoff` = hold flag, `lifttime` = hold release. [FACT - d1.sql->soa_isprestriction]. dbevent `soa_loadisp`/`tc_loadisp`. [FACT - d1.sql].

### 4.3 Request-For-Permit (RFP) + FCR Work Permit — IR / Rapid Restore (substation electronic)
- `ir_requestforpermit(rfp, card, requestforpermit, revisionnumber, fcrname, objective, outagetype, rfpstatus integer, acknowledgedbydo, rejectedbydo, revisionrequestedbydo, linkedbydo)` — FCR requests, DO acks/rejects/links. [FACT - d1.sql].
- `ir_workpermit(workpermit, replacespermitid, targetfcr, doname, backfromworkstatus, continuity, caution, urgentrestoration, highpot*, permitstatus integer, protectionmovecount, equipmentdropped, equipmentpicked, returnrejecttime/do/reason)`. [FACT - d1.sql].
- Issue: `IR_IssueFCRWorkPermit(TargetFCR, DOName, PermitStatus, ProtectionMoveCount, WorkPermit)`. [FACT - L30111].
- **Return: `IR_ReturnWorkPermit(...) sets PermitStatus = 50`** (hardcoded) + captures BackFromWorkStatus, Continuity, Caution, UrgentRestoration, HighPot, EquipmentDropped/Picked. [FACT - L30215-30220 `PermitStatus = 50`]. → `permitstatus 50` = returned. Other permitstatus values [UNKNOWN].
- RFP/permit link: `IR_LinkRFPCard`, `ir_locationxferlink`. dbevents drive the async UI: `ir_processingpermit`, `ir_returnpermit`, `ir_permitcomplete`, `ir_processingtags`, `ir_reviewtags`, `ir_tagsreviewed`, `ir_issuepermitmsgupd`, `ir_deletejobs`. [FACT - d1.sql L26906-27068]. dbevents are bare pub/sub signals (no bodies). [FACT - L27008-27015].

---

## 5. Tagging / clearance / grounds / sesame lock

### 5.1 Tags (apply / remove)
- **FMS register tags** `fms_regtag(feeder, tagnumber, locationstructure, tagsentdate, tagsentby, phases, brasstag, plastictag, expirationdate, warningdate, lastvalidateddate)` — physical caution/brass/plastic tags with expiry & periodic re-validation. Expired-tag report: `fms_expiredregtagrpt`. [FACT - d1.sql].
- **IR FOD tags** `ir_fodtag(card, rfp, rfplocation, tagtype char(13), tagnumber, tagstatus varchar(20), phases, brasstag, plastictag, foddirectionalequip, reqreplacementtime, directionalequip*)`. [FACT - d1.sql]. `tagstatus`/`tagtype` enums = **[UNKNOWN]** (seed).
- **IR work-location tags** `ir_worklocationtag(workpermit, wplocation, tagtype, tagnumber, phases, tagdisposition varchar(17), tagsentby, tagsentdate, insertiondate, fromfod, directionalequip*)` and `ir_rfplocationtag`. [FACT - d1.sql].
- Tag review workflow (Rapid Restore): dbevents `ir_processingtags` → `ir_reviewtags` → `ir_tagsreviewed`. [FACT - d1.sql L27014-27068]. Tag-state transitions live in client 4GL (no DB proc bodies). [INFERENCE].

### 5.2 Grounds (apply / remove) — energization safety
- `fms_groundhistory(object, terminal, groundstatus, groundcount, groundcountbefore, timeset, card, job, sessionuser, systemuser)` = immutable ground apply/remove log. [FACT - d1.sql].
- Top-of-card grounds: `fms_card.stationground char(3)` ('On'/'Off'), `groundson` (count). [FACT - d1.sql].
- Object-status grounds: status **`10053`** = grounds (`FMS_UpdateCardHeader IF Status=10053 SET GroundsOn`), **`10044`** = station-ground on/off (`StatusCount=0→'Off' else 'On'`). [FACT - proc L29517-29518; rules `FMS_CardHeader1/2/3 WHERE Status IN (10044,10053)` L32880-32884].
- soa_job `groundon` (timestamp), `grounds` (count). dbevents `fms_card_grounds`, `fms_update_grounds`. [FACT - d1.sql].

### 5.3 Sesame lock / clearance — `fms_sesamelockcard`
Massive form (≈70 cols) capturing the physical lock/clearance on the feeder: `sesamelock`, `lockno`, `serialno`, per-phase serial/lock (`phasea/b/c` + serial + lock), `installedby`/`installdate`, `supervisor`/`approvaldate`, `groundsw`, `neutralinstalled`, `anodesinstalled`, `switchlocked`, `camopslocked`, plus power-supply/handheld/scada/manual/camA-C lock+combo sets, `processed`, `bydo`, `formid`/`formtype`. [FACT - d1.sql->fms_sesamelockcard]. = the make-safe / clearance record (lock-out + ground switch + neutral) bound to a feeder & equipment. Lifecycle (received→installed→approved→processed) implied by timestamp columns; transition procs not in d1.sql. [INFERENCE].

---

## 6. Energize / de-energize (CutIn / CutOut) and feeder status

- `soa_card.cutout` (de-energize) / `cutin` (energize) timestamps; `fms_card.cutout`/`cutin`/`openautoplus`. [FACT - d1.sql].
- Top-of-card CutOut/CutIn status set from source-breaker relationship (legacy) or substation connectivity (modern, `Source Connected = YES`). [FACT - ug.html §2.14 L10613-10662].
- Waived high-pot: CutIn without a high-pot test while OOS → `FMS_WaivedHiPot` row; Expired after `Waived High Pot Alarm` days. [FACT - ug.html §1.15.1 L6516-6519].
- dbevents `fms_sxcutin`, `fms_sxcutout`, `fms_feeder_cutout`. [FACT - d1.sql L26824-26830, 26688].
- "the segment is energized or the switch is closed" / "not energized or the switch is open" — the only explicit energize-state language in the guide. [FACT - ug.html L8462/8468].

---

## 7. PLANNED vs AUTOMATIC (forced) divergence

### 7.1 Planned (operator-built switching)
Operator builds card → adds moves (jobs) by step → activates (status→20) → issues TakeOut moves (isolation) → establishes work-permit protection (target grounds, Sequence-600 step) → issues OSWP/ISWP → field work → returns permit → issues Restore moves → CutIn/energize → closes card (status→50). Card timestamps `opened→activated→cutout→...→cutin→closed`. [INFERENCE - soa_card/soa_job DDL + SOA_CardStatusUpd + IssueMove/CompleteMove + §1.15 work-permit text].

### 7.2 Automatic / forced (Open Auto, Dead Move, Rapid Restore electronic order)
- **Open Auto equipment** "open automatically when faults occur" (`fms_openautoequip`); drive CutOut Breakers / Open Auto SLC items / Relay Summary. [FACT - ug.html §4.6 L11716]. CIOA = Cut-In-on-Open-Auto card class; FOT card class. [FACT - ug.html L6516, L10681 "CIOA"].
- **FMS cards are preloaded** with all step headings/moves at creation (vs SLC items which insert steps on demand) — the FMS feeder card is a templated, near-automatic switching script. [FACT - ug.html §1.14 L6392].
- **Dead Move count** computed by `FMS_DeadMoveCount` using HV status + `movetype='Dead'` in the Dead Moves step. [FACT - ug.html §2.7 L9963-10110].
- **Rapid Restore (IR) electronic operating order** = the AUTOMATIC/forced-substation path: `ir_operatingorder(ordernumber, ordertarget, ordertype, orderstatus, issuetime, downloadtime, ackrejecttime, ackrejectbysso, returntime, returnbysso, rescindtime, rescindtype, rescinddo, rescindreasontype, priority)` with `ir_opordersteps(ordernumber, seq, type, operatingstep, starttime, status)`. Lifecycle: **issued → downloaded → ack/reject (by SSO) → return → rescind**. [FACT - d1.sql->ir_operatingorder/ir_opordersteps]. A "UID move" ≈ a work-permit move on OMS apps. [FACT - ug.html L12730]. FCR/FOD/Substation-Operator qualification gates electronic order receipt; "Lift a Caution" only by FCR-qualified operator. [FACT - ug.html §1.13 L6258-6260].
- **Outage request (planned-outage scheduling)** `soa_outagerequest` carries scheduled-vs-actual date pairs: `skedoutagedate/actualoutagedate`, `skedstartdate/actualstartdate`, `skedreturndate/actualreturndate`, `skedinservicedate/actualinservicedate`, `ossstatus`, `status`. [FACT - d1.sql]. soa_log items mirror actuals: `'ActualOutageDate'`,`'ActualWorkIssueDate'`,`'ActualStartDate'`,`'ActualReturnDate'`,`'ActualInserviceDate'`. [FACT - d1.sql]. Link: `soa_outagerequestpermit`.

**Divergence summary:** planned = operator-built moves on a card with manual issue/complete; automatic/forced = (a) fault-driven Open Auto/CIOA card classes with preloaded/dead moves, (b) Rapid Restore electronic operating order with its own issue→download→ack→return→rescind status chain (`ir_operatingorder.orderstatus`), separate from the card/job status enums. [INFERENCE].

---

## 8. Completion / archival

- Close: card status→50 (SOA/FMS) / 4 (TC), sets `closed`. [FACT - SOA_CardStatusUpd, TC_CloseCard]. `TC_CloseCard` also blanks job statuses (`SET Status='   '`). [FACT - L31953].
- Archive twin tables (35 system-wide; relevant here): `fms_archivecard`, `fms_archiveoperatingstep`, `fms_archiveworkpermit`; `soa_archivecardlog`, `soa_archivejob`, `soa_archivelog`, `soa_archiveworkpermit`, `soa_archiveoutage`, `soa_archiveisolink`; `tc_archivecard`/`tc_archiveoperatingstep`/`tc_archiveworkpermit`; `tfms_archivecard*`; `slc_archive*`. [FACT - grep `^create table .*_archive`]. Move-to-archive procs are client-orchestrated (DB-proc bodies for the copy not surfaced here). [INFERENCE].

---

## 9. Lifecycle stage → object binding (cross-reference)

| Stage | Table(s) | Proc(s) (real bodies) | Rule/dbevent | Frame (OpenROAD) |
|---|---|---|---|---|
| Card build | `soa_card`,`fms_card` (status<20/10) | `SOA_CardUpd` | dbevent `soa_loadcommoncard`,`loadfmscard` | [UNKNOWN - psm.dmt] |
| Card activate/issue | `soa_card.status=20`,`soa_activecard` | `SOA_CardStatusUpd` | rules `SOA_CardActivate`,`FMS_ActivateCardInserted` | [UNKNOWN] |
| Add/sequence moves | `soa_job`,`fms_steppair`,`*_operatingstepstatus` | `SOA_DetermineMoveSequence` **(client 4GL, not in d1.sql)** | dbevent `soa_newjoboncard` | Job Class / Step Heading screens |
| Issue TakeOut (isolate) | `soa_job.toissued/tooperator` | `SOA_IssueMove(Status='TO')` | — | Issue Moves screen |
| Establish protection / grounds | `fms_workpermitprotection`,`fms_groundhistory`,`fms_card.stationground` | `FMS_UpdateCardHeader` (10044/10053) | rules `FMS_CardHeader1/2/3`; dbevents `fms_card_grounds`,`fms_update_grounds` | Establish Work Permit Protection (step Seq 600) |
| Make safe / lock | `fms_sesamelockcard`,`fms_regtag`,`ir_fodtag`,`ir_worklocationtag` | (client 4GL) | dbevents `ir_processingtags`→`ir_reviewtags`→`ir_tagsreviewed` | [UNKNOWN] |
| Issue work permit | `fms_workpermit`,`soa_workpermit`,`ir_workpermit`,`soa_inservicepermit` | `IR_IssueFCRWorkPermit`,`SOA_WorkPermitIns`,`FMS_WorkPermitUpdate` | dbevents `ir_processingpermit` | Aged Work Permits / permit screens |
| Permit return | `ir_workpermit.permitstatus=50`,`soa_workpermit.returnstatus` | `IR_ReturnWorkPermit` | dbevent `ir_returnpermit`,`ir_permitcomplete` | Issue/Return Moves |
| Issue Restore (re-energize) | `soa_job.rsissued/rsoperator/rscomplete`,`soa_card.cutin` | `SOA_IssueMove(Status='RS')`,`SOA_CompleteMove` | dbevents `fms_sxcutin` | Issue Moves |
| Complete/close | `soa_card.status=50/closed`,`tc_card.status=4` | `SOA_CardStatusUpd`,`TC_CloseCard` | rules `SOA_CardDelete`,`FMS_RemoveCardReport2`,`ir_closecard` | — |
| Archive | `*_archivecard`,`*_archiveworkpermit`,`soa_archivejob`,`soa_archivelog` | (client) | — | — |
| Electronic order (auto) | `ir_operatingorder`,`ir_opordersteps`,`ir_downloadmove` | `IR_MsgKeyUpd`,`IR_LinkRFPCard` | dbevents `report_switchdistributor`,`soo_completejob`,`soo_jobupdate`,`soo_uploadjoberror` | Rapid Restore (IR app) |

---

## 10. State list for Mermaid (per-app numeric enums kept distinct)

```mermaid
stateDiagram-v2
    direction LR
    [*] --> CardBuilt : create card (SOA status=10 / FMS status<20)
    CardBuilt --> MovesAdded : add jobs by StepPair (SOA_DetermineMoveSequence, client 4GL)
    MovesAdded --> CardActive : activate (status=20, set Activated) [SOA_CardStatusUpd]
    CardActive --> TakeOutIssued : SOA_IssueMove TO (set TOIssued/TOOperator)
    TakeOutIssued --> Isolated : TakeOut complete (TOComplete) -> CutOut/de-energize (soa_card.cutout)
    Isolated --> ProtectionEstablished : grounds applied (10053) + station ground (10044) + sesame lock + tags
    ProtectionEstablished --> WorkPermitIssued : OSWP/ISWP/ISP/FCR permit issued (Seq 600 step)
    WorkPermitIssued --> WorkInProgress : field work (skill-gated)
    WorkInProgress --> WorkPermitReturned : permit return (IR permitstatus=50)
    WorkPermitReturned --> RestoreIssued : SOA_IssueMove RS (set RSIssued/RSOperator)
    RestoreIssued --> Restored : Restore complete (RSComplete) -> grounds removed
    Restored --> Energized : CutIn (soa_card.cutin)
    Energized --> CardClosed : close (SOA status=50 set Closed / FMS 50/99 / TC 4)
    CardClosed --> Archived : copy to *_archive*
    Archived --> [*]

    state "AUTOMATIC / Rapid Restore electronic order (ir_operatingorder)" as Auto {
        [*] --> OrderIssued : issuetime
        OrderIssued --> OrderDownloaded : downloadtime
        OrderDownloaded --> OrderAcked : ack (SSO)
        OrderDownloaded --> OrderRejected : reject (SSO)
        OrderAcked --> OrderReturned : returntime
        OrderReturned --> OrderRescinded : rescindtime
        OrderRescinded --> [*]
    }

    state "Forced / Open Auto" as Forced {
        [*] --> AutoOpened : Open Auto / CIOA / FOT (fault-driven CutOut)
        AutoOpened --> DeadMoves : Dead Moves step (movetype=Dead)
    }
```
**[INFERENCE]** for the linear card flow — assembled from DDL timestamps + real proc bodies + guide prose; the **named state LABELS (Isolated/ProtectionEstablished/etc.) are reconstructed, not literal enum names.** The only LITERAL state values are the integers/strings in §2-§4. `ir_operatingorder` auto-substate is a separate enum (`orderstatus`, only literal `0` seen). [FACT/INFERENCE mixed].

---

## 11. [UNKNOWN] / gaps / contradictions

1. **Full status enums are [UNKNOWN]** (seed-dependent): `soa_card.status`, `soa_job.status char(3)`, `ir_operatingorder.orderstatus`, `*permitstatus`, `soa_inservicepermit.status`, `ir_requestforpermit.rfpstatus`, tag `tagstatus`/`tagtype`/`tagdisposition`. Only the hardcoded literals in §2-§4 are confirmable. [FACT - no seed rows].
2. **`movetype char(4)` enum [UNKNOWN]** — only `'Dead'` is confirmable in DB code. [FACT].
3. **Move-sequencing & completion-check logic is NOT in d1.sql** — `SOA_DetermineMoveSequence`, `CheckDeloadComplete` are client OpenROAD 4GL (psm.dmt/psm_4glprocs.dmt). The DB only stores results. [FACT - 0 matches].
4. **Named lifecycle DB procs are STUBS** (`soa_issuemove`,`soa_completemove`,`fms_feeder_cutout`, etc. at lines ~22k-26k = `as begin return; end`); real bodies are the duplicate definitions ~27k+. Don't cite the stub line numbers as logic. [FACT].
5. **Card-status enums DIVERGE per application** (SOA 10/20/50; FMS <20/20/50/55/99; TC 4). No unified status table found. [FACT - contradiction across rules].
6. **Guide vs schema mismatch on "switching order"**: the guide never defines a single "switching order" entity/lifecycle; the closest schema construct is card+jobs (operator) and `ir_operatingorder` (electronic). The phrase "switching order" in the prompt maps to two different schema objects. [INFERENCE].
7. **Sesame-lock / tag / archive state transitions** have no recoverable DB-proc bodies — orchestrated client-side; only the storage tables + timestamp columns are evidence. [INFERENCE].
8. **dbevents are bare signals** (no bodies/comments) — they prove the async stages exist (`ir_processingpermit`/`ir_returnpermit`/`ir_reviewtags`/`ir_tagsreviewed`/`fms_sxcutin`/`fms_sxcutout`) but not their payload logic. [FACT].
9. **OpenROAD editor FRAMES per stage are [UNKNOWN]** from d1.sql (frames live in psm.dmt; not analyzed here). Screen names quoted (Issue Moves, Establish Work Permit Protection, Aged Work Permits) are from the guide, not frame metadata. [FACT - guide names; frame binding UNKNOWN].
