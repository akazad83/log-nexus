# Schema Mechanics — PSM (Ingres) — Raw Analysis

Primary source: `d:/103_RnD/psm_v1/d1.sql` (33,392 lines, authoritative Ingres DDL/dump).
Every claim tagged `[FACT - file->object]`, `[INFERENCE]`, or `[UNKNOWN]`. Counts are grep/awk-derived, reproducible.

---

## 0. Headline mechanics (one paragraph)

PSM is a **metamodel-driven, integrity-in-code** Ingres database. There is **zero declared referential integrity, zero declared CHECK constraints, and zero declared PRIMARY KEY / UNIQUE constraints** in the DDL `[FACT]`. Identity, uniqueness, FK enforcement, cascade, validation, denormalized-cache sync, history capture, and archival are ALL implemented imperatively — in 1,225 server procedures, 290 Ingres rules (triggers), and 208 dbevents (async pub/sub). Uniqueness is enforced *physically* via `modify ... to <struct> unique on <cols>` storage statements (377 of 450 tables), not declaratively. Security is flat: all 4,835 grants go to `public`; there are no named roles.

---

## 1. STORAGE / INDEX

### 1.1 Structure tally (450 `modify` statements) `[FACT - d1.sql -> ^modify lines]`

| Structure | Count | % | Notes |
|---|---:|---:|---|
| btree  | 367 | 81.6% | default choice; range + equality |
| hash   | 42 | 9.3% | exact-match keys (e.g. `cac_lastkey`, `fms_3manomaly`) |
| heap   | 26 | 5.8% | unkeyed scratch/queue tables (e.g. `ddb_recoverytimeout`, `egis_nfload`, all `with extend=16`) |
| isam   | 15 | 3.3% | static lookup/config (e.g. `allapp_systemparameters`, `ddb_status`) |
| **total** | **450** | | one structure per base table (1:1 with 450 tables) |

`modify ... unique on` = 377 `[FACT]`; non-unique keyed (`to btree on` without `unique`) = remainder (e.g. `cfg_group`, `fms_audittrail`, `fms_archivecard`, `fms_archivelog` — append-heavy log/audit tables deliberately NOT unique). `[FACT]`

Sample format (column list is on the **following line**, multi-line):
```
modify udb_object to btree unique on
	object
modify cac_lastkey to hash unique on
	tablename
modify fms_audittrail to btree on        <-- NON-unique: audit log allows dup keys
```

### 1.2 Primary "keys" = the `on` columns of the unique structure `[INFERENCE]`

There is NO declared PK. The de-facto PK of each table is the `unique on (...)` clause of its `modify`. Examples `[FACT]`:

| Table | Structure | Key column(s) |
|---|---|---|
| `udb_object` | btree unique | `object` (single surrogate int) |
| `udb_lastkey` | (hash unique, see §2) | `lastkey` |
| `cac_lastkey` | hash unique | `tablename` |
| `cac_cardtype` | btree unique | `type, cardtype` (composite) |
| `dso_connection` | btree unique | `fromobj, ...` (composite) |
| `allapp_systemparameters` | isam unique | `rowkey` |

### 1.3 Secondary indexes: NONE `[FACT - d1.sql]`

- `create index` count = **0** `[FACT]`.
- Only ONE table has >1 `modify`: `udb_temp` (3 modifies) — a scratch/staging table reorganized repeatedly, not a secondary index `[INFERENCE]`.
- **Conclusion: each table has exactly one storage structure (its clustering key) and no secondary indexes.** Any non-key lookup is a full scan. `[INFERENCE - severe for large tables fms_/soa_]`

---

## 2. KEYS — surrogate-key pattern (`lastkey`-driven `object` ids)

**Confirmed: consistent surrogate-int key pattern centered on `udb_object.object`.** `[FACT]`

- `udb_object.object integer not null not default` is the PK; btree unique on `object` `[FACT - d1.sql -> udb_object, modify udb_object]`.
- Sequence allocators are **`*_lastkey` tables** (one row per logical table): `udb_lastkey`, `cac_lastkey`, `tc_lastkey`, `msg_lastkey`, `soa_joblastkey`, `soa_loglastkey` `[FACT]`.
  - `udb_lastkey(lastkey char(40) not null, value integer not null)` `[FACT]`
  - `cac_lastkey(tablename varchar(24), lastkey integer)` `[FACT]`
  - `soa_joblastkey(rowkey integer, value integer)` `[FACT]`
- Allocation proc pattern (`CAC_KeyGenerator1`, real body line 27839) `[FACT]`:
  ```sql
  UPDATE CAC_LastKey SET LastKey = LastKey + 1 WHERE TableName = :TableName;
  NextKey = 0; SELECT :NextKey = LastKey FROM CAC_LastKey WHERE TableName = :TableName;
  IF NextKey = 0 THEN RAISE ERROR -99 ...;           -- missing seed row
  ELSEIF TableName='fms_archivelog' THEN UPDATE FMS_ArchiveLog SET RowKey=:NextKey WHERE tid=:RowTID;
  ELSE RAISE ERROR -99 ... ;                          -- unknown table guard
  ```
  i.e. **increment-then-read-back, then stamp the new row by its `tid`.** 8 numbered variants `cac_keygenerator1..8` exist `[FACT]`; `lastkey` is referenced in 152 lines `[FACT]`.
- `udb_nextkey` exists only as an empty stub (`as begin return; end`) `[FACT]` — the real allocators are the `*_keygenerator*` / per-module key procs.

`152` lastkey references + 6 lastkey tables ⇒ surrogate keys are pervasive and central. `[INFERENCE]`

---

## 3. INTEGRITY — declared vs in-code (DISAMBIGUATED)

### 3.1 Declared integrity: NONE `[FACT - decisive]`

| Construct | Raw grep hits | Real DDL constraints | Verdict |
|---|---:|---:|---|
| `references` | 450 | **0** | all 450 are `grant references ... to public` — privilege grants, NOT FK clauses `[FACT]` |
| `foreign key` | 0 | 0 | no declared FKs `[FACT]` |
| `primary key` | 0 | 0 | no declared PKs `[FACT]` |
| `check (` | 25 | **0** | all 25 are table names containing "check" (`fms_phasecheck`, `fms_jobcheck`, `soa_visiblebreakcheck`) or proc names (`*DelayCheck`, `REP_DateCheck`) — NOT CHECK constraints `[FACT]` |
| `unique` (declarative) | 0 in create-table | 0 | uniqueness lives in `modify ... unique`, not constraints `[FACT]` |

`not null` appears 4,727× — that IS used (column nullability), but it is the ONLY declared integrity in the schema. Most columns are `not null default ' '`/`default 0` (sentinel-defaulted), a few date/coord columns are nullable `[FACT - udb_object: 9 nullable]`.

### 3.2 Integrity-in-code: PROVEN

The absence above forces all RI into procedures + rules. Proof points `[FACT]`:

- **Cascade delete (hand-coded):** `CAC_CO_GroupingDel` (line ~27791) deletes from 7 child tables in sequence with manual `IF iierrornumber <> 0 THEN return -1` after each:
  `CAC_CO_Circuit, CAC_CO_Feeder, CAC_CO_Info, CAC_CO_Note, CAC_CO_Note_Link, CAC_CO_Status, CAC_CO_Attachment` — all keyed by `Grouping`. No `ON DELETE CASCADE` exists; this replaces it. `[FACT]`
- **FK-existence validation (rule-driven):** rules like `FMS_JobClassCtrl$Insert1` call `FMS_ValidateEquipClass(EquipClass=New.EquipClass, Problem='Type_102')` AFTER INSERT — i.e. parent-existence check done post-hoc in a proc, recording violations instead of rejecting at write time. `[FACT]`
- **Domain validation via exception tables (not rejection):** `Conductor$Validate` (line ~) `IF (X/R) < 5 THEN INSERT INTO Udb_GrassCatcher(Object,Problem) VALUES(:Object,'Conductor_001')`. Violations are logged, not blocked. `[FACT]`
  - Exception/"grass-catcher" tables: `udb_grasscatcher(object,problem,text,known)`, `udb_problem(problem,severity,description)`, `fms_mhproblem`, `soa_connectivityproblem`, `tc_problemtracker`, `pvl_xref_exception` `[FACT]`. `udb_grasscatcher.problem` → `udb_problem.problem` is the (undeclared) severity lookup. `[INFERENCE]`

**Conclusion: PSM is a validate-and-log, eventually-flag integrity model — not a reject-at-write model. Bad data can land; rules/procs surface it into problem tables.** `[INFERENCE - high severity]`

---

## 4. SECURITY — grants/revokes

### 4.1 Grants (4,835) `[FACT]` — flat, everything to `public`

Grantee tally: **`public` = 4,835 (100%)**. **No named roles/users.** `[FACT]`

| Privilege | Count | Target |
|---|---:|---|
| execute | 1,225 | procedures (1:1 with the 1,225 real procs) |
| references | 450 | tables (1:1 w/ tables) |
| select | 449 | tables |
| update | 448 | tables |
| insert | 448 | tables |
| delete | 448 | tables |
| copy_into | 448 | tables |
| copy_from | 448 | tables |
| register | 208 | dbevents (1:1 w/ dbevents) |
| raise | 202 | dbevents |
| modify | 49 | tables |

Per base table the standard 7-grant block is issued to public: `select, update, delete, insert, references, copy_into, copy_from` `[FACT - e.g. allapp_systemparameters]`. **Net effect: any connected client has full DML + DDL-ish (modify/copy/references) + execute on everything.** `[INFERENCE - high severity: no privilege separation]`

### 4.2 Revokes (180) `[FACT]` — all `revoke execute ... from public cascade`

100% are `revoke execute on procedure X from public cascade` `[FACT]`. These lock down **internal-only procs** that must not be called by clients directly, e.g. the rule-target/key procs: `cac_keygenerator1..8`, `cardtype$delete/$insert/$typedelete`, `cascadetype$change`, `conductor$validate`, `consumer$updateloadmodel`, `csd_message$ins`, `ddb_logentry` `[FACT]`. **Pattern: grant execute to all, then revoke the trigger-only / sequence-only procs so they're invoked solely by rules.** `[INFERENCE]`

### 4.3 Dbevent security `[FACT]`

`grant register` = 208 (all dbevents), `grant raise` = 202. The 6 dbevents that are **register-only (no raise grant to public)** — server-raised only, clients may subscribe but not publish: `ddb_logentry, fms_deadmovescount, fms_estimateduptime, fms_invalidcard, fms_update_grounds, sds_dbunload` `[FACT]`.

---

## 5. TEMPORAL / AUDIT — hand-rolled history (no system-versioning)

### 5.1 Archive twin tables — 35 `<module>_archive*` `[FACT]`

Manual soft-history: live rows are copied to a parallel `*_archive*` table then deleted. **No DBMS temporal feature is used.** Proof: proc bodies do `INSERT INTO X_Archive SELECT ... FROM X WHERE ...` then `DELETE` (e.g. `FMS_ArchivePhaseCheck` block line ~28435: `INSERT INTO FMS_ArchivePhaseCheck (...) SELECT ... FROM FMS_PhaseCheck WHERE Card=...`) `[FACT]`. Archive INSERTs observed for `TC_ArchiveReportStats, SOA_ArchiveLog, SLC_ArchiveInfItemEquip, CAC_ArchiveRelayOps, TFMS_ArchiveCard*, TC_ArchiveWorkPermit, ...` `[FACT]`.

Full archive list (35): `cac_archiverelayops, cac_archiverocontrol, fms_archivecard, fms_archivefeederlog, fms_archivejob, fms_archivejobdelaylink, fms_archivelog, fms_archivenotifications, fms_archiveoperatingstep, fms_archivephasecheck, fms_archiveworkpermit, fms_archivewpprotection, gta_archivemessage, msg_archivemessage, oa_archiveaccounting, slc_archiveinfitem, slc_archiveinfitemequip, slc_archivewpequiplinks, soa_archivecardlog, soa_archiveisolink, soa_archivejob, soa_archivelog, soa_archiveoutage, soa_archiveworkpermit, tc_archivecard, tc_archivecircuitslog, tc_archivejob, tc_archivelog, tc_archiveoperatingstep, tc_archivereportstats, tc_archiveworkpermit, tfms_archivecard, tfms_archivecardprepby, tfms_archivecardtoobject, tfms_archivechecklist` `[FACT]`. Note several archive tables use `to btree on` (NON-unique) — they accept duplicate keys because they are append-only history `[FACT - fms_archivecard, fms_archivelog]`. Archive of `*archivetrigger` is also fired async via `RAISE DBEVENT SOA_ArchiveTrigger :ControlText` (line ~28572) `[FACT]`.

### 5.2 Per-row audit columns — centralized on `udb_object`, sparse elsewhere `[FACT]`

`udb_object` carries the full audit/lock column set `[FACT - udb_object DDL]`:
`created, createdby, lastchanged, lastchangedby, validated, validatedby, locked, lockedby` (dates are `ingresdate` nullable; `*by` are `char(24)`).
Prevalence: `createdby` appears on only 4 tables (`udb_object, rtu_workissue, soa_busfaultoutage, soa_inservicepermit`); `lastchangedby` on ~16 lines total `[FACT]`. **So audit columns are NOT a universal row pattern — they live on the central object table and a few feature tables.** `[INFERENCE]`

### 5.3 Audit-trail table — `fms_audittrail` `[FACT]`

One dedicated change-log table:
```
fms_audittrail(rowkey, entity varchar(32), handle int, logtime ingresdate not null,
  operator int, item varchar(32), old varchar(200), new varchar(200),
  operatorname varchar(40), handlename varchar(40))    -- modify ... to btree ON (non-unique)
```
Classic (entity, item, old→new, operator, time) field-level audit row, populated in code (fired via `fms_objectstatusaudit` dbevent + procs) `[FACT/INFERENCE]`. Companion `*history` tables: `fms_groundhistory, fms_highpothistory, soa_hipothistory, soa_scenariohistory(+jobs), tv_bogeyhistory, udb_groupinghistory, cac_relay_groupinghistory` — domain-specific history written by rules (see §7) `[FACT]`.

---

## 6. CONCURRENCY

- **`set lockmode` = 0 occurrences in d1.sql** `[FACT - decisive]`.
  ⚠️ **CONTRADICTION with Phase-0 ground truth ("8 'set lockmode' usages").** Those 8 are NOT in the SQL dump; they are presumably in the OpenROAD `.dmt` 4GL client files, not the server schema. **In the server DB there is no explicit lock-mode tuning.** `[FACT/INFERENCE]`
- **Optimistic-lock signal:** `systemversion integer not null default 0` on exactly 3 tables: `udb_object, udb_grouping, udb_groupinghistory` `[FACT]`. Intended as a version/optimistic-concurrency token on the core metamodel rows `[INFERENCE]` — but it is NOT enforced by any constraint; any check is in app/proc code `[INFERENCE]`.
- **Pessimistic-lock signal:** `udb_object.locked (ingresdate) / lockedby (char(24))` — an application-level row-checkout/edit-lock (who has the object open in the editor), distinct from DBMS locks `[INFERENCE - udb_object DDL]`. Also `validated/validatedby` = approval workflow stamp `[INFERENCE]`.
- **Key-allocation concurrency:** relies on the `UPDATE *_lastkey SET lastkey=lastkey+1` write-lock to serialize concurrent key requests under Ingres default locking — no explicit lockmode, no sequence object `[INFERENCE - CAC_KeyGenerator1]`. Risk: lock contention hotspot on each `*_lastkey` single row under load `[INFERENCE - medium]`.
- `readlock/nolock` referenced in only 5 lines `[FACT]`.

---

## 7. RULES (290) + DBEVENTS (208)

### 7.1 Rules — trigger verb & target distribution `[FACT]`

Trigger verbs (case-combined): INSERT ~112, UPDATE ~119, DELETE ~59. Hottest target tables:

| Target table | # rules |
|---|---:|
| `Udb_Grouping` | 20 |
| `FMS_Card` | 20 |
| `Udb_Object` | 18 |
| `SOA_Job` | 15 |
| `FMS_ObjectStatus` | 14 |
| `TC_Job` | 9 |
| `Udb_Type` | 7 |
| `FMS_OperatingStepStatus` | 7 |
| `FMS_JobClassControl` | 5 |

All rules are `AFTER {INSERT|UPDATE(col)|DELETE} ON <t> [WHERE ...] EXECUTE PROCEDURE <proc>(args=New./Old.cols)` — **statement-pattern: thin rule → fat proc.** `[FACT]`

### 7.2 Rule classification (sampled bodies, exact) `[FACT]`

| Rule | Class | What it does |
|---|---|---|
| `CardType$Delete` (AFTER DELETE ON Cac_CardType) | **cascade** | `CardType$Delete(Type,CardType)` removes dependents |
| `CardType$TypeDelete` (AFTER DELETE/UPDATE(Type) ON Udb_Type) | **cascade/RI** | propagate type deletion |
| `CascadeType$Change` (AFTER UPDATE(Type) ON Udb_Object WHERE New.Type<>Old.Type) | **denormalized-cache sync** | body: `UPDATE Udb_Grouping SET MemberType=:Type WHERE Member=:Object; UPDATE Udb_Grouping SET GroupingType=:Type WHERE Grouping=:Object` — keeps the cached type copies in `udb_grouping` consistent with `udb_object.type` `[FACT - decisive example of the typename/type denorm pattern]` |
| `Consumer$UpdatePQ` (AFTER UPDATE ON Udb_Consumer WHERE Pfixed/Pnom/Qfixed/Qnom changed) | **denormalized recompute** | `Consumer$UpdateLoadModel(...)` recomputes load-model cache |
| `Conductor$Insert2/$Update` (Udb_Conductor) | **validation→exception table** | `Conductor$Validate` writes `Udb_GrassCatcher` if X/R<5 |
| `FMS_JobClassCtrl$Insert1/2` (FMS_JobClassControl) | **validation** | `FMS_ValidateEquipClass / ValidateStepPair(Problem='...')` post-hoc FK check |
| `FMS_GroundHistory1/2/3` (INS/UPD(StatusCount)/DEL ON FMS_ObjectStatus WHERE Status IN(10016,10053)) | **history capture** | `FMS$GroundHistoryIns(...)` appends to `fms_groundhistory` with before/after counts |
| `FMS_JobClassCtrlSeqIns/Upd` (FMS_JobClassControl) | **resequencing/derived order** | `FMS_JobClassResequence(...)` renumbers Seq |
| `FMS_Feeder_Cutout1/2` (INS/DEL ON FMS_ObjectStatus WHERE Status=10110) | **derived-state maintenance** | toggles feeder cutout state |
| `CSD_Message$Ins` (AFTER INSERT INTO CSD_Message) | **async notify** | proc body = `RAISE DBEVENT CSD_MessageSend` (rule→dbevent bridge) |
| `DDB_RepStatusUpd` (AFTER UPDATE(Status) ON DDB_RepTargetStatus) | **denormalized label sync** | `DDB_RepStatusDescUpd(Status)` keeps status-description text current |

Net rule taxonomy `[INFERENCE]`: (a) cascade/RI enforcement, (b) **denormalized-cache maintenance** (type/typename/status-label/load-model copies kept in sync — `CascadeType$Change`, `DDB_RepStatusDescUpd`), (c) validation-to-exception-table, (d) history capture, (e) derived-state / resequencing, (f) rule→dbevent async fan-out. Note hardcoded magic type/status ints (10016, 10053, 10110, 10147, 10134, 52, 91, basetype 26) embedded in WHERE clauses — these are the absent seed-row enums `[FACT - values present; meanings UNKNOWN without seed rows]`.

### 7.3 Dbevents — async pub/sub notification backbone (208) `[FACT]`

Mechanism: server procs/rules `RAISE DBEVENT "ingres". <name> [:payload]`; clients `register`/wait. Confirmed raises with payload `[FACT]`:
`RAISE DBEVENT FMS_Feeder_Change :Msg` (Msg = grouping;PICKUP/DROP), `RAISE DBEVENT SOA_ArchiveTrigger :ControlText` (`'FMS;'+Card+';'`), `RAISE DBEVENT FMS_PhaseCheckCompl :ProcUser`, `RAISE DBEVENT FMS_Status_Change`, `RAISE DBEVENT FMS_AutomationGo`, `RAISE DBEVENT FMS_DeadMovesCount`, `RAISE DBEVENT CSD_MessageSend`, `RAISE DBEVENT DDB_LogEntry`.

Dbevent count by module prefix `[FACT]`:

| prefix | # | prefix | # | prefix | # |
|---|--:|---|--:|---|--:|
| fms | 44 | ir | 35 | soa | 29 |
| tc | 27 | soo | 11 | opnet | 9 |
| xa | 8 | dmz | 7 | ddb | 5 |
| report | 4 | msg | 4 | fra | 3 |
| tm/sds/itc | 2 each | (singletons) | 1 each | | |

Semantic clusters `[INFERENCE from names]`: outage/switching state machine (`soa_*`, `tc_*`, `ir_*processing*/return*/complete*`), real-time SCADA/EMS bridge (`xa_bus*`, `xa_tfms*`, `qgis_realtimeupdate`, `fms_status_change`), replication/HA (`ddb_*`, `opnet_*`, `dmz_*`, `replicator_status`), messaging (`msg_*`, `csd_messagesend`, `soo_sendmsg`), monitor lifecycle (`*_startmonitor0/1/2`, `*_stopmonitor`, `fms_shutdownmonitor*`). **These are the real-time automation/notification spine: DB state change → dbevent → background monitor app reacts (auto-archive, refresh UI, push SCADA, restart processes).** `[INFERENCE - high confidence]`

---

## 8. CRITICAL FINDING — proc bodies: 1,225 stubs + 1,225 real `[FACT]`

`d1.sql` contains **2,450 `create or replace procedure`** statements = **two passes**:
1. **1,225 empty stubs** `create or replace procedure X as begin return; end` (lines ~21611–26507) — declare-first so rules/grants can bind. `[FACT]`
2. **1,225 real bodies** `create or replace procedure X (...args...) = BEGIN ...sql... END` (lines ~27762 onward, before rules at 32781). `[FACT]`

The real server logic is the second block. The "2,450 procedures" is therefore **1,225 distinct procedures**, each declared twice (stub then body). `[INFERENCE - corrects the headline count]` This matters for any downstream proc inventory.

---

## 9. Findings ranked by severity

| # | Severity | Finding | Evidence |
|---|---|---|---|
| 1 | **Critical** | **No declared referential integrity, no CHECK, no PK/UNIQUE/FK constraints** — all integrity is imperative (procs+rules). Bad data is logged to exception tables, not rejected. | `[FACT]` references=450 all grants; FK=0; check-constraints=0; PK=0 |
| 2 | **Critical** | **Flat security: 4,835 grants → `public` only, no roles.** Every client has full DML + `modify`/`copy`/`references` + execute. Only mitigation is 180 `revoke execute ... cascade` on trigger-only procs. | `[FACT]` grantee tally 100% public |
| 3 | **High** | **No secondary indexes** (`create index`=0); one clustering structure per table. Non-key access = scan on large `fms_`/`soa_` tables. | `[FACT]` |
| 4 | **High** | **Denormalized type/typename/status caches** kept consistent only by rules (`CascadeType$Change`, `DDB_RepStatusDescUpd`). Any rule disablement or direct-SQL bypass silently desynchronizes `udb_object` vs `udb_grouping`. | `[FACT]` body of CascadeType$Change |
| 5 | **High** | **Integrity logic is double-maintained** — 1,225 stubs vs 1,225 real bodies; rules bind by name. Drift risk; a stub left un-replaced = silent no-op trigger. | `[FACT]` |
| 6 | **Medium** | **Key-allocation hotspot:** single-row `UPDATE *_lastkey SET lastkey+1` per insert, no sequence object, no explicit lockmode → serialization point under concurrency. | `[FACT]` CAC_KeyGenerator1 |
| 7 | **Medium** | **Hand-rolled archival** (35 twin tables, INSERT…SELECT…+DELETE in procs). No temporal/system-versioning; correctness depends entirely on proc code running. Some archive tables non-unique (dup keys possible). | `[FACT]` |
| 8 | **Medium** | **Optimistic-lock token `systemversion` present but unenforced** and only on 3 tables; `locked/lockedby/validated*` are app-level, not DBMS. Concurrency safety rests in client code. | `[FACT]` |
| 9 | **Low/Data-quality** | **Magic ints everywhere** in rule WHERE clauses (status 10016/10053/10110, type 10147/91/26, relationship 52). Meanings live in absent seed rows → semantics `[UNKNOWN]`. | `[FACT]` values; `[UNKNOWN]` meanings |
| 10 | **Doc-discrepancy** | **Ground-truth "8 set lockmode" not in d1.sql (0 found)** — those usages are in `.dmt` client 4GL, not the server schema. | `[FACT]` |

---

## 10. Mermaid — integrity/automation control flow

```mermaid
flowchart TD
  C[Client / OpenROAD frame] -->|execute proc| P[Server procedure 1,225 real]
  P -->|UPDATE *_lastkey +1| K[(udb/cac/tc *_lastkey)]
  P -->|INSERT/UPDATE/DELETE| T[(Base table e.g. udb_object)]
  T -->|AFTER trigger| R[Ingres rule 290]
  R -->|EXECUTE PROCEDURE New./Old.| P2[Trigger proc revoked from public]
  P2 -->|cascade DELETE children| T2[(child tables)]
  P2 -->|denorm sync MemberType/GroupingType| G[(udb_grouping cache)]
  P2 -->|validation fail| X[(udb_grasscatcher / *_problem)]
  P2 -->|history INSERT| H[(fms_groundhistory / *_history)]
  P2 -->|archive INSERT..SELECT + DELETE| A[(*_archive 35 tables)]
  P2 -->|RAISE DBEVENT :payload| E((dbevent 208))
  E -->|register/wait| M[Background monitor / UI / SCADA bridge]
  M -->|reacts: refresh, automate, push| C
```

---

## 11. Gaps / UNKNOWN

- Meaning of all status/type/relationship integer codes (10016, 10053, 10110, 10147, 91, 26, 52, ...) — require absent seed rows. `[UNKNOWN]`
- Exact `systemversion` enforcement (is it checked on UPDATE? not visible in sampled procs). `[UNKNOWN]`
- Whether all 35 archive tables are actively populated (only a subset proven via INSERT…SELECT in sampled procs). `[INFERENCE - pattern is uniform]`
- The 8 `set lockmode` from Phase-0 are not in d1.sql; their actual location/intent unverified here. `[UNKNOWN - likely .dmt]`
- Full per-table key-column catalog (450 rows) not exhaustively transcribed here — method given in §1.2; sampled ~60. `[partial]`
