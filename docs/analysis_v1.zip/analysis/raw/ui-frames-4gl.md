# UI / Frames / 4GL Tier — Raw Analysis (group: ui)

Primary artifacts: `psm.dmt` (30,734 lines, OpenROAD app report), `psm_4glprocs.dmt` (8,496 lines, DDB-generated shared 4GL procs), `psm_dbprocs.dmt` (21 lines, stub). Cross-ref: `d1.sql` (server DDL+dbprocs), `ug.html` (semantics).

All counts re-derived by me; ground-truth numbers from Phase 0 confirmed where checked.

---

## 0. TL;DR architecture (read this first)

`psm.dmt` is **one OpenROAD application = the UDB equipment-model editor (a.k.a. the Power System Model / "PSM" DB Manager)**. It is NOT the SOA switching, IR, TC, or FMS UI — those are separate OpenROAD apps not in these files. [FACT - psm.dmt header "Application: PowerSystemModel"; subsystem-ref scan below]

Logic tiers (three real, one stub):
1. **Client 4GL frames** (`psm.dmt`) — equipment editor UI: 122 components, 872 `ON` event handlers, 53 `INITIALIZE` blocks, 814 `FIELD(...)` refs, 490 `SELECT`s, 284 `Message`s. Holds **real business logic** (validation, type filtering, SCADA notify, combination parsing). [FACT - psm.dmt counts]
2. **Shared client 4GL procs** (`psm_4glprocs.dmt`) — 67 DDB-generated CRUD **dual-write wrappers** (63 `udb_*`, 3 `fms_*`, 1 `qgis_*`). Each builds a replay SQL string in `DDB_Global.Statement[]` and `CALLPROC psm_dbprocs!<name>` against **two DB sessions** (One+Two). 3,799 `Global` refs (matches ground truth exactly). [FACT - psm_4glprocs.dmt]
3. **Server dbprocs** (`d1.sql`) — 2,450 procs; the wrappers' real bodies live here (e.g. `udb_switchupd`). This is the authoritative server tier. [FACT - Phase 0 + spot-check]
4. **`psm_dbprocs.dmt`** — CONFIRMED 21-line metadata stub; only `Included Applications: core … core.plb`. No procedure bodies. [FACT - full file read below]

```
psm_dbprocs.dmt (lines 1-21, verbatim header):
  Name: psm_dbprocs / VersShortRemarks: Holds database procedures for psm application
  Included Applications:  core   -1   0   core.plb
```
It is a *handle* to compiled `.img`/server procs, not source. [FACT]

---

## 1. Application / component inventory (`psm.dmt`)

| Metric | Count | Source |
|---|---|---|
| Top-level components (`Application Component Report` / `Name:`) | 122 unique | `grep -aoE 'Name: +\w+' \| sort -u` |
| `ON <event>` handlers (client logic surface) | 872 | [FACT] |
| `INITIALIZE(...)` blocks (≈ frames/classes w/ ctor) | 53 | [FACT] |
| `METHOD` decls (user-class methods) | 26 | [FACT] |
| Top-level `PROCEDURE` (shared frame procs) | 7 | [FACT] |
| `FIELD(...)` references (UI field bindings) | 814 | [FACT] |
| `SELECT` statements | 490 | [FACT] |
| `Message` statements (operator prompts) | 284 | [FACT] |
| `CALLPROC` total | ~1,300 (DDB_ROLLBACK 392, DDB_COMMIT 280 dominate) | [FACT] |
| `CALLFRAME` / `OPENFRAME` | navigation; see §3 | [FACT] |

Header provenance: `CreateDate 2019-02-05`, `AlterDate 2022-11-08`, `AlterCount 2230`, `Created By mx206`, `WindowIcon /usr/users/ingres/udb.xbm`. Copyright "Unified Information, Inc. (1991,1992)" and "Pateric Software LLC (2007)". [FACT - psm.dmt header + banners] → app lineage dates to early-1990s Ingres/OpenROAD, last touched 2022.

**Included apps** (psm.dmt depends on): `core` (core.plb), `psm_4glprocs` (.img), `ddb` (.img). [FACT]

### 1.1 Component taxonomy (128 names incl. helpers)
Pattern: each editable equipment **type X** has an **editor frame `X`** plus a UI helper **class `XClass`** (the ObjectClass-derived editor model). [INFERENCE - consistent X / XClass pairing across all equipment names]

App shell + infra frames: `PSM` (root frame), `ObjectEditor`, `ObjectGeneric`, `ObjectSelection`, `FindObject`, `GraphicConnectivityEditor`, `TabularConnectivityEditor`, `SelectDiagram`, `SetType`/`SetLocation`/`SetGrouping`/`SetRating`/`SetObject`/`SetTapSetting`/`SetWinding`/`SetLoadCurve` (modal setters), `ChangeName`, `TypeTree`/`TypeHierarchy`/`Type`, `CallQGIS`, `Export_EPRI_OTS`, `ImageManager`, `LoadCurveGraph`, `LoadTypeList`, `SystemParameters`, `AuditTrailReport`. [FACT - component name list]

---

## 2. Per-type EDITOR FRAMES (the `udb_basetype.editorname` targets)

`udb_basetype(type integer, editorname char(20), tablename char(20))`. [FACT - d1.sql DDL]
- `editorname` = the OpenROAD frame that edits that type; `tablename` = its subtype table.
- **`editorname`/`tablename` VALUES are SEED ROWS in the absent `udb_basetype.ingres` file → the exact type→frame binding is [UNKNOWN].** `editorname` is referenced ONLY in DDL — **zero** procedure/rule references it (`grep editorname d1.sql` → 1 hit, the column decl). The dispatch is 100% data-driven at runtime. [FACT - grep]

Therefore the frame↔table↔proc mapping below is reconstructed by **name convention** (frame `X` ↔ table `udb_X` ↔ wrapper `udb_Xupd`), verified by existence, NOT by reading seed rows. [INFERENCE - naming convention; existence FACT-checked]

| Editor frame (psm.dmt) | Subtype table (d1.sql) | Client wrapper (4glprocs) | Server dbproc (d1.sql) | Notes |
|---|---|---|---|---|
| Switch | udb_switch ✓ | udb_switchupd ✓ | udb_switchupd ✓ | full stack |
| Capacitor | udb_capacitor ✓ | udb_capacitorupd ✓ | ✓ | |
| Conductor | udb_conductor ✓ | udb_conductorupd ✓ | ✓ | |
| ConductorType | udb_conductortype ✓ | udb_conductortypeupd ✓ | ✓ | |
| Consumer | udb_consumer ✓ | udb_consumerupd ✓ | ✓ | |
| Generator | udb_generator ✓ | udb_generatorupd ✓ | ✓ | |
| Transformer | udb_transformer ✓ | udb_transformerupd ✓ | ✓ | |
| Reactor | udb_reactor ✓ | udb_reactorupd ✓ | ✓ | |
| TowerType | udb_towertype ✓ | udb_towertypeupd ✓ | ✓ | |
| Computer | udb_computer ✓ | udb_computerupd ✓ | ✓ | |
| Telemetry | udb_telemetry ✓ | udb_telemetryupd ✓ | ✓ | |
| TelephoneCircuit | udb_telephonecircuit ✓ | udb_telephonecircuitupd ✓ | ✓ | |
| Person | udb_person ✓ | udb_personupd ✓ | ✓ | |
| MeasurementType | udb_measurementtype ✓ | udb_measurementtypeupd ✓ | ✓ | |
| BWRSteamSupply | udb_bwrsteamsupply ✓ | udb_bwrsteamsupplyupd ✓ | ✓ | |
| PWRSteamSupply | udb_pwrsteamsupply ✓ | udb_pwrsteamsupplyupd ✓ | ✓ | |
| FossilSteamSupply | udb_fossilsteamsupply ✓ | **udb_fossilsteamupd** ✓ | udb_fossilsteamupd ✓ | name shortened (not …supplyupd) |
| SteamTurbine | udb_steamturbine ✓ | udb_steamturbineupd ✓ | ✓ | |
| HydroTurbine | udb_hydroturbine ✓ | udb_hydroturbineupd ✓ | ✓ | |
| CombustionTurbine | udb_combustionturbine ✓ | udb_combustionturbineupd ✓ | ✓ | |
| DSOValve | udb_dsovalve ✓ | udb_dsovalveupd ✓ | **MISSING** | ⚠ see §6 |
| Line | **no udb_line table** | udb_lineupd ✓ | **MISSING** | ⚠ orphan |
| Tank | **no udb_tank table** | udb_tankupd / udb_tankcompartmentupd ✓ | **MISSING** | ⚠ orphan |
| Pump | **no udb_pump table** | udb_pumpupd ✓ | **MISSING** | ⚠ orphan |
| PumpPlant | **no udb_pumpplant table** | udb_pumpplantupd ✓ | **MISSING** | ⚠ orphan |
| ReliefValve | **no udb_reliefvalve table** | udb_reliefvalveupd ✓ | **MISSING** | ⚠ orphan |
| GrassCatcher | udb_grasscatcher ✓ | (ins/del only, no `upd`) | grasscatcherins ✓ | join-table pattern |

[FACT - cross-existence grep across all three files, §6 verifies the MISSINGs]

Tally: **63 client `udb_*` wrappers** vs **69 server `udb_*` dbprocs** vs ~24 distinct subtype tables. The cardinality mismatch (63 client ≠ 69 server) plus 6 client wrappers with no server proc = real drift between tiers. [FACT]

Subtype tables present (`udb_*`, the editable types): bwrsteamsupply, capacitor, circuitroute, combustionturbine, communicationlink, computer, conductor, conductortype, consumer, dsovalve, fossilsteamsupply, generator, grasscatcher, hydroturbine, kvlevel, measurementtype, person, pwrsteamsupply, reactor, steamturbine, switch, tapsetting, telemetry, telephonecircuit, towertype, transformer, winding (+ infra: object, type, supertype, basetype, extendedtype, grouping, terminal, node, rating, loadcurve, location, problem, image, bitmap, scanblock, lastkey, systemparameters, exportfield/defn/record, temp$*). [FACT - `grep create table udb_`]

---

## 3. Navigation / menu structure → subsystem mapping

OpenROAD menus are **not dumped as a MENUBAR block**; they appear as inline `Menu.<Bar>.<Item>` refs in `ON CLICK` handlers. [FACT - 0 MENUBAR keywords, but structured `Menu.x.y` refs]

Menu hierarchy (derived from handler refs, count = #handlers referencing it):

| Menu path | Hits | Function |
|---|---|---|
| Menu.Preferences.AutoValidate / AutoShowLocation / Connectivity | 88/88/8 | toggle prefs (drive global state) |
| Menu.File.CloseButton / Add / Replace / Exchange / Refresh / TypeTable / Fclose | 84/28/28/28/… | object lifecycle |
| Menu.Edit.Network / Type / Groupings / Cut/Copy/Paste/Undo / Attach_Type/Detach_Type/Paste_Type/Undo_Detach | 30/28/28/… | type & connectivity edit |
| Menu.Edit.Properties / Duplicate / ChangeName | 2/2/2 | per-object ops |

[FACT - `Menu.x.y` ref frequency]

**Navigation graph** (CALLFRAME/OPENFRAME/CALLPROC):
- `PSM` (root) → on startup `DDB_CONNECT`, loads `Udb_SystemParameters` globals, `OPENFRAME GraphicConnectivityEditor` into `GlobalFrame[Frame$ConnectivityEditor]`, registers `GlobalFrame[Frame$StartingFrame]`. [FACT - PSM INITIALIZE]
- Editors fan out via `ObjectEditor` (43 calls), `FindObject` (33), `SetType` (29), `SetLocation` (29), `SetGrouping` (28), `SetObject` (3), `ChangeName` (2), `Type` / `GroupingSelection` / `TabularConnectivityEditor` (1-2 each). [FACT - CALLFRAME/OPENFRAME counts]
- External-subsystem touchpoints from editor frames: `CallQGIS` (22), `QGIS_ExternalEventIns` (2) → QGIS/TOMS diagram; `NotifyXA21` (2) → XA21 EMS/SCADA; `FMS_AuditTrailIns` (58), `FMS_EmailNotificationIns` → FMS audit/notification; `DDB_RaiseDBEvent` (2) → Ingres dbevent bus. [FACT]

```mermaid
graph TD
  PSM[PSM root frame] -->|OPENFRAME| GCE[GraphicConnectivityEditor]
  PSM --> OE[ObjectEditor]
  OE --> EDIT[Per-type editor frames<br/>Switch/Transformer/Generator/...]
  EDIT -->|CALLFRAME| FO[FindObject]
  EDIT -->|CALLFRAME| ST[SetType/SetLocation/SetGrouping]
  EDIT -->|CALLPROC| W[udb_*upd wrappers<br/>psm_4glprocs]
  W -->|CALLPROC psm_dbprocs!| S[Server dbprocs<br/>d1.sql]
  EDIT -->|CALLPROC| QGIS[CallQGIS / QGIS_ExternalEventIns]
  EDIT -->|CALLPROC| XA21[NotifyXA21 -> FMS_EmailNotificationIns]
  EDIT -->|CALLPROC| AUD[FMS_AuditTrailIns]
  W --> SES1[(DB Session One)]
  W --> SES2[(DB Session Two)]
```

**Subsystem-reference scan inside `psm.dmt`** (proves it's the UDB editor, not SOA/IR/TC):

| Prefix | Refs in psm.dmt | Refs in psm_4glprocs.dmt |
|---|---|---|
| udb_ | 1,100 | 378 |
| fms_ | 68 (audit + email only) | 18 |
| dso_ | 37 (DSOValve editing) | 0 |
| qgis_ | 4 | 6 |
| xa21 | 2 | 0 |
| cac_ | 2 | 0 |
| soa_ | 2 (`soa_event_manager`, `SOA_XA21Exclusion`) | 0 |
| tc_ | 1 (`TC_CardRouteUpd`) | 0 |
| ir_ | **0** | 0 |
| fra_/slc_/pvl_/tfms_ | 0 | 0 |

[FACT - regex counts]. Conclusion: SOA/IR/TC/FMS business UIs are **separate OpenROAD apps**; psm.dmt only reaches them via cross-cutting hooks (FMS audit/email, SOA XA21-exclusion lookup, TC card-route, QGIS). [INFERENCE - ref distribution]

---

## 4. Shared 4GL procs (`psm_4glprocs.dmt`) — the dual-write tier

67 `PROCEDURE` decls; prefixes: **udb 63, fms 3, qgis 1**. `VersShortRemarks: "DDB generated 4GL procedures"`. These are **machine-generated** client stubs. [FACT]

Every wrapper does TWO things:
1. **Builds a textual replay statement** into `DDB_Global.Statement[]` (1,799 such builder lines): `'EXECUTE PROCEDURE <name>( col=…, … )'` with NULL/quote-escaping. This is the distributed-transaction / audit / replication log. [FACT]
2. **Dual-session execution**: `CALLPROC psm_dbprocs!<name>` against `DDB_Global.Session.One` AND `DDB_Global.Session.Two` (134 calls = 67×2, 134 `Session.One` + 134 `Session.Two` refs), reconciled by `DDB_CheckConnection` (67 calls). [FACT]

Verbatim excerpt — `udb_switchupd` (proves the dual-write + replay pattern):
```
IF DDB_Global.Session.One.State = DS_CONNECTED THEN
    CurProcedure.DBSession = DDB_Global.Session.One;
    DDB_ReturnStatus1 = CALLPROC psm_dbprocs!udb_switchupd ( Object=Object, NormalOpen=NormalOpen, ... );
ENDIF;
IF DDB_Global.Session.Two.State = DS_CONNECTED THEN
    CurProcedure.DBSession = DDB_Global.Session.Two;
    DDB_ReturnStatus2 = CALLPROC psm_dbprocs!udb_switchupd ( ... );
ENDIF;
DDB_ReturnStatus = CALLPROC DDB_CheckConnection (ProcedureName='psm_dbprocs!udb_switchupd', Status1=DDB_ReturnStatus1, Status2=DDB_ReturnStatus2);
```
→ The client maintains **two live DB connections** (primary + replica) and writes both, then reconciles. This is a client-side replication scheme — a major migration concern. [INFERENCE - dual Session.One/Two write semantics; FACT - code]

`DDB_*` is the **DDB (Distributed DataBase) runtime framework** (from included `ddb.img`): `DDB_CONNECT`, `DDB_COMMIT`, `DDB_ROLLBACK`, `DDB_CheckConnection`, `DDB_RaiseDBEvent`, `DDB_Global.*`. Transaction control is **client-driven** (392 ROLLBACK + 280 COMMIT calls in psm.dmt). [FACT]

---

## 5. Global / shared client state

`DDB_Global` is the central shared singleton (3,799 refs in 4glprocs; in psm.dmt `DDB_Global.Session.{One,Two,Cur}`, `DDB_Global.Statement`, `DDB_Global.TopFrame.Trace`). Key shared state:
- `DDB_Global.Session.One/Two/Cur` — dual DB connections + current selector. [FACT]
- `DDB_Global.Statement[]` — accumulated replay/audit SQL. [FACT]
- `GlobalFrame[]` array (68 refs in psm.dmt) — registry of long-lived global frames, indexed by enum consts `Frame$ConnectivityEditor`, `Frame$StartingFrame`. Editors reuse the single open `GraphicConnectivityEditor` instance. [FACT - PSM `ON UserEvent 'StartGlobalFrames'`]
- `DBMOperator` (DBMOperatorClass) — logged-in operator identity (`.Object`, `.Description`); threaded into every `FMS_AuditTrailIns` (Operator/OperatorName params). [FACT - 600+ refs e.g. lines 614-615]
- `SP` (SystemParametersClass) — system params (Frequency, MVABase, KVReference, LengthRatio, GroundResistivity, Temperature) loaded once at startup from `Udb_SystemParameters`. [FACT - PSM INITIALIZE]
- Type enum consts `Type$Relay`, `Type$SecondaryNetwork`, `Type$GrdSwFdr`, `Type$LoadBreaking`, `Type$Source`, `Type$SOURCE_SBFKS/Bifur/VISY` — compiled-in type IDs used in client `WHERE` clauses. **These are hard-coded client constants whose numeric values map to absent `udb_type` seed rows → values [UNKNOWN].** [FACT - usage; UNKNOWN - values]

---

## 6. ⚠ Client-only logic & tier contradictions (MIGRATION HAZARDS)

### 6.1 Logic that exists ONLY in client 4GL (no server dbproc equivalent)

**(a) `Switch.SplitCombo()`** — ground-switch "combination" string parser. Queries `Udb_ExtendedType` for `SuperType = Type$GrdSwFdr`, then tokenizes `O.Combination` on `','` / `'-'` into `A/B/C Combination` phase fields and rebuilds the UI choice list. Pure client logic, no dbproc. [FACT - psm.dmt PROCEDURE SplitCombo]
```
SELECT :k = COUNT(*) FROM Udb_ExtendedType ET
WHERE ET.SuperType = :Type$GrdSwFdr AND ET.Type = :O.Type;
... WHILE length(TempCombo) > 0 DO k = LOCATE(TempCombo, ','); ... ENDWHILE;
```

**(b) `Switch.NotifyXA21()`** — SCADA/EMS (XA21) change notification. Entirely client-side decision + email construction: checks if type is load-breaking/source via `UDB_ExtendedType`, checks `SOA_XA21Exclusion`, then inserts an FMS email request. No server proc does this. [FACT - psm.dmt PROCEDURE NotifyXA21]
```
SELECT :i = 1 FROM SOA_XA21Exclusion X, UDB_ExtendedType ET
WHERE X.Type = ET.SuperType AND ET.Type = :Switch.Type;
...
RetCode = CALLPROC FMS_EmailNotificationIns( EmailType=20,
   Subject='Equipment update for XA21-FMS interface',
   Message1='Type='+Switch.TypeName+';;'+'Old='+OldName+';;'+'New='+Switch.Name+...,
   Template='XA21EquipUpdate.html');
```
→ The **EMS-sync rule for renamed/added load-break switches is buried in a UI frame**. If the editor frame is bypassed (e.g. direct dbproc/API write), XA21 is never notified. Re-home to server/dbevent on migration. [INFERENCE]

**(c) `LoadTypeList()`** — populates every type dropdown by joining `Udb_Type`+`Udb_ExtendedType` on `SuperType=StartType`. Client-side type-hierarchy resolution; 12 call sites. [FACT]

**(d) Transaction & dual-write orchestration** — COMMIT/ROLLBACK boundaries and the two-session replication (§4) are client-controlled. No server-side equivalent. [FACT]

**(e) Audit trail** — `FMS_AuditTrailIns` is invoked from 58 client sites with client-computed Old/New/Operator; whether a server trigger also audits is [UNKNOWN] (would need rule scan, out of scope here). [FACT - call count; UNKNOWN - server dup]

### 6.2 Tier CONTRADICTION: client wrappers with NO server dbproc and/or NO table

Verified by grep across all three files:

| Client wrapper (4glprocs) | udb_* table in d1.sql | udb_*upd dbproc in d1.sql |
|---|---|---|
| udb_dsovalveupd | **EXISTS** (udb_dsovalve) | **ABSENT** |
| udb_lineupd | ABSENT | ABSENT |
| udb_tankupd / udb_tankcompartmentupd | ABSENT | ABSENT |
| udb_pumpupd | ABSENT | ABSENT |
| udb_pumpplantupd | ABSENT | ABSENT |
| udb_reliefvalveupd | ABSENT | ABSENT |

[FACT - `grep -aciE "procedure udb_X" d1.sql` = 0 for each; udb_dsovalve table confirmed present]

Interpretation: either (i) these equipment editors (Line/Tank/Pump/PumpPlant/ReliefValve — water/gas/DSO domain) are **dead/legacy frames** whose tables+server procs were dropped but the client stubs+frames remain, or (ii) `d1.sql` is an **incomplete server snapshot** missing 6 dbprocs (and ≥5 tables) that the running client still calls. DSOValve is the sharpest case: live table + live frame + live client wrapper, but the server proc it invokes (`psm_dbprocs!udb_dsovalveupd`) is not in the authoritative dump. **Cannot disambiguate from artifacts → flagged.** Either way: any migration that regenerates the server tier from `d1.sql` will break these editors. [INFERENCE - documented contradiction]

Count reconciliation: 63 client `udb_*` wrappers vs 69 server `udb_*` dbprocs → not a clean 1:1; tiers have drifted in both directions. [FACT]

---

## 7. Logic-split assessment (drives migration risk)

| Logic category | Where it lives | Evidence |
|---|---|---|
| CRUD persistence | server dbprocs (`d1.sql`), invoked via thin client wrappers | udb_switchupd dbproc reads/writes; wrapper just forwards |
| Input validation, type/supertype filtering | **client frames** (LoadTypeList, SplitCombo, AutoValidate pref) | 490 client SELECTs, Type$ consts |
| Cross-system sync (XA21/EMS, QGIS/TOMS) | **client frames** (NotifyXA21, CallQGIS) | §6.1 |
| Audit trail capture | **client** drives it (FMS_AuditTrailIns × 58) | call sites |
| Transaction control + replication | **client** (DDB dual-session, 392 ROLLBACK/280 COMMIT) | §4 |
| Referential rules / cascades | server (290 Ingres rules, 208 dbevents) — NOT in these files | Phase 0; out of UI scope |

**Verdict:** The dbprocs are mostly **dumb persistence**; the **decision logic, validation, type resolution, cross-system notification, and transaction/replication orchestration sit in the OpenROAD client tier** (`psm.dmt` + `psm_4glprocs.dmt`). Migrating off OpenROAD means **re-homing all of §6.1 to a server/service layer** — the dbprocs alone are insufficient to reproduce application behavior. The 872 `ON` handlers are the true behavioral surface and must be ported, not just the 69 dbprocs. [INFERENCE - synthesized from counts + read bodies]

Highest-risk items to re-home: (1) NotifyXA21 EMS sync, (2) SplitCombo phase parsing, (3) dual-write replication + client COMMIT boundaries, (4) the 6 orphan/missing-server editors (§6.2).

---

## 8. Gaps / UNKNOWNs

- `udb_basetype.editorname` / `tablename` **values** = seed rows (absent) → exact type→frame binding UNKNOWN; reconstructed by naming convention only.
- `Type$*` enum constant numeric values = absent `udb_type` seed rows → UNKNOWN.
- Whether Line/Tank/Pump/PumpPlant/ReliefValve/DSOValve are dead frames vs missing-from-dump server objects → UNDETERMINABLE from artifacts (CONTRADICTION between client tier and `d1.sql`).
- "~335 shared 4GL procedures" (Phase 0 estimate): I count **67** `PROCEDURE` decls in `psm_4glprocs.dmt` + **7** top-level + **26** METHOD + ~hundreds of inline `ON`/INITIALIZE blocks in `psm.dmt`. If ~335 means "all named callable 4GL units across both files," it's plausibly reached by summing component method scripts; as discrete `PROCEDURE` decls the shared-proc file has 67. Flagging the definitional mismatch.
- SOA/IR/TC/FMS frame UIs are not in these files (separate apps) → their client logic is out of scope here.
