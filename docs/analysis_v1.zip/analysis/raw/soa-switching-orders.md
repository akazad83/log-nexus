# SOA — Switching Order Application (subsystem analysis)

Source of truth: `d:/103_RnD/psm_v1/d1.sql` (Ingres DDL/dump). Secondary: `ug.html` (business semantics). All claims tagged.

> **CRITICAL CORRECTION TO GROUND TRUTH** — `[FACT - d1.sql]` d1.sql contains **two** procedure populations:
> 1. Lines ~1–27757: **stub** procs of the form `create or replace procedure NAME as begin return; end`. **All 240 lowercase `soa_*` procs here are empty stubs.** (`grep -cE '^create or replace procedure soa_[a-z0-9_]* as begin return; end'` = 240 of 240.)
> 2. Lines 27758–~32500: the **real** procs, form `create or replace procedure  NAME ( args )= BEGIN ... END` followed by `\p\g`. The 240 real `SOA_*` bodies live here (line 30794 `SOA_ActivateSwitchItem` onward).
> Total file: 2,450 procs, of which **1,163 are stubs (47%)**. `[INFERENCE]` The stub block is a forward-declaration / signature catalog; the second block is the actual `create or replace` that supplies bodies. Always read the **second** occurrence (NR>27757) for logic. The dbproc count of "2,450" double-counts: there are ~1,225 distinct procs, each declared as stub then defined with a body.

---

## 1. Table catalog — 86 SOA tables `[FACT - d1.sql grep '^create table soa_']`

| Table | Cols | Storage/PK `[FACT - modify]` | Role |
|---|---|---|---|
| soa_job | 31 | btree unique on **job** | **Central switching-order line / "move".** One row per TO+RS move pair. |
| soa_jobcontrol | 8 | btree unique on **card,job,switchingitem** | Links job→card; sequence/step/printid. |
| soa_job_to_soo | 4 | (no modify found) | Bridge job → operating order (`to_or_rs`, `ordernumber`). |
| soa_joblastkey | 2 | — | Key generator (rowkey,value) for job IDs. |
| soa_archivejob | 29 | btree unique on **card,seq,job,switchingitem** | Archived (closed) jobs; one of 35 archive twins. |
| soa_busfaultoutage | **73** | btree unique on **switchingitem** | **Largest table in DB.** Bus-fault / auto-outage data capture. |
| soa_busfaultfeeder | — | — | Feeders affected by a bus fault. |
| soa_busfaultcorrelationmatrix | — | — | Rules matrix correlating relay targets → fault action. |
| soa_inservicepermit | 33 | hash unique on **ispermit** | In-Service (Work) Permit header. |
| soa_ispermitrequest | 37 | hash unique on **ispermit** | ISWP **request** form (work details, hazards). |
| soa_ispjob | 10 | — | ISP TO-issue / RS-complete operator+time. |
| soa_ispcondition | 8 | — | Conditions tied to permit jobs. |
| soa_isprestriction / ...item | 9 / — | — | Standing equipment restrictions. |
| soa_isplog / soa_ispattachment / soa_ispbinaryfile | — | — | ISP audit log; file attachments. |
| soa_ispwithdrawevent / ...permit | — | — | Permit withdrawal events. |
| soa_ispjob, soa_ispwithdrawpermit ... | | | |
| soa_outagerequest | 22 | btree unique on **ornumber** | Planned outage request (OSS import). |
| soa_outagerequestpermit | 4 | — | OR → permit job link. |
| soa_orworkitem / soa_orbinaryfile / soa_orlog / soa_ordelay / soa_orneverlinked / soa_pendingordelay | — | — | OR sub-entities. |
| soa_workpermit | 17 | hash unique on **permitjobid** | SLC work-permit detail. |
| soa_card / soa_cardcontrol / soa_cardlog / soa_cardlastkey... | — | btree on card | Switching **card** (the order container/desk). |
| soa_activecard / soa_activeobject / soa_activity | 11/3/11 | activeobject btree unique on **object,card** | Active-list materialization (broadcast to clients). |
| soa_scenarioequip / soa_scenariohistory / soa_scenariohistoryjobs | 4/5/5 | — | "What-if" switching scenarios; saved sequences. |
| soa_outageequiptype / soa_cfgequiptype / soa_iswpequiptype / soa_xa21exclusion / soa_typeexclusion | 1 each | — | **Type-filter config tables** (single `type integer` col; list of udb types eligible for outage/cfg/ISWP). |
| soa_connectivityprobequip / soa_connectivityproblem / soa_connectivitylog | 3/—/— | — | Connectivity-problem incidents. |
| soa_hipottestequip / soa_hipothistory / soa_hipottestcriteria | 5/—/— | — | Hi-pot test records. |
| soa_ammetercleartest / soa_groundterminal / soa_visiblebreakcheck / soa_vbcheckdoubleside / soa_vbchecksingleside / soa_returnphasetypes | — | — | Field test / safety checks. |
| soa_warning* (7 tables) | — | — | Warning / override / backout subsystem. |
| soa_voltagereduction / soa_substation / soa_substationtransformer / soa_networkbus | — | — | Equipment/operational refs. |
| soa_dologin / soa_doactivity / soa_to_fms_userxref / soa_hudstationxref / soa_reportmanager / soa_rptdistributor | — | — | DO session, user xref, report distribution. |
| soa_incidentreport / soa_incidentreportlink | — | — | Incident reports. |
| soa_fmsslclink / soa_electronicorderexcl / soa_endeenspecial / soa_schd_work_gap / soa_schd_work_rpt / soa_xa21sequence / soa_xa21exclusion | — | — | Cross-module links / config. |
| soa_archive* (cardlog, isolink, job, log, outage, workpermit) | — | — | Archive twins. |
| soa_outageisolink / soa_outagesummary / soa_outagerequest... | — | — | Outage isolation/summary. |

`[UNKNOWN]` Full column lists for tables not deep-read above; row data absent (all tables `copy ... from '/home/ingres/Downloads/<t>.ingres'`, files not present) so no seed enumerations, type lists, or counts.

---

## 2. What is a "job" — the switching-order data model

`[FACT - d1.sql soa_job DDL]` `soa_job` is the atomic unit. PK = `job` (integer, from `soa_joblastkey`). It is **not** "one switching order" — it is **one switching move/line** carrying a paired Take-Out (TO) and Restore (RS) instruction:

```
job integer PK
jobclass integer            -- working-group / class (joins IR_WorkingGroup)
status char(3) default ' '  -- TEXT status: ' ', 'NIS', 'Hid' (see §4)
equip integer / equipname / equipclass / equipclassname  -- target apparatus
grounds integer (nullable)  -- ground set ref
movetype char(4)            -- 'Dead','229B','229C','229G',... (operation code)
tomove varchar(160)         -- Take-Out instruction text   } the two
tomoverules / tooperator / toissued / tocomplete           } halves of
response varchar(40)        -- 'Active','Purge', free-text  } the
rsmove varchar(160)         -- Restore instruction text     } switching
rsmoverules / rsoperator / rsissued / rscomplete           } move
groundon ingresdate
switemstatus integer default 0   -- NUMERIC lifecycle status (see §4)
controlcard integer / substation / deskname
movecategory integer        -- 0=normal,1,2,3=SLC,4,5,6=ISP (see §3)
movetype, activityidentifier char(1)  -- 'S'=shared move
shadowlink, movefgcolor, movebgcolor   -- UI display
```

`[FACT]` The **switching order container** is the **card** (`soa_card`), not the job. `soa_jobcontrol(card,job,switchingitem)` attaches jobs to a card in `steppair`/`steplevel`/`seq` order; `printid` selects which printout. A card = an ordered list of jobs = the printable switching order. `[FACT - SOA_DetermineSequence @31093, SOA_ControlResequence @31060]` sequencing of steps is server-driven via rules `SOA_DetermineSequence` (on `soa_jobcontrol` insert where `Seq=0`) and `SOA_ControlResequence` (on Seq update).

`[FACT - soa_job DDL]` **soa_job has TWO status columns:**
- `status char(3)` — text move-status: observed values `' '`, `'NIS'` (not-in-service), `'Hid'` (hidden). Used in WHERE `Status IN ('','NIS')` for active jobs `[FACT - SOA_JobControlIns @31427]`.
- `switemstatus integer` — numeric **switching-item lifecycle** status (the real state machine, §4).

---

## 3. movecategory — distinguishes order TYPES `[FACT - SOA_JobColor @31411, SOA_CloseSwitchItem @31033, SLC rules]`

| movecategory | Meaning (evidence) |
|---|---|
| 0 | Normal move `[FACT - SOA_JobIns/SOA_JobEquipControlUpd: MoveCategory = 0]` |
| 1 | special (UI FgColor=8) `[FACT - SOA_JobColor]` |
| 2,3 | **SLC** items — `SLC_NewItemActivated` fires when `Movecategory IN (2,3)`; `SLC_ArchiveItem`/`SLC_PurgeItem` on `(2,3,6)` `[FACT - rules @33172,33178,33180]` |
| 4,5 | substation-rated moves (kV-color-coded) `[FACT - SOA_JobColor: MoveCategory=4 OR 5]` |
| 6 | **In-Service Permit** move — `SOA_CloseSwitchItem` checks `MoveCategory = 6` to mark `Status='Hid'` `[FACT @31033]`; also SLC archive set |

`[INFERENCE]` movecategory is the discriminator separating planned switching (0/1/4/5), SLC long-term clearances (2/3), and ISP-driven moves (6). Exact full enum is `[UNKNOWN]` (seed rows absent), but the above six values are proven by code.

---

## 4. The switching-order STATE SET

### 4a. soa_job.switemstatus (numeric move/item lifecycle) `[INFERENCE - enum values from proc/rule code; labels inferred]`

| switemstatus | Inferred state | Evidence |
|---|---|---|
| `<20` (e.g. 0/10) | **Created / inactive** (drafted, not yet activated) | default 0; rules treat `<20` as not-active |
| `= 20` | **Active / activated** | `SLC_NewItemActivated` fires `New.Switemstatus=20` `[FACT rule @33178]`; `SOA_ActivateSwitchItem` sets `:ActiveStatus` (passed=20) + `Response='Active'` `[FACT @30794]`; queries gate active on `SwItemStatus >= 20 AND < 50` `[FACT @31427,31489,31713]` |
| `>=20 AND <50` | **Active range** (in progress) | repeated guard in joins `[FACT]` |
| `>=50` | **Closed / complete** | `SLC_ItemClosed` fires `New.Switemstatus>=50 AND Old<50` `[FACT rule @33176]`; `SOA_CloseSwitchItem` sets `:ClosureStatus` `[FACT @31030]` |

`[FACT]` State transitions are driven by procs, NOT free SQL:
- **Activate:** `SOA_ActivateSwitchItem(SwitchingItem,ActivationTime,ActiveStatus)` → `UPDATE SOA_Job SET TOIssued=:t, Response='Active', SWItemStatus=:ActiveStatus WHERE Job=:SwitchingItem` then cascades same status to all child jobs via SOA_JobControl. `[FACT @30794]`
- **Close:** `SOA_CloseSwitchItem(SwitchingItem,ClosureTime,ClosureStatus,ClosureRemark)` → if `ClosureRemark='Purge'` sets `Response='Purge'` else `Response=:Remark, RSComplete=:ClosureTime`; sets `SWItemStatus=:ClosureStatus`; if the item is an ISP (`MoveCategory=6`) un-hides child jobs (`Status='Hid'`→`'   '`). `[FACT @31030-31034]`

### 4b. soa_job.status char(3) (move text status) `[FACT]`
Observed literals: `' '` (normal/in-service-eligible), `'NIS'` (not in service), `'Hid'` (hidden — used to suppress ISP child jobs). `[FACT - WHERE Status IN ('','NIS'); SOA_ISPArchive sets J.Status='Hid' @31212]`

### 4c. Per-move TO/RS micro-states `[FACT - SOA_IssueMove/SOA_CompleteMove @31387,31039]`
A move advances by **issuing** then **completing** each half:
- `SOA_IssueMove(Job,Status,Issued,Operator)`: `Status='TO'`→set `TOIssued/TOOperator`; `'RS'`→set `RSIssued/RSOperator`.
- `SOA_CompleteMove(Job,Status,Complete)`: `'TO'`→`TOComplete`; `'RS'`→`RSComplete`.

> Excerpt `[FACT @31387]`:
> ```
> SOA_IssueMove ( Job, Status, Issued, Operator ) = BEGIN
>   IF Status = 'TO' THEN UPDATE SOA_Job SET TOIssued=:Issued, TOOperator=:Operator WHERE Job=:Job;
>   ELSEIF Status = 'RS' THEN UPDATE SOA_Job SET RSIssued=:Issued, RSOperator=:Operator WHERE Job=:Job;
>   ELSE message 'Unknown action' ENDIF; ...
> ```

`[INFERENCE]` Move lifecycle: **drafted → TO issued → TO complete → (work) → RS issued → RS complete**. The four nullable ingresdate columns (`toissued,tocomplete,rsissued,rscomplete`) ARE the per-move state — null = not-yet, non-null = done. Confirmed by 7 `SOA_JobUpdate$1..9` rules firing `soa_jobupdated` on each of these columns `[FACT rules @33228-33244]`.

---

## 5. In-Service Permit (ISP) / In-Service Work Permit (ISWP) constructs

Two coupled headers: **`soa_inservicepermit`** (the permit) + **`soa_ispermitrequest`** (the request form, 37 cols of hazard/work detail: relaycalibration, alarmcircuits, lossofcontrol, asbestos*, tripout*, gndlevelwork, etc.). Same PK `ispermit` (hash). Plus `soa_ispjob` (TO/RS operator+time), `soa_ispcondition`, `soa_isprestriction(+item)`, `soa_isplog`, `soa_ispwithdrawevent/permit`.

### 5a. ISP numeric Status machine — MASTER DECODER `SOA_ISPStatusUpd` `[FACT @31355-31370]`

| Status | CurrentStatus (varchar) | RequestStatus | Meaning |
|---|---|---|---|
| 1 | (request) | — | request created `[FACT @31214 P.Status IN (1,2)]` |
| 2 | REQUEST | REQUEST | request submitted |
| 8 | (interim) | — | aging draft, auto-closed after 4 days `[FACT @31213]` |
| 10 | OPEN | — | permit opened |
| 15 | PENDTO | — | pending Transmission Operator |
| 20 | PENDSO | — | pending System Operator |
| 25 | DENIED | DENIED | denied |
| 30 | PEND | — | pending (reason) |
| 35 | A/COND | — | approved w/ conditions |
| 40 | APPRV | APPROVED* | approved (Request→APPROVED only if ObjectType 0/1) |
| 45 | ISSUED | — | issued |
| 50 | ISSUED | APPROVED | issued (approved) |
| 54 | PULLRQ | — | pull requested |
| 55 | PULLED | PULLED | pulled |
| 60 | COMPL | COMPL | returned complete |
| 65 | INCOMPL | INCOMPL | returned incomplete |
| 70 | LOCAL | LOCAL | under local authorization (sets LocalAuthorization=1) |
| 100 | (archived) | — | archived/closed (sets CloseTime) |

> Excerpt `[FACT @31357-31361]`:
> ```
> IF Status = 10 THEN CurrentStatus='OPEN'; ... ELSEIF Status=15 THEN CurrentStatus='PENDTO';
> ELSEIF Status=20 THEN CurrentStatus='PENDSO'; ... ELSEIF Status=40 THEN CurrentStatus='APPRV';
> ...IF ObjectType=0 OR 1 THEN RequestStatus='APPROVED';... ELSEIF Status=45 THEN CurrentStatus='ISSUED';
> ```

`[FACT]` This is an **approval workflow**: REQUEST → (PENDTO/PENDSO) → APPRV / A/COND / DENIED → ISSUED → (PULLED) → COMPL/INCOMPL → archived(100). `[INFERENCE]` TO/SO = Transmission Operator / System Operator dual-jurisdiction approval; `jurisdiction char(2)` ('DO' set for ObjectType 10153/40) `[FACT @31335]`.

`[FACT - SOA_ISPArchive @31212]` Auto-close sweep: `UPDATE SOA_InServicePermit SET Status=100 WHERE Status IN (25,55,60,65,70) OR (Status=8 AND StatusTime <= now-4days)`; requests aged 6 months also closed.

### 5b. Request submit / reset `[FACT @31328, @31334]`
- `SOA_ISPRequestSubmit` → sets permit+request `CurrentStatus='REQUEST'`, `Status=:Status`, logs `'Request Submitted By '+name` (LogType 2).
- `SOA_ISPResetToRequest` → reverts to REQUEST, clears EnterBy/PreIssued/ShiftStartTime, logs "ISWP Deletion".

### 5c. Issue / Complete / Withdraw `[FACT @31383,31036,31376]`
- `SOA_IssueISP` → upsert `soa_ispjob`(TOOperator,TOIssued,Note).
- `SOA_CompleteISP` → `soa_ispjob` SET RSOperator,RSComplete,ReturnStatus,Note.
- `SOA_ISPWithdrawJob` → repoints the underlying work permit: `Application='SLC'`→`SOA_WorkPermit.PermitJobID`; `'TLS'`→`TC_WorkPermit.PermitJobID`; updates `SOA_InServicePermit.Job=NewJob`. (Cross-module: SLC vs TLS/TC.)

`soa_ispermitrequest.CurrentStatus` is also driven through `RequestStatus` mirror in the decoder above (REQUEST/DENIED/APPROVED/PULLED/COMPL/INCOMPL/LOCAL).

---

## 6. Bus-fault / automatic outage — `soa_busfaultoutage` (73 cols, biggest table)

`[FACT - DDL]` PK = `switchingitem` (btree). It is **one wide row per bus-fault outage event**, capturing every relay-target / power-quality datapoint of an automatic substation outage. **Why so wide:** it is a denormalized telemetry capture form — each protection element gets its own (flag, value/relayname, lastupd, lastupdby) quad:

- Bus differential: `bdphasea/b/c, bdrelayname, bdlastupd/by`
- Bus overcurrent: `bocphasea/b/c/n, bocrelayname,...`
- Backup timer: `butoperated, butrelayname,...`
- Feeder target: `ftfeeder, ftphasea/b/c/n, ftrelayname,...`
- Closed feeder breaker: `clfdrbkr, clfdrbkrs,...`
- Visible break fault: `vbfault, vbfdescription,...`
- Power-quality nodes: `pqfound/pqvalue/pqtime`, `pqrmsfound/...`, `fbmpr/fblor`, `bbmpr/bblor` (front/back-bus MPR/LOR relays)
- Manhole event `mhevent`, vault-fault FOD `vffod`, `correlationaction varchar(160)`, `importstatus`.

`[FACT - SOA_BFIns @30934]` Created by `SOA_BFIns(Substation,BusSection,SwitchingItem,CreationTime,CreatedByDO)` — inserts with all flags = **-1** (sentinel "unknown/not-yet-determined"). Then ~15 targeted `SOA_BF*Upd` procs each patch one element group (`SOA_BFBusDiffUpd`, `SOA_BFBusOCUpd`, `SOA_BFBackupTimerUpd`, `SOA_BFFeederTargetUpd`, `SOA_BFClosedFdrBkrUpd`, `SOA_BFVisibleFaultUpd`, `SOA_BFPQNodeUpd`, `SOA_BFPQRMSUpd`, `SOA_BFMHEventUpd`, `SOA_BFVFFODUpd`, `SOA_BFBBMPRUpd`, `SOA_BFBBLORUpd`, `SOA_BFFBMPRUpd`, `SOA_BFFBLORUpd`, `SOA_BFCorrActionUpd`, `SOA_BFImportStatusUpd`) `[FACT @30886-30950]`.

`[FACT]` Correlation logic lives in `soa_busfaultcorrelationmatrix` (managed by `SOA_BFCMatrixIns/Del`) + `correlationaction` text — `[INFERENCE]` the system reads which protection targets operated and looks up the matrix to recommend the operator's corrective switching action.

### Planned vs bus-fault distinction `[INFERENCE - structural]`
| | Planned switching order | Bus-fault / auto outage |
|---|---|---|
| Entity | `soa_job` on a `soa_card`; `soa_outagerequest` (OSS import) | `soa_busfaultoutage` keyed by switchingitem |
| Origin | DO/planner enters moves; OSS outage requests | Created by DO from SCADA event (`createdbydo`, `xa_busoutage` dbevent @27714) |
| Approval | ISP TO/SO workflow (§5) | reactive — capture & correlate, no pre-approval |
| State | switemstatus 20→50, TO/RS issue/complete | importstatus + per-element flags |
| Trigger | manual / scheduled | EMS/SCADA `xa21_*`, `rtu_*`, `xa_busoutage`/`xa_tfmsoutage` dbevents |

---

## 7. Planned outage request (`soa_outagerequest`) state machine `[FACT - SOA_ORStatusUpd @31552]`

| Status | CurrentStatus | Meaning |
|---|---|---|
| 10 | IMPORTED | imported from OSS (external outage-scheduling system) |
| 20 | PERMIT | permit issued/linked |
| 50 | CLOSED | closed |
| 70 | RECALLED | recalled |
| 100 | ARCHIVED | archived |

Also carries `ossstatus varchar(40)` (free external status) and sked/actual date pairs (outage/work-issue/start/return/in-service). `[FACT - DDL]` Linked to permit jobs via `soa_outagerequestpermit(ornumber,workitem,permitjobid,workgroup)`; workgroup derived by joining `SOA_Job.JobClass → IR_WorkingGroup → UDB_Type` `[FACT - SOA_ORPermitIns @31547]`. Cascade delete via rule `SOA_OutageRequest$Del → SOA_ORCascadeDel` `[FACT rule @33252, proc @31532]`.

---

## 8. Card lifecycle (the order container) `[FACT - SOA_CardStatusUpd @30986, rules]`

`soa_card.Status` (numeric): **10 (created) → 20 (activated, sets Activated date) → 50 (closed, sets Closed date)** `[FACT @30986-30988]`. Rules materialize the active list:
- `SOA_CardActivate`/`SOA_CardINSERT` (Status≥20,<50) → `SOA_ActiveListInsert` `[FACT @33188,33196]`
- `SOA_CardDelete` (→≥50 or →10) → `SOA_ActiveListDelete` `[FACT @33194]`
- `SOA_CardStatChange` (stays 20–49) → `SOA_ActiveLStatusChange` `[FACT @33198]`

---

## 9. Event propagation

`[FACT]` Two raise mechanisms:
1. **Server procs raise** (proven `RAISE DBEVENT` in SOA bodies): `SOA_ActiveListChange` (from `SOA_ActiveListInsert/Delete/LStatusChange/LFStatusChange` @30798,30803,30822,30827,31495–31511), `SOA_CardValidation` (@31004), `SOA_CautionUpd` (@31019), `SOA_JobUpdated` (from `SOA_JobUpdate` @31465), `SOA_ArchiveTrigger` (@28572). `[FACT]`
2. **Client (OpenROAD 4GL) raises** — events with `grant raise ... to public` and **no proc raising them**: **`active_order_change`** (@26520-26524), `soa_jobupdated` (also client-raisable), `soa_newjoboncard`, `soa_reloadjob(s)`, `soa_loadisp`, etc. `[FACT]` `active_order_change` has NO server proc raising it → `[INFERENCE]` it is raised by the OpenROAD client/distributor process to tell all desks to refresh the active-order list; consumers `register` on it.

### Event flow (Mermaid)
```mermaid
flowchart TD
  subgraph Server[Ingres procs + rules]
    JU[SOA_Job col update<br/>TOIssued/TOComplete/RSIssued/<br/>RSComplete/Grounds/Response]
    R1[rules SOA_JobUpdate$1..9]
    PJ[SOA_JobUpdate proc]
    AL[SOA_ActiveListInsert/Delete/<br/>LStatusChange]
    CV[SOA_CardValidationUpd]
    BF[SOA_BFIns / SOA_BF*Upd]
  end
  JU --> R1 --> PJ -->|RAISE| EJ((soa_jobupdated))
  AL -->|RAISE| EAL((SOA_ActiveListChange))
  CV -->|RAISE| ECV((SOA_CardValidation))
  Client[OpenROAD client / Distributor] -->|RAISE| EAO((active_order_change))
  EJ --> Desks[All DO desks register & reload job]
  EAL --> Desks
  EAO --> Desks
  BF -->|SCADA xa_busoutage @27714| BFcap[Bus-fault capture]
```

---

## 10. Cross-module links / readers-writers `[FACT]`
- **IR (operating orders):** `soa_job_to_soo(job,seq,to_or_rs,ordernumber)` bridges SOA jobs to IR operating orders. Rules `IR_FMSJobRSComplete/RSIssued/TOComplete/TOIssued` fire `IR_FMSJobUpdate` on `SOA_Job` TO/RS timestamp changes (Action 'RC','RI','TC','TI') `[FACT @33097-33103]`. ISP archive joins `IR_OpOrderJobs`/`IR_OperatingOrder` (OrderStatus>50) `[FACT @31212]`.
- **SLC (long-term clearances):** rules `SLC_NewItemActivated`(switemstatus=20,movecat 2/3), `SLC_ItemClosed`(≥50), `SLC_ArchiveItem`/`SLC_PurgeItem` on archive/delete `[FACT @33172-33180]`. `SOA_WorkPermit` repointed on ISP withdraw for `Application='SLC'`.
- **TC/TLS (transmission):** ISP withdraw repoints `TC_WorkPermit` for `Application='TLS'` `[FACT @31377]`; `xa_tfmsoutage` dbevent.
- **FMS:** active-list insert reads `FMS_Card`, `TFMS_CardToObject`; rule `SOA_FMSFStatusChange` → `SOA_ActiveLFStatusChange` `[FACT @33222]`. `LogCard_FeederStatusName` rule on FMS_Card → `SOA_LogInsert` `[FACT @33113]`.
- **CAC (relay ops):** `SOA_ArchiveRelays`, `SOA_CascadeRelayDel` write `CAC_RelayOpsControl`/`CAC_ArchiveRelayOps` `[FACT @30879,31014]`.
- **UDB (metamodel):** equip validation cascade — rule `SOA_CascadeEquipVal` on `Udb_Object.ValidatedBy`; `SOA_EquipType$Insert/Delete` maintain `SOA_*EquipType` filter tables from `UDB_ExtendedType.SuperType=17` `[FACT @33200,33218,33220]`.

**Transaction boundaries** `[INFERENCE]`: each proc is one logical txn; multi-step procs `RETURN -1` on any `iierrornumber<>0` (e.g. `SOA_CloseSwitchItem` does 3 updates then conditional un-hide, bailing on each error) — but Ingres DB procs are **not auto-atomic**; rollback is the **caller's** responsibility on the returned -1. No explicit `COMMIT`/`ROLLBACK` in proc bodies observed `[FACT]`.

---

## 11. Switching-order state machine (consolidated, Mermaid) `[INFERENCE - labels; numeric values FACT]`
```mermaid
stateDiagram-v2
  [*] --> Drafted: SOA_JobIns (switemstatus<20, status=' '/'NIS')
  Drafted --> Active: SOA_ActivateSwitchItem (switemstatus=20, Response='Active')
  Active --> TOIssued: SOA_IssueMove('TO')
  TOIssued --> TOComplete: SOA_CompleteMove('TO')
  TOComplete --> RSIssued: SOA_IssueMove('RS')
  RSIssued --> RSComplete: SOA_CompleteMove('RS')
  RSComplete --> Closed: SOA_CloseSwitchItem (switemstatus>=50)
  Active --> Purged: SOA_CloseSwitchItem(ClosureRemark='Purge')
  Closed --> [*]: SOA_ArchiveJob (->soa_archivejob)

  state "ISP approval (parallel)" as ISP {
    [*] --> REQUEST: SOA_ISPRequestSubmit (Status=2)
    REQUEST --> PENDTO: 15
    PENDTO --> PENDSO: 20
    PENDSO --> APPRV: 40
    APPRV --> ISSUED: 45/50
    ISSUED --> PULLED: 55
    ISSUED --> COMPL: 60
    ISSUED --> INCOMPL: 65
    REQUEST --> DENIED: 25
    COMPL --> ARCHIVED: 100
  }
```

---

## 12. Gaps / UNKNOWNs / contradictions
- `[UNKNOWN]` No row data anywhere (all `copy from '<t>.ingres'` files absent) → cannot enumerate `jobclass`, `equipclass`, `udb_type`, full `movecategory`/`movetype` lists, or any seed status that isn't hard-coded in a proc. Enum **labels** in §4/§5/§7 are `[INFERENCE]` except where a literal string appears in proc code.
- `[CONTRADICTION - ground truth]` "2,450 procedures" and "soa ~480" overcount: d1.sql has each proc **twice** (stub @<27757 + body @>27757). Distinct SOA procs = **240** (all stubs in block 1, all bodies in block 2). Real distinct DB procs ≈1,225, not 2,450. The "real server-side logic" claim is correct but the bodies are in the SECOND half of the file, not throughout.
- `[UNKNOWN]` `soa_job_to_soo` has no `modify` statement (no index in dump) — heap; PK assumed (job,seq) but unproven.
- `[UNKNOWN]` Whether `active_order_change` is raised by any process (no proc raises it; presumed OpenROAD client per `psm.dmt`, not verified in this pass).
- `[UNKNOWN]` `soa_job.status` full domain — only `' '`,`'NIS'`,`'Hid'` proven; others may exist in absent data.
- `[INFERENCE]` `switemstatus` granular values between 0 and 20, and 50+, are not individually decoded by any single proc (unlike ISP's `SOA_ISPStatusUpd`); only the threshold bands (<20 / =20 / 20–49 / ≥50) are code-proven.
