# FMS — Field Management Subsystem (raw analysis)

Source of truth: `d:/103_RnD/psm_v1/d1.sql`. Supporting: `ug.html`.
All claims tagged `[FACT - file->object]`, `[INFERENCE]`, or `[UNKNOWN]`.

---

## 0. CRITICAL STRUCTURAL FINDING — d1.sql has TWO proc regions

`d1.sql` contains the FMS procedures **twice**:

| Region | Approx lines | Form | Content |
|---|---|---|---|
| Stub region | ~22000–26800 | `create or replace procedure fms_x as begin return; end` | **347 of 354 FMS procs are empty stubs** `[FACT - d1.sql:22027..23291]` |
| Real-body region | ~28230–29550+ | `create or replace procedure  FMS_X ( args ) = DECLARE … BEGIN … END` (OpenROAD/Ingres 4GL with `\p\g` delimiters) | **351 real FMS proc bodies** `[FACT - d1.sql:28230..29550]` |

`[FACT - d1.sql:22211]` `create or replace procedure fms_cardstatuschange as begin return; end` (stub)
`[FACT - d1.sql:28490]` `create or replace procedure  FMS_CardStatusChange ( Card INTEGER NOT NULL, Status INTEGER NOT NULL ) = … UPDATE "ingres". SOA_Card SET Status = :Status WHERE Card = :Card …` (real body)

`[INFERENCE]` The stub region is a forward-declaration / dependency-ordering pass (lets rules and grants bind before bodies load); the lower region carries the authoritative logic. **Read the real-body region, NOT the stubs.** The Phase-0 note "real logic is in the 2,450 procedures inside d1.sql" is correct — but you must target the `= DECLARE … BEGIN` bodies, not the `as begin return; end` lines.

Counts (case-combined): `[FACT - d1.sql]` 114 FMS tables; 354 `procedure fms…` stub lines; **351 real `procedure  FMS_…` bodies**; 83 FMS rules; 45 FMS dbevents; **0 FMS Ingres `rule`-typed errors** but 290 rules total in DB. No `view`. No row data (every table `copy … from '/home/ingres/Downloads/<t>.ingres'`, files absent) `[FACT - Phase 0]`.

---

## 1. FMS role

`[INFERENCE - from tables+procs+rules+dbevents]` FMS = the **real-time field-operations / automation / object-status engine**. It is the **largest subsystem** (114 tables, ~351 real procs). It does NOT author switching orders (that is SOA); it **executes** them in the field and maintains live equipment/feeder STATE. Responsibilities evidenced:

1. **Operating cards** (`fms_card`) — the live field work record for a feeder/job. `[FACT - d1.sql:1956]`
2. **Real-time object status state machine** (`fms_objectstatus` + `…audit` + `…queue`). `[FACT - d1.sql:3795,3827,3865]`
3. **Automation control loop** (`fms_automationcontrol`/`block`, dbevents `fms_automationgo`/`stopped`). `[FACT - d1.sql:1819,1860,26608]`
4. **Clearance / lockout-tagout records** (`fms_sesamelockcard` — 71 cols). `[FACT - d1.sql:4384]`
5. **SOA bridge** — cascades card status into `SOA_Card`, grounds into `SOA_Job`. `[FACT - d1.sql:28490,29523]`
6. Subsidiary: phase checks, hi-pot tests, manholes, notifications, fault correlation, work permits, monitors, email/dissemination.

NOTE on task brief: **there is no `fms_job` table.** `[FACT - grep ^create table fms_(job)]` The job record lives in `fms_card` + the move tables; the canonical job-row shape is visible in the archive twin `fms_archivejob` (job, card, seq, status, jobclass, equip, steppair, move/restore operator+time). `[FACT - d1.sql:1484]`

---

## 2. FMS table catalog (114)

`[FACT - d1.sql, grep ^create table fms_]`. Grouped by function (line = DDL start).

### 2.1 Card / job / operating-step core
| Table | Line | Role |
|---|---|---|
| `fms_card` | 1956 | Live operating card (47 cols) |
| `fms_cardtypefilter` | 2022 | Card-type display filter |
| `fms_jobaction` | 3180 | Job → status-setting actions |
| `fms_jobcheck` | 3222 | Job validation checks |
| `fms_jobclass` | 3264 | Job class master |
| `fms_jobclasscontrol` | 3296 | Job-class step-pair sequencing |
| `fms_jobclasslink` | 3330 | Job-class linkage |
| `fms_jobobjective` | 3405 | jobclass→objective→tors map |
| `fms_jobtoskill` | 3435 | Job→skill requirement |
| `fms_jobdelaylink` | 3375 | Job delay linkage |
| `fms_droppedequipjobs` | 2345 | equip↔job (dropped equipment) |
| `fms_operatingstepstatus` | 3927 | Operating-step timing/duration state |
| `fms_pendingopstep` | 3999 | Pending operating steps (card,job,step,tors) |
| `fms_tmpoperatingstep` | 4775 | Temp op-step scratch |
| `fms_steppair` | 4646 | To/Restore step pairs |
| `fms_stepdownlink` | 4618 | Step-down card linkage |
| `fms_portionlink` | 4149 | Portion linkage |
| `fms_jobclasscontrol`… | — | (above) |

### 2.2 Object-status state machine
| Table | Line | Role |
|---|---|---|
| `fms_objectstatus` | 3795 | **Current** status (object,terminal,status,statuscount,timeset) |
| `fms_objectstatusaudit` | 3827 | **Append-only history** (adds job,tors,card,switchingitem,fromapp,doname,rowtime,statusupdate) |
| `fms_objectstatusqueue` | 3865 | **Inbound work queue** (same key + provenance, no statuscount) |
| `fms_pendingstatus` | 4030 | Pending status by issued operator |
| `fms_fromworkstatus` | 2767 | "From-work" derived status source |
| `fms_operationactivity` | 3964 | Operation activity log |

### 2.3 Automation control loop
| Table | Line | Role |
|---|---|---|
| `fms_automationcontrol` | 1860 | Automation sequence queue (automationsequence,card,returnblock,returnsystem,action) |
| `fms_automationblock` | 1819 | Automation blocks (block lifecycle: status/start/stop/end, sendto, division) |
| `fms_enableconfigchange` | 2468 | Config-change enable |
| `fms_speedbump`/`fms_speedbumpcnt` | 4535/4564 | Automation throttle/pause ("speed bump") |

### 2.4 Clearance / locks / grounds
| Table | Line | Role |
|---|---|---|
| `fms_sesamelockcard` | 4384 | **Clearance / lockout-tagout card (71 cols)** — largest single equipment/lock table |
| `fms_groundhistory` | 2896 | Grounds history |
| `fms_regtag` | 4241 | Registration tag |
| `fms_expiredregtagrpt` | 2490 | Expired reg-tag report |
| `fms_workpermit` | 4923 | Work permit |
| `fms_workpermitprotection` | 4956 | WP protection |
| `fms_wpprotectionactual/result/suggested` | 4990/5020/5055 | WP protection actual/result/suggested |
| `fms_accessrequest` | 1312 | Access request |

### 2.5 Equipment-class config (subtype membership tables)
| Table | Line | Role |
|---|---|---|
| `fms_openautoequip` | 3901 | EquipClasses that auto-open (single col equipclass) |
| `fms_phasecheckequip` | 4123 | EquipClasses requiring phase check |
| `fms_sslequiptype` | 4592 | Sesame-lock equip types |
| `fms_typeterminals` | 4806 | Type→terminal counts |
| `fms_preservedtype` / `fms_preload` | 4212/4177 | Preserved/preload type config |
| `fms_hvsensitive` | 3154 | HV-sensitive equip class list |

### 2.6 Faults / phase / hi-pot / tests
| Table | Line | Role |
|---|---|---|
| `fms_fault` | 2518 | Fault record |
| `fms_faultcorrelation` | 2565 | Fault correlation (inrush/rtf/damage/visiblefault/recommend) |
| `fms_phasecheck` | 4089 | Phase check |
| `fms_3manomaly` | 1287 | 3-phase anomaly |
| `fms_ammetercleartest` | 1355 | Ammeter clear test |
| `fms_hipottest`/`fms_hipottestcriteria` | 3064/3094 | Hi-pot test + criteria |
| `fms_highpothistory` | 2964 | Hi-pot history |
| `fms_highpotmaxcriteria`/`fms_highpotmaxfeeder` | 3007/3036 | Hi-pot max criteria/feeder |
| `fms_waivedhipot` | 4862 | Waived hi-pot |

### 2.7 Feeder / network / bus
| `fms_feederdiv` 2612, `fms_feederlog` 2641, `fms_feedermanhole` 2672, `fms_feederrestriction` 2734, `fms_connectedsource` 2137, `fms_busconfiguration` 1894, `fms_bussectionoutage` 1921, `fms_networkjeopardy` 3677, `fms_networkoutage` 3704, `fms_networkrankcolor` 3759, `fms_mtacontingency`/`…feeder` 3612/3646, `fms_cercday` 2048 `[FACT - d1.sql]`

### 2.8 Manholes
| `fms_commonmanhole` 2107, `fms_manholeimport` 3463, `fms_manholerfp` 3488, `fms_mhproblem` 3520 `[FACT - d1.sql]`

### 2.9 Messaging / SOA bridge / monitors / email
| Table | Line | Role |
|---|---|---|
| `fms_soccsxmessage` | 4477 | **SOCCS/SCADA switching-execution messages** (card,job,tors,device,status,devicetime) |
| `fms_soccsxmessagebus` | 4512 | SX message → bus |
| `fms_dssorderrouting` | 2373 | DSS order routing (division→route) |
| `fms_dbeventqueue` | 2225 | Outbound dbevent queue (id,name,text,toapp,fromapp,attempt) |
| `fms_monitor`/`fms_monitor_tbl` | 3546/3582 | Process monitors |
| `fms_notifications`/`fms_emailnotification`/`fms_emailattachment` | 3759.../2431/2400 | Notifications/email |
| `fms_disseminationfile`/`fms_dissfiledoxref`/`fms_dissfilerecord` | 2257/2285/2315 | File dissemination |
| `fms_reportmanager` | 4280 | Active-card report manager |

### 2.10 Config / misc
| `fms_systemparameters` 4675, `fms_security` 4352, `fms_usersetting` 4833, `fms_holiday` 3126, `fms_timerestriction` 4775, `fms_restriction` 4313, `fms_frtexclusion` 2767, `fms_speedbump` 4535, `fms_helptext`/`fms_webhelp`/`fms_customprompt`/`fms_checklist`/`fms_cpmchecklist`/`fms_greensheet*`/`fms_audittrail` 1782, `fms_testcontrol` 4718, `fms_persontoskill` 4061 `[FACT - d1.sql]`

### 2.11 Archive twins (11)
`fms_archivecard` 1389, `fms_archivefeederlog` 1453, `fms_archivejob` 1484, `fms_archivejobdelaylink` 1542, `fms_archivelog` 1574, `fms_archivenotifications` 1610, `fms_archiveoperatingstep` 1646, `fms_archivephasecheck` 1683, `fms_archiveworkpermit` 1717, `fms_archivewpprotection` 1750 `[FACT - d1.sql]`

---

## 3. `fms_card` (47 cols) — the live operating card `[FACT - d1.sql:1956]`

PK `card integer`. Key columns:
- Identity/class: `typeofcard`, `cardclass`, `cardclassname`, `substationname`, `feeder`, `feedername`, `position`.
- **Status driver**: `status integer` (lifecycle), `feederstatus`/`feederstatusname` (live HV status echoed from `fms_objectstatus`).
- **Grounds**: `stationground char(3)` ('On'/'Off'), `groundson integer`.
- Automation/move: `deadmoves`, `deadmovesto`, `rapidrestore`, `phasechecks`, `processautoexecution`, `xferflag`, `processautoexecution`, `networkfeeder`.
- Timestamps: `opened`, `activated`, `closed`, `cutout`, `openautoplus`, `cutin`, plus estimated/actual completion/in-service times.
- Flags: `notifyflag`, `workpermitflag`, `validated`, `tv_bogey` (temperature-variable bogey — set >1 by daily forecast threshold per `ug.html`).
- 20-slot fixed display arrays: `loop1..loop4`, `assoc`, `relays`, `notifications`.

`[FACT - ug.html:6617]` "If a card is out of service when the temperature variable threshold has been exceeded, the `tv_bogey` field in `fms_card` table is updated to a value >1."

Storage: `modify fms_card to btree on feeder` (secondary key on feeder, not card) `[FACT - d1.sql]`.

### Card status codes (from rules — partial, seed rows absent)
| Status int | Meaning (evidenced) | Source |
|---|---|---|
| `20` | **Active card** | `FMS_ActivateCardInserted` / `FMS_CardActivatedIns` / `FMS_NewCardActivated` rules fire WHERE Status=20 `[FACT - d1.sql:32846,32872,32968]` |
| `< 50` | card still open/in-service (multiple procs gate `Status < 50`) `[FACT - d1.sql:29518,29524]` |
| `>= 50` | card closed/removed → `FMS_RemoveCardReport` fires WHERE New.Status>=50 AND Old.Status<50 `[FACT - d1.sql:33000]` |
| `-1` | sentinel for key generation → `FMS_ProduceCardKey` WHERE New.Card=-1 `[FACT - d1.sql:32998]` |
| `10099` | a CardClass value (special re-activation) `[FACT - d1.sql:32968]` |

`[UNKNOWN]` Full enumeration of `status` and `cardclass` values — requires absent seed rows (`udb_type`/`fms_jobclass` data). Do NOT fabricate.

---

## 4. `fms_sesamelockcard` (71 cols) — clearance / lockout-tagout `[FACT - d1.sql:4384]`

Largest single equipment/lock table. **Compound PK** = `(division, received, feeder, equip)` via `modify fms_sesamelockcard to btree unique on division,received,feeder,equip` `[FACT - d1.sql]`.

### Structure (the "sesame lock card" = a physical clearance/LOTO form)
- **Provenance**: `received` (date), `division`, `feeder`, `equip`, `fdrandstruct`, `location`, `enteredby`, `bydo` (by Dispatch Operator), `installedby`, `installdate`, `supervisor`, `approvaldate`, `updatetime`, `processed`, `formid`, `formtype`.
- **Lock identity**: `combono`, `serialno`, `lockno`, `sesamelock` (the "sesame" e-lock flag/id), `unitlocked`, `switchlocked`, `camopslocked`, `dmbadging`.
- **Per-phase locks**: `phasea/b/c` + `phase{a,b,c}serial` + `phase{a,b,c}lock` — independent lock per electrical phase.
- **Equipment-type flags**: `nwtrans` (network transformer), `radial`, `reactor`, `groundsw` (ground switch), `fdrandvault`, `neutralinstalled`, `anodesinstalled`.
- **Component locks (serial/lock/combo triples)** for: `powersupply`, `handheld`, `scada`, `manual`, and three CAM units `cama/camb/camc`.
- Ratings: `kv`, `kva`, `kv2`. Free text: `remarks varchar(300)`.

### Sesame-lock semantics `[INFERENCE - schema + procs]`
"Sesame lock" = an **electronic/combination lock ("open sesame")** applied to field equipment to enforce clearance/lockout-tagout. A card records **who locked what, with which lock/combo/serial, on which phase(s)/component(s), authorized by which supervisor/DO, and when**. It is a **records-of-record data-entry artifact**, NOT a live state machine:

- `[FACT - d1.sql:29369]` `FMS_SesameLockCardIns` — pure INSERT, branches on `FormType` (0 = full lock-card with phase+equip flags; else = component-lock variant with powersupply/handheld/scada/manual/cam locks). No status transitions.
- `[FACT - d1.sql:29388]` `FMS_SesameLockCardUpd` — sets `Equip`, `Processed = 1`, `UpdateTime`, `ByDO`. The only lifecycle bit is `processed 0→1`.
- `[FACT - d1.sql:29367]` `FMS_SesameLockCardDel` — DELETE by `FormID`.
- `[FACT - d1.sql:30678]` `SetSesameLockCardFormID` — back-fills sequential `FormID` across all rows (Min→Max Tid loop).
- `[FACT - d1.sql:24435]` `setsesamelockcardformid` stub mirrors it.

`[INFERENCE]` Clearance ENFORCEMENT (preventing a switching move on locked equipment) is NOT visible in FMS procs — sesamelockcard is descriptive. Lock-state that gates operations lives in `udb_object.lockNumber`/`combination` and the live `fms_objectstatus` (status 10016 grounds, etc.), set via SOA/SLC. `[UNKNOWN]` whether any proc cross-checks `fms_sesamelockcard` before allowing a move — none found.

---

## 5. The object-STATUS state machine (status + queue + audit triple)

`[INFERENCE - strong]` This is an **event-sourced / CQRS-style** status model:

```
fms_objectstatusqueue  →  fms_objectstatus      →  fms_objectstatusaudit
(inbound events,           (current materialized      (append-only history,
 provenance,               truth, unique key          full provenance)
 dequeued+deleted)         object+terminal+status)
```

| Table | Key | Mutability | Purpose |
|---|---|---|---|
| `fms_objectstatusqueue` | btree (object,status,time) NON-unique | insert→delete | Inbound event log; `FMS_ObjectStatusQueueDel` deletes `WHERE Object=:O AND Time<=:T` (dequeue-and-purge) `[FACT - d1.sql:29114]` |
| `fms_objectstatus` | **btree UNIQUE (object,terminal,status)** | insert/update/delete | Current state; one row per (object,terminal,status) with `statuscount`+`timeset` `[FACT - d1.sql:3795 + modify]` |
| `fms_objectstatusaudit` | btree (object,status,time) NON-unique | insert only | History with `job,tors,card,switchingitem,fromapp,doname,rowtime,statusupdate` `[FACT - d1.sql:3827]` |

`statuscount` is a **reference count**, not a boolean: a status can be set by N sources; the row persists while count>0 and is garbage-collected at count<=0.

### Writers / mutators (real bodies)
- `[FACT - d1.sql:29125]` `FMS_ObjStatIns(Object,Terminal,Status,StatusCount,TimeSet)` — raw INSERT into `fms_objectstatus`.
- `[FACT - d1.sql:29128]` `FMS_ObjStatTimeSetUpd(...,increment,...)` — `SET StatusCount = StatusCount + :increment, TimeSet=:TimeSet` (the count-bump).
- `[FACT - d1.sql:29018]` `FMS_KeepStatusClean(Object,Status)` — `DELETE FROM fms_objectstatus WHERE Object AND Status` — invoked by rule `FMS_KeepStatusClean AFTER Update(StatusCount) … WHERE New.StatusCount <= 0` `[FACT - d1.sql:32960]`. Garbage collector.
- `[FACT - d1.sql:29022]` `FMS_KeepStatusCurrent(Feeder,Status)` — reconciles `fms_objectstatus` from a `COUNT(*)` of `fms_fromworkstatus`; inserts/updates/deletes to match. Wired by rules `FMS_KeepStatusCurrent1/2 AFTER INSERT/DELETE ON FMS_FromWorkStatus` `[FACT - d1.sql:32962,32964]`.
- `[FACT - d1.sql:29110]` `FMS_ObjectStatusAuditIns(...)` / `[FACT - d1.sql:29116]` `FMS_ObjectStatusQueueIns(...)` — append to audit/queue with full provenance (job/tors/card/switchingitem/fromapp/doname).

### Status → card-header propagation (rules)
`[FACT - d1.sql:32880-32913, 32927-32937]`:
| Status int | Meaning (from rule WHERE clauses) |
|---|---|
| `10044` | Station ground (→ `FMS_UpdateCardHeader` sets `fms_card.StationGround` On/Off) `[FACT - d1.sql:32880,29518]` |
| `10053` | Grounds (→ sets `fms_card.GroundsOn = StatusCount`) `[FACT - d1.sql:29517]` |
| `10016` | Equipment grounds (→ `FMS$GroundHistoryIns`; `FMS_UpdateGrounds` sums to `SOA_Job.Grounds`) `[FACT - d1.sql:32931,29523]` |
| `10034` | Dead move (→ `FMS_DeadMoveTOCount`) `[FACT - d1.sql:32909,32911]` |
| `10110` | Feeder cutout (→ `FMS_Feeder_Cutout`) `[FACT - d1.sql:32927,32929]` |
| `>10100` | "live HV status" band — `FMS_Status_Change` picks max-TimeSet status>10100 w/ count>0 as the feeder's current status `[FACT - d1.sql:29435]` |
| `10031`,`10032` | special statuses forcing a `FMS_Status_Change` dbevent raise `[FACT - d1.sql:29438]` |

### `FMS_Status_Change` — the status→card recompute (excerpt) `[FACT - d1.sql:29433]`
```
SELECT :ActiveCard=C.Card, :CurrentStatus=C.FeederStatus FROM FMS_Card C, TFMS_CardToObject CTO
 WHERE CTO.Object=:Object AND CTO.Card=C.Card AND C.Status=20;
IF ActiveCard>0 THEN
  SELECT :MaxTimeSet=ifnull(Max(TimeSet),'') FROM FMS_ObjectStatus
   WHERE Object=:Object AND Status>10100 AND StatusCount>0;
  ... pick Status@MaxTimeSet ... IF NewStatus<>CurrentStatus THEN
     UPDATE FMS_Card SET FeederStatus=:NewStatus, FeederStatusName=:NewStatusName WHERE Card=:ActiveCard;
     RAISE DBEVENT FMS_Status_Change :EventText;   -- payload "card:status:statusname"
```
`[INFERENCE]` The status machine is **derived/materialized**: `fms_objectstatus` is the truth, `fms_card.FeederStatus` is a denormalized cache recomputed on every status change, and a `FMS_Status_Change` dbevent notifies OpenROAD clients to refresh.

`[UNKNOWN]` The full status-code enumeration (the `udb_type` rows for types 10016/10031/10032/10034/10044/10053/10110/…) — requires absent seed data. Names above are inferred from rule predicates + `ug.html` ("HV object status"), not from a catalog.

### Bridge: `tfms_cardtoobject` `[FACT - d1.sql, TFMS module]`
`(card, object, type, name, status, seq, validatedby)` — maps an FMS card to the udb_object(s) it operates. Used by `FMS_Status_Change`, `FMS_UpdateCardHeader`, `FMS_NewActiveCard` to translate object↔card. `[FACT - d1.sql:29434,29518,29083]`

---

## 6. Automation control loop

### Tables
- `fms_automationcontrol(automationsequence, card, returnblock, returnsystem, action)` `[FACT - d1.sql:1860]` — a **FIFO command queue**; `automationsequence=0` means "unsequenced/new".
- `fms_automationblock(card, block, blockseq, sendto, initiatingdo, inittime, blocktitle, blockstatus, blockstart, blockstopped, stopreason, blockend, startonany, division, startondbf)` `[FACT - d1.sql:1819]` — execution blocks with full lifecycle timestamps + stop reason.

### The pump (real body) `[FACT - d1.sql:28370]`
```
FMS_AutoControlGo = ... BEGIN
  SELECT :MaxSeq = IFNULL(Max(AutomationSequence),0)+1 FROM FMS_AutomationControl;
  UPDATE FMS_AutomationControl SET AutomationSequence=:MaxSeq WHERE AutomationSequence=0;
  IF iierrornumber<>0 OR iirowcount>1 OR iirowcount=0 THEN RAISE ERROR -99 :msg;
  ELSE RAISE DBEVENT "ingres". FMS_AutomationGo; ENDIF;  END
```
Triggered by rule `FMS_AutoControl$Ins AFTER INSERT INTO FMS_AutomationControl WHERE New.AutomationSequence=0 EXECUTE PROCEDURE FMS_AutoControlGo` `[FACT - d1.sql:32860]`.

`[INFERENCE]` Control flow:
1. Client/SOA inserts an `fms_automationcontrol` row with `AutomationSequence=0`.
2. Rule fires `FMS_AutoControlGo`, which atomically assigns the next sequence number (enforcing exactly-one via `iirowcount>1` guard) and **raises dbevent `FMS_AutomationGo`**.
3. An external automation daemon (OpenROAD app, registered on `FMS_AutomationGo`) wakes, reads the queue, executes blocks (`fms_automationblock`), updates `BlockStatus`/`BlockStart`/`BlockStopped`/`BlockEnd` via `FMS_AutoBlock*Upd` procs `[FACT - d1.sql:28342-28368]`, and raises `FMS_AutomationStopped` on halt.
4. Block status updates feed back into the object-status machine and card.

### Block-lifecycle procs `[FACT - d1.sql]`
`FMS_AutoBlockIns` 28350, `FMS_AutoBlockSeqUpd` 28356, `FMS_AutoBlockStartUpd` 28359, `FMS_AutoBlockStatusUpd` 28362, `FMS_AutoBlockStopUpd` (sets BlockStatus+BlockStopped+StopReason) 28365, `FMS_AutoBlockEndUpd` 28347, `FMS_AutoBlockDel` 28342.

### dbevents (45) — the signaling fabric `[FACT - d1.sql:26608-26860]`
All are bare named events (register+raise granted to public; **no typed payload in DDL** — payload is a runtime string, e.g. `FMS_Status_Change` carries `card:status:name`). Grouped:

| Group | dbevents |
|---|---|
| Automation | `fms_automationgo`, `fms_automationstopped`, `fms_dodelay`, `fms_delaycleared`, `fms_deadmovescount`, `fms_splitnetwork` |
| Card lifecycle | `fms_card_control_taken`, `fms_card_grounds`, `fms_card_request`, `fms_reloadcardheader`, `fms_loadcommoncard`, `fms_purgeopencard`, `fms_invalidcard`, `fms_status_change` |
| SCADA/SOCCS exec | `fms_sxcomplete`, `fms_sxcutin`, `fms_sxcutout`, `fms_sxopenauto`, `fms_sxprocessing`, `fms_sxtransfer`, `fms_feeder_change`, `fms_feeder_cutout` |
| Faults/phase | `fms_faultcorrelation`, `fms_phasecheckcompl`, `fms_update_grounds` |
| Process mgmt | `fms_monitorresponse`, `fms_querymonitor`, `fms_shutdownmonitor`, `fms_shutdownmonitorresponse`, `fms_stopallapps`, `fms_stopuserapp`, `fms_stopreportmonitors`, `fms_inactivetimer`, `fms_processingwarning`, `fms_completewarning`, `fms_estimateduptime`, `fms_logstat_status` |
| Messaging/notif | `fms_emaildbevent`, `fms_send_message`, `fms_evalglobalnotif`, `fms_taskdbevent`, `fms_dbeventqueue`(via table), `fms_oswpdbevent`, `fms_objectstatusaudit`, `fms_objectstatusqueue` |

`[INFERENCE]` `fms_sx*` events bridge to **SOCCS/SCADA** switching-execution (`fms_soccsxmessage` = the device-level status feed: device, devicetime, status, substation). FMS consumes real-time field/SCADA confirmations and translates them into object-status + card updates.

---

## 7. FMS ↔ SOA / udb_object boundaries

`[FACT - d1.sql]` Concrete cross-module writes (FMS PRODUCES into SOA/UDB):

1. `[FACT - d1.sql:28490]` `FMS_CardStatusChange` → `UPDATE SOA_Card SET Status=:Status WHERE Card=:Card` (card status mirror), wired by rule `FMS_Card$StatusChange AFTER UPDATE(Status) ON FMS_Card` `[FACT - d1.sql:32870]`. RAISE ERROR rolls back if SOA update fails → **transactional coupling**.
2. `[FACT - d1.sql:29523]` `FMS_UpdateGrounds` → sums `fms_objectstatus` (status 10016) and `UPDATE SOA_Job SET Grounds=... FROM SOA_Card, SOA_JobControl WHERE C.Status<50`. Then raises `FMS_Update_Grounds`.
3. `[FACT - d1.sql:28506]` `FMS_CascadeEquipVal` → invalidates `Udb_Object` validation when equipment fails (`SuperType=26` = equipment supertype, `40` = feeder supertype).
4. `[FACT - d1.sql:30683]` `SLC_AddEquipmentOnLine` (shared) inserts `Udb_Object`+`Udb_Grouping`+`Udb_Switch` — FMS-adjacent equipment creation against the udb_ metamodel.
5. FMS rules fire ON `Udb_Grouping`/`Udb_Object`/`Udb_ExtendedType`/`Udb_Switch`/`Udb_Type` (associations, feeder-division membership, equip-class subtype membership, switch open-state). `[FACT - d1.sql:32852-33010]` FMS **reacts to** udb_object/grouping changes (CONSUMES udb status).

`[INFERENCE - direction]`:
- **SOA → FMS**: SOA authors switching orders; FMS receives jobs/cards (the `fms_objectstatusqueue` provenance carries `job`,`tors`,`switchingitem`,`fromapp` — i.e., from SOA/SLC). FMS executes them in the field.
- **FMS → SOA**: FMS pushes back live execution status (card status, grounds counts) into `SOA_Card`/`SOA_Job`.
- **FMS ↔ udb_object**: `fms_objectstatus.object` = `udb_object.object`. FMS is the real-time STATUS overlay on the static udb_ equipment metamodel; `tfms_cardtoobject` is the card↔object bridge.

`[UNKNOWN]` The exact SOA proc that enqueues into `fms_objectstatusqueue` — not located in FMS region (lives in SOA's ~480 procs). The queue's provenance columns prove the producer is cross-module but the inserting proc was not read.

---

## 8. Transaction boundaries

`[INFERENCE - from proc bodies]`:
- Procs use the OpenROAD/Ingres pattern: each proc is one logical unit; errors → `RAISE ERROR -1 :msg` (aborts caller's transaction) or `RETURN -1` (soft fail, caller decides). `[FACT - d1.sql:28491,28495]`
- `SetSesameLockCardFormID` does explicit per-row `COMMIT` inside a WHILE loop — **non-atomic batch** `[FACT - d1.sql:30679]`.
- Rules execute **synchronously within the triggering transaction** (Ingres AFTER rules), so e.g. an FMS_Card status update + the SOA_Card cascade + the dbevent raise are one transaction; failure of the SOA cascade rolls back the card change (`RAISE ERROR`). `[INFERENCE - d1.sql:28490 + rule 32870]`
- dbevents are raised **after** the data change commits (Ingres delivers on commit), decoupling notification from the writing transaction. `[INFERENCE]`
- `fms_dbeventqueue` (id,name,text,toapp,fromapp,attempt) is a **durable retry queue** for dbevents that need guaranteed delivery (the `attempt` counter implies redelivery). `[FACT+INFERENCE - d1.sql:2225]`

---

## 9. Mermaid — FMS object-status state machine + automation loop

```mermaid
flowchart TD
  subgraph SOA["SOA / SLC (order authoring)"]
    SO[Switching order / job/tors/switchingitem]
  end
  SO -->|enqueue w/ provenance| Q[fms_objectstatusqueue]
  Q -->|dequeue + purge\nFMS_ObjectStatusQueueDel| CUR[fms_objectstatus\nUNIQUE object,terminal,status\nstatuscount = refcount]
  CUR -->|append| AUD[fms_objectstatusaudit\nappend-only history]
  CUR -->|count<=0\nrule FMS_KeepStatusClean| GC[(deleted)]
  FWS[fms_fromworkstatus] -->|rule KeepStatusCurrent\nreconcile| CUR
  CUR -->|status 10044/10053\nFMS_UpdateCardHeader| CARD[fms_card\nFeederStatus / StationGround / GroundsOn]
  CUR -->|status>10100 max TimeSet\nFMS_Status_Change| CARD
  CUR -->|status 10016 sum\nFMS_UpdateGrounds| SOAJOB[SOA_Job.Grounds]
  CARD -->|rule FMS_Card$StatusChange\nFMS_CardStatusChange| SOACARD[SOA_Card.Status]
  CARD -->|raise| EV1((dbevent\nFMS_Status_Change\nFMS_Card_Grounds))

  subgraph AUTO["Automation loop"]
    AC0[insert fms_automationcontrol\nAutomationSequence=0]
    AC0 -->|rule FMS_AutoControl$Ins| GO[FMS_AutoControlGo\nassign next seq]
    GO -->|raise| EVAGO((dbevent FMS_AutomationGo))
    EVAGO -.->|external automation app| BLK[fms_automationblock\nBlockStatus lifecycle]
    BLK -->|FMS_AutoBlock*Upd| BLK
    BLK -->|halt| EVASTOP((dbevent FMS_AutomationStopped))
  end
  EV1 -.->|OpenROAD clients refresh| UI[Card UI]
  SX[SCADA/SOCCS\nfms_soccsxmessage] -->|fms_sx* dbevents| CUR
```

---

## 10. Contradictions / cautions surfaced

1. **Task brief says read `fms_job`** — no such table exists. `[FACT]` Job model = `fms_card` + `fms_jobclass*`/`fms_jobaction`/`fms_droppedequipjobs`; canonical row shape in `fms_archivejob`. Adjust downstream synthesis accordingly.
2. **"2,450 procedures inside d1.sql are the real logic"** is only half-true for FMS: the `fms_…` procs in the upper region are **empty stubs**; the real bodies are the `FMS_…` (capitalized, `= DECLARE…BEGIN`) bodies ~line 28230+. Anyone grepping `procedure fms_x` and reading `as begin return; end` will wrongly conclude FMS has no logic. `[FACT]`
3. **`psm_dbprocs.dmt` is a 22-line stub** (only includes `core.plb`) — irrelevant; the real bodies are in d1.sql's lower region. `[FACT - Phase 0 + confirmed]`
4. **Sesame-lock is descriptive, not enforcing** — no proc gates a switching move on `fms_sesamelockcard`. Clearance enforcement (if any) is elsewhere (SOA/SLC/udb_object lock fields). `[INFERENCE/UNKNOWN]`

## 11. Hard UNKNOWNs (need absent seed rows)
- Full `fms_card.status` / `cardclass` / `typeofcard` enumerations.
- Full object `status` code catalog (10016/10031/10032/10034/10044/10053/10110/>10100 names) — only rule predicates + ug.html hints available.
- `fms_jobclass` / `fms_jobaction` actual job-class → status-action mappings (data-driven).
- Which external apps register on each dbevent (OpenROAD `psm.dmt` frames may hold this — not analyzed here).
- The SOA-side proc that populates `fms_objectstatusqueue`.
