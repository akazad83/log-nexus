# Metamodel-Core (UDB / PSDM) — Raw Analysis

Domain: the UDB metamodel CORE — `udb_object` (the universal object table) + the type-system control tables (`udb_type`, `udb_basetype`, `udb_supertype`, `udb_extendedtype`). This is a **hand-rolled, data-driven, single-table-inheritance (STI) object model** sitting on Actian Ingres.

Primary source: `d:/103_RnD/psm_v1/d1.sql`. Client semantics cross-checked in `psm.dmt` and `ug.html`.

> The PSM/PSDM application that "supports" these tables is named in the user guide: *"The underlying connected data model, consisting of Udb tables like Udb_Type, Udb_Object, Udb_Grouping, etc, is supported by the Udb / PSDM (Power System Data Model) application."* [FACT - ug.html:5121-5123]

---

## 1. The five core tables (verbatim DDL)

### 1.1 `udb_object` — the universal object table [FACT - d1.sql:14388-14418]

```
create table udb_object(
    object integer not null not default,          -- PK
    source integer,                               -- nullable FK (provenance)
    systemversion integer not null default 0,
    basetype integer not null default 0,          -- FK -> udb_basetype.type (DENORMALIZED, derived from type)
    type integer not null default 0,              -- FK -> udb_type.type
    primarygrouping integer not null default 0,   -- FK -> udb_object.object (self-ref: parent grouping)
    typename varchar(40) not null default ' ',    -- CACHE of udb_type.name
    primarygroupingname varchar(40) not null default ' ', -- CACHE of parent udb_object.name
    name varchar(40) not null default ' ',
    description varchar(60) not null default ' ',
    comment varchar(200) not null default ' ',
    status char(16) not null default ' ',         -- lifecycle/state (enumeration UNKNOWN - no seed rows)
    terminals integer not null default 0,          -- electrical terminal count -> drives udb_terminal fan-out
    inservice ingresdate,                          -- nullable
    outservice ingresdate,                         -- nullable
    positionx f4,                                  -- nullable GIS coord
    positiony f4,                                  -- nullable GIS coord
    ownernumber char(20) not null default ' ',
    serialnumber char(20) not null default ' ',
    specnumber char(20) not null default ' ',
    combination char(20) not null default ' ',
    locknumber varchar(40) not null default ' ',
    validated ingresdate,                          -- nullable (audit)
    validatedby char(24) not null default ' ',
    locked ingresdate,                             -- nullable (audit)
    lockedby char(24) not null default ' ',
    created ingresdate,                            -- nullable (audit)
    createdby char(24) not null default ' ',
    lastchanged ingresdate,                        -- nullable (audit)
    lastchangedby char(24) not null default ' '
)
```
Storage: `modify udb_object to btree unique on object` — clustered PK on `object`. `row_estimate = 105880` (the load-time estimate; actual row count UNKNOWN — data file absent). [FACT - d1.sql:14427-14441]

### 1.2 `udb_type` — the type catalog (the "class" table) [FACT - d1.sql:15102-15107]
```
create table udb_type(
    type integer not null not default,            -- PK part 1
    basetype integer not null not default,        -- FK -> udb_basetype.type
    name char(40) not null not default,           -- PK part 2 (unique btree on type,name)
    description char(60) not null default ' '
)
```
`modify udb_type to btree unique on type, name`. `row_estimate = 2054`. [FACT - d1.sql:15119, 15117]

### 1.3 `udb_basetype` — base-type -> physical wiring (STI dispatch table) [FACT - d1.sql:13363-13367]
```
create table udb_basetype(
    type integer not null not default,            -- PK (the base-type id)
    editorname char(20),                          -- OpenROAD editor frame name (CLIENT use only)
    tablename char(20)                            -- per-type SUBTYPE table name (server STI dispatch)
)
```
`modify udb_basetype to btree unique on type`. `row_estimate = 41` — i.e. **~41 base types** (the count of distinct physical subtype shapes). [FACT - d1.sql:13379, 13377]

### 1.4 `udb_supertype` — class hierarchy AS DATA (direct edges) [FACT - d1.sql:14679-14682]
```
create table udb_supertype(
    type integer not null not default,
    supertype integer not null not default
)
```
`modify udb_supertype to btree unique on type, supertype`. `row_estimate = 3577`. [FACT - d1.sql:14694, 14692]

### 1.5 `udb_extendedtype` — materialized TRANSITIVE CLOSURE of supertype [FACT - d1.sql:13839-13842]
```
create table udb_extendedtype(
    type integer not null not default,
    supertype integer not null not default
)
```
`modify udb_extendedtype to btree unique on type, supertype`. `row_estimate = 15441` — **~4.3x larger than `udb_supertype` (3577)**, consistent with a closure expansion (every type gains a row for itself + all transitive ancestors). [FACT - d1.sql:13854, 13852]

---

## 2. Single-table-inheritance design

**Pattern:** ONE wide root table (`udb_object`) holds every object's common attributes (identity, name, lifecycle, GIS, audit). Type-specific (subclass) attributes live in **per-type "side" tables keyed 1:1 on `object`**. The first column of each such subtype table is `object` (FK to `udb_object.object`). [FACT - inspected DDL]

Subtype tables in the `udb_` namespace whose first data column is `object` (STI side tables) — **24 electrical/equipment subtype tables** (excluding the audit/temp/grasscatcher noise):

| Subtype table | Domain meaning [INFERENCE from name + DDL] |
|---|---|
| udb_bwrsteamsupply | Boiling-water-reactor steam supply |
| udb_capacitor | Capacitor (nominalmvar, voltsensitivity, avrdelay) |
| udb_circuitroute | Circuit routing |
| udb_combustionturbine | Combustion turbine |
| udb_communicationlink | Comms link |
| udb_computer | Computer asset |
| udb_conductor | Line conductor (r,x,bch,length,towertype...) |
| udb_conductortype | Conductor-type spec |
| udb_consumer | Load/consumer (pfixed,qfixed,pnom,qnom...) |
| udb_dsovalve | DSO valve (gas/pipe domain) |
| udb_fossilsteamsupply | Fossil steam supply |
| udb_generator | Generator |
| udb_hydroturbine | Hydro turbine |
| udb_loadcurve | Load curve |
| udb_location | Geographic location attrs |
| udb_measurementtype | Measurement-type spec |
| udb_person | Person/contact |
| udb_pwrsteamsupply | Pressurized-water-reactor steam supply |
| udb_rating | Equipment rating |
| udb_reactor | Reactor (shunt) |
| udb_scanblock | SCADA scan block |
| udb_steamturbine | Steam turbine |
| udb_switch | Switch (normalopen,currentlyopen,relaytype,networktype,stoptag) |
| udb_tapsetting | Transformer tap setting |
| udb_telemetry | Telemetry point |
| udb_telephonecircuit | Telephone circuit |
| udb_towertype | Tower-type spec |
| udb_transformer | Transformer (bank,phases,magbasekv,gmag...) |
| udb_winding | Transformer winding |

[FACT - d1.sql, awk first-column scan]

`udb_terminal` and `udb_node` are **electrical-connectivity** tables, also keyed on `object`/`node`, not pure STI subtype rows: `udb_terminal(object, basetype, terminal, node, inservice, outservice)` — note `basetype` and `inservice/outservice` are **denormalized copies** of the parent `udb_object` values. [FACT - d1.sql:14997-15006, 14359-14365]

`udb_grasscatcher(object, problem, text, known)` is NOT a subtype — it is the **validation-error sink** (see §6). `udb_problem(problem, severity, description)` is the **problem-code catalog**. [FACT - d1.sql:13973-13977, 14473-14477]

---

## 3. "What is this object?" — the exact resolution path

The canonical resolution is hard-coded in `object$insert`. The join that answers identity is:

> `SELECT :BaseType = BT.Type, :TableName = BT.TableName FROM Udb_Type T, Udb_BaseType BT WHERE :Type = T.Type AND T.BaseType = BT.Type;` [FACT - d1.sql:30457-30458, proc `object$insert`]

So resolution is:

```
udb_object.type
   -> udb_type   (type = T.type)            : gives T.basetype, T.name
       -> udb_basetype (T.basetype = BT.type): gives BT.tablename  (which physical subtype table)
                                              gives BT.editorname (which OpenROAD frame)
```

- `udb_basetype.tablename` => the per-type subtype table holding subclass columns (e.g. `'Switch'` -> `udb_switch`). **Server-side STI dispatch.** [FACT - d1.sql `object$insert`]
- `udb_basetype.editorname` => the OpenROAD editor frame to open for that base type. **Client-side only** — `editorname` appears in NO server procedure body anywhere in `d1.sql` (only in the table DDL and in grants). It is consumed by `psm.dmt` frames. [FACT - grep editorname -> only DDL/grants; INFERENCE - it is the UI editor binding]
- `udb_object.basetype` and `udb_object.typename` are **denormalized derivations** written at insert time (see §5).

### 3.1 CRITICAL CONTRADICTION — dispatch is data-driven in schema but HARD-CODED in `object$insert`
Although `udb_basetype.tablename` is *designed* to be a data-driven dispatch key, `object$insert` does NOT do dynamic SQL. After reading `TableName` from `udb_basetype`, it runs a **hard-coded IF/ELSEIF ladder on the string value**, inserting the stub child row only for an enumerated subset:

> `IF (TableName = '') THEN TableName=TableName; ELSEIF (TableName='Conductor') THEN INSERT INTO Udb_Conductor(Object)...; ELSEIF (TableName='Generator') THEN ... Udb_Generator ...; ELSEIF 'Consumer'->Udb_Consumer; 'Capacitor'->Udb_Capacitor; 'Reactor'->Udb_Reactor; 'Switch'->Udb_Switch; 'Transformer'->Udb_Transformer; 'Telemetry'->Udb_Telemetry; 'TowerType'->Udb_TowerType; 'ConductorType'->Udb_ConductorType; 'Computer'->Udb_Computer; 'MeasurementType'->Udb_MeasurementType; 'Person'->Udb_Person; 'CombustionTurbine'->Udb_CombustionTurbine; 'HydroTurbine'->Udb_HydroTurbine; 'SteamTurbine'->Udb_SteamTurbine; 'FossilSteamSupply'->Udb_FossilSteamSupply; 'BWRSteamSupply'->Udb_BWRSteamSupply; 'PWRSteamSupply'->Udb_PWRSteamSupply; 'CommunicationLink'->Udb_CommunicationLink; 'TelephoneCircuit'-> Udb_TelephoneCircuit + Udb_CircuitRoute; 'EquipTemplate'->SLC_EquipTemplate; ENDIF;` [FACT - d1.sql:30458 region, proc `object$insert`]

Consequences (implementation-critical):
- `udb_basetype` rows whose `tablename` is NOT in this ladder (e.g. `Capacitor` IS handled, but `Location`, `Rating`, `Winding`, `TapSetting`, `ScanBlock`, `LoadCurve`, `DsoValve`, `Telephone`-routing subtypes…) get **NO automatic child row** on insert — those side rows must be created by other paths. [INFERENCE - the ladder is a closed set; subtype tables exist that are absent from it]
- `'TelephoneCircuit'` uniquely also seeds `udb_circuitroute(object, route)=( ,0)`. [FACT]
- `'EquipTemplate'` dispatches OUTSIDE the udb_ namespace to `SLC_EquipTemplate` — proof the metamodel is shared across modules. [FACT]
- Adding a new base type requires BOTH a data row in `udb_basetype` AND a code edit to `object$insert`. The "data-driven" claim is therefore only half-true. [INFERENCE]

---

## 4. `udb_supertype` / `udb_extendedtype` — class hierarchy as data

- `udb_supertype(type, supertype)` stores **direct** is-a / part-of edges between types (the class graph). [FACT - DDL]
- `udb_extendedtype(type, supertype)` is the **materialized transitive closure** of that graph, maintained by trigger procs.

Closure maintenance, proven in `SuperType$Insert` [FACT - d1.sql:31831 region]:
1. `DELETE FROM Udb_ExtendedType WHERE Type = :Type;`  — wipe the type's closure rows.
2. `INSERT INTO Udb_ExtendedType (Type, SuperType) VALUES (:Type, :Type);` — **reflexive self-edge** (every type is its own extended-supertype). This self-edge is why extendedtype (15441) >> supertype (3577).
3. `INSERT INTO Udb_ExtendedType (Type, SuperType) SELECT DISTINCT :Type, SuperType FROM Udb_ExtendedType ET WHERE ET.Type IN (SELECT DISTINCT SuperType FROM Udb_SuperType WHERE Type = :Type AND SuperType != :Type);` — inherit every ancestor's already-closed supertypes (one-level closure step relying on parents already being closed).
4. Validates `BaseType` consistency: if `T.BaseType != 0` and there is no `udb_extendedtype` row linking `Type -> BaseType`, raises problem `'Type_008'` into grasscatcher. [FACT]

`SuperType$Delete` mirrors this: rebuilds closure, and guards against deleting a supertype still referenced (`Type_001`, `Type_002` problems if `udb_object` rows or child supertypes still depend on it, unless an extendedtype row to literal supertype `15028` exists — a magic id, meaning UNKNOWN without seed rows). [FACT - d1.sql:31823 region]

Rules wiring the closure: [FACT - d1.sql:33260-33264]
- `SuperType$Insert1 AFTER INSERT ON Udb_SuperType -> SuperType$Insert`
- `SuperType$Update AFTER UPDATE ON Udb_SuperType -> SuperType$Insert`
- `SuperType$Delete AFTER DELETE ON Udb_SuperType -> SuperType$Delete`

Closure is **consumed** in branch logic across modules via `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)` — e.g. FMS card-class validation requires the card class be a descendant of supertype `10093`:
> `... Udb_Type WHERE Type = :CardClass AND Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = 10093);` [FACT - d1.sql:29552]
and `Object$PrimaryGrouping` tests node membership via `PG.Type IN (SELECT ET.Type FROM Udb_ExtendedType ET WHERE ET.SuperType = 05)`. [FACT - d1.sql:30490 region]

So `udb_extendedtype` is the **polymorphic "is-a-kind-of" test surface**: instead of walking the supertype graph at query time, code does a single closure-table lookup. [INFERENCE]

---

## 5. `udb_object`'s 30 columns by role

| Role | Columns | Notes |
|---|---|---|
| **Identity / FK** | `object` (PK), `source`, `systemversion`, `basetype`, `type`, `primarygrouping` | `type`->udb_type; `basetype`->udb_basetype (derived); `primarygrouping`->self-ref parent (udb_object.object). `source` nullable = provenance. [FACT] |
| **Denormalized name caches** | `typename`, `primarygroupingname` | `typename` = copy of `udb_type.name`; `primarygroupingname` = copy of parent object's `name`. Maintained by triggers. [FACT - object$insert, Object$TypeName, Object$Name] |
| **Descriptive** | `name`, `description`, `comment` | free text |
| **Generic-overloaded identity** | `ownernumber`, `serialnumber`, `specnumber`, `combination`, `locknumber` | five char(20)/varchar(40) "tag" slots reused per type — meaning varies by object type (classic god-table overloading). char(20) except locknumber varchar(40). [FACT - DDL; INFERENCE - reuse] |
| **Lifecycle / state** | `status` char(16), `inservice`, `outservice`, `terminals` | `status` enumeration UNKNOWN (no seed rows). `terminals` int -> at insert, fans out N rows into `udb_terminal`. `inservice`/`outservice` nullable dates drive `Object$Validate`. [FACT] |
| **GIS coords** | `positionx` f4, `positiony` f4 | nullable single-precision floats. (Separate `nodes_xy`/`objects_xy` GIS tables exist elsewhere.) [FACT] |
| **Audit pairs (4)** | `validated`/`validatedby`, `locked`/`lockedby`, `created`/`createdby`, `lastchanged`/`lastchangedby` | date is nullable ingresdate; `*by` is char(24) sentinel-defaulted ' '. `created`/`createdby` set in object$insert (`Created='Now', CreatedBy=VARCHAR(User)`). [FACT - d1.sql object$insert] |

Trigger-maintained denormalization [FACT - rules d1.sql:33131-33148, 33372]:
- `Object$Insert1 -> object$insert` (sets `basetype`, `typename`, `primarygroupingname`, `created`, `createdby`; fans out terminals; inserts child STI stub; inserts primary-grouping edge with relationship `52`).
- `Object$Update_Type -> Object$TypeName` (`UPDATE Udb_Object O FROM Udb_Type T SET TypeName = T.Name WHERE T.Type = O.Type AND O.Tid = :Tid`).
- `Object$Update_Name -> Object$Name` (refresh children's `primarygroupingname`).
- `Object$Update_PG -> Object$PrimaryGrouping` (maintains `udb_grouping` relationship-52 edges; for `BaseType=21` does consumer-load arithmetic roll-up).
- `Udb$CascadeTypeName` (rule `Udb$CascadeTypeName AFTER UPDATE(Name) ON Udb_Type`): `UPDATE Udb_Object SET TypeName = :NewTypeName WHERE Type = :Type` — propagates a type rename to all instances' cache. [FACT - d1.sql:32502, 33372]
- `CascadeType$Change` (rule `CascadeType$Change AFTER UPDATE(Type) ON Udb_Object`): updates `udb_grouping.membertype`/`groupingtype` to the new type. [FACT - d1.sql:27983, 32789]

So **`basetype`, `typename`, `primarygroupingname` are all redundant derivations** kept consistent only by trigger discipline — any direct DML bypassing the rules silently desyncs them. [INFERENCE]

---

## 6. The sentinel-default pattern — 20 of 30 columns

Exact count [FACT - awk/grep on udb_object DDL]:
- **20 / 30** columns are sentinel-defaulted: `default ' '` (varchar/char) or `default 0` (integer). `not null` + sentinel default.
- **9 / 30** are genuinely nullable (no `not null`): `source`, `inservice`, `outservice`, `positionx`, `positiony`, `validated`, `locked`, `created`, `lastchanged` — i.e. the dates + `source` + the 2 GIS floats.
- **1 / 30** is `not null not default`: the PK `object`.

Why sentinel defaults are WORSE than NULL for integrity [INFERENCE, but structurally grounded]:
1. **Cannot distinguish "unknown" from "blank/not-applicable."** `serialnumber = ' '` could mean (a) never entered, (b) intentionally blank, (c) N/A for this type. NULL + a separate convention would separate these; `' '` collapses them. Same for `basetype/type/primarygrouping = 0`: `0` is simultaneously "root/none" AND "not yet resolved" AND a possibly-valid sentinel object id.
2. **Magic-value coupling.** Code must test `= 0` / `= ' '` everywhere (e.g. `object$insert`: `IF (BaseType = 0) THEN ...grasscatcher Object_012`; `IF (PrimaryGrouping != 0) THEN ...`). A real NULL with `IS NULL` is checkable by the engine and by constraints; sentinel `0` is indistinguishable from a legitimate `0`. [FACT - object$insert branches on `=0`]
3. **`udb_object.object = 0` is explicitly an ERROR state**, guarded by rule `Object$NullObjectProtect AFTER INSERT,UPDATE ON Udb_Object WHERE new.Object = 0 -> reject('Object_014')`. The fact that `0` had to be *banned by a trigger* is direct evidence the sentinel-zero convention leaks a forbidden value into a meaningful column. [FACT - d1.sql:33137]
4. **Aggregations/joins silently include sentinels.** A join `udb_object.basetype = udb_basetype.type` matches the sentinel `0` against any base type whose id happens to be `0`, rather than being eliminated by NULL semantics. [INFERENCE]
5. **No index null-skip benefit; no DBMS-enforced "required" check.** Because the column is `not null default ' '`, the engine can never tell you a value was actually supplied — the app layer must enforce presence, and it does so reactively via grasscatcher problems (`Type_010` "type name blank", `Object_012` "no basetype"), i.e. **post-hoc soft validation instead of hard constraints**. [FACT - Type$Insert, object$insert]

The grasscatcher mechanism IS the integrity layer this design substitutes for real constraints: triggers insert `(object, problem)` rows into `udb_grasscatcher`; `udb_problem` holds severity+description per problem code. Validation is **detective, not preventive** (rows are written first, problems flagged after). [FACT - d1.sql:30458 (`Object_012`), 30492 (`Object$Validate` -> `Object_001`), 31831 (`Type_004/005/008/009`), 13973/14473 DDL]

---

## 7. Type universe — what we can and cannot know

- **`udb_basetype` row_estimate = 41** => ~41 base types (physical subtype shapes). The base-type *names* are UNKNOWN (no seed data), but the **`tablename` targets are partially recoverable** from `object$insert`'s string ladder: `Conductor, Generator, Consumer, Capacitor, Reactor, Switch, Transformer, Telemetry, TowerType, ConductorType, Computer, MeasurementType, Person, CombustionTurbine, HydroTurbine, SteamTurbine, FossilSteamSupply, BWRSteamSupply, PWRSteamSupply, CommunicationLink, TelephoneCircuit, EquipTemplate(SLC_)` = **22 named dispatch targets** (subset of the 41). [FACT - object$insert]
- **`udb_type` row_estimate = 2054** => ~2054 concrete types. The full type list is **[UNKNOWN]** — it lives only in the absent `udb_type.ingres` data file. Do NOT enumerate it.
- Specific type/supertype ids appearing as **magic constants** in proc/rule bodies (these ARE in the dump and ARE real, but their human meaning is UNKNOWN without seed rows): `10093` (FMS CardClass base — confirmed by rule `FMS_CardClass$Delete1 WHERE Old.BaseType=10093`), `26` (FMS EquipClass base — rule `FMS_EquipClass$Delete WHERE Old.BaseType=26`), `21` (consumer/load-management basetype — `object$primarygrouping IF (BaseType=21)`), `52` (the "primary grouping" relationship id), `05` (node supertype), `15028` (supertype guard in SuperType$Delete), `999,22173,22174` (obsolete object types — rule `Udb_ObsoleteObjClean`), `10` (line type — rule `Udb_Object$NewCFGLine2 New.Type=10`). [FACT - cited rules/procs]
- Status enumeration (`udb_object.status char(16)`): **[UNKNOWN]** — no seed rows; not enumerated anywhere in DDL. Type-of-card / class names: **[UNKNOWN]**.

---

## 8. Mermaid — metamodel resolution path

```mermaid
classDiagram
    class udb_object {
        +int object PK
        int type FK
        int basetype "denormalized FK"
        int primarygrouping "self-ref"
        varchar typename "cache of udb_type.name"
        varchar primarygroupingname "cache of parent.name"
        char status
        int terminals
        ingresdate inservice
        ingresdate outservice
        f4 positionx
        f4 positiony
        char ownernumber
        char serialnumber
        char specnumber
        char combination
        varchar locknumber
        audit validated/locked/created/lastchanged (+by)
    }
    class udb_type {
        +int type PK
        +char name PK
        int basetype FK
        char description
    }
    class udb_basetype {
        +int type PK
        char tablename "-> STI subtype table"
        char editorname "-> OpenROAD frame"
    }
    class udb_supertype {
        int type
        int supertype
    }
    class udb_extendedtype {
        int type
        int supertype "transitive closure + self"
    }
    class udb_switch
    class udb_transformer
    class udb_consumer
    class udb_conductor
    class OpenROAD_Frame
    class udb_grasscatcher {
        int object
        char problem
    }

    udb_object --> udb_type : type = type
    udb_type --> udb_basetype : basetype = type
    udb_basetype ..> udb_switch : tablename='Switch'
    udb_basetype ..> udb_transformer : tablename='Transformer'
    udb_basetype ..> udb_consumer : tablename='Consumer'
    udb_basetype ..> udb_conductor : tablename='Conductor'
    udb_basetype ..> OpenROAD_Frame : editorname (CLIENT only)
    udb_switch --|> udb_object : object 1:1 (STI subtype)
    udb_transformer --|> udb_object : object 1:1
    udb_consumer --|> udb_object : object 1:1
    udb_conductor --|> udb_object : object 1:1
    udb_type --> udb_supertype : type
    udb_supertype ..> udb_extendedtype : closure (SuperType$Insert)
    udb_object ..> udb_grasscatcher : soft-validation problems
```

```mermaid
erDiagram
    udb_object ||--o| udb_switch : "object (STI)"
    udb_object ||--o| udb_transformer : "object (STI)"
    udb_object ||--o{ udb_terminal : "object, terminals"
    udb_object }o--|| udb_type : "type"
    udb_type }o--|| udb_basetype : "basetype -> type"
    udb_type ||--o{ udb_supertype : "type"
    udb_supertype ||--o{ udb_extendedtype : "closure"
    udb_object ||--o{ udb_grasscatcher : "problems"
    udb_problem ||--o{ udb_grasscatcher : "problem code"
```

---

## 9. Server-side vs client-side split (definitive)

| Concern | Where | Evidence |
|---|---|---|
| STI child-row creation, type resolution, denorm caches, closure maintenance, soft validation | **Server** (db procs in `d1.sql`, fired by Ingres rules) | object$insert, Object$TypeName, SuperType$Insert, rules 33131-33381 [FACT] |
| `editorname` -> which UI editor frame opens | **Client** (OpenROAD, `psm.dmt`) | `editorname` never referenced by any server proc; `BaseType`/`SuperType` logic present throughout psm.dmt [FACT - grep] |

---

## 10. Open items / UNKNOWNs

- Full `udb_type` catalog (2054 rows), `udb_basetype` catalog (41 rows incl. all `tablename`/`editorname` values), `udb_supertype` edges, `udb_object.status` enumeration — **all UNKNOWN** (external `.ingres` data files absent). [FACT - copy-from statements reference missing files]
- Meaning of magic ids `15028`, `52`, `05`, `21`, `26`, `10093`, `999/22173/22174`, `10` — ids are real (in proc/rule bodies) but their seed-row semantics are UNKNOWN.
- Which of the 41 base types lack an `object$insert` dispatch branch (the ladder names only ~22) — exact gap UNKNOWN without `udb_basetype` data; structurally certain that a gap exists.
- Whether `udb_object.basetype` can ever legitimately differ from `udb_type.basetype` (it is derived at insert but a later `udb_type.basetype` change is not obviously cascaded to instances) — **potential desync bug, UNVERIFIED**. [INFERENCE]
