# Peripheral Modules & Integration Surfaces — Raw Analysis

Source of record: `d:/103_RnD/psm_v1/d1.sql` (Ingres DDL/dump) + `ug.html` (business semantics). No row data exists (every table loaded via absent `copy ... from '/home/ingres/Downloads/*.ingres'`); `row_estimate=N` on each `copy` is a loader sizing hint = relative scale only, NOT authoritative counts.

## 0. CRITICAL STRUCTURAL NOTE ON PROCEDURE BODIES
[FACT - d1.sql] The dump defines every procedure **twice**: an early **STUB** block (`create or replace procedure NAME as begin return; end`, lines ~21883–24351; 1,225 stubbed) and a later **REAL** body block (`create or replace procedure NAME ( args ) = BEGIN ... END`, lines 27758–32790). Of 2,450 `create or replace procedure` statements, 1,225 are stub forms and 1,225 carry real bodies. **The real bodies (later block) are authoritative.** Anyone grepping only the first hit per name gets `begin return; end` and wrongly concludes the logic is empty. All proc logic below is quoted from the REAL block.

---

## 1. MODULE FAMILY ONE-LINERS (non-integration)

Application identity (ug.html:5093-5100 [FACT]): 5 switching apps use DBM — **FMS** (Distribution Feeders), **TOMS/SOA** (Substations=**SLC** + Transmission Feeders=**TFMS**), **TLS** (Telephone Lines; on FMS DB), **SMS** Steam Mgmt (standalone **SDS** DB), **DSO** = **Dielectric Switching Operations** (standalone DSO DB, separate `DSO_DBM` image).

| Family | #tbl | One-line purpose | Evidence |
|---|---|---|---|
| `cac_` | 24 | **Clearance Assurance / relay-operation control**: relay-op logs (`cac_relayops`,`cac_relayopscontrol`), clearance-order groupings (`cac_co_*` = "CO" cards w/ circuit/feeder/note/status/attachment), relay groupings (`cac_relay_*`), card↔type maps (`cac_cardtype`,`cac_relaytypes`), and **`cac_softwarelevel`** = release version gate (ug.html:6853 — app shuts down on version mismatch). | [FACT - d1.sql DDL; ug.html:5218,6853] |
| `tfms_`/`tfmsddb_` | 14+2 | **Transmission Feeder Mgmt System** cards (`tfms_card`,`tfms_cardtoobject`,`tfms_operatingstep`,`tfms_opstepdetail`,`tfms_checklist`,`tfms_compromised`) + replication log pair. TOMS sub-app. | [FACT - d1.sql; ug.html:5094,6717] |
| `slc_`/`slcddb_` | 11+2 | **Substation Log Card** (`slc_card` w/ grounds, work-permit flags, station note) + **Information Items** (`slc_informationitem*`,`slc_itemcategory`) + equip templates/doc/wp-links + replication log pair. TOMS sub-app. | [FACT - d1.sql; ug.html:6660,11440] |
| `pvl_` | 10 | **External GIS feeder-data load/reconciliation** (xy + nf records) → builds Feeder Diagrams; `pvl_xreference` cross-refs pvl equip/manhole names → Udb Object IDs. **INTEGRATION** (see §4). | [FACT - d1.sql; ug.html:8746-8752] |
| `fra_` | 10 | **Field relay/cable acceptance test cards**: relay trip tests (`fra_relay` — 50/51/67/46 protection elements ×A/B/C/N phases), **hipot** cable insulation tests (`fra_hipot` — kV/duration/start-end mA), fault location (`fra_fault`), op-step timing, HV phases, + `*temp*` staging twins (field download). Feeder cutout/cutin RTS workflow. | [FACT - d1.sql DDL lines 5144-5544] |
| `dso_` | 3 | **NOT "Distribution System Operator".** = **Dielectric Switching Operations** QGIS geometry model: `dso_object` (per-diagram object+xy+symbol), `dso_connection` (line edges from/to), `dso_defaultrotation`. Parallel object store. **INTEGRATION** (see §4). | [FACT - ug.html:5097,8009-8021] |
| `rtu_` | 6 | **RTU/telecom circuit provisioning** for SCADA comms: circuit↔PVC mapping (`rtu_circuitmapping`), routers/TCP ports (`rtu_circuitrouter`), substation RTU counts (`rtu_substation`), provider, + RTU work-issue tracker (`rtu_workissue`/`rtu_workissuelog`). **INTEGRATION-adjacent** (see §4). | [FACT - d1.sql DDL] |
| `csd_` | 4 | **Console/desk messaging** (D.O. desk-to-desk): `csd_message` (text, desktype, priority), `csd_messagelink` (IP/node addressing + ack/clear), `csd_messagetype` (per desk IP enable), `csd_toecc` (route "to ECC"). | [FACT - d1.sql DDL 834-953] |
| `sds_` | 3 | **Steam/SMS "Sole authority" switching cards**: `sds_card` (msonumber, soleauthority, station, prepared/checked-by), `sds_cardmain` (mains), `sds_download` (DB-unload sync state). Standalone SDS DB. | [FACT - d1.sql 8042-8131; ug.html:5096] |
| `msg_` | 3 | **Inter-application substation message queue**: `msg_message` (substation/card, toapp/fromapp, ack/del, priority) + archive + lastkey. row_estimate≈5147. | [FACT - d1.sql 7170-7211] |
| `gta_` | 2 | **Alarm/note messaging** (`gta_message`: msgid, alarmtime, application, category, recurrence, desk, note) + archive (adds acktime/ackbyopname). | [FACT - d1.sql 5545-5610] |
| `oa_` | 5 | **Offline Archive card indexes** by `archiveyear` for FMS/SLC/TC/TFMS (`oa_*cardindex`) + `oa_archiveaccounting` (year/disk/location, sidea/sideb). `oa_fmscardindex` row_estimate≈213760 (large historical index). | [FACT - d1.sql 7262-7407] |
| `tm_` | 2 | **Task Manager bogey (SLA) alerts**: `tm_bogeytype` (per-type/status thresholds bogeyalert/nextalert/resend + notify routing flags enablecsd/fod/dcc/cig/pgm), `tm_bogeyalert` (live alerts per card). | [FACT - d1.sql 13250-13330; ug.html:10669-10723] |
| `tv_` | 1 | **Temperature-Variable bogey history**: `tv_bogeyhistory` (logdate, actual/forecast/dayahead temp, tv_threshold, peakload). Drives TV-vs-regular bogey selection (>82°→TV). | [FACT - d1.sql 13332; ug.html:10678-10682] |
| `itc_` | 2 | **ETC (Estimated Time of Completion/restoration) reporting**: `itc_eetccard` (per card/job/desk ETC), `itc_reportlogistics` (report frequency per app/division/user). | [FACT - d1.sql 7035-7100] |
| `soo_` | 1 | **SOA→SOO→remote comms-enable flags** per substation: `soo_communication`(substation, soa_to_soo, soo_to_remote). Electronic-order routing gate. | [FACT - d1.sql 11447; ug.html:12598-12606] |
| `nwp_` | 1 | **Network Planner job-class allowlist**: `nwp_jobclass`(jobclass). row_estimate≈13. | [FACT - d1.sql 7240] |
| `cfg_` | 1 | **Config/group→line lookup**: `cfg_group`(cfg_name, line, linename, lastupdate). | [FACT - d1.sql 805] |
| `allapp_` | 1 | **Global cross-app system parameters**: `allapp_systemparameters` (etccheckingperiod, userautologout, recoverytimeout, outagemonitordelay, outagelatentperiod, softwareversioncheck, peakloadthreshold). 1 row. | [FACT - d1.sql 21] |
| `xa21_` | 1 | **SCADA/EMS outage feed**: `xa21_outagereport`. **INTEGRATION** (see §4). | [FACT - d1.sql 15174] |
| `ddb_` | 6 | **Distributed-DB / dual-target replication control plane.** **INTEGRATION** (see §4). | [FACT - d1.sql DDL+dbevents] |
| `qgis_`/`egis_` | 3+2 | QGIS rendering symbols/locks/events; eGIS (Esri) structure cross-ref/load. **INTEGRATION** (see §4). | [FACT - d1.sql] |

---

## 2. INTEGRATION SURFACE INVENTORY

| External system | Bridging tables | Bridging procs / rules / dbevents | Direction | Confidence |
|---|---|---|---|---|
| **SCADA/EMS (XA/21 — GE/ABB EMS)** | `xa21_outagereport`; `soa_xa21exclusion` (type-exclusion list); `soa_xa21sequence` | `XA21_OutageReportIns` (pure INSERT); ug.html:5339 "FMS-XA21 interface"; equip-type exclusion UI | **EMS→PSM inbound** (outage device reports) + **PSM→EMS outbound** (breaker types pushed; see ug.html:5339-5385) | [FACT/INFERENCE] |
| **RTU / telecom infra** | `rtu_circuitmapping`,`rtu_circuitrouter`,`rtu_substation`,`rtu_circuitprovider`,`rtu_workissue(log)`; **writes `udb_TelephoneCircuit`** | `rtu_circuitupd` (UPDATEs `udb_TelephoneCircuit` ecc/acc FEP/channel/TCP-port/RAN); `RTU_WorkIssueIns/MsgUpd`; dbevents `tc_processingrtucircuit`,`tc_rtucircuitcomplete`,`tc_rtucircuitpermit` (TC module drives RTU circuit work) | **PSM-managed provisioning** of RTU comms; outbound to field telecom | [FACT - proc body 30637] |
| **Real-time telemetry/scan (analog/digital point ingest)** | `udb_telemetry` (min/max, xormask, deadband, in/out, address/size/offset, cable/panel/terminal), `udb_scanblock` (interval, startaddress, length, retries) | (config only in dump; runtime ingest is external EMS scanner) | **EMS→PSM inbound** point definitions/scan config | [INFERENCE — structure is classic SCADA point map; no ingest proc in dump] |
| **QGIS Diagram Editor (geo-schematic UI; TOMS+DSO)** | `dso_object`,`dso_connection`,`dso_defaultrotation`,`qgis_symbols`,`qgis_diagramlock`,`qgis_externalevent` | `QGIS_RTUpdNotification`→raises **dbevent `QGIS_RealTimeUpdate`** per locked computer; `QGIS_ExternalEventIns/Del`,`QGIS_DiagramLockUpd`,`QGIS_ActiveSwitchStatus`,`QGIS_ACLineSegVal`,`QGIS_SetOutage`,`DSO_CascadeType`; rules `QGIS_RealTimeUpdate`,`QGIS_ActiveSwitchUpd1-4`,`QGIS_ACLineSegVal1/2`,`DSO_SymbolSizeUpd` | **Bi-directional**: DB→UI push (event spool + dbevent) and UI→DB writes (object/connection edits) | [FACT - proc bodies 30556-30605, rules 33150-33164] |
| **eGIS (Esri ArcGIS)** | `egis_xreference` (egisStructure→object/feeder/xy), `egis_nfload` (network-feature load file) | `egis_xreferenceins` | **eGIS→PSM inbound** structure load + name cross-ref | [FACT - d1.sql; proc 28221] |
| **pvl GIS feeder data** | `pvl_xreference`,`pvl_xy_add/del`,`pvl_xyload`,`pvl_nf_add/del`,`pvl_nfload`,`pvl_networkstoload`,`pvl_processdate`,`pvl_xref_exception` | `pvl_nfupdate_ins`,`pvl_xyupdate_ins`,`pvl_*_process`,`pvl_ReplaceObject`,`pvl_transferobj`,`pvl_XRefIns/Del/Upd`,`pvl_update_clear` | **pvl files→PSM inbound** daily diagram update (3-step load) | [FACT - ug.html:8746; procs 30502-30552] |
| **Coordinate geometry stores** | `nodes_xy`(node→x,y,substation; ~19041 rows), `objects_xy`(object→x,y,rotation,substation,newobject) | (loaded; consumed by diagram render) | **inbound coord sync** to Udb node/object model | [FACT - d1.sql 7212; INFERENCE on consumer] |
| **Distributed-DB replication (dual hot targets A/B)** | `ddb_application`(prefix→appname), `ddb_reptargetstatus`(status+desc), `ddb_status`(timemarker), `ddb_reconnectdelay`,`ddb_recoverytimeout`,`ddb_replicatorstopped`; per-module spool pairs `fmsddb_log/logobject`,`tcddb_*`,`slcddb_*`,`tfmsddb_*` | `DDB_LogEntry`→**raises dbevent `ddb_logentry`**; `DDB_RepStatusDescUpd`; dbevents `ddb_abouttoreconnect/commit_failure/disconnect/reconnect`; rules `FMSDDB_LogEntry`/`TCDDB_LogEntry`/`SLCDDB_LogEntry`/`TFMSDDB_LogEntry` (AFTER INSERT→`DDB_LogEntry`), `DDB_RepStatusUpd` | **PSM↔replica peer**, bidirectional sync/heartbeat | [FACT - DDL 992-1076, dbevents 26538-26566, rules 32806+] |
| **Task-Monitor alert push (intra-app integration)** | `tm_bogeyalert`,`tm_bogeytype` (notify flags) | dbevent `tm_bogeyalertupd`; rules `TM$FODOrderStatusUpd`/`TM$OpOrderStatusUpd`/`TM$WPStatusUpd`→`TM$AlertUpdate` (fire off IR order/permit status change) | DB→Task Monitor service | [FACT - rules 33362-33366] |
| **IR field-order dispatch (Rapid Restore)** | (FMS/IR tables) | dbevent `ir_foddbevent` raised w/ RRMsgID controltext (proc near 29982) | DB→IR/RapidRestore | [FACT - line 29982; ug.html:12595] |

---

## 3. DEEP-READ: KEY INTEGRATION TABLE DDL

### 3.1 dso_object — QGIS geometry model (parallel object store)
[FACT - d1.sql] PK/index `btree unique`. Per-diagram (`pocket`) projection of `Udb_Object`:
```
object int, type int, typename, name, pocket int, pocketname,
structuretype/obj/name, activetype int, activetypename, symbolcolor,
pos_x float, pos_y float, rotation int, symbolsize float,
label_size/x/y, bus_llx/lly/urx/ury
```
**Is dso_object a second object model? YES — confirmed.** ug.html:8009-8021 [FACT]: "The QGIS Diagram Editor connected data model is **different from the Udb Object, Terminal, Node model**. It models 'Lines' using two tables DSO_Object and DSO_Connection." An object appears once **per pocket (diagram)** — PK is effectively (object,pocket) per proc WHERE clauses. `DSO_CascadeType` reads `Name` from `Udb_Object` and resolves `ActiveType`/symbol by walking `Udb_SuperType` up the type tree against `QGIS_Symbols` → writes denormalized display attrs into `dso_object`. So dso_object is a **derived/denormalized render cache of Udb_Object**, NOT an independent authority. The "DSO" prefix = **Dielectric Switching Operations** app, which (with TOMS) uses this QGIS model; it is NOT "Distribution System Operator". [FACT - ug.html:5097, 6929-6930, 8009]

### 3.2 dso_connection — graph edges
```
oid int, fromobj int, toobj int, outflowside int, pipetype int,
pipetypename, linecolor, connectionlength float
```
[FACT - ug.html:8015-8021] from/to have **no directional significance**. `DSO_ConnectionIns` auto-assigns `oid` from `Udb_LastKey 'ConnectionOID'`, dedups on (from,to)/(to,from), infers pipetype from neighbors (annotation type 17056→17090 else 17083). `QGIS_ACLineSegVal` flags AC-line-segments (Type=22) with <2 connections by coloring them `255,20,147,255` (deep-pink dangling-end indicator). [FACT - proc 30556]

### 3.3 xa21_outagereport — EMS outage feed
```
outagerecorded ingresdate, outagetype varchar(24), outageobject int,
substation int, equip int, devicetime ingresdate
```
[FACT] `XA21_OutageReportIns` = bare INSERT (no transform). `soa_xa21exclusion(type int)` = equipment types excluded from XA21 interface (ug.html:3100,5337). ug.html:5339-5385 [FACT]: "FMS-XA21 interface provides XA21 system the capability to [process feeder] changes. The types of breakers that XA21 sends should be Source, Source-SBFKS,…"; new excluded types trigger an **email to XA21 support staff** to configure manually → so the bridge is partly manual/email, not fully automatic.

### 3.4 udb_telemetry / udb_scanblock — SCADA point map
```
udb_telemetry: object, telemetryminimum/maximum, xormask, deadband,
  input, output, address, size, offset, powercable/returncable/groundcable/
  terminationcable, panel, terminalblock
udb_scanblock: object, interval, startaddress, length, retries
```
[INFERENCE] Classic RTU/EMS point definition + scan-block polling config. No ingest procedure present in dump → runtime telemetry ingest is an **external EMS/scanner process**; these tables are configuration only. The cable/panel/terminalblock columns = physical wiring documentation.

### 3.5 ddb_* replication control + *ddb_log spool
```
ddb_application(prefix char5, applicationname)   -- prefix→app registry
ddb_reptargetstatus(status int, description)      -- 0=Normal,10=DDB recovery incomplete,20=Ingres repl incomplete
ddb_status(rowkey, timemarker)                    -- heartbeat marker
ddb_reconnectdelay / ddb_recoverytimeout / ddb_replicatorstopped
fmsddb_log(transaction_time, transaction_dbhandle varchar76, string_id)
fmsddb_logobject(string_id, row_sequence, text_total, text_value varchar1786)  -- chunked payload
```
[FACT - proc 28063] `DDB_RepStatusDescUpd(Status)`: maps 0/10/20 → human descriptions ("the **other target** database is …"), else RAISE ERROR. → **dual-target (A/B) replication topology** confirmed. [FACT - proc] `DDB_LogEntry = RAISE DBEVENT ddb_logentry` (fired by `*DDB_LogEntry` rules AFTER INSERT into each module's `*ddb_log`). **Mechanism**: app writes a row into `<module>ddb_log` + chunked text into `<module>ddb_logobject`; INSERT rule raises `ddb_logentry`; an external **replicator daemon** registered on `ddb_logentry`/`ddb_reconnect`/`ddb_commit_failure`/`ddb_disconnect`/`ddb_abouttoreconnect` ships the spooled SQL text to the peer DB. This is a **home-grown statement-shipping replication layer** layered on top of (and complementary to — note status 20 "Ingres Replication is Incomplete") native **Ingres Replicator**. [INFERENCE on daemon — daemon binary not in artifacts]

---

## 4. SYNC-DIRECTION MERMAID

```mermaid
flowchart LR
  subgraph EXT[External systems]
    XA21[XA/21 EMS-SCADA]
    EMS_SCAN[EMS point scanner]
    QGIS[QGIS Diagram Editor UI]
    EGIS[eGIS / Esri ArcGIS]
    PVLF[pvl feeder GIS files]
    PEER[(Replica DB target A/B)]
    FIELD[RTU / field telecom]
    IRRR[IR Rapid Restore]
  end
  subgraph PSM[PSM Ingres DB]
    XAtab[xa21_outagereport / soa_xa21exclusion]
    TEL[udb_telemetry / udb_scanblock]
    DSO[dso_object / dso_connection]
    QSYM[qgis_symbols / qgis_externalevent / qgis_diagramlock]
    EGX[egis_xreference / egis_nfload]
    PVL[pvl_xreference / pvl_xy* / pvl_nf*]
    DDB[*ddb_log / *ddb_logobject / ddb_*]
    RTU[rtu_* / udb_TelephoneCircuit]
    UDBO[Udb_Object terminal-node model]
  end
  XA21 -- outage device reports --> XAtab
  XAtab -. breaker types + email .-> XA21
  EMS_SCAN -- point/scan config defs --> TEL
  QGIS <-- edits + UPDATEOBJECT events + dbevent QGIS_RealTimeUpdate --> DSO
  QGIS <--> QSYM
  EGIS -- structure load --> EGX
  PVLF -- daily 3-step load --> PVL
  PVL -- xref names --> UDBO
  DSO -. derived render cache .- UDBO
  DDB <-- statement-ship + heartbeat --> PEER
  RTU -- provisioning --> FIELD
  PSM -- ir_foddbevent --> IRRR
```

---

## 5. CONTRADICTIONS / CORRECTIONS TO TASK BRIEF
1. **`dso_object` is NOT "Distribution System Operator view".** [FACT - ug.html:5097] DSO = **Dielectric Switching Operations**, a standalone switching application (steam/dielectric-cable ops) with its own `DSO_DBM` image. `dso_object`/`dso_connection` are the **QGIS connected-geometry model** shared by TOMS and DSO, a derived projection of `Udb_Object` keyed per diagram (pocket).
2. **The "ddb" families are a custom statement-shipping replication/spool layer**, confirmed — and they coexist with native Ingres Replicator (status code 20 = "Ingres Replication is Incomplete"), i.e. **two replication mechanisms**, not one. [FACT - proc 28063]
3. **XA21 bridge is partly manual** (email to support staff for new equip types) — not a clean automatic EMS sync. [FACT - ug.html:5384]
4. **Procedure bodies are doubly-defined** (stub + real); naive single-grep yields false "empty logic". [FACT]

## 6. GAPS / UNKNOWNS
- All `type`/`status`/`pipetype`/`activetype` integer codes (e.g. 22=ACLineSeg, 10016/12201/20542 switch-status, 17055/17056/17083/17090 pipe/annotation, 22585 obsolete-person, 17 type-floor) are **referenced in proc logic** but their full enumerations live in absent seed tables → enumerations [UNKNOWN]; only the specific literals hard-coded in procs are known.
- No runtime **telemetry-ingest** or **ddb-replicator daemon** code in artifacts (external binaries) → ingest/ship logic [UNKNOWN beyond the DB-side trigger surface].
- `nwp_` (Network Planner) has only `nwp_jobclass`; full NWP module logic not represented here → purpose [INFERENCE from name + ug context only].
- Exact PK column lists per table not all enumerated above (read `modify <t> to ...` for each if needed); confirmed unique btree/hash on the integration tables in §1/§3.
- Row counts: NONE authoritative (no data); `row_estimate` cited only as relative scale.
