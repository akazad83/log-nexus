# Metamodel-Subtypes (UDB) — Raw Analysis

Primary source: `d:/103_RnD/psm_v1/d1.sql`. Secondary: `d:/103_RnD/psm_v1/ug.html`.
All proc/rule line numbers refer to d1.sql unless noted. UDB family = 53 tables [FACT - d1.sql->grep `^create table udb_` = 53].

> **VERIFIED COPY** — adversarial verification applied 2026-06-12. Inline corrections are marked `[VERIFIER-FIX]`. See `## Verification` footer for the full confirmation/correction log. All cited objects exist; zero fabricated.

---

## 0. HEADLINE CORRECTION (the prompt's "one big table" hypothesis is WRONG)

[FACT - d1.sql->udb_object + every subtype table] The model is **CLASS-TABLE INHERITANCE**, not single-table inheritance (STI). Every equipment object is split across:
- one row in `udb_object` (PK=`object`, 30 cols, common attributes) AND
- one row in exactly one **subtype table** (PK=`object`, type-specific attributes), where the subtype table is named by `udb_basetype.tablename`.

[FACT - d1.sql:30457 `object$insert`] Proof: the central insert engine resolves `BaseType`/`TableName` from `udb_type`→`udb_basetype`, then in a big `IF/ELSEIF (TableName = 'Conductor'/'Generator'/...)` chain does `INSERT INTO Udb_<Subtype> (Object) VALUES (:Object)`. One object → one udb_object row + one subtype row keyed on the same `object`. [VERIFIER-CONFIRMED - full body read at 30457; every claimed branch present verbatim.]

[FACT - all `modify udb_<subtype> to btree/hash unique on object`] Every subtype table is uniquely keyed on `object` (1:1 with udb_object). Verified for capacitor, reactor, generator, switch, transformer, conductor, telemetry, measurementtype, etc. Exceptions noted in §2.

---

## 1. PROC-BODY CONSTRAINT (critical for downstream synthesis)

[FACT - d1.sql grep] The 2,450 procedures split ~50/50 into TWO syntactic classes:
| Class | Prefix syntax | Count | Body |
|---|---|---|---|
| Client-callable stubs | `create or replace procedure NAME` (1 space) | 1,225 | ALL empty: `as begin return; end` — zero logic |
| `"ingres"`-owned rule-target procs | `create or replace procedure  NAME` (2 spaces) | 1,225 | Full `= DECLARE...BEGIN...END` bodies — REAL server logic |

[VERIFIER-CONFIRMED] Counts exact: 2-space = 1225; 1-space-only = 1225; and `grep '^create or replace procedure [a-zA-Z].*as begin return; end'` = 1225 → **every** 1-space proc is an empty stub. Total = 2450.

[INFERENCE] The one-space stubs are the OpenROAD client-facing DB-proc interface (definitions shipped, bodies stripped/empty in this dump). The two-space procs are the actual DBMS-side procedures fired by Ingres RULES. **All real metamodel/connectivity logic lives in the two-space set + the rule definitions** (lines ~32785–33230). The 69 `udb_*` one-space procs (e.g. `udb_objectins`, `udb_nextkey`, `udb_createnewnode`) are ALL empty stubs — do not mine them for logic. [VERIFIER-CONFIRMED - 69 one-space `udb_*` procs.]

[FACT - d1.sql:33131 `Object$Delete`] Direct SQL DELETE on udb_object is blocked by a rule that calls `Reject(Problem='Object_006')`. [VERIFIER-FIX/CLARIFY: `Object$Delete` is a **RULE** (`create rule Object$Delete AFTER DELETE ON Udb_Object EXECUTE PROCEDURE Reject(Problem='Object_006')`), NOT a procedure. The analyst's prose already says "a rule that calls Reject" — correct — but the object-class is a rule, so it does not appear in the procedure inventory. Confirmed at 33131.] [FACT - ug.html] confirms: "The database has a database rule that prevents a simple SQL 'Delete' statement from deleting rows in the Udb_Object table"; deletion is done by an offline annual SQL script that bypasses the rule, OR by re-typing to a "Historical Object" (type 998) / "Obsolete" type. [VERIFIER-CONFIRMED - ug.html text "prevents a simple SQL 'Delete' statement from deleting rows" and "Type 998 – Historical Object (for permanent...)" both present.]

---

## 2. SUBTYPE TABLE CATALOG (per-equipment extension attributes)

[FACT - d1.sql DDL lines 13363–15170]. "Key" = unique storage index. All FK back to `udb_object.object` via the `object` column. Signature cols = 3–6 most distinctive.

| Subtype table | DDL line | Storage key | object→udb_object | Signature columns |
|---|---|---|---|---|
| `udb_transformer` | 15069 | btree unique (object) | yes | `bank`, `phases char(1)`, `magbasekv`, `gmag`, `bmag`, `magsatflux` |
| `udb_winding` | 15132 | btree unique (object,winding) | yes (1:N — multiple windings/xfmr) | `winding`, `nominalkv`, `ratedmva`, `lowstep`/`highstep`/`neutralstep`, `loadtapchanger`, `phaseshift` |
| `udb_tapsetting` | 14767 | btree unique (object,winding1,tapstep1,winding2,tapstep2) | yes (1:N) | per-winding-pair impedance matrix `r0_1_2`,`z0_1_2`...`x1_3` (38 R/X/Z cols) |
| `udb_switch` | 14707 | hash unique (object) | yes | `normalopen`, `currentlyopen`, `relaytype`, `networktype`, `stoptag` |
| `udb_capacitor` | 13460 | btree unique (object) | yes | `nominalmvar`, `voltsensitivity`, `avrdelay ingresdate` |
| `udb_reactor` | 14581 | btree unique (object) | yes | identical schema to capacitor: `nominalmvar`, `voltsensitivity`, `avrdelay` |
| `udb_conductor` | 13607 | btree unique (object) | yes | `r`,`x`,`bch`,`length`, `towertype`, `phaseconductortype`, `phaseconductorcount`, `phaseconductorspacing` |
| `udb_conductortype` | 13642 | btree unique (object) | yes | `resistance`, `radius`, `gmr`, `ampacity` |
| `udb_towertype` | 15027 | btree unique (object) | yes | phase/ground geometry: `a1_offset`/`a1_height`...`g2_height` (16 offset/height cols, 2 circuits) |
| `udb_generator` | 13922 | btree unique (object) | yes | `primemover`, `ratedmva`, `min/base/maxmw`, `min/base/maxmvar`, `x`,`r`,`inertia`,`damping`, ramp rates |
| `udb_combustionturbine` | 13516 | btree unique (object) | yes | `powervariationbytemp`, `referencetemp`, `ambienttemp`, `timeconstant` |
| `udb_hydroturbine` | 14105 | btree unique (object) | yes | `gatelowerlimit`/`gateupperlimit`/`gateratelimit`, `speedregulation`, `waterstartingtime` |
| `udb_steamturbine` | 14640 | btree unique (object) | yes | `steamsupply` (FK to a steamsupply object), shaft1/2 HP/IP/LP power, reheater/crossover TCs |
| `udb_pwrsteamsupply` | 14501 | btree unique (object) | yes | PWR reactor steam-supply gains/lags: `pressurecg`, `hotlegtocoldleggain`, `coreneutronicsht`... (20 cols) |
| `udb_fossilsteamsupply` | 13867 | btree unique (object) | yes | boiler/coordinated-control PID gains: `throttlepressuresp`, `coordinatedctrlpeb`, `boilerfollowctrl*` (29 cols) |
| `udb_bwrsteamsupply` | 13421 | btree unique (object) | yes | BWR: `rodpattern`, `pressuresetpointga`, `integralgain`, `proportionalgain`, `incorethermaltc` |
| `udb_consumer` | 13672 | btree unique (object) | yes | `type`, `toploadarea`, `pfixed`/`qfixed`/`pnom`/`qnom`, `powerfactor`, ZIP exponents `pvexp`/`qvexp`/`pfexp`, `customercount` |
| `udb_computer` | 13579 | btree unique (object) | yes | `objectaddress`, `loadfile varchar(200)` |
| `udb_communicationlink` | 13546 | btree unique (object) | yes | `controller`, `controlleraddress`, `unit`, `unitaddress`, `protocol`, `speed`, `cable` |
| `udb_telephonecircuit` | 14875 | hash unique (object) | yes | `functionarea`, `priorityline`, `rtunumber`/`rtuaddress`, ECC/ACC FEP+channel+tcpport, `rtu2*` (29 cols) |
| `udb_measurementtype` | 14320 | btree unique (object) | yes | `sensorminimum`/`sensormaximum`/`sensorunits`/`sensoraccuracy`, `measurandterminal1/2`, `alarm`,`history`,`trigger`,`input`,`output` |
| `udb_telemetry` | 14834 | btree unique (object) | yes | `telemetryminimum/maximum`, `xormask`, `deadband`, `address`/`size`/`offset`, cable/panel/terminalblock |
| `udb_scanblock` | 14610 | btree unique (object) | yes | `interval`, `startaddress`, `length`, `retries` |
| `udb_person` | 14443 | btree unique (object) | yes | `loginname`, `password`, `initials`, `email` |
| `udb_location` | 14285 | btree unique (object) | yes | `combination`, `phone`,`fax`,`contact`, address lines `l1`–`l4`, `comment` |
| `udb_dsovalve` | 13714 | **HEAP (no unique idx)** | yes (PK declared `object not null`) | `normalopen`, `currentlyopen`, `valvemode`, `cracked`, `acfeedremoved`, `valvetype` (DSO = gas/distribution valve, OUTSIDE electric model) |
| `udb_grasscatcher` | 13973 | **btree on object (NON-unique)** | yes (1:N — many problems/object) | `problem char(20)`, `text`, `known` — validation-error SINK, see §5 |

[VERIFIER-CONFIRMED] Storage spot-checks: `modify udb_dsovalve to heap`, `modify udb_grasscatcher to btree on` (no `unique`), `modify udb_capacitor to btree unique`, `modify udb_reactor to btree unique`. capacitor & reactor DDL bodies are byte-for-byte the same column set (`object`, `nominalmvar f4`, `voltsensitivity f4`, `avrdelay ingresdate`).

[UNKNOWN] No subtype table exists for many other equipment kinds (e.g. busbar/breaker have no dedicated table); those use only udb_object + the generic subtype tables above, or are typed via `udb_type` without a dedicated subtype table (TableName='' branch in object$insert is a no-op). The seed `udb_type`/`udb_basetype` rows that enumerate which types map to which TableName are in the absent `.ingres` data files → the full type→tablename map is [UNKNOWN] beyond the literal TableName strings hardcoded in `object$insert` (§3).

---

## 3. TYPE METAMODEL & the object$insert ENGINE (authoritative)

[FACT - d1.sql:13839,14679,14502... DDL]
| Table | Cols | Key | Role |
|---|---|---|---|
| `udb_type` | type, basetype, name, description | btree unique (type,name) | concrete type registry |
| `udb_basetype` | type, editorname char(20), tablename char(20) | btree unique (type) | basetype→OpenROAD editor frame + subtype table name |
| `udb_supertype` | type, supertype | btree unique (type,supertype) | direct super relation |
| `udb_extendedtype` | type, supertype | btree unique (type,supertype) | TRANSITIVE closure of supertype (used by Grouping$Validate) |
| `udb_image` | type, leftdbhandle varchar(76), rightdbhandle | btree unique (type) | per-type symbol/bitmap handles |

[FACT - d1.sql:30457 `object$insert`, verbatim logic flow] [VERIFIER-CONFIRMED - full body read; flow below is accurate]:
1. `SELECT :BaseType=BT.Type, :TableName=BT.TableName FROM Udb_Type T, Udb_BaseType BT WHERE :Type=T.Type AND T.BaseType=BT.Type` — resolve basetype+subtype-table from type.
2. If `BaseType=0` → log GrassCatcher `Object_012`. [VERIFIER-NOTE: it INSERTs the grasscatcher row but does **not** abort/return — execution falls through and continues. "log" is the right word; there is no early exit.]
3. If `Object=-1` → **allocate key**: `UPDATE Udb_LastKey SET Value=Value+1 WHERE LastKey='Object'`; re-select new value. (key-gen, see §4)
4. `UPDATE Udb_Object ... SET Object=:Object, BaseType=:BaseType, TypeName=T.Name, PrimaryGroupingName=PG.Name, Created='Now', CreatedBy=VARCHAR(User) WHERE ... :Tid=O.Tid` — finalize the just-inserted udb_object row (the rule fires AFTER INSERT; the proc patches it by Tid).
5. If `PrimaryGrouping!=0` → `INSERT INTO Udb_Grouping (...Relationship) SELECT :SystemVersion,:PrimaryGrouping,PG.Type,:Object,:Type,52` — auto-create the **primary-grouping membership (Relationship=52)**. [VERIFIER-CONFIRMED literal 52.]
6. `WHILE Loop<=Terminals DO INSERT INTO Udb_Terminal (Object,BaseType,Terminal) VALUES (:Object,:BaseType,:Loop)` — **spawn N terminal rows** (Loop 1..Terminals). [VERIFIER-CONFIRMED.]
7. `IF/ELSEIF (TableName=...)` → INSERT the subtype row. **Hardcoded TableName branches (the ONLY confirmed type→subtype map):** Conductor, Generator, Consumer, Capacitor, Reactor, Switch, Transformer, Telemetry, TowerType, ConductorType, Computer, MeasurementType, Person, CombustionTurbine, HydroTurbine, SteamTurbine, FossilSteamSupply, BWRSteamSupply, PWRSteamSupply, CommunicationLink, TelephoneCircuit (also inserts `Udb_CircuitRoute (Object,0)`), EquipTemplate (→`SLC_EquipTemplate`). `TableName=''` → no subtype row. [VERIFIER-CONFIRMED - every branch and the two side-inserts (CircuitRoute(Object,0); SLC_EquipTemplate) present verbatim; `IF (TableName='') THEN TableName=TableName` is the literal no-op.]

[FACT - rule wiring] `Object$Insert1` (33133) fires `Object$Insert` AFTER INSERT ON Udb_Object passing `Tid=New.Tid`. The `Tid` is Ingres' hidden tuple-id system column (NOT a declared DDL column) — every rule passes `New.Tid`/`Old.Tid` so the proc can locate the row it must patch. [INFERENCE] This is the standard Ingres "insert blank row, let AFTER-INSERT rule fill it in" idiom.

[FACT - 33148 Object$Update_Type→Object$TypeName, 32789 CascadeType$Change] On type change, `udb_object.typename` is refreshed from `udb_type.name`, and `CascadeType$Change` (27983) propagates the new type into `udb_grouping.membertype`/`groupingtype` everywhere the object participates. [VERIFIER-CONFIRMED - `CascadeType$Change` body at 27983: `UPDATE Udb_Grouping SET MemberType=:Type WHERE Member=:Object; UPDATE Udb_Grouping SET GroupingType=:Type WHERE Grouping=:Object`. Exact. `Object$TypeName` body confirmed refreshes TypeName from Udb_Type.]

---

## 4. KEY GENERATION — udb_lastkey (sequence emulation)

[FACT - d1.sql:14194 DDL] `udb_lastkey(lastkey char(40) PK, value integer)`; hash unique on lastkey.
[FACT - object$insert / Node$Insert / kVLevel$Insert / LoadCurve$Insert] Pattern is identical everywhere: `UPDATE Udb_LastKey SET Value=Value+1 WHERE LastKey='<name>'; SELECT :x=Value FROM Udb_LastKey WHERE LastKey='<name>'`. Confirmed counter names: `'Object'`, `'Node'`, `'kVLevel'`, `'Curves'` (for LoadCurve). [VERIFIER-CONFIRMED - `'Object'` in object$insert, `'Node'` in Node$Insert (30431); counter literals verified for the two procs read. `'kVLevel'`/`'Curves'` not independently re-read by verifier but the pattern is consistent and the analyst tagged them FACT from those proc bodies.] [INFERENCE] One row per allocatable entity class; this is the system-wide surrogate-key generator. Caller passes -1 to request a new key. [UNKNOWN] Full list of LastKey rows lives in absent seed data; only the 4 literal names above are confirmed.

---

## 5. GRASSCATCHER = validation-error sink (NOT equipment)

[FACT - d1.sql:13973 DDL + 29830 GrassCatcher$Insert body] `udb_grasscatcher(object, problem char(20), text, known)`, btree NON-unique on object. `problem` FKs to `udb_problem(problem PK, severity char(1), description char(60))`.
[FACT - 29830] On insert, GrassCatcher$Insert dedupes (deletes if >1 identical), looks up `Description`/`Severity` from `Udb_Problem`; **IF Severity='F' THEN RAISE ERROR -1 (hard fail/reject); ELSE MESSAGE (warning)**. [VERIFIER-CONFIRMED - body at 29830: `SELECT :Refs=COUNT(*) ... ; IF Refs>1 THEN DELETE ... WHERE :Tid=Tid; ...; IF Severity='F' THEN RAISE ERROR -1 Description; ELSE MESSAGE 0 Description`. Exact.]
[FACT - multiple validators write here] Validation failures across the metamodel funnel into grasscatcher: `Conductor$Validate` (27992, inserts `Conductor_001` when X/R<5), `Object$Validate` (30492, `Object_001` when InService>OutService), `Grouping$Validate` (29850, `Object_013` invalid relationship), `object$insert` (`Object_012` bad basetype), `Grouping$Insert` (`Object_004`/`Object_005` unresolved group/member type), `kVLevel$Delete` (referential-integrity guard). [VERIFIER-CONFIRMED bodies: Conductor$Validate `IF (X/R)<5 THEN ...'Conductor_001'`; Object$Validate `IF InService>OutService THEN ...'Object_001'`; Grouping$Insert writes `Object_004`/`Object_005`; object$insert writes `Object_012`; Grouping$Validate writes `Object_013`. All exact.] [INFERENCE] grasscatcher = the system's deferred data-quality exception log; `severity='F'` problems block the txn, others just warn. The `udb_problem` rows (the actual problem-code→severity/description map) are seed data → [UNKNOWN] full enumeration; only the literal problem codes quoted above are confirmed present in proc bodies.

---

## 6. CONNECTIVITY / GRAPH MODEL (authoritative reconstruction)

[FACT - ug.html] "The Udb connectivity model involves the following tables: Udb_Object, Udb_Terminal, and Udb_Node. The Udb_Object table has a Terminals attribute that indicates the number of valid connections... The Terminals attribute drives how many rows are inserted into Udb_Terminal... If the terminals value is two, then two rows are inserted for the object in the Udb_Terminal table indicating that two devices should be connected to this object." [VERIFIER-CONFIRMED - "connectivity model involves the following tables" and "terminals value is two, then two rows are inserted for the object in the Udb_Terminal table" both present in ug.html (text spans HTML tags). VERIFIER-NOTE: cited ug.html line numbers throughout this doc are unreliable because ug.html is heavily tag-wrapped HTML, not line-oriented; the quoted TEXT is what was verified, not the line numbers.]

[FACT - ug.html] Two coexisting connectivity models: **TOMS/DSO use the QGIS diagram model; SMS (Steam), FMS 3G, and Staten Island 33kV use the Udb terminal/node model.** So udb terminal/node connectivity is NOT universal — it's the legacy/electric-network model. [VERIFIER-CONFIRMED - ug.html contains "Udb connectivity model using terminal and nodes" and "Staten Island"; the two-model split is supported by the text.]

### Graph tables
| Table | DDL | Key | Role |
|---|---|---|---|
| `udb_node` | 14359 | hash unique (node) | electrical node (bus/connection point); `kvlevel`, `primarygrouping`, `seq` |
| `udb_terminal` | 14997 | **hash NON-unique on object** | object's connection point: `(object,basetype,terminal,node)`, `inservice`/`outservice` |
| `udb_grouping` | 14003 | btree unique (grouping,relationship,member) | the universal M:N association graph (feeders, circuits, hierarchies, locations) |
| `udb_circuitroute` | 13489 | hash unique (object,route) | maps an object to circuit route id(s); auto-seeded `(object,0)` for telephonecircuits |

[VERIFIER-CONFIRMED] `udb_grouping` columns `(systemversion, grouping, groupingtype, member, membertype, relationship, reference)` and `modify udb_grouping to btree unique on (grouping, relationship, member)`. `udb_circuitroute` `modify ... to hash unique on (object, route)`. Both exact.

### Graph traversal path
[INFERENCE from DDL + object$insert + ug.html] An OBJECT connects to the network thus:
```
udb_object(object, terminals=N)
   └─ N rows in udb_terminal(object, terminal=1..N, node)   [created by object$insert WHILE loop]
        └─ each terminal references udb_node(node)
              └─ a node is shared by the terminals of all objects electrically tied at that point
```
Two objects are electrically connected ⟺ a terminal of object A and a terminal of object B reference the **same** `udb_node.node`. Node is the shared junction; terminal is the per-object stub. [FACT - 30426 Node$Delete] refuses to delete a node still referenced by any udb_terminal row (`SELECT COUNT(*) FROM Udb_Terminal WHERE Node=:Node; IF >0 raise error`). [VERIFIER-CONFIRMED - body at 30426: `SELECT :i=COUNT(*) FROM UDB_Terminal WHERE Node=:Node; IF i>0 THEN ...raise error -1`. Exact.] [FACT - 30431 Node$Insert] allocates node key from LastKey 'Node', defaults Name=varchar(Node). [VERIFIER-CONFIRMED - body at 30431 allocates from `LastKey='Node'`.]

[FACT - ug.html] **Equipment Terminal Mismatch** validation: `FMS_TypeTerminals` table holds expected terminal-count per type; objects whose `udb_object.terminals` ≠ expected count → flagged (red numerals), cause "connectivity trace problems in TOMS". `FMS_3GFeederTerminalUpd` (28245) reconciles actual vs expected udb_terminal rows. [VERIFIER-CONFIRMED - `FMS_TypeTerminals(type integer, terminals integer)` exists; FMS_TypeTerminalsIns/Del maintain it; ug.html contains "Terminal Mismatch" validation text.]

### GROUPINGS = feeders / circuits / hierarchies
[FACT - 14003 DDL] `udb_grouping(systemversion, grouping, groupingtype, member, membertype, relationship, reference)`. It is a self-referential M:N edge list over objects: a "grouping" object contains "member" objects under a typed "relationship". [VERIFIER-CONFIRMED - DDL exact.]
[FACT - Relationship codes seen in rules/procs — CONFIRMED literals]:
- **52** = primary "is-member-of" / contains (object$insert auto-creates it; FMS_FdrDiv$Ins/Del, FMS_CloseOpenCards, FMS_NotifyXferEquip, dso_grouping all key off Relationship=52). This is the feeder/division membership edge. [VERIFIER-CONFIRMED - 52 in object$insert, Object$PrimaryGrouping, FMS_FdrDiv rules, SOA rules.]
- **57** = "located-with" (Grouping$Location 29842; ties an object's grouping to a `udb_location`). [VERIFIER-CONFIRMED - Grouping$Location body uses `RelationShip=57` against UDB_Location/UDB_Grouping.]
- **10137 / 10138** = FMS association edges (FMS_AssociationIns/Del/Upd, 32852-32857) — bidirectional (rule re-inserts the inverse). [VERIFIER-CONFIRMED - FMS_AssociationIns/Del/Upd rules at 32852-32857 fire on `Relationship=10137 OR 10138` and swap Grouping↔Member; FMS_CascadeAssocDel deletes both directions.]
[UNKNOWN] groupingtype/membertype/relationship are all integer type-codes resolved against `udb_type`; their full enumeration is seed data → only the literals above (and 40,10152,10154 for feeder member types in FMS_FdrDiv rules; groupingtype 4,10131 for division) are confirmed. [VERIFIER-CONFIRMED - FMS_FdrDiv$Ins/Del rules (32923/32925): `MemberType IN (40,10152,10154) AND Relationship=52 AND (GroupingType=4 OR GroupingType=10131)`; SOA_ObjectDivision rules also key on `GroupingType IN (4,10131) AND Relationship=52`. All literals exact.]

[FACT - 29850 Grouping$Validate] A (groupingtype,membertype,relationship) triple is legal ⟺ a matching `udb_groupingvalidation` row exists **after expanding each code up its supertype chain via udb_extendedtype**: `WHERE GV.GroupingType IN (SELECT SuperType FROM Udb_ExtendedType WHERE :GroupingType=Type) AND GV.MemberType IN (...) AND GV.Relationship IN (...)`. Invalid → grasscatcher `Object_013`. [VERIFIER-CONFIRMED - Grouping$Validate body: the three `IN (SELECT ET.SuperType FROM Udb_ExtendedType ET WHERE :X=ET.Type)` subqueries and the `Object_013` insert (with RelationshipName as Text) are present verbatim.] [INFERENCE] `udb_groupingvalidation(groupingtype,membertype,relationship)` is the rule table defining which container-types may hold which member-types under which relationship; supertype generalization lets one validation row cover a whole class subtree.

[FACT - 14037 DDL `udb_groupinghistory`] denormalized append-only audit of grouping membership: adds `groupingname`, `groupingtypename`, `transfertime ingresdate` to the grouping tuple. btree unique (grouping,relationship,member,transfertime). [INFERENCE] Records feeder-transfer / membership-change history (transfertime = when the edge was active). `udb_buildgrouphistory` proc is a stub (26219) so build logic is [UNKNOWN] in this dump.

```mermaid
erDiagram
  UDB_OBJECT ||--|| UDB_SWITCH : "object (1:1 subtype)"
  UDB_OBJECT ||--|| UDB_TRANSFORMER : "object (1:1)"
  UDB_OBJECT ||--o{ UDB_WINDING : "object (1:N)"
  UDB_OBJECT ||--|| UDB_CONDUCTOR : "object (1:1)"
  UDB_OBJECT ||--o{ UDB_TERMINAL : "object (1:N = terminals)"
  UDB_TERMINAL }o--|| UDB_NODE : "node (shared junction)"
  UDB_OBJECT ||--o{ UDB_GROUPING : "as grouping or member"
  UDB_GROUPING }o--|| UDB_TYPE : "groupingtype/membertype"
  UDB_GROUPING }o--o{ UDB_GROUPINGVALIDATION : "validated via udb_extendedtype"
  UDB_OBJECT }o--|| UDB_TYPE : "type"
  UDB_TYPE }o--|| UDB_BASETYPE : "basetype -> tablename,editorname"
  UDB_OBJECT ||--o{ UDB_GRASSCATCHER : "validation errors"
  UDB_GRASSCATCHER }o--|| UDB_PROBLEM : "problem -> severity"
  UDB_NODE }o--|| UDB_KVLEVEL : "kvlevel"
```

---

## 7. REFERENCE / CONTROL TABLES

| Table | DDL | Key | Role / signature |
|---|---|---|---|
| `udb_kvlevel` | 14166 | btree unique (kvlevel) | voltage-level lookup: `name`, `voltage f4`. kVLevel$Insert allocates from LastKey 'kVLevel'; kVLevel$Delete blocks if referenced by any udb_node |
| `udb_rating` | 14547 | btree unique (object,type) | equipment thermal ratings per (object,type,season,temperature): `normal`,`shortterm`,`emergency`,`loadshed` |
| `udb_measurementtype` | 14320 | btree unique (object) | (also a subtype, §2) sensor/measurand config |
| `udb_tapsetting` | 14767 | btree unique (object,winding pairs) | transformer tap-position impedance matrix |
| `udb_loadcurve` | 14220 | btree unique (object,daytype,season,temperature) | load-shape header: `loadcurve` id, `interpolate`, `source`. LoadCurve$Insert allocates from LastKey 'Curves' |
| `udb_loadvalue` | 14255 | btree unique (loadcurve,time) | time-series points: `(loadcurve,time,loadvalue)` |
| `udb_telemetry` | 14834 | btree unique (object) | (subtype) SCADA point scaling + wiring |
| `udb_scanblock` | 14610 | btree unique (object) | (subtype) RTU scan block timing |
| `udb_location` | 14285 | btree unique (object) | (subtype) site address/contact |
| `udb_person` | 14443 | btree unique (object) | (subtype) user login/credentials |
| `udb_problem` | 14473 | btree unique (problem) | validation problem-code dictionary: `severity char(1)` ('F'=fatal), `description` |
| `udb_systemparameters` | 14737 | **isam unique (rowkey)** | singleton power-system base: `frequency`,`mvabase`,`kvreference`,`lengthratio`,`groundresistivity`,`temperature` |
| `udb_lastkey` | 14194 | hash unique (lastkey) | surrogate-key sequence emulation (§4) |
| `udb_image` | 14138 | btree unique (type) | per-type symbol DB handles |
| `udb_bitmap` | 13391 | btree unique (picture_id,row_sequence) | chunked bitmap text storage: `text_total`, `text_value varchar(1786)` |
| `udb_exportfield` | 13744 | **HEAP** | export staging: `(exportrecord,exportfielddefn,idata,fdata,cdata)` |
| `udb_exportfielddefn` | 13770 | **HEAP** | export field layout: `cardtype`,`name`,`offset`,`format`,`udb_column`,`udb_table`,`udb_method` |
| `udb_exportrecord` | 13801 | **HEAP** | export record buffer: p0..p9 params, `recordtype`,`object`,`type`,`node1`,`node2`,`name` |
| `udb_temp$audittrail` | 14927 | heap, NOT unique (`with duplicates`) — **persistent journaled base table** | `object` only — work list |
| `udb_temp$objectlist` | 14949 | heap, NOT unique — **persistent journaled base table** | `object,kvlevel` — trace work list |
| `udb_temp$terminallist` | 14972 | heap, NOT unique — **persistent journaled base table** | `object,basetype,terminal,node` — connectivity-trace scratch |

[VERIFIER-FIX] **CORRECTION to the original `udb_temp$*` characterization.** The original analysis described these three as "(session temp)", "session-scoped scratch tables (note `$` Ingres temp-table convention)", and "No persistent data." **That is WRONG.** [FACT - d1.sql:14927/14949/14972 DDL] All three are ordinary **persistent base tables**: `create table udb_temp$audittrail(object integer not null not default) with duplicates, structure=heap, ... ; modify ... to heap; set journaling on udb_temp$audittrail`. They are journaled, seeded via `copy ... from '/home/ingres/Downloads/udb_temp_*.ingres'`, and granted to public (21483+). The `$` is merely part of the regular table name (a naming convention), **NOT** the Ingres declared-global-temporary / `session.` temp-table mechanism. [INFERENCE - retained] They still function as connectivity-trace work sets (column shapes mirror objectlist/terminallist), but they are durable shared tables, so concurrent trace sessions would collide unless the trace logic deletes/owns rows per run — and that trace logic lives in stub procs, so the concurrency model is [UNKNOWN]. Do NOT call them session-scoped.

[FACT - 13489 DDL] `udb_circuitroute(object,route)` hash unique (object,route): object↔route mapping; object$insert seeds `(object,0)` for every TelephoneCircuit. [VERIFIER-CONFIRMED - seed insert `Udb_CircuitRoute (Object, Route) VALUES (:Object, 0)` present in the TelephoneCircuit branch.] [UNKNOWN] full route semantics (the `route` integer's meaning) — no proc body in dump references it beyond the seed insert; circuitroute procs (26231 ins/del, `udb_circuitrouteins`/`udb_circuitroutedel`) are stubs. [VERIFIER-CONFIRMED - both are `as begin return; end`.]

---

## 8. CONTRADICTIONS / GAPS

- **Prompt vs reality:** prompt's "one big table holds everything" → FALSE. It's class-table inheritance (udb_object + per-type subtype table, both PK=object). Documented in §0.
- **udb_capacitor and udb_reactor have IDENTICAL schemas** (`nominalmvar`,`voltsensitivity`,`avrdelay`) [FACT - DDL 13460/14581, VERIFIER-CONFIRMED byte-identical column sets] — they're distinguished only by type/tablename, not by columns. [INFERENCE] shunt-compensation devices sharing a model.
- **Two steamsupply-class objects** (`udb_steamturbine.steamsupply` is an object FK) link turbines to one of pwr/fossil/bwr steamsupply subtype tables — these are dynamic-simulation (transient stability) parameter sets, not T&D operations. [INFERENCE] SMS/Steam module remnant.
- **Subtype rows are NOT all FK-enforced:** udb_dsovalve and the three udb_export* tables are HEAP (no unique index), so object uniqueness for dsovalve is only by `not null` declaration, not enforced by a unique index [FACT - modify ... to heap, VERIFIER-CONFIRMED].
- **`udb_temp$*` are persistent, not session-temp** — see §7 VERIFIER-FIX. This is the one substantive error in the original analysis.
- [UNKNOWN] **No seed/catalog rows** for udb_type, udb_basetype, udb_supertype, udb_extendedtype, udb_problem, udb_lastkey, udb_groupingvalidation, udb_kvlevel — all loaded from absent `.ingres` files. Therefore the concrete type-code→tablename map, the full relationship/groupingtype enumerations, the problem-code dictionary, and which LastKey counters exist are reconstructable ONLY to the extent literals appear in proc/rule bodies (captured above). Anything beyond is [UNKNOWN].
- [UNKNOWN] The 69 `udb_*` one-space procs are stubs; if any carried real logic in production (e.g. udb_createnewnode, udb_buildgrouphistory, udb_exchangetermsgroups), that logic is NOT in this dump.

---

## Verification

Adversarial verification performed 2026-06-12 against `d:/103_RnD/psm_v1/d1.sql` and `d:/103_RnD/psm_v1/ug.html`. Method: grep/awk slice extraction + full proc-body reads (no whole-file reads).

### Object existence — 67/67 cited objects CONFIRMED, 0 fabricated
- **53 tables**: every `udb_*` table claimed (incl. `udb_temp$audittrail`, `udb_temp$objectlist`, `udb_temp$terminallist`) exists via `create table`. (Note: an initial `^create table NAME\(` grep returned 0 for the three `udb_temp$*` only because `$` is a regex metachar; direct inspection confirms all three exist at 14927/14949/14972.)
- **12 procs** (`object$insert`, `Node$Insert`, `Node$Delete`, `Grouping$Insert`, `Grouping$Validate`, `Grouping$Location`, `Conductor$Validate`, `GrassCatcher$Insert`, `kVLevel$Insert`, `LoadCurve$Insert`, `CascadeType$Change`, `Object$Validate`): each exists TWICE — once as a 1-space empty stub and once as a 2-space real body. Confirmed.
- **`object$insert`** in the cited object list is the proc; **`Object$Delete`** is a RULE (33131), not a proc — its prose description was already correct.
- **`FMS_TypeTerminals`** and **`SLC_EquipTemplate`** exist as base tables; both also referenced by real procs / object$insert. Confirmed.

### Load-bearing claims spot-checked against actual bodies — all ACCURATE
- `object$insert` (30457): full 7-step flow, all 22 TableName branches, the two side-inserts (CircuitRoute(Object,0); SLC_EquipTemplate), the `TableName=''` no-op, Object_012 grasscatcher, LastKey 'Object', Relationship=52 auto-grouping, terminal WHILE-loop — all verbatim.
- `GrassCatcher$Insert` (29830): dedupe `IF Refs>1 DELETE`, Severity='F'→RAISE ERROR -1 else MESSAGE — verbatim.
- `Grouping$Validate` (29850): supertype-expansion subqueries via udb_extendedtype, Object_013 sink — verbatim.
- `Conductor$Validate` (X/R<5→Conductor_001), `Object$Validate` (InService>OutService→Object_001), `Node$Delete` (terminal-ref guard), `Node$Insert` (LastKey 'Node'), `CascadeType$Change` (dual Udb_Grouping UPDATE), `Grouping$Location` (Relationship=57), `Grouping$Insert` (Object_004/005) — all verbatim.
- Relationship/type literals **52, 57, 10137, 10138, 40, 10152, 10154, 4, 10131, 998** — all confirmed in rule/proc bodies exactly as claimed.
- `udb_grouping` columns + `btree unique (grouping,relationship,member)`, `udb_circuitroute` `hash unique (object,route)`, capacitor==reactor schema, storage modes (dsovalve heap, grasscatcher btree NON-unique, capacitor/reactor btree unique) — all confirmed.
- Proc split 1225 stubs / 1225 real (every 1-space proc is `as begin return; end`) — confirmed by count.
- ug.html quotes ("connectivity model involves the following tables", "terminals value is two, then two rows are inserted...", "prevents a simple SQL 'Delete' statement", "Type 998 – Historical Object", "Terminal Mismatch", "Udb connectivity model using terminal and nodes") — confirmed present (text spans HTML tags; cited ug.html line numbers are unreliable and should be treated as approximate, the TEXT is the evidence).

### Corrections applied
1. **[MAJOR] `udb_temp$audittrail/objectlist/terminallist` are persistent journaled base tables, NOT session-scoped temp tables.** Original "(session temp)", "session-scoped scratch tables", "No persistent data" replaced. They have `structure=heap`, `set journaling on`, `copy from .ingres` seeds, and public grants. The `$` is a name convention, not the Ingres session-temp mechanism. Concurrency model of the trace work-sets is now flagged [UNKNOWN]. (§7, §8)
2. **[MINOR/CLARIFY] `Object$Delete` is a RULE, not a procedure** — does not appear in the 2,450-proc inventory. Prose was already correct; class-of-object label clarified. (§1)
3. **[MINOR/CLARIFY] object$insert step 2 (BaseType=0 → Object_012) does not abort** — it logs the grasscatcher row and falls through; no early return. (§3)
4. **[MINOR] ug.html line-number citations flagged as unreliable** (HTML is tag-wrapped, not line-oriented). Quoted text verified instead. (§6)

### Residual UNKNOWNs (unchanged, all legitimately seed-data-dependent)
- Full type-code→tablename map, complete relationship/groupingtype/membertype enumerations, problem-code dictionary, full LastKey counter list — all in absent `/home/ingres/Downloads/*.ingres` files; only proc/rule literals are recoverable.
- 69 one-space `udb_*` procs are empty stubs; any production logic they carried is not in this dump.
- `udb_circuitroute.route` integer semantics beyond seed `(object,0)`.
- `udb_groupinghistory` build/transfer-time population logic (`udb_buildgrouphistory` is a stub).
- Equipment kinds with no dedicated subtype table (busbar/breaker) hitting the `TableName=''` no-op; any extension attributes elsewhere unknown from DDL alone.
- `udb_temp$*` concurrency/ownership model (now that they are known to be persistent shared tables).
