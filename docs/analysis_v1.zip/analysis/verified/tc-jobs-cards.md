# TC Subsystem — Jobs, Cards, Trouble Report Orders (TLS / Telephone Line System)

Primary artifact: `d:/103_RnD/psm_v1/d1.sql`. Vocabulary bound to `ug.html`. Every material claim tagged.

> **VERIFICATION STATUS:** Adversarially verified 2026-06-12 against `d1.sql` (33,392 lines) and `ug.html`. 0 fabricated objects. 4 corrections applied inline (marked **[VERIFIER FIX]**). See `## Verification` footer.

---

## 0. HEADLINE — What TC actually is

**TC = TLS = "Telephone Line System"** — ConEd's trouble-call / telecom-circuit trouble-ticket switching application, one of the OMS switching applications that share the **FMS database**.

- [FACT - ug.html:5093-5095] "There are five switching applications that use DBM. 1) FMS - Distribution Feeders, 2) TOMS (or SOA) ... TFMS, and **3) TLS - Telephone Lines** use the 'FMS' database." → TC tables physically live in the FMS Ingres database alongside fms_/soa_/tfms_. ✓ VERIFIED (ug.html:5093-5095).
- [FACT - ug.html:11061] "These numbers are saved in the **TC_TroubleType table in the FMS database**." → confirms TC_* = TLS and resides in FMS DB. ✓ VERIFIED (ug.html:11061).
- [FACT - ug.html:10790,10796,10815] UI is the "**telephonecard** main screen"; cards are loaded per "telephone circuit." TC manages telephone/telecom circuit cards.
- [FACT - ug.html:10976-10977] "To create an electronic ticket for a Verizon circuit, the TLS system has to send the Verizon name... **TC_VerizonCircuit** table stores the mapping." → TC issues electronic trouble tickets to **Verizon** (the telco carrier). ✓ VERIFIED (ug.html:10975-10977).
- [INFERENCE] TC is NOT a generic job-ticketing system and NOT a power-feeder switching system. It is the telephone/telecom-line trouble-order subsystem: a DO (District Operator) opens a card on a telephone circuit, performs switching moves (jobs), and issues trouble report orders downloaded to Verizon's TLS, polling status back.

### JOB vs CARD vs MOVE (resolved from the guide)
- [FACT - ug.html:5160-5163] "A **Job Class** defines the 'move' with all the move rules, job checks and actions for each OMS switching application. **The term 'move' and 'job' are synonymous.**" ✓ VERIFIED (ug.html:5160-5163, exact phrasing confirmed).
- [INFERENCE - ug.html:5162 + tc_job/tc_card DDL] Therefore in TC: a **CARD** is the work container (one telephone circuit's switching/trouble card); a **JOB = a single switching MOVE/step on that card**. `tc_job` is keyed `(card, seq, job)` — i.e. ordered steps within a card. A card holds N jobs (moves) in `seq` order. This is the identical card→ordered-steps pattern used by FMS (fms_card/fms_job) and SOA.

> CONTRADICTION vs prompt premise: prompt asked "is a card a switching step within a job?" — **No, it is the inverse.** Card is the parent container; job is the step/move. Evidence: `tc_job` btree index on `(card, seq, job)` [FACT - d1.sql] and ug.html:5162. ✓ VERIFIED — `modify tc_job to btree on (card, seq, job)` confirmed.

---

## 1. CRITICAL CONSTRAINT — All TC procedure bodies are STUBS

[FACT - d1.sql] All **127** `create or replace procedure tc*` statements are empty stubs of the form `... as begin return; end`. **[VERIFIER FIX]** ~~Verified: 122 match the bare `as begin return; end` regex; the other 5 (`tc_relayprotection$chk`, `tc_reportln$upd`, `tc_reportnoorg$ins`, `tc_reportos$ins`, `tc_reportstats$ins`) are also `as begin return; end` (just `$`-suffixed rule helpers).~~ → **CORRECTED: ALL 127 TC procs (including the 5 `$`-suffixed rule helpers) match the bare `as begin return; end` form. Grep `^create or replace procedure tc[a-z0-9_$]* as begin return; end` returns 127/127; zero TC procs deviate.** The original "122 + 5" split was an internal miscount. **Zero TC procedure bodies exist in this dump.**

- [FACT - d1.sql:25707] `create or replace procedure tc_insertcard as begin return; end` — representative. ✓ VERIFIED (tc_insertcard exists, is a bare stub).
- [FACT - d1.sql] **[VERIFIER FIX]** ~~Globally ~1,225 procs have real bodies and ~1,163 are stubs~~ → **CORRECTED: globally 2,450 procs total; exactly 1,225 are bare `as begin return; end` stubs → 1,225 have real bodies (≈50/50 split). The original "1,163 stubs" figure was wrong; stub count is 1,225.** **TC falls entirely in the stubbed set** (127/127). ✓
- [INFERENCE] Server-side TC logic (insert/issue/complete/archive flows) is **[UNKNOWN] at the statement level** — cannot be quoted from proc bodies. The recoverable behavior comes from **Ingres RULES** (present in full, lines 33272-33352) which fire these procs with explicit WHERE-clause guards and parameter bindings, plus DDL structure and ug.html.

This is the single most important fact for downstream synthesis: **do not expect TC business logic from proc bodies; reconstruct from rules + DDL + guide only.**

---

## 2. TC TABLE CATALOG (33 tables)

[FACT - d1.sql grep `^create table tc_`]. Column counts verified by AWK over DDL blocks. ✓ VERIFIED — grep returns exactly 33 `tc_` tables; all 33 names below confirmed present.

| # | Table | Cols | Storage / Key | Role (INFERENCE unless cited) |
|---|-------|------|---------------|------|
| 1 | `tc_card` | 29 | btree **unique** on `(card,circuit)` | Trouble/switching card header per telephone circuit |
| 2 | `tc_job` | 37 | btree on `(card,seq,job)` | Ordered switching **move** (step) within a card |
| 3 | `tc_troublereportorder` | 30 | btree on `(circuit,workpermit)` | Electronic trouble ticket order sent to Verizon/TLS |
| 4 | `tc_troublereportstatus` | 6 | btree unique | Status-history rows per order (`ordernumber,sequenceid`) |
| 5 | `tc_troubletype` | 3 | btree unique | Verizon report-type code catalog [FACT ug.html:11060] |
| 6 | `tc_troublestatus` | 4 | btree unique | Verizon status-number catalog [FACT ug.html:11076] |
| 7 | `tc_cardlock` | 3 | btree unique | Card control lock (user/desk owns the card) |
| 8 | `tc_cardnote` | 2 | hash unique | Free-text note attached to a card |
| 9 | `tc_circuitslog` | 4 | btree unique | Timestamped circuit log entries per card |
| 10 | `tc_circuitdocument` | 3 | hash unique | Circuit doc registry [FACT ug.html:10789 "Docs"] |
| 11 | `tc_circuitdocumentlink` | — | btree unique | Links circuit→document |
| 12 | `tc_circuittoreportmapping` | 2 | btree unique | `circuittype → reporttype` mapping |
| 13 | `tc_verizoncircuit` | 2 | btree unique | ConEd circuit ↔ Verizon line-name map [FACT ug.html:10977] |
| 14 | `tc_workpermit` | 12 | hash unique | Work-permit detail (keyed `permitjobid`) ✓ VERIFIED (hash unique on permitjobid, 12 cols) |
| 15 | `tc_operatingstepstatus` | 10 | btree unique | Live operating-step timing per card/circuit |
| 16 | `tc_reportstats` | 16 | btree | Outage/restoration statistics rows (hours out) |
| 17 | `tc_reportmanager` | 7 | btree unique | Per-circuit "report needed" flag / last access |
| 18 | `tc_problemtracker` | 5 | btree unique | Circuit problem-tracking notes |
| 19 | `tc_workgrouprequest` | 19 | btree unique | Work-group dispatch request (`requestid`) |
| 20 | `tc_wgrequestrecipient` | 10 | btree unique | Recipients of a work-group request + responses |
| 21 | `tc_wgrequestack` | 1 | heap | Acknowledgement stub (`requestid` only) ✓ VERIFIED (single col `requestid`, `modify ... to heap`) |
| 22 | `tc_specialpstsubstation` | — | btree unique | Special PST substation list |
| 23 | `tc_systemparameters` | 4 | isam unique | TLS tunables (telcardactivity, responsetimeout, minimumdodelayrecorded) ✓ VERIFIED (4 cols: rowkey + those 3) |
| 24 | `tc_lastkey` | 2 | btree unique | Manual sequence generator (`table_name,last_key`) |
| 25 | `tc_log` | 10 | btree | Card/job change audit log |
| 26 | `tc_tempgroupertransfer` | — | btree unique | Scratch table for grouper move transfer |
| **Archive twins (8)** | | | | |
| 27 | `tc_archivecard` | 28 | btree unique | Archived card (drops `priority` vs live) ✓ VERIFIED (28 cols, no `priority`) |
| 28 | `tc_archivejob` | 37 | btree | Archived job/move |
| 29 | `tc_archivelog` | — | btree | Archived log |
| 30 | `tc_archivecircuitslog` | — | btree unique | Archived circuit log |
| 31 | `tc_archiveoperatingstep` | 10 | btree unique | Archived operating-step timing (mirror of tc_operatingstepstatus) |
| 32 | `tc_archivereportstats` | — | btree | Archived report stats (drives report-rollup rules) |
| 33 | `tc_archiveworkpermit` | — | hash unique | Archived work permit |

[FACT] 8 archive twins (`tc_archive*`), consistent with the 35 archive twins counted dump-wide. Archive twins are near-structural copies of their live tables, used for closed/historical cards.

---

## 3. DEEP-READ: `tc_card` (29 cols)

[FACT - d1.sql:11773-11801] Header per telephone circuit. ✓ VERIFIED — 29-column DDL confirmed; column names/types below match the dump. Notable columns:

| Column | Type | Notes [INFERENCE unless cited] |
|--------|------|------|
| `card` | int PK-part | Card id; unique with `circuit` |
| `circuit` | int | The telephone circuit (a udb_object); FK to circuit object |
| `linenumber` | varchar(40) | Circuit line number; **empty→nonempty transition activates the card** (see rule below) ✓ VERIFIED `varchar(40) ... default ' '` |
| `circuitstatus`/`circuitstatusname` | int/varchar | Circuit operating status (set from fms_objectstatus via tc_circuitstatuschange) ✓ VERIFIED both cols exist |
| `status` | int **not default** | Card lifecycle status (integer codes — values are **[UNKNOWN]**, no seed rows; rule shows `status=4` = closeable/report-removal) ✓ VERIFIED `status integer not null not default`; status=4 guard confirmed in rule TC_RemoveCardReport2 |
| `username` | char(24) nullable | Current owner/controller ✓ VERIFIED `username char(24)` (nullable) |
| `cardtype`,`linetype`,`linetypename`,`functionarea`,`troublecategory`,`carrier` | int+name pairs | Classification (name columns are denormalized caches) ✓ VERIFIED all present (+`carriername`,`functionareaname`,`troublecategoryname`) |
| `opened`/`closed` | ingresdate | Card open/close timestamps ✓ VERIFIED |
| `validatedby` | varchar(24) | Validation actor ✓ VERIFIED |
| `reasonforfailure` | varchar(120) | Trouble reason text ✓ VERIFIED |
| `priority` | int NULL | Present in live, **absent in tc_archivecard** [FACT - DDL diff] ✓ VERIFIED `priority integer default NULL`; absent in tc_archivecard |
| `altline1`,`altline2`,`routename`,`substationnames`,`feedernames` | varchar/char | Denormalized routing/topology strings ✓ VERIFIED (note: `substationnames`/`feedernames` are `char(80)`, `routename` `varchar(80)`, `altline1/2` `varchar(40)`) |

> [VERIFIER NOTE] Additional live columns not in the analyst's "notable" subset but present in the 29-col DDL: `notes varchar(200)`, `shownote int`, `billing int`, plus the `*name` cache columns above. Subset table is illustrative, not exhaustive — no error.

Storage: `btree unique on (card,circuit)`, page 8192, journaling on [FACT - d1.sql:11815]. ✓ VERIFIED `modify tc_card to btree unique on (card, circuit)`.

---

## 4. DEEP-READ: `tc_job` (37 cols) — the switching MOVE

[FACT - d1.sql:11995-12031]. Key=`(card,seq,job)`. ✓ VERIFIED — 37 cols, btree on (card,seq,job). A job is one move; columns split into a **TO (issue/take-out)** half and an **RS (restore)** half — classic two-phase switching move (out-of-service then in-service):

| Group | Columns | Meaning [INFERENCE] |
|-------|---------|------|
| Identity | `job`, `card`, `seq`, `jobclass`, `jobclassseq`, `steppair` | job id; parent card; sequence within card; job-class (=move definition, ug.html:5161); steppair links TO/RS halves ✓ VERIFIED `steppair integer not null not default` |
| Status | `status char(3)` | Move status code; **known value: `'Xfr'` = "Move transferred"** [FACT - rule TC_LogJob_XfrStatus] ✓ VERIFIED `status char(3)`; `'Xfr'` guard + `Item='Move transferred'` confirmed in rule |
| Topology | `circuit`, `linenumber`, `circuitclass`, `circuitclassname`, `substation`, `substationname`, `organization`, `organizationname` | what is being switched |
| TO half | `movetype char(4)`, `tomove`, `tostep`, `tomoverules`, `tooperator`, `tooperatorname`, `toissued`, `tocomplete` | take-out / issue side of the move ✓ VERIFIED `movetype char(4)` |
| RS half | `rsmove`, `rsmoverules`, `rsstep`, `rsoperator`, `rsoperatorname`, `rsissued`, `rscomplete` | restore side of the move |
| Service | `inservice`, `outservice` | service-interruption timestamps — **drive report-stats rules** |
| Switch pos | `initialswitchpos`, `finalswitchpos` | device position before/after |
| Results | `results`, `resultscode`, `resultscodename` | move outcome |

[INFERENCE] `tomoverules`/`rsmoverules` > 1 trigger move-rule expansion (rule `TC_JobInsMoveRules`). `inservice`/`outservice` null↔notnull transitions are the hooks for outage statistics and relay-protection checks. ✓ VERIFIED — rules TC_JobInsMoveRules1/2 guard on `New.TOMoveRules > 1 OR New.RSMoveRules > 1`; TC_RelayProtection$Chk guards on OutService/InService null↔notnull flips.

Sentinel value seen: `job = -1` (placeholder/new), `job = 2147483647` (max-int sentinel), `seq = -1` — used as insert-staging markers (rules `TC_JobInsert2`, `TC_GrouperSeqUpd`). ✓ VERIFIED — `TC_JobInsert2 ... WHERE New.Job = -1`; `TC_GrouperSeqUpd ... WHERE Old.Job = -1 AND New.Job > 1 AND Old.Seq = -1`; `2147483647` appears in TC_JobInsMoveRules2 guard.

---

## 5. DEEP-READ: `tc_troublereportorder` (30 cols) — electronic ticket to Verizon

[FACT - d1.sql:12350-12380]. Key path: `(circuit, workpermit)` index; identity `ordernumber`. ✓ VERIFIED — 30 cols, btree on (circuit, workpermit).

| Phase | Columns |
|-------|---------|
| Identity/link | `ordernumber`, `orderstatus`, `card`, `circuit`, `workpermit`, `msgkey` |
| Issue | `issuecomment`, `troubletype` (→tc_troubletype), `issuedbydo`, `dophone`, `issuetime`, `downloadtime`, `reportid` |
| Report state | `reportstate`, `reportstatus` (→tc_troublestatus), `statustime`, `lastpoll`, `pollrate` |
| Ack/Reject | `ackrejecttime`, `ackrejectby`, `ackrejectcomment` |
| Rescind | `rescindtime`, `rescindtype`, `rescinddo`, `rescindreasontype`, `rescindreasontypename`, `rescindcomment` |
| Verify | `verification`, `verifydo`, `verifycomment` |

[FACT - ug.html:11070-11077] "During the processing of trouble tickets, **Verizon communicates the progress to TLS by sending a status number**... The status information is stored in the **TC_TroubleStatus** table." → `reportstatus`/`reportstate` are Verizon-returned codes; `pollrate`/`lastpoll` implement polling for ticket progress. ✓ VERIFIED (ug.html:11071,11076).
[FACT] `row_estimate = 8228` on the copy statement — the busiest TC table (vs tc_card row_estimate=206, tc_job=3595). [VERIFIER NOTE] Not re-checked against copy headers; non-load-bearing.

**Status history twin:** `tc_troublereportstatus(ordernumber, sequenceid, reportstate, reportstatus, statustime, statuscomment)` [FACT - d1.sql:12406] — one row per status transition of an order. ✓ VERIFIED — exact 6 columns `ordernumber, sequenceid, reportstate, reportstatus, statustime, statuscomment` confirmed in DDL. [INFERENCE] `ordernumber` joins to `tc_troublereportorder.ordernumber`; `sequenceid` orders the history.

---

## 6. The TRO → JOB → CARD chain (reconstructed)

[INFERENCE from FK-shaped columns + rules; no proc bodies to confirm]

```
tc_card (card, circuit)                     ← work container, one telephone circuit
   │ 1:N  (card, seq)
   ▼
tc_job (card, seq, job)                      ← ordered switching MOVE/step
   │ references circuit  [VERIFIER FIX: tc_job has NO workpermit column]
   ▼
tc_workpermit (permitjobid)                  ← permit covering a job; permitjobid ≈ tc_job.job (name-based INFERENCE only)
   │
tc_troublereportorder (ordernumber)          ← electronic ticket, links card+circuit+workpermit
   │ 1:N (ordernumber, sequenceid)
   ▼
tc_troublereportstatus                       ← Verizon status history per order
```

> **[VERIFIER FIX]** The original diagram drew `tc_job → tc_workpermit` and said tc_job "references workpermit, circuit." **CORRECTED: `tc_job` contains a `circuit` column but NO `workpermit` (or `permitjobid`) column** — verified by AWK over the full tc_job DDL (grep for `workpermit|permit` returns empty). The only structural link to work permits is: `tc_troublereportorder.workpermit` → `tc_workpermit.permitjobid` (name/value INFERENCE, no FK), and `tc_workpermit.permitjobid` is plausibly the same domain as `tc_job.job` (INFERENCE, unconfirmed). The job↔workpermit edge is **weaker than originally drawn** and is pure inference.

Supporting links: `tc_workgrouprequest(card, job, tors, circuit)` carries `tors` (=trouble-order/report sequence) tying a work-group dispatch to a card+job [FACT - d1.sql workgrouprequest DDL has columns card,job,tors,circuit]. ✓ VERIFIED — `card, job, tors, circuit` all present in tc_workgrouprequest DDL.

---

## 7. RECOVERABLE BUSINESS LOGIC — Ingres RULES (the real behavior)

[FACT - d1.sql:33272-33352] All TC rules present in full. ✓ VERIFIED — rules block read in full; every rule, guard, and bound proc below matches the dump verbatim. These are the only place TC server logic survives. Each fires a (stubbed) proc with explicit guards:

### Card lifecycle
| Rule | Trigger / Guard | Action |
|------|-----------------|--------|
| `tccard$insert` | AFTER INSERT tc_card | `TC_CardIns(Card)` ✓ |
| `tccardnote$ins` / `$del` | INSERT/DELETE **tc_card** (note: both fire ON tc_card, not tc_cardnote) | `TC_CardNoteIns` / `TC_CardNoteDel` ✓ VERIFIED — `tccardnote$ins after insert into tc_card`, `tccardnote$del after delete from tc_card` |
| `TC_ActivateCardInserted` | UPD(LineNumber) tc_card WHERE Old=''  AND New<>'' | `TC_NewActiveCard(Card,Circuit,LineNumber)` → **card activation when line number first set** ✓ VERIFIED (rule; binds to proc tc_newactivecard) |
| `tccard$anyupd` | AFTER UPDATE tc_card | `TC_CardAnyUpd(Card)` ✓ |
| `tccard$typeupd` | UPD(linetype) WHERE changed | `TC_CardTypeUpd` ✓ |
| `tccard$funcareaupd` | UPD(functionarea) WHERE changed | `TC_CardFuncAreaUpd` ✓ |
| `tccard$carrierupd` | INSERT udb_grouping WHERE relationship=15013 AND groupingtype=3 | `TC_CardCarrierUpd(circuit,carrier)` — carrier from UDB grouping ✓ VERIFIED (binds `circuit=new.member, carrier=new.grouping`) |
| `TC_RemoveCardReport2` | UPD(Status) tc_card WHERE **New.Status=4** | `TC_RemoveCardReport(Card)` → status 4 = report removal/close ✓ VERIFIED |

### Card control / lock → report flag
| `TC_CardControlTaken` | AFTER INSERT tc_cardlock | `TC_SetReportFlag(Card,UserName)` ✓ |
| `TC_ControlLifted` | AFTER DELETE tc_cardlock | `TC_ClearReportUserName(Card)` ✓ |

### Job (move) lifecycle
| `TC_JobInsert2` | INSERT tc_job WHERE **New.Job=-1** | `TC_JobInsert2` — assign real job id to staged row ✓ |
| `TC_GrouperSeqUpd` | UPD(Job) WHERE Old.Job=-1 AND New.Job>1 AND Old.Seq=-1 | `TC_GrouperSeq(StepPair,Job)` ✓ |
| `TC_JobInsMoveRules1` | UPD(Job) WHERE TOMoveRules>1 OR RSMoveRules>1 | `TC_JobInsMoveRules` — expand move rules ✓ |
| `TC_JobInsMoveRules2` | INSERT WHERE (rules>1) AND Job<>-1 AND Job<>2147483647 | same ✓ |
| `tcjob$insupd` | UPD,INSERT tc_job | `TC_JobInsUpd(Card,Job)` ✓ |
| `tcjob$substationupd` | UPD(substation) WHERE changed | `TC_JobSubstationUpd` ✓ |
| `TC_LogJob_XfrStatus` | UPD(Status) WHERE **New.Status='Xfr'** | `TC_LogInsert(... Item='Move transferred')` ✓ |
| `TC_LogJob_XfrStatus1` | INSERT WHERE Status='Xfr' | same ✓ |

### Service / outage statistics (the report engine)
| `TC_ReportStats$Ins` | UPD(OutService) tc_job WHERE New notnull, Old null | `TC_ReportStats$Ins(...)` — open an outage stat when move goes out of service ✓ |
| `TC_ReportStats$Upd` | UPD(InService) tc_job WHERE New notnull, Old null | restore → close outage stat (NB: binds to proc `TC_ReportStats$Ins`, passing ServiceTime) ✓ VERIFIED |
| `TC_ReportUpdAdj` | INSERT tc_reportstats | `TC_ReportUpdAdj` ✓ |
| `TC_CalculateHoursOut` | UPD(Inservice) tc_reportstats WHERE New notnull, Old null, Sequence=1 | `TC_CalculateHoursOut` ✓ |
| `TC_ReportLN$Upd` / `TC_ReportNoOrg$Ins` / `TC_ReportOS$Ins` | INSERT tc_archivereportstats WHERE Sequence IN(2,3)/OrganizationName=''/Seq=3 | report rollups fire off the **archive** table ✓ VERIFIED (NoOrg guard is `New.OrganizationName = ''`) |

### Operating-step timing
| `TC_CalculateDuration` | UPD(EndTime) tc_operatingstepstatus | `TC_CalculateDuration(Card,OperatingStep,StartTime,EndTime)` ✓ |
| `TC_DelayCheck` | INSERT tc_operatingstepstatus WHERE OperatingStep NOT IN (10147,10134) | `TC_DelayCheck` ✓ |
| `TC_DODelayAdj` | INSERT WHERE OperatingStep=10134 AND EndTime='' | `TC_DODelayAdj(Card)` — **10134 = a DO-delay step code** ✓ |

### Relay protection
| `TC_RelayProtection$Chk` | UPD tc_job WHERE OutService/InService null↔notnull flips | `TC_RelayProtection$Chk(Circuit)` — recheck relay protection on service change ✓ |

### Circuit status integration with FMS
| `tc_status_change1/2/3` | INSERT/DELETE/UPDATE **fms_objectstatus** | `TC_CircuitStatusChange(circuit,circuitstatus)` — **TC reacts to FMS object-status changes** (TC and FMS share the DB) ✓ VERIFIED — three rules bind `circuit=new/old.object, circuitstatus=new/old.status` |

### Key generation (manual sequences)
[FACT] `TC_Log$Ins`, `TC_ArchiveLog$Ins`, `TC_ReportStats$Ins2`, `TC_ArchiveReportStats$Ins` all fire `CAC_KeyGeneratorN(TableName, RowTID=new.tid)` on insert → surrogate keys are minted by the shared **CAC_KeyGenerator** family (cross-module key service), plus `tc_lastkey` for table-scoped counters and `tc_lastkeyupd`/`tc_newseq` procs. ✓ VERIFIED — TC_Log$Ins→CAC_KeyGenerator5, TC_ArchiveLog$Ins→CAC_KeyGenerator3, TC_ReportStats$Ins2→CAC_KeyGenerator7, TC_ArchiveReportStats$Ins→CAC_KeyGenerator8 all confirmed with `RowTID=new.tid`.

---

## 8. DBEVENTS — the async client signalling layer

[FACT - d1.sql:27510-27666] **[VERIFIER FIX]** ~~**28 TC dbevents**~~ → **CORRECTED: exactly 27 TC dbevents** (`grep -icE '^create dbevent tc_'` = 27, confirmed twice; the enumerated name list below also contains exactly 27 distinct names — the "28" header was an off-by-one, the list itself was always correct). Each with `grant register`+`grant raise to public`. These push notifications to the TLS client (a separate Tcl/Java app, not the OpenROAD psm.dmt frames — no `tc_`/telephonecard references in psm.dmt or psm_4glprocs.dmt [FACT - grep returned empty]).

The 27 dbevents (alphabetical, all ✓ VERIFIED present): `tc_cardcontroltaken`, `tc_cardrequest`, `tc_cardrouteupd`, `tc_cardupdate`, `tc_checkoutservice`, `tc_checkrelayprotection`, `tc_completeorders`, `tc_defectiverelay`, `tc_delaycleared`, `tc_dodelay`, `tc_jobupdated`, `tc_loadcard`, `tc_loadisp`, `tc_processingrtucircuit`, `tc_processingtrorders`, `tc_processingwgresponse`, `tc_protectionupd`, `tc_refresh_otherdesk`, `tc_reloadjob`, `tc_returntrorders`, `tc_returnwgresponse`, `tc_rtucircuitcomplete`, `tc_rtucircuitpermit`, `tc_statuschange`, `tc_systemparameters`, `tc_tlswgresponsecomplete`, `tc_trordercomplete`.

[INFERENCE] The trouble-order roundtrip with Verizon and the RTU/work-group response handling are event-driven: a daemon raises `tc_processingtrorders`/`tc_returntrorders`/`tc_trordercomplete` as tickets move through Verizon; `tc_refresh_otherdesk` keeps multiple DO desks in sync.

---

## 9. ARCHIVE PATTERN

[FACT] 8 `tc_archive*` tables structurally mirror their live counterparts (`tc_archivecard`↔`tc_card`, `tc_archivejob`↔`tc_job`, etc.). Differences are minor (e.g. live `tc_card` has `priority` and `shownote`; `tc_archivecard` drops `priority`; column ordering of `initialswitchpos`/`finalswitchpos` differs between `tc_job` and `tc_archivejob`). ✓ VERIFIED — tc_archivecard = 28 cols (one fewer than tc_card's 29), `priority` absent.

- [INFERENCE] On card close/completion, the (stubbed) `tc_cardarchiver` proc copies the card and its child rows (`tc_deletecard`, `tc_deletecardjobs`, `tc_deletecardlog`, `tc_deletecardoperstep`, `tc_deletecardreportstats`, `tc_cascadecarddel` procs exist as stubs) into the archive twins and removes the live rows. **Exact logic [UNKNOWN]** — bodies stubbed. ✓ VERIFIED that `tc_cardarchiver` and `tc_cascadecarddel` exist as bare stubs. [VERIFIER NOTE] The other `tc_deletecard*` proc names cited here were NOT individually grep-confirmed by the verifier; the cascade/delete-child-table set and its order remain INFERENCE from names only (as the analyst already flags).
- [FACT] Reporting rollups (`TC_ReportLN$Upd`, `TC_ReportNoOrg$Ins`, `TC_ReportOS$Ins`) trigger off `tc_archivereportstats` INSERTs, confirming report statistics are finalized at archive time. ✓ VERIFIED — all three rules guard `AFTER INSERT ON TC_ArchiveReportStats`.

---

## 10. RELATION TO SOA, FMS, TFMS

| System | Relationship to TC [evidence] |
|--------|------|
| **FMS** | Same Ingres DB [FACT ug.html:5095]. TC reacts to `fms_objectstatus` changes via `tc_status_change1/2/3` rules [FACT d1.sql:33324-33328]. ✓ VERIFIED. ug.html ties TC tunables to "FMS ETC Deadband" for work-permit alerting [FACT ug.html:6690,6737] [VERIFIER NOTE: not re-checked, non-load-bearing]. |
| **SOA (=TOMS)** | Shares the `soa_activecard` registry. `SOA_RemoveCardReport2` rule mirrors `TC_RemoveCardReport2` [FACT — TC side ✓ VERIFIED; SOA-side rule name not re-checked]. SOA_ActiveCard has an `application char(4)` discriminator [FACT d1.sql DDL] ✓ VERIFIED `application char(4) not null not default`. |
| **TFMS** | `TFMS_NewCardActivated AFTER INSERT INTO SOA_ActiveCard WHERE New.Application <> 'FMS'` [FACT d1.sql:33358] ✓ VERIFIED at line 33358 verbatim — any non-FMS active card (incl. TLS-origin) flows into TFMS activation. **TC participates in the shared SOA_ActiveCard card registry**, discriminated by `application`. |
| **Common pattern** | TC = FMS = SOA all use the **card → ordered jobs(moves) → workpermit** model with TO/RS two-phase moves, denormalized name caches, archive twins, CAC_KeyGenerator surrogate keys, and dbevent client signalling. TC is the **telephone-line specialization** of that shared switching framework, adding the Verizon electronic-ticket layer (`tc_troublereportorder` + poll/status). |

---

## 11. GAPS / [UNKNOWN]

- **All TC proc bodies are stubbed** → no statement-level lifecycle (insert/issue/complete/archive/undo) recoverable. Only rule guards + param bindings + names are evidence. ✓ CONFIRMED (127/127 bare stubs).
- **No seed rows** (external `.ingres` files absent): `tc_card.status` integer codes (only `4`=report-removal observed via rule), `tc_job.status char(3)` codes (only `'Xfr'` observed), `tc_troubletype.type` (Verizon numbers), `tc_troublestatus.status`/`action` enumerations, `cardtype`/`linetype`/`troublecategory`/`functionarea` code lists, `operatingstep` codes (only `10134`,`10147` observed in rules) — all **[UNKNOWN]**. ✓ CONFIRMED.
- `tc_wgrequestack` is a single-column (`requestid`) heap — purpose beyond an ack marker is [UNKNOWN]. ✓ CONFIRMED.
- `tc_tempgroupertransfer`, `tc_specialpstsubstation` DDL not fully read here (small; flagged for completeness) — column detail [UNKNOWN beyond name].
- **[VERIFIER-UPGRADED]** `tc_job` has **no** `workpermit`/`permitjobid` column; the job↔work-permit linkage is INFERENCE through `tc_troublereportorder.workpermit → tc_workpermit.permitjobid` only, unconfirmed by FK/proc body. (Original gap understated this — the chain diagram in §6 has been corrected.)
- TLS client UI is **not** in psm.dmt/psm_4glprocs (OpenROAD) — it is an external app; its frame logic is outside these artifacts.
- Prompt's stated column counts (job 43 / card 35 / TRO 36) **do not match the dump** (job 37 / card 29 / TRO 30). Using DDL-verified counts. ✓ CONFIRMED — job=37, card=29, TRO=30 all re-verified by AWK column count.

---

## Verification

**Verifier:** adversarial pass, 2026-06-12, against `d:/103_RnD/psm_v1/d1.sql` and `d:/103_RnD/psm_v1/ug.html`.

### Object existence — 0 fabricated
All cited objects in the prompt's claim list were confirmed present:
- **33/33 `tc_` tables** exist (`grep -icE '^create table tc_'` = 33), plus `soa_activecard`, `fms_objectstatus`, `CAC_KeyGenerator3`.
- All cited **procedures** exist as bare stubs (`tc_insertcard`, `tc_insertjob`, `tc_issuejob`, `tc_completejob`, `tc_closecard`, `tc_cardarchiver`, `tc_cascadecarddel`, `tc_troublereportorderins`, `tc_newactivecard`, `tc_removecardreport`, `tc_setreportflag`, `tc_calculatehoursout`, `tc_reportstats$ins`, `tc_relayprotection$chk`, `tc_circuitstatuschange`, `tc_jobinsmoverules`, `tc_loginsert`, `tc_jobinsert2` …).
- **Type re-classification (not fabrication):** several names in the flat claim list are **RULES**, not procedures — `TC_ActivateCardInserted`, `TC_JobInsert2`, `TC_LogJob_XfrStatus`, `TC_RemoveCardReport2`, `TC_RelayProtection$Chk`, `tc_status_change1`. And `tc_cardupdate`, `tc_processingtrorders`, `tc_trordercomplete` are **DBEVENTS**, not procedures. All exist; only the object-type label differs from what a flat list implies.

### Confirmed (spot-checked against DDL/rules/guide)
1. Column counts: `tc_card`=29, `tc_job`=37, `tc_troublereportorder`=30, `tc_troublereportstatus`=6, `tc_workpermit`=12, `tc_systemparameters`=4, `tc_archivecard`=28. All AWK-verified.
2. Storage/keys: tc_card btree **unique** (card,circuit); tc_job btree (card,seq,job); tc_troublereportorder btree (circuit,workpermit); tc_workpermit hash unique (permitjobid); tc_wgrequestack heap. All confirmed.
3. Column types: `tc_card.status integer not null not default`; `tc_job.status char(3)`; `tc_job.steppair`/`movetype char(4)`; `priority integer default NULL` present in tc_card, absent in tc_archivecard.
4. All §7 Ingres rules read in full (d1.sql:33272-33352) — every guard, WHERE clause, and bound proc matches verbatim, including `New.Status=4`, `New.Status='Xfr'`, `New.Job=-1`, `2147483647`, OperatingStep `10134`/`10147`, and the CAC_KeyGenerator N-suffixes.
5. ug.html quotes verified at the cited lines: 5093-5095 (five switching apps / TLS-Telephone Lines / FMS database), 5160-5163 ("move and job are synonymous"), 10975-10977 (Verizon electronic ticket / TC_VerizonCircuit), 11061 (TC_TroubleType in FMS DB), 11071/11076 (Verizon status number / TC_TroubleStatus).
6. soa_activecard `application char(4)` discriminator and TFMS_NewCardActivated rule at d1.sql:33358 confirmed verbatim.

### Corrected (4 inline fixes, marked [VERIFIER FIX])
1. **§8 dbevent count: 28 → 27.** Actual `^create dbevent tc_` count is 27 (the enumerated name list was already correct at 27; only the header number was wrong).
2. **§1 stub-count narrative: "122 bare + 5 $-suffixed" → all 127 match the bare `as begin return; end` form.** The original split was an internal miscount; regex confirms 127/127.
3. **§1 global proc figures: "~1,225 real / ~1,163 stub" → 2,450 total, 1,225 stubs, 1,225 real-bodied.** The "1,163 stub" figure was wrong.
4. **§6 chain diagram: removed the `tc_job → tc_workpermit` structural edge.** `tc_job` has NO `workpermit`/`permitjobid` column (AWK-verified empty); the job↔work-permit link is pure inference via `tc_troublereportorder.workpermit`. Gap list in §11 upgraded accordingly.

### Residual UNKNOWNs (unchanged, valid)
- All statement-level TC business logic (insert/issue/complete/closecard/archiver/undojob) — bodies stubbed.
- Seed/enum values: `tc_card.status` (only 4 observed), `tc_job.status` (only 'Xfr'), `tc_troubletype.type`, `tc_troublestatus.status`/`action`, and the cardtype/linetype/troublecategory/functionarea/operatingstep code lists.
- Exact archive cascade order and which child tables move on card close — inferred from stubbed proc names only; the `tc_deletecard*` proc set was not individually grep-confirmed by the verifier.
- `tc_workpermit.permitjobid → tc_job` linkage — name-based inference, no FK.
- `tc_wgrequestack` purpose beyond an ack marker.
- TLS client UI/frame logic — external app, absent from psm.dmt / psm_4glprocs.dmt.
