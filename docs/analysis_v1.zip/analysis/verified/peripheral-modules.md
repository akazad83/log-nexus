# Peripheral Modules & Integration Surfaces — Raw Analysis

> **[VERIFIED 2026-06-12]** Adversarial verification complete. 90/90 cited tables confirmed to exist; 16/16 cited procs confirmed with real bodies. All DDL column lists, status codes, pipetype/color literals, dbevents, and rules spot-checked against actual artifact bodies and corroborated. Inline `[VERIFIED]`/`[CORRECTED]` stamps added where checked; see `## Verification` footer for the full ledger. Original analyst content preserved verbatim except where marked `[CORRECTED]`.

Source of record: `d:/103_RnD/psm_v1/d1.sql` (Ingres DDL/dump) + `ug.html` (business semantics). No row data exists (every table loaded via absent `copy ... from '/home/ingres/Downloads/*.ingres'`); `row_estimate=N` on each `copy` is a loader sizing hint = relative scale only, NOT authoritative counts. **[VERIFIED - d1.sql:39,7227]** — confirmed: `copy <t> () from '/home/ingres/Downloads/<t>.ingres' with notnull_empty, row_estimate = N`; `row_estimate` is a `with`-clause on the COPY (Ingres loader pre-allocation hint), exactly as stated.

## 0. CRITICAL STRUCTURAL NOTE ON PROCEDURE BODIES
[FACT - d1.sql] The dump defines every procedure **twice**: an early **STUB** block (`create or replace procedure NAME as begin return; end`, ~~lines ~21883–24351~~ **[CORRECTED → lines 21611–26507]**; 1,225 stubbed) and a later **REAL** body block (`create or replace procedure NAME ( args ) = BEGIN ... END`, lines 27758–~~32790~~ **[CORRECTED → 32776]**). Of 2,450 `create or replace procedure` statements, 1,225 are stub forms and 1,225 carry real bodies. **The real bodies (later block) are authoritative.** Anyone grepping only the first hit per name gets `begin return; end` and wrongly concludes the logic is empty. All proc logic below is quoted from the REAL block.
> **[VERIFIED]** Counts exact: `grep -c 'create or replace procedure'` = **2,450**; inline-stub form (`... as begin return; end`) = **1,225**; real bodies = **1,225** (= 1,193 paren-arg-list procs **+ 32 no-arg real procs** that use `AS BEGIN`/`= BEGIN` with no parameter list, e.g. `DDB_LogEntry = BEGIN RAISE DBEVENT ... END` at line 28059, `TM$AlertUpdate = BEGIN RAISE DBEVENT TM_BogeyAlertCheck END` at 32457). The 1,225/1,225 split is correct. Only the cited stub-block **line range** was off (real range 21611–26507).

---

## 1. MODULE FAMILY ONE-LINERS (non-integration)

Application identity (ug.html:5093-5100 [FACT]): 5 switching apps use DBM — **FMS** (Distribution Feeders), **TOMS/SOA** (Substations=**SLC** + Transmission Feeders=**TFMS**), **TLS** (Telephone Lines; on FMS DB), **SMS** Steam Mgmt (standalone **SDS** DB), **DSO** = **Dielectric Switching Operations** (standalone DSO DB, separate `DSO_DBM` image).

> **[VERIFIED]** Every per-family table count in the table below was re-counted with `grep -icE '^create table PFX'` and matches exactly: cac_=24, tfms_=14, tfmsddb_=2, slc_=11, slcddb_=2, pvl_=10, fra_=10, dso_=3, rtu_=6, csd_=4, sds_=3, msg_=3, gta_=2, oa_=5, tm_=2, tv_=1, itc_=2, soo_=1, nwp_=1, cfg_=1, allapp_=1, xa21_=1, ddb_=6, qgis_=3, egis_=2.

| Family | #tbl | One-line purpose | Evidence |
|---|---|---|---|
| `cac_` | 24 | **Clearance Assurance / relay-operation control**: relay-op logs (`cac_relayops`,`cac_relayopscontrol`), clearance-order groupings (`cac_co_*` = "CO" cards w/ circuit/feeder/note/status/attachment), relay groupings (`cac_relay_*`), card↔type maps (`cac_cardtype`,`cac_relaytypes`), and **`cac_softwarelevel`** = release version gate (ug.html:6853 — app shuts down on version mismatch). | [FACT - d1.sql DDL; ug.html:5218,6853] **[VERIFIED - cac_softwarelevel(application varchar80, "level" varchar80); ug.html:6857 "If the software level values don't match the application will shut down."]** |
| `tfms_`/`tfmsddb_` | 14+2 | **Transmission Feeder Mgmt System** cards (`tfms_card`,`tfms_cardtoobject`,`tfms_operatingstep`,`tfms_opstepdetail`,`tfms_checklist`,`tfms_compromised`) + replication log pair. TOMS sub-app. | [FACT - d1.sql; ug.html:5094,6717] **[VERIFIED counts]** |
| `slc_`/`slcddb_` | 11+2 | **Substation Log Card** (`slc_card` w/ grounds, work-permit flags, station note) + **Information Items** (`slc_informationitem*`,`slc_itemcategory`) + equip templates/doc/wp-links + replication log pair. TOMS sub-app. | [FACT - d1.sql; ug.html:6660,11440] **[VERIFIED counts]** |
| `pvl_` | 10 | **External GIS feeder-data load/reconciliation** (xy + nf records) → builds Feeder Diagrams; `pvl_xreference` cross-refs pvl equip/manhole names → Udb Object IDs. **INTEGRATION** (see §4). | [FACT - d1.sql; ug.html:8746-8752] **[VERIFIED]** |
| `fra_` | 10 | **Field relay/cable acceptance test cards**: relay trip tests (`fra_relay` — 50/51/67/46 protection elements ×A/B/C/N phases), **hipot** cable insulation tests (`fra_hipot` — kV/duration/start-end mA), fault location (`fra_fault`), op-step timing, HV phases, + `*temp*` staging twins (field download). Feeder cutout/cutin RTS workflow. | [FACT - d1.sql DDL lines 5144-5544] **[VERIFIED - fra_relay cols rt5051a/b/c/n (50/51 o-c ×phase), rt67a/b/c/n (67 dir ×phase), rt46to (46 neg-seq); fra_hipot cols feederkv,testtypekv,duration,startma,endma — exact match]** |
| `dso_` | 3 | **NOT "Distribution System Operator".** = **Dielectric Switching Operations** QGIS geometry model: `dso_object` (per-diagram object+xy+symbol), `dso_connection` (line edges from/to), `dso_defaultrotation`. Parallel object store. **INTEGRATION** (see §4). | [FACT - ug.html:5097,8009-8021] **[VERIFIED]** |
| `rtu_` | 6 | **RTU/telecom circuit provisioning** for SCADA comms: circuit↔PVC mapping (`rtu_circuitmapping`), routers/TCP ports (`rtu_circuitrouter`), substation RTU counts (`rtu_substation`), provider, + RTU work-issue tracker (`rtu_workissue`/`rtu_workissuelog`). **INTEGRATION-adjacent** (see §4). | [FACT - d1.sql DDL] **[VERIFIED]** |
| `csd_` | 4 | **Console/desk messaging** (D.O. desk-to-desk): `csd_message` (text, desktype, priority), `csd_messagelink` (IP/node addressing + ack/clear), `csd_messagetype` (per desk IP enable), `csd_toecc` (route "to ECC"). | [FACT - d1.sql DDL 834-953] **[VERIFIED]** |
| `sds_` | 3 | **Steam/SMS "Sole authority" switching cards**: `sds_card` (msonumber, soleauthority, station, prepared/checked-by), `sds_cardmain` (mains), `sds_download` (DB-unload sync state). Standalone SDS DB. | [FACT - d1.sql 8042-8131; ug.html:5096] **[VERIFIED]** |
| `msg_` | 3 | **Inter-application substation message queue**: `msg_message` (substation/card, toapp/fromapp, ack/del, priority) + archive + lastkey. row_estimate≈5147. | [FACT - d1.sql 7170-7211] **[VERIFIED - msg_message row_estimate = 5147 at d1.sql:7199]** |
| `gta_` | 2 | **Alarm/note messaging** (`gta_message`: msgid, alarmtime, application, category, recurrence, desk, note) + archive (adds acktime/ackbyopname). | [FACT - d1.sql 5545-5610] **[VERIFIED]** |
| `oa_` | 5 | **Offline Archive card indexes** by `archiveyear` for FMS/SLC/TC/TFMS (`oa_*cardindex`) + `oa_archiveaccounting` (year/disk/location, sidea/sideb). `oa_fmscardindex` row_estimate≈213760 (large historical index). | [FACT - d1.sql 7262-7407] **[VERIFIED - oa_fmscardindex row_estimate = 213760 at d1.sql:7316]** |
| `tm_` | 2 | **Task Manager bogey (SLA) alerts**: `tm_bogeytype` (per-type/status thresholds bogeyalert/nextalert/resend + notify routing flags enablecsd/fod/dcc/cig/pgm), `tm_bogeyalert` (live alerts per card). | [FACT - d1.sql 13250-13330; ug.html:10669-10723] **[VERIFIED]** |
| `tv_` | 1 | **Temperature-Variable bogey history**: `tv_bogeyhistory` (logdate, actual/forecast/dayahead temp, tv_threshold, peakload). Drives TV-vs-regular bogey selection (>82°→TV). | [FACT - d1.sql 13332; ug.html:10678-10682] **[VERIFIED table; >82° threshold not re-read — UNKNOWN if exact]** |
| `itc_` | 2 | **ETC (Estimated Time of Completion/restoration) reporting**: `itc_eetccard` (per card/job/desk ETC), `itc_reportlogistics` (report frequency per app/division/user). | [FACT - d1.sql 7035-7100] **[VERIFIED]** |
| `soo_` | 1 | **SOA→SOO→remote comms-enable flags** per substation: `soo_communication`(substation, soa_to_soo, soo_to_remote). Electronic-order routing gate. | [FACT - d1.sql 11447; ug.html:12598-12606] **[VERIFIED table]** |
| `nwp_` | 1 | **Network Planner job-class allowlist**: `nwp_jobclass`(jobclass). row_estimate≈13. | [FACT - d1.sql 7240] **[VERIFIED table; module purpose remains INFERENCE — see §6]** |
| `cfg_` | 1 | **Config/group→line lookup**: `cfg_group`(cfg_name, line, linename, lastupdate). | [FACT - d1.sql 805] **[VERIFIED]** |
| `allapp_` | 1 | **Global cross-app system parameters**: `allapp_systemparameters` (etccheckingperiod, userautologout, recoverytimeout, outagemonitordelay, outagelatentperiod, softwareversioncheck, peakloadthreshold). 1 row. | [FACT - d1.sql 21] **[VERIFIED - ALLAPP_SystemParmsUpd proc (line 27758) updates exactly these cols + ConfirmWarning]** |
| `xa21_` | 1 | **SCADA/EMS outage feed**: `xa21_outagereport`. **INTEGRATION** (see §4). | [FACT - d1.sql 15174] **[VERIFIED]** |
| `ddb_` | 6 | **Distributed-DB / dual-target replication control plane.** **INTEGRATION** (see §4). | [FACT - d1.sql DDL+dbevents] **[VERIFIED 6 tables]** |
| `qgis_`/`egis_` | 3+2 | QGIS rendering symbols/locks/events; eGIS (Esri) structure cross-ref/load. **INTEGRATION** (see §4). | [FACT - d1.sql] **[VERIFIED]** |

---

## 2. INTEGRATION SURFACE INVENTORY

| External system | Bridging tables | Bridging procs / rules / dbevents | Direction | Confidence |
|---|---|---|---|---|
| **SCADA/EMS (XA/21 — GE/ABB EMS)** | `xa21_outagereport`; `soa_xa21exclusion` (type-exclusion list); `soa_xa21sequence` | `XA21_OutageReportIns` (pure INSERT); ug.html:5339 "FMS-XA21 interface"; equip-type exclusion UI | **EMS→PSM inbound** (outage device reports) + **PSM→EMS outbound** (breaker types pushed; see ug.html:5339-5385) | [FACT/INFERENCE] **[VERIFIED - all 3 tables exist; XA21_OutageReportIns proc exists; outbound = email to XA21 support staff, ug.html:5384, confirmed verbatim]** |
| **RTU / telecom infra** | `rtu_circuitmapping`,`rtu_circuitrouter`,`rtu_substation`,`rtu_circuitprovider`,`rtu_workissue(log)`; **writes `udb_TelephoneCircuit`** | `rtu_circuitupd` (UPDATEs `udb_TelephoneCircuit` ecc/acc FEP/channel/TCP-port/RAN); `RTU_WorkIssueIns/MsgUpd`; dbevents `tc_processingrtucircuit`,`tc_rtucircuitcomplete`,`tc_rtucircuitpermit` (TC module drives RTU circuit work) | **PSM-managed provisioning** of RTU comms; outbound to field telecom | [FACT - proc body 30637] **[VERIFIED - rtu_circuitupd real body at line 30637 UPDATEs udb_TelephoneCircuit]** |
| **Real-time telemetry/scan (analog/digital point ingest)** | `udb_telemetry` (min/max, xormask, deadband, in/out, address/size/offset, cable/panel/terminal), `udb_scanblock` (interval, startaddress, length, retries) | (config only in dump; runtime ingest is external EMS scanner) | **EMS→PSM inbound** point definitions/scan config | [INFERENCE — structure is classic SCADA point map; no ingest proc in dump] **[VERIFIED - both table DDLs exact; no ingest proc found, INFERENCE stands]** |
| **QGIS Diagram Editor (geo-schematic UI; TOMS+DSO)** | `dso_object`,`dso_connection`,`dso_defaultrotation`,`qgis_symbols`,`qgis_diagramlock`,`qgis_externalevent` | `QGIS_RTUpdNotification`→raises **dbevent `QGIS_RealTimeUpdate`** per locked computer; `QGIS_ExternalEventIns/Del`,`QGIS_DiagramLockUpd`,`QGIS_ActiveSwitchStatus`,`QGIS_ACLineSegVal`,`QGIS_SetOutage`,`DSO_CascadeType`; rules `QGIS_RealTimeUpdate`,`QGIS_ActiveSwitchUpd1-4`,`QGIS_ACLineSegVal1/2`,`DSO_SymbolSizeUpd` | **Bi-directional**: DB→UI push (event spool + dbevent) and UI→DB writes (object/connection edits) | [FACT - proc bodies 30556-30605, rules 33150-33164] **[VERIFIED - QGIS_RTUpdNotification (line 30593) does `RAISE DBEVENT "ingres". QGIS_RealTimeUpdate :ComputerName`; dbevent qgis_realtimeupdate exists; rules QGIS_RealTimeUpdate + DSO_SymbolSizeUpd exist]** |
| **eGIS (Esri ArcGIS)** | `egis_xreference` (egisStructure→object/feeder/xy), `egis_nfload` (network-feature load file) | `egis_xreferenceins` | **eGIS→PSM inbound** structure load + name cross-ref | [FACT - d1.sql; proc 28221] **[VERIFIED - egis_xreferenceins real body at line 28221; args eGisStructure/feeder/feedername/name/manhole/eGISxy/Pos_x]** |
| **pvl GIS feeder data** | `pvl_xreference`,`pvl_xy_add/del`,`pvl_xyload`,`pvl_nf_add/del`,`pvl_nfload`,`pvl_networkstoload`,`pvl_processdate`,`pvl_xref_exception` | `pvl_nfupdate_ins`,`pvl_xyupdate_ins`,`pvl_*_process`,`pvl_ReplaceObject`,`pvl_transferobj`,`pvl_XRefIns/Del/Upd`,`pvl_update_clear` | **pvl files→PSM inbound** daily diagram update (3-step load) | [FACT - ug.html:8746; procs 30502-30552] **[VERIFIED - pvl_XRefIns real body at line 30542; pvl_XRefDel at 30533. NOTE: cited-objects list named it `pvl_xreferenceins` — that exact name does NOT exist; the real proc is `pvl_XRefIns`. Minor misname, object family confirmed.]** |
| **Coordinate geometry stores** | `nodes_xy`(node→x,y,substation; ~19041 rows), `objects_xy`(object→x,y,rotation,substation,newobject) | (loaded; consumed by diagram render) | **inbound coord sync** to Udb node/object model | [FACT - d1.sql 7212; INFERENCE on consumer] **[VERIFIED - nodes_xy(node,x,y,substation) row_estimate=19041 at line 7227; objects_xy(object,x,y,rotation,substation,newobject) exact]** |
| **Distributed-DB replication (dual hot targets A/B)** | `ddb_application`(prefix→appname), `ddb_reptargetstatus`(status+desc), `ddb_status`(timemarker), `ddb_reconnectdelay`,`ddb_recoverytimeout`,`ddb_replicatorstopped`; per-module spool pairs `fmsddb_log/logobject`,`tcddb_*`,`slcddb_*`,`tfmsddb_*` | `DDB_LogEntry`→**raises dbevent `ddb_logentry`**; `DDB_RepStatusDescUpd`; dbevents `ddb_abouttoreconnect/commit_failure/disconnect/reconnect`; rules `FMSDDB_LogEntry`/`TCDDB_LogEntry`/`SLCDDB_LogEntry`/`TFMSDDB_LogEntry` (AFTER INSERT→`DDB_LogEntry`), `DDB_RepStatusUpd` | **PSM↔replica peer**, bidirectional sync/heartbeat | [FACT - DDL 992-1076, dbevents 26538-26566, rules 32806+] **[VERIFIED - DDB_LogEntry real body at 28059 = `RAISE DBEVENT "ingres". DDB_LogEntry`; dbevents ddb_logentry/abouttoreconnect/commit_failure/disconnect/reconnect all exist; rules FMSDDB/TCDDB/SLCDDB/TFMSDDB_LogEntry + DDB_RepStatusUpd all exist; 8 module log tables (4 pairs) exist]** |
| **Task-Monitor alert push (intra-app integration)** | `tm_bogeyalert`,`tm_bogeytype` (notify flags) | dbevent `tm_bogeyalertupd`; rules `TM$FODOrderStatusUpd`/`TM$OpOrderStatusUpd`/`TM$WPStatusUpd`→`TM$AlertUpdate` (fire off IR order/permit status change) | DB→Task Monitor service | [FACT - rules 33362-33366] **[CORRECTED - rules verified at 33362/33364/33366 firing PROCEDURE TM$AlertUpdate (line 32457), which raises dbevent `TM_BogeyAlertCheck`, NOT `tm_bogeyalertupd`. Both dbevents `tm_bogeyalertcheck`(27684) and `tm_bogeyalertupd`(27690) exist, but the rule→proc chain raises *check*, not *upd*.]** |
| **IR field-order dispatch (Rapid Restore)** | (FMS/IR tables) | dbevent `ir_foddbevent` raised w/ RRMsgID controltext (proc near 29982) | DB→IR/RapidRestore | [FACT - line 29982; ug.html:12595] **[VERIFIED - dbevent ir_foddbevent exists]** |

---

## 3. DEEP-READ: KEY INTEGRATION TABLE DDL

### 3.1 dso_object — QGIS geometry model (parallel object store)
[FACT - d1.sql] PK/index `btree unique`. Per-diagram (`pocket`) projection of `Udb_Object`:
```
object int, type int, typename, name, pocket int, pocketname,
structuretype/obj/name, activetype int, activetypename, symbolcolor,
pos_x float, pos_y float, rotation int, symbolsize float,
label_size/x/y, bus_llx/lly/urx/ury
```
> **[VERIFIED]** Full DDL confirmed: `object,type,typename,name,pocket,pocketname,structuretype,structuretypename,structureobj,structurename,activetype,activetypename,symbolcolor,pos_x,pos_y,rotation,symbolsize,label_size,label_x,label_y,bus_llx,bus_lly,bus_urx,bus_ury`. All 24 columns present; shorthand above is accurate.

**Is dso_object a second object model? YES — confirmed.** ug.html:8009-8021 [FACT]: "The QGIS Diagram Editor connected data model is **different from the Udb Object, Terminal, Node model**. It models 'Lines' using two tables DSO_Object and DSO_Connection." An object appears once **per pocket (diagram)** — PK is effectively (object,pocket) per proc WHERE clauses. `DSO_CascadeType` reads `Name` from `Udb_Object` and resolves `ActiveType`/symbol by walking `Udb_SuperType` up the type tree against `QGIS_Symbols` → writes denormalized display attrs into `dso_object`. So dso_object is a **derived/denormalized render cache of Udb_Object**, NOT an independent authority. The "DSO" prefix = **Dielectric Switching Operations** app, which (with TOMS) uses this QGIS model; it is NOT "Distribution System Operator". [FACT - ug.html:5097, 6929-6930, 8009]
> **[VERIFIED - DSO_CascadeType real body @ line ~28xx]** Confirmed: reads `Name` from `Udb_Object`; `WHILE ShapeExists IS NULL AND Type > 17` walks `Udb_SuperType` against `QGIS_Symbols`; defaults `ShapeType = IFNULL(ShapeExists,17055)`; updates `DSO_Object SET TypeName,Name,ActiveType,ActiveTypeName,SymbolSize WHERE Object=:Object AND Pocket=:Pocket` → (object,pocket) keying and denormalized-render-cache claim both correct. (Type-floor literal `17` and default-symbol literal `17055` are hard-coded in the body; their semantics still depend on absent seed tables — see §6.)

### 3.2 dso_connection — graph edges
```
oid int, fromobj int, toobj int, outflowside int, pipetype int,
pipetypename, linecolor, connectionlength float
```
> **[VERIFIED]** DDL exact: `oid,fromobj,toobj,outflowside,pipetype,pipetypename,linecolor,connectionlength`.

[FACT - ug.html:8015-8021] from/to have **no directional significance**. `DSO_ConnectionIns` auto-assigns `oid` from `Udb_LastKey 'ConnectionOID'`, dedups on (from,to)/(to,from), infers pipetype from neighbors (annotation type 17056→17090 else 17083). `QGIS_ACLineSegVal` flags AC-line-segments (Type=22) with <2 connections by coloring them `255,20,147,255` (deep-pink dangling-end indicator). [FACT - proc 30556]
> **[VERIFIED - DSO_ConnectionIns real body lines 28088-28100]** Exact: dedup `WHERE FromObj=:Obj1 AND ToObj=:Obj2` then `FromObj=:Obj2 AND ToObj=:Obj1`; pipetype inference `SELECT :Annotation = Type FROM DSO_Object WHERE Object IN (:Obj1,:Obj2) AND Type = 17056; IF Annotation <> 0 THEN Pipe = 17090; ELSE Pipe = 17083`; OID via `UPDATE Udb_LastKey SET Value=Value+1 WHERE LastKey='ConnectionOID'`. All three claims literally correct.
> **[VERIFIED + minor nuance - QGIS_ACLineSegVal real body]** Exact: `WHERE ... Type = 22`; counts `DSO_Connection WHERE FromObj=:ACL OR ToObj=:ACL`; `IF ACLCount <> 2 AND ACLColor='' THEN ... SymbolColor = '255,20,147,255'` (and clears to `''` when `ACLCount = 2`). **Nuance:** the trigger is `ACLCount <> 2` (NOT exactly two connections — covers 0,1,3+), the prose "<2 connections" is slightly narrow; deep-pink color literal `255,20,147,255` is correct.

### 3.3 xa21_outagereport — EMS outage feed
```
outagerecorded ingresdate, outagetype varchar(24), outageobject int,
substation int, equip int, devicetime ingresdate
```
> **[VERIFIED]** DDL exact: `outagerecorded ingresdate, outagetype varchar(24), outageobject int, substation int, equip int, devicetime ingresdate`.

[FACT] `XA21_OutageReportIns` = bare INSERT (no transform). `soa_xa21exclusion(type int)` = equipment types excluded from XA21 interface (ug.html:3100,5337). ug.html:5339-5385 [FACT]: "FMS-XA21 interface provides XA21 system the capability to [process feeder] changes. The types of breakers that XA21 sends should be Source, Source-SBFKS,…"; new excluded types trigger an **email to XA21 support staff** to configure manually → so the bridge is partly manual/email, not fully automatic.
> **[VERIFIED - ug.html:5339,5384]** Quotes confirmed verbatim incl. "the DBM sends an email with the breaker information to the XA21 support staff in order for them to set it up in the XA21 system." Partly-manual conclusion stands.

### 3.4 udb_telemetry / udb_scanblock — SCADA point map
```
udb_telemetry: object, telemetryminimum/maximum, xormask, deadband,
  input, output, address, size, offset, powercable/returncable/groundcable/
  terminationcable, panel, terminalblock
udb_scanblock: object, interval, startaddress, length, retries
```
> **[VERIFIED]** Both DDLs exact (cables are `char(20)`, all numerics `integer`).

[INFERENCE] Classic RTU/EMS point definition + scan-block polling config. No ingest procedure present in dump → runtime telemetry ingest is an **external EMS/scanner process**; these tables are configuration only. The cable/panel/terminalblock columns = physical wiring documentation.

### 3.5 ddb_* replication control + *ddb_log spool
```
ddb_application(prefix char5, applicationname)   -- prefix→app registry
ddb_reptargetstatus(status int, description)      -- 0=Normal,10=DDB recovery incomplete,20=Ingres repl incomplete
ddb_status(rowkey, timemarker)                    -- heartbeat marker
ddb_reconnectdelay / ddb_recoverytimeout / ddb_replicatorstopped
fmsddb_log(transaction_time, transaction_dbhandle varchar76, string_id)
fmsddb_logobject(string_id, row_sequence, text_total, text_value varchar1786)  -- chunked payload
```
> **[VERIFIED]** DDL exact: `ddb_application(prefix char5, applicationname varchar48)`; `ddb_reptargetstatus(status int, description varchar(80))`; `ddb_status(rowkey int, timemarker ingresdate)`; `fmsddb_log(transaction_time ingresdate, transaction_dbhandle varchar(76), string_id int)`; `fmsddb_logobject(string_id, row_sequence, text_total, text_value varchar(1786))`. The 0/10/20 status codes are NOT seed rows in DDL — they are hard-coded in proc `DDB_RepStatusDescUpd` (see below).

[FACT - proc 28063 **[CORRECTED → real body @ line 27973]**] `DDB_RepStatusDescUpd(Status)`: maps 0/10/20 → human descriptions ("the **other target** database is …"), else RAISE ERROR. → **dual-target (A/B) replication topology** confirmed. [FACT - proc] `DDB_LogEntry = RAISE DBEVENT ddb_logentry` (fired by `*DDB_LogEntry` rules AFTER INSERT into each module's `*ddb_log`). **Mechanism**: app writes a row into `<module>ddb_log` + chunked text into `<module>ddb_logobject`; INSERT rule raises `ddb_logentry`; an external **replicator daemon** registered on `ddb_logentry`/`ddb_reconnect`/`ddb_commit_failure`/`ddb_disconnect`/`ddb_abouttoreconnect` ships the spooled SQL text to the peer DB. This is a **home-grown statement-shipping replication layer** layered on top of (and complementary to — note status 20 "Ingres Replication is Incomplete") native **Ingres Replicator**. [INFERENCE on daemon — daemon binary not in artifacts]
> **[VERIFIED - DDB_RepStatusDescUpd real body]** Exact text: `Status=0 → 'Normal - The other target database is Normal'`; `=10 → 'DDB Recovery is Incomplete - The other target database is Not Current'`; `=20 → 'Ingres Replication is Incomplete - The other target database is Not Current'`; `ELSE ... RAISE ERROR -1`. Dual-target topology + coexistence-with-Ingres-Replicator inference both confirmed. (Cited line "28063" is off; actual ~27973 — immaterial.)

---

## 4. SYNC-DIRECTION MERMAID

```mermaid
flowchart LR
  subgraph EXT[External systems]
    XA21[XA/21 EMS-SCADA]
    EMS_SCAN[EMS point scanner]
    QGIS[QGIS Diagram Editor UI]
    EGIS[eGIS / Esri ArcGIS]
    PVLF[pvl feeder GIS files]
    PEER[(Replica DB target A/B)]
    FIELD[RTU / field telecom]
    IRRR[IR Rapid Restore]
  end
  subgraph PSM[PSM Ingres DB]
    XAtab[xa21_outagereport / soa_xa21exclusion]
    TEL[udb_telemetry / udb_scanblock]
    DSO[dso_object / dso_connection]
    QSYM[qgis_symbols / qgis_externalevent / qgis_diagramlock]
    EGX[egis_xreference / egis_nfload]
    PVL[pvl_xreference / pvl_xy* / pvl_nf*]
    DDB[*ddb_log / *ddb_logobject / ddb_*]
    RTU[rtu_* / udb_TelephoneCircuit]
    UDBO[Udb_Object terminal-node model]
  end
  XA21 -- outage device reports --> XAtab
  XAtab -. breaker types + email .-> XA21
  EMS_SCAN -- point/scan config defs --> TEL
  QGIS <-- edits + UPDATEOBJECT events + dbevent QGIS_RealTimeUpdate --> DSO
  QGIS <--> QSYM
  EGIS -- structure load --> EGX
  PVLF -- daily 3-step load --> PVL
  PVL -- xref names --> UDBO
  DSO -. derived render cache .- UDBO
  DDB <-- statement-ship + heartbeat --> PEER
  RTU -- provisioning --> FIELD
  PSM -- ir_foddbevent --> IRRR
```

---

## 5. CONTRADICTIONS / CORRECTIONS TO TASK BRIEF
1. **`dso_object` is NOT "Distribution System Operator view".** [FACT - ug.html:5097] DSO = **Dielectric Switching Operations**, a standalone switching application (steam/dielectric-cable ops) with its own `DSO_DBM` image. `dso_object`/`dso_connection` are the **QGIS connected-geometry model** shared by TOMS and DSO, a derived projection of `Udb_Object` keyed per diagram (pocket). **[VERIFIED]**
2. **The "ddb" families are a custom statement-shipping replication/spool layer**, confirmed — and they coexist with native Ingres Replicator (status code 20 = "Ingres Replication is Incomplete"), i.e. **two replication mechanisms**, not one. [FACT - proc 28063 **[CORRECTED → ~27973]**] **[VERIFIED]**
3. **XA21 bridge is partly manual** (email to support staff for new equip types) — not a clean automatic EMS sync. [FACT - ug.html:5384] **[VERIFIED]**
4. **Procedure bodies are doubly-defined** (stub + real); naive single-grep yields false "empty logic". [FACT] **[VERIFIED - 1,225 stub + 1,225 real of 2,450 total]**

## 6. GAPS / UNKNOWNS
- All `type`/`status`/`pipetype`/`activetype` integer codes (e.g. 22=ACLineSeg, 10016/12201/20542 switch-status, 17055/17056/17083/17090 pipe/annotation, 22585 obsolete-person, 17 type-floor) are **referenced in proc logic** but their full enumerations live in absent seed tables → enumerations [UNKNOWN]; only the specific literals hard-coded in procs are known. **[VERIFIED — literals 22, 17056, 17090, 17083, 17055, 10016, 12201, 20542, and type-floor 17 all confirmed present in proc bodies (QGIS_ACLineSegVal, QGIS_ActiveSwitchStatus, DSO_ConnectionIns, DSO_CascadeType); their seed enumerations remain UNKNOWN. Note 20030/22095 (ActiveType excludes in QGIS_ActiveSwitchStatus) are additional literals not previously listed.]**
- No runtime **telemetry-ingest** or **ddb-replicator daemon** code in artifacts (external binaries) → ingest/ship logic [UNKNOWN beyond the DB-side trigger surface]. **[VERIFIED — no ingest/daemon proc found]**
- `nwp_` (Network Planner) has only `nwp_jobclass`; full NWP module logic not represented here → purpose [INFERENCE from name + ug context only]. **[VERIFIED]**
- Exact PK column lists per table not all enumerated above (read `modify <t> to ...` for each if needed); confirmed unique btree/hash on the integration tables in §1/§3. **[NOT re-verified per-table — residual UNKNOWN stands]**
- Row counts: NONE authoritative (no data); `row_estimate` cited only as relative scale. **[VERIFIED — row_estimate is a COPY-statement `with` hint; 19041/213760/5147 figures confirmed at d1.sql:7227/7316/7199]**

---

## Verification

**Verifier:** adversarial SME pass, 2026-06-12. Method: grep/awk existence checks against `d1.sql`; targeted Read of real-body proc/DDL/rule/dbevent text and `ug.html` line ranges. The files were not read whole.

### Confirmed (no change)
- **Object existence: 90/90 cited tables EXIST** (`^create table <t>(`), 0 fabricated. **16/16 cited procs EXIST** with real bodies (paren-arg or no-arg `=BEGIN`/`AS BEGIN` form), with one name caveat (see below).
- **Module table counts** (§1): all 25 prefixes re-counted, exact match.
- **DDL column lists** (§3.1–3.5): `dso_object` (24 cols), `dso_connection` (8), `xa21_outagereport` (6), `udb_telemetry` (16), `udb_scanblock` (5), `ddb_application/ddb_reptargetstatus/ddb_status`, `fmsddb_log/logobject`, `nodes_xy`, `objects_xy`, `fra_relay`, `fra_hipot`, `cac_softwarelevel` — all verified exact.
- **Proc behavior, read from real bodies:** `DSO_ConnectionIns` (dedup + 17056→17090/else→17083 pipetype + `Udb_LastKey 'ConnectionOID'`); `QGIS_ACLineSegVal` (Type=22, color `255,20,147,255`); `DSO_CascadeType` (Udb_SuperType walk, default 17055, (object,pocket) update); `DDB_RepStatusDescUpd` (0/10/20 → "other target database…" text, else RAISE ERROR); `DDB_LogEntry`=RAISE DBEVENT; `QGIS_RTUpdNotification`=RAISE DBEVENT QGIS_RealTimeUpdate per ComputerName; `rtu_circuitupd` UPDATEs `udb_TelephoneCircuit`; `egis_xreferenceins` / `pvl_XRefIns` arg signatures.
- **dbevents/rules:** ddb_logentry, ddb_abouttoreconnect, ddb_commit_failure, ddb_disconnect, ddb_reconnect, ir_foddbevent, qgis_realtimeupdate, tm_bogeyalertcheck, tm_bogeyalertupd all exist; rules FMSDDB/TCDDB/SLCDDB/TFMSDDB_LogEntry, DDB_RepStatusUpd, QGIS_RealTimeUpdate, DSO_SymbolSizeUpd, TM$FODOrderStatusUpd/OpOrderStatusUpd/WPStatusUpd (33362/33364/33366) all exist.
- **ug.html semantics:** cac_softwarelevel version-shutdown (6857), XA21 outbound email to support staff (5384) — verbatim confirmed.
- **Structural note core claim** (§0): 2,450 procs = 1,225 stub + 1,225 real (verified, including the 32 no-arg real procs that a paren-only grep misses).
- **row_estimate** framing: confirmed a `with`-clause on `COPY` (loader sizing hint), figures 19041/213760/5147 confirmed; non-authoritative disclaimer valid.

### Corrected (inline, marked `[CORRECTED]`)
1. **§0 stub-block line range:** "~21883–24351" → **actual inline-stub procs span 21611–26507**; real-body block end "32790" → **32776**. Counts unaffected.
2. **§2 Task-Monitor row:** rules → `TM$AlertUpdate` (proc @ 32457) raise dbevent **`TM_BogeyAlertCheck`**, not `tm_bogeyalertupd` as the row implied. Both dbevents exist, so not a fabrication — a wrong event-name attribution on the rule→proc chain.
3. **§3.5 / §5.2 line citation:** `DDB_RepStatusDescUpd` real body is at **~27973**, not "28063". Immaterial to substance.
4. **§3.2 nuance (annotated, not a hard error):** `QGIS_ACLineSegVal` fires on `ACLCount <> 2` (not strictly "<2"). Prose tightened.

### Name caveat (not a fabrication)
- The cited-objects list contains **`pvl_xreferenceins`** — that exact procedure name does NOT exist. The real procedure is **`pvl_XRefIns`** (real body @ line 30542); the §2 body text already used the correct `pvl_XRefIns/Del/Upd`. Treated as a typo in the object list, family confirmed.

### Residual UNKNOWNs (unchanged from §6)
- Full enumerations of all integer type/status/pipetype/activetype codes (seed tables absent). Additional literals surfaced during verification: `20030`, `22095` (ActiveType excludes in `QGIS_ActiveSwitchStatus`).
- Runtime telemetry-ingest and ddb-replicator daemon logic (external binaries; not in artifacts).
- `nwp_` module purpose (INFERENCE only; single table present).
- Exhaustive per-table PK/index column lists (not all enumerated; integration tables spot-confirmed).
- No authoritative row counts (no data loaded).

**Verdict: CLEAN with minor corrections.** No fabricated objects. All load-bearing proc/DDL claims hold against the artifacts. Four citation/range/event-name corrections applied inline; substance of the analysis is sound.
