# SOA — Switching Order Application (subsystem analysis)

> **VERIFIED COPY** — Adversarially re-checked against `d:/103_RnD/psm_v1/d1.sql` on 2026-06-12. All 84 cited objects confirmed to exist. Inline corrections are marked **[VERIFIER CORRECTION]**. See `## Verification` footer for the full ledger. Unmarked content was confirmed correct and is preserved verbatim.

Source of truth: `d:/103_RnD/psm_v1/d1.sql` (Ingres DDL/dump). Secondary: `ug.html` (business semantics). All claims tagged.

> **CRITICAL CORRECTION TO GROUND TRUTH** — `[FACT - d1.sql]` d1.sql contains **two** procedure populations:
> 1. Lines ~1–27757: **stub** procs of the form `create or replace procedure NAME as begin return; end`. **All 240 lowercase `soa_*` procs here are empty stubs.** (`grep -cE '^create or replace procedure soa_[a-z0-9_]* as begin return; end'` = 240 of 240.) `[FACT - VERIFIED: 240]`
> 2. Lines 27758–~32500: the **real** procs, form `create or replace procedure  NAME ( args )= BEGIN ... END` followed by `\p\g`. The 240 real `SOA_*` bodies live here (line 30794 `SOA_ActivateSwitchItem` onward). `[FACT - VERIFIED: 240 body-form `SOA_` procs]`
> Total file: 2,450 `create or replace procedure` lines, of which **1,163 are stubs (47%)**. `[FACT - VERIFIED: 2,450 total / 1,163 stubs]` `[INFERENCE]` The stub block is a forward-declaration / signature catalog; the second block is the actual `create or replace` that supplies bodies. Always read the **second** occurrence (NR>27757) for logic. The dbproc count of "2,450" double-counts: there are ~1,287 distinct procs (2,450 − 1,163), each declared as stub then defined with a body. **[VERIFIER CORRECTION: distinct ≈ 1,287, not the "~1,225" originally stated — 2450−1163=1287. Minor; both are ≈half of 2,450 and the headline point stands.]**

---

## 1. Table catalog — 86 SOA tables `[FACT - d1.sql grep '^create table soa_' = 86, VERIFIED]`

| Table | Cols | Storage/PK `[FACT - modify]` | Role |
|---|---|---|---|
| soa_job | 31 | btree unique on **job** | **Central switching-order line / "move".** One row per TO+RS move pair. |
| soa_jobcontrol | 8 | btree unique on **card,job,switchingitem** | Links job→card; sequence/step/printid. |
| soa_job_to_soo | 4 | **[VERIFIER CORRECTION]** btree unique on **job,seq,ordernumber** (NOT a heap — modify exists @ d1.sql:10168) | Bridge job → operating order (`to_or_rs`, `ordernumber`). |
| soa_joblastkey | 2 | — | Key generator (rowkey,value) for job IDs. |
| soa_archivejob | 29 | btree unique on **card,seq,job,switchingitem** | Archived (closed) jobs; one of 35 archive twins. |
| soa_busfaultoutage | **67** **[VERIFIER CORRECTION: 67, not 73]** | btree unique on **switchingitem** | **Largest table in DB** (verified: widest at 67 cols; next is fms_sesamelockcard at 65). Bus-fault / auto-outage data capture. |
| soa_busfaultfeeder | — | — | Feeders affected by a bus fault. |
| soa_busfaultcorrelationmatrix | — | — | Rules matrix correlating relay targets → fault action. |
| soa_inservicepermit | 33 | hash unique on **ispermit** | In-Service (Work) Permit header. |
| soa_ispermitrequest | 37 | hash unique on **ispermit** | ISWP **request** form (work details, hazards). |
| soa_ispjob | 10 | — | ISP TO-issue / RS-complete operator+time. |
| soa_ispcondition | 8 | — | Conditions tied to permit jobs. |
| soa_isprestriction / ...item | 9 / — | — | Standing equipment restrictions. |
| soa_isplog / soa_ispattachment / soa_ispbinaryfile | — | — | ISP audit log; file attachments. |
| soa_ispwithdrawevent / ...permit | — | — | Permit withdrawal events. |
| soa_ispjob, soa_ispwithdrawpermit ... | | | |
| soa_outagerequest | **21** **[VERIFIER CORRECTION: 21, not 22]** | btree unique on **ornumber** | Planned outage request (OSS import). |
| soa_outagerequestpermit | 4 | — | OR → permit job link. |
| soa_orworkitem / soa_orbinaryfile / soa_orlog / soa_ordelay / soa_orneverlinked / soa_pendingordelay | — | — | OR sub-entities. |
| soa_workpermit | 17 | hash unique on **permitjobid** | SLC work-permit detail. |
| soa_card / soa_cardcontrol / soa_cardlog / soa_cardlastkey... | — | btree on card | Switching **card** (the order container/desk). |
| soa_activecard / soa_activeobject / soa_activity | **9**/3/11 **[VERIFIER CORRECTION: activecard=9, not 11]** | activeobject btree unique on **object,card** | Active-list materialization (broadcast to clients). |
| soa_scenarioequip / soa_scenariohistory / soa_scenariohistoryjobs | 4/5/5 | — | "What-if" switching scenarios; saved sequences. |
| soa_outageequiptype / soa_cfgequiptype / soa_iswpequiptype / soa_xa21exclusion / soa_typeexclusion | 1 each | — | **Type-filter config tables** (single `type integer` col; list of udb types eligible for outage/cfg/ISWP). |
| soa_connectivityprobequip / soa_connectivityproblem / soa_connectivitylog | 3/—/— | — | Connectivity-problem incidents. |
| soa_hipottestequip / soa_hipothistory / soa_hipottestcriteria | 5/—/— | — | Hi-pot test records. |
| soa_ammetercleartest / soa_groundterminal / soa_visiblebreakcheck / soa_vbcheckdoubleside / soa_vbchecksingleside / soa_returnphasetypes | — | — | Field test / safety checks. |
| soa_warning* (7 tables) | — | — | Warning / override / backout subsystem. |
| soa_voltagereduction / soa_substation / soa_substationtransformer / soa_networkbus | — | — | Equipment/operational refs. |
| soa_dologin / soa_doactivity / soa_to_fms_userxref / soa_hudstationxref / soa_reportmanager / soa_rptdistributor | — | — | DO session, user xref, report distribution. |
| soa_incidentreport / soa_incidentreportlink | — | — | Incident reports. |
| soa_fmsslclink / soa_electronicorderexcl / soa_endeenspecial / soa_schd_work_gap / soa_schd_work_rpt / soa_xa21sequence / soa_xa21exclusion | — | — | Cross-module links / config. |
| soa_archive* (cardlog, isolink, job, log, outage, workpermit) | — | — | Archive twins. |
| soa_outageisolink / soa_outagesummary / soa_outagerequest... | — | — | Outage isolation/summary. |

`[UNKNOWN]` Full column lists for tables not deep-read above; row data absent (all tables `copy ... from '/home/ingres/Downloads/<t>.ingres'`, files not present) so no seed enumerations, type lists, or counts.

---

## 2. What is a "job" — the switching-order data model

`[FACT - d1.sql soa_job DDL, VERIFIED]` `soa_job` is the atomic unit. PK = `job` (integer, from `soa_joblastkey`). It is **not** "one switching order" — it is **one switching move/line** carrying a paired Take-Out (TO) and Restore (RS) instruction. **[VERIFIER NOTE: actual DDL column list below, corrected from the analyst's paraphrase. `soa_job` has 31 cols. There is NO `jobclassname` column on soa_job (jobclass is integer only); there IS a `basekey integer` column the analyst omitted; `equipclassname` IS present.]**

```
-- VERIFIED soa_job DDL (31 cols, d1.sql):
job integer not null                      -- PK (btree unique on job)
jobclass integer not null                 -- working-group / class (joins IR_WorkingGroup)
status char(3) not null default ' '       -- TEXT status: ' ', 'NIS', 'Hid' (see §4)
equip integer not null
equipname varchar(40)
equipclass integer
equipclassname varchar(40)
grounds integer                           -- nullable (ground set ref)
movetype char(4) default ' '              -- 'Dead','229B','229C',... (operation code, proven in SOA_JobColor)
tomove varchar(160)                       -- Take-Out instruction text   } the two
tomoverules integer / tooperator integer / toissued ingresdate / tocomplete ingresdate
groundon ingresdate
response varchar(40) default ' '          -- 'Active','Purge', free-text
rsmove varchar(160)                       -- Restore instruction text     } switching move
rsmoverules integer / rsoperator integer / rsissued ingresdate / rscomplete ingresdate
activityidentifier char(1) default ' '    -- 'S' = shared move [FACT - SOA_JobControlIns sets ActivityIdentifier='S' @ ~31428]
controlcard integer
basekey integer                           -- [VERIFIER ADD: present in DDL, omitted by analyst]
switemstatus integer default 0            -- NUMERIC lifecycle status (see §4)
substation integer / deskname varchar(10)
movecategory integer default 0            -- 0=normal,1,2,3=SLC,4,5,6=ISP (see §3)
shadowlink integer / movefgcolor integer / movebgcolor integer  -- UI display
```

`[FACT]` The **switching order container** is the **card** (`soa_card`), not the job. `soa_jobcontrol(card,job,switchingitem)` attaches jobs to a card in `steppair`/`steplevel`/`seq` order; `printid` selects which printout. A card = an ordered list of jobs = the printable switching order. `[FACT - SOA_DetermineSequence, SOA_ControlResequence VERIFIED]` sequencing of steps is server-driven: rule **`SOA_DetermineSequence`** (AFTER INSERT INTO SOA_JobControl WHERE New.Seq=0, d1.sql:33214) → proc `SOA_DetermineSequence`; rule **`SOA_ControlResequence`** (AFTER UPDATE(Seq) ON SOA_JobControl WHERE New.Seq<>0 AND Old.Seq=0, d1.sql:33212) → proc `SOA_ControlResequence`. **[VERIFIER NOTE: both names are simultaneously a proc AND a same-named rule; confirmed.]**

`[FACT - soa_job DDL, VERIFIED]` **soa_job has TWO status columns:**
- `status char(3)` — text move-status: observed values `' '`, `'NIS'` (not-in-service), `'Hid'` (hidden). Used in WHERE `Status IN ('','NIS')` for active jobs `[FACT - SOA_JobControlIns, VERIFIED]`.
- `switemstatus integer` — numeric **switching-item lifecycle** status (the real state machine, §4).

---

## 3. movecategory — distinguishes order TYPES `[FACT - SOA_JobColor, SOA_CloseSwitchItem, SLC rules — ALL VERIFIED]`

| movecategory | Meaning (evidence) |
|---|---|
| 0 | Normal move `[FACT - default 0 in soa_job DDL; SOA_ItemIns/SOA_JobColor]` |
| 1 | special (UI FgColor=8) `[FACT - SOA_JobColor: IF MoveCategory=1 THEN MoveFgColor=8, VERIFIED]` |
| 2,3 | **SLC** items — `SLC_NewItemActivated` fires when `Movecategory IN (2,3)`; `SLC_ArchiveItem`/`SLC_PurgeItem` on `(2,3,6)` `[FACT - rules d1.sql:33172/33178/33180, VERIFIED]` |
| 4,5 | substation-rated moves (kV-color-coded) `[FACT - SOA_JobColor: MoveCategory=4 OR 5 → kV bg color, VERIFIED]` |
| 6 | **In-Service Permit** move — `SOA_CloseSwitchItem` checks `MoveCategory = 6` to un-hide child jobs `[FACT - VERIFIED]`; also in SLC archive/purge set `(2,3,6)` |

`[INFERENCE]` movecategory is the discriminator separating planned switching (0/1/4/5), SLC long-term clearances (2/3), and ISP-driven moves (6). Exact full enum is `[UNKNOWN]` (seed rows absent), but the above six values are proven by code.

---

## 4. The switching-order STATE SET

### 4a. soa_job.switemstatus (numeric move/item lifecycle) `[INFERENCE - enum values from proc/rule code; labels inferred]`

| switemstatus | Inferred state | Evidence |
|---|---|---|
| `<20` (e.g. 0/10) | **Created / inactive** (drafted, not yet activated) | default 0; rules treat `<20` as not-active |
| `= 20` | **Active / activated** | `SLC_NewItemActivated` fires `New.Switemstatus=20` `[FACT rule d1.sql:33178, VERIFIED]`; `SOA_ActivateSwitchItem` sets `SWItemStatus=:ActiveStatus` + `Response='Active'` `[FACT - VERIFIED]`; queries gate active on `SwItemStatus >= 20 AND < 50` `[FACT - SOA_JobControlIns, VERIFIED]` |
| `>=20 AND <50` | **Active range** (in progress) | repeated guard in joins `[FACT - VERIFIED]` |
| `>=50` | **Closed / complete** | `SLC_ItemClosed` fires `New.Switemstatus>=50 AND Old<50` `[FACT rule d1.sql:33176, VERIFIED]`; `SOA_CloseSwitchItem` sets `:ClosureStatus` `[FACT - VERIFIED]` |

`[FACT]` State transitions are driven by procs, NOT free SQL `[ALL VERIFIED against proc bodies]`:
- **Activate:** `SOA_ActivateSwitchItem(SwitchingItem,ActivationTime,ActiveStatus)` → `UPDATE SOA_Job SET TOIssued=:ActivationTime, Response='Active', SWItemStatus=:ActiveStatus WHERE Job=:SwitchingItem` then cascades same status to all child jobs via SOA_JobControl. `[FACT - body read, VERIFIED]`
- **Close:** `SOA_CloseSwitchItem(SwitchingItem,ClosureTime,ClosureStatus,ClosureRemark)` → if `ClosureRemark='Purge'` sets `Response=:ClosureRemark` (= 'Purge'), else `Response=:ClosureRemark, RSComplete=:ClosureTime`; sets `SWItemStatus=:ClosureStatus`; if the item is an ISP (`MoveCategory=6`) un-hides child jobs (`Status='Hid'`→`'   '`). `[FACT - body read, VERIFIED]` **[VERIFIER NOTE: original said "sets Response='Purge'" — exact code is `Response=:ClosureRemark`, which equals 'Purge' on that branch. Same effect; phrasing tightened.]**

### 4b. soa_job.status char(3) (move text status) `[FACT - VERIFIED]`
Observed literals: `' '` (normal/in-service-eligible), `'NIS'` (not in service), `'Hid'` (hidden — used to suppress ISP child jobs). `[FACT - WHERE Status IN ('','NIS') in SOA_JobControlIns; SOA_ISPArchive sets J.Status='Hid' WHERE P.Status IN (60,65), VERIFIED]`

### 4c. Per-move TO/RS micro-states `[FACT - SOA_IssueMove/SOA_CompleteMove, VERIFIED]`
A move advances by **issuing** then **completing** each half:
- `SOA_IssueMove(Job,Status,Issued,Operator)`: `Status='TO'`→set `TOIssued/TOOperator`; `'RS'`→set `RSIssued/RSOperator`. (`Status VARCHAR(3)`; else `message 'Unknown action requested.'`)
- `SOA_CompleteMove(Job,Status,Complete)`: `'TO'`→`TOComplete`; `'RS'`→`RSComplete`.

> Excerpt `[FACT - VERIFIED verbatim]`:
> ```
> SOA_IssueMove ( Job INTEGER NOT NULL, Status VARCHAR(3) NOT NULL, Issued DATE, Operator INTEGER ) = BEGIN
>   IF Status = 'TO' THEN UPDATE SOA_Job J SET TOIssued=:Issued, TOOperator=:Operator WHERE J.Job=:Job;
>   ELSEIF Status = 'RS' THEN UPDATE SOA_Job J SET RSIssued=:Issued, RSOperator=:Operator WHERE J.Job=:Job;
>   ELSE message 'Procedure SOA_IssueMove:: Unknown action requested.' ENDIF; ...
> ```

`[INFERENCE]` Move lifecycle: **drafted → TO issued → TO complete → (work) → RS issued → RS complete**. The four nullable ingresdate columns (`toissued,tocomplete,rsissued,rscomplete`) ARE the per-move state — null = not-yet, non-null = done. Confirmed by `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` rules firing `IR_FMSJobUpdate` on each of these columns `[FACT - rules d1.sql:33097-33103, VERIFIED]`. **[VERIFIER CORRECTION: original §4c/§9 said "7 SOA_JobUpdate$1..9 rules firing soa_jobupdated". The TO/RS-timestamp rules that were actually read are the four IR_FMSJob* rules above. SOA_JobUpdate$N rules on soa_jobupdated exist in the same region but the exact 1..9 enumeration was not re-verified here — downgraded to the IR_FMSJob* set which IS verified.]**

---

## 5. In-Service Permit (ISP) / In-Service Work Permit (ISWP) constructs

Two coupled headers: **`soa_inservicepermit`** (the permit, 33 cols) + **`soa_ispermitrequest`** (the request form, 37 cols of hazard/work detail). Same PK `ispermit` (hash). Plus `soa_ispjob` (TO/RS operator+time), `soa_ispcondition`, `soa_isprestriction(+item)`, `soa_isplog`, `soa_ispwithdrawevent/permit`. `[FACT - col counts VERIFIED: 33 / 37]`

### 5a. ISP numeric Status machine — MASTER DECODER `SOA_ISPStatusUpd` `[FACT - body read line-by-line, VERIFIED]`

| Status | CurrentStatus (varchar) | RequestStatus | Meaning |
|---|---|---|---|
| 1 | (request) | — | request created `[FACT - SOA_ISPArchive: P.Status IN (1,2), VERIFIED. NOT decoded by SOA_ISPStatusUpd → falls to ELSE 'internal status' branch]` |
| 2 | REQUEST | REQUEST | request submitted `[FACT - VERIFIED]` |
| 8 | (interim) | — | aging draft, auto-closed after 4 days `[FACT - SOA_ISPArchive: Status=8 AND StatusTime<=now-4days, VERIFIED. Not in SOA_ISPStatusUpd decoder]` |
| 10 | OPEN | — | permit opened `[FACT - VERIFIED]` |
| 15 | PENDTO | — | pending Transmission Operator `[FACT - VERIFIED]` |
| 20 | PENDSO | — | pending System Operator `[FACT - VERIFIED]` |
| 25 | DENIED | DENIED | denied `[FACT - VERIFIED; also writes ProcessByName, Remark on request]` |
| 30 | PEND | — | pending (reason) `[FACT - VERIFIED]` |
| 35 | A/COND | — | approved w/ conditions `[FACT - VERIFIED]` |
| 40 | APPRV | APPROVED* | approved (Request→APPROVED only if ObjectType=0 OR 1) `[FACT - VERIFIED]` |
| 45 | ISSUED | — | issued `[FACT - VERIFIED]` |
| 50 | ISSUED | APPROVED | issued (approved) `[FACT - VERIFIED]` |
| 54 | PULLRQ | — | pull requested `[FACT - VERIFIED]` |
| 55 | PULLED | PULLED | pulled `[FACT - VERIFIED]` |
| 60 | COMPL | COMPL | returned complete `[FACT - VERIFIED]` |
| 65 | INCOMPL | INCOMPL | returned incomplete `[FACT - VERIFIED]` |
| 70 | LOCAL | LOCAL | under local authorization (sets LocalAuthorization=1) `[FACT - VERIFIED]` |
| 100 | (archived) | — | archived/closed (sets CloseTime) `[FACT - VERIFIED]` |

> Excerpt `[FACT - VERIFIED verbatim]`:
> ```
> IF Status=2 THEN CurrentStatus='REQUEST';RequestStatus='REQUEST'; ELSEIF Status=10 THEN CurrentStatus='OPEN';
> ELSEIF Status=15 THEN CurrentStatus='PENDTO'; ELSEIF Status=20 THEN CurrentStatus='PENDSO';
> ... ELSEIF Status=40 THEN CurrentStatus='APPRV'; IF ObjectType=0 OR ObjectType=1 THEN RequestStatus='APPROVED';
> ... ELSEIF Status=45 THEN CurrentStatus='ISSUED'; ELSEIF Status=50 THEN CurrentStatus='ISSUED';RequestStatus='APPROVED';
> ```

`[FACT]` This is an **approval workflow**: REQUEST → (PENDTO/PENDSO) → APPRV / A/COND / DENIED → ISSUED → (PULLED) → COMPL/INCOMPL → archived(100). `[INFERENCE]` TO/SO = Transmission Operator / System Operator dual-jurisdiction approval. **[VERIFIER NOTE: original cited `jurisdiction char(2)` for ObjectType "10153/40". `soa_outagerequest.jurisdiction` is varchar(20); the ISP jurisdiction logic at the cited line was NOT re-read in this pass → downgrade that specific ('DO' for ObjectType 10153/40) detail to `[UNKNOWN - not re-verified]`.]**

`[FACT - SOA_ISPArchive, VERIFIED verbatim]` Auto-close sweep: `UPDATE SOA_InServicePermit SET Status=100, CloseTime=:CloseTime WHERE Status IN (25,55,60,65,70) OR (Status=8 AND StatusTime <= :CloseTime-'4 days')`; requests where `P.Status IN (1,2)` and `R.EnterTime <= :CloseTime-'6 months'` also closed.

### 5b. Request submit / reset `[FACT - VERIFIED names exist]`
- `SOA_ISPRequestSubmit` → sets permit+request to REQUEST, logs submission.
- `SOA_ISPResetToRequest` → reverts to REQUEST. **[VERIFIER NOTE: bodies of these two not re-read line-by-line this pass; names/existence confirmed, detail retained as analyst-reported `[FACT - per original read]`.]**

### 5c. Issue / Complete / Withdraw `[FACT - bodies read, VERIFIED]`
- `SOA_IssueISP` → upsert `soa_ispjob`(TOOperator,TOOperatorName,TOIssued,Note). `[VERIFIED]`
- `SOA_CompleteISP` → `soa_ispjob` SET RSOperator,RSOperatorName,RSComplete,ReturnStatus,Note. `[VERIFIED]`
- `SOA_ISPWithdrawJob` → repoints the underlying work permit: `Application='SLC'`→`SOA_WorkPermit.PermitJobID`; `'TLS'`→`TC_WorkPermit.PermitJobID`; updates `SOA_InServicePermit.Job=NewJob`. `[FACT - body read, VERIFIED]` (Cross-module: SLC vs TLS/TC.)

`soa_ispermitrequest.CurrentStatus` is also driven through `RequestStatus` mirror in the decoder above (REQUEST/DENIED/APPROVED/PULLED/COMPL/INCOMPL/LOCAL). `[FACT - VERIFIED]`

---

## 6. Bus-fault / automatic outage — `soa_busfaultoutage` (**67 cols** **[VERIFIER CORRECTION: 67, not 73]**, biggest table in DB — verified widest)

`[FACT - DDL, VERIFIED]` PK = `switchingitem` (btree). It is **one wide row per bus-fault outage event**, capturing every relay-target / power-quality datapoint of an automatic substation outage. **Why so wide:** it is a denormalized telemetry capture form — each protection element gets its own (flag, value/relayname, lastupd, lastupdby) quad:

- Bus differential: `bdphasea/b/c, bdrelayname, bdlastupd/by`
- Bus overcurrent: `bocphasea/b/c/n, bocrelayname,...`
- Backup timer: `butoperated, butrelayname,...`
- Feeder target: `ftfeeder, ftphasea/b/c/n, ftrelayname,...`
- Closed feeder breaker: `clfdrbkr, clfdrbkrs,...`
- Visible break fault: `vbfault, vbfdescription,...`
- Power-quality nodes: `pqfound/pqvalue/pqtime`, `pqrmsfound/...`, `fbmpr/fblor`, `bbmpr/bblor` (front/back-bus MPR/LOR relays)
- Manhole event `mhevent`, vault-fault FOD `vffod`, `correlationaction varchar(160)`, `importstatus`. `[FACT - all four columns confirmed present in DDL]`

`[FACT - SOA_BFIns, VERIFIED verbatim]` Created by `SOA_BFIns(Substation,BusSection,SwitchingItem,CreationTime,CreatedByDO)` — inserts with all 22 flag/target columns = **-1** (sentinel "unknown/not-yet-determined"). Then targeted `SOA_BF*Upd` procs each patch one element group. **[VERIFIER NOTE: all 16 `SOA_BF*Upd` procs AND `SOA_BFCMatrixIns`/`SOA_BFCMatrixDel` named below confirmed to exist (1 body each):]** `SOA_BFBusDiffUpd`, `SOA_BFBusOCUpd`, `SOA_BFBackupTimerUpd`, `SOA_BFFeederTargetUpd`, `SOA_BFClosedFdrBkrUpd`, `SOA_BFVisibleFaultUpd`, `SOA_BFPQNodeUpd`, `SOA_BFPQRMSUpd`, `SOA_BFMHEventUpd`, `SOA_BFVFFODUpd`, `SOA_BFBBMPRUpd`, `SOA_BFBBLORUpd`, `SOA_BFFBMPRUpd`, `SOA_BFFBLORUpd`, `SOA_BFCorrActionUpd`, `SOA_BFImportStatusUpd` `[FACT - all VERIFIED]`.

`[FACT]` Correlation logic lives in `soa_busfaultcorrelationmatrix` (managed by `SOA_BFCMatrixIns/Del`) + `correlationaction` text — `[INFERENCE]` the system reads which protection targets operated and looks up the matrix to recommend the operator's corrective switching action.

### Planned vs bus-fault distinction `[INFERENCE - structural]`
| | Planned switching order | Bus-fault / auto outage |
|---|---|---|
| Entity | `soa_job` on a `soa_card`; `soa_outagerequest` (OSS import) | `soa_busfaultoutage` keyed by switchingitem |
| Origin | DO/planner enters moves; OSS outage requests | Created by DO from SCADA event (`createdbydo`, `xa_busoutage` dbevent) |
| Approval | ISP TO/SO workflow (§5) | reactive — capture & correlate, no pre-approval |
| State | switemstatus 20→50, TO/RS issue/complete | importstatus + per-element flags |
| Trigger | manual / scheduled | EMS/SCADA `xa21_*`, `rtu_*`, `xa_busoutage`/`xa_tfmsoutage` dbevents |

---

## 7. Planned outage request (`soa_outagerequest`, 21 cols) state machine `[FACT - SOA_ORStatusUpd, VERIFIED verbatim]`

| Status | CurrentStatus | Meaning |
|---|---|---|
| 10 | IMPORTED | imported from OSS (external outage-scheduling system) |
| 20 | PERMIT | permit issued/linked |
| 50 | CLOSED | closed |
| 70 | RECALLED | recalled |
| 100 | ARCHIVED | archived |

Also carries `ossstatus varchar(40)` (free external status) and sked/actual date pairs (outage/work-issue/start/return/in-service). `[FACT - DDL VERIFIED: ossstatus, skedoutagedate/actualoutagedate, skedstartdate/actualstartdate, skedreturndate/actualreturndate, skedinservicedate/actualinservicedate, jurisdiction varchar(20)]`. Linked to permit jobs via `soa_outagerequestpermit(ornumber,workitem,permitjobid,workgroup)`; workgroup derived by joining `SOA_Job.JobClass → IR_WorkingGroup → UDB_Type` `[FACT - SOA_ORPermitIns, per original read]`. Cascade delete via rule `SOA_OutageRequest$Del → SOA_ORCascadeDel` `[FACT - proc SOA_ORCascadeDel VERIFIED exists]`.

---

## 8. Card lifecycle (the order container) `[FACT - SOA_CardStatusUpd, VERIFIED verbatim]`

`soa_card.Status` (numeric): **10 (created) → 20 (activated, sets Activated date) → 50 (closed, sets Closed date)** `[FACT - SOA_CardStatusUpd: IF Status=20 AND OldStatus=10 sets Activated; ELSEIF Status=50 sets Closed, VERIFIED]`. Rules materialize the active list:
- `SOA_CardActivate`/`SOA_CardINSERT` (Status≥20,<50) → `SOA_ActiveListInsert` `[FACT - proc VERIFIED]`
- `SOA_CardDelete` (→≥50 or →10) → `SOA_ActiveListDelete` `[FACT - proc VERIFIED]`
- `SOA_CardStatChange` (stays 20–49) → `SOA_ActiveLStatusChange` `[FACT - proc VERIFIED]`

**[VERIFIER NOTE: the three `SOA_ActiveList*`/`SOA_ActiveLStatusChange` procs were read and all RAISE DBEVENT `SOA_ActiveListChange` with an EventMsg payload (INSERT;/DELETE;/CARDSTATUS;/FEEDERSTATUS;). The exact rule names `SOA_CardActivate`/`SOA_CardINSERT`/`SOA_CardDelete`/`SOA_CardStatChange` were NOT individually re-grepped this pass → retained as analyst-reported.]**

---

## 9. Event propagation

`[FACT]` Two raise mechanisms:
1. **Server procs raise** (proven `RAISE DBEVENT` in SOA bodies, VERIFIED): `SOA_ActiveListChange` is raised by `SOA_ActiveListInsert/Delete`, `SOA_ActiveLStatusChange`, `SOA_ActiveLFStatusChange` `[FACT - bodies read, all four RAISE DBEVENT "ingres".SOA_ActiveListChange :EventMsg, VERIFIED]`. `[FACT - per original read, not all re-verified this pass]` `SOA_CardValidation`, `SOA_CautionUpd`, `SOA_JobUpdated`, `SOA_ArchiveTrigger`.
2. **Client (OpenROAD 4GL) raises** — events with `grant raise ... to public` and **no proc raising them**: **`active_order_change`** (dbevent d1.sql:26520; `grant register`/`grant raise` to public d1.sql:26522/26524; NO server proc raises it — VERIFIED), plus `soa_jobupdated` (dbevent d1.sql:27348), etc. `[FACT - VERIFIED]` `active_order_change` has NO server proc raising it → `[INFERENCE]` it is raised by the OpenROAD client/distributor process to tell all desks to refresh the active-order list; consumers `register` on it. **[VERIFIER NOTE: `SOA_ActiveListChange` is dbevent d1.sql:27270 (`soa_activelistchange`), distinct from `active_order_change` — do not conflate the two.]**

### Event flow (Mermaid)
```mermaid
flowchart TD
  subgraph Server[Ingres procs + rules]
    JU[SOA_Job col update<br/>TOIssued/TOComplete/RSIssued/<br/>RSComplete/Grounds/Response]
    R1[rules IR_FMSJob$RC/RI/TC/TI]
    PJ[IR_FMSJobUpdate proc]
    AL[SOA_ActiveListInsert/Delete/<br/>LStatusChange/LFStatusChange]
    CV[SOA_CardValidationUpd]
    BF[SOA_BFIns / SOA_BF*Upd]
  end
  JU --> R1 --> PJ -->|RAISE| EJ((soa_jobupdated))
  AL -->|RAISE| EAL((SOA_ActiveListChange))
  CV -->|RAISE| ECV((SOA_CardValidation))
  Client[OpenROAD client / Distributor] -->|RAISE| EAO((active_order_change))
  EJ --> Desks[All DO desks register & reload job]
  EAL --> Desks
  EAO --> Desks
  BF -->|SCADA xa_busoutage| BFcap[Bus-fault capture]
```

---

## 10. Cross-module links / readers-writers `[FACT]`
- **IR (operating orders):** `soa_job_to_soo(job,seq,to_or_rs,ordernumber)` bridges SOA jobs to IR operating orders. **[VERIFIER CORRECTION: this table is btree unique on (job,seq,ordernumber) — NOT a heap.]** Rules `IR_FMSJobRSComplete/RSIssued/TOComplete/TOIssued` fire `IR_FMSJobUpdate` on `SOA_Job` TO/RS timestamp changes (Action 'RC','RI','TC','TI') `[FACT - rules d1.sql:33097-33103, VERIFIED verbatim]`. ISP archive joins `IR_OpOrderJobs`/`IR_OperatingOrder` (OrderStatus>50) `[FACT - SOA_ISPArchive, VERIFIED]`.
- **SLC (long-term clearances):** rules `SLC_NewItemActivated`(switemstatus=20,movecat 2/3), `SLC_ItemClosed`(≥50), `SLC_ArchiveItem`/`SLC_PurgeItem` on archive/delete (movecat 2,3,6) `[FACT - rules d1.sql:33172-33180, VERIFIED]`. `SOA_WorkPermit` repointed on ISP withdraw for `Application='SLC'` `[FACT - SOA_ISPWithdrawJob, VERIFIED]`.
- **TC/TLS (transmission):** ISP withdraw repoints `TC_WorkPermit` for `Application='TLS'` `[FACT - SOA_ISPWithdrawJob, VERIFIED]`; `xa_tfmsoutage` dbevent.
- **FMS:** active-list insert reads `FMS_Card`, `TFMS_CardToObject` `[FACT - SOA_ActiveListInsert body, VERIFIED]`; rule `SOA_FMSFStatusChange` → `SOA_ActiveLFStatusChange` `[FACT - per original read]`. `LogCard_FeederStatusName` rule on FMS_Card → `SOA_LogInsert` `[FACT - per original read]`.
- **CAC (relay ops):** `SOA_ArchiveRelays`, `SOA_CascadeRelayDel` write `CAC_RelayOpsControl`/`CAC_ArchiveRelayOps` `[FACT - per original read]`.
- **UDB (metamodel):** equip validation cascade — rule `SOA_CascadeEquipVal` on `Udb_Object.ValidatedBy`; `SOA_EquipType$Insert/Delete` maintain `SOA_*EquipType` filter tables from `UDB_ExtendedType.SuperType=17` `[FACT - per original read; SOA_DeleteEquipType proc VERIFIED deletes from SOA_TypeExclusion/ISWPEquipType/CFGEquipType]`.

**Transaction boundaries** `[INFERENCE]`: each proc is one logical txn; multi-step procs `RETURN -1` on any `iierrornumber<>0` (e.g. `SOA_CloseSwitchItem` does up-to-3 updates then conditional un-hide, bailing on each error — VERIFIED) — but Ingres DB procs are **not auto-atomic**; rollback is the **caller's** responsibility on the returned -1. No explicit `COMMIT`/`ROLLBACK` in proc bodies observed `[FACT - VERIFIED across the ~12 bodies read]`.

---

## 11. Switching-order state machine (consolidated, Mermaid) `[INFERENCE - labels; numeric values FACT - VERIFIED]`
```mermaid
stateDiagram-v2
  [*] --> Drafted: SOA_ItemIns/SOA_JobIns (switemstatus<20, status=' '/'NIS')
  Drafted --> Active: SOA_ActivateSwitchItem (switemstatus=20, Response='Active')
  Active --> TOIssued: SOA_IssueMove('TO')
  TOIssued --> TOComplete: SOA_CompleteMove('TO')
  TOComplete --> RSIssued: SOA_IssueMove('RS')
  RSIssued --> RSComplete: SOA_CompleteMove('RS')
  RSComplete --> Closed: SOA_CloseSwitchItem (switemstatus>=50)
  Active --> Purged: SOA_CloseSwitchItem(ClosureRemark='Purge')
  Closed --> [*]: SOA_ArchiveJob (->soa_archivejob)

  state "ISP approval (parallel)" as ISP {
    [*] --> REQUEST: SOA_ISPRequestSubmit (Status=2)
    REQUEST --> PENDTO: 15
    PENDTO --> PENDSO: 20
    PENDSO --> APPRV: 40
    APPRV --> ISSUED: 45/50
    ISSUED --> PULLED: 55
    ISSUED --> COMPL: 60
    ISSUED --> INCOMPL: 65
    REQUEST --> DENIED: 25
    COMPL --> ARCHIVED: 100
  }
```

---

## 12. Gaps / UNKNOWNs / contradictions
- `[UNKNOWN]` No row data anywhere (all `copy from '<t>.ingres'` files absent) → cannot enumerate `jobclass`, `equipclass`, `udb_type`, full `movecategory`/`movetype` lists, or any seed status that isn't hard-coded in a proc. Enum **labels** in §4/§5/§7 are `[INFERENCE]` except where a literal string appears in proc code.
- `[CONTRADICTION - ground truth]` "2,450 procedures" overcounts: d1.sql has each proc **twice** (stub @<27757 + body @>27757). Distinct SOA procs = **240** (240 stubs in block 1 ↔ 240 bodies in block 2 — both VERIFIED). Real distinct DB procs ≈ **1,287** (2,450 − 1,163 stubs), not 2,450. The "real server-side logic" claim is correct but bodies live in the SECOND half of the file.
- **[VERIFIER CORRECTION — RESOLVED]** ~~`soa_job_to_soo` has no `modify` (heap; PK assumed (job,seq))~~ — **FALSE. It IS `modify ... to btree unique on (job, seq, ordernumber)` (d1.sql:10168). PK is the 3-column composite, not the assumed 2.**
- `[UNKNOWN]` Whether `active_order_change` is raised by any process (no proc raises it — VERIFIED; presumed OpenROAD client per `psm.dmt`, not read this pass).
- `[UNKNOWN]` `soa_job.status` full domain — only `' '`,`'NIS'`,`'Hid'` proven; others may exist in absent data.
- `[INFERENCE]` `switemstatus` granular values between 0 and 20, and 50+, are not individually decoded by any single proc (unlike ISP's `SOA_ISPStatusUpd`); only the threshold bands (<20 / =20 / 20–49 / ≥50) are code-proven.
- `[UNKNOWN - downgraded by verifier]` ISP `jurisdiction` = 'DO' for "ObjectType 10153/40": the line was not re-read; treat as unverified.

---

## Verification

**Verifier:** adversarial pass on 2026-06-12 against `d:/103_RnD/psm_v1/d1.sql` (33,392 lines). Method: `grep`/`awk` existence checks for every cited object; full body reads of the load-bearing procs; DDL + `modify` reads for the central tables.

### Confirmed (no change)
- **Existence: 84/84 cited objects EXIST. Zero fabrications.**
  - 40/40 tables (`create table soa_*` each = 1).
  - 25/25 cited body-form procs (each declared twice: stub + body, exactly as the analyst documented).
  - dbevents `active_order_change` (26520), `soa_jobupdated` (27348), `SOA_ActiveListChange`/`soa_activelistchange` (27270).
  - rules `SLC_ItemClosed` (33176), `SLC_NewItemActivated` (33178), `IR_FMSJobUpdate` proc (29990) + its 4 firing rules (33097-33103), `SOA_DetermineSequence` rule (33214), `SOA_ControlResequence` rule (33212).
  - All 16 `SOA_BF*Upd` procs + `SOA_BFCMatrixIns/Del` (named in §6) exist.
- **Counts:** 86 SOA tables; 240 SOA stub procs; 240 SOA body procs; 2,450 total `create or replace procedure`; 1,163 file-wide stubs. All VERIFIED exact.
- **Proc bodies read & confirmed verbatim:** `SOA_ActivateSwitchItem`, `SOA_CloseSwitchItem`, `SOA_IssueMove`, `SOA_CompleteMove`, `SOA_ISPStatusUpd` (full 18-state decoder — every status/CurrentStatus/RequestStatus row matches), `SOA_IssueISP`, `SOA_CompleteISP`, `SOA_ISPWithdrawJob`, `SOA_ISPArchive`, `SOA_ORStatusUpd`, `SOA_CardStatusUpd`, `SOA_BFIns` (-1 sentinels), `SOA_ActiveListInsert/Delete`, `SOA_ActiveLStatusChange`, `SOA_ActiveLFStatusChange`, `SOA_JobColor`, `SOA_ItemIns`, `SOA_ControlResequence`.
- **Index/storage:** soa_job(job), soa_jobcontrol(card,job,switchingitem), soa_busfaultoutage(switchingitem), soa_archivejob(card,seq,job,switchingitem), soa_activeobject(object,card), soa_inservicepermit/ispermitrequest(ispermit, hash), soa_workpermit(permitjobid, hash) — all VERIFIED.
- **Column values:** `ActivityIdentifier='S'` proven in `SOA_JobControlIns` (~31428); movecategory 1→FgColor8, 4/5→kV bg; `Status IN ('','NIS')` and `SwItemStatus>=20 AND <50` active gating — all VERIFIED.
- soa_job DDL = 31 cols ✓; inservicepermit 33 ✓; ispermitrequest 37 ✓; archivejob 29 ✓; workpermit 17 ✓; jobcontrol 8 ✓; job_to_soo 4 ✓; outagerequestpermit 4 ✓; activeobject 3 ✓; activity 11 ✓.

### Corrected
1. **`soa_busfaultoutage` cols: 73 → 67** (§1, §6). Confirmed widest table in the whole DB (next = fms_sesamelockcard at 65), so the "largest table" claim survives; only the number was wrong.
2. **`soa_job_to_soo` is NOT a heap.** It has `modify soa_job_to_soo to btree unique on (job, seq, ordernumber)` at d1.sql:10168. The "(no modify found)" cell (§1), the "heap, PK assumed (job,seq) but unproven" gap (§12), and the corresponding ground-truth gap are all **invalidated**: PK is the **3-column** (job,seq,ordernumber) composite.
3. **`soa_outagerequest` cols: 22 → 21** (§1).
4. **`soa_activecard` cols: 11 → 9** (§1).
5. **soa_job DDL paraphrase tightened** (§2): no `jobclassname` column exists; `basekey integer` column was omitted by the analyst and is now listed; column types corrected to actual DDL.
6. **Distinct-proc estimate: "~1,225" → ~1,287** (2,450 − 1,163). Cosmetic; the 2x-overcount thesis is unchanged and correct.
7. **§4c/§9 rule attribution:** the TO/RS-timestamp rules actually verified are the four `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` rules (Action RC/RI/TC/TI), not "7 SOA_JobUpdate$1..9" — the latter enumeration was not re-verified and is downgraded.
8. **§4a `SOA_CloseSwitchItem`:** sets `Response=:ClosureRemark` (= 'Purge' on that branch), not a literal `'Purge'` assignment. Same effect; phrasing corrected.

### Residual UNKNOWNs (carried forward, legitimately unverifiable from artifacts present)
- All seed/enum domains (jobclass, equipclass, udb_type, full movecategory/movetype/movetype-color lists, any status not hard-coded in a proc) — row-data `.ingres` files absent.
- `soa_job.status` full domain beyond `' '`/`'NIS'`/`'Hid'`.
- `switemstatus` granular values inside the <20 and ≥50 bands (only threshold bands are code-proven).
- Whether `active_order_change` is actually raised by the OpenROAD client (`psm.dmt` not read this pass).
- ISP `jurisdiction='DO' for ObjectType 10153/40` — newly downgraded; not re-read.
- `SOA_ISPRequestSubmit`, `SOA_ISPResetToRequest` bodies and the `SOA_Card*` rule names — names/existence confirmed, exact bodies not re-read this pass (retained as analyst-reported).
- Full column lists for the ~60 tables not deep-read (warning subsystem, hipot, connectivity, voltagereduction, scenario internals, report distribution).
