# Metamodel-Core (UDB / PSDM) — Raw Analysis

Domain: the UDB metamodel CORE — `udb_object` (the universal object table) + the type-system control tables (`udb_type`, `udb_basetype`, `udb_supertype`, `udb_extendedtype`). This is a **hand-rolled, data-driven, single-table-inheritance (STI) object model** sitting on Actian Ingres.

Primary source: `d:/103_RnD/psm_v1/d1.sql`. Client semantics cross-checked in `psm.dmt` and `ug.html`.

> The PSM/PSDM application that "supports" these tables is named in the user guide: *"The underlying connected data model, consisting of Udb tables like Udb_Type, Udb_Object, Udb_Grouping, etc, is supported by the Udb / PSDM (Power System Data Model) application."* [FACT - ug.html:5121-5123] **[VERIFIED - ug.html:5122-5123, exact match. Same passage names the deployment site: "This hardcopy would exist only at Con Edison. Pateric Software" (ug.html:5138).]**

---

## 1. The five core tables (verbatim DDL)

### 1.1 `udb_object` — the universal object table [FACT - d1.sql:14388-14418] **[VERIFIED - DDL spans d1.sql:14388-14419 (close at 14419); all 30 columns, types, and defaults exact.]**

```
create table udb_object(
    object integer not null not default,          -- PK
    source integer,                               -- nullable FK (provenance)
    systemversion integer not null default 0,
    basetype integer not null default 0,          -- FK -> udb_basetype.type (DENORMALIZED, derived from type)
    type integer not null default 0,              -- FK -> udb_type.type
    primarygrouping integer not null default 0,   -- FK -> udb_object.object (self-ref: parent grouping)
    typename varchar(40) not null default ' ',    -- CACHE of udb_type.name
    primarygroupingname varchar(40) not null default ' ', -- CACHE of parent udb_object.name
    name varchar(40) not null default ' ',
    description varchar(60) not null default ' ',
    comment varchar(200) not null default ' ',
    status char(16) not null default ' ',         -- lifecycle/state (enumeration UNKNOWN - no seed rows)
    terminals integer not null default 0,          -- electrical terminal count -> drives udb_terminal fan-out
    inservice ingresdate,                          -- nullable
    outservice ingresdate,                         -- nullable
    positionx f4,                                  -- nullable GIS coord
    positiony f4,                                  -- nullable GIS coord
    ownernumber char(20) not null default ' ',
    serialnumber char(20) not null default ' ',
    specnumber char(20) not null default ' ',
    combination char(20) not null default ' ',
    locknumber varchar(40) not null default ' ',
    validated ingresdate,                          -- nullable (audit)
    validatedby char(24) not null default ' ',
    locked ingresdate,                             -- nullable (audit)
    lockedby char(24) not null default ' ',
    created ingresdate,                            -- nullable (audit)
    createdby char(24) not null default ' ',
    lastchanged ingresdate,                        -- nullable (audit)
    lastchangedby char(24) not null default ' '
)
```
Storage: `modify udb_object to btree unique on object` — clustered PK on `object`. `row_estimate = 105880` (the load-time estimate; actual row count UNKNOWN — data file absent). [FACT - d1.sql:14427-14441] **[CORRECTED - the `modify udb_object to btree unique on object` clause is at d1.sql:14431-14439. The `row_estimate = 105880` is NOT in the modify clause; it is in the bulk-load statement `copy udb_object () from '/home/ingres/Downloads/udb_object.ingres' with notnull_empty, row_estimate = 105880`. VALUE 105880 confirmed; line citation 14427-14441 was approximate. Modify uses page_size=8192, btree, journaling on.]**

### 1.2 `udb_type` — the type catalog (the "class" table) [FACT - d1.sql:15102-15107] **[VERIFIED - DDL exact at d1.sql:15102-15107.]**
```
create table udb_type(
    type integer not null not default,            -- PK part 1
    basetype integer not null not default,        -- FK -> udb_basetype.type
    name char(40) not null not default,           -- PK part 2 (unique btree on type,name)
    description char(60) not null default ' '
)
```
`modify udb_type to btree unique on type, name`. `row_estimate = 2054`. [FACT - d1.sql:15119, 15117] **[VERIFIED - modify at d1.sql:15119 (`btree unique on type, name`); row_estimate=2054 confirmed in the `copy udb_type` load statement. VALUE exact.]**

### 1.3 `udb_basetype` — base-type -> physical wiring (STI dispatch table) [FACT - d1.sql:13363-13367] **[VERIFIED - DDL exact at d1.sql:13363-13367.]**
```
create table udb_basetype(
    type integer not null not default,            -- PK (the base-type id)
    editorname char(20),                          -- OpenROAD editor frame name (CLIENT use only)
    tablename char(20)                            -- per-type SUBTYPE table name (server STI dispatch)
)
```
`modify udb_basetype to btree unique on type`. `row_estimate = 41` — i.e. **~41 base types** (the count of distinct physical subtype shapes). [FACT - d1.sql:13379, 13377] **[VERIFIED - modify at d1.sql:13379; row_estimate=41 confirmed in `copy udb_basetype` load. VALUE exact.]**

### 1.4 `udb_supertype` — class hierarchy AS DATA (direct edges) [FACT - d1.sql:14679-14682] **[VERIFIED - DDL exact; modify at d1.sql:14694; row_estimate=3577 confirmed in `copy udb_supertype` load.]**
```
create table udb_supertype(
    type integer not null not default,
    supertype integer not null not default
)
```
`modify udb_supertype to btree unique on type, supertype`. `row_estimate = 3577`. [FACT - d1.sql:14694, 14692]

### 1.5 `udb_extendedtype` — materialized TRANSITIVE CLOSURE of supertype [FACT - d1.sql:13839-13842] **[VERIFIED - DDL exact; modify at d1.sql:13854; row_estimate=15441 confirmed in `copy udb_extendedtype` load.]**
```
create table udb_extendedtype(
    type integer not null not default,
    supertype integer not null not default
)
```
`modify udb_extendedtype to btree unique on type, supertype`. `row_estimate = 15441` — **~4.3x larger than `udb_supertype` (3577)**, consistent with a closure expansion (every type gains a row for itself + all transitive ancestors). [FACT - d1.sql:13854, 13852] **[VERIFIED - 15441/3577 = 4.32x, arithmetic correct.]**

---

## 2. Single-table-inheritance design

**Pattern:** ONE wide root table (`udb_object`) holds every object's common attributes (identity, name, lifecycle, GIS, audit). Type-specific (subclass) attributes live in **per-type "side" tables keyed 1:1 on `object`**. The first column of each such subtype table is `object` (FK to `udb_object.object`). [FACT - inspected DDL] **[VERIFIED - all 29 listed tables below have `object` as their first data column.]**

Subtype tables in the `udb_` namespace whose first data column is `object` (STI side tables) — ~~**24 electrical/equipment subtype tables**~~ **[CORRECTED -> 29 subtype tables; the prose said "24" but the table immediately below lists and verifies 29, every one with first column `object`. The "24" was a counting error]** (excluding the audit/temp/grasscatcher noise):

| Subtype table | Domain meaning [INFERENCE from name + DDL] |
|---|---|
| udb_bwrsteamsupply | Boiling-water-reactor steam supply |
| udb_capacitor | Capacitor (nominalmvar, voltsensitivity, avrdelay) |
| udb_circuitroute | Circuit routing |
| udb_combustionturbine | Combustion turbine |
| udb_communicationlink | Comms link |
| udb_computer | Computer asset |
| udb_conductor | Line conductor (r,x,bch,length,towertype...) |
| udb_conductortype | Conductor-type spec |
| udb_consumer | Load/consumer (pfixed,qfixed,pnom,qnom...) |
| udb_dsovalve | DSO valve (gas/pipe domain) |
| udb_fossilsteamsupply | Fossil steam supply |
| udb_generator | Generator |
| udb_hydroturbine | Hydro turbine |
| udb_loadcurve | Load curve |
| udb_location | Geographic location attrs |
| udb_measurementtype | Measurement-type spec |
| udb_person | Person/contact |
| udb_pwrsteamsupply | Pressurized-water-reactor steam supply |
| udb_rating | Equipment rating |
| udb_reactor | Reactor (shunt) |
| udb_scanblock | SCADA scan block |
| udb_steamturbine | Steam turbine |
| udb_switch | Switch (normalopen,currentlyopen,relaytype,networktype,stoptag) |
| udb_tapsetting | Transformer tap setting |
| udb_telemetry | Telemetry point |
| udb_telephonecircuit | Telephone circuit |
| udb_towertype | Tower-type spec |
| udb_transformer | Transformer (bank,phases,magbasekv,gmag...) |
| udb_winding | Transformer winding |

[FACT - d1.sql, awk first-column scan] **[VERIFIED - 29 rows; every one confirmed `object` as first data column via per-table DDL scan.]**

`udb_terminal` and `udb_node` are **electrical-connectivity** tables, also keyed on `object`/`node`, not pure STI subtype rows: `udb_terminal(object, basetype, terminal, node, inservice, outservice)` — note `basetype` and `inservice/outservice` are **denormalized copies** of the parent `udb_object` values. [FACT - d1.sql:14997-15006, 14359-14365] **[CORRECTED - `udb_terminal` DDL is at d1.sql:14997-15004 (closes 15004, not 15006). DDL exact. CAVEAT: `object$insert`'s terminal fan-out inserts ONLY (Object, BaseType, Terminal) — it does NOT copy inservice/outservice; those columns exist but are left at default 0/NULL by the insert proc, so calling them "denormalized copies of the parent" is [INFERENCE], not proven by the insert path.]**

`udb_grasscatcher(object, problem, text, known)` is NOT a subtype — it is the **validation-error sink** (see §6). `udb_problem(problem, severity, description)` is the **problem-code catalog**. [FACT - d1.sql:13973-13977, 14473-14477] **[VERIFIED - both tables exist; grasscatcher is the target of all `INSERT INTO Udb_GrassCatcher (Object, Problem[, Text]) VALUES (...)` statements seen in the procs below.]**

---

## 3. "What is this object?" — the exact resolution path

The canonical resolution is hard-coded in `object$insert`. The join that answers identity is:

> `SELECT :BaseType = BT.Type, :TableName = BT.TableName FROM Udb_Type T, Udb_BaseType BT WHERE :Type = T.Type AND T.BaseType = BT.Type;` [FACT - d1.sql:30457-30458, proc `object$insert`] **[VERIFIED - exact, d1.sql:30457-30458. NOTE: there are TWO definitions of `object$insert` — a forward-declared stub `create or replace procedure object$insert as begin return; end` at d1.sql:24223, then the real body at d1.sql:30457. The real body is the one analyzed here.]**

So resolution is:

```
udb_object.type
   -> udb_type   (type = T.type)            : gives T.basetype, T.name
       -> udb_basetype (T.basetype = BT.type): gives BT.tablename  (which physical subtype table)
                                              gives BT.editorname (which OpenROAD frame)
```

- `udb_basetype.tablename` => the per-type subtype table holding subclass columns (e.g. `'Switch'` -> `udb_switch`). **Server-side STI dispatch.** [FACT - d1.sql `object$insert`] **[VERIFIED.]**
- `udb_basetype.editorname` => the OpenROAD editor frame to open for that base type. **Client-side only** — `editorname` appears in NO server procedure body anywhere in `d1.sql` (only in the table DDL ~~and in grants~~). It is consumed by `psm.dmt` frames. [FACT - grep editorname -> only DDL/grants; INFERENCE - it is the UI editor binding] **[CORRECTED - `editorname` appears EXACTLY ONCE in d1.sql: the table DDL at line 13365. It is NOT in any grant statement. The "and in grants" qualifier is wrong; the underlying claim (never referenced by a server proc) is CORRECT and in fact stronger.]**
- `udb_object.basetype` and `udb_object.typename` are **denormalized derivations** written at insert time (see §5). [VERIFIED - both set by the `UPDATE Udb_Object O ... SET BaseType=:BaseType, TypeName=T.Name` in `object$insert`, d1.sql:30460.]

### 3.1 CRITICAL CONTRADICTION — dispatch is data-driven in schema but HARD-CODED in `object$insert`
Although `udb_basetype.tablename` is *designed* to be a data-driven dispatch key, `object$insert` does NOT do dynamic SQL. After reading `TableName` from `udb_basetype`, it runs a **hard-coded IF/ELSEIF ladder on the string value**, inserting the stub child row only for an enumerated subset:

> `IF (TableName = '') THEN TableName=TableName; ELSEIF (TableName='Conductor') THEN INSERT INTO Udb_Conductor(Object)...; ELSEIF (TableName='Generator') THEN ... Udb_Generator ...; ELSEIF 'Consumer'->Udb_Consumer; 'Capacitor'->Udb_Capacitor; 'Reactor'->Udb_Reactor; 'Switch'->Udb_Switch; 'Transformer'->Udb_Transformer; 'Telemetry'->Udb_Telemetry; 'TowerType'->Udb_TowerType; 'ConductorType'->Udb_ConductorType; 'Computer'->Udb_Computer; 'MeasurementType'->Udb_MeasurementType; 'Person'->Udb_Person; 'CombustionTurbine'->Udb_CombustionTurbine; 'HydroTurbine'->Udb_HydroTurbine; 'SteamTurbine'->Udb_SteamTurbine; 'FossilSteamSupply'->Udb_FossilSteamSupply; 'BWRSteamSupply'->Udb_BWRSteamSupply; 'PWRSteamSupply'->Udb_PWRSteamSupply; 'CommunicationLink'->Udb_CommunicationLink; 'TelephoneCircuit'-> Udb_TelephoneCircuit + Udb_CircuitRoute; 'EquipTemplate'->SLC_EquipTemplate; ENDIF;` [FACT - d1.sql:30458 region, proc `object$insert`] **[VERIFIED - the full ladder was read verbatim (d1.sql:30460-30471). All 22 named branches confirmed; `TelephoneCircuit` does seed both Udb_TelephoneCircuit and Udb_CircuitRoute(Object,Route)=(:Object,0); `EquipTemplate` seeds SLC_EquipTemplate. SEE NEW FINDING #3 below — one branch literal is mistyped in the source.]**

> **[VERIFIER NEW FINDING — source defect not noted by analyst]** The `Generator` branch in the actual source reads `ELSEIF (TableName = ' Generator')` — **with a LEADING SPACE inside the literal**. A `udb_basetype` row with `tablename = 'Generator'` (no leading space) will NOT match this branch and will get NO `udb_generator` stub row on insert. The analyst's paraphrase silently normalized it to `'Generator'`. This is a real latent dispatch bug in `d1.sql:30461` region. [FACT - d1.sql object$insert ladder, literal `' Generator'`]

Consequences (implementation-critical):
- `udb_basetype` rows whose `tablename` is NOT in this ladder (e.g. `Capacitor` IS handled, but `Location`, `Rating`, `Winding`, `TapSetting`, `ScanBlock`, `LoadCurve`, `DsoValve`, `Telephone`-routing subtypes…) get **NO automatic child row** on insert — those side rows must be created by other paths. [INFERENCE - the ladder is a closed set; subtype tables exist that are absent from it] **[VERIFIED as structurally sound — the 29 STI tables in §2 minus the 22 ladder targets leaves tables like udb_location/udb_rating/udb_winding/udb_tapsetting/udb_scanblock/udb_loadcurve/udb_dsovalve with no insert-time stub branch. Exact gap vs the full 41 base types still needs udb_basetype seed data.]**
- `'TelephoneCircuit'` uniquely also seeds `udb_circuitroute(object, route)=( ,0)`. [FACT] **[VERIFIED - `INSERT INTO Udb_CircuitRoute (Object, Route) VALUES (:Object, 0)` immediately follows the TelephoneCircuit insert.]**
- `'EquipTemplate'` dispatches OUTSIDE the udb_ namespace to `SLC_EquipTemplate` — proof the metamodel is shared across modules. [FACT] **[VERIFIED - `INSERT INTO SLC_EquipTemplate (Object) VALUES (:Object)`; table SLC_EquipTemplate exists at d1.sql:8295.]**
- Adding a new base type requires BOTH a data row in `udb_basetype` AND a code edit to `object$insert`. The "data-driven" claim is therefore only half-true. [INFERENCE] **[VERIFIED reasoning.]**

---

## 4. `udb_supertype` / `udb_extendedtype` — class hierarchy as data

- `udb_supertype(type, supertype)` stores **direct** is-a / part-of edges between types (the class graph). [FACT - DDL]
- `udb_extendedtype(type, supertype)` is the **materialized transitive closure** of that graph, maintained by trigger procs.

Closure maintenance, proven in `SuperType$Insert` [FACT - d1.sql:31831 region] **[VERIFIED - real body read at d1.sql:31831-31838; stub at 25527.]**:
1. `DELETE FROM Udb_ExtendedType WHERE Type = :Type;`  — wipe the type's closure rows. **[VERIFIED.]**
2. `INSERT INTO Udb_ExtendedType (Type, SuperType) VALUES (:Type, :Type);` — **reflexive self-edge** (every type is its own extended-supertype). This self-edge is why extendedtype (15441) >> supertype (3577). **[VERIFIED.]**
3. `INSERT INTO Udb_ExtendedType (Type, SuperType) SELECT DISTINCT :Type, SuperType FROM Udb_ExtendedType ET WHERE ET.Type IN (SELECT DISTINCT SuperType FROM Udb_SuperType WHERE Type = :Type AND SuperType != :Type);` — inherit every ancestor's already-closed supertypes (one-level closure step relying on parents already being closed). **[VERIFIED verbatim. NOTE: the proc additionally issues `UPDATE Udb_SuperType ST SET SuperType = ST.SuperType WHERE ST.SuperType = :Type` — a no-op self-touch that re-fires the SuperType$Update rule on descendants to re-close them; omitted from the analyst's step list but not an error.]**
4. Validates `BaseType` consistency: if `T.BaseType != 0` and there is no `udb_extendedtype` row linking `Type -> BaseType`, raises problem `'Type_008'` into grasscatcher. [FACT] **[VERIFIED. Proc also raises `Type_009` (self-supertype: Type=SuperType), `Type_004` (Type not in Udb_Type), `Type_005` (SuperType not in Udb_Type) — all four problem codes confirmed in the body.]**

`SuperType$Delete` mirrors this: rebuilds closure, and guards against deleting a supertype still referenced (`Type_001`, `Type_002` problems if `udb_object` rows or child supertypes still depend on it, unless an extendedtype row to literal supertype `15028` exists — a magic id, meaning UNKNOWN without seed rows). [FACT - d1.sql:31823 region] **[VERIFIED - real body at d1.sql:31823-31825; `Type_001` guarded by `COUNT(*) FROM Udb_SuperType ST WHERE :Type=ST.SuperType ... AND Supertype=15028`, `Type_002` guarded by `COUNT(*) FROM Udb_Object O WHERE :Type=O.Type ... AND Supertype=15028`. Magic id 15028 confirmed; human meaning UNKNOWN.]**

Rules wiring the closure: [FACT - d1.sql:33260-33264] **[VERIFIED exact:]**
- `SuperType$Insert1 AFTER INSERT ON Udb_SuperType -> SuperType$Insert` **(d1.sql:33262)**
- `SuperType$Update AFTER UPDATE ON Udb_SuperType -> SuperType$Insert` **(d1.sql:33264)**
- `SuperType$Delete AFTER DELETE ON Udb_SuperType -> SuperType$Delete` **(d1.sql:33260)**

Closure is **consumed** in branch logic across modules via `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)` — e.g. FMS card-class validation requires the card class be a descendant of supertype `10093`:
> `... Udb_Type WHERE Type = :CardClass AND Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = 10093);` [FACT - d1.sql:29552] **[VERIFIED exact, d1.sql:29552.]**
and `Object$PrimaryGrouping` tests node membership via `PG.Type IN (SELECT ET.Type FROM Udb_ExtendedType ET WHERE ET.SuperType = 05)`. [FACT - d1.sql:30490 region] **[VERIFIED - present in the real `Object$PrimaryGrouping` body (d1.sql:30477-30484), gated on `IF (Terminals != 0)`, updating Udb_Node.PrimaryGrouping for terminals of node-supertype objects.]**

So `udb_extendedtype` is the **polymorphic "is-a-kind-of" test surface**: instead of walking the supertype graph at query time, code does a single closure-table lookup. [INFERENCE] **[VERIFIED reasoning.]**

---

## 5. `udb_object`'s 30 columns by role

| Role | Columns | Notes |
|---|---|---|
| **Identity / FK** | `object` (PK), `source`, `systemversion`, `basetype`, `type`, `primarygrouping` | `type`->udb_type; `basetype`->udb_basetype (derived); `primarygrouping`->self-ref parent (udb_object.object). `source` nullable = provenance. [FACT] |
| **Denormalized name caches** | `typename`, `primarygroupingname` | `typename` = copy of `udb_type.name`; `primarygroupingname` = copy of parent object's `name`. Maintained by triggers. [FACT - object$insert, Object$TypeName, Object$Name] |
| **Descriptive** | `name`, `description`, `comment` | free text |
| **Generic-overloaded identity** | `ownernumber`, `serialnumber`, `specnumber`, `combination`, `locknumber` | five char(20)/varchar(40) "tag" slots reused per type — meaning varies by object type (classic god-table overloading). char(20) except locknumber varchar(40). [FACT - DDL; INFERENCE - reuse] |
| **Lifecycle / state** | `status` char(16), `inservice`, `outservice`, `terminals` | `status` enumeration UNKNOWN (no seed rows). `terminals` int -> at insert, fans out N rows into `udb_terminal`. `inservice`/`outservice` nullable dates drive `Object$Validate`. [FACT] |
| **GIS coords** | `positionx` f4, `positiony` f4 | nullable single-precision floats. (Separate `nodes_xy`/`objects_xy` GIS tables exist elsewhere.) [FACT] |
| **Audit pairs (4)** | `validated`/`validatedby`, `locked`/`lockedby`, `created`/`createdby`, `lastchanged`/`lastchangedby` | date is nullable ingresdate; `*by` is char(24) sentinel-defaulted ' '. `created`/`createdby` set in object$insert (`Created='Now', CreatedBy=VARCHAR(User)`). [FACT - d1.sql object$insert] |

**[VERIFIED - column->role mapping is consistent with the DDL. `Created='Now', CreatedBy=VARCHAR(User)` confirmed in `object$insert` body (d1.sql:30460). The `terminals` fan-out is confirmed: `WHILE Loop <= Terminals DO INSERT INTO Udb_Terminal (Object, BaseType, Terminal) VALUES (:Object, :BaseType, :Loop)`.]**

Trigger-maintained denormalization [FACT - rules d1.sql:33131-33148, 33372]:
- `Object$Insert1 -> object$insert` (sets `basetype`, `typename`, `primarygroupingname`, `created`, `createdby`; fans out terminals; inserts child STI stub; inserts primary-grouping edge with relationship `52`). **[VERIFIED - rule at d1.sql:33133. NOTE: the rule itself does NOT pass BaseType (it passes Tid, Object, SystemVersion, Type, PrimaryGrouping, Terminals); the proc DERIVES BaseType from the Udb_Type/Udb_BaseType join and writes it. Relationship 52 grouping insert confirmed in proc body.]**
- `Object$Update_Type -> Object$TypeName` (`UPDATE Udb_Object O FROM Udb_Type T SET TypeName = T.Name WHERE T.Type = O.Type AND O.Tid = :Tid`). **[VERIFIED - rule `Object$Update_Type AFTER UPDATE (Type) ON Udb_Object WHERE Old.Type != New.Type` at d1.sql:33148.]**
- `Object$Update_Name -> Object$Name` (refresh children's `primarygroupingname`). **[VERIFIED - rule at d1.sql:33141; passes Tid and BaseType=New.BaseType.]**
- `Object$Update_PG -> Object$PrimaryGrouping` (maintains `udb_grouping` relationship-52 edges; for `BaseType=21` does consumer-load arithmetic roll-up). **[VERIFIED - rule at d1.sql:33145; proc body confirms `IF (BaseType = 21) THEN` subtract-from-old-grouping + add-to-new-grouping of Pfixed/Pnom/Qfixed/Qnom on Udb_Consumer.]**
- `Udb$CascadeTypeName` (rule `Udb$CascadeTypeName AFTER UPDATE(Name) ON Udb_Type`): `UPDATE Udb_Object SET TypeName = :NewTypeName WHERE Type = :Type` — propagates a type rename to all instances' cache. [FACT - d1.sql:32502, 33372] **[VERIFIED exact - proc at 32502, rule at 33372.]**
- `CascadeType$Change` (rule `CascadeType$Change AFTER UPDATE(Type) ON Udb_Object`): updates `udb_grouping.membertype`/`groupingtype` to the new type. [FACT - d1.sql:27983, 32789] **[VERIFIED exact - proc at 27983 (`SET MemberType=:Type WHERE Member=:Object; SET GroupingType=:Type WHERE Grouping=:Object`), rule at 32789 (`WHERE New.Type <> Old.Type`).]**

So **`basetype`, `typename`, `primarygroupingname` are all redundant derivations** kept consistent only by trigger discipline — any direct DML bypassing the rules silently desyncs them. [INFERENCE] **[VERIFIED reasoning — and see §10: `basetype` has NO cascade at all even via the proper rule path.]**

---

## 6. The sentinel-default pattern — 20 of 30 columns

Exact count [FACT - awk/grep on udb_object DDL] **[VERIFIED exact — 1 + 20 + 9 = 30:]**:
- **20 / 30** columns are sentinel-defaulted: `default ' '` (varchar/char) or `default 0` (integer). `not null` + sentinel default. **[VERIFIED.]**
- **9 / 30** are genuinely nullable (no `not null`): `source`, `inservice`, `outservice`, `positionx`, `positiony`, `validated`, `locked`, `created`, `lastchanged` — i.e. the dates + `source` + the 2 GIS floats. **[VERIFIED - exact list matches the DDL scan.]**
- **1 / 30** is `not null not default`: the PK `object`. **[VERIFIED.]**

Why sentinel defaults are WORSE than NULL for integrity [INFERENCE, but structurally grounded]:
1. **Cannot distinguish "unknown" from "blank/not-applicable."** `serialnumber = ' '` could mean (a) never entered, (b) intentionally blank, (c) N/A for this type. NULL + a separate convention would separate these; `' '` collapses them. Same for `basetype/type/primarygrouping = 0`: `0` is simultaneously "root/none" AND "not yet resolved" AND a possibly-valid sentinel object id.
2. **Magic-value coupling.** Code must test `= 0` / `= ' '` everywhere (e.g. `object$insert`: `IF (BaseType = 0) THEN ...grasscatcher Object_012`; `IF (PrimaryGrouping != 0) THEN ...`). A real NULL with `IS NULL` is checkable by the engine and by constraints; sentinel `0` is indistinguishable from a legitimate `0`. [FACT - object$insert branches on `=0`] **[VERIFIED - `IF(BaseType = 0) THEN INSERT INTO Udb_GrassCatcher (Object, Problem) VALUES (:Object, 'Object_012')` and `IF (PrimaryGrouping != 0)` both present in object$insert body.]**
3. **`udb_object.object = 0` is explicitly an ERROR state**, guarded by rule `Object$NullObjectProtect AFTER INSERT,UPDATE ON Udb_Object WHERE new.Object = 0 -> reject('Object_014')`. The fact that `0` had to be *banned by a trigger* is direct evidence the sentinel-zero convention leaks a forbidden value into a meaningful column. [FACT - d1.sql:33137] **[VERIFIED exact - rule at d1.sql:33137, `EXECUTE PROCEDURE reject(problem = 'Object_014')`.]**
4. **Aggregations/joins silently include sentinels.** A join `udb_object.basetype = udb_basetype.type` matches the sentinel `0` against any base type whose id happens to be `0`, rather than being eliminated by NULL semantics. [INFERENCE]
5. **No index null-skip benefit; no DBMS-enforced "required" check.** Because the column is `not null default ' '`, the engine can never tell you a value was actually supplied — the app layer must enforce presence, and it does so reactively via grasscatcher problems (`Type_010` "type name blank", `Object_012` "no basetype"), i.e. **post-hoc soft validation instead of hard constraints**. [FACT - Type$Insert, object$insert] **[VERIFIED - `Type$Insert` (d1.sql:32497): `IF Name = '' AND Type != 0 THEN INSERT INTO Udb_GrassCatcher (Object, Text, Problem) VALUES (0, :Name, 'Type_010')`. `Object_012` confirmed in object$insert.]**

The grasscatcher mechanism IS the integrity layer this design substitutes for real constraints: triggers insert `(object, problem)` rows into `udb_grasscatcher`; `udb_problem` holds severity+description per problem code. Validation is **detective, not preventive** (rows are written first, problems flagged after). [FACT - d1.sql:30458 (`Object_012`), 30492 (`Object$Validate` -> `Object_001`), 31831 (`Type_004/005/008/009`), 13973/14473 DDL] **[VERIFIED - Object_012 (object$insert), Type_004/005/008/009 (SuperType$Insert), Type_010 (Type$Insert), Type_001/002 (SuperType$Delete) all read directly from proc bodies.]**

---

## 7. Type universe — what we can and cannot know

- **`udb_basetype` row_estimate = 41** => ~41 base types (physical subtype shapes). The base-type *names* are UNKNOWN (no seed data), but the **`tablename` targets are partially recoverable** from `object$insert`'s string ladder: `Conductor, Generator, Consumer, Capacitor, Reactor, Switch, Transformer, Telemetry, TowerType, ConductorType, Computer, MeasurementType, Person, CombustionTurbine, HydroTurbine, SteamTurbine, FossilSteamSupply, BWRSteamSupply, PWRSteamSupply, CommunicationLink, TelephoneCircuit, EquipTemplate(SLC_)` = **22 named dispatch targets** (subset of the 41). [FACT - object$insert] **[VERIFIED - exactly 22 named branches counted in the ladder. CAVEAT: the `Generator` branch literal is `' Generator'` (leading space) in the source — see §3.1 finding; as written it can only match a tablename value that itself begins with a space.]**
- **`udb_type` row_estimate = 2054** => ~2054 concrete types. The full type list is **[UNKNOWN]** — it lives only in the absent `udb_type.ingres` data file. Do NOT enumerate it. **[VERIFIED - `copy udb_type () from '/home/ingres/Downloads/udb_type.ingres'` references an absent external file.]**
- Specific type/supertype ids appearing as **magic constants** in proc/rule bodies (these ARE in the dump and ARE real, but their human meaning is UNKNOWN without seed rows): `10093` (FMS CardClass base — confirmed by rule `FMS_CardClass$Delete1 WHERE Old.BaseType=10093`), `26` (FMS EquipClass base — rule `FMS_EquipClass$Delete WHERE Old.BaseType=26`), `21` (consumer/load-management basetype — `object$primarygrouping IF (BaseType=21)`), `52` (the "primary grouping" relationship id), `05` (node supertype), `15028` (supertype guard in SuperType$Delete), `999,22173,22174` (obsolete object types — rule `Udb_ObsoleteObjClean`), `10` (line type — rule `Udb_Object$NewCFGLine2 New.Type=10`). [FACT - cited rules/procs] **[VERIFIED EVERY id against the cited body: 10093 (d1.sql:32876 + closure use 29552), 26 (32919), 21 (Object$PrimaryGrouping body), 52 (object$insert + Object$PrimaryGrouping grouping inserts), 05 (Object$PrimaryGrouping closure test), 15028 (SuperType$Delete body 31824-31825), 999/22173/22174 (Udb_ObsoleteObjClean rule 33381 — `New.Type IN (999,22173,22174)`; note the rule ALSO fires on name LIKE '%OBSOLET%'/'%DELETE%'), 10 (Udb_Object$NewCFGLine1 INSERT-rule 33377 AND Udb_Object$NewCFGLine2 UPDATE-rule 33379, both `New.Type = 10`). All ids real; all human meanings remain UNKNOWN without seed rows.]**
- Status enumeration (`udb_object.status char(16)`): **[UNKNOWN]** — no seed rows; not enumerated anywhere in DDL. Type-of-card / class names: **[UNKNOWN]**. **[VERIFIED UNKNOWN - no status literal enumeration found.]**

---

## 8. Mermaid — metamodel resolution path

```mermaid
classDiagram
    class udb_object {
        +int object PK
        int type FK
        int basetype "denormalized FK"
        int primarygrouping "self-ref"
        varchar typename "cache of udb_type.name"
        varchar primarygroupingname "cache of parent.name"
        char status
        int terminals
        ingresdate inservice
        ingresdate outservice
        f4 positionx
        f4 positiony
        char ownernumber
        char serialnumber
        char specnumber
        char combination
        varchar locknumber
        audit validated/locked/created/lastchanged (+by)
    }
    class udb_type {
        +int type PK
        +char name PK
        int basetype FK
        char description
    }
    class udb_basetype {
        +int type PK
        char tablename "-> STI subtype table"
        char editorname "-> OpenROAD frame"
    }
    class udb_supertype {
        int type
        int supertype
    }
    class udb_extendedtype {
        int type
        int supertype "transitive closure + self"
    }
    class udb_switch
    class udb_transformer
    class udb_consumer
    class udb_conductor
    class OpenROAD_Frame
    class udb_grasscatcher {
        int object
        char problem
    }

    udb_object --> udb_type : type = type
    udb_type --> udb_basetype : basetype = type
    udb_basetype ..> udb_switch : tablename='Switch'
    udb_basetype ..> udb_transformer : tablename='Transformer'
    udb_basetype ..> udb_consumer : tablename='Consumer'
    udb_basetype ..> udb_conductor : tablename='Conductor'
    udb_basetype ..> OpenROAD_Frame : editorname (CLIENT only)
    udb_switch --|> udb_object : object 1:1 (STI subtype)
    udb_transformer --|> udb_object : object 1:1
    udb_consumer --|> udb_object : object 1:1
    udb_conductor --|> udb_object : object 1:1
    udb_type --> udb_supertype : type
    udb_supertype ..> udb_extendedtype : closure (SuperType$Insert)
    udb_object ..> udb_grasscatcher : soft-validation problems
```

```mermaid
erDiagram
    udb_object ||--o| udb_switch : "object (STI)"
    udb_object ||--o| udb_transformer : "object (STI)"
    udb_object ||--o{ udb_terminal : "object, terminals"
    udb_object }o--|| udb_type : "type"
    udb_type }o--|| udb_basetype : "basetype -> type"
    udb_type ||--o{ udb_supertype : "type"
    udb_supertype ||--o{ udb_extendedtype : "closure"
    udb_object ||--o{ udb_grasscatcher : "problems"
    udb_problem ||--o{ udb_grasscatcher : "problem code"
```

**[VERIFIED - both Mermaid diagrams are structurally consistent with the verified schema and dispatch logic. Preserved unchanged.]**

---

## 9. Server-side vs client-side split (definitive)

| Concern | Where | Evidence |
|---|---|---|
| STI child-row creation, type resolution, denorm caches, closure maintenance, soft validation | **Server** (db procs in `d1.sql`, fired by Ingres rules) | object$insert, Object$TypeName, SuperType$Insert, rules 33131-33381 [FACT] |
| `editorname` -> which UI editor frame opens | **Client** (OpenROAD, `psm.dmt`) | `editorname` never referenced by any server proc; `BaseType`/`SuperType` logic present throughout psm.dmt [FACT - grep] |

**[VERIFIED - server side confirmed by direct proc/rule reads. `editorname` confirmed absent from every server proc body (only occurrence is the DDL at d1.sql:13365), supporting the client-only conclusion.]**

---

## 10. Open items / UNKNOWNs

- Full `udb_type` catalog (2054 rows), `udb_basetype` catalog (41 rows incl. all `tablename`/`editorname` values), `udb_supertype` edges, `udb_object.status` enumeration — **all UNKNOWN** (external `.ingres` data files absent). [FACT - copy-from statements reference missing files] **[VERIFIED UNKNOWN - `copy <table> () from '/home/ingres/Downloads/<table>.ingres'` load statements present; the .ingres data files themselves are not in the workspace.]**
- Meaning of magic ids `15028`, `52`, `05`, `21`, `26`, `10093`, `999/22173/22174`, `10` — ids are real (in proc/rule bodies) but their seed-row semantics are UNKNOWN. **[VERIFIED - all ids confirmed real (see §7); meanings remain UNKNOWN.]**
- Which of the 41 base types lack an `object$insert` dispatch branch (the ladder names only ~22) — exact gap UNKNOWN without `udb_basetype` data; structurally certain that a gap exists. **[VERIFIED - 22 ladder branches confirmed; 41-22 = at least 19 base types with no insert-time stub branch, but exact identities need seed data.]**
- Whether `udb_object.basetype` can ever legitimately differ from `udb_type.basetype` (it is derived at insert but a later `udb_type.basetype` change is not obviously cascaded to instances) — ~~**potential desync bug, UNVERIFIED**~~ **[CORRECTED -> CONFIRMED DESYNC GAP, VERIFIED. There is NO rule `AFTER UPDATE(BaseType) ON Udb_Type` (the only Udb_Type rules fire on DELETE, UPDATE(Type), UPDATE(Name), INSERT — d1.sql:32787/32876/32919/33218/33368/33370/33372). And NO statement anywhere writes `udb_object.basetype` except `object$insert` at insert time (no `SET BaseType` outside it). Therefore changing `udb_type.basetype` for an existing type silently leaves all already-inserted `udb_object` rows pointing at the stale basetype/wrong STI table. Real latent bug.]** [INFERENCE -> now FACT for the absence of cascade]

---

## Verification

**Verifier:** adversarial SME pass over `d:/103_RnD/psm_v1/d1.sql` (and `ug.html`), reading actual DDL / procedure bodies / rule definitions — not names alone.

### Object existence — 53 / 53 cited objects EXIST. Zero fabricated.
- **41 tables** (`udb_object` … `udb_dsovalve`, plus `SLC_EquipTemplate`): each found exactly once via `create table` scan. SLC_EquipTemplate at d1.sql:8295.
- **14 procedures** confirmed via `create or replace procedure`: `object$insert`, `Object$TypeName`, `Object$Name`, `Object$PrimaryGrouping`, `Object$Validate`, `SuperType$Insert`, `SuperType$Delete`, `Type$Insert`, `Udb$CascadeTypeName`, `CascadeType$Change`, `Udb_TypeIns`, `Udb_TypeUpd`, `Udb_TypeDel`, `Udb_ObsoleteObjClean`. (Each has a forward-declared `... as begin return; end` stub earlier in the file plus the real body later — normal Ingres load ordering.)
- **5 are RULES, not procedures** — and the analyst correctly described them as rules: `Object$Insert1` (33133), `Object$NullObjectProtect` (33137), `Object$Update_Type` (33148), `FMS_CardClass$Delete1` (32876), `FMS_EquipClass$Delete` (32919). Note their rule names differ from the procedure names they invoke (e.g. `FMS_CardClass$Delete1` rule -> `FMS_CardClassDelete1` proc).

### Confirmed verbatim / numerically exact
- All 5 core-table DDLs (`udb_object` 30 cols, `udb_type`, `udb_basetype`, `udb_supertype`, `udb_extendedtype`), plus `udb_terminal`.
- All 5 row_estimates: udb_object **105880**, udb_type **2054**, udb_basetype **41**, udb_supertype **3577**, udb_extendedtype **15441** (each from the table's `copy … from '/home/ingres/Downloads/*.ingres'` load statement; closure/super ratio 4.32x).
- Resolution join in `object$insert` (30457-30458) exact.
- 22-branch STI dispatch ladder (all targets), TelephoneCircuit+CircuitRoute double-seed, EquipTemplate->SLC_EquipTemplate.
- `SuperType$Insert` closure algorithm (delete / reflexive self-edge / one-level closure / Type_008 check) and problem codes Type_004/005/008/009; `SuperType$Delete` Type_001/002 with 15028 guard.
- Every magic id (10093, 26, 21, 52, 05, 15028, 999/22173/22174, 10) located in its cited proc/rule body.
- Sentinel count 1 PK + 20 sentinel-default + 9 nullable = 30, with exact nullable list.
- Both cascade procs (`Udb$CascadeTypeName`, `CascadeType$Change`), `Type$Insert` Type_010, `Object$NullObjectProtect` Object_014, all Object/SuperType rule wiring.
- ug.html PSDM passage (5122-5123).

### Corrected (inline, marked)
1. **§2 prose: "24 … subtype tables" -> 29.** The subtype table directly below lists 29 rows; all 29 verified to have `object` as their first data column. "24" was a counting error.
2. **§3 "editorname … only in the table DDL and in grants" -> DDL-ONLY.** `editorname` occurs exactly once in d1.sql (line 13365, the DDL). It is in NO grant. The core claim (never in a server proc) is correct and stronger than stated.
3. **NEW source-defect finding (§3.1 / §7):** the `Generator` branch literal in `object$insert` is `' Generator'` with a **leading space**. As written it cannot match a `tablename` value of `'Generator'`. Latent dispatch bug the analyst's paraphrase smoothed over.
4. **§10 basetype desync: "UNVERIFIED" -> CONFIRMED.** No `AFTER UPDATE(BaseType) ON Udb_Type` rule exists and nothing writes `udb_object.basetype` outside `object$insert`; a later `udb_type.basetype` change does NOT cascade to existing instances. Real latent bug.
5. **Minor line-citation drift (informational, values correct):** several "[FACT - d1.sql:NNNN]" line numbers for `row_estimate`/storage and a couple of table-DDL end lines are off by a few lines (e.g. row_estimate lines belong to `copy` statements, not `modify`; `udb_terminal` closes at 15004 not 15006). All cited VALUES and object identities are correct.
6. **Minor (not errors):** `SuperType$Insert` also self-touches Udb_SuperType to re-fire closure on descendants; `Object$Insert1` rule does not pass BaseType (the proc derives it); `udb_terminal.inservice/outservice` are NOT populated by the insert proc, so "denormalized copies" there is inference, not proven.

### Residual UNKNOWNs (unchanged — genuinely unresolvable from artifacts present)
- `udb_type` (~2054), `udb_basetype` (~41), `udb_supertype` edges, `udb_object.status` char(16) enumeration — all live in absent `/home/ingres/Downloads/*.ingres` files.
- Human meaning of magic ids 15028, 52, 05, 21, 26, 10093, 999/22173/22174, 10.
- Exact identities of the ~19+ base types lacking an `object$insert` dispatch branch.
- `udb_basetype.editorname` -> OpenROAD frame bindings (server-side file is d1.sql; bindings live in psm.dmt — out of scope here).
