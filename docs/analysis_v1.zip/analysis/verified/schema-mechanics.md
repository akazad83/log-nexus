# Schema Mechanics — PSM (Ingres) — VERIFIED Analysis

> **VERIFICATION STAMP (adversarial pass, 2026-06-12):** All 90 cited objects confirmed to EXIST in `d1.sql` EXCEPT **`udb_temp`** (FABRICATED as a base table — see §1.3 correction). All four load-bearing proc/rule bodies were read in full and match the prior analyst's quotes. Headline counts (450/377/2450/1225/290/208/4835/180/35/0-index/0-lockmode/3-systemversion) all re-derived and CONFIRMED. Corrections are marked inline as **[CORRECTED]**. See `## Verification` footer for the full ledger.

Primary source: `d:/103_RnD/psm_v1/d1.sql` (33,392 lines, authoritative Ingres DDL/dump).
Every claim tagged `[FACT - file->object]`, `[INFERENCE]`, or `[UNKNOWN]`. Counts are grep/awk-derived, reproducible.

---

## 0. Headline mechanics (one paragraph)

PSM is a **metamodel-driven, integrity-in-code** Ingres database. There is **zero declared referential integrity, zero declared CHECK constraints, and zero declared PRIMARY KEY / UNIQUE constraints** in the DDL `[FACT]`. Identity, uniqueness, FK enforcement, cascade, validation, denormalized-cache sync, history capture, and archival are ALL implemented imperatively — in 1,225 server procedures, 290 Ingres rules (triggers), and 208 dbevents (async pub/sub). Uniqueness is enforced *physically* via `modify ... to <struct> unique on <cols>` storage statements (377 of 450 tables), not declaratively. Security is flat: all 4,835 grants go to `public`; there are no named roles. `[FACT - all counts re-verified]`

---

## 1. STORAGE / INDEX

### 1.1 Structure tally (450 `modify` statements) `[FACT - d1.sql -> ^modify lines]`

| Structure | Count | % | Notes |
|---|---:|---:|---|
| btree  | 367 | 81.6% | default choice; range + equality |
| hash   | 42 | 9.3% | exact-match keys (e.g. `cac_lastkey`, `fms_3manomaly`) |
| heap   | 26 | 5.8% | unkeyed scratch/queue tables (e.g. `ddb_recoverytimeout`, `egis_nfload`, all `with extend=16`) |
| isam   | 15 | 3.3% | static lookup/config (e.g. `allapp_systemparameters`, `ddb_status`) |
| **total** | **450** | | one structure per base table (1:1 with 450 tables) |

`[VERIFIED 2026-06-12: btree 367 / hash 42 / heap 26 / isam 15 = 450, exact. `ddb_recoverytimeout` and `egis_nfload` both `to heap with extend=16`, confirmed.]`

`modify ... unique on` = 377 `[FACT - re-counted, exact]`; non-unique keyed (`to btree on` without `unique`) = remainder (e.g. `cfg_group`, `fms_audittrail`, `fms_archivecard`, `fms_archivelog` — append-heavy log/audit tables deliberately NOT unique). `[FACT - fms_audittrail modify confirmed `to btree on (entity, handle, ...)` non-unique]`

Sample format (column list is on the **following line**, multi-line):
```
modify udb_object to btree unique on
	object
modify cac_lastkey to hash unique on
	tablename
modify fms_audittrail to btree on        <-- NON-unique: audit log allows dup keys
```

### 1.2 Primary "keys" = the `on` columns of the unique structure `[INFERENCE]`

There is NO declared PK. The de-facto PK of each table is the `unique on (...)` clause of its `modify`. Examples `[FACT]`:

| Table | Structure | Key column(s) |
|---|---|---|
| `udb_object` | btree unique | `object` (single surrogate int) |
| `udb_lastkey` | (hash unique, see §2) | `lastkey` |
| `cac_lastkey` | hash unique | `tablename` |
| `cac_cardtype` | btree unique | `type, cardtype` (composite) |
| `dso_connection` | btree unique | `fromobj, ...` (composite) |
| `allapp_systemparameters` | isam unique | `rowkey` |

`[VERIFIED: `modify udb_object to btree unique on object` confirmed verbatim.]`

### 1.3 Secondary indexes: NONE `[FACT - d1.sql]`

- `create index` count = **0** `[FACT - re-counted, exact]`.
- **[CORRECTED]** ~~Only ONE table has >1 `modify`: `udb_temp` (3 modifies) — a scratch/staging table reorganized repeatedly, not a secondary index.~~ **This was WRONG on two counts.** (a) **No base table has >1 `modify`** — all 450 `modify` targets are distinct (verified: `awk '{print $2}'|sort|uniq -c` shows max count = 1). (b) **`udb_temp` is not a table.** The prior analyst confused three *separate* heap tables `udb_temp$audittrail`, `udb_temp$objectlist`, `udb_temp$terminallist` (lines 14927/14949/14972, each `to heap`, each populated by `copy ... from '/home/ingres/Downloads/udb_temp_*.ingres'`) for one table with 3 modifies. `[FACT - corrected]`
- **Conclusion (unchanged): each base table has exactly one storage structure (its clustering key) and no secondary indexes.** Any non-key lookup is a full scan. `[INFERENCE - severe for large tables fms_/soa_; the conclusion strengthens — it is now 450/450, not "all but one"]`

---

## 2. KEYS — surrogate-key pattern (`lastkey`-driven `object` ids)

**Confirmed: consistent surrogate-int key pattern centered on `udb_object.object`.** `[FACT]`

- `udb_object.object integer not null not default` is the PK; btree unique on `object` `[FACT - udb_object DDL + modify, both read verbatim]`.
- Sequence allocators are **`*_lastkey` tables** (one row per logical table): `udb_lastkey`, `cac_lastkey`, `tc_lastkey`, `msg_lastkey`, `soa_joblastkey`, `soa_loglastkey` `[FACT - all 6 `create table` confirmed]`.
  - `udb_lastkey(lastkey char(40) not null, value integer not null)` `[FACT - DDL read verbatim]`
  - `cac_lastkey(tablename varchar(24), lastkey integer)` `[FACT - DDL read verbatim]`
  - `soa_joblastkey(rowkey integer, value integer)` `[FACT - DDL read verbatim]`
- Allocation proc pattern (`CAC_KeyGenerator1`, **real body at line 27839** — body read in full and matches) `[FACT - VERIFIED verbatim]`:
  ```sql
  UPDATE "ingres".CAC_LastKey SET LastKey = LastKey + 1 WHERE TableName = :TableName;
  NextKey = 0; SELECT :NextKey = LastKey FROM "ingres".CAC_LastKey WHERE TableName = :TableName;
  IF NextKey = 0 THEN RAISE ERROR -99 ...;           -- missing seed row
  ELSEIF TableName='fms_archivelog' THEN UPDATE FMS_ArchiveLog SET RowKey=:NextKey WHERE tid=:RowTID;
  ELSE RAISE ERROR -99 ... ;                          -- unknown table guard
  ```
  i.e. **increment-then-read-back, then stamp the new row by its `tid`.** 8 numbered variants `CAC_KeyGenerator1..8` exist `[FACT - real bodies at lines 27839,27846,27853,27860,27867,27874,27881,27888; each hard-wired to a different log/archive table: fms_archivelog, soa_archivelog, tc_archivelog, soa_log, tc_log, soa_activity, ... — confirmed]`; `lastkey` is referenced in ~152 lines `[FACT]`.
  - **[NOTE - clarification]** Only the **stub** `cac_keygenerator1..8 as begin return; end` is lowercase (line ~21707); the **real bodies** are mixed-case `CAC_KeyGenerator1..8` (line ~27839+). A naive case-sensitive grep for the real body by lowercase name returns nothing — the prior analyst's line-27839 attribution is correct; flag for any downstream re-grepping.
- `udb_nextkey` exists only as an empty stub (`as begin return; end`) `[FACT - confirmed: 1 def, stub]` — the real allocators are the `CAC_KeyGenerator*` / per-module key procs.

`~152` lastkey references + 6 lastkey tables ⇒ surrogate keys are pervasive and central. `[INFERENCE]`

---

## 3. INTEGRITY — declared vs in-code (DISAMBIGUATED)

### 3.1 Declared integrity: NONE `[FACT - decisive]`

| Construct | Raw grep hits | Real DDL constraints | Verdict |
|---|---:|---:|---|
| `references` | 450 | **0** | all 450 are `grant references ... to public` — privilege grants, NOT FK clauses `[FACT - grant references count = 450, exact]` |
| `foreign key` | 0 | 0 | no declared FKs `[FACT]` |
| `primary key` | 0 | 0 | no declared PKs `[FACT]` |
| `check (` | 25 | **0** | all 25 are table names containing "check" (`fms_phasecheck`, `fms_jobcheck`, `soa_visiblebreakcheck`) or proc names (`*DelayCheck`, `REP_DateCheck`) — NOT CHECK constraints `[FACT]` |
| `unique` (declarative) | 0 in create-table | 0 | uniqueness lives in `modify ... unique`, not constraints `[FACT]` |

`not null` appears 4,727× — that IS used (column nullability), but it is the ONLY declared integrity in the schema. Most columns are `not null default ' '`/`default 0` (sentinel-defaulted), a few date/coord columns are nullable `[FACT - udb_object: 9 nullable date/coord cols, confirmed from DDL: inservice, outservice, positionx/y, validated, locked, created, lastchanged]`.

### 3.2 Integrity-in-code: PROVEN

The absence above forces all RI into procedures + rules. Proof points `[FACT - all bodies below read in full]`:

- **Cascade delete (hand-coded):** `CAC_CO_GroupingDel` (**real body line 27789**, prior analyst said ~27791 — within rounding) deletes from 7 child tables in sequence with manual `IF iierrornumber <> 0 THEN return -1` after each:
  `CAC_CO_Circuit, CAC_CO_Feeder, CAC_CO_Info, CAC_CO_Note, CAC_CO_Note_Link, CAC_CO_Status, CAC_CO_Attachment` — all keyed by `Grouping`. No `ON DELETE CASCADE` exists; this replaces it. `[FACT - VERIFIED verbatim: exactly these 7 DELETEs in this order]`
- **FK-existence validation (rule-driven):** rules like `FMS_JobClassCtrl$Insert1` call `FMS_ValidateEquipClass(...)` AFTER INSERT — parent-existence check done post-hoc in a proc, recording violations instead of rejecting at write time. `[FACT - rule on FMS_JobClassControl confirmed present; FMS_JobClassControl is the 5th-hottest rule target]`
- **Domain validation via exception tables (not rejection):** `Conductor$Validate` (**real body line 27992**): `IF (X/R) < 5 THEN INSERT INTO "ingres".Udb_GrassCatcher(Object,Problem) VALUES(:Object,'Conductor_001')`. Violations are logged, not blocked. `[FACT - VERIFIED verbatim]`
  - Exception/"grass-catcher" tables: `udb_grasscatcher(object, problem char(20), text char(20), known integer)`, `udb_problem(problem char(20), severity char(1), description char(60))`, `fms_mhproblem`, `soa_connectivityproblem`, `tc_problemtracker`, `pvl_xref_exception` `[FACT - udb_grasscatcher & udb_problem DDL read verbatim; note `text` and `problem` are fixed char(20), not free text]`. `udb_grasscatcher.problem` → `udb_problem.problem` is the (undeclared) severity lookup. `[INFERENCE]`

**Conclusion: PSM is a validate-and-log, eventually-flag integrity model — not a reject-at-write model. Bad data can land; rules/procs surface it into problem tables.** `[INFERENCE - high severity]`

---

## 4. SECURITY — grants/revokes

### 4.1 Grants (4,835) `[FACT]` — flat, everything to `public`

Grantee tally: **`public` = 4,835 (100%)**. **No named roles/users.** `[FACT - re-verified: grep of all `^grant` lines NOT ending `to public` returns ZERO rows]`

| Privilege | Count | Target |
|---|---:|---|
| execute | 1,225 | procedures (1:1 with the 1,225 real procs) |
| references | 450 | tables (1:1 w/ tables) |
| select | 449 | tables |
| update | 448 | tables |
| insert | 448 | tables |
| delete | 448 | tables |
| copy_into | 448 | tables |
| copy_from | 448 | tables |
| register | 208 | dbevents (1:1 w/ dbevents) |
| raise | 202 | dbevents |
| modify | 49 | tables |

`[VERIFIED 2026-06-12: every count in this table re-derived and EXACT.]`

Per base table the standard 7-grant block is issued to public: `select, update, delete, insert, references, copy_into, copy_from` `[FACT - e.g. allapp_systemparameters, ddb_reptargetstatus]`. **Net effect: any connected client has full DML + DDL-ish (modify/copy/references) + execute on everything.** `[INFERENCE - high severity: no privilege separation]`

### 4.2 Revokes (180) `[FACT]` — all `revoke execute ... from public cascade`

100% are `revoke execute on procedure X from public cascade` `[FACT - re-verified: 180/180 match this exact pattern, zero exceptions]`. These lock down **internal-only procs** that must not be called by clients directly, e.g. the rule-target/key procs: `cac_keygenerator1..8`, `cardtype$delete/$insert/$typedelete`, `cascadetype$change`, `conductor$validate`, `consumer$updateloadmodel`, `csd_message$ins`, `ddb_logentry` `[FACT - cac_keygenerator1..8 and cascadetype$change revokes read verbatim immediately after their real bodies]`. **Pattern: grant execute to all, then revoke the trigger-only / sequence-only procs so they're invoked solely by rules.** `[INFERENCE]`

### 4.3 Dbevent security `[FACT]`

`grant register` = 208 (all dbevents), `grant raise` = 202 `[FACT - re-counted, exact]`. The 6 dbevents that are **register-only (no raise grant to public)** — server-raised only, clients may subscribe but not publish: `ddb_logentry, fms_deadmovescount, fms_estimateduptime, fms_invalidcard, fms_update_grounds, sds_dbunload` `[FACT - spot-checked: `ddb_logentry` and `fms_update_grounds` each have `grant register on dbevent` but NO `grant raise`; both are raised server-side by procs `DDB_LogEntry` / the `FMS_Update_Grounds :DBEventText` raise — confirmed]`.

---

## 5. TEMPORAL / AUDIT — hand-rolled history (no system-versioning)

### 5.1 Archive twin tables — 35 `<module>_archive*` `[FACT - re-counted: exactly 35 `create table *_archive*`]`

Manual soft-history: live rows are copied to a parallel `*_archive*` table then deleted. **No DBMS temporal feature is used.** Proof: proc bodies do `INSERT INTO X_Archive SELECT ... FROM X WHERE ...` then `DELETE` (e.g. `FMS_ArchivePhaseCheck` block ~line 28435: `INSERT INTO FMS_ArchivePhaseCheck (...) SELECT ... FROM FMS_PhaseCheck WHERE Card=...`) `[FACT - pattern confirmed on sampled procs; not exhaustively proven for all 35 — see UNKNOWN]`. Archive INSERTs observed for `TC_ArchiveReportStats, SOA_ArchiveLog, ...` `[FACT]`.

Full archive list (35), **re-derived from DDL and matches the prior analyst's list verbatim** `[VERIFIED]`: `cac_archiverelayops, cac_archiverocontrol, fms_archivecard, fms_archivefeederlog, fms_archivejob, fms_archivejobdelaylink, fms_archivelog, fms_archivenotifications, fms_archiveoperatingstep, fms_archivephasecheck, fms_archiveworkpermit, fms_archivewpprotection, gta_archivemessage, msg_archivemessage, oa_archiveaccounting, slc_archiveinfitem, slc_archiveinfitemequip, slc_archivewpequiplinks, soa_archivecardlog, soa_archiveisolink, soa_archivejob, soa_archivelog, soa_archiveoutage, soa_archiveworkpermit, tc_archivecard, tc_archivecircuitslog, tc_archivejob, tc_archivelog, tc_archiveoperatingstep, tc_archivereportstats, tc_archiveworkpermit, tfms_archivecard, tfms_archivecardprepby, tfms_archivecardtoobject, tfms_archivechecklist`. Several archive tables use `to btree on` (NON-unique) — append-only history `[FACT - fms_archivecard, fms_archivelog]`. Archive is also fired async via `RAISE DBEVENT SOA_ArchiveTrigger :ControlText` `[FACT]`.

### 5.2 Per-row audit columns — centralized on `udb_object`, sparse elsewhere `[FACT]`

`udb_object` carries the full audit/lock column set `[FACT - udb_object DDL read verbatim]`:
`created, createdby, lastchanged, lastchangedby, validated, validatedby, locked, lockedby` (dates are `ingresdate` nullable; `*by` are `char(24) not null default ' '`).
Prevalence: `createdby` appears on only ~4 tables; `lastchangedby` sparse `[FACT]`. **Audit columns are NOT a universal row pattern — they live on the central object table and a few feature tables.** `[INFERENCE]`

### 5.3 Audit-trail table — `fms_audittrail` `[FACT - DDL read verbatim]`

One dedicated change-log table:
```
fms_audittrail(rowkey integer, entity varchar(32) not null, handle integer, logtime ingresdate not null,
  operator integer, item varchar(32) not null, old varchar(200), new varchar(200),
  operatorname varchar(40), handlename varchar(40))    -- modify ... to btree ON (entity, handle, ...) non-unique
```
Classic (entity, item, old→new, operator, time) field-level audit row, populated in code `[FACT - DDL; population path INFERENCE]`. Companion `*history` tables: `fms_groundhistory, fms_highpothistory, soa_hipothistory, soa_scenariohistory(+jobs), tv_bogeyhistory, udb_groupinghistory, cac_relay_groupinghistory` — domain-specific history written by rules (see §7) `[FACT - fms_groundhistory, fms_highpothistory, udb_groupinghistory confirmed as tables]`.

---

## 6. CONCURRENCY

- **`set lockmode` = 0 occurrences in d1.sql** `[FACT - re-verified, decisive: 0]`.
  ⚠️ **CONTRADICTION with Phase-0 ground truth ("8 'set lockmode' usages") — CONFIRMED REAL.** Those 8 are NOT in the SQL dump; they are presumably in the OpenROAD `.dmt` 4GL client files (`psm.dmt` / `psm_4glprocs.dmt`, both present in the project dir), not the server schema. **In the server DB there is no explicit lock-mode tuning.** `[FACT/INFERENCE]`
- **Optimistic-lock signal:** `systemversion integer not null default 0` on exactly 3 tables: `udb_object, udb_grouping, udb_groupinghistory` `[FACT - re-verified: column appears at lines 14004 (udb_grouping), 14038 (udb_groupinghistory), 14391 (udb_object) — exactly 3 base tables]`. Intended as a version/optimistic-concurrency token on the core metamodel rows `[INFERENCE]` — but it is NOT enforced by any constraint; any check is in app/proc code `[INFERENCE - enforcement on UPDATE not visible in sampled proc bodies, remains UNKNOWN]`.
- **Pessimistic-lock signal:** `udb_object.locked (ingresdate) / lockedby (char(24))` — an application-level row-checkout/edit-lock, distinct from DBMS locks `[INFERENCE - udb_object DDL]`. Also `validated/validatedby` = approval workflow stamp `[INFERENCE]`.
- **Key-allocation concurrency:** relies on the `UPDATE CAC_LastKey SET LastKey=LastKey+1` write-lock to serialize concurrent key requests under Ingres default locking — no explicit lockmode, no sequence object `[INFERENCE - CAC_KeyGenerator1 body confirmed]`. Risk: lock contention hotspot on each `*_lastkey` single row under load `[INFERENCE - medium]`.
- `readlock/nolock` referenced in only ~5 lines `[FACT]`.

---

## 7. RULES (290) + DBEVENTS (208)

### 7.1 Rules — trigger verb & target distribution `[FACT - 290 rules re-counted, exact]`

Trigger verbs (case-combined): INSERT ~112, UPDATE ~119, DELETE ~59. Hottest target tables (approximate — see correction below):

| Target table | # rules (analyst) | # rules (verifier re-tally) |
|---|---:|---:|
| `Udb_Grouping` | 20 | ~29 |
| `FMS_ObjectStatus` | 14 | ~25 |
| `FMS_Card` | 20 | ~23 |
| `Udb_Object` | 18 | ~19 |
| `SOA_Job` | 15 | ~17 |
| `TC_Job` | 9 | ~11 |
| `Udb_Type` | 7 | ~8 |
| `FMS_OperatingStepStatus` | 7 | ~8 |
| `FMS_JobClassControl` | 5 | ~5 |

**[CORRECTED - low severity]** The prior per-table counts are **understated and the ordering is slightly off.** A re-tally (extracting the table after `ON`/`INTO`/`FROM` from each `create rule` line) puts **`Udb_Grouping` clearly first (~29)**, then `FMS_ObjectStatus` (~25), `FMS_Card` (~23), `Udb_Object` (~19), `SOA_Job` (~17). Both tallies are approximations (multi-action rules `AFTER INSERT, UPDATE ON` and `WHERE`-clause column refs complicate exact attribution), so neither column is authoritative to ±1, but the **relative hotspot ranking is the load-bearing takeaway and it holds**: the metamodel grouping/object tables plus the FMS status/card tables carry the bulk of trigger logic. `[FACT - values; exact per-table count requires a disambiguated parser]`

All rules are `AFTER {INSERT|UPDATE(col)|DELETE} ON <t> [WHERE ...] EXECUTE PROCEDURE <proc>(args=New./Old.cols)` — **statement-pattern: thin rule → fat proc.** `[FACT - confirmed across sampled rules]`

### 7.2 Rule classification (sampled bodies, exact) `[FACT - rows marked ✓ had their proc body or rule line read in full]`

| Rule | Class | What it does | Verified |
|---|---|---|---|
| `CardType$Delete` (AFTER DELETE ON Cac_CardType) | **cascade** | `CardType$Delete(Type,CardType)` removes dependents | ✓ rule line 32781 |
| `CardType$TypeDelete` (AFTER DELETE/UPDATE(Type) ON Udb_Type) | **cascade/RI** | propagate type deletion | — name only |
| `CascadeType$Change` (AFTER UPDATE(Type) ON Udb_Object WHERE New.Type<>Old.Type) | **denormalized-cache sync** | body (line 27983): `UPDATE "ingres".Udb_Grouping SET MemberType=:Type WHERE Member=:Object; UPDATE "ingres".Udb_Grouping SET GroupingType=:Type WHERE Grouping=:Object` — keeps the cached type copies in `udb_grouping` consistent with `udb_object.type` | ✓✓ **body read verbatim, exact match** |
| `Consumer$UpdatePQ` (AFTER UPDATE ON Udb_Consumer WHERE Pfixed/Pnom/Qfixed/Qnom changed) | **denormalized recompute** | `Consumer$UpdateLoadModel(...)` recomputes load-model cache | ✓ proc real body exists |
| `Conductor$Insert2/$Update` (Udb_Conductor) | **validation→exception table** | `Conductor$Validate` (line 27992) writes `Udb_GrassCatcher` if X/R<5 | ✓✓ **body read verbatim** |
| `FMS_JobClassCtrl$Insert1/2` (FMS_JobClassControl) | **validation** | `FMS_ValidateEquipClass / ValidateStepPair(Problem='...')` post-hoc FK check | ✓ rule target present |
| `FMS_GroundHistory1/2/3` (INS / UPD(StatusCount) / DEL ON FMS_ObjectStatus WHERE Status IN(10016,10053)) | **history capture** | `FMS$GroundHistoryIns(...)` appends to `fms_groundhistory` with before/after counts | ✓✓ **all 3 rule lines read (32931/32934/32937), `IN (10016,10053)` exact** |
| `FMS_JobClassCtrlSeqIns/Upd` (FMS_JobClassControl) | **resequencing/derived order** | `FMS_JobClassResequence(...)` renumbers Seq | — name only |
| `FMS_Feeder_Cutout1/2` (INS/DEL ON FMS_ObjectStatus WHERE Status=10110) | **derived-state maintenance** | toggles feeder cutout state | ✓✓ **rule lines 32927/32929 read, `Status = 10110` exact** |
| `CSD_Message$Ins` (AFTER INSERT INTO CSD_Message) | **async notify** | proc body = `RAISE DBEVENT CSD_MessageSend` (rule→dbevent bridge) | ✓ proc real body exists |
| `DDB_RepStatusUpd` (AFTER UPDATE(Status) ON DDB_RepTargetStatus) | **denormalized label sync** | `DDB_RepStatusDescUpd(Status)` (body read): `IF Status=0 THEN UPDATE DDB_RepTargetStatus SET Description='Normal...'; ELSEIF Status=10 THEN ...` keeps status-description text current | ✓✓ **body read verbatim** |

Net rule taxonomy `[INFERENCE]`: (a) cascade/RI enforcement, (b) **denormalized-cache maintenance** (type/typename/status-label/load-model copies kept in sync — `CascadeType$Change`, `DDB_RepStatusDescUpd`), (c) validation-to-exception-table, (d) history capture, (e) derived-state / resequencing, (f) rule→dbevent async fan-out. Hardcoded magic type/status ints (10016, 10053, 10110, 10147, 10134, 52, 91, basetype 26) embedded in WHERE clauses — these are the absent seed-row enums `[FACT - values present in real rule/proc text: 10016 (14×), 10053 (8×), 10110 (2×), 10147 (16×, incl. rule FMS_DODelayCheck), relationship 52 (in FMS ground query line 28415); meanings UNKNOWN without seed rows]`.

### 7.3 Dbevents — async pub/sub notification backbone (208) `[FACT - re-counted, exact]`

Mechanism: server procs/rules `RAISE DBEVENT "ingres". <name> [:payload]`; clients `register`/wait. Confirmed raises with payload `[FACT]`:
`RAISE DBEVENT FMS_Feeder_Change :Msg`, `RAISE DBEVENT SOA_ArchiveTrigger :ControlText`, `RAISE DBEVENT FMS_PhaseCheckCompl :ProcUser`, `RAISE DBEVENT FMS_Status_Change`, `RAISE DBEVENT FMS_AutomationGo`, `RAISE DBEVENT FMS_DeadMovesCount`, `RAISE DBEVENT CSD_MessageSend`, `RAISE DBEVENT DDB_LogEntry`, `RAISE DBEVENT FMS_Update_Grounds :DBEventText`.

Dbevent count by module prefix `[FACT]`:

| prefix | # | prefix | # | prefix | # |
|---|--:|---|--:|---|--:|
| fms | 44 | ir | 35 | soa | 29 |
| tc | 27 | soo | 11 | opnet | 9 |
| xa | 8 | dmz | 7 | ddb | 5 |
| report | 4 | msg | 4 | fra | 3 |
| tm/sds/itc | 2 each | (singletons) | 1 each | | |

Semantic clusters `[INFERENCE from names]`: outage/switching state machine (`soa_*`, `tc_*`, `ir_*`), real-time SCADA/EMS bridge (`xa_*`, `qgis_realtimeupdate`, `fms_status_change`), replication/HA (`ddb_*`, `opnet_*`, `dmz_*`, `replicator_status`), messaging (`msg_*`, `csd_messagesend`, `soo_sendmsg`), monitor lifecycle (`*_startmonitor*`, `*_stopmonitor`, `fms_shutdownmonitor*`). **The real-time automation/notification spine: DB state change → dbevent → background monitor app reacts.** `[INFERENCE - high confidence]`

---

## 8. CRITICAL FINDING — proc bodies: 1,225 stubs + 1,225 real `[FACT - re-verified]`

`d1.sql` contains **2,450 `create or replace procedure`** statements = **two passes** `[FACT - exact count 2,450; stub-pattern `as begin return; end` count = exactly 1,225]`:
1. **1,225 empty stubs** `create or replace procedure X as begin return; end` (lines ~21611–26507) — declare-first so rules/grants can bind. `[FACT]`
2. **1,225 real bodies** `create or replace procedure X (...args...) = BEGIN ...sql... END` (lines ~27762 onward, before rules at 32781). `[FACT - rules block confirmed to start at line 32781 = `CardType$Delete`]`

The real server logic is the second block. "2,450 procedures" is therefore **1,225 distinct procedures**, each declared twice (stub then body). `[INFERENCE - corrects the headline count]` **Caveat for re-grepping:** some real bodies are written `create or replace procedure  ingres.<Name> (...)` (schema-prefixed, double space) and most use mixed-case names while stubs are lowercase — a case-sensitive `\bName\b` grep can miss the real body (this tripped one verification pass; see `FMS_DODelayCheck` real body at line 28704). `[FACT]`

---

## 9. Findings ranked by severity

| # | Severity | Finding | Evidence |
|---|---|---|---|
| 1 | **Critical** | **No declared referential integrity, no CHECK, no PK/UNIQUE/FK constraints** — all integrity is imperative (procs+rules). Bad data is logged to exception tables, not rejected. | `[FACT]` references=450 all grants; FK=0; check-constraints=0; PK=0 |
| 2 | **Critical** | **Flat security: 4,835 grants → `public` only, no roles.** Every client has full DML + `modify`/`copy`/`references` + execute. Only mitigation is 180 `revoke execute ... cascade` on trigger-only procs. | `[FACT]` grantee tally 100% public (0 non-public grants) |
| 3 | **High** | **No secondary indexes** (`create index`=0); one clustering structure per table (450/450). Non-key access = scan on large `fms_`/`soa_` tables. | `[FACT]` |
| 4 | **High** | **Denormalized type/typename/status caches** kept consistent only by rules (`CascadeType$Change`, `DDB_RepStatusDescUpd`). Any rule disablement or direct-SQL bypass silently desynchronizes `udb_object` vs `udb_grouping`. | `[FACT]` body of CascadeType$Change read verbatim |
| 5 | **High** | **Integrity logic is double-maintained** — 1,225 stubs vs 1,225 real bodies; rules bind by name. Drift risk; a stub left un-replaced = silent no-op trigger. | `[FACT]` |
| 6 | **Medium** | **Key-allocation hotspot:** single-row `UPDATE *_lastkey SET lastkey+1` per insert, no sequence object, no explicit lockmode → serialization point under concurrency. | `[FACT]` CAC_KeyGenerator1 body |
| 7 | **Medium** | **Hand-rolled archival** (35 twin tables, INSERT…SELECT…+DELETE in procs). No temporal/system-versioning; correctness depends entirely on proc code. Some archive tables non-unique. | `[FACT]` 35 confirmed |
| 8 | **Medium** | **Optimistic-lock token `systemversion` present but enforcement unverified** and only on 3 tables; `locked/lockedby/validated*` are app-level, not DBMS. | `[FACT]` 3 tables; enforcement `[UNKNOWN]` |
| 9 | **Low/Data-quality** | **Magic ints everywhere** in rule WHERE clauses (status 10016/10053/10110, operatingstep 10147, type 91/26, relationship 52). Meanings live in absent seed rows → semantics `[UNKNOWN]`. | `[FACT]` values present |
| 10 | **Doc-discrepancy** | **Ground-truth "8 set lockmode" not in d1.sql (0 found)** — those usages are in `.dmt` client 4GL, not the server schema. | `[FACT]` 0 in d1.sql |

---

## 10. Mermaid — integrity/automation control flow

```mermaid
flowchart TD
  C[Client / OpenROAD frame] -->|execute proc| P[Server procedure 1,225 real]
  P -->|UPDATE *_lastkey +1| K[(udb/cac/tc *_lastkey)]
  P -->|INSERT/UPDATE/DELETE| T[(Base table e.g. udb_object)]
  T -->|AFTER trigger| R[Ingres rule 290]
  R -->|EXECUTE PROCEDURE New./Old.| P2[Trigger proc revoked from public]
  P2 -->|cascade DELETE children| T2[(child tables)]
  P2 -->|denorm sync MemberType/GroupingType| G[(udb_grouping cache)]
  P2 -->|validation fail| X[(udb_grasscatcher / *_problem)]
  P2 -->|history INSERT| H[(fms_groundhistory / *_history)]
  P2 -->|archive INSERT..SELECT + DELETE| A[(*_archive 35 tables)]
  P2 -->|RAISE DBEVENT :payload| E((dbevent 208))
  E -->|register/wait| M[Background monitor / UI / SCADA bridge]
  M -->|reacts: refresh, automate, push| C
```

---

## 11. Gaps / UNKNOWN

- Meaning of all status/type/relationship integer codes (10016, 10053, 10110, 10147, 91, 26, 52, ...) — require absent seed rows. `[UNKNOWN]`
- Exact `systemversion` enforcement (is it checked on UPDATE?) — not visible in sampled procs. `[UNKNOWN]`
- Whether all 35 archive tables are actively populated — INSERT…SELECT confirmed only on a sampled subset; uniform pattern inferred. `[INFERENCE - pattern uniform]`
- The 8 `set lockmode` from Phase-0 are not in d1.sql; their actual location/intent unverified here (likely `psm.dmt`/`psm_4glprocs.dmt`). `[UNKNOWN - likely .dmt]`
- Full per-table key-column catalog (450 rows) not exhaustively transcribed — method given in §1.2; sampled ~60. `[partial]`
- Exact per-table rule counts (§7.1) — approximations; a disambiguated parser is needed for ±1 accuracy. The relative ranking is sound. `[partial]`

---

## Verification

**Verifier:** adversarial pass, 2026-06-12. Method: every cited object existence-checked via grep/awk against `d1.sql`; four most load-bearing proc/rule bodies read in full; every headline count independently re-derived.

### CONFIRMED (exact, re-derived)
- **Object existence:** 89 of 90 cited objects EXIST. All cited tables, procs (incl. all 8 `CAC_KeyGenerator1..8` real bodies), rules, and the `DDB_Logs` view are present. `udb_winding, udb_kvlevel, udb_supertype, udb_basetype, udb_extendedtype` and all `*_lastkey` tables confirmed.
- **Counts (all exact):** 450 tables / 450 modify / 377 unique-on / 0 `create index` / 0 `set lockmode` / 2,450 proc defs / 1,225 stubs / 290 rules / 208 dbevents / 4,835 grants (100% public, 0 non-public) / 180 revokes (100% `revoke execute … from public cascade`) / 35 archive tables / 3 `systemversion` tables. Grant-by-privilege table (§4.1) and structure tally (§1.1, 367/42/26/15) re-derived exactly.
- **Proc/rule bodies read verbatim and matching:** `CAC_KeyGenerator1` (line 27839), `CascadeType$Change` (27983), `CAC_CO_GroupingDel` (27789, all 7 child DELETEs), `Conductor$Validate` (27992), `DDB_RepStatusDescUpd`, rules `FMS_GroundHistory1/2/3` (`IN (10016,10053)`), `FMS_Feeder_Cutout1/2` (`Status=10110`), `FMS_DODelayCheck` (`OperatingStep=10147`). Magic ints 10016/10053/10110/10147/52 confirmed present in real text.
- **DDL read verbatim and matching:** `udb_object` (incl. `systemversion`, full audit/lock column set), `udb_lastkey`, `cac_lastkey`, `soa_joblastkey`, `udb_grasscatcher`, `udb_problem`, `fms_audittrail`.
- **Phase-0 contradiction CONFIRMED:** "8 set lockmode" = 0 in d1.sql. The "1 view" gap RESOLVED: it is `DDB_Logs`, a `UNION ALL` over `fmsddb_log`/`tcddb_log`/… (out of core schema-mechanics scope but now identified).

### CORRECTED
1. **§1.3 — `udb_temp` is FABRICATED as a base table.** `grep '^create table udb_temp('` = 0. The "table with 3 modifies" was a misread of **three separate heap tables** `udb_temp$audittrail`, `udb_temp$objectlist`, `udb_temp$terminallist` (each with ONE `modify … to heap`, each loaded via `copy … from`). **Stronger corrected fact:** NO base table has >1 `modify` — all 450 modify targets are distinct, so the "no secondary indexes" conclusion is now 450/450, not "all but one." This is the only fabricated object in the cited list.
2. **§7.1 — per-table rule counts understated / order slightly wrong (low severity).** Re-tally puts `Udb_Grouping` clearly first (~29, not tied-20) and surfaces `FMS_ObjectStatus` (~25) above `FMS_Card` (~23). Both the analyst's and verifier's tallies are approximations; the relative hotspot ranking (the load-bearing point) holds. Table annotated with both columns.
3. **Minor line-number drift (cosmetic, not errors):** `CAC_CO_GroupingDel` real body is line 27789 (analyst: ~27791); the analyst's tilde-approximations are otherwise accurate.
4. **§3.2 / §5.3 — column-type precision added:** `udb_grasscatcher.text` and `.problem` are fixed `char(20)` (not free text); `udb_problem` is `(problem char(20), severity char(1), description char(60))`. Substance unchanged.

### RESIDUAL UNKNOWNS (carried forward, legitimate)
- All integer code meanings (status/type/relationship enums) — absent seed rows. `[UNKNOWN]`
- `systemversion` optimistic-lock enforcement on UPDATE — not in sampled bodies. `[UNKNOWN]`
- Location/intent of the 8 `set lockmode` — almost certainly in `psm.dmt`/`psm_4glprocs.dmt` 4GL, not verified here. `[UNKNOWN]`
- Population of all 35 archive tables — subset proven, uniform pattern inferred. `[INFERENCE]`
- Exhaustive 450-row key-column catalog and ±1-exact per-table rule counts. `[partial]`

**Verdict: minor-issues.** One fabricated object (`udb_temp`), one low-severity tally imprecision (§7.1). Every load-bearing claim — no declared RI, flat-public security, zero secondary indexes, lastkey surrogate-key mechanics, hand-coded cascade/validation/denorm-sync/history/archive, the set-lockmode contradiction — is CONFIRMED against the actual artifact text.
