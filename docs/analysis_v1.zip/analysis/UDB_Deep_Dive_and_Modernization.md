# UDB / PSM Deep Dive and Modernization Assessment

> Con Edison OMS / **PSM (Power System Model)** — a metamodel-driven Actian Ingres database (server logic in DB procedures/rules/dbevents) fronted by an OpenROAD 4GL client. This report reconstructs the metamodel, integrity model, schema mechanics, application logic, operational workflows, and a SQL Server 2025 / .NET modernization plan **entirely from DDL structure + procedure/rule/dbevent bodies + the user guide** — because the external `.ingres` data files are absent (no row data, no seed catalogs, no status enums). Every material claim is tagged `[FACT - file→object]`, `[INFERENCE]`, or `[UNKNOWN]`; enum labels that live in absent seed files are `[UNKNOWN-seed]`. Where sections disagreed, the more evidence-backed claim was kept and the contradiction surfaced.

---

## Table of Contents

- [Phase 0 — Inventory](#phase-0--inventory)
  - [0.1 Artifacts](#01-artifacts)
  - [0.2 Object-type counts](#02-object-type-counts-d1sql)
  - [0.3 Module table counts](#03-module-table-counts)
  - [0.4 Procedure counts by prefix](#04-procedure-counts-by-prefix-approx)
  - [0.5 SAMPLING / COVERAGE caveat (read first)](#05-sampling--coverage-caveat-read-first)
- [Deliverable 1 (Phases 1–2) — Database Analysis](#deliverable-1-phases-12--database-analysis)
  - [1. The inheritance pattern: CLASS-TABLE INHERITANCE, not STI](#1-the-inheritance-pattern-class-table-inheritance-not-sti)
  - [2. The object-resolution mechanism](#2-the-object-resolution-mechanism)
  - [3. Equipment class hierarchy + operating domains](#3-equipment-class-hierarchy--operating-domains-inferred)
  - [4. Closure mechanics (runtime is-a test)](#4-closure-mechanics-runtime-is-a-test)
  - [5. The integrity model — declared vs enforced](#5-the-integrity-model--declared-vs-enforced)
  - [6. Schema mechanics — storage, keys, security, archival, concurrency](#6-schema-mechanics--storage-keys-security-archival-concurrency)
  - [7. Rules + dbevents — the automation spine](#7-rules-290--dbevents-208--the-automation-spine)
  - [8. Design-quality findings, ranked by severity](#8-design-quality-findings-ranked-by-severity)
- [Phases 3–4 — Application Logic + Business Model](#phases-34--application-logic--business-model)
  - [(a) Where business rules live — four tiers](#a-where-business-rules-live--four-tiers)
  - [(b) End-to-end subsystem map: JOB / JOB CLASS / SWITCHING ORDER / OUTAGE](#b-end-to-end-subsystem-map-job--job-class--switching-order--outage)
  - [(c) Reconstructed operational workflows](#c-reconstructed-operational-workflows)
  - [(d) Guide-vs-schema contradictions](#d-guide-vs-schema-contradictions-consolidated)
  - [(e) Migration-critical synthesis](#e-migration-critical-synthesis)
- [Deliverable 2 (Phase 5) — How UDB Works](#deliverable-2-phase-5--how-udb-works)
  - [Layer 1: Object resolution](#layer-1-object-resolution--the-metamodel-engine)
  - [Layer 2: Network-graph traversal](#layer-2-network-graph-traversal--terminal--node--grouping)
  - [Layer 3: Lifecycle of one planned switching order](#layer-3-lifecycle-of-one-representative-planned-switching-order)
  - [How the three layers interlock](#how-the-three-layers-interlock)
- [Deliverable 3 — JOB & JOB CLASS deep-dive](#deliverable-3--job--job-class-deep-dive-and-peer-constructs)
  - [Construct 1 — JOB (the switching move)](#construct-1--job-the-switching-move)
  - [Construct 2 — JOB CLASS (the move template)](#construct-2--job-class-the-move-template)
  - [Construct 3 — SWITCHING ORDER (card + jobs; IR operating order)](#construct-3--switching-order-card--jobs-ir-operating-order)
  - [Construct 4 — OUTAGE (planned & bus-fault)](#construct-4--outage-planned--bus-fault)
  - [Construct 5 — SWITCHING STEP / CARD (StepPair)](#construct-5--switching-step--card-steppair)
  - [Construct 6 — IN-SERVICE PERMIT (ISP/ISWP)](#construct-6--in-service-permit-ispiswp)
  - [Construct 7 — WORK PERMIT](#construct-7--work-permit)
  - [Construct 8 — SESAME LOCK / CLEARANCE](#construct-8--sesame-lock--clearance)
- [Deliverable 4 (Phase 6) — Modernization & Optimization](#deliverable-4-phase-6--modernization--optimization)
  - [Executive ranking](#executive-ranking-value-vs-effort)
  - [1. Target data-model options](#1-target-data-model-options)
  - [2. Critical DB optimizations](#2-critical-db-optimizations)
  - [3. Integration architecture — anti-corruption boundaries](#3-integration-architecture--anti-corruption-boundaries)
  - [4. Migration sequencing](#4-migration-sequencing)
- [Cross-cutting residual UNKNOWNs](#cross-cutting-residual-unknowns)

---

# Phase 0 — Inventory

## 0.1 Artifacts
All in `d:/103_RnD/psm_v1`.

| Artifact | Size | Role | Authoritative for |
|---|---|---|---|
| `d1.sql` | 33,392 lines | Ingres DDL/dump (tables, procs, rules, dbevents, grants) | **All server-side structure + logic** |
| `psm.dmt` | 30,734 lines | OpenROAD frames / UI / menus / `ON` event handlers | Client behavioral surface |
| `psm_4glprocs.dmt` | 8,496 lines | Shared client 4GL procedures (dual-write wrappers) | Client transaction/replication logic |
| `psm_dbprocs.dmt` | 632 bytes / 22 lines | **METADATA STUB** — only `include core.plb`; **NO procedure bodies** | Nothing (ignore) |
| `ug.html` | 12,878 lines | User guide (DBM admin guide) | Business vocabulary/semantics |

**The real server-side business logic is the 2,450 procedure declarations inside `d1.sql`, NOT `psm_dbprocs.dmt`** (a stub). `[FACT]`

## 0.2 Object-type counts (`d1.sql`)
`[FACT - Phase-0 ground truth, cross-checked against section bodies]`

| Object | Count | Notes |
|---|---:|---|
| Base tables | 450 | each loaded via `copy <t> () from '/home/ingres/Downloads/<t>.ingres'` |
| `create or replace procedure` | **2,450** | = **1,225 forward-declaration stubs + 1,225 real bodies** (each proc declared twice). Real logic volume ≈ **1,225 distinct procs** — do NOT treat 2,450 as a logic-volume metric. `[FACT]` |
| Ingres rules | 290 | `create rule … AFTER {INSERT\|UPDATE(col)\|DELETE} … EXECUTE PROCEDURE` |
| Ingres dbevents | 208 | async pub/sub channels |
| Views | 1 | |
| Grants | 4,835 | **100% to `public`** |
| Revokes | 180 | all `revoke execute … from public cascade` |
| `modify … to btree\|isam\|hash\|heap … on …` | 450 | one storage/clustering structure per table |
| Archive twin tables (`<module>_archive*`) | 35 | hand-rolled history |

## 0.3 Module table counts
`[FACT]` `fms_` 114, `soa_` 86, `udb_` 53, `ir_` 38, `tc_` 33, `cac_` 24, `tfms_` 14, `slc_` 11, `pvl_` 10, `fra_` 10, `rtu_` 6, `ddb_` 6, `oa_` 5, `csd_` 4, `sds_` 3, `qgis_` 3, `msg_` 3, `dso_` 3, plus singletons incl. GIS (`nodes_xy`, `objects_xy`, `egis_` 2, `qgis_` 3) and EMS/SCADA (`xa21_` 1, `rtu_` 6). Core metamodel = the **`udb_` family (53 tables)**.

## 0.4 Procedure counts by prefix (approx)
`[FACT - case-combined, ±1]` `fms` ~704, `soa` ~480, `ir` ~268, `tc` ~254, `udb` ~138, `cac` ~82, `fra` ~70, `tfms` ~62, `slc` ~58, `dso` ~52, `pvl` ~32. (These are raw declaration counts; halve for distinct bodies. Distinct **real-body** module split: `fms` ~352, `soa` ~240, `ir` ~134, `tc` 127 — **all 127 TC bodies are stubs**.)

## 0.5 SAMPLING / COVERAGE caveat (read first)

**The external `.ingres` DATA FILES ARE ABSENT.** Every table loads via `copy <t> () from '/home/ingres/Downloads/<t>.ingres'` and those files are not present. Therefore **no row data exists in the dump**:

| Was analyzable (FACT) | Was NOT analyzable (UNKNOWN-seed) |
|---|---|
| All 450 table DDLs (columns, defaults, nullability) | Seed rows of any table |
| 1,225 real procedure bodies + 290 rules + 208 dbevents | `udb_type` catalog (~2,054 type rows) |
| 4,835 grants / 180 revokes / 450 storage `modify`s | `udb_basetype` (~41 rows incl. all `tablename`/`editorname`) |
| Integer/string **literals hard-coded in proc/rule bodies** | `udb_supertype` is-a edges (~3,577) |
| `ug.html` business vocabulary | Every status/jobclass/movetype/movecategory/outagetype enumeration |
| | `udb_problem.severity` dictionary (which problems reject) |
| | Row counts (the `row_estimate` in DDL are loader estimates, NOT counts) |
| | Human meaning of magic ids (05, 21, 26, 52, 10093, 15028, 998, 22173/22174, 10016/10044/10053/10110/10147) |

`psm_dbprocs.dmt` is a 22-line stub (includes `core.plb` only) — irrelevant. **All semantics below are derived from DDL structure + proc/rule/dbevent bodies + `ug.html` ONLY.** Anything requiring the absent seed rows is flagged `[UNKNOWN-seed]` and is never fabricated.

---

# Deliverable 1 (Phases 1–2) — Database Analysis

**One-line verdict:** PSM is a metamodel-driven, **integrity-in-code** Ingres database with **zero declared RI/CHECK/PK/FK constraints**, **flat all-to-`public` security**, **zero secondary indexes**, and a **validate-and-log (detective), not reject-at-write (preventive)** correctness model. `[FACT]`

## 1. The inheritance pattern: CLASS-TABLE INHERITANCE, not STI

The Phase-0 brief and some verified sources call this "single-table inheritance (STI)." **That label is wrong; it is class-table inheritance (CTI).** `[FACT - d1.sql:30457 object$insert + 28 subtype-table DDLs]`

- **STI** = one table holds every subclass; one row per object; a discriminator column selects the class.
- **CTI** = a root table holds common attributes; each subclass has its OWN table with only that subclass's attributes, PK'd 1:1 on the root key; **two rows per object** (one root, one subclass).

PSM is unambiguously CTI:
- Common attributes live in `udb_object` (30 cols, PK `object`) `[FACT - d1.sql:14388-14419]`.
- Subclass attributes live in **separate per-type tables** (`udb_switch`, `udb_transformer`, `udb_conductor`, …), each `modify … unique on object` (1:1) `[FACT]`.
- `object$insert` writes the `udb_object` row, then `INSERT INTO Udb_<Subtype>(Object) VALUES (:Object)` — **two rows, two tables, same `object` id** `[FACT - d1.sql:30462-30471]`.

### 1.1 It is a HYBRID — three subtleties
1. **The discriminator is normalized out into a 3-table type metamodel**, not a discriminator column: `udb_object.type` → `udb_type.basetype` → `udb_basetype.tablename` `[FACT]`.
2. **`udb_object` is itself a wide god-table** — 5 overloaded `char(20)`/`varchar(40)` tag slots (`ownernumber, serialnumber, specnumber, combination, locknumber`), reused per type → STI-like overloading on top of the CTI split `[FACT - DDL; reuse INFERENCE]`.
3. **Not every type has a subtype table.** `udb_basetype.tablename = ''` is a legal no-op branch in `object$insert` — such objects exist ONLY as a `udb_object` row (pure root). PSM is CTI *for the ~22 enumerated subtypes* and *root-only* for the rest `[FACT - d1.sql:30462]`.

**Verdict:** `[INFERENCE - high confidence]` **data-driven class-table inheritance** — a normalized 3-table type/basetype/supertype metamodel as discriminator, a wide common root, optional per-base-type extension tables joined 1:1 on `object`. NOT single-table inheritance.

### 1.2 Subtype-table inventory (28 CTI extension tables) `[FACT - d1.sql DDL]`
`udb_bwrsteamsupply`(13421), `udb_capacitor`(13460), `udb_circuitroute`(13489), `udb_combustionturbine`(13516), `udb_communicationlink`(13546), `udb_computer`(13579), `udb_conductor`(13607), `udb_conductortype`(13642), `udb_consumer`(13672), `udb_dsovalve`(13714), `udb_fossilsteamsupply`(13867), `udb_generator`(13922), `udb_hydroturbine`(14105), `udb_location`(14285), `udb_measurementtype`(14320), `udb_person`(14443), `udb_pwrsteamsupply`(14501), `udb_rating`(14547), `udb_reactor`(14581), `udb_scanblock`(14610), `udb_steamturbine`(14640), `udb_switch`(14707), `udb_tapsetting`(14767), `udb_telemetry`(14834), `udb_telephonecircuit`(14875), `udb_towertype`(15027), `udb_transformer`(15069), `udb_winding`(15132).
- **1:1 on `object`:** most of the above.
- **1:N on `object`** (multi-row extension, NOT pure subtype): `udb_winding`(object,winding), `udb_tapsetting`(object,winding-pair), `udb_rating`(object,type), `udb_terminal`(object,terminal) `[FACT - composite unique keys]`.
- **HEAP, no unique index:** `udb_dsovalve` — `object` uniqueness declared (`not null`) but NOT index-enforced `[FACT - modify udb_dsovalve to heap]`.

## 2. The object-resolution mechanism

Resolution is hard-coded in `object$insert` `[FACT - d1.sql:30457-30458]`:

```sql
SELECT :BaseType = BT.Type, :TableName = BT.TableName
FROM "ingres".Udb_Type T, "ingres".Udb_BaseType BT
WHERE :Type = T.Type AND T.BaseType = BT.Type;
```

```
udb_object.type
  └─> udb_type (T.type=:type)              → T.basetype, T.name
        └─> udb_basetype (T.basetype=BT.type) → BT.tablename  (subtype table  — SERVER dispatch)
                                              → BT.editorname (OpenROAD frame — CLIENT only)
```

- `udb_basetype.tablename` → per-type subtype table (`'Switch'`→`udb_switch`). Server-side dispatch.
- `udb_basetype.editorname` → OpenROAD editor frame. **Client-only:** `editorname` appears EXACTLY ONCE in `d1.sql` (its DDL at line 13365), in NO server proc and NO grant `[FACT]`.
- `udb_object.basetype`, `typename`, `primarygroupingname` are **denormalized caches** written at insert time `[FACT - d1.sql:30460]`.

### 2.1 CONTRADICTION — "data-driven" dispatch is actually HARD-CODED
After reading `TableName`, `object$insert` does **no dynamic SQL** — it runs a **hard-coded `IF/ELSEIF` ladder with exactly 22 named branches**; only those base types get an automatic subclass stub row `[FACT - d1.sql:30462-30471, all 22 read verbatim]`:

`Conductor, Generator, Consumer, Capacitor, Reactor, Switch, Transformer, Telemetry, TowerType, ConductorType, Computer, MeasurementType, Person, CombustionTurbine, HydroTurbine, SteamTurbine, FossilSteamSupply, BWRSteamSupply, PWRSteamSupply, CommunicationLink, TelephoneCircuit (also seeds Udb_CircuitRoute(Object,0)), EquipTemplate (→ SLC_EquipTemplate).`

Implications `[INFERENCE - structurally certain]`:
- ~41 base types exist but only 22 have an insert-time branch → **≥19 base types get NO automatic subclass row** (e.g. `Location, Rating, Winding, TapSetting, ScanBlock, LoadCurve, DsoValve`); their extension rows are created by other paths. Exact identities `[UNKNOWN-seed]`.
- **Adding a base type requires BOTH a `udb_basetype` data row AND a code edit to `object$insert`.** The "data-driven metamodel" claim is half-true.

### 2.2 RESOLVED — the `'Generator'` branch literal is NOT a live bug
A prior analysis claimed a leading-space `' Generator'` dispatch bug. **Raw-byte inspection shows an embedded newline from dump line-wrapping**, not a leading space; the other 21 branches wrap identically (`'Reactor'`, `'Transformer'`, `'TowerType'` all span line breaks). This is almost certainly an Ingres unload line-wrap artifact, NOT a defect `[FACT - d1.sql:30462-30463 raw-byte inspection]`. **Do not assert a live "Generator dispatch bug."** Whether the loader folds the wrap is `[UNKNOWN]`.

### Diagram 1 — Metamodel resolution path
```mermaid
flowchart LR
  OBJ["udb_object<br/>(PK object, 30 cols)<br/>type, basetype*, typename*,<br/>primarygrouping, status, terminals"]
  TYP["udb_type<br/>(type, basetype, name, desc)<br/>~2054 rows [UNKNOWN-seed]"]
  BT["udb_basetype<br/>(type, tablename, editorname)<br/>~41 rows [UNKNOWN-seed]"]
  SUP["udb_supertype<br/>(type, supertype)<br/>direct edges ~3577"]
  EXT["udb_extendedtype<br/>(type, supertype)<br/>TRANSITIVE CLOSURE +self ~15441"]
  SUB["per-type subtype table<br/>udb_switch / _transformer / _conductor ...<br/>PK object (1:1 CTI)"]
  FRAME["OpenROAD editor frame<br/>(psm.dmt — CLIENT ONLY)"]
  GC["udb_grasscatcher<br/>(object, problem)<br/>soft-validation sink"]

  OBJ -->|"type = T.type"| TYP
  TYP -->|"T.basetype = BT.type"| BT
  BT -.->|"tablename → IF/ELSEIF ladder<br/>(HARD-CODED, 22 branches)"| SUB
  BT -.->|"editorname (never read server-side)"| FRAME
  TYP --> SUP
  SUP -.->|"SuperType$Insert maintains"| EXT
  SUB -->|"object 1:1"| OBJ
  OBJ -.->|"validation failures"| GC
  EXT -.->|"polymorphic is-a-kind-of test<br/>WHERE Type IN (SELECT Type FROM udb_extendedtype WHERE SuperType=X)"| TYP

  classDef seed fill:#e2e3e5,stroke:#383d41;
  class TYP,BT seed;
```
\* `basetype`, `typename` on `udb_object` are denormalized caches derived at insert time. `[FACT]`

## 3. Equipment class hierarchy + operating domains (inferred)

`udb_supertype(type, supertype)` stores the is-a/part-of class graph **as data**; `udb_extendedtype` is its materialized transitive closure (reflexive self-edge + all ancestors), maintained by `SuperType$Insert/$Delete` `[FACT]`. **The actual edges live in absent seed data** `[UNKNOWN-seed]` — the hierarchy below is reconstructed from subtype-table column semantics, the steamturbine→steamsupply FK, and operating-domain grouping. It is `[INFERENCE]`, not a transcription of `udb_supertype`.

**Grounded edges (FACTs constraining the hierarchy):**
- `udb_steamturbine.steamsupply integer` = object FK to a steamsupply subtype table `[FACT - d1.sql:14642]`.
- `udb_winding`(1:N), `udb_tapsetting`(1:N) hang off transformer objects → part-of `[FACT]`.
- `udb_conductor` references `towertype`, `phaseconductortype` (→ `udb_conductortype`) `[FACT]`.
- `Object$PrimaryGrouping` does consumer-load arithmetic roll-up only when `BaseType = 21` `[FACT]` → ties `udb_consumer` to the load/distribution domain.
- Node-supertype literal `05`; FMS card-class descendants tested against supertype `10093`; FMS equip-class basetype `26` `[FACT - magic ids in proc/rule bodies]` `[UNKNOWN-seed - labels]`.

### Diagram 2 — Equipment class hierarchy by operating domain (inferred)
```mermaid
classDiagram
  class Object["udb_object (ROOT — every equipment is one)"]

  %% ---- TRANSMISSION / NETWORK (electric) ----
  class Conductor
  class ConductorType
  class TowerType
  class Switch
  class Transformer
  class Winding
  class TapSetting
  class Capacitor
  class Reactor
  class Rating
  Object <|-- Conductor : CTI
  Object <|-- Switch : CTI
  Object <|-- Transformer : CTI
  Object <|-- Capacitor : CTI
  Object <|-- Reactor : CTI
  Conductor ..> ConductorType : phaseconductortype
  Conductor ..> TowerType : towertype
  Transformer *-- Winding : 1:N part-of
  Transformer *-- TapSetting : 1:N part-of
  Object ..> Rating : thermal ratings (object,type)

  %% ---- GENERATION / DYNAMICS (SMS/Steam remnant) ----
  class Generator
  class CombustionTurbine
  class HydroTurbine
  class SteamTurbine
  class FossilSteamSupply
  class BWRSteamSupply
  class PWRSteamSupply
  Object <|-- Generator : CTI
  Object <|-- CombustionTurbine : CTI
  Object <|-- HydroTurbine : CTI
  Object <|-- SteamTurbine : CTI
  Object <|-- FossilSteamSupply : CTI
  Object <|-- BWRSteamSupply : CTI
  Object <|-- PWRSteamSupply : CTI
  SteamTurbine ..> FossilSteamSupply : steamsupply FK
  SteamTurbine ..> BWRSteamSupply : steamsupply FK
  SteamTurbine ..> PWRSteamSupply : steamsupply FK

  %% ---- DISTRIBUTION / LOAD ----
  class Consumer["Consumer (BaseType=21 → load roll-up)"]
  class LoadCurve
  class LoadValue
  Object <|-- Consumer : CTI
  Consumer ..> LoadCurve : load shape
  LoadCurve *-- LoadValue : 1:N time-series

  %% ---- SUBSTATION / SCADA / MEASUREMENT ----
  class Telemetry
  class MeasurementType
  class ScanBlock
  Object <|-- Telemetry : CTI
  Object <|-- MeasurementType : CTI
  Object <|-- ScanBlock : CTI

  %% ---- TELEPHONIC / COMMS ----
  class TelephoneCircuit
  class CircuitRoute
  class CommunicationLink
  class Computer
  Object <|-- TelephoneCircuit : CTI
  Object <|-- CommunicationLink : CTI
  Object <|-- Computer : CTI
  TelephoneCircuit *-- CircuitRoute : auto-seeded (object,0)

  %% ---- NON-ELECTRIC / SUPPORT ----
  class DsoValve["DsoValve (gas/distribution — OUTSIDE electric model)"]
  class Person
  class Location
  Object <|-- DsoValve : CTI (HEAP, no uniq idx)
  Object <|-- Person : CTI
  Object <|-- Location : CTI
```
**Caveats** `[INFERENCE / UNKNOWN]`: domain partitions are inferred from table-family semantics, NOT read from `udb_supertype`. Actual is-a edges (~3,577) and type names (~2,054) are in absent files `[UNKNOWN-seed]`. `udb_terminal`/`udb_node` electrical connectivity is the runtime graph (covered in Deliverable 2); it is orthogonal to this *class* hierarchy.

## 4. Closure mechanics (runtime is-a test)

`udb_extendedtype` is the **polymorphic is-a-kind-of test surface** `[FACT]`:
- `SuperType$Insert`: (1) wipe the type's closure rows; (2) insert reflexive self-edge `(Type,Type)`; (3) inherit every ancestor's already-closed supertypes; (4) validate basetype consistency → grasscatcher `Type_008`. Also raises `Type_004/005/009` `[FACT - d1.sql:31831]`.
- Closure ratio 15,441 / 3,577 = **4.32×** — consistent with self-edge + ancestor expansion `[FACT]`.
- **Consumed** as `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)` — single closure-table lookup, not a recursive graph walk. Confirmed uses: FMS card-class must descend from `10093` (d1.sql:29552); node-membership test on supertype `05` `[FACT]`.

## 5. The integrity model — declared vs enforced

This is the single most important architectural fact of the schema.

### 5.1 Declared integrity: effectively ZERO `[FACT]`
| Construct | Raw hits | Real constraints | Note |
|---|---:|---:|---|
| `references` | 450 | **0** | all are `grant references … to public` (privileges), NOT FK clauses |
| `foreign key` | 0 | 0 | no declared FKs anywhere |
| `primary key` | 0 | 0 | no declared PKs |
| `check (` | 25 | **0** | all are table/proc NAMES containing "check" |
| declarative `unique` | 0 | 0 | uniqueness is in `modify … unique`, not constraints |
| `not null` | 4,727 | (used) | the ONLY declared integrity; mostly `not null default ' '`/`0` (sentinel) |

- **De-facto PK** of each table = the `modify <t> to <struct> unique on <cols>` clause. **377 of 450** tables have a unique structure; the rest (logs/audit/archive) are deliberately non-unique `[FACT]`.
- **Zero secondary indexes** (`create index` = 0); one clustering structure per table, 450/450. Non-key lookup = full scan `[FACT]`.

### 5.2 Enforced integrity: ALL in code (1,225 real procs + 290 rules + 208 dbevents) `[FACT]`
- **FK enforcement** → post-hoc proc checks fired by AFTER-INSERT rules (e.g. `FMS_ValidateEquipClass`); violations **logged, not rejected**.
- **Cascade delete** → hand-coded sequential `DELETE` ladders with manual `IF iierrornumber<>0 THEN return -1` (e.g. `CAC_CO_GroupingDel` deletes 7 child tables). No `ON DELETE CASCADE` exists.
- **Domain validation** → `INSERT INTO udb_grasscatcher(object, problem)` (`Conductor$Validate`: `IF (X/R)<5 THEN … 'Conductor_001'`; `Object$Validate`: `IF InService>OutService THEN … 'Object_001'`). **31 `INSERT INTO Udb_GrassCatcher` sites** (verified; the earlier "56" was a textual overcount).
- **The grasscatcher IS the integrity layer.** `GrassCatcher$Insert` dedupes, looks up `udb_problem.severity`; `IF Severity='F' THEN RAISE ERROR -1 (reject) ELSE MESSAGE (warn)`. **`severity='F'` problems DO block the txn** — the model is **detective-with-selective-rejection**, not preventive.
- **Delete protection** → `udb_object` rows cannot be SQL-deleted: rule `Object$Delete AFTER DELETE ON Udb_Object EXECUTE PROCEDURE Reject(Problem='Object_006')`; `Object$NullObjectProtect` rejects `object=0` (`Object_014`). Deletion is offline (annual script bypassing the rule) or by re-typing to "Historical Object" (type 998) `[FACT - ug.html]`.

### 5.3 Sentinel-default anti-pattern (20 of 30 `udb_object` columns) `[FACT]`
20/30 columns are `not null default ' '`/`default 0`; 9 are genuinely nullable (dates + 2 GIS floats + `source`); 1 is the `not null not default` PK. Consequence: `0`/`' '` cannot be distinguished from "unknown"/"N-A," forcing magic-value tests (`IF BaseType=0`, `IF PrimaryGrouping!=0`) everywhere, and `object=0` had to be **trigger-banned** — direct evidence the sentinel-zero convention leaks a forbidden value into a key column.

### 5.4 Denormalization desync — confirmed latent bug `[FACT - CONFIRMED]`
`udb_object.basetype` is written ONLY by `object$insert` (insert time). There is **NO** `AFTER UPDATE(BaseType) ON Udb_Type` rule and nothing else writes it. Changing `udb_type.basetype` for an existing type silently leaves all already-inserted instances pointing at a stale basetype / wrong subtype table. Real latent integrity gap.

### 5.5 Security & concurrency (integrity-adjacent) `[FACT]`
- **Flat security:** 4,835 grants, 100% to `public`, no roles. 180 `revoke execute … from public cascade` lock down trigger-only/key-gen procs so they fire solely via rules.
- **No explicit concurrency control in the server schema:** `set lockmode` = **0** in `d1.sql` (the Phase-0 "8 usages" are in the `.dmt` client 4GL). `systemversion` optimistic token exists on exactly 3 tables (`udb_object, udb_grouping, udb_groupinghistory`) but its UPDATE enforcement is `[UNKNOWN]`. Key allocation serializes on a single-row `UPDATE *_lastkey SET value+1` — a contention hotspot, no sequence object.

## 6. Schema mechanics — storage, keys, security, archival, concurrency

### 6.1 Storage / index `[FACT]`
| Structure | Count | % | Role |
|---|---:|---:|---|
| btree | 367 | 81.6% | default; range + equality |
| hash | 42 | 9.3% | exact-match keys (`cac_lastkey`) |
| heap | 26 | 5.8% | unkeyed scratch/queue (`udb_temp$*`; all `with extend=16`) |
| isam | 15 | 3.3% | static lookup/config (`allapp_systemparameters`) |
| **total** | **450** | | 1:1 with 450 base tables |

`modify … unique on` = 377/450. The other 73 are non-unique keyed (deliberately append-heavy log/audit). No table has >1 `modify` (the suspected "udb_temp ×3" was three *separate* heap tables). Every non-key lookup is a full scan — a structural ceiling on `fms_`/`soa_`/`ir_`.

### 6.2 Keys — `lastkey`-driven surrogate-int pattern `[FACT]`
Identity centered on `udb_object.object integer not null not default` (the only `not null not default` column). Sequence allocators = `*_lastkey` tables (6 confirmed: `udb_lastkey, cac_lastkey, tc_lastkey, msg_lastkey, soa_joblastkey, soa_loglastkey`), NO Ingres sequence objects. Allocation idiom: `UPDATE *_lastkey SET value=value+1 WHERE lastkey=:K; SELECT :NewKey=value; IF iierrornumber=0 AND iirowcount=1 THEN RETURN :NewKey ELSE RETURN -1` (canonical `Udb_NextKey` line 32630). The `=1` rowcount guard is the only concurrency safety. **Duplication smell:** `CAC_KeyGenerator1..8` = 8 near-identical copy-paste bodies; the idiom is also inlined in dozens of business procs. ~152 `lastkey` references.

### 6.3 Security / grant model `[FACT]`
**4,835 grants, 100% to `public`.** Per table a 7-grant block (`select, update, delete, insert, references, copy_into, copy_from`). Procedure `execute` = 1,225; dbevent `register` = 208, `raise` = 202 (6 register-only: server-raised channels). **Net: any connected client has full DML + `modify`/`copy`/`references` (DDL-ish) + execute on everything.** Sole control = 180 `revoke execute … cascade` on trigger-only/sequence-only procs.

### 6.4 Archive / temporal / audit — hand-rolled, no DBMS temporal `[FACT]`
- **35 `<module>_archive*` twin tables**: `INSERT INTO X_Archive SELECT … FROM X WHERE …` then `DELETE` inside procs (e.g. `FMS_ArchivePhaseCheck`). No system-versioning. Several archive tables are non-unique (append-only). Async via `RAISE DBEVENT SOA_ArchiveTrigger`.
- **Audit columns centralized on `udb_object`** (`created/createdby, lastchanged/lastchangedby, validated/validatedby, locked/lockedby`), sparse elsewhere (`createdby` on ~4 tables). Audit is NOT a universal row pattern.
- One field-level change log: `fms_audittrail(entity, handle, logtime, operator, item, old, new, …)` (non-unique btree). History tables written by rules: `fms_groundhistory, fms_highpothistory, soa_hipothistory, soa_scenariohistory, tv_bogeyhistory, udb_groupinghistory, cac_relay_groupinghistory`.

### 6.5 Concurrency model `[FACT]`
- `set lockmode` = 0 in `d1.sql` — server does zero explicit lock-mode tuning.
- `systemversion integer not null default 0` on exactly 3 tables — NOT enforced by any constraint; UPDATE-check `[UNKNOWN]`.
- App-level locks: `udb_object.locked/lockedby` (row checkout), `validated/validatedby` (approval stamp) — distinct from DBMS locks.
- **Transaction model:** procs contain NO explicit transaction control — `COMMIT` appears **exactly once** (`SetSesameLockCardFormID`, intra-loop lock release); `ROLLBACK` = 0. Procs run inside the **caller's** transaction; success/failure signalled by `RETURN 0/-1` (1,396 `iierrornumber` checks). **Partial-write hazard:** multi-statement procs (`SOA_ISPRequestStatusUpd`) `RETURN -1` *after* a successful first UPDATE with no compensation — the client must roll back or partial state persists.

## 7. Rules (290) + dbevents (208) — the automation spine

### 7.1 Rules — thin rule → fat proc `[FACT]`
All rules: `AFTER {INSERT|UPDATE(col)|DELETE} ON <t> [WHERE …] EXECUTE PROCEDURE <proc>(args=New./Old.cols)`. Verbs (case-combined): UPDATE ~119, INSERT ~112, DELETE ~59. Hottest targets (±1): `Udb_Grouping` ~29, `FMS_ObjectStatus` ~25, `FMS_Card` ~23, `Udb_Object` ~19, `SOA_Job` ~17, `TC_Job` ~11. **Taxonomy:** (a) cascade/RI (`CardType$Delete`); (b) denormalized-cache sync (`CascadeType$Change` aligns `udb_grouping.membertype/groupingtype`); (c) validation-to-exception-table; (d) history capture (`FMS_GroundHistory1/2/3`); (e) derived-state/resequencing; (f) rule→dbevent async fan-out. Magic ints embedded in WHERE clauses (10016 ×14, 10053 ×8, 10110, operatingstep 10147 ×16, relationship 52, supertypes 10093/26/21/05/15028, obsolete 999/22173/22174) are the absent seed enums — meanings `[UNKNOWN-seed]`.

### 7.2 Dbevents — async pub/sub backbone (208) `[FACT]`
Server procs/rules `RAISE DBEVENT "ingres".<name> [:payload]`; clients `register`/wait; Ingres delivers **on commit**. 60 raise sites across ~33 procs; busiest `SOA_ActiveListChange` (10), `FMS_Status_Change` (4). Payload = `;`/`:`-delimited string built with `VARCHAR(...)` casts. By prefix: fms 44, ir 35, soa 29, tc 27, soo 11, opnet 9, xa 8, dmz 7, ddb 5, report/msg 4, fra 3. **Semantic clusters:** outage/switching state machine (`soa/tc/ir`), real-time SCADA/EMS bridge (`xa/qgis_realtimeupdate/fms_status_change`), replication/HA (`ddb/opnet/dmz`), messaging, monitor lifecycle. The real-time automation spine: **DB state change → dbevent → background monitor / SCADA bridge / UI reacts.**

### 7.3 The double-declaration mechanic `[FACT]`
`d1.sql` has **2,450** `create or replace procedure` = **1,225 stubs** (`as begin return; end`, forward-declarations so rules/grants bind) + **1,225 real bodies**. Risk: a stub left un-replaced = a silent no-op trigger.

### Diagram 3 — Integrity / automation control flow
```mermaid
flowchart TD
  C[Client / OpenROAD frame] -->|execute proc| P[Server procedure 1,225 real]
  P -->|UPDATE *_lastkey +1| K[(udb/cac/tc *_lastkey)]
  P -->|INSERT/UPDATE/DELETE| T[(Base table e.g. udb_object)]
  T -->|AFTER trigger| R[Ingres rule 290]
  R -->|EXECUTE PROCEDURE New./Old.| P2[Trigger proc revoked from public]
  P2 -->|cascade DELETE children| T2[(child tables)]
  P2 -->|denorm sync MemberType/GroupingType| G[(udb_grouping cache)]
  P2 -->|validation fail| X[(udb_grasscatcher / *_problem)]
  P2 -->|history INSERT| H[(fms_groundhistory / *_history)]
  P2 -->|archive INSERT..SELECT + DELETE| A[(*_archive 35 tables)]
  P2 -->|RAISE DBEVENT :payload| E((dbevent 208))
  E -->|register/wait| M[Background monitor / UI / SCADA bridge]
  M -->|reacts: refresh, automate, push| C
```

## 8. Design-quality findings, ranked by severity

| # | Severity | Finding | Evidence | Impact |
|---|---|---|---|---|
| 1 | **Critical** | **Zero declared referential integrity** — no FK/CHECK/PK/UNIQUE constraints. All RI/cascade/validation is imperative (1,225 procs + 290 rules). Detective (validate-and-log to grasscatcher), not preventive. | `[FACT]` references=450 all grants; FK=0; CHECK-constraints=0; PK=0; 31 `Udb_GrassCatcher` insert sites | Orphan/invalid data commits and is only flagged later. Correctness hinges on every rule firing AND the client honoring problem rows. Direct SQL bypasses all integrity. |
| 2 | **Critical** | **Flat security: 4,835 grants → `public` only, no roles.** Every client gets full DML + `modify`/`copy`/`references` + execute on everything. Sole mitigation = 180 `revoke execute … cascade`. | `[FACT]` grantee tally 100% public | No least-privilege, no separation of duties, no read-only role. Any session can `modify` (DDL-ish), bulk-`copy`, or mutate any table. |
| 3 | **High** | **No secondary indexes** (`create index`=0); one clustering structure per table (450/450). | `[FACT]` | Every non-key predicate is a full scan. Structural performance ceiling on `fms_`/`soa_`/`ir_`. No tuning lever short of schema change. |
| 4 | **High** | **Denormalized caches kept consistent only by rules** — `udb_object.basetype/typename`, `udb_grouping.membertype/groupingtype`, status-label text. **Confirmed latent bug:** NO `AFTER UPDATE(BaseType) ON Udb_Type` rule → changing a type's basetype leaves existing instances pointing at the stale/wrong subtype table. | `[FACT]` `CascadeType$Change` body | Rule disablement or direct-SQL write silently desyncs `udb_object` vs `udb_grouping`. |
| 5 | **High** | **Integrity logic double-maintained** — 1,225 stubs vs 1,225 real bodies; rules bind by name; some real bodies are case/whitespace-variant. | `[FACT]` | Drift risk; an un-replaced stub = silent no-op trigger. Mixed-case binding tripped verification greps. (Note: the `'Generator'` ladder literal is a dump line-wrap artifact, **not** a live bug — see §2.2.) |
| 6 | **Medium** | **Key-allocation hotspot + duplication** — single-row `UPDATE *_lastkey SET value+1` per insert, no sequence object, no explicit lockmode; idiom inlined in dozens of procs; `CAC_KeyGenerator1..8` = 8 copy-paste bodies. | `[FACT]` `Udb_NextKey`/`CAC_KeyGenerator1` | Serialization point per `*_lastkey` row under concurrent inserts. One logic change must be applied across many copies. |
| 7 | **Medium** | **Partial-write hazard under caller-managed transactions** — 1 COMMIT total, 0 ROLLBACK; multi-statement procs `RETURN -1` after a successful first UPDATE with no compensation. | `[FACT]` `SOA_ISPRequestStatusUpd` | If the OpenROAD client fails to roll back on `-1`, the DB is left partially mutated. |
| 8 | **Medium** | **Hand-rolled archival, no DBMS temporal** — 35 twin tables via `INSERT…SELECT…+DELETE`; some archive tables non-unique. | `[FACT]` 35 confirmed | No point-in-time/system-versioning guarantee; archival failures are silent. |
| 9 | **Medium** | **Sentinel-default overload (66.7% of `udb_object`)** + god-table tag slots. `0`/`' '` conflate unknown/blank/N-A; `object=0` trigger-banned. | `[FACT]` 20/30 sentinel; `Object$NullObjectProtect` | Cannot enforce "required"; joins/aggregates silently include sentinels; presence checked reactively. |
| 10 | **Medium** | **`systemversion` optimistic-lock token present but unenforced** and only on 3 tables; `locked/validated*` are app-level, not DBMS. | `[FACT]` 3 tables; enforcement `[UNKNOWN]` | If UPDATE doesn't check `systemversion`, lost-update protection is illusory. |
| 11 | **Low / Data-quality** | **Magic ints throughout rule/proc WHERE clauses** — semantics live in absent seed rows. | `[FACT]` values present; meanings `[UNKNOWN]` | Unreadable business logic; reimplementation cannot recover code meanings without the `.ingres` seed data. |
| 12 | **Doc-discrepancy** | **Phase-0 "8 set lockmode" is 0 in `d1.sql`** — those usages are in `.dmt` client 4GL. | `[FACT]` 0 in d1.sql | Server has no explicit lock-mode tuning; any concurrency tuning lives client-side. |

**Critical + High findings: 5** (#1–#5).

---

# Phases 3–4 — Application Logic + Business Model

**Subject:** Con Edison OMS / PSM — JOB / JOB CLASS / SWITCHING ORDER / OUTAGE subsystems across data + server code + client UI + user guide.

**Headline facts that govern everything:**
1. **"2,450 procedures" is a 2× over-count** — each proc is declared twice (stub + real body). The real server logic is **~1,225 distinct bodies** (read only the second occurrence, NR > 27757). `[FACT]`
2. The DB-proc layer is a **write/command layer**: fine-grained `*Ins`/`*Upd`/`*Del` wrappers (65% CRUD-suffixed) + thin state-transition/event-raising commands. **Querying is client-side SQL** (broad `select` grants; almost no reader procs server-side). `[FACT]`
3. **No row data exists** → every status-code enum, type/basetype/supertype list, jobclass/movetype/movecategory/outagetype code is `[UNKNOWN]` except literals hard-coded in proc/rule bodies. `[FACT]`
4. **Contradiction (stub count), resolved:** five verified docs say **1,225 stubs / 1,225 real (exact 1:1, each citing `grep -c 'as begin return; end' = 1225`)**; two docs + the Phase-0 brief say 1,163. **1,225 is the better-evidenced figure**; the 1,163 likely uses a narrower stub regex. Immaterial to architecture (~62 procs); flagged. **Module real-body splits ARE consistent: SOA 240, IR 134, FMS ~352, TC 127 (all stubs).**

## (a) Where business rules live — four tiers

Decision logic is split: **persistence + state machines + cross-module cascades are server-side; validation, type resolution, cross-system notification, and transaction/replication orchestration are client-side.** `[INFERENCE]`

| Tier | Artifact | Volume | What lives here |
|---|---|---|---|
| **1. Server DB procedures** | `d1.sql` real-body block | **~1,225 procs** (~12k–16k logical LOC) | CRUD wrappers; numeric→string status decoders; cross-module cascades (FMS→SOA, IR→SOA/FMS/TC); key generation; `RAISE DBEVENT`; soft validators → `Udb_GrassCatcher` |
| **2. Server Ingres RULES** | rules block (~32780–33366) | **290 rules** | AFTER triggers firing procs with `Old.`/`New.` bindings + WHERE guards; the ONLY recoverable server behavior where procs are stubs (esp. TC — all 127 bodies stubbed) |
| **3. Server DBEVENTS** | dbevent decls | **208** | bare async signals; delivered on commit; how the DB notifies clients/daemons |
| **4. Client OpenROAD 4GL** | `psm.dmt` (872 `ON` handlers), `psm_4glprocs.dmt` (67 dual-write wrappers) | **872 handlers + 67 wrappers** | input validation, type/supertype filtering, XA21/EMS sync, phase-combo parsing, audit capture, **COMMIT/ROLLBACK boundaries**, dual-session replication |

**Real server-logic mass by module:** fms 352 + soa 240 + tc 127 + tfms 31 = **750 procs (61%)** = the switching-order/outage core. udb 70 + ~40 `$`-named rule procs = the small-but-load-bearing metamodel engine (every object insert funnels through `object$insert`). ir 134 (large but shallow — board-refresh + feed writers). Remainder: cac 42, fra 35, slc 29, dso 26, pvl 16, csd 14, others.

**Decisive architectural facts:** integrity is in code not constraints (bad data is logged, not blocked); transactions are caller-managed (`COMMIT`=1, `ROLLBACK`=0 in 33,392 lines; `iierrornumber` checked 1,396×, `RAISE ERROR` 92×, `RAISE DBEVENT` 60×); **irreplaceable client logic** — `Switch.NotifyXA21()` (EMS sync), `Switch.SplitCombo()` (phase parsing), `LoadTypeList()` (type-hierarchy resolution), dual-write COMMIT/ROLLBACK orchestration — exists ONLY in `psm.dmt`/`psm_4glprocs.dmt` with no server equivalent.

## (b) End-to-end subsystem map: JOB / JOB CLASS / SWITCHING ORDER / OUTAGE

### b.0 Unit-of-work model
- **There is NO single "SwitchingOrder" entity.** The order container is the **CARD**; a card holds **MOVES (= jobs)** organized into **STEPS (StepPairs)**. `[FACT - ug-switching-lifecycle]`
- **"Move" and "job" are synonymous** per the guide (ug.html:5130-5132). `[FACT]`
- **A JOB CLASS is the move TEMPLATE** (move rules + job checks + job actions); a JOB is the per-object INSTANCE. The schema separates class↔instance; the guide collapses them. `[FACT]`
- **A card = an ordered list of jobs = the printable switching order.** `soa_jobcontrol(card,job,switchingitem)` attaches jobs in `steppair`/`steplevel`/`seq` order; server sequencing via `SOA_DetermineSequence`/`SOA_ControlResequence`. `[FACT]`

### b.1 The three-job-table reconciliation
| Table | Exists? | Cols | Key | Role | Domain |
|---|---|---|---|---|---|
| `soa_job` | **YES** | 31 | btree unique on `job` | JOB INSTANCE | TOMS/SOA = Substations (SLC) + Transmission Feeders (TFMS) |
| `tc_job` | **YES** | 37 | btree on `(card,seq,job)` | JOB INSTANCE | TLS = Telephone circuits |
| `fms_job` | **NO — DOES NOT EXIST** | — | — | — | — |
| `fms_jobclass` | YES | 7 | PK `jobclass` | JOB CLASS / TEMPLATE (shared move library) | FMS + shared |
| `fms_archivejob` | YES | — | — | archived job-row shape (only place FMS job-row shape is visible) | FMS |

**Reconciliation:** there are **exactly two job-INSTANCE tables** — `soa_job` and `tc_job`. **`fms_job` does not exist.** FMS's job model = `fms_card` (live operating card, 47 cols) + move-template tables (`fms_jobclass`, `fms_jobaction`, `fms_jobcheck`, `fms_jobclasscontrol`, `fms_jobclasslink`, `fms_jobobjective`, `fms_jobtoskill`). `[INFERENCE]` `soa_job` is the de-facto **shared** job-instance store; FMS is the executor/state-overlay (writes back into `SOA_Job.Grounds`, `SOA_Card.Status`), not a separate instance owner. **Same shape, three prefixes:** `soa_job`, `tc_job`, `fms_archivejob` all carry the **TO (TakeOut/issue) half + RS (Restore) half** pattern. The two-phase out-of-service-then-in-service move is the universal primitive.

### b.2 FMS / SOA / IR / TC division of labor
| Module | Best-evidence acronym | Owns | Writes into (cross-module) |
|---|---|---|---|
| **SOA** (=TOMS) | Switching Order App / TOMS | switching-order data model: `soa_card`, `soa_job`, `soa_jobcontrol`, in-service permits, planned outage requests, bus-fault capture. **System of record for permits + switching jobs (NYISO/NYPA regulatory).** | repoints `SOA_WorkPermit`/`TC_WorkPermit` on ISP withdraw |
| **FMS** | Field Management Subsystem | **Real-time field execution + object-status state machine.** Largest (114 tbl, ~352 procs). `fms_objectstatus` (current) + `…audit` (history) + `…queue` (inbound) CQRS triple; automation loop; `fms_card`; clearance/LOTO. | `UPDATE SOA_Card SET Status`; `UPDATE SOA_Job SET Grounds` (sums status 10016) |
| **IR** | Issue/Return (inferred) | order-issue / field-return state machine. 38 tbl, 134 procs. Operating orders, FCR work permits, RFPs, telephone orders, relay-target returns. | `UPDATE SOA_Job` (`IR_CompletePermit`); `UPDATE FMS_Workpermit` (`IR_WorkPermitUpdate`); `UPDATE TC_Job` (`IR_TLSCompleteJob`) |
| **TC** (=TLS) | Telephone Line System | telephone/telecom-circuit switching, on the FMS DB. 33 tbl, **all 127 procs stubs** (logic recoverable only from rules+DDL+guide). Electronic trouble-ticket to Verizon. | shared `soa_activecard` registry (discriminated by `application char(4)`) |

**Key cross-module edges (all FACT, body-verified):**
1. **FMS → SOA (card mirror):** `FMS_CardStatusChange` → `UPDATE SOA_Card SET Status`, rule-fired by `FMS_Card$StatusChange`; `RAISE ERROR -1` rolls back the whole txn on cascade failure (transactional coupling).
2. **FMS → SOA (grounds):** `FMS_UpdateGrounds` sums `fms_objectstatus.StatusCount WHERE Status=10016` → `UPDATE SOA_Job SET Grounds … WHERE C.Status<50`, raises `FMS_Update_Grounds`.
3. **SOA/SLC → FMS (job enqueue):** producer proc INSERTs into `fms_objectstatusqueue` with `job/tors/switchingitem/fromapp` provenance (exact proc `[UNKNOWN]`, lives in SOA's ~240 procs).
4. **IR → SOA/FMS/TC (completion write-back):** `IR_CompletePermit`→`SOA_Job`; `IR_WorkPermitUpdate`→`FMS_Workpermit`; `IR_TLSCompleteJob`→`TC_Job`.
5. **SOA ↔ IR (job timestamp sync):** rules `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` on `SOA_Job` fire `IR_FMSJobUpdate(Action='RC'|'RI'|'TC'|'TI')` → raises `IR_FeederBoardUpd`.
6. **SOA ↔ SLC (long-term clearances):** rules `SLC_NewItemActivated`(switemstatus=20, movecat 2/3), `SLC_ItemClosed`(≥50), `SLC_ArchiveItem`/`SLC_PurgeItem`.
7. **Shared active-card registry:** `soa_activecard.application char(4)` discriminates FMS/SLC/TC/TFMS; `TFMS_NewCardActivated … WHERE New.Application <> 'FMS'` routes any non-FMS card into TFMS activation.

### b.3 Transaction boundaries (migration-critical)
- **Each proc = one logical unit, NOT auto-atomic.** Ingres DB procs are not transactional containers; **rollback is the caller's responsibility.** Several multi-statement procs (`SOA_ISPRequestStatusUpd`, `SOA_ISPRequestCopy`, `SOA_CloseSwitchItem`) `RETURN -1` *after* a successful first write → **real partial-write hazard.**
- **Rules execute synchronously inside the triggering transaction** (FMS_Card status update + SOA_Card cascade + dbevent raise = ONE transaction; SOA-cascade failure rolls back via `RAISE ERROR`).
- **dbevents delivered on commit** (queued, decoupled).
- **The real transaction boundary is the OpenROAD client** (`psm.dmt`: 392 `DDB_ROLLBACK` + 280 `DDB_COMMIT`; dual-session replication). The DB tier cannot reproduce application transactional behavior alone.

### b.4 End-to-end map (Mermaid)
```mermaid
flowchart TD
  subgraph CLIENT["OpenROAD client tier (psm.dmt + per-app frames)"]
    UI[DO desk frames: Issue Moves / Return Moves / permit screens]
    DW[psm_4glprocs dual-write wrappers<br/>Session.One + Session.Two]
  end
  subgraph SOA["SOA = TOMS (order authoring + permits)"]
    CARD[soa_card status 10->20->50]
    JOB[soa_job: TO half / RS half<br/>switemstatus 0..20..50]
    JC[soa_jobcontrol card<->job<->step]
    ISP[soa_inservicepermit + ispermitrequest<br/>Status 2..100 decoder SOA_ISPStatusUpd]
    OR[soa_outagerequest 10..100]
    BF[soa_busfaultoutage 67 cols<br/>SOA_BFIns -1 sentinels]
  end
  subgraph FMS["FMS (field execution + status state machine)"]
    Q[fms_objectstatusqueue inbound]
    CUR[fms_objectstatus UNIQUE obj,term,status<br/>statuscount=refcount]
    AUD[fms_objectstatusaudit history]
    FC[fms_card FeederStatus/StationGround/GroundsOn]
    AUTO[automation loop: fms_automationcontrol/block]
  end
  subgraph IR["IR = Issue/Return (drive to field)"]
    OO[ir_operatingorder]
    WP[ir_workpermit + RFP]
    TO[ir_telephoneorder]
    RR[ir_returnrelay]
  end
  subgraph TC["TC = TLS (telephone, all procs stubbed)"]
    TCC[tc_card]
    TCJ[tc_job]
    TRO[tc_troublereportorder -> Verizon poll]
  end
  UI --> DW --> CARD & JOB & ISP & OR
  JC --- JOB
  JOB -->|SOA->FMS enqueue job/tors/switchingitem| Q
  Q -->|dequeue+purge| CUR --> AUD
  CUR -->|status 10044/10053/10016| FC
  FC -->|FMS_CardStatusChange rule| CARD
  CUR -->|FMS_UpdateGrounds sum 10016| JOB
  IR -->|IR_CompletePermit| JOB
  IR -->|IR_WorkPermitUpdate| WP
  IR -->|IR_TLSCompleteJob| TCJ
  JOB -->|rules IR_FMSJob RC/RI/TC/TI| IR
  TC -->|reacts tc_status_change1/2/3| CUR
  TC -->|application<>'FMS'| SOA
  BF -->|SCADA xa_busoutage| CUR
  AUTO -->|FMS_AutomationGo dbevent| ExtAuto[External automation daemon]
```

## (c) Reconstructed operational workflows

> Caveat: the user guide is a **DBM admin guide**, not an operator switching manual. State **labels** are reconstructed; only numeric/string literals embedded in procs are authoritative. `[INFERENCE]`

### c.1 PLANNED outage / switching order (operator-built)
| # | Step | Tables | Procs (real bodies) | Rules / dbevents |
|---|---|---|---|---|
| 1 | DO builds card | `soa_card` (status 10 = built) | `SOA_CardUpd` | dbevent `soa_loadcommoncard`/`loadfmscard` |
| 2 | Add moves by step | `soa_job`, `soa_jobcontrol`, `fms_steppair` | `SOA_ItemIns`/`SOA_JobIns` (switemstatus<20) | `SOA_DetermineSequence`/`SOA_ControlResequence`. **`SOA_DetermineMoveSequence` is client 4GL — location `[UNKNOWN]`** |
| 3 | Activate card | `soa_card.status=20`, `soa_activecard` | `SOA_CardStatusUpd` (10→20) | `SOA_CardActivate`→`SOA_ActiveListInsert`→ **RAISE `SOA_ActiveListChange`** |
| 4 | Activate switch item | `soa_job.switemstatus=20`, `Response='Active'` | `SOA_ActivateSwitchItem` (sets `TOIssued`, cascades) | `SLC_NewItemActivated` (movecat 2/3) |
| 5 | Issue TakeOut (isolate) | `soa_job.toissued/tooperator` | `SOA_IssueMove('TO')` | `IR_FMSJobTOIssued`→`IR_FMSJobUpdate('TI')`; **skill check** (`FMS_JobToSkill` vs `FMS_PersonToSkill`) |
| 6 | Complete TakeOut → CutOut | `soa_job.tocomplete`, `soa_card.cutout` | `SOA_CompleteMove('TO')` | `IR_FMSJobTOComplete`→`('TC')`; dbevent `fms_sxcutout` |
| 7 | Establish protection / grounds | `fms_workpermitprotection`, `fms_groundhistory`, `fms_card.stationground` | `FMS_UpdateCardHeader` (status **10044** station-ground, **10053** grounds); `FMS_UpdateGrounds` (status **10016** sum→`SOA_Job.Grounds`) | `FMS_CardHeader1`(10044,10053), `FMS_GroundHistory1`(10016,10053); dbevents `fms_card_grounds`, `fms_update_grounds`. Work-Permits = Sequence **600** (global constant) |
| 8 | Make safe / lock | `fms_sesamelockcard` (65 cols, descriptive), `fms_regtag`, `ir_fodtag` | `FMS_SesameLockCardIns/Upd` (lifecycle bit = `processed 0→1`) — **NOT an enforcement gate** | dbevents `ir_processingtags`→`ir_reviewtags`→`ir_tagsreviewed` |
| 9 | Issue work permit | OSWP/ISWP `fms_workpermit`/`soa_workpermit`; ISP `soa_inservicepermit`; FCR `ir_workpermit` | `IR_IssueFCRWorkPermit`; `SOA_IssueISP`; ISP via `SOA_ISPStatusUpd` (18-state decoder) | dbevent `ir_processingpermit`; **target-ground protection-distance check Green/Yellow/Red** |
| 10 | Field work (skill-gated) | — | — | mismatch → "Operator is not qualified for this move…" |
| 11 | Permit return | `ir_workpermit.permitstatus=50`, `soa_workpermit.returnstatus` | `IR_ReturnWorkPermit` (hardcodes 50); `IR_CompletePermit`→`SOA_Job` | dbevents `ir_returnpermit`, `ir_permitcomplete` |
| 12 | Issue Restore (re-energize) | `soa_job.rsissued/rscomplete`, `soa_card.cutin` | `SOA_IssueMove('RS')`, `SOA_CompleteMove('RS')` | `IR_FMSJobRSIssued/RSComplete`→`('RI'/'RC')`; dbevent `fms_sxcutin` |
| 13 | Close switch item / card | `soa_job.switemstatus≥50`; `soa_card.status=50` | `SOA_CloseSwitchItem` (un-hides ISP child jobs if MoveCategory=6); `SOA_CardStatusUpd`(→50) | `SOA_CardDelete`(≥50)→`SOA_ActiveListDelete`; `ir_closecard` |
| 14 | Archive | `soa_archivejob`, `soa_archivelog`, `*_archivecard` | `SOA_ArchiveJob`; archive copy client-orchestrated | — |

**Parallel: PLANNED OUTAGE REQUEST (OSS-driven)** — `soa_outagerequest` via `SOA_ORStatusUpd`: **10 IMPORTED → 20 PERMIT → 50 CLOSED → 70 RECALLED → 100 ARCHIVED**, carrying scheduled-vs-actual date pairs. Cascade-delete via `SOA_OutageRequest$Del`→`SOA_ORCascadeDel`.

### c.2 AUTOMATIC / FORCED outage (event-driven)
1. Breaker operates → `xa21_outagereport` (EMS feed), `XA21_OutageReportIns` (bare INSERT).
2. Outage Monitor waits `allapp_systemparameters.outagemonitordelay` seconds.
3. Connectivity trace on `Udb_Terminal`/`Udb_Node` (legacy) **or** QGIS model (modern).
4. Outage identified → `soa_outagesummary(object, type, voltage, card, switchingitem, job, outagetype int, outservicestart/end, latentflag, outagekey)`.
5. Late ID → asterisk on TOMS Outage Summary (`outagelatentperiod`).
6. Open-Auto / relay capture (`fms_openautoequip`, `cac_relaytypes`).
7. Bus-fault telemetry → `soa_busfaultoutage` (67 cols, widest table); `SOA_BFIns` writes 22 flag/target cols = **−1 sentinel**; 16 `SOA_BF*Upd` patch one element group each.
8. Correlate → `soa_busfaultcorrelationmatrix`, `correlationaction varchar(160)` (Peak Load matrix when load > threshold).
9. Visual outage → `qgis_setoutage` (stub body — behavior `[UNKNOWN]`).
10. Rapid-Restore electronic order (substation forced path) → `ir_operatingorder`/`ir_opordersteps`/`ir_downloadmove`, lifecycle **issued → downloaded → ack/reject → return → rescind**.

### c.3 PERMIT / IN-SERVICE-PERMIT approval (parallel state machine)
`soa_inservicepermit.Status` decoded by `SOA_ISPStatusUpd` (18 states, verified verbatim): **2 REQUEST → 10 OPEN → 15 PENDTO → 20 PENDSO → 40 APPRV / 35 A-COND / 25 DENIED → 45/50 ISSUED → 54 PULLRQ → 55 PULLED → 60 COMPL / 65 INCOMPL → 70 LOCAL → 100 archived.** Auto-close sweep `SOA_ISPArchive`. A **second, distinct** decoder `SOA_ISPRequestStatusUpd` decodes the *request* side (`1/2/4/8 → REQ_OPEN/RCC_APPRV/PENDING/REQ_DENIED`) — do not conflate.

### c.4 Move lifecycle (universal primitive)
**drafted → TO issued → TO complete → (work) → RS issued → RS complete → closed.** The four nullable `ingresdate` columns (`toissued,tocomplete,rsissued,rscomplete`) ARE the per-move micro-state. Driven by `SOA_IssueMove`/`SOA_CompleteMove` (action selector `'TO'`/`'RS'`). Numeric band `switemstatus`: **<20 created / =20 active / 20–49 in-progress / ≥50 closed.**

## (d) Guide-vs-schema contradictions (consolidated)

| # | Contradiction | Resolution |
|---|---|---|
| **D1** | Brief says reconcile **`fms_job`** | **`fms_job` does NOT exist.** Only `soa_job` + `tc_job` are instance tables; FMS uses `fms_card` + `fms_jobclass`; instance shape only in `fms_archivejob` |
| **D2** | Ground-Truth "2,450 procedures" = real logic | **Double-counted.** ~1,225 distinct bodies; read NR>27757 only |
| **D2b** | Docs disagree: **1,225 vs 1,163 stubs** | Five docs say 1,225/1,225 (exact grep) — **preferred**; two + brief say 1,163. Immaterial to architecture |
| **D3** | Guide names **`SOA_OSWPEquipType`** | **NOT in `d1.sql`.** Only `soa_iswpequiptype` exists. OSWP equip-type storage unaccounted-for; in-schema status `[UNKNOWN]` |
| **D4** | Guide names **`fms_highpottesthistory`** | Schema has **`fms_highpothistory`** (no "test"). Guide name inexact |
| **D5** | Guide describes proc behavior for TC | TC's 127 procs are **stubs end-to-end** — behavior unverifiable at code level |
| **D6** | "**TLS**" overloaded | §3 TOC "TLS Menu" = Transmission Line System; body prose = Telephone Lines switching app. Keep separate |
| **D7** | "**DSO**" assumed = Distribution System Operator | = **Dielectric Switching Operations** (separate `DSO_DBM` image). `dso_object`/`dso_connection` = QGIS render cache of `Udb_Object`, NOT an independent object authority |
| **D8** | Active "Outage Monitor" with timing params | Version history: Outage Monitor was **disabled then rebuilt on QGIS**; timing-param docs still present. Live path ambiguous |
| **D9** | `SOA_DetermineMoveSequence` / `CheckDeloadComplete` | **Absent from `d1.sql` AND `.dmt` slice.** Location `[UNKNOWN]` (likely compiled OpenROAD frame). A same-named server proc `SOA_DetermineSequence` does exist — do not conflate |
| **D10** | "move=job synonymous" | Schema has BOTH instance (`soa_job`,`tc_job`) AND template (`fms_jobclass`); guide collapses class↔instance |
| **D11** | Column-count mismatches | Authoritative DDL: IR `ir_operatingorder`/`ir_workpermit`/`ir_telephoneorder` = **28 / 30 / 25**; TC `tc_job`/`tc_card` = **37 / 29**. Brief AND original analyses mis-counted |
| **D12** | Client tier (6 editors) calls server procs absent from `d1.sql` | `udb_dsovalveupd`/`udb_lineupd`/`udb_tankupd`/`udb_pumpupd`/`udb_pumpplantupd`/`udb_reliefvalveupd` have **no server proc** — dead frames or incomplete dump. Regenerating the server tier from `d1.sql` will break these editors |

## (e) Migration-critical synthesis
1. **Dbprocs alone cannot reproduce application behavior.** ~40% of decision logic (validation, type resolution, XA21/EMS sync, phase parsing, transaction/replication orchestration, audit) lives in the **OpenROAD client** (872 `ON` handlers + 67 dual-write wrappers). Port these, not just the ~1,225 dbprocs.
2. **Integrity-in-code, not constraints** → re-express ~290 rules + ~31 soft validators as real constraints/triggers, or bad data that today is *logged* (`Udb_GrassCatcher`) will silently flow.
3. **Caller-managed transactions + partial-write hazard** → a naive service-layer re-host without explicit transaction wrapping will corrupt state.
4. **Two job-instance tables, one shared model** → model the job once with a domain discriminator, not three tables.
5. **All status/type/jobclass enums are UNKNOWN** (seed `.ingres` absent) → recover from the live system before the state machines can be fully specified.

---

# Deliverable 2 (Phase 5) — How UDB Works

**The three layers, one sentence each:**
1. **Object resolution** = "what kind of thing is object N, and where do its subclass columns live?" → `udb_object.type → udb_type → udb_basetype` join + hard-coded dispatch ladder in `object$insert`. `[FACT]`
2. **Network graph** = "what is connected to what?" → `udb_terminal.node` (electrical adjacency: two objects connected ⟺ shared `node`) and `udb_grouping` (typed containment edges). `[FACT]`
3. **Switching order** = "isolate, work, restore" → a `soa_card` of ordered `soa_job` moves (TO/RS) driven through state machines by `SOA_*` procs, fired by rules, fanned out to FMS/IR via `RAISE DBEVENT`. `[FACT]`

These layers are **stacked**: a switching order operates on objects (layer 1) whose connectivity (layer 2) defines what an "outage" is, and every write is governed by the integrity-in-code model.

## Layer 1: Object resolution — the metamodel engine

**Five core tables** `[FACT - row_estimates are loader estimates, NOT counts]`:
- `udb_object(object PK, type, basetype*, primarygrouping*, typename*, status, terminals, …30 cols)` — btree unique on `object`, est. 105,880.
- `udb_type(type, basetype, name, description)` — btree unique `(type,name)`, est. 2,054.
- `udb_basetype(type, editorname, tablename)` — btree unique `type`, est. 41.
- `udb_supertype(type, supertype)` — class graph edges, est. 3,577.
- `udb_extendedtype(type, supertype)` — materialized transitive closure (+self), est. 15,441 (4.32×).

**Resolution path** (server dispatch): `udb_object.type → udb_type(T.type) → T.basetype, T.name → udb_basetype(T.basetype=BT.type) → BT.tablename (server), BT.editorname (client)`. `BT.tablename` selects the CTI subclass table; `object$insert` then `INSERT INTO Udb_<Subtype>(Object)` (two rows, same id). Dispatch is *designed* data-driven but *implemented* as a hard-coded 22-branch ladder (≥19 of 41 base types get no insert-time stub). `BT.editorname` is **never read server-side** (1 occurrence = its DDL). `object$insert` also writes caches, audit (`created/createdby='Now'/User`), fans out `terminals` into `udb_terminal`, and inserts the **relationship-52 primary-grouping edge** into `udb_grouping`.

**Polymorphic is-a test:** single closure lookup `WHERE Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = <ancestor>)` (FMS card-class descends from `10093` at d1.sql:29552; node-membership on `05`). Closure maintained by `SuperType$Insert/$Delete`.

**Integrity posture (governs every write):** zero declared FK/PK/CHECK; RI/cascade/validation = imperative; validation is detective (`udb_grasscatcher` + `udb_problem.severity`; only `severity='F'` rejects); `udb_object` rows can't be SQL-deleted.

## Layer 2: Network-graph traversal — terminal / node / grouping

Two **orthogonal instance graphs** sit on `udb_object` (distinct from the *class* graph `udb_supertype`).

**Electrical connectivity = terminal/node graph** `[FACT - d1.sql:14359-14365, 14997-15004]`:
- `udb_node(node PK, name, kvlevel, primarygrouping, seq)` — hash unique on `node`, est. 21,459. A node = an electrical bus/connection point at a kV level.
- `udb_terminal(object, basetype, terminal, node, inservice, outservice)` — heap, one row per object terminal; `object$insert` fans out `(Object, BaseType, Terminal=1..N)`, leaving `node` wired later.
- **Adjacency rule:** two objects connected ⟺ two of their `udb_terminal` rows share the same `node` `[INFERENCE - high confidence; the join is the only connectivity mechanism in the udb_ schema]`.
- **Traversal** (Outage Monitor trace) = node-hopping walk bounded by open switches; the trace algorithm is client/monitor 4GL, body `[UNKNOWN]`.
- `Object$PrimaryGrouping` writes `udb_node.primarygrouping` for node-supertype `05` objects.

**Containment / hierarchy = grouping graph** `[FACT - d1.sql:14003-14034]`:
- `udb_grouping(grouping, member, relationship, groupingtype, membertype, reference, systemversion)` — heap→**btree unique on (grouping, relationship, member)**, est. **295,316** (largest in the metamodel). Typed edge list: `grouping` (parent) —[`relationship`]→ `member` (child); `groupingtype`/`membertype` caches kept aligned by `CascadeType$Change`.
- **relationship = 52** = the primary-grouping (containment) edge; other relationship ids `[UNKNOWN-seed]`.
- **Load roll-up:** when `BaseType=21` (consumer/load), `Object$PrimaryGrouping` subtracts load (Pfixed/Pnom/Qfixed/Qnom from `udb_consumer`) from old grouping, adds to new — aggregated load carried up the containment tree.
- History: `udb_groupinghistory` (one of 3 `systemversion` tables).

**Why both graphs matter to switching:** the **terminal/node graph** answers "if I open this switch, what loses power?" (de-energization set → outage identification); the **grouping graph** answers "what station/feeder does this belong to?" (routing a card to the right desk, status roll-up). A switching order's *effect* is computed on the terminal/node graph; its *organization* on the grouping graph.

## Layer 3: Lifecycle of one representative planned switching order

**Scenario** `[INFERENCE - representative composite; each step FACT-cited]`: a DO builds a planned switching order to take a distribution feeder switch out of service, work it under permit, then restore (the SOA/TOMS planned path, specialized by FMS field-execution and IR permit issue/return). **There is no `switchingorder` entity — the order = a `soa_card` + its ordered `soa_job` moves.**

| # | Operator action | Tables | Proc(s) (real body) | Rule(s) | Dbevent |
|---|---|---|---|---|---|
| 1 | DO opens/builds card | `soa_card` (status 10) | `SOA_CardUpd` | — | `soa_loadcommoncard`/`loadfmscard` |
| 2 | Add moves by step | `soa_job`, `soa_jobcontrol`, `fms_steppair` | `SOA_JobIns`/`SOA_ItemIns`, `SOA_JobControlIns` | `SOA_DetermineSequence`/`SOA_ControlResequence` | — |
| 3 | Move text from class template | reads `fms_jobclass` + `fms_jobclasscontrol` + `fms_jobcheck`/`fms_jobaction` + `fms_jobtoskill` | client 4GL / stubbed `[UNKNOWN-body]` | — | — |
| 4 | Activate card | `soa_card.status=20`, `soa_activecard` | `SOA_CardStatusUpd` (10→20) | `SOA_CardActivate`→`SOA_ActiveListInsert` | **`SOA_ActiveListChange`** (INSERT;) |
| 5 | Activate switch item | `soa_job.switemstatus=20`, `Response='Active'` | `SOA_ActivateSwitchItem` | `SLC_NewItemActivated` (movecat 2/3) | — |
| 6 | Issue TakeOut (isolate) | `soa_job.toissued/tooperator` | `SOA_IssueMove('TO')` | `IR_FMSJobTOIssued`→`('TI')` | `IR_FeederBoardUpd`. **Skill gate** |
| 7 | Field executes → status to FMS | `fms_objectstatusqueue`→`fms_objectstatus`→`fms_objectstatusaudit` | SOA enqueue `[UNKNOWN]`; FMS dequeue/apply | FMS status rules | — |
| 8 | Complete TakeOut → CutOut | `soa_job.tocomplete`, `soa_card.cutout`, `fms_card.feederstatus` | `SOA_CompleteMove('TO')`; `FMS_CardStatusChange` (`RAISE ERROR -1` rolls back) | `IR_FMSJobTOComplete`→`('TC')`; `FMS_Card$StatusChange` | `fms_sxcutout`, `FMS_Status_Change` |
| 9 | Protection / grounds | `fms_groundhistory`, `fms_card.stationground/groundson`, `fms_workpermitprotection` | `FMS_UpdateCardHeader` (10044/10053); `FMS_UpdateGrounds` (sum 10016→`SOA_Job.Grounds`) | `FMS_CardHeader1`(10044,10053); `FMS_GroundHistory1`(10016,10053) | `fms_card_grounds`, `fms_update_grounds`. Seq **600** |
| 10 | Issue work permit | `ir_workpermit`/`soa_workpermit`/`fms_workpermit`; ISP `soa_inservicepermit`+`soa_ispermitrequest` | `IR_IssueFCRWorkPermit`; ISP `SOA_ISPStatusUpd` (18-state) | — | `ir_processingpermit`. Protection-distance gate |
| 11 | Field work, permit return | `ir_workpermit.permitstatus=50`; `soa_workpermit.returnstatus` | `IR_ReturnWorkPermit` (50); `IR_CompletePermit`→`SOA_Job`; `IR_WorkPermitUpdate`→`FMS_Workpermit` | — | `ir_returnpermit`, `ir_permitcomplete` |
| 12 | Issue Restore | `soa_job.rsissued/rscomplete`; `soa_card.cutin` | `SOA_IssueMove('RS')`, `SOA_CompleteMove('RS')` | `IR_FMSJobRSIssued/RSComplete`→`('RI'/'RC')` | `fms_sxcutin` |
| 13 | Close switch item / card | `soa_job.switemstatus≥50`; `soa_card.status=50`; un-hides ISP child jobs if `movecategory=6` | `SOA_CloseSwitchItem`; `SOA_CardStatusUpd`(→50) | `SOA_CardDelete`(≥50)→`SOA_ActiveListDelete` | `SOA_ActiveListChange`(DELETE;); `ir_closecard` |
| 14 | Archive | `soa_archivejob`, `soa_archivelog`, `*_archivecard` | `SOA_ArchiveJob` | — | `SOA_ArchiveTrigger` |

**Universal move primitive:** every move advances **drafted → TO issued → TO complete → (work) → RS issued → RS complete → closed**; the four nullable timestamps ARE the micro-state; `switemstatus` band (<20/=20/20–49/≥50) is the item lifecycle.

**Transaction & coupling reality:** `COMMIT`=1, `ROLLBACK`=0 in 33,392 lines; rollback is the OpenROAD client's responsibility (`psm.dmt`: 392 `DDB_ROLLBACK` + 280 `DDB_COMMIT`). Ingres AFTER rules execute synchronously inside the triggering txn; dbevents delivered on commit (decoupled). Several procs `RETURN -1` *after* a successful first write → partial-write hazard.

**Forced/automatic outage (contrast):** breaker operates → `xa21_outagereport` → Outage Monitor waits `outagemonitordelay` → connectivity trace on the terminal/node graph → `soa_outagesummary(outagetype, latentflag)` + wide `soa_busfaultoutage` (67c, `SOA_BFIns` writes 22 cols=−1, 16 `SOA_BF*Upd` patch groups) → `soa_busfaultcorrelationmatrix` recommends corrective switching. No approval lifecycle (capture, not workflow).

### Sequence diagram — one planned switching order
```mermaid
sequenceDiagram
    autonumber
    actor DO as DO / OpenROAD frame
    participant SOA as SOA procs (SOA_*)
    participant CARD as soa_card / soa_job / soa_jobcontrol
    participant RULE as Ingres rules (AFTER)
    participant FMS as FMS (fms_objectstatus* / fms_card)
    participant IR as IR (ir_workpermit / IR_*)
    participant EV as dbevent bus
    participant AUTO as Desks / SCADA bridge / archiver

    Note over DO,CARD: BUILD
    DO->>SOA: SOA_CardUpd (open card)
    SOA->>CARD: soa_card.status=10 (Opened)
    DO->>SOA: SOA_JobIns + SOA_JobControlIns (add moves)
    SOA->>CARD: soa_job(switemstatus<20) + soa_jobcontrol(steppair,seq)
    CARD-->>RULE: AFTER INSERT soa_jobcontrol (Seq=0)
    RULE->>SOA: SOA_DetermineSequence (order moves)

    Note over DO,EV: ACTIVATE
    DO->>SOA: SOA_CardStatusUpd (10->20)
    SOA->>CARD: soa_card.status=20 (Activated) + soa_activecard
    CARD-->>RULE: SOA_CardActivate
    RULE->>SOA: SOA_ActiveListInsert (reads FMS_Card/TFMS_CardToObject)
    SOA->>EV: RAISE DBEVENT SOA_ActiveListChange (INSERT;)
    EV->>AUTO: all DO desks refresh active list
    DO->>SOA: SOA_ActivateSwitchItem
    SOA->>CARD: soa_job.switemstatus=20, Response='Active'

    Note over DO,FMS: TAKE OUT (isolate)
    DO->>SOA: SOA_IssueMove('TO')  [skill gate FMS_JobToSkill]
    SOA->>CARD: soa_job.toissued/tooperator
    CARD-->>RULE: IR_FMSJobTOIssued
    RULE->>IR: IR_FMSJobUpdate('TI')
    IR->>EV: RAISE DBEVENT IR_FeederBoardUpd
    SOA->>FMS: enqueue -> fms_objectstatusqueue (job/tors/switchingitem)
    FMS->>FMS: apply -> fms_objectstatus (statuscount) -> fms_objectstatusaudit
    DO->>SOA: SOA_CompleteMove('TO')  (CutOut)
    SOA->>CARD: soa_job.tocomplete, soa_card.cutout
    FMS->>CARD: FMS_CardStatusChange -> UPDATE soa_card.status (RAISE ERROR -1 = rollback)
    FMS->>EV: RAISE DBEVENT fms_sxcutout / FMS_Status_Change

    Note over DO,FMS: PROTECT (grounds)
    DO->>FMS: FMS_UpdateCardHeader (10044 station-ground / 10053 grounds)
    FMS->>FMS: FMS_UpdateGrounds (sum status 10016)
    FMS->>CARD: UPDATE soa_job.Grounds (WHERE card status<50)
    FMS->>EV: RAISE DBEVENT fms_update_grounds

    Note over DO,IR: PERMIT
    DO->>IR: IR_IssueFCRWorkPermit (ProtectionMoveCount) [protection-distance gate]
    IR->>EV: RAISE DBEVENT ir_processingpermit
    DO->>IR: IR_ReturnWorkPermit (permitstatus=50)
    IR->>CARD: IR_CompletePermit -> soa_job (RSComplete/Operator)
    IR->>FMS: IR_WorkPermitUpdate -> fms_workpermit (AcknowledgedByFCR)
    IR->>EV: RAISE DBEVENT ir_permitcomplete

    Note over DO,AUTO: RESTORE (re-energize)
    DO->>SOA: SOA_IssueMove('RS') ; SOA_CompleteMove('RS')
    SOA->>CARD: soa_job.rsissued/rscomplete, soa_card.cutin
    CARD-->>RULE: IR_FMSJobRSComplete
    RULE->>IR: IR_FMSJobUpdate('RC')
    FMS->>EV: RAISE DBEVENT fms_sxcutin

    Note over DO,AUTO: CLOSE + ARCHIVE
    DO->>SOA: SOA_CloseSwitchItem (switemstatus>=50) ; SOA_CardStatusUpd(->50)
    SOA->>CARD: soa_card.status=50 (Closed)
    CARD-->>RULE: SOA_CardDelete (>=50)
    RULE->>SOA: SOA_ActiveListDelete
    SOA->>EV: RAISE DBEVENT SOA_ActiveListChange (DELETE;)
    SOA->>AUTO: SOA_ArchiveJob -> soa_archivejob (+ RAISE SOA_ArchiveTrigger)
```

## How the three layers interlock
1. **Resolution underpins everything:** the switch operated in the take-out step is a `udb_object` whose `type→basetype` resolved to `udb_switch`, giving `normalopen/currentlyopen/relaytype`. Without resolution there is no equipment to switch.
2. **The graph defines the outage:** opening the switch changes the energization of its `udb_node`(s); the terminal/node walk is exactly what the Outage Monitor traces to populate `soa_outagesummary`. Desk/feeder routing comes from the grouping graph (relationship 52).
3. **The order drives state through code, not constraints:** each move's progress is four timestamps + a status band, advanced only by `SOA_*` procs fired by rules, with cross-module truth flowing back via rule cascades and `RAISE DBEVENT`. Integrity is detective; transactions are caller-managed; ~40% of decision logic lives in the **OpenROAD client**, not `d1.sql`.

---

# Deliverable 3 — JOB & JOB CLASS deep-dive (and peer constructs)

**Read-first invariants** `[FACT]`:
- **`job` == `move`** (one operate instruction on one object); it is **not** "a switching order."
- **The order container is the CARD.** A switching order ≈ card + its ordered jobs(moves). There is no `switchingorder` table.
- **Card → ordered StepPairs → Jobs(moves), each move split TakeOut(left)/Restore(right)** — shared across FMS, SOA, TC (and TFMS/SLC/FRA), each app specializing it.
- **No `fms_job` table.** Job INSTANCE tables = `soa_job` + `tc_job` only; FMS holds the job CLASS library (`fms_jobclass`); FMS job-row shape survives in `fms_archivejob`.
- **Status enums DIVERGE per application** (NOT shared): SOA card 10/20/50; FMS card <20/20/50/55/99; TC card 4. Treat per-app.

## Construct 1 — JOB (the switching move)

**Purpose:** a job = one switching MOVE carrying a paired Take-Out (TO) and Restore (RS) half. The atomic unit of switching work; N jobs in `seq`/`steppair` order = the printable switching order.

**`soa_job` (31 cols, PK `job`, btree unique on `job`):**
| Group | Columns |
|---|---|
| Identity | `job, jobclass, basekey, controlcard, shadowlink` |
| Object operated | `equip, equipname, equipclass, equipclassname, grounds, substation, deskname` |
| Two status fields | `status char(3)` (text), `switemstatus integer` (numeric) |
| Move classification | `movetype char(4)` (e.g. `'Dead'`), `movecategory integer` |
| TO half | `tomove varchar(160), tomoverules, tooperator, toissued, tocomplete, groundon` |
| RS half | `rsmove varchar(160), rsmoverules, rsoperator, rsissued, rscomplete, response varchar(40)` |
| Display | `activityidentifier char(1)` (`'S'`=shared), `movefgcolor, movebgcolor` |

`soa_jobcontrol(card, job, switchingitem)` attaches a job in `steppair`/`steplevel`/`seq` order. `soa_job_to_soo(job, seq, ordernumber)` bridges a job to an IR operating order (btree unique, NOT heap).

**`tc_job` (37 cols, btree on `(card, seq, job)`):** same TO/RS shape, specialized for telephone circuits; `status char(3)` known value `'Xfr'`; service `inservice/outservice` drive outage stats; switch position `initialswitchpos/finalswitchpos`; `results/resultscode`. **No `workpermit`/`permitjobid` column.** Sentinels: `job=-1` (staged), `job=2147483647` (max-int), `seq=-1`.

**State machine — `soa_job`** (two orthogonal state fields):
- **(a) `switemstatus integer`** — switching-item lifecycle (the real state machine). Only BANDS are code-proven: `<20` drafted (default 0); `=20` active (`SOA_ActivateSwitchItem` sets `SWItemStatus=:ActiveStatus`, `Response='Active'`); `≥20 AND <50` in-progress; `≥50` closed (`SOA_CloseSwitchItem`). Granular intra-band values `[UNKNOWN-seed]`.
- **(b) `status char(3)`** — confirmed literals only: `' '` normal, `'NIS'` not-in-service, `'Hid'`/`'HID'` hidden (suppresses ISP child jobs), `'Del'` delete move (cascade-deletes `FMS_WorkPermitProtection`), `'Xfr'` transferred. Full domain `[UNKNOWN]`.
- **(c) TO/RS micro-states** = four nullable timestamps. `SOA_IssueMove('TO'/'RS')` and `SOA_CompleteMove('TO'/'RS')` — **`'TO'`/`'RS'` are ACTION SELECTORS, NOT status codes.**

```mermaid
stateDiagram-v2
  direction LR
  [*] --> Drafted: SOA_ItemIns/SOA_JobIns<br/>(switemstatus<20, status=' '/'NIS')
  Drafted --> Active: SOA_ActivateSwitchItem<br/>(switemstatus=20, Response='Active')
  Active --> TOIssued: SOA_IssueMove('TO')<br/>set TOIssued/TOOperator
  TOIssued --> TOComplete: SOA_CompleteMove('TO')<br/>set TOComplete
  TOComplete --> RSIssued: SOA_IssueMove('RS')<br/>set RSIssued/RSOperator
  RSIssued --> RSComplete: SOA_CompleteMove('RS')<br/>set RSComplete
  RSComplete --> Closed: SOA_CloseSwitchItem<br/>(switemstatus>=50)
  Active --> Purged: SOA_CloseSwitchItem<br/>(ClosureRemark='Purge')
  Closed --> Archived: -> soa_archivejob
  Archived --> [*]
  note right of Drafted
    LABELS Drafted/Active/Closed are INFERENCE.
    NUMERIC bands (<20 / =20 / 20-49 / >=50) are FACT.
    status char(3) granular codes = UNKNOWN (seed rows absent).
  end note
```

**`movecategory` — the order-TYPE discriminator** (all code-proven): `0`=normal · `1`=special · `2,3`=**SLC** long-term clearance · `4,5`=substation kV-rated · `6`=**In-Service Permit** move. Full enum `[UNKNOWN]`.

**Cross-module readers/writers of `soa_job`:** IR rules `IR_FMSJob{RSComplete,RSIssued,TOComplete,TOIssued}` → `IR_FMSJobUpdate`; `IR_CompletePermit` writes RSComplete/RSOperator/Response; `FMS_UpdateGrounds` sums status 10016 → `Grounds`; `IR_DelOrderSubJobs`/`IR_DelCompleteSubJobs` DELETE. **Failure modes:** per-move issue is null→timestamp with no idempotency guard (double-issue overwrites operator/time silently); procs are not auto-atomic.

## Construct 2 — JOB CLASS (the move template)

**Purpose:** the reusable template defining a move (move rules, job checks, job actions) per switching app. Every job instance references a `jobclass` (integer FK). The concrete taxonomy is in absent seed rows → `[UNKNOWN]`.

**`fms_jobclass` (7 cols, btree unique on `jobclass`):**
```
jobclass    integer  not null            -- PK
movetype    char(4)  default ' '         -- 4-char operation code (e.g. 'Dead'); enum UNKNOWN
conditional integer  default 0
tomove      varchar(160) default ' '     -- TakeOut instruction-text template
tomoverules integer  default 0
rsmove      varchar(160) default ' '     -- Restore instruction-text template
rsmoverules integer  default 0
```
**No human-readable class-name column** — the label lives in the (seed-dependent) `udb_type` hierarchy.

**The job-class family** (a job class behaves differently per equipclass × step pair × card type × TO/RS leg):
| Table | Cols | Key dimensions | Role | row_est |
|---|---|---|---|---|
| `fms_jobclass` | 7 | `jobclass` | move-text + rules template | 1202 |
| `fms_jobaction` | 9 | `(jobclass, equipclass, steppair, typeofcard, tors, issuecompl, action, status, feederequip)` | status-setting actions on issue/complete | 24676 |
| `fms_jobcheck` | 9 | `(jobclass, equipclass, steppair, typeofcard, tors, issuecompl, jobcheck, status, feederequip)` | validation checks (yellow-warning gating) | 24102 |
| `fms_jobclasscontrol` | 6 | `(jobclass, typeofcard, steppair, equipclass)` + `seq, preferredstep` | step-pair sequencing/placement | 6922 |
| `fms_jobclasslink` | 11 | source→link `(...)` + `seq` | chains one class's leg to another (auto companion moves) | 715 |
| `fms_jobobjective` | 3 | `(jobclass, objective, tors)` | class → Rapid-Restore objective per leg | 85 |
| `fms_jobtoskill` | 2 | `(jobclass, skill)` | class → required operator skill group | 178 |

`tors` = TakeOut/Restore leg; `issuecompl` = issue-vs-complete event; `action`/`jobcheck`/`status` = integer codes into the absent-seed type hierarchy. **State machine: NONE** — a job class is static configuration data (no status column, no lifecycle). **Skill gate:** at Issue Moves and permit return, `FMS_JobToSkill` vs `FMS_PersonToSkill`; mismatch → "Operator is not qualified for this move." **Design rationale:** a data-driven rules engine (≈24k jobaction/jobcheck rows per loader estimate) lets non-programmers author switching rules; the cost is that the actual semantics live in seed data + client 4GL, opaque in this artifact set.

## Construct 3 — SWITCHING ORDER (card + jobs; IR operating order)

"Switching order" maps to **two schema objects**: (A) operator-built order = a CARD + ordered jobs (`soa_card`/`fms_card`/`tc_card` + `soa_job`/`tc_job` via `*_jobcontrol`); (B) electronic operating order = `ir_operatingorder` (issue/return wrapper downloaded to the field — Rapid Restore / SSO, the automatic/substation path).

**Card (`soa_card`, generic container):** `card` (PK), `status integer`, `application varchar(10)` (FMS/SLC/TC/TFMS discriminator), `typeofcard`/`cardclass`, lifecycle timestamps `opened/activated/closed` + `cutout/cutin` + `esttimecomplete/esttimeinservice`, `workpermitflag`, `validated`. Per-app twins add fields (`fms_card`: 47 cols incl. `feederstatus`, `stationground char(3)`, `groundson`, `tv_bogey`).

**`ir_operatingorder` (28 cols, btree on `substation` non-unique, identity `ordernumber`):** `application char(4)`, `card`, `switchingitem`, `ordertarget char(4)`, `ordertype varchar(14)`, `orderstatus int`, `priority int` (forced `=100` on insert), plus issue/download/ack-reject/return/rescind timestamp+actor quads, `msgkey`. Children: `ir_oporderjobs`, `ir_opordersteps`, `ir_oporderfeeders.ispermit` (only structural link to SOA in-service permits).

**Card status (per-app, divergent):** SOA `10`(built)→`20`(active)→`≥50`(closed); FMS `<20`→`20`→`50`, FRA adds `55`(delete)/`99`(terminal), `-1`=key-gen sentinel; TC `status=4`=closed (also blanks `tc_job.status`).

**`ir_operatingorder.orderstatus`** (codes `[UNKNOWN]`, only default 0 seen):
```mermaid
stateDiagram-v2
  direction LR
  [*] --> Inserted: IR_OperatingOrderIns (Priority=100 forced)
  Inserted --> StatusSet: IR_OrderStatusUpd (+IssueTime)
  StatusSet --> Downloaded: IR_DownloadTimeUpd (set DownloadTime)
  Downloaded --> AckRejected: IR_OpOrderAckRejUpd (by SSO)
  AckRejected --> Returned: IR_CompletedTimeUpd (ReturnBySSO)
  StatusSet --> Rescinded: IR_OpOrderRescindUpd (any point)
  Downloaded --> Rescinded
  Returned --> [*]
  Rescinded --> [*]
  note right of Downloaded
    Stage transitions = FACT (proc bodies).
    orderstatus integer codes = UNKNOWN (only default 0 seen).
    DO issues/rescinds; SSO acks/returns.
  end note
```

**Failure modes:** card-status mirror (`FMS_CardStatusChange`) is transactionally coupled to SOA (failed SOA_Card update rolls back the FMS change); per-app status divergence (10/20/50 vs <20/20/50/55/99 vs 4) is a maintenance hazard — no unified status table.

## Construct 4 — OUTAGE (planned & bus-fault)

Two distinct outage modes with separate data paths.

**Planned: `soa_outagerequest` (21 cols, btree unique on `ornumber`):** `ornumber varchar(20)`, `title`, `ossstatus varchar(40)` (free external OSS status), `currentstatus`, `status integer`, `jurisdiction`, and **four scheduled-vs-actual date pairs** (`skedoutagedate/actualoutagedate`, `skedstartdate/actualstartdate`, `skedreturndate/actualreturndate`, `skedinservicedate/actualinservicedate`). Linked to permit jobs via `soa_outagerequestpermit`. **Two state fields:** `ossstatus` (external) AND `currentstatus`/`status` (internal).

**Bus-fault: `soa_busfaultoutage` (67 cols, btree unique on `switchingitem`, widest table in the DB):** one wide denormalized telemetry-capture row per event. Each protection element gets a quad (flag, value/relayname, lastupd, lastupdby): bus differential (`bd*`), bus overcurrent (`boc*`), backup timer (`but*`), feeder target (`ft*`), closed feeder breaker (`clfdrbkr*`), visible-break fault (`vbf*`), power-quality nodes (`pq*`/`pqrms*`), front/back-bus MPR/LOR relays, manhole event, vault-fault FOD, `correlationaction varchar(160)`, `importstatus`. Correlation in `soa_busfaultcorrelationmatrix`. Cross-cutting forced-outage summaries: `soa_outagesummary`, `fms_bussectionoutage`, `fms_networkoutage`, `xa21_outagereport`.

**Planned-outage state machine (`SOA_ORStatusUpd`):** `10`=IMPORTED → `20`=PERMIT → `50`=CLOSED → `70`=RECALLED → `100`=ARCHIVED.
```mermaid
stateDiagram-v2
  direction LR
  [*] --> IMPORTED: Status=10 (OSS import)
  IMPORTED --> PERMIT: Status=20 (permit linked)
  PERMIT --> CLOSED: Status=50
  CLOSED --> ARCHIVED: Status=100
  IMPORTED --> RECALLED: Status=70
  PERMIT --> RECALLED
  RECALLED --> ARCHIVED
  ARCHIVED --> [*]
  note right of IMPORTED
    CurrentStatus labels + numeric codes = FACT (SOA_ORStatusUpd body).
    ossstatus (external OSS status) = separate free-text field, UNKNOWN domain.
  end note
```

**Bus-fault: capture, not approval.** `SOA_BFIns` inserts with all 22 flag/target columns = `-1` sentinel; 16 `SOA_BF*Upd` patch one element group each; `importstatus` tracks ingest. State = `importstatus` + per-element flags transitioning from `-1` to readings, NOT a status enum. **Planned-vs-forced discriminator** = `soa_outagesummary.outagetype integer` (+ likely `latentflag`), codes `[UNKNOWN]`. **Failure modes:** a bus-fault row left at `-1` if patches never arrive → matrix can't recommend an action; Outage Monitor Udb-trace-vs-QGIS contradiction; `ossstatus` (external) and internal `status` can drift.

## Construct 5 — SWITCHING STEP / CARD (StepPair)

**CONTRADICTION resolved:** the premise "is a card a switching step within a job?" is **inverted.** The CARD is the parent container; the **STEP (StepPair) groups jobs(moves) on the card**; the JOB(move) is the unit. Hierarchy: **Card → StepPairs (ordered) → Jobs(moves), each move split TakeOut(left)/Restore(right)** (ug.html:6369-6371).

**Schema:** `fms_steppair(steppair, typeofcard, name)` stores step headings; FMS cards are **preloaded** with all step headings at creation, SLC inserts a heading only when a move exists. **Globally-fixed:** Work Permits step = **Sequence 600**. `soa_jobcontrol` carries `steppair`/`steplevel`/`seq`. Operating-step timing: `fms_operatingstepstatus`/`tc_operatingstepstatus`/`*_archiveoperatingstep` track `starttime`/`endtime`/`durationmins`. Duration is rule-computed (`FMS_CalculateDuration`/`TC_CalculateDuration` AFTER UPDATE(EndTime)). TC adds `TC_DelayCheck` (OperatingStep NOT IN 10147,10134) and `TC_DODelayAdj` (10134); step codes `[UNKNOWN]` beyond these.

## Construct 6 — IN-SERVICE PERMIT (ISP/ISWP)

**Purpose:** a permit to work on equipment **while the system is in service**, approved by Transmission Operator or District Operator (contrast OSWP, out-of-service, which is preceded by isolation switching).

**Schema:** two coupled headers, same PK `ispermit` (hash): `soa_inservicepermit` (33 cols) + `soa_ispermitrequest` (37 cols, the hazard form: relaycalibration, lossofcontrol, ownisolation, liveconnections, asbestos, tripout…). Plus `soa_ispjob`, `soa_ispcondition`, `soa_isprestriction(+item)` (`handsoff` hold flag, `lifttime` release), `soa_isplog`, `soa_ispwithdrawevent/permit`, `soa_ispattachment/binaryfile`. **`soa_iswpequiptype` IS real (d1.sql:10069); `soa_oswpequiptype` is NOT in `d1.sql`** (guide-prose only).

**The MASTER DECODER `SOA_ISPStatusUpd`** (the most fully-decoded enum in the system, the ONE fully-seeded-in-code enum):
| Status | CurrentStatus | RequestStatus | Meaning |
|---|---|---|---|
| 1 | (request) | — | request created |
| 2 | REQUEST | REQUEST | submitted |
| 8 | (interim) | — | aging draft (auto-closed +4 days) |
| 10 | OPEN | — | opened |
| 15 | PENDTO | — | pending Transmission Operator |
| 20 | PENDSO | — | pending System Operator |
| 25 | DENIED | DENIED | denied |
| 30 | PEND | — | pending (reason) |
| 35 | A/COND | — | approved w/ conditions |
| 40 | APPRV | APPROVED* | approved (Request→APPROVED only if ObjectType 0 or 1) |
| 45 | ISSUED | — | issued |
| 50 | ISSUED | APPROVED | issued (approved) |
| 54 | PULLRQ | — | pull requested |
| 55 | PULLED | PULLED | pulled |
| 60 | COMPL | COMPL | returned complete |
| 65 | INCOMPL | INCOMPL | returned incomplete |
| 70 | LOCAL | LOCAL | under local authorization |
| 100 | (archived) | — | archived/closed (sets CloseTime) |

```mermaid
stateDiagram-v2
  direction LR
  [*] --> REQUEST: SOA_ISPRequestSubmit (2)
  REQUEST --> OPEN: 10
  OPEN --> PENDTO: 15
  PENDTO --> PENDSO: 20
  PENDSO --> APPRV: 40
  PENDSO --> ACOND: 35 (A/COND)
  REQUEST --> DENIED: 25
  APPRV --> ISSUED: 45/50
  ACOND --> ISSUED: 45/50
  ISSUED --> PULLED: 54->55
  ISSUED --> COMPL: 60
  ISSUED --> INCOMPL: 65
  ISSUED --> LOCAL: 70
  COMPL --> ARCHIVED: 100
  INCOMPL --> ARCHIVED
  PULLED --> ARCHIVED
  DENIED --> ARCHIVED
  ARCHIVED --> [*]
  note right of PENDTO
    ALL numeric codes + CurrentStatus labels = FACT (SOA_ISPStatusUpd, full 18-state decoder).
    TO=Transmission Operator, SO=System Operator (dual jurisdiction).
  end note
```

**Auto-close sweep `SOA_ISPArchive`:** `Status IN (25,55,60,65,70)` or aging drafts (Status=8, +4 days) → 100; abandoned requests (Status 1/2, +6 months). **`SOA_ISPWithdrawJob`** repoints the underlying work permit (`Application='SLC'`→`SOA_WorkPermit.PermitJobID`, `'TLS'`→`TC_WorkPermit.PermitJobID`). **Rationale:** encodes a real dual-jurisdiction approval workflow (TO + SO both clear) with conditional approval, pull/recall, complete/incomplete returns. **Failure modes:** silent expiry of aging drafts; fragile name/value cross-module repoint.

## Construct 7 — WORK PERMIT

**FOUR distinct permit flavors** (module-specific, NOT one entity):
- **`ir_workpermit`** (30 cols, btree unique on `workpermit`) — the FCR (Field Crew Rep) issue/return transaction.
- **`soa_workpermit`** (17 cols, hash unique on `permitjobid`) — SLC permit detail.
- **`fms_workpermit`** — FMS feeder permit (permitjobid, restoration, acknowledgedbyfcr, phasecheckindicator).
- **`tc_workpermit`** (12 cols, hash unique on `permitjobid`) — TLS circuit permit.

These are **distinct layers, not duplicates** — SOA owns the in-service permit data model (regulatory), IR owns the issue/return transaction; they overlap only at `ispermit`/`job`/`permitjobid` join keys.

**`ir_workpermit` (30 cols):** `workpermit` (PK), revision block (`replacespermitid/revisionnumber/revisiondate`), FCR ownership (`targetfcr char(1)/doname/fcremployeeobjectid`), return block, high-pot block (`highpottype/highpotkv/highpotduration/…`), return-reject block, `permitstatus int`, `protectionmovecount int`. **Protection linkage:** `fms_workpermitprotection(permitcard, permitjobid, protectioncard, protectionjobid, seq, prepost)` ties a permit job to required isolation/ground jobs; `SOA_JobStatusUpd Status='Del'` cascade-deletes these.

**State machine (`permitstatus`):** only one literal proven — `IR_ReturnWorkPermit` hardcodes `PermitStatus=50` (returned). All other codes `[UNKNOWN]`.
```mermaid
stateDiagram-v2
  direction LR
  [*] --> RFP: IR_RFPIns (revisioned RFP)
  RFP --> Acknowledged: IR_AcknowledgeRFP (DO ack/reject/revise)
  Acknowledged --> Created: IR_NewFCRWorkPermit
  Created --> Issued: IR_IssueFCRWorkPermit (TargetFCR, ProtectionMoveCount)
  Issued --> LocationAcked: IR_WorkPermitAck (per-location, skip 'TAG LATER')
  LocationAcked --> Returned: IR_ReturnWorkPermit (permitstatus=50) + ReturnFCRWPLocation/Tags/Equip
  Returned --> Rejected: IR_RejectPermit (returns to issued)
  Rejected --> Issued
  Returned --> Completed: IR_CompletePermit (->SOA_Job) / IR_WorkPermitUpdate (->FMS_Workpermit)
  Completed --> [*]
  note right of Issued
    permitstatus=50 (Returned) = FACT (IR_ReturnWorkPermit body).
    All other permitstatus/rfpstatus codes = UNKNOWN (seed rows absent).
    'TAG LATER' bulk-ack skip = FACT.
  end note
```

**Protection trace at issue:** Feeder Diagram compares actual vs suggested protections; target ground = Green(OK)/Yellow(beyond Acceptable Protection Distance)/Red(Missing); DO alerted to red when attempting to issue. **Aging:** permit past ETC + `FMS ETC Deadband` → Task Monitor writes `itc_eetccard`, reddens button; past ETC by `FMS Inactivity OTW Alarm` days = "Aged." **Failure modes:** `permitjobid↔job` is name/value with no declared FK (stale id orphans the permit); `'TAG LATER'` locations skipped by bulk-ack can be left un-acked; ETC/aging is timer-driven (if Task Monitor is down, no alerts).

## Construct 8 — SESAME LOCK / CLEARANCE

**Purpose:** a "sesame lock" = an electronic/combination lock applied to field equipment to enforce clearance / lockout-tagout (LOTO). The card is the records-of-record data-entry artifact. **NB:** "clearance" is NOT a defined vocabulary term in ug.html; OSWP/permit is the nearest concept.

**`fms_sesamelockcard` (65 cols, btree unique on `(division, received, feeder, equip)`).** *Contradiction resolved this pass: one source doc said 71 cols; direct DDL count = **65**; 65 is authoritative.* Second-widest table in the DB (next after `soa_busfaultoutage` at 67). Structure: provenance, lock identity (`combono/serialno/lockno/sesamelock`), per-phase locks (`phasea/b/c` + serials/locks), equipment-type flags, component-lock triples (`powersupply/handheld/scada/manual` + three CAM units), ratings, `remarks varchar(300)`.

**State machine — NONE (descriptive, NOT a live state machine).** The only lifecycle bit is `processed integer` (0→1).
```mermaid
stateDiagram-v2
  direction LR
  [*] --> Entered: FMS_SesameLockCardIns (FormType 0=full / else=component variant)
  Entered --> Processed: FMS_SesameLockCardUpd (Processed=1, set Equip/UpdateTime/ByDO)
  Processed --> Deleted: FMS_SesameLockCardDel (by FormID)
  Deleted --> [*]
  note right of Entered
    INSERT/UPDATE(processed 0->1)/DELETE only. No clearance state machine.
    Timestamp columns (received/installdate/approvaldate) imply received->installed->approved
    but NO transition procs enforce it (INFERENCE).
  end note
```

**CRITICAL failure mode:** **clearance ENFORCEMENT is NOT visible** — no proc cross-checks `fms_sesamelockcard` before allowing a switching move. The card is **descriptive, not enforcing.** Operational lock-state that *gates* moves lives elsewhere (`udb_object.lockNumber`/`combination`, live `fms_objectstatus` grounds status 10016/10053). `SetSesameLockCardFormID` back-fills FormIDs in a WHILE loop with **per-row COMMIT** — a crash mid-loop leaves FormIDs partially assigned (non-atomic).

### Cross-construct map
```
                         fms_jobclass (TEMPLATE, 7 cols)
                         + jobaction/jobcheck/jobclasscontrol/jobclasslink/jobobjective/jobtoskill
                                 │ drives (read at build/issue/complete)
                                 ▼
CARD (soa_card/fms_card/tc_card) ──contains──> StepPair (fms_steppair, Seq 600=permits)
   │  status: SOA 10/20/50 · FMS <20/20/50/55/99 · TC 4          │ orders
   │                                                              ▼
   │                                          JOB / MOVE (soa_job 31c / tc_job 37c)
   │                                          switemstatus <20/=20/20-49/>=50
   │                                          status char(3): ' '/NIS/Hid/Del/Xfr
   │                                          TO half ─── RS half (issue->complete each)
   ├──> ir_operatingorder (electronic order, issue->download->ack->return->rescind)
   ├──> WORK PERMIT (ir_workpermit 30c · soa_workpermit 17c · fms_workpermit · tc_workpermit)
   │       permitstatus=50=Returned; fms_workpermitprotection ties to isolation/ground jobs
   ├──> IN-SERVICE PERMIT (soa_inservicepermit 33c + soa_ispermitrequest 37c)
   │       SOA_ISPStatusUpd 18-state: REQUEST->PENDTO->PENDSO->APPRV->ISSUED->COMPL->100
   ├──> OUTAGE: planned soa_outagerequest (10/20/50/70/100) | bus-fault soa_busfaultoutage (67c, -1 sentinels)
   └──> SESAME LOCK (fms_sesamelockcard 65c, processed 0/1, DESCRIPTIVE not enforcing)
```

---

# Deliverable 4 (Phase 6) — Modernization & Optimization

**Target:** SQL Server 2025 + .NET 9/10, on-premises, regulated OT/IT (NERC-CIP-adjacent), 24/7 grid-critical. Data stays in-enterprise; GIS/Esri, SCADA/EMS, planning integrations are first-class. Method: `problem → evidence → change → benefit → risk & effort (S/M/L)`.

**The central tension, stated once:** UDB was attractive because **a new equipment type is a data row, not a DDL migration**. That metadata-driven flexibility is the one property a 24/7 grid-critical schema must preserve. BUT the flexibility is **half-fake**: dispatch is a hard-coded 22-branch ladder, and adding a base type needs **both** a `udb_basetype` row **and** a code edit. So the real requirement: **adding a new TYPE under an existing BASETYPE is already DDL-free; adding a new BASETYPE (new attribute shape) is not.** Every option is judged against that actual requirement.

## Executive ranking (value vs effort)

| Rank | Recommendation | Value | Effort |
|---|---|---|---|
| 1 | **Recover the absent `.ingres` seed data from the live DB before anything else** | Blocking | S |
| 2 | **Add declared PK + UNIQUE constraints** matching the 377 `modify … unique on` keys | High | S |
| 3 | **Hybrid data model** (metadata-driven typed root + per-basetype subtype tables + JSON extension), NOT pure STI, NOT graph-as-storage | High | M |
| 4 | **Add FKs for the high-traffic join keys** (`object`, `card`, `job`, `permitjobid`, `node`) staged | High | M |
| 5 | **Replace the 35 archive twins + audit columns with system-versioned temporal tables** | High | M |
| 6 | **Ledger tables for the regulated audit trail** (switching-order/clearance/permit history) | High (compliance) | M |
| 7 | **Anti-corruption boundary services for GIS/Esri, SCADA/EMS, planning** (map to CIM at boundary only) | High | L |
| 8 | **Move SAFE integrity into CHECK/computed/FK; keep grasscatcher detective layer for soft rules** | Medium-High | L |
| 9 | **Replace `*_lastkey` single-row allocators with SEQUENCE objects** | Medium | S |
| 10 | **SQL Server graph tables for connectivity** (query/trace layer, not the equipment store) | Medium | M |
| 11 | **Strangler-fig migration; re-home the OpenROAD client 4GL into a .NET service tier** | Gating for cutover | L |

## 1. Target data-model options

**Three storage options, judged against schema-stability:**
| Option | DDL-free new TYPE? | DDL-free new BASETYPE? | Verdict |
|---|---|---|---|
| **A. Pure STI** (one wide table, sparse columns, discriminator) | Yes | Yes | **Reject as sole model** — recreates the `udb_object` god-table + sentinel-default anti-pattern |
| **B. Pure CTI** (today's model: root + rigid per-type tables) | Yes | **No (new table = DDL)** | **Reject as sole model** — this is exactly today's pain |
| **C. Hybrid (RECOMMENDED)** — root + per-**basetype** typed subtype tables for the ~22 stable shapes + a schema-validated JSON extension column on root for the long tail | Yes | **Yes** via JSON; DDL only to promote a hot attribute | **Adopt** |

The model already IS a hybrid (wide root + 22 CTI tables + `tablename=''` no-op). The 22 stable physics shapes deserve **real typed tables with CHECK constraints**; the long tail (≥19 base types with no insert branch, future equipment) belongs in a schema-validated `nvarchar(max)` JSON column with `ISJSON`/`JSON_PATH` CHECK constraints.

**Recommended target model:**
```
Equipment (root, system-versioned temporal)
  ├─ EquipmentType  (type, basetype, name, …)         ← metadata; new TYPE = INSERT
  ├─ Basetype       (basetype, subtype_table, editor)  ← metadata; subtype_table nullable
  ├─ per-basetype typed subtype tables (Transformer, Switch, Conductor, … ~22)
  │     1:1 on equipment_id, REAL CHECK/FK constraints
  ├─ ExtensionJson  nvarchar(max)  CHECK (ISJSON(...)=1)  ← long-tail / new shapes, DDL-free
  ├─ Node / Terminal      → SQL graph EDGE for electrical connectivity trace
  └─ Grouping (typed edges)→ SQL graph EDGE for containment / roll-up
Regulated facts (switching order, ISP, work permit, clearance) → LEDGER (append, tamper-evident)
```
**Replace the `object$insert` hard-coded ladder** with metadata-driven dispatch (subtype_table selected from `Basetype`, not `IF/ELSEIF`) — eliminates the "add a basetype = edit a stored proc" trap AND the confirmed stale-basetype desync bug.

**Temporal tables** replace the 35 archive twins + audit columns: make operational tables `SYSTEM_VERSIONED`; drop the twins; the engine maintains history transactionally (point-in-time `FOR SYSTEM_TIME AS OF`, no silent archive-failure class). **Risk/effort M:** legacy archive tables sometimes carry an older column shape (e.g. `fms_archivejob` is the only place the FMS job-row shape survives) — reconcile first; bus-fault/outage capture tables are append telemetry, leave as plain.

**Ledger tables** for the regulated surface (switching-order transitions, ISP approvals, work-permit issue/return, clearance) give cryptographic tamper-evidence — directly answers the CIP "who did what, provably" question that flat `public` security cannot. **Risk/effort M:** legacy *updates rows in place*; must model as append-per-transition (event rows), a real redesign for those few tables. Do NOT ledger high-churn operational tables.

**Graph tables** for connectivity (`udb_terminal.node` adjacency + `udb_grouping` ~295k-edge containment) as NODE/EDGE tables; express the trace as `MATCH`/`SHORTEST_PATH`. **Risk/effort M:** two coexisting connectivity models — TOMS/DSO use the QGIS geometry model, only SMS/FMS-3G/Staten-Island-33kV use the Udb terminal/node model. Graph tables solve the terminal/node model; do NOT make them the equipment store.

## 2. Critical DB optimizations

- **2.1 Declare PK + UNIQUE (effort S):** generate from the 377 `modify … unique on` column lists; the optimizer gets real cardinality; duplicate-key bugs become engine-enforced. Risk: data violating the de-facto key today — surface violations first.
- **2.2 Add FKs on hot join keys, staged NOT-ENFORCED → ENFORCED (effort M):** `equipment_id`, `card`, `job`, `permitjobid`, `node`; roll out `WITH NOCHECK` → `WITH CHECK` once clean; replace hand-coded cascade ladders with declared `ON DELETE CASCADE` only where the legacy proc cascades unconditionally. Risk: orphans already exist; preserve the `udb_object` delete-ban + re-type-to-Historical(998) pattern (model as soft-delete/status).
- **2.3 Move SAFE integrity into CHECK/computed columns (effort L):** `CHECK (OutService >= InService)`, `CHECK (object <> 0)`; express denormalized caches (`basetype/typename`, `membertype/groupingtype`) as computed columns / indexed views so they cannot desync — kills the stale-basetype latent bug. Risk: not every validator is row-local (the X/R<5 conductor check is a soft warning).
- **2.4 Keep the grasscatcher as the DETECTIVE layer (effort L):** promote `severity='F'` rules to real constraints/triggers (preventive); keep non-fatal rules as a data-quality exception table. Gated on recovering `udb_problem` severity seed rows.
- **2.5 Secondary indexes + self-documenting schema (S/M):** add nonclustered indexes on proven hot predicates (status bands, card/job/desk filters, `node` joins, `relationship=52` lookups); add a code-table-backed enum layer + `MS_Description` so `status=10016` reads as `STATION_GROUND_ON` (gated on seed recovery).
- **2.6 Replace `*_lastkey` allocators with SEQUENCE objects (effort S):** removes per-row contention, removes the 8 copy-paste `CAC_KeyGenerator` bodies + inlined idioms. Risk: callers pass `-1` to request a key — re-home that convention.

## 3. Integration architecture — anti-corruption boundaries

**Principle:** the modernized PSM model is the system of record; every external system gets a .NET ACL service translating its vocabulary/shape into PSM's, **no shared tables**. Benchmark PSM vocabulary against IEC CIM (61970/61968) **for naming/mapping only — never store CIM**. Data stays in-enterprise.

- **3.1 GIS / Esri (eGIS) + pvl/QGIS (effort M-L):** three GIS surfaces already exist as load/cross-ref tables (`egis_xreference`+`egis_nfload`; `pvl_*` daily feeder load; `dso_object`/`dso_connection` = derived render cache of `Udb_Object`). Formalize each as an ACL; PSM equipment id is canonical; keep `dso_object` as a read-projection. CIM mapping (in the ACL table only): `udb_switch→cim:Switch/Breaker`, `udb_conductor→cim:ACLineSegment`, `udb_transformer→cim:PowerTransformer`, `udb_winding→cim:PowerTransformerEnd`, `udb_node→cim:ConnectivityNode`, `udb_terminal→cim:Terminal`, `udb_consumer→cim:EnergyConsumer`. Risk: the QGIS bridge is bidirectional (UI↔DB via dbevents) — preserve the push channel.
- **3.2 SCADA / EMS (XA/21, RTU, telemetry) (effort L):** `xa21_outagereport` is a bare INSERT; the XA21 bridge is **partly manual** (new excluded breaker types trigger an *email to support staff*); `udb_telemetry`/`udb_scanblock` are point-map config with no ingest proc in the dump (external EMS scanner). Put an EMS/SCADA ACL in front: staging shape → validate/correlate → operational model; automate the XA21 exclusion sync (replace the email with a queued change feed). Risk: the live EMS contract (XA/21) is external — reverse-engineer from the live interface, not the dump (highest-uncertainty integration).
- **3.3 Planning + ddb dual-target replication (effort L):** a home-grown statement-shipping layer (`*ddb_log`/`DDB_LogEntry → RAISE DBEVENT` + external daemon) **coexists with native Ingres Replicator** (two mechanisms). On SQL Server, replace **both** with one supported HA path (Always On availability groups), retiring the `ddb_*` spool + daemon. Planning (NWP) gets a read-replica + a CIM 61970 export contract. Risk: the dual-target topology is load-bearing for 24/7 — prove failover before retiring the old path.

## 4. Migration sequencing

**Strategy: strangler-fig, NOT big-bang.** Stand the new SQL Server model beside Ingres, migrate module-by-module behind ACLs, keep the old DB authoritative until each slice is proven.

**4.1 FIRST (blocking, risk S):**
1. **Recover the absent `.ingres` seed data from the live production DB** — full `udb_type`/`udb_basetype`/`udb_supertype` catalogs, `udb_problem` severity dictionary, all status/jobclass/movecategory/movetype/outagetype enumerations, LastKey counters. **Nothing downstream can be specified without these.** Extract from the running instance (not the dump). If the live DB is gone, large parts stay `[UNKNOWN]` — project-existential risk.
2. **Inventory the OpenROAD client 4GL behavioral surface** — 872 `ON` handlers + 67 dual-write wrappers; `Switch.NotifyXA21()`, `Switch.SplitCombo()`, `LoadTypeList()`, `SOA_DetermineMoveSequence`/`CheckDeloadComplete` (absent from ALL artifacts), COMMIT/ROLLBACK + dual-session replication. These are the true behavioral spec, not the 1,225 procs.

**4.2 NEXT (risk M):**
3. Build the metamodel + UDB core on SQL Server (§1 hybrid: root + typed subtype tables + JSON extension + metadata-driven dispatch + temporal + connectivity graph).
4. Add declared PK/UNIQUE → staged FKs → SAFE CHECK/computed, in that order.
5. **Re-home the client 4GL into a .NET service tier with EXPLICIT transaction boundaries** — the single highest-risk re-host: procs are caller-managed, not auto-atomic; several `RETURN -1` *after* a successful first write. A naive service that doesn't wrap each unit-of-work in an explicit transaction **will corrupt state.** Wrap; do not copy the partial-write hazard forward.
6. Migrate operational modules behind ACLs, lowest-coupling first: peripheral/reference (`cac_`, `tm_`, messaging) → then the switching core (`soa_`/`fms_`/`ir_`) as ONE coordinated slice (tight cross-module rule cascades). **TC is special:** all 127 procs are stubs — reconstruct server logic from rules+DDL+guide; budget extra discovery.

**4.3 DEFER (risk L):**
7. Ledger tables for the regulated surface (requires event-sourced redesign of permit/clearance state).
8. Replace both replication mechanisms with Always On (defer until you can prove failover).
9. Graph-table connectivity trace (defer behind seed-data recovery and the QGIS-vs-Udb "which model is live" contradiction).
10. Retire the 6 OpenROAD editors with no server proc (`udb_dsovalveupd` etc.) — resolve against the live system before assuming they're dead.

**The two hard parts:** (a) **absent `.ingres` data** — no row data in the dump; migration data MUST come from the live Ingres instance via a one-time per-table export in a freeze window. (b) **re-homing 4GL** — port the 872 handlers + absent move-sequencing 4GL as explicit tested .NET services, NOT a thin pass-through over the old procs (which would carry the partial-write hazard and caller-managed-transaction trap forward).

---

# Cross-cutting residual UNKNOWNs

`[UNKNOWN-seed / UNKNOWN]` and their blast radius — all gated on recovering live data:
- **All seed catalogs** (type/basetype/supertype/problem/status/jobclass/movetype/movecategory/outagetype) — gate the type map, severity→constraint routing, enum layer, FK targets. **Recoverable only from the live DB.**
- **Human meaning of magic ids** (05/21/26/52/10093/15028, 998/22173/22174, 10016/10044/10053/10110/10147) — labels need seed rows.
- **The move-sequencing + connectivity-trace 4GL** (`SOA_DetermineMoveSequence`, `CheckDeloadComplete`, the Outage Monitor trace) — absent from `d1.sql` AND both `.dmt` files.
- **The exact SOA proc that enqueues into `fms_objectstatusqueue`** — lives in SOA's procs, not located.
- **The live EMS/XA21 ingest contract and the ddb replicator daemon** — external binaries, not in artifacts.
- **Which connectivity model is authoritative now** (Udb terminal/node vs rebuilt-on-QGIS) — unresolved contradiction.
- **Whether `systemversion` is enforced on UPDATE** — not visible in sampled bodies.
- **The exact stub count** (1,225 vs 1,163, differ by ~62) — cross-doc contradiction; 1,225 preferred (five exact-grep passes).
- **Whether the dump's mid-token line-wraps survive loading** (the `'Generator'` literal question).
- **Exact identities of the ≥19 base types with no `object$insert` dispatch branch.**
- **The 6 OpenROAD editors with no server proc** — dead frames or incomplete dump, undisambiguable.

Until the seed-data gap closes, the model *shape* (this document) is specifiable but the *semantics* (which status means what, which problems reject) are not.
