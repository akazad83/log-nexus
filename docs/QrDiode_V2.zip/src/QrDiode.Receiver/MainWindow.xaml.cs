using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using FlashCap;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Core.Presentation;
using QrDiode.Core.Simulation;
using QrDiode.Receiver.Capture;
using QrDiode.Receiver.Inbox;
using QrDiode.Receiver.Storage;
using QrDiode.Ui;

namespace QrDiode.Receiver;

public partial class MainWindow : Window
{
    /// <summary>The chain, in the exact order the engine enforces it. Index = how far a session got.</summary>
    private static readonly string[] ChainSteps =
    [
        "Manifest structure",
        "Manifest signature (ECDSA P-256)",
        "Addressed to this receiver key",
        "Anti-replay window",
        "Ciphertext hash",
        "AES-256-GCM decrypt",
        "Decompression cap",
        "Plaintext hash",
        "Content gate",
        "Stored to the local store",
    ];

    private CngEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    /// <summary>Opened for the app's lifetime: the archive tab reads it while nothing is receiving.</summary>
    private readonly SqliteJournal _journal;
    private readonly ReceiverSettings _settings;
    private readonly PayloadStore _store;
    private ReceiveEngine? _engine;
    private QrDecodePipeline? _pipeline;
    private readonly AuditLog _audit;
    private WriteableBitmap? _previewBitmap;
    private QrDecodePipeline.LumFrame _pendingPreview;
    private readonly DispatcherTimer _uiTimer;

    private readonly ObservableCollection<InboxEntry> _inbox = [];
    private readonly ListCollectionView _inboxView;
    private InboxEntry? _selected;
    private PayloadText _selectedText = PayloadText.Empty;

    private DateTime _runStartedUtc;
    private DateTime? _sessionStartedUtc;
    private Guid _lastActiveSession;
    private long _lastQrHits;
    private int _tallyOk, _tallyDup, _tallyBad;
    /// <summary>XAML property setters raise Checked/SelectionChanged while the tree is half-built.</summary>
    private bool _ready;

    private sealed record CameraChoice(CaptureDeviceDescriptor Descriptor, VideoCharacteristics Characteristics)
    {
        private double Fps => Characteristics.FramesPerSecond.Numerator /
                              Math.Max(1.0, Characteristics.FramesPerSecond.Denominator);

        // The pixel format is on the label because it decides how the frame gets decoded — an
        // operator chasing a dead preview should not have to guess what the camera is emitting.
        public string Label =>
            $"{Descriptor.Name} — {Characteristics.Width}×{Characteristics.Height} @ {Fps:0.#} fps · {Characteristics.PixelFormat}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "receiver-audit.jsonl"));

        _settings = ReceiverSettings.Load();
        _store = new PayloadStore(_settings);
        _journal = new SqliteJournal(QrDiodePaths.JournalDb);

        _inboxView = (ListCollectionView)CollectionViewSource.GetDefaultView(_inbox);
        _inboxView.Filter = o => o is InboxEntry entry && PassesFilter(entry);
        InboxList.ItemsSource = _inboxView;

        _uiTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(150) };
        _uiTimer.Tick += OnUiTick;

        _ready = true;
        RefreshCameras_Click(this, null!);
        RefreshTrustPill();
        RenderDetail(null);
        InitArchive();
        UpdateButtons();
    }

    // ═══════════════════ identity, trust, camera ═══════════════════

    private void RefreshTrustPill()
    {
        using var trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);
        int senders = trust.Peers.Count(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId));
        SetPill(TrustPill, TrustPillText,
            senders > 0 ? $"✔ {senders} trusted sender{(senders == 1 ? "" : "s")}" : "✖ 0 trusted senders",
            senders > 0 ? "PillOk" : "PillBad");
    }

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _keys?.Dispose();
            _keys = CngEndpointKeys.OpenOrCreate(EndpointNameBox.Text.Trim());
            KeyInfoText.Text = $"kex {KeyId.ToHex(_keys.AgreementKeyId)} — senders must address transfers to this key.";
            SetPill(KeyPill, KeyPillText, _keys.IsTpmBacked ? "✔ TPM-backed" : "✔ software KSP", "PillOk");
            HideError();
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            SetPill(KeyPill, KeyPillText, "✖ error", "PillBad");
            _keys = null;
        }
        RefreshTrustPill();
        UpdateButtons();
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.ItEndpoint;
            OpenKeys_Click(sender, e);
            RibbonText.Text =
                $"demo ready · ot {ids.OtFingerprint[..19]}… · it {ids.ItFingerprint[..19]}… — " +
                "pick a camera, press Start, and aim it at the OT stage";
        }
        catch (Exception ex)
        {
            ShowError($"Demo setup failed: {ex.Message}");
        }
    }

    private void RefreshCameras_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            CameraCombo.ItemsSource = QrDecodePipeline.EnumerateCameras()
                .Select(c => new CameraChoice(c.Descriptor, c.Characteristics)).ToList();
            if (CameraCombo.Items.Count > 0) CameraCombo.SelectedIndex = 0;
            else ShowError("No camera found. Connect a webcam and press ↻ Refresh.");
        }
        catch (Exception ex)
        {
            ShowError($"Camera enumeration failed: {ex.Message}");
        }
        UpdateButtons();
    }

    private void Camera_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready) return;
        CameraBadgeText.Text = (CameraCombo.SelectedItem as CameraChoice)?.Label ?? "no camera";
        UpdateButtons();
    }

    private void UpdateButtons()
    {
        bool running = _pipeline is not null;
        StartButton.IsEnabled = !running && _keys is not null && CameraCombo.SelectedItem is not null;
        StopButton.IsEnabled = running;

        // Identity, camera and Strict mode are committed for the whole run — the journal's
        // replay window and the addressed key cannot change under a session in flight.
        EndpointNameBox.IsEnabled = !running;
        CameraCombo.IsEnabled = !running;
        StrictModeCheck.IsEnabled = !running;
        StrictModeCheck.ToolTip = running
            ? "Stop receiving to change."
            : "Recommended whenever the sender's and receiver's clocks are in sync.";

        SetPill(RunPill, RunPillText, running ? "● receiving" : "● stopped", running ? "PillOk" : "PillIdle");
    }

    // ═══════════════════ run lifecycle ═══════════════════

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (_keys is null || CameraCombo.SelectedItem is not CameraChoice camera) return;

        try
        {
            _trust?.Dispose();
            _trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);
            RefreshTrustPill();
            if (_trust.Peers.Count == 0)
            {
                ShowError("Trust store is empty — import the OT sender’s bundle (KeyCeremony tool) " +
                          "or use ⚡ Demo setup on both apps.");
                return;
            }
            HideError();

            // A store that cannot be written to must fail here, not three payloads into a session
            // with verified plaintext in hand and nowhere to put it.
            try
            {
                _store.EnsureReady();
            }
            catch (Exception ex)
            {
                ShowError($"The local store at “{_store.Root}” is not writable: {ex.Message} — " +
                          "pick another folder on the Archive tab.");
                return;
            }

            // Strict mode: shrink the replay acceptance window from 48 h to 15 min.
            _journal.ReplayWindow = StrictModeCheck.IsChecked == true
                ? TimeSpan.FromMinutes(15)
                : TimeSpan.FromHours(48);

            _engine = new ReceiveEngine(_trust, _journal, _keys);
            _runStartedUtc = DateTime.UtcNow;
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            _lastQrHits = 0;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            ProgressText.Text = "waiting for a manifest…";
            RibbonText.Text = "receiving · waiting for the first manifest";

            _pipeline = new QrDecodePipeline(OnQrPayload, frame => _pendingPreview = frame);
            await _pipeline.StartAsync(camera.Descriptor, camera.Characteristics);

            _audit.Append("receive.started", new Dictionary<string, string>
            {
                ["camera"] = camera.Label,
                ["endpoint"] = EndpointNameBox.Text.Trim(),
                ["strictMode"] = (StrictModeCheck.IsChecked == true).ToString(),
                ["storageRoot"] = _store.Root,
            });

            PreviewHint.Visibility = Visibility.Collapsed;
            _uiTimer.Start();
        }
        catch (Exception ex)
        {
            ShowError($"Failed to start: {ex.Message}");
            if (_pipeline is not null) { await _pipeline.DisposeAsync(); _pipeline = null; }
        }
        UpdateButtons();
    }

    private async void Stop_Click(object sender, RoutedEventArgs e)
    {
        _uiTimer.Stop();
        if (_pipeline is not null)
        {
            await _pipeline.DisposeAsync();
            _pipeline = null;
        }
        PreviewHint.Visibility = Visibility.Visible;
        SetLock(false);
        RibbonText.Text = "stopped · the inbox keeps everything received in this run";
        PreviewProgressText.Text = "idle";
        UpdateButtons();
    }

    /// <summary>Called from the capture thread for every decoded QR payload.</summary>
    private void OnQrPayload(byte[] payload)
    {
        var engine = _engine;
        if (engine is null) return;

        var result = engine.Feed(payload);
        if (result == FeedResult.Completed)
        {
            Dispatcher.BeginInvoke(HandleCompletion);
        }
        else if (result == FeedResult.Rejected)
        {
            // Snapshot on this thread: another frame may overwrite the engine's last rejection
            // before the dispatcher gets round to us.
            var info = engine.LastRejectionInfo ?? new RejectionInfo(engine.LastRejection, null);
            Dispatcher.BeginInvoke(() => HandleRejection(info));
        }
    }

    // ═══════════════════ outcomes ═══════════════════

    private void HandleCompletion()
    {
        var engine = _engine;
        if (engine?.Completed is not { } completed) return;

        var manifest = completed.Manifest;
        double seconds = (DateTime.UtcNow - (_sessionStartedUtc ?? _runStartedUtc)).TotalSeconds;
        var type = PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType);
        string senderKey = "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId));

        try
        {
            if (_journal.IsDuplicateContent(manifest.SenderSigningKeyId, manifest.PlaintextSha256))
            {
                _journal.RecordTransfer(manifest.SessionId, manifest.PlaintextSha256, manifest.Filename,
                    manifest.OriginalSize, "duplicate");
                _audit.Append("receive.duplicate", new Dictionary<string, string>
                {
                    ["session"] = manifest.SessionId.ToString(),
                    ["file"] = manifest.Filename,
                });

                AddEntry(new InboxEntry
                {
                    Type = type,
                    Name = manifest.Filename,
                    Size = manifest.OriginalSize,
                    ArrivedAt = DateTime.Now,
                    Outcome = InboxOutcome.Duplicate,
                    SenderKeyShort = senderKey,
                    SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                    SessionId = manifest.SessionId.ToString("N"),
                    Receipt = completed.ReceiptHash,
                    Seconds = seconds,
                    ContentType = manifest.ContentType,
                    Counter = manifest.Counter,
                    PlaintextSha256 = Convert.ToHexString(manifest.PlaintextSha256),
                    Reason = "This exact content from this sender was already stored earlier. " +
                             "Nothing was written — idempotency guaranteed.",
                    Chain = DuplicateChain(),
                    PreviewData = Capped(completed.Plaintext),
                    PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                    Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
                });
                return;
            }

            // Atomic materialization into the configured store: staging write + fsync, then rename.
            string finalPath = _store.Save(manifest, completed.Plaintext, completed.ReceiptHash, DateTime.Now);

            _journal.RecordTransfer(manifest.SessionId, manifest.PlaintextSha256, manifest.Filename,
                manifest.OriginalSize, "stored");
            _audit.Append("receive.completed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["file"] = manifest.Filename,
                ["stored"] = finalPath,
                ["size"] = manifest.OriginalSize.ToString(),
                ["sha256"] = Convert.ToHexString(manifest.PlaintextSha256),
                ["receipt"] = completed.ReceiptHash,
            });

            TransferProgress.Value = 1;
            ProgressPercent.Text = "100%";

            AddEntry(new InboxEntry
            {
                Type = type,
                Name = manifest.Filename,
                Size = manifest.OriginalSize,
                ArrivedAt = DateTime.Now,
                Outcome = InboxOutcome.Verified,
                SenderKeyShort = senderKey,
                SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                SessionId = manifest.SessionId.ToString("N"),
                Receipt = completed.ReceiptHash,
                StoredPath = finalPath,
                Seconds = seconds,
                ContentType = manifest.ContentType,
                Counter = manifest.Counter,
                PlaintextSha256 = Convert.ToHexString(manifest.PlaintextSha256),
                Chain = VerifiedChain(manifest, seconds),
                PreviewData = Capped(completed.Plaintext),
                PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
            });
        }
        catch (Exception ex)
        {
            _audit.Append("receive.store_failed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["error"] = ex.Message,
            });
            AddEntry(new InboxEntry
            {
                Type = type,
                Name = manifest.Filename,
                Size = manifest.OriginalSize,
                ArrivedAt = DateTime.Now,
                Outcome = InboxOutcome.StoreFailed,
                SenderKeyShort = senderKey,
                SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                SessionId = manifest.SessionId.ToString("N"),
                Receipt = completed.ReceiptHash,
                Seconds = seconds,
                ContentType = manifest.ContentType,
                Counter = manifest.Counter,
                PlaintextSha256 = Convert.ToHexString(manifest.PlaintextSha256),
                Reason = $"Payload verified but not stored: {ex.Message}",
                Chain = StoreFailedChain(ex.Message),
                PreviewData = Capped(completed.Plaintext),
                PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
            });
        }
        finally
        {
            // Back-to-back sessions: clear the in-flight state so the next manifest is picked up.
            // The engine remembers this session, so the tail of the sender's carousel is ignored
            // rather than re-judged.
            engine.Reset();
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            RibbonText.Text = "session complete → waiting for the next manifest";
        }
    }

    private void HandleRejection(RejectionInfo info)
    {
        _audit.Append("receive.rejected", new Dictionary<string, string> { ["reason"] = info.Reason });

        var manifest = info.Manifest;
        var type = manifest is not null
            ? PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType)
            : PayloadCatalogue.ManualFile with { Name = "unverified frame", Code = "???" };

        // The carousel replays a bad manifest for the rest of its air time; identical
        // back-to-back rejections coalesce into one row instead of flooding the inbox.
        if (_inbox.FirstOrDefault() is { Outcome: InboxOutcome.Rejected } top &&
            top.Reason == info.Reason &&
            (DateTime.Now - top.ArrivedAt) < TimeSpan.FromSeconds(30))
        {
            top.Repeats++;
            _engine?.Reset();
            return;
        }

        AddEntry(new InboxEntry
        {
            Type = type,
            Name = manifest?.Filename ?? "unverified frame",
            Size = manifest?.OriginalSize ?? 0,
            ArrivedAt = DateTime.Now,
            Outcome = InboxOutcome.Rejected,
            SenderKeyShort = manifest is not null
                ? "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId))
                : "sender not established",
            SenderKeyId = manifest is not null ? KeyId.ToHex(manifest.SenderSigningKeyId) : "",
            SessionId = manifest?.SessionId.ToString("N") ?? "",
            ContentType = manifest?.ContentType ?? ContentKind.File,
            Counter = manifest?.Counter ?? 0,
            Reason = info.Reason,
            Chain = RejectionChain(info.Reason),
        });

        _engine?.Reset();
        _sessionStartedUtc = null;
        _lastActiveSession = Guid.Empty;
        TransferProgress.Value = 0;
        ProgressPercent.Text = "0%";
        RibbonText.Text = "session rejected — nothing was written → waiting for the next manifest";
    }

    // ═══════════════════ verification chain ═══════════════════

    private static IReadOnlyList<ChainStep> VerifiedChain(TransferManifest manifest, double seconds) =>
    [
        new(ChainSteps[0], ChainStatus.Passed, "CRC-32 + span parse"),
        new(ChainSteps[1], ChainStatus.Passed, "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId))),
        new(ChainSteps[2], ChainStatus.Passed, "kex " + Short(KeyId.ToHex(manifest.ReceiverAgreementKeyId))),
        new(ChainSteps[3], ChainStatus.Passed, $"counter {manifest.Counter}"),
        new(ChainSteps[4], ChainStatus.Passed, "sha256 " + Short(Convert.ToHexString(manifest.CiphertextSha256))),
        new(ChainSteps[5], ChainStatus.Passed, "tag ok"),
        new(ChainSteps[6], ChainStatus.Passed, manifest.Compression == CompressionAlg.Brotli
            ? $"{manifest.CompressedSize:N0} → {manifest.OriginalSize:N0} B" : "not compressed"),
        new(ChainSteps[7], ChainStatus.Passed, "sha256 " + Short(Convert.ToHexString(manifest.PlaintextSha256))),
        new(ChainSteps[8], ChainStatus.Passed, manifest.ContentType.ToString().ToLowerInvariant()),
        new(ChainSteps[9], ChainStatus.Passed, $"journal.db + audit · {seconds:0.0} s"),
    ];

    private static IReadOnlyList<ChainStep> DuplicateChain()
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < 9; i++) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
        steps.Add(new ChainStep(ChainSteps[9], ChainStatus.NotReached, "already stored — nothing written"));
        return steps;
    }

    private static IReadOnlyList<ChainStep> StoreFailedChain(string error)
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < 9; i++) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
        steps.Add(new ChainStep(ChainSteps[9], ChainStatus.Failed, Trim(error, 40)));
        return steps;
    }

    /// <summary>
    /// Everything before the failing step verified, everything after it was never reached —
    /// which is the whole point of failing closed, so the operator gets to see it.
    /// </summary>
    private static IReadOnlyList<ChainStep> RejectionChain(string reason)
    {
        int failed = reason switch
        {
            _ when reason.StartsWith("Manifest parse", StringComparison.Ordinal) => 0,
            _ when reason.StartsWith("Unknown sender key", StringComparison.Ordinal) => 1,
            _ when reason.Contains("signature", StringComparison.OrdinalIgnoreCase) => 1,
            _ when reason.Contains("different receiver", StringComparison.OrdinalIgnoreCase) => 2,
            _ when reason.StartsWith("Replay check", StringComparison.Ordinal) => 3,
            _ when reason.StartsWith("Ciphertext hash", StringComparison.Ordinal) => 4,
            _ when reason.StartsWith("AES-GCM", StringComparison.Ordinal) => 5,
            _ when reason.StartsWith("Decompression", StringComparison.Ordinal) => 6,
            _ when reason.StartsWith("Plaintext hash", StringComparison.Ordinal) => 7,
            _ when reason.StartsWith("Content gate", StringComparison.Ordinal) => 8,
            _ => 9,
        };

        var steps = new List<ChainStep>();
        for (int i = 0; i < ChainSteps.Length; i++)
        {
            if (i < failed) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
            else if (i == failed) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Failed, Trim(reason, 44)));
            else steps.Add(new ChainStep(ChainSteps[i], ChainStatus.NotReached,
                i == ChainSteps.Length - 1 ? "nothing written" : "not reached"));
        }
        return steps;
    }

    /// <summary>The viewer's copy of a payload — bounded, because 500 rows of 64 MB is not a UI.</summary>
    private static byte[] Capped(byte[] plaintext) =>
        plaintext.Length <= InboxEntry.PreviewBytes ? plaintext : plaintext[..InboxEntry.PreviewBytes];

    // ═══════════════════ inbox ═══════════════════

    private void AddEntry(InboxEntry entry)
    {
        _inbox.Insert(0, entry);

        // Rows keep their metadata for the whole run; their bytes only while they are near the top.
        // Anything older is read back from the store on demand.
        if (_inbox.Count > InboxEntry.PreviewDepth)
            _inbox[InboxEntry.PreviewDepth].PreviewData = null;
        while (_inbox.Count > 500) _inbox.RemoveAt(_inbox.Count - 1);

        IndexArrival(entry);

        switch (entry.Outcome)
        {
            case InboxOutcome.Verified: _tallyOk++; break;
            case InboxOutcome.Duplicate: _tallyDup++; break;
            default: _tallyBad++; break;
        }
        RefreshTallies();

        if (AutoFollowToggle.IsChecked == true && PassesFilter(entry))
            InboxList.SelectedItem = entry;
    }

    private bool PassesFilter(InboxEntry entry)
    {
        if (!entry.Matches(SearchBox?.Text ?? "")) return false;
        if (FilterOk?.IsChecked == true) return entry.Outcome == InboxOutcome.Verified;
        if (FilterDup?.IsChecked == true) return entry.Outcome == InboxOutcome.Duplicate;
        if (FilterBad?.IsChecked == true) return entry.Outcome is InboxOutcome.Rejected or InboxOutcome.StoreFailed;
        return true;
    }

    private void Filter_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        _inboxView.Refresh();
        RefreshTallies();
    }

    private void RefreshTallies()
    {
        InboxCountText.Text = _inboxView.Count == _inbox.Count
            ? _inbox.Count.ToString()
            : $"{_inboxView.Count}/{_inbox.Count}";
        TallyOkText.Text = $"✔ {_tallyOk}";
        TallyDupText.Text = $"◎ {_tallyDup}";
        TallyBadText.Text = $"✖ {_tallyBad}";
        InboxEmpty.Visibility = _inboxView.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private void Inbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) RenderDetail(InboxList.SelectedItem as InboxEntry);
    }

    private void ViewMode_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) RenderPayload();
    }

    private void RenderDetail(InboxEntry? entry)
    {
        _selected = entry;
        ChainList.ItemsSource = entry?.Chain;

        if (entry is null)
        {
            SetPill(DetailOutcomePill, DetailOutcomeText, "nothing selected", "PillIdle");
            DetailNameText.Text = "";
            ReceiptBox.Text = "———— ———— ———— ————";
            ReceiptBox.Foreground = (Brush)FindResource("MutedBrush");
            StoredPathText.Text = "";
            CopyPayloadButton.IsEnabled = false;
            CopyReceiptButton.IsEnabled = false;
            OpenFolderButton.IsEnabled = false;
            PayloadViewer.Document = PayloadView.Message("Select an arrival to see its payload.");
            PreviewNoteText.Text = "";
            return;
        }

        SetPill(DetailOutcomePill, DetailOutcomeText, entry.OutcomeLabel, entry.Outcome switch
        {
            InboxOutcome.Verified => "PillOk",
            InboxOutcome.Duplicate => "PillWarn",
            _ => "PillBad",
        });
        DetailNameText.Text = $"{entry.Name} · {entry.SizeLabel}";

        bool hasReceipt = entry.Receipt.Length >= 16;
        ReceiptBox.Text = hasReceipt ? entry.ReceiptGrouped : "no receipt — nothing was verified";
        ReceiptBox.Foreground = (Brush)FindResource(
            entry.Outcome == InboxOutcome.Verified ? "SuccessTextBrush"
            : hasReceipt ? "WarningTextBrush" : "MutedBrush");

        StoredPathText.Text = entry.StoredPath is not null
            ? "stored  " + entry.StoredPath
            : entry.Reason ?? "nothing written";

        CopyReceiptButton.IsEnabled = hasReceipt;
        CopyPayloadButton.IsEnabled = entry.PreviewData is not null || entry.HasFile;
        OpenFolderButton.IsEnabled = entry.HasFile;
        RenderPayload();
    }

    private void RenderPayload()
    {
        var entry = _selected;
        _selectedText = PayloadText.Empty;

        if (entry is null)
        {
            PayloadViewer.Document = PayloadView.Message("Select an arrival to see its payload.");
            PreviewNoteText.Text = "";
            return;
        }

        byte[]? bytes = ResolveBytes(entry);
        if (bytes is null)
        {
            PayloadViewer.Document = PayloadView.Message(
                entry.Outcome == InboxOutcome.Rejected
                    ? "No payload to show — the chain failed, so nothing was ever decrypted."
                    : "No payload to show — this row's bytes are no longer in memory and the file is gone from the store.");
            PreviewNoteText.Text = "";
            return;
        }

        _selectedText =
            ViewHex.IsChecked == true ? PayloadFormatter.Hex(bytes) :
            ViewRaw.IsChecked == true ? PayloadFormatter.Raw(entry.ContentType, bytes) :
            PayloadFormatter.Formatted(entry.ContentType, bytes);

        PayloadViewer.Document = PayloadView.Build(_selectedText);

        PreviewNoteText.Text =
            entry.PreviewTruncated || _selectedText.Truncated
                ? $"showing the first {bytes.Length / 1024} KB — the whole payload is in the store"
                : entry.PlaintextSha256 is { Length: 64 } hash ? "sha256 " + Short(hash) : "";
    }

    /// <summary>
    /// The viewer's bytes: the in-memory copy while the row is recent, otherwise read back from the
    /// store. An arrival that scrolled out of the preview window is still fully inspectable —
    /// that is the point of writing it down.
    /// </summary>
    private byte[]? ResolveBytes(InboxEntry entry)
    {
        if (entry.PreviewData is { } cached) return cached;
        if (ReferenceEquals(_loadedFor, entry)) return _loadedBytes;
        if (entry.StoredPath is not { Length: > 0 } path || !File.Exists(path)) return null;

        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            int length = (int)Math.Min(stream.Length, InboxEntry.PreviewBytes);
            var buffer = new byte[length];
            stream.ReadExactly(buffer);
            _loadedFor = entry;
            _loadedBytes = buffer;
            return buffer;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    private InboxEntry? _loadedFor;
    private byte[]? _loadedBytes;

    private void CopyPayload_Click(object sender, RoutedEventArgs e) => CopyToClipboard(_selectedText.Text);

    private void CopyReceipt_Click(object sender, RoutedEventArgs e) => CopyToClipboard(_selected?.Receipt);

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        if (_selected?.StoredPath is not { } path || !File.Exists(path)) return;
        try
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ShowError($"Could not open the quarantine folder: {ex.Message}");
        }
    }

    private static void CopyToClipboard(string? text)
    {
        if (string.IsNullOrEmpty(text)) return;
        try { Clipboard.SetText(text); } catch (Exception) { /* clipboard busy — not worth an error */ }
    }

    // ═══════════════════ live tick ═══════════════════

    private void OnUiTick(object? sender, EventArgs e)
    {
        var engine = _engine;
        var pipeline = _pipeline;
        if (engine is null || pipeline is null) return;

        if (engine.ActiveManifest is { } manifest)
        {
            if (manifest.SessionId != _lastActiveSession)
            {
                _lastActiveSession = manifest.SessionId;
                _sessionStartedUtc = DateTime.UtcNow;
                RibbonText.Text = $"manifest verified · receiving {manifest.Filename} — nothing is written until the chain completes";
            }
            TransferProgress.Value = engine.Progress;
            ProgressPercent.Text = $"{engine.Progress * 100:0}%";
            ProgressText.Text =
                $"{manifest.Filename} ({manifest.OriginalSize:N0} B) · blocks {engine.DecodedSourceCount}/{engine.K} · " +
                $"symbols {engine.UniqueSymbolsReceived} · session {manifest.SessionId:N}";
            PreviewProgressText.Text = $"blocks {engine.DecodedSourceCount}/{engine.K} · symbols {engine.UniqueSymbolsReceived}";
        }
        else
        {
            ProgressText.Text = "waiting for a manifest…";
            PreviewProgressText.Text = "searching for a manifest";
        }

        double elapsed = Math.Max(0.1, (DateTime.UtcNow - _runStartedUtc).TotalSeconds);
        TelemetryText.Text =
            $"frames {pipeline.FramesSeen} · analyzed {pipeline.FramesDecoded} · QR hits {pipeline.QrHits} · " +
            $"{pipeline.FramesDecoded / elapsed:0.0} analyzed/s · {pipeline.QrHits / elapsed:0.0} hits/s" +
            (pipeline.FramesUnreadable > 0 ? $" · {pipeline.FramesUnreadable} unreadable" : "");

        // Frames arriving but none of them convertible is a broken capture path, not a bad aim.
        // Say so rather than leaving the operator staring at a black preview and "analyzed 0".
        if (pipeline.FramesDecoded == 0 && pipeline.FramesUnreadable > 60)
            ShowError($"The camera is delivering frames this build cannot read " +
                      $"({(CameraCombo.SelectedItem as CameraChoice)?.Characteristics.PixelFormat}). " +
                      "Pick a different camera mode with ↻ Refresh, or choose another camera.");

        // Lock-on: the border is the peripheral-vision signal, the pill carries the word.
        long hits = pipeline.QrHits;
        SetLock(hits > _lastQrHits);
        _lastQrHits = hits;

        var preview = _pendingPreview;
        if (preview.Pixels is { Length: > 0 })
        {
            _pendingPreview = default;
            if (_previewBitmap is null || _previewBitmap.PixelWidth != preview.Width || _previewBitmap.PixelHeight != preview.Height)
            {
                _previewBitmap = new WriteableBitmap(preview.Width, preview.Height, 96, 96,
                    System.Windows.Media.PixelFormats.Gray8, null);
                PreviewImage.Source = _previewBitmap;
            }
            _previewBitmap.WritePixels(new Int32Rect(0, 0, preview.Width, preview.Height), preview.Pixels, preview.Width, 0);
        }
    }

    private bool _locked;
    private bool _lockShownRunning;
    private void SetLock(bool locked)
    {
        bool running = _pipeline is not null;
        // Both inputs must be compared: after a Stop/Start the pill was left reading STOPPED
        // because the lock state itself had not changed.
        if (locked == _locked && running == _lockShownRunning) return;
        _locked = locked;
        _lockShownRunning = running;

        PreviewBorder.BorderBrush = (Brush)FindResource(
            !running ? "Neutral800Brush" : locked ? "SuccessBrush" : "Neutral700Brush");
        ScanDot.Fill = (Brush)FindResource(!running ? "Neutral500Brush" : locked ? "SuccessBrush" : "Neutral500Brush");
        ScanPillText.Text = !running ? "STOPPED" : locked ? "LOCKED — decoding" : "SEARCHING";
        ScanPill.Style = (Style)FindResource(!running ? "PillIdle" : locked ? "PillOk" : "PillIdle");
    }

    // ═══════════════════ helpers ═══════════════════

    private void ShowError(string message)
    {
        ErrorPill.Visibility = Visibility.Visible;
        ErrorPillText.Text = "✖ " + message;
    }

    private void HideError() => ErrorPill.Visibility = Visibility.Collapsed;

    private void SetPill(Border pill, TextBlock text, string label, string styleKey)
    {
        text.Text = label;
        pill.Style = (Style)FindResource(styleKey);
    }

    /// <summary>First and last four of a long hex value — enough to compare, short enough to fit.</summary>
    private static string Short(string hex) =>
        hex.Length <= 12 ? hex : $"{hex[..4]}…{hex[^4..]}";

    private static string Trim(string text, int max) =>
        text.Length <= max ? text : text[..(max - 1)] + "…";

    protected override async void OnClosed(EventArgs e)
    {
        _uiTimer.Stop();
        if (_pipeline is not null) await _pipeline.DisposeAsync();
        _journal.Dispose();
        _trust?.Dispose();
        _keys?.Dispose();
        base.OnClosed(e);
    }
}
