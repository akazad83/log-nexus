using System.IO;
using System.Text.Json;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// The physical landing zone for verified payloads. One payload becomes one file plus, optionally,
/// one <c>.meta.json</c> sidecar, so the folder can be read by anything — a script, an AV scanner,
/// an auditor with Explorer — without this app or its journal.
///
/// Writes stay atomic: staging file + fsync, then rename into place. Staging lives inside the
/// configured root so the rename never crosses a volume boundary, which is the one thing that
/// would turn an atomic move back into a copy.
/// </summary>
public sealed class PayloadStore
{
    public const string SidecarSuffix = ".meta.json";
    private const string StagingFolder = ".staging";

    private static readonly JsonSerializerOptions SidecarJson = new() { WriteIndented = true };
    private readonly object _lock = new();

    public PayloadStore(ReceiverSettings settings)
    {
        Root = settings.StorageRoot;
        OrganizeByDate = settings.OrganizeByDate;
        WriteSidecar = settings.WriteSidecar;
    }

    public string Root { get; private set; }
    public bool OrganizeByDate { get; private set; }
    public bool WriteSidecar { get; private set; }

    public string StagingDir => Path.Combine(Root, StagingFolder);

    public void Apply(ReceiverSettings settings)
    {
        lock (_lock)
        {
            Root = settings.StorageRoot;
            OrganizeByDate = settings.OrganizeByDate;
            WriteSidecar = settings.WriteSidecar;
        }
    }

    /// <summary>
    /// Creates the root and its staging folder, then proves the store is actually writable by
    /// round-tripping a probe file. Called before a run starts so a bad path fails at Start —
    /// not three payloads into a session with nowhere to put them.
    /// </summary>
    public void EnsureReady()
    {
        lock (_lock)
        {
            Directory.CreateDirectory(Root);
            Directory.CreateDirectory(StagingDir);

            string probe = Path.Combine(StagingDir, $".probe-{Guid.NewGuid():N}");
            File.WriteAllBytes(probe, [0x71, 0x72]);
            File.Delete(probe);
        }
    }

    /// <summary>Writes one verified payload and returns the path it now lives at.</summary>
    public string Save(TransferManifest manifest, byte[] plaintext, string receipt, DateTime receivedLocal)
    {
        lock (_lock)
        {
            string folder = OrganizeByDate
                ? Path.Combine(Root, receivedLocal.ToString("yyyy-MM-dd"))
                : Root;
            Directory.CreateDirectory(folder);
            Directory.CreateDirectory(StagingDir);

            string finalName = $"{manifest.SessionId:N}_{SanitizeFilename(manifest.Filename)}";
            string stagingPath = Path.Combine(StagingDir, finalName + ".tmp");
            string finalPath = Path.Combine(folder, finalName);

            using (var stream = new FileStream(stagingPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(plaintext);
                stream.Flush(flushToDisk: true);
            }
            File.Move(stagingPath, finalPath, overwrite: false);

            if (WriteSidecar) TryWriteSidecar(finalPath, manifest, receipt, receivedLocal);
            return finalPath;
        }
    }

    /// <summary>
    /// The sidecar is a convenience, not a record — the journal and the audit log are. A failure
    /// to write it must never undo a payload that is already safely on disk.
    /// </summary>
    private static void TryWriteSidecar(string payloadPath, TransferManifest manifest, string receipt, DateTime receivedLocal)
    {
        try
        {
            var meta = new
            {
                session = manifest.SessionId.ToString("N"),
                receivedLocal = receivedLocal.ToString("O"),
                receivedUtc = receivedLocal.ToUniversalTime().ToString("O"),
                sentUtc = DateTimeOffset.FromUnixTimeMilliseconds(manifest.TimestampUnixMs).UtcDateTime.ToString("O"),
                counter = manifest.Counter,
                filename = manifest.Filename,
                contentType = manifest.ContentType.ToString(),
                originalSize = manifest.OriginalSize,
                compressedSize = manifest.CompressedSize,
                ciphertextSize = manifest.CiphertextSize,
                compression = manifest.Compression.ToString(),
                senderSigningKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                receiverAgreementKeyId = KeyId.ToHex(manifest.ReceiverAgreementKeyId),
                plaintextSha256 = Convert.ToHexString(manifest.PlaintextSha256),
                ciphertextSha256 = Convert.ToHexString(manifest.CiphertextSha256),
                sourceSymbolCount = manifest.SourceSymbolCount,
                symbolSize = manifest.SymbolSize,
                receipt,
            };
            File.WriteAllText(payloadPath + SidecarSuffix, JsonSerializer.Serialize(meta, SidecarJson));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
        {
        }
    }

    /// <summary>Sender-supplied filenames are hostile input; nothing here may escape the store.</summary>
    public static string SanitizeFilename(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = name.Select(c => invalid.Contains(c) ? '_' : c).ToArray();
        string safe = new string(chars).TrimStart('.').Trim();
        return safe.Length == 0 ? "payload.bin" : safe;
    }
}
