# QrDiode — One-Way Optical Data Diode (OT → IT) over Animated QR Codes

QrDiode moves transactional data (files, XML, JSON) from an OT (operational technology)
environment to an IT environment **with no network path whatsoever**: an OT screen plays an
animated stream of QR codes, an IT camera watches it. The channel is strictly one-way —
true data-diode semantics, with fountain coding instead of ACKs.

Unlike the projects that inspired it, **every transfer is signed, encrypted, replay-protected
and content-validated**. Security is not optional and not a later phase.

```
┌─ OT machine ─────────────┐        light        ┌─ IT machine ──────────────────┐
│  QrDiode.Sender (WPF)    │  ═══════════════▶   │  QrDiode.Receiver (WPF)       │
│  encrypt→sign→LT→QR      │   QR carousel       │  camera→decode→verify→store   │
└──────────────────────────┘                     └───────────────────────────────┘
```

## Projects

| Project | What it is |
|---|---|
| `src/QrDiode.Core` | UI-agnostic protocol library: framing, LT fountain codec, crypto envelope, manifest, pipelines, and the payload simulator. No camera or screen needed — fully unit-testable. |
| `src/QrDiode.Sender` | WPF app for the OT side: live source simulator, session queue with an air-time policy and a payload inspector (formatted / raw / hex), and a resizable QR stage window with a ring-buffered renderer and live fps control. |
| `src/QrDiode.Receiver` | WPF app for the IT side: webcam capture (FlashCap), native QR decode (zxing-cpp), verification chain, live inbox with payload previews, a configurable local payload store, an Archive tab for searching and re-verifying everything received, SQLite journal, audit log. |
| `src/QrDiode.KeyCeremony` | Console tool for the offline key ceremony: keygen (TPM-preferred, non-exportable), public-bundle export/import, fingerprint comparison. |
| `tests/QrDiode.Core.Tests` | 75 tests: LT property tests under loss/shuffle, parser bit-flip fuzzing, crypto tamper/replay/XXE negative paths, full optical loopback through real QR images, back-to-back streaming sessions on one engine, and payload-viewer formatting of hostile input. |
| `tests/QrDiode.Bench` | Software throughput bench (everything except the physical screen→camera hop). |

## Quick start

**→ Full walkthrough (5-minute single-machine demo + production ceremony): [docs/USER_GUIDE.md](docs/USER_GUIDE.md)**

The fastest way to see it working: build, launch both apps, click **⚡ Demo setup** in each
(provisions and cross-trusts demo keys with full security active), point your webcam at the
sender's screen. Details in the guide.

Requires .NET 10 SDK on Windows.

```powershell
dotnet build
dotnet test tests/QrDiode.Core.Tests
dotnet run --project tests/QrDiode.Bench -c Release
```

### 1. Key ceremony (once, before anything can flow)

```powershell
# On the OT machine
dotnet run --project src/QrDiode.KeyCeremony -- init ot-line-1
dotnet run --project src/QrDiode.KeyCeremony -- export ot-line-1 E:\ot-line-1.json

# On the IT machine
dotnet run --project src/QrDiode.KeyCeremony -- init it-recv-1
dotnet run --project src/QrDiode.KeyCeremony -- export it-recv-1 E:\it-recv-1.json

# Cross-import via removable media, then COMPARE FINGERPRINTS out-of-band (voice):
dotnet run --project src/QrDiode.KeyCeremony -- import E:\it-recv-1.json   # on OT
dotnet run --project src/QrDiode.KeyCeremony -- import E:\ot-line-1.json   # on IT
```

Private keys are created **non-exportable** in Windows CNG (TPM-backed via the Platform
Crypto Provider when available). Only public bundles ever leave a machine.

### 2. Transfer

1. **OT**: run `QrDiode.Sender` → open keys (`ot-line-1`) → pick the receiver → **Start source**.
   The live simulator emits realistic JSON plant events at irregular intervals; each becomes its
   own session and streams from the **QR stage** — a normal, movable, resizable window you size to
   the camera (Esc closes, ↑/↓ adjusts fps, +/− cycles size presets). The queue shows what is on
   air, what is next, what is done, the air time each payload got, and a preview of the payload
   itself; select a row to read the exact bytes going out (formatted, raw or hex). *Manual file*
   mode sends one browsed file through the same queue.
2. **IT**: run `QrDiode.Receiver` → open keys (`it-recv-1`) → pick the camera → Start receiving →
   point it at the OT stage. Payloads arrive continuously in the **live inbox**: outcome badge,
   full verification chain, receipt, a per-row payload preview and a formatted/raw/hex viewer.
   Nothing is written until the whole chain passes.
3. **Both operators compare the receipt hash** shown on each screen.
4. **IT, later**: the receiver's **Archive** tab reads the local store back — every arrival ever
   judged (stored, duplicate or rejected), searchable by filename, type, session, receipt, sender
   key or payload text, filterable by date and outcome, with a per-type breakdown and a
   **Verify bytes on disk** button that re-hashes a stored file against the signed hash.

Because there is no acknowledgement, a session ends on an **air-time policy** rather than on
success: *loop 3× K frames or ≥ 6 s, whichever is longer*, then a short gap so the receiver can
finalize before the next manifest appears.

Received files are stored in the receiver's **local store** — by default
`%LocalAppData%\QrDiode\quarantine\<yyyy-MM-dd>\<sessionId>_<sanitizedName>`, each with a
`.meta.json` sidecar, and relocatable to any folder from the Archive tab. The journal
(`journal.db`, which also carries the archive index) and hash-chained audit logs
(`audit\*.jsonl`) live under `%LocalAppData%\QrDiode\`.

## Security model (summary)

* **Confidentiality** — payload is AES-256-GCM encrypted with a per-session key from static-static ECDH P-256 + HKDF-SHA256. Filming the screen yields ciphertext.
* **Authenticity** — the manifest is ECDSA P-256 signed; the receiver verifies against offline-provisioned keys **before touching a single payload byte**.
* **Binding** — the signed manifest carries the ciphertext hash; the GCM AAD carries the session identity. Manifest and ciphertext cannot be mixed and matched.
* **Anti-replay** — session GUID dedupe + per-sender-key monotonic counter high-watermark + ±48 h timestamp window; all three enforced in a transactional SQLite store.
* **Hostile input** — span-based frame parser (fail-fast, allocation-free on reject), CRC-32 pre-filter, XXE-prohibited XML / depth-capped JSON validation, decompression hard-capped at the signed size (zip-bomb guard), filenames sanitized, atomic write-then-rename materialization.
* **Audit** — append-only hash-chained JSONL logs on both ends; `AuditLog.Verify` detects any edit.

Full details, threat model and phased roadmap: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Throughput expectations

Software is not the bottleneck (measured on this repo's bench: QR generation ~1,100 codes/s,
native decode ~370/s, the entire 64 MB receive pipeline ~1 s of CPU). The screen→camera hop
dominates. With a single V30-L lane:

| Effective unique frames/s | Payload rate | 64 MB takes |
|---|---|---|
| 10 | ~13 KB/s | ~83 min |
| 15 | ~20 KB/s | ~55 min |
| 30 | ~40 KB/s | ~28 min |

Small transactional XML/JSON (the common case) completes in seconds. Multi-lane rendering
and camera tuning (Phase 2) raise the ceiling several-fold.
