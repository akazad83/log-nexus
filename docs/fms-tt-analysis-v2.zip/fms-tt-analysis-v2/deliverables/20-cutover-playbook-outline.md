# Cutover Playbook Outline

**Artifact ID:** B5.11 (companion)
**Status:** Outline for Operations Lead + Architecture Council review
**Audience:** Operations Lead, Service Manager, DevOps Lead, Data Architect, Operator panel, CIO
**Pairs with:** [19-test-strategy.md](19-test-strategy.md), [17-data-migration-strategy.md](17-data-migration-strategy.md), [04-network-boundary-design.md](04-network-boundary-design.md)

This is an **outline**, not the full playbook. The full per-app cutover runbook is a P4 deliverable produced 8–12 weeks before each cutover event. This outline establishes the structure, gates, and discipline that every per-app runbook inherits.

---

## 1. Purpose

Six cutover events under Option A (D-001) — staggered big-bang per application: FMS → TOMS → DBM → DSO → SDS → TLS. This outline ensures each event:

1. Follows the same pattern (predictable for operations + auditors)
2. Has the same gates (consistent decision discipline)
3. Has the same rollback plane (the OpNET legacy hot-standby for soak)
4. Has the same audit continuity (no regulatory gap)
5. Adapts to per-app specifics without re-inventing the framework

**This outline is what makes Option A safer than pure big-bang.** The framework absorbs surprises that would cascade in a single event.

---

## 2. The four-week cutover window

```
T-4 weeks   Dress Rehearsal #1 (DR1)
T-3 weeks   Dry-run + go/no-go review
T-2 weeks   Dress Rehearsal #2 (DR2)
T-1 week    Final go/no-go; freeze; Dress Rehearsal #3 (DR3)
T-0         Cutover weekend (Friday evening → Sunday)
T+1 week    Stabilization
T+2 to T+4  Soak; legacy hot-standby retained on OpNET
T+4 weeks   Soak exit; legacy decommission decision
```

Each phase has entry criteria, activities, exit criteria, and a named gate authority.

---

## 3. T-4 weeks — Dress Rehearsal #1

### 3.1 Purpose
Full migration + cutover sequence executed against a Pre-Prod clone. Establishes the timing baseline. Surfaces defects in scripts, data shapes, smoke checks.

### 3.2 Activities
- Freeze Pre-Prod clone at a recent snapshot
- Execute the full per-app cutover sequence (extract → transform → load → reconcile → smoke → operator readiness)
- Time every step with explicit measurement
- Capture every defect, however minor, with severity
- Operator panel observes (not participates) — they're learning the process

### 3.3 Exit criteria
- Cutover sequence completes within target window
- All severity-1 defects identified
- Reconciliation harness produces a pass result (or all mismatches explained)
- Smoke tests pass

### 3.4 If exit criteria fail
- Identify root cause
- Repair scripts / data / process
- Re-run DR1; do not advance to DR2 until DR1 passes

### 3.5 Authority
Operations Lead reviews; Engineering Lead acknowledges defects; no operator panel sign-off needed.

---

## 4. T-3 weeks — Dry-run + go/no-go review

### 4.1 Purpose
Defect triage from DR1. Decide whether the cutover proceeds on schedule.

### 4.2 Activities
- Defect review panel: Engineering Lead + Test Lead + Data Architect
- Severity-1 defects must be fixed before DR2; severity-2 + 3 triaged for fix or defer
- Updated cutover script + data + process
- Risk re-assessment for the cutover event
- Schedule confirmation or postponement

### 4.3 Exit criteria
- All severity-1 defects from DR1 addressed (fixed or explicitly deferred with justification)
- Updated runbook reviewed by all participants
- Schedule confirmed (or postponed with new schedule)

### 4.4 Authority
Engineering Lead.

---

## 5. T-2 weeks — Dress Rehearsal #2

### 5.1 Purpose
Validate the post-DR1 fixes. Catch new defects introduced by the fixes. Tighten timing.

### 5.2 Activities
- Same as DR1 against a fresh Pre-Prod snapshot
- Defects compared to DR1 (regressions are highlighted)
- Operator panel participates (begins to drive the operator-side sequence)

### 5.3 Exit criteria
- Cutover sequence completes within target window with margin
- No severity-1 defects from DR1 regress
- Operator panel can drive the operator-readiness phase confidently

### 5.4 If exit criteria fail
- Same as DR1: repair + re-run DR2; do not advance until DR2 passes
- Schedule postponement is the default response if DR2 fails twice

### 5.5 Authority
Operations Lead reviews; operator panel acknowledges readiness.

---

## 6. T-1 week — Final go/no-go; freeze; Dress Rehearsal #3

### 6.1 Purpose
The decision point. After DR3, the cutover is locked or postponed.

### 6.2 Activities
- DR3: full sequence against the most recent Pre-Prod refresh
- Final go/no-go meeting: Operations Lead + CIO + Engineering Lead + Operator panel + Compliance officer
- Freeze: code freeze for the cutover-bound app; no schema changes, no config changes, no production deploys until cutover or postponement
- Communications: stakeholder notifications; CAB approval recorded; regulator notification if applicable

### 6.3 Decision matrix

| Condition | Decision |
|---|---|
| DR3 passes; all gates green; operator panel confident | **Go** |
| DR3 passes; ≥ 1 gate amber but operationally explained | **Go** with named risk + accepted contingency |
| DR3 fails on a fixable defect; window allows fix + DR4 | **Postpone 1 week**; run DR4; revisit go/no-go |
| DR3 fails on a structural issue; >1 week to fix | **Postpone to next available window** |
| Operator panel does not consent | **Postpone** (operator confidence is non-negotiable) |
| Compliance objects | **Postpone** until objection resolved |

### 6.4 Authority
Operations Lead + CIO. Sponsor informed.

---

## 7. T-0 — Cutover weekend

### 7.1 The high-level sequence

```mermaid
flowchart TB
    F[Friday 18:00<br/>Legacy app frozen for cut-over scope<br/>Final extract begins]
    SAT_AM[Saturday 06:00<br/>Extract complete<br/>Transform begins]
    SAT_PM[Saturday 14:00<br/>Transform complete<br/>Load begins]
    SAT_LATE[Saturday 22:00<br/>Load complete<br/>Reconciliation begins]
    SUN_AM[Sunday 06:00<br/>Reconciliation complete<br/>Sign-off panel reviews]
    SUN_MID[Sunday 10:00<br/>Smoke tests + operator readiness checks]
    SUN_PM[Sunday 14:00<br/>Final go/no-go]
    SUN_LIVE[Sunday 16:00<br/>Traffic flips to modern]
    SUN_MON[Sunday 18:00 onward<br/>Stabilization on-call]

    F --> SAT_AM
    SAT_AM --> SAT_PM
    SAT_PM --> SAT_LATE
    SAT_LATE --> SUN_AM
    SUN_AM --> SUN_MID
    SUN_MID --> SUN_PM
    SUN_PM --> SUN_LIVE
    SUN_LIVE --> SUN_MON
```

Times indicative; per-app variation in [17-data-migration-strategy.md](17-data-migration-strategy.md) §8.3.

### 7.2 Gate authority during cutover

| Gate | Authority |
|---|---|
| Friday extract begins | Service Manager (operations confirms freeze) |
| Saturday transform begins | Data Architect (extract integrity confirmed) |
| Saturday load begins | Data Architect (transform output validated) |
| Sunday morning reconciliation pass | Data Architect + Compliance |
| Sunday smoke pass | Test Lead + Service Manager |
| Sunday final go/no-go | Operations Lead + CIO |
| Traffic flip | Operations Lead (single command, recorded) |

### 7.3 Communication cadence during cutover

| Cadence | Channel |
|---|---|
| Hourly status update | War room channel + SMS to Sponsor + CIO |
| Defect escalation | Real-time to war room |
| External (operators, field crews, regulator) | Per pre-arranged comms plan; predictable cadence |
| Public-facing (if applicable) | Per Communications Lead |

### 7.4 The abort decision

At any gate in the cutover sequence:

| Trigger | Action |
|---|---|
| Reconciliation fails fundamentally (mismatches not explained) | **Abort**; restore legacy as primary; postpone |
| Smoke tests fail on critical path | **Abort or rollback** depending on point reached; defer to gate authority |
| Operator panel withdraws readiness confirmation | **Abort**; investigate; postpone |
| Safety event detected | **Abort**; safety review; postpone |
| Regulator or Compliance objects | **Abort**; resolve objection; postpone |

**Abort is not failure.** A correctly-aborted cutover is a successful run of the safety net. Failed cutovers that proceed are far worse than aborted cutovers.

### 7.5 Audit during cutover

Cutover itself is a regulator-relevant event. Captured:

- Cutover ID (per app, per attempt)
- Every gate decision with timestamp and authority
- Every defect found with severity and resolution
- Reconciliation report final state (success/failure + per-table results)
- Sign-off chain
- Hash chain re-anchored at cutover boundary (documented as corrective audit action per [16-database-design-principles.md](16-database-design-principles.md) §9.5)

---

## 8. T+1 week — Stabilization

### 8.1 Purpose
The first week post-cutover with elevated on-call. Catches issues that surface only with real production load.

### 8.2 Mode
- Engineering on-call: 24/7 with rapid escalation
- Operator panel: dedicated touchpoints for issue reporting (separate from normal channels)
- Defect SLA: severity-1 fix within 4 hours; severity-2 within 1 business day
- Daily standup: Engineering Lead + Operations Lead + Operator panel rep + Service Manager

### 8.3 What's monitored more aggressively
- Every operator-action log emission rate (audit completeness verification)
- Every authorization decision rate (RBAC parity)
- Every integration call (especially EMS endpoint)
- AG replication health
- Every error event in observability

### 8.4 Exit criteria
- 7 days elapsed
- No P1 defects open
- Defect rate trending toward steady-state threshold
- Operator panel confirms no parity-blocking issues

---

## 9. T+2 to T+4 — Soak

### 9.1 Mode
- Standard on-call (not heightened)
- Defect SLA: per normal severity scale
- Weekly review: defect count + audit reconciliation + operator feedback
- **Legacy retained read-only on OpNET as rollback plane**

### 9.2 What soak is for
- Catch issues that surface only with multi-week load patterns
- Validate audit reconstruction over the soak window
- Build operator confidence that the new system is steady

### 9.3 Soak exit criteria
- 4 weeks elapsed (counting from cutover, not from stabilization)
- No P1 defects open
- Defect rate ≤ steady-state threshold for 30 consecutive days
- Audit reconstruction validated by Compliance for the soak window
- Operator confidence panel sign-off

### 9.4 Soak rollback (rare; major decision)
- Authority: Steering Committee (not Operations Lead alone)
- Triggered by: sustained P1 defects; safety event; regulator escalation
- Process: see [17-data-migration-strategy.md](17-data-migration-strategy.md) §10.2
- Rollback during soak is a major decision; data accumulated in modern system must be reconciled

---

## 10. T+4 weeks and beyond — Legacy decommission

### 10.1 The decision

Once soak exit is achieved:
- Legacy app is decommissioned for **operational use** (no further user access)
- Legacy DB is retained **read-only for 7 years** for audit reconstruction (per [17-data-migration-strategy.md](17-data-migration-strategy.md) §7.2 Approach B)
- Legacy infrastructure is documented for archive lifecycle

### 10.2 Decommissioning checklist (per app)
- [ ] Legacy app pool stopped
- [ ] Legacy app integration endpoints removed from external system contracts
- [ ] Legacy DB set to read-only mode
- [ ] Legacy DB cycle tested (can it be queried for an audit? yes/no)
- [ ] Decommission record filed in audit
- [ ] Operations team formally accepts service ownership of new app
- [ ] Hypercare exit memo published

---

## 11. Cross-cutting playbook elements

### 11.1 The war room

For each cutover event, a war room is convened:

| Role | Required? | Channel |
|---|---|---|
| Operations Lead | On-site or video | Voice |
| Engineering Lead | On-site | Voice + chat |
| Service Manager | On-site | Voice + chat |
| Data Architect | On-site | Voice + chat |
| Test Lead | On-site | Voice + chat |
| Security Lead | On-call | Voice |
| Compliance officer | On-call | Voice |
| CIO | On-call | Voice (gate authority) |
| DevOps Lead | On-site | Voice + chat |
| Operator panel rep | On-site | Voice + chat |
| Sponsor | On-call | Voice (informed) |

### 11.2 Comms plan

- Pre-defined SMS distribution list for hourly updates
- Pre-defined chat channel for war-room operations
- Pre-defined external-facing comms (operators, field crews) with templated messages
- Regulator notification protocol if applicable

### 11.3 Tooling

- Status dashboard (ops + observability)
- Pre-Prod-fidelity Pre-Prod available for ad-hoc verification
- Documented escape hatches for manual interventions if scripts fail
- Rollback plan printed (yes, on paper) — not just in the laptop

### 11.4 The "no surprise" rule

- Every action in the playbook is rehearsed in DR1, DR2, DR3
- No improvisation during cutover weekend
- If improvisation is needed, that's an abort signal — postpone, fix, retry

---

## 12. Per-app variations summary

The framework is the same; the specifics vary. See [17-data-migration-strategy.md](17-data-migration-strategy.md) §8.2 for app-specific notes.

| App | Specific cutover considerations |
|---|---|
| FMS (1st) | Highest scrutiny; longest soak; rehearsals exercise the harness most rigorously |
| TOMS | Highest reuse; transmission-specific schedule alignment with control room |
| DBM | Foundational data; downstream dependency; coordinate with apps yet to cut |
| DSO | Dielectric extensions; longer reconciliation |
| SDS | Steam-specific; potentially longest cutover window; specialist operator pool |
| TLS | Many integrations; coordinate adapter cutover within the same weekend |

---

## 13. Risk register additions for cutover phase

| Risk ID | Description | Probability | Impact | Score | Mitigation |
|---|---|---|---|---|---|
| R-CUT-01 | Reconciliation harness produces false-positive mismatches under load | Med | Med | 9 | Harness exercised at full data volume in DR1 |
| R-CUT-02 | Cutover window exceeded due to data volume larger than projected | Med | High | 12 | Profiling in P1; DR1 measures; abort if window exceeded |
| R-CUT-03 | Operator panel withdraws readiness late in window | Low | High | 8 | Operator panel embedded from DR2 onward |
| R-CUT-04 | Audit chain re-anchoring misinterpreted by regulator | Low | Very High | 10 | Pre-cutover regulator engagement; documented memo |
| R-CUT-05 | Inter-cutover learning not applied (FMS lessons not improving TOMS rehearsal) | Med | Med | 9 | Post-cutover review captures lessons; explicitly applied to next-app rehearsal planning |
| R-CUT-06 | Soak rollback invoked; reverse migration complexity exceeds estimates | Low | Very High | 10 | Reverse-migration capability tested in DR2; rollback authority elevated to Steering Committee |
| R-CUT-07 | Legacy decommissioning misses an integration | Med | Med | 9 | Decommission checklist per app; integration inventory cross-referenced |

---

## 14. What this outline does not specify

- Specific extraction commands for Ingres (per-app runbook in P4)
- Specific T-SQL transformation procedures (lives in `repo/data-migration`)
- Specific reconciliation queries (lives in harness)
- Specific operator-readiness checks per app (per-app runbook in P4)
- Specific timing tolerances per stage (refined by DR1 measurement)
- Specific war-room phone numbers / escalation chains (P4 runbook)
- Specific regulator notification text (Compliance team owns)

The full per-app runbook is a P4 artifact: 50–80 pages of detailed step-by-step procedures, escalation contacts, and rollback details. This outline is the structure that runbook fills in.

---

## 15. Inter-cutover learning loop

A cutover is not a one-off — six events happen sequentially. The framework includes an explicit learning loop:

```
Cutover N → Post-cutover review (within 1 week)
          → Lessons captured in lessons log
          → Next-cutover (N+1) DR1 explicitly applies lessons
          → Repeat
```

| Lesson type | Where it goes |
|---|---|
| Script defect found at cutover | Migration repo PR; tests added |
| Process gap | Playbook update; DR1 of next cutover exercises the fix |
| Defect found in modern app under cutover load | Bug ticket; severity per impact |
| Operator workflow gap | Story added to backlog; resolved before next cutover if affecting same workflow |
| Communication gap | Comms plan update; rehearsed in next cutover |

The lessons log is reviewed at the cutover post-mortem AND at the next cutover's DR1 planning. This is what makes a 6-event sequence actually safer than a single big-bang.

---

## 16. Sign-off

This outline is approved by:

- [ ] Operations Lead
- [ ] Engineering Lead
- [ ] Data Architect
- [ ] Test Lead
- [ ] Security Lead
- [ ] Compliance officer
- [ ] CIO
- [ ] Sponsor

Each per-app cutover runbook produced from this outline carries the same sign-off chain.
