# Task Template

**Use:** Tasks are engineer-day units of work that decompose a Story for execution. Tasks are not visible to operators or PO. Tasks exist for engineering planning and tracking.

**Pairs with:** [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §6.

---

## Task header

| Field | Value |
|---|---|
| **Task ID** | (e.g., `T-FMS-S-104-03`) |
| **Title** | (verb-led; one short line) |
| **Story** | (link to Story ID) |
| **Type** | Backend / Frontend / DB / Integration / Audit / Telemetry / Test / Docs / Infra |
| **Owner** | (single engineer) |
| **Estimated hours** | (1–16; if more, split) |
| **Status** | To Do / In Progress / In Review / Done / Blocked |
| **Sprint** | (sprint #) |

---

## Description

What needs to be done. One paragraph max. Engineer-readable, not operator-readable.

---

## Acceptance test (for the task itself, not the story)

The lightweight pass/fail for this specific task. May be a unit test, a code review checklist, an updated runbook, etc.

> e.g., *"Unit test `CardReviewService.PrePopulateContext()` covers all 12 required EMS fields and the 4 conditional fields. Coverage ≥ 90% on the new code path. Passes in CI."*

---

## Dependencies

| Dependency | Status |
|---|---|
| (Other task ID) | Done / In progress / Not started |
| (Spike) | Concluded / Active |
| (External — e.g., infra ticket, environment) | |

---

## Implementation notes

Optional. If the implementation has a non-obvious choice, capture it here so reviewers and future maintainers see the decision. Keep it short.

> e.g., *"Pre-population logic uses `IFeederContextResolver` rather than direct EF Core queries to allow swap-in of cached resolution in P3."*

---

## Definition of Done (task-level)

A task is Done when:

- [ ] Acceptance test passes
- [ ] Code reviewed (minimum 1 reviewer for tasks; 2 for security-sensitive)
- [ ] Unit tests added or updated
- [ ] No new SAST findings above baseline
- [ ] Telemetry instrumentation added if applicable
- [ ] Docs updated if applicable

Task Done does **not** mean the parent Story is Done. Story DoD is in [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §9.

---

## Anti-patterns

| Anti-pattern | Fix |
|---|---|
| Task is "implement the feature" with no decomposition | Split into smaller tasks |
| Task estimated >16 hours | This is a story, not a task |
| Task has no acceptance test | Add one — engineer self-checks |
| Task is "research X" | This is a spike, not a task |
| Task spans multiple stories | Split per story |

---

## Worked example

```
Task ID:        T-FMS-S-104-03
Title:          Add audit emission for review-pane edit confirmations
Story:          FMS-S-104
Type:           Backend + Audit
Owner:          P. Iyer
Estimated hrs:  6
Status:         In Progress
Sprint:         P2 / Sprint 7

Description:
  In the FMS service `UpdateCardCommand` handler, emit an operator action
  log entry for each edit-confirm event. Action type = "EditCardField".
  Capture before-value and after-value (hashed for sensitive fields).
  Use the existing `IOperatorActionLogger` abstraction.

Acceptance test:
  Unit test in CardCommandHandlerTests covers:
    - Single field edit emits one action log row
    - Multi-field edit emits one action log row per changed field
    - Failed edit emits action log row with success=false
  Integration test in SIT confirms the row lands in the operator-action log
  table with the expected hash chain link.

Dependencies:
  T-FMS-S-104-02 (UpdateCardCommand handler stub) | Done
  Foundational: IOperatorActionLogger | Done (P1a)

Implementation notes:
  Use existing audit logger; do not introduce a new abstraction. Hash before/after
  values using the program-standard SHA-256 helper from PTRS.Core.Crypto.

Definition of Done:
  ✅ Acceptance test passes
  ✅ Code reviewed (1 reviewer; this task is not security-sensitive)
  ✅ Unit tests added
  ✅ No new SAST findings
  ✅ Telemetry: emit a metric `fms.card.edit.audit.emitted` per emission
  ✅ Docs: nothing public; internal note added to FMS service README
```
