# Acceptance Criteria Template — Gherkin + NFR Addendum

**Use:** Every Story has at least one ACs document populated from this template. AC categories required per story are listed in [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §5.2.

---

## Header

| Field | Value |
|---|---|
| **AC Doc ID** | (e.g., `AC-FMS-S-104`) |
| **Story ID** | (link) |
| **Author (BA)** | |
| **Reviewer (Test Lead)** | |
| **Operator SME validator** | |
| **Status** | Draft / Reviewed / Operator-validated / Locked |

---

## Functional ACs (Gherkin)

Use `Given / When / Then`. Be concrete — names, values, states, not abstractions.

### AC-1 — Happy path

```gherkin
Scenario: Operator reviews an auto-created card with parity-matched layout
  Given an FMS switching card was auto-created from an EMS planned-outage event
    And the operator is logged in with District Operator role for the relevant district
    And the card is in state "PendingReview"
  When the operator opens the card review pane
  Then the pane displays fields in the parity layout sequence: feeder, breaker, substation, switch points, default tag, target restoration window, comments
    And every field shows the value pre-populated from the EMS event context
    And the pane render completes within 800 ms (p99)
```

### AC-2 — Error path

```gherkin
Scenario: Operator attempts to open a card outside their district
  Given an FMS switching card exists for a district the operator is not authorized for
  When the operator attempts to open the card review pane
  Then the pane is not displayed
    And an "insufficient authorization" message is shown with corrective guidance
    And no card data is leaked to the operator's session (verified via DOM inspection in test)
```

### AC-3 — Authorization

```gherkin
Scenario: Authorization check is recorded for every card open
  Given any operator attempts to open a card review pane
  When the authorization decision is computed
  Then the auth-decision log records: principal, action="OpenCardReview", target=cardId, decision=(allow|deny), policy version, timestamp
```

### AC-4 — Audit trail (Pattern A — entity history)

```gherkin
Scenario: Edits to the review pane fields are temporally recorded
  Given an operator opens the review pane for a card
    And edits the "target restoration window" field
  When the operator confirms the edit
  Then the Card entity's temporal history records the field change with before-value, after-value, principal, timestamp
    And the temporal record is queryable for at least 7 years
```

### AC-5 — Audit trail (Pattern B — operator action)

```gherkin
Scenario: Every operator interaction with the review pane is logged
  Given an operator opens, edits, and confirms a card review pane
  When the actions complete (each one)
  Then the operator-action log records, for each action: operator identity, action type, target card ID, timestamp, success/failure, before-state hash, after-state hash, request correlation ID
    And the operator-action log entries form a verifiable hash chain with prior entries
```

### AC-6 — Resilience

```gherkin
Scenario: Telemetry collector is temporarily unavailable
  Given the observability collector is unreachable
  When an operator opens, edits, and confirms a card review pane
  Then the operator's workflow completes successfully (functionality is not blocked by telemetry failure)
    And the missed telemetry is buffered locally
    And replayed when the collector returns
```

### AC-7 — Operator visibility

```gherkin
Scenario: Operator's edit reflects in real-time across the operator's own session
  Given an operator edits a field in the review pane
  When the edit is confirmed
  Then the change is reflected in the pane within 500 ms (p99)
    And the change is reflected in any other open view of this card on the same operator's screens
```

---

## NFR Addendum

Always present. If a category genuinely doesn't apply, write "N/A — rationale" rather than omitting.

### Latency

| Interaction | Target | Measurement |
|---|---|---|
| Pane render (initial) | p99 < 800 ms | trace span on BFF GET card-with-context |
| Edit confirm round-trip | p99 < 500 ms | trace span on PATCH card |

### Availability

| Dependency | Required during this story | Behavior on dependency loss |
|---|---|---|
| BFF | Yes | Pane shows offline banner; rejects edits |
| FMS service | Yes | Same as above |
| DB primary | Yes | Same as above |
| Audit collector | No | Edit succeeds; audit buffered locally |
| Observability collector | No | Edit succeeds; telemetry buffered locally |

### Security

| Aspect | Requirement |
|---|---|
| Authentication | Windows Integrated Auth (Kerberos) |
| Authorization | District Operator role for the card's district |
| Data sensitivity | Card content is restricted (operator + audit roles only) |
| Logging of credentials | Never log credentials, tokens, or session IDs |

### Audit

| What is logged | Retention bucket | Sensitivity |
|---|---|---|
| Operator action log | 7 years | Tamper-evident |
| Entity history | 7 years | Standard |
| Auth-decision log | 7 years | Tamper-evident |
| Integration calls | N/A — no external integration in this story | — |

### Performance / load

| Scenario | Target |
|---|---|
| Concurrent operators on the same card | Up to 5 (last-write-wins with conflict notification) |
| Cards open simultaneously per operator | Up to 20 (operator workflow norm) |
| Sustained edit rate per operator | 1/sec sustained; 5/sec burst |

### Accessibility

| Standard | Target |
|---|---|
| WCAG | 2.2 AA (program-wide standard) |

---

## Operator validation criterion

For Parity stories: the operator SME signs off that the pane visually and behaviorally matches the legacy system to the standard agreed at Epic level. Specifically:

- [ ] Field ordering matches legacy
- [ ] Field labels match legacy or are improved with operator concurrence
- [ ] Default values match legacy
- [ ] Keyboard navigation matches legacy where operators have muscle memory
- [ ] Visual hierarchy matches legacy

For New-Value stories: the operator panel reviews and confirms the new behavior delivers the value claimed at Epic level.

---

## Test coverage notes

| Test type | Coverage notes |
|---|---|
| Unit | Pre-population logic; field validation rules |
| Contract | BFF ↔ FMS service contract; tested both directions |
| Integration | SIT — real DB, real audit, real observability |
| E2E | Pre-Prod — full operator flow including auth |
| Parity (custom harness) | Compare legacy capture vs new pane field-by-field |
| Operator validation | Sprint demo with R. Chen + at least 1 other operator |

---

## Regulatory tagging

For each AC, mark with `[REG]` if it exists because of a regulatory requirement, with the citation:

```
AC-3 [REG NERC CIP-008-6 R1.4]: Authorization decision is recorded
AC-5 [REG NERC CIP-008-6 R1.5]: Operator action is recorded with hash-chain
```

These ACs are also tagged in the test suite for filtered regulatory regression runs.

---

## Anti-patterns (reject these in AC review)

| Anti-pattern | Fix |
|---|---|
| "User can do X successfully" with no concrete given/when/then | Rewrite in Gherkin |
| ACs that copy-paste audit pattern with no specifics | Tailor the "what is logged" to the actual state transition |
| Missing error paths | Add at least one — what happens when something goes wrong? |
| NFR addendum says "standard" with no numbers | Use real numbers or write "N/A — rationale" |
| Latency target without measurement approach | Add measurement column |
| Authorization AC missing on stories that change state | DoR fails |
| Audit AC missing on stories that change state | DoR fails — non-negotiable |
