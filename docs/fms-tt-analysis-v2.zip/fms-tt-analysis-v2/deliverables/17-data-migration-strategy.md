# Data Migration Strategy — Ingres → SQL Server 2025

**Artifact ID:** B5.8
**Status:** Draft for Architecture Council + Data Architecture review
**Audience:** Data Architect, DB Engineers, Integration Lead, Compliance Officer, Sponsor
**Pairs with:** [16-database-design-principles.md](16-database-design-principles.md), [03-technical-architecture-outline.md](03-technical-architecture-outline.md)

This document specifies the strategy for migrating data from the legacy Actian Ingres database (UDB-modeled) into SQL Server 2025 Enterprise (CIM-aligned). The strategy is gated on the P1b POC and re-baselined after it. The cutover migration is per-application under Option A (D-001) — staggered big-bang.

---

## 1. Executive summary

Three things to know if you read nothing else:

1. **The migration is the program's #1 latent risk after hidden 4GL rules.** UDB→CIM is not a syntactic mapping — it is a model translation. Some constructs do not map cleanly. The P1b POC exists to bound this risk before estimates are committed.
2. **Migration is per-application, not bulk.** Under Option A staggered cutover, each app cuts over with its own data migration on a separate weekend. Six migration events. Rehearsed three times each.
3. **Reconciliation tooling is half the migration work.** Building the diff harness that proves source-vs-target fidelity is a major underestimate area in every migration project. Budget for it explicitly (estimation worksheet has this).

---

## 2. Source landscape

### 2.1 What's in Ingres today

| Property | Value |
|---|---|
| Engine | Actian Ingres |
| Data model | UDB (legacy in-house data model) |
| Schemas | One per application + shared reference data + audit tables |
| Estimated total volume | Per A-005 — to be profiled in P1; assume ~150K cards/year, 7 years retained = ~1M cards aggregate + ancillary data |
| Hot data | Last 18 months of operational data |
| Warm data | Months 18–84 (audit reconstruction window) |
| Cold data | Older (regulator archive only) |

### 2.2 Source data shape — what makes UDB difficult

| Feature | Implication for migration |
|---|---|
| In-house custom types and aliases | Must be enumerated and mapped explicitly |
| Heavy use of triggers and stored procedures embedded in 4GL | Behavior often baked into data shape; some "data" is actually derived state |
| Loose timestamp semantics (Ingres date/time mixed precision) | Risk of precision loss; explicit conversion rules required |
| NULL semantics differ subtly from SQL Server | `NULL = NULL` evaluation, three-valued logic edge cases |
| Date math and string functions with Ingres-specific semantics | Audit-reconstruction queries must be replayed against new DB to verify |
| Encoded fields (e.g., status flags packed into single columns) | Must be unpacked into proper relational form |

### 2.3 Profiling the source first

Before any migration design is finalized, source profiling is required:

- Per-table row counts, distinct value counts, NULL ratios
- Per-column data-type distribution (especially detected vs. declared)
- Date range coverage per audit-relevant table
- Cross-table referential integrity check (orphan detection)
- Hot-path query patterns from production logs

Profiling output is an input to the UDB→CIM POC (P1b).

---

## 3. Target — SQL Server 2025

Target structure follows [16-database-design-principles.md](16-database-design-principles.md):
- One SQL Server instance with schema-per-service (`fms`, `toms`, `dso`, `tls`, `sds`, `dbm`, `audit`, `report`, etc.)
- AlwaysOn AG with synchronous commit between CorpNET primary and OpNET standby
- System-versioned temporal tables for entity history
- Append-only `_Audit` tables for operator action logs with hash chains
- Time-based partitioning on high-volume tables

---

## 4. The UDB → CIM conversion

### 4.1 Why CIM

CIM (Common Information Model) is the IEC-standardized data model for utility power-system information (IEC 61970/61968). Adopting it brings:

- Compatibility with utility ecosystem (EMS vendors, GIS, FeederBoard, market systems)
- Established semantic contracts for substation/feeder/breaker hierarchies
- Reduced custom modeling of well-understood domain concepts
- Simpler regulatory reporting (regulators recognize CIM-aligned structures)

### 4.2 Why this is hard

UDB was built before CIM was widely adopted in utility OT software. UDB models 80% of the same concepts but with utility-specific extensions and shortcuts that CIM does not naturally accommodate:

| UDB construct | CIM equivalent | Difficulty |
|---|---|---|
| Feeder hierarchy with custom topology shortcuts | CIM ConnectivityNode + Terminal model | Medium — CIM is more verbose; capture mapping |
| Breaker state encoded as packed flags | CIM Breaker + SwitchPosition + measurement values | Medium — unpacking required |
| Card-step relationship (UDB-specific) | No direct CIM equivalent (operational workflow is outside CIM core) | **High — domain-specific extension required** |
| Tag / clearance entities | Limited CIM coverage; mostly operational | **High — domain-specific extension required** |
| Custom dielectric / steam constructs | CIM partial coverage | **High — DSO and SDS are most exposed** |
| Audit & operator-action concepts | Not in CIM | Outside CIM scope; modeled native to SQL Server temporal + audit |

**The CIM-aligned target is approximately 60% pure CIM + 40% utility-specific extensions to CIM.** This is normal for production utility systems. The extensions are documented as part of the program's `dbm` schema.

### 4.3 The P1b POC — what it produces

Per B1 phase definition, the POC delivers (M-04 exit):

1. FMS feeder hierarchy converted UDB → CIM with full reconciliation
2. Reconciliation report demonstrating ≥99.9% row-level fidelity on FMS sample
3. **Type mapping specification** — every UDB type → SQL Server type, with rules for edge cases
4. **CIM extension catalog** — every utility-specific CIM extension required, with justification
5. **ETL throughput projection** — extrapolated to full data volume
6. **Reconciliation harness** — reusable for the remaining 5 cores' migrations
7. **Failure-mode catalog** — UDB constructs that don't map cleanly, with chosen resolutions

This is a real artifact set, not a slide deck. The POC is the gate for D-002 (re-baseline of all P3 data work).

---

## 5. ETL approach

### 5.1 Pattern: extract → stage → transform → load → reconcile → cut

```mermaid
flowchart LR
    INGRES[(Ingres UDB)]
    EXTRACT[Extract<br/>per-table snapshots]
    STAGE[(Staging DB<br/>SQL Server 2025)]
    TRANSFORM[Transform<br/>UDB→CIM mapping]
    PRODSCH[(Per-service schemas<br/>fms, toms, ...)]
    RECONCILE[Reconciliation<br/>harness]
    AUDIT[(audit schema)]

    INGRES --> EXTRACT
    EXTRACT --> STAGE
    STAGE --> TRANSFORM
    TRANSFORM --> PRODSCH
    PRODSCH --> RECONCILE
    INGRES --> RECONCILE
    PRODSCH --> AUDIT
```

### 5.2 Extract — from Ingres to staging

| Aspect | Decision |
|---|---|
| Tooling | SSIS for batch + Ingres ODBC; for change-data scenarios, Ingres replication tools or change-tracking via timestamp + version columns |
| Snapshot frequency in pre-cutover phase | Daily incremental into staging during dress rehearsals; full snapshot at cutover |
| Staging location | Separate SQL Server staging instance on CorpNET; not the production DB |
| Encryption in flight | TLS for the ODBC channel; staging DB encrypted at rest |
| Read load on Ingres | Throttled; read replica preferred if available |
| Audit during extract | Each extract produces a manifest with row counts + hashes per table |

### 5.3 Stage — what's in the staging DB

- Mirror of source Ingres tables, in source shape (no transformation yet)
- Adds `_extract_run_id` and `_row_hash` columns per row for reconciliation
- Indexed for transformation join performance
- Retained until full reconciliation completes; archived after cutover

### 5.4 Transform — UDB → CIM mapping

Transformation is implemented in **versioned, repeatable, reviewable code** — not ad-hoc SQL scripts run by humans.

| Property | Decision |
|---|---|
| Implementation | T-SQL stored procedures in a `migration` schema, version-controlled in the data-migration repo |
| Mapping definitions | Per-table mapping spec (input columns → output columns + transformation rule) |
| Edge-case handling | Each UDB-to-CIM conversion edge case (NULL, encoded value, missing FK target) has a documented rule and a unit test |
| Lookups (e.g., district code → CIM ConnectivityNode reference) | Reference tables in `dbm` schema; pre-loaded during P1b |
| Idempotency | Re-running transformation produces the same result; not append-only |
| Observability | Transformation emits row-counts, error-counts, type-conversion-warnings to migration audit log |

### 5.5 Load — staging to per-service production schemas

- Direct INSERT from transformed staging tables into per-service production schemas
- Bulk-load mode (`BULK INSERT` or `bcp`) for high-volume tables (audit, history)
- Constraints temporarily disabled for performance; **re-enabled and validated before cutover go-live**
- Indexes built after load completes (faster than maintaining during load)
- Temporal table SYSTEM_TIME populated explicitly for historical data using migrated timestamps

### 5.6 Reconcile — the diff harness

This is half the migration work, frequently underestimated. Detail in §6.

### 5.7 Cut — switch traffic

Cutover sequence per application — see §8.

---

## 6. Reconciliation strategy

### 6.1 Three layers of reconciliation

Each layer catches different defects.

| Layer | What it checks | Tooling |
|---|---|---|
| **Row-level** | Every source row has a corresponding target row; field values match per mapping rule | Per-table row-by-row diff job; reports mismatches |
| **Aggregate** | Source aggregates (COUNT, SUM, GROUP BY) match target aggregates | Per-table aggregate query against source vs. target |
| **Behavioral** | Production-pattern queries on the source produce the same results on the target | Captured query corpus from Ingres production replayed against SQL Server |

All three are required. Row-level alone misses semantic mismatches (e.g., dates that look identical but compare differently). Aggregate alone misses individual row defects that cancel out.

### 6.2 Acceptance criteria

| Layer | Target | Rationale |
|---|---|---|
| Row-level | ≥ 99.99% match (per mapping rule) | Some legitimate semantic translations look like differences (e.g., NULL → 'Unknown' for explicit sentinel handling) |
| Aggregate | 100% match for transactional tables; ≥ 99.99% for audit-derived | Aggregates that don't match indicate row-level bugs we missed |
| Behavioral | 100% match on the audit-relevant query corpus | Regulator queries must be reproducible |

### 6.3 The harness reuses across apps

Built during P1b POC for FMS, reused for TOMS, DBM, DSO, SDS, TLS. Marginal cost per subsequent app is 30–40% of the first build.

### 6.4 Mismatches are not always bugs

The harness is configured to recognize **expected legitimate translations** (e.g., `NULL` → `'Unknown'`, packed flag → unpacked enum). These are documented in the type-mapping spec. Unexplained mismatches are bugs.

---

## 7. Audit data continuity

### 7.1 Why audit is special

Regulators require a **continuous, reconstructible audit trail**. Cutting over to a new database without audit continuity is a regulatory event in itself.

### 7.2 Strategy

Two approaches, used together:

#### Approach A — Migrate historical audit data into the new audit schema

- Operator action logs from Ingres are migrated into the new `audit` schema
- Hash chain rebuilt during migration with documented re-hash chain (the rehash itself is recorded as a corrective audit action)
- Temporal history reconstructed where source data supports it; flagged where it doesn't
- Documented in regulator-facing migration audit memo (delivered before cutover)

#### Approach B — Preserve the legacy DB read-only for 7 years

- Legacy Ingres remains running in read-only mode for the full retention window
- Regulator queries against pre-cutover data go to the legacy system
- Post-cutover queries go to SQL Server
- Operator action queries spanning the cutover boundary are explicitly handled by query-routing logic

**Recommendation: both.** Approach A makes new-system queries simple; Approach B handles cases where rehash is not possible or audit-reconstruction must use the original system. Keeping Ingres running for 7 years is a real ops cost — name it explicitly in the budget.

### 7.3 Cutover-window audit gap

The cutover weekend itself produces a small audit gap (legacy frozen → new system live). Mitigation:

- Freeze legacy at T0; capture final state hash
- Verify reconciliation complete at T0 + ε
- New system live at T0 + ε with cutover record marking the boundary
- Operators trained that any actions during freeze are logged by-hand and entered post-cutover with a documented timestamp

The gap is a known, time-boxed, documented event. Not a silent loss.

---

## 8. Per-app cutover migration sequence (Option A)

Each application's cutover migration follows the same pattern. Six events: FMS → TOMS → DBM → DSO → SDS → TLS.

### 8.1 The 4-week-window pattern

This integrates with the per-app cutover pattern from B1 §2.5.

| Week | Migration activity |
|---|---|
| -4 | Dress rehearsal #1: full migration to a clone of Pre-Prod; full reconciliation; timing measured |
| -3 | Dry-run review; defects fixed |
| -2 | Dress rehearsal #2: full migration with defect fixes; reconciliation passes |
| -1 | Final freeze for the **app's data** (not full system); rehearsal #3 against latest snapshot |
| 0 (Friday evening) | **Cutover begins:** legacy app entry to read-only |
| 0 (Friday → Saturday) | Final extract + transform + load |
| 0 (Saturday) | Reconciliation runs; sign-off by Data Architecture + Compliance |
| 0 (Saturday → Sunday) | Smoke tests + operator-driven readiness checks |
| 0 (Sunday) | Go/no-go decision; if go, traffic flips |
| +1 to +4 | Soak: legacy retained read-only on OpNET as rollback plane |

### 8.2 Application-specific considerations

| App | Specific considerations |
|---|---|
| FMS | First migration; harness is exercised most rigorously here; longest soak (4 weeks) |
| TOMS | Highest reuse from FMS; transmission-specific topology adjustments |
| DBM | Foundational data; **cuts over before remaining apps depend on shared hierarchy** — consider sequencing DBM before DSO/SDS/TLS even though incremental build did them in different order |
| DSO | Dielectric extensions add edge cases vs. FMS/TOMS |
| SDS | Steam-specific constructs least CIM-aligned; longest reconciliation cycle expected |
| TLS | Many integration touch-points; coordinate with integration migration |

**Open decision:** DBM cutover sequencing — should DBM cut earlier than its build order suggests, given downstream dependency? Recommend: build TOMS first (reuse from FMS), but cut over DBM second so remaining apps depend on the modernized DBM. Confirm in P1.

### 8.3 Per-event migration size estimates

Indicative — refined post-profiling.

| App | Estimated migration window | Reconciliation window |
|---|---|---|
| FMS | 8–12 hours | 6–10 hours |
| TOMS | 6–10 hours | 5–8 hours |
| DBM | 4–8 hours | 4–6 hours |
| DSO | 6–10 hours | 6–10 hours (more reconciliation due to extension complexity) |
| SDS | 8–14 hours | 8–14 hours (most complex) |
| TLS | 4–6 hours | 4–6 hours |

These fit within the cutover weekend (Friday evening → Sunday). Sizes refine with profiling and dress rehearsal data.

---

## 9. Parallel-run strategy

### 9.1 Why "parallel-run" applies even under big-bang

Option A is per-app big-bang, but **legacy is retained read-only on OpNET for the soak period (4 weeks per app)**. This is parallel-run for read-only verification, not bidirectional dual-write.

### 9.2 What runs in parallel during soak

| System | Mode | Purpose |
|---|---|---|
| Legacy Ingres for the cut-over app | Read-only | Audit reconstruction for pre-cutover events; rollback plane |
| Modern stack | Active read-write | Primary system for the cut-over app |
| Other legacy apps | Active read-write | Operating normally; not yet cut over |
| Modern other apps | Empty / shadow | Built but not yet cut over |

### 9.3 What we explicitly do not do

- **Bidirectional dual-write across legacy and modern.** This is the single most expensive integration pattern; under Option A we don't need it.
- **Mid-soak rollback to legacy as primary.** Soak is a rollback *availability* window; if rollback is invoked, it's a rollback decision, not a routine operation.

### 9.4 Soak exit criteria

- 4 weeks of operation under load
- No P1 defects open against the cut-over app
- Audit reconstruction validated by Compliance for the soak window
- Defect rate trending below threshold
- Operator confidence panel sign-off

---

## 10. Fallback / rollback strategy

### 10.1 Roll back from what to what

- Pre-cutover: legacy is primary; rollback is trivial (don't go ahead with cutover)
- Cutover weekend (T0 to T0+72h): rollback to legacy is feasible if invoked before the operator goes-live confidence panel; data drift is bounded to the weekend's manual entries
- Soak period (T0+72h to T0+4 weeks): rollback is **a major decision**; data accumulated in the modern system must be reverse-migrated to legacy or a "modern-was-authoritative for these N days" reconciliation produced
- Post-soak: rollback is no longer feasible without significant data loss; legacy retired

### 10.2 Decision points

| Decision point | Authority | Trigger |
|---|---|---|
| Pre-cutover go/no-go (T0-1) | Operations Lead + CIO | Reconciliation passes; smoke tests pass; operator panel sign-off |
| Cutover-weekend abort (T0 to T0+72h) | Operations Lead | P1 defect surface; reconciliation regression; safety event |
| Soak rollback (T0+72h to T0+28d) | Steering Committee | Sustained P1 defects; safety event; regulator escalation |
| Soak completion (T0+28d) | Service Manager | Defect rate ≤ threshold; legacy decommission prep begins |

### 10.3 Reverse-migration capability

The harness builds reverse-migration capability for the **cutover weekend** abort scenario. Modern → legacy reverse mapping is verified during dress rehearsal #2.

For the **soak rollback** scenario, reverse-migration is more complex (modern data has accumulated; some may not have a clean legacy representation). Documented in the cutover playbook outline.

### 10.4 What rollback never includes

- Restoring legacy as if cutover never happened. Once cutover happens, the cutover record exists; rollback rolls *forward* from a documented point, not *backward* in time.

---

## 11. Special considerations

### 11.1 BLOB / attachment data

If the source Ingres has attachment data (rare for switching workflows, but DSO/SDS may have inspection photos):

- Migrate to FILESTREAM (SQL Server) or external object storage
- Maintain referential integrity in the relational layer
- Verify attachment integrity with hash compare during reconciliation

### 11.2 Encrypted source columns

If Ingres columns are encrypted at the application layer:

- Decryption key access must be available during migration
- Re-encrypt under SQL Server's Always Encrypted or column-level encryption
- Key rotation may be required during migration if keys are old

### 11.3 Temporal data continuity

- Source temporal records (audit, history) carry their original timestamps to the target
- New temporal records start from the cutover moment with `ValidFromUtc = cutover_T0`
- Queries spanning cutover boundary work correctly because timestamps are preserved

### 11.4 Reference data hierarchies

- Power system hierarchies (substation, feeder, breaker) migrated from `dbm` first
- Foreign keys from app-specific schemas to `dbm` are validated post-load
- Orphan rows (children without parents) are quarantined for review, not silently dropped

### 11.5 EMS-related data

- EMS event history from the legacy EMS endpoint stub is migrated as integration audit log entries
- Live EMS connection cuts over at the *same moment* as the application — no continuity requirement at the EMS layer (EMS retries on failure)

---

## 12. Migration testing

### 12.1 Test layers

| Layer | What it tests | Where |
|---|---|---|
| Migration unit tests | Each transformation rule (UDB→CIM mapping function) | CI on every commit |
| Reconciliation tests | Source → target matches per harness | CI; full run nightly during Pre-Prod |
| End-to-end migration test | Full app data through extract → transform → load → reconcile | Pre-Prod; weekly during P1b/P2; per-rehearsal in P4 |
| Restore + replay test | Migrated DB restored and operated | Pre-Prod; per-rehearsal |
| Performance test | Migration completes in window; reconciliation completes in window | Pre-Prod; per-rehearsal |
| Regulator-query test | Regulator query corpus produces matching results on source vs. target | Pre-Prod; M-09 gate |

### 12.2 Test data

- Production-like data volumes used in Pre-Prod (anonymized PII)
- Edge cases curated explicitly:
  - Boundary timestamps (year transitions, leap days)
  - NULL combinations
  - Encoded/packed values at boundary
  - Maximum-length strings
  - Non-ASCII characters in operator names, locations
  - Historic data with deprecated UDB type encodings

### 12.3 Synthetic disaster scenarios

Tested at least once in P3a:

- Power loss during transform
- Reconciliation harness crash mid-run
- Source extract corrupted (verify hashes detect)
- Network partition CorpNET ↔ OpNET during migration
- Disk-full during load

---

## 13. Risks and mitigations

Augments the program risk register; not exhaustive.

| Risk | Probability | Impact | Score | Mitigation |
|---|---|---|---|---|
| **CIM extension proliferation beyond expected (>15% of model)** | Med | High | 12 | P1b POC budgets +20% for extension catalog work; Data Architect manages extension proliferation explicitly |
| **Reconciliation harness underestimated** | High | High | 16 | Estimation worksheet has explicit reconciliation budget; build harness-first in P1b POC |
| **Source profiling reveals data quality issues** | High | Med | 12 | Profiling delivered before transform design; quality fixes in legacy or migration adjusted |
| **Performance: migration window exceeds cutover weekend** | Med | High | 12 | Dress rehearsal #1 measures actual time; if exceeds, switch to incremental migration pattern (more complex) |
| **Reverse-migration not implementable for some constructs** | Med | High | 12 | Catalog non-reversible cases during P1b; document accepted rollback risk per construct |
| **Audit chain rehash misinterpreted by regulator** | Low | Very High | 10 | Pre-cutover engagement with regulator; documented memo explaining rehash methodology |
| **DBM cutover order causes downstream dependency issue** | Med | Med | 9 | Decision in P1; if DBM cuts second, downstream apps reference modern DBM without legacy fallback |
| **Always Encrypted key rotation during migration** | Low | Med | 6 | Plan key rotation outside migration window; migration uses stable keys |

---

## 14. Open decisions for P1 / P1b

| ID | Decision | Driver | Required by |
|---|---|---|---|
| MIG-01 | Confirm legacy retention period (read-only Ingres maintained) | Compliance | P1 |
| MIG-02 | Confirm DBM cutover sequencing (build vs. cutover order can differ) | Data Architect + Operations | P1b |
| MIG-03 | Confirm CIM version (CIM 17 vs. 18) | Data Architect | P1b |
| MIG-04 | Confirm tooling for extract from Ingres (SSIS, custom, or vendor tool) | Data Architect + Integration Lead | P1 |
| MIG-05 | Confirm staging DB sizing | Storage team | P1 |
| MIG-06 | Confirm migration testing frequency in Pre-Prod | Test Lead | P1a |
| MIG-07 | Confirm Always Encrypted scope and key custody | Security Lead | P1 |
| MIG-08 | Confirm regulator engagement timing for audit-rehash explanation | Compliance + Sponsor | M-04 |
| MIG-09 | Confirm legacy decommission criteria post-soak | Operations + Compliance | M-10 |

---

## 15. What this document does not specify

- Specific UDB→CIM column mappings (P1b POC output)
- Specific T-SQL transformation procedures (built during P1b, P2, P3 per app)
- Specific reconciliation harness implementation (built during P1b POC)
- Detailed cutover-weekend runbook (covered in [19-cutover-playbook-outline.md](19-cutover-playbook-outline.md); full runbook is per-app artifact in P4)
- DR/HA topology beyond migration context (covered in [16-database-design-principles.md](16-database-design-principles.md))
- Specific staging DB sizing (P1 detailed design after profiling)
