# Bug Template

**Use:** Every defect against built capability uses this template. Bug severity is **operator-impact-aware**, not abstract.

**Pairs with:** [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §2 (adjuncts).

---

## Bug header

| Field | Value |
|---|---|
| **Bug ID** | (e.g., `BUG-FMS-0142`) |
| **Title** | (one line, observed behavior) |
| **Severity** | S1 / S2 / S3 / S4 (see below) |
| **Priority** | P1 / P2 / P3 / P4 |
| **Affected service** | FMS / TOMS / DSO / TLS / SDS / DBM / Messaging / Task Manager / Integration |
| **Affected workflow step** | Notify / Create / De-energize / Authorize / Execute / Test / Re-energize / Close / cross-cutting |
| **Found in** | Dev / SIT / Pre-Prod / Prod / Hypercare |
| **Found by** | (name) |
| **Reported on** | (date) |
| **Owner** | (engineer assigned) |
| **Status** | New / Triaged / In Progress / In Review / Verified / Closed / Won't Fix |

---

## Severity scale (operator-impact-aware)

This scale governs response time and escalation. It is **not** abstract bug severity.

| Severity | Definition | Response |
|---|---|---|
| **S1** | Operator cannot complete a switching workflow; or audit trail loss; or cross-system inconsistency that could cause unsafe state | Drop other work; on-call engaged immediately; sponsor notified |
| **S2** | Operator can complete the workflow with a workaround; or non-load-bearing audit gap; or notable parity divergence | Same-sprint fix; PO + Engineering Lead notified |
| **S3** | Cosmetic or minor parity divergence; non-critical telemetry gap | Backlog; fix when capacity allows |
| **S4** | Documentation or non-functional polish | Bundle with adjacent work |

**Operator confusion is severity 1.** If an operator cannot tell what state a card is in, that is S1, even if the underlying state is correct.

---

## Reproduction steps

Numbered, deterministic, copy-pasteable. Vague reproduction is the most common cause of bug bounce-backs.

1. 
2. 
3. 

## Expected behavior

What should happen — referencing the AC or the parity contract from the relevant story.

## Actual behavior

What happens. Screenshots / logs / trace links attached. Include the **request correlation ID** if available.

---

## Impact assessment

| Impact dimension | Assessment |
|---|---|
| Number of operators affected | (1 / district / all) |
| Frequency observed | (one-off / per-day / per-card) |
| Workaround available? | (yes/no; describe) |
| Audit / safety implication | **Yes / No** — explicit answer required |
| Regulatory implication | (cite regulation if any) |

---

## Operator workaround

If a workaround exists, document it explicitly so it can be communicated to operators while the fix is in flight. Include any caveats (e.g., "workaround does not produce the same audit trail").

---

## Root cause analysis

Required for S1 and S2. Optional but encouraged for S3.

| Field | Value |
|---|---|
| Suspected root cause | |
| Confirmed root cause | |
| Why this slipped past tests | (test gap analysis) |
| Why this slipped past code review | (process gap analysis) |
| Was this a known risk? | (R-ID if yes) |

---

## Fix plan

| Step | Owner | Estimate |
|---|---|---|
| Reproduce in isolated test | | |
| Code change | | |
| Unit / integration test added | | |
| Validation in SIT | | |
| Operator validation if parity | | |

---

## Validation

| Validator | Result | Notes |
|---|---|---|
| Test engineer | | |
| Operator SME (if parity) | | |
| Compliance officer (if `[REG]`) | | |

---

## Audit / safety implication review

If "Audit / safety implication = Yes" was checked above:

- [ ] Compliance officer reviewed
- [ ] Audit log gap (if any) reconciled
- [ ] Regulator notification considered (if applicable)
- [ ] Affected card / workflow IDs captured for forensics
- [ ] Lessons learned added to the program risk register if novel

---

## Worked example

```
Bug ID:           BUG-FMS-0142
Title:            Edit-confirm on card review pane occasionally fails to update temporal history
Severity:         S2
Priority:         P1
Affected service: FMS
Workflow step:    Create
Found in:         SIT
Found by:         T. Khan (Test engineer)
Reported on:      2026-09-12
Owner:            P. Iyer
Status:           In Progress

Reproduction steps:
  1. Open a PendingReview card (auto-created from EMS planned-outage event)
  2. Edit the "target restoration window" field
  3. Confirm the edit
  4. Open the card's temporal history
  5. Observe: the edit appears in the operator-action log but not in the
     temporal history of the Card entity in approximately 1 in 30 attempts

Expected behavior:
  Per AC-FMS-S-104 AC-4, every confirmed edit appears in the temporal
  history of the Card entity with before-value, after-value, principal,
  and timestamp.

Actual behavior:
  Approximately 1 edit in 30 fails to record in the temporal table.
  Operator action log records the edit. Correlation IDs of failed cases
  attached: c-7e2..., c-9b8..., c-2a1...

Impact:
  Operators affected: any FMS operator
  Frequency: ~3% of edits
  Workaround: no operator workaround; the data state is correct, only
    history is missing
  Audit / safety implication: YES — entity history gap is a regulatory exposure
  Regulatory implication: NERC CIP-008 audit-trail completeness

Operator workaround:
  None. Note to operators: edits are still functional; history may be incomplete.
  Operators should not rely on temporal history for audit reconstruction
  for cards modified between 2026-09-08 and the fix date.

Root cause analysis:
  Suspected root cause: race condition between Card UPDATE and the SQL
    Server temporal SYSTEM_TIME insert when the operator-action log write
    is committed in the same transaction as the entity update.
  Confirmed root cause: under investigation
  Why this slipped past tests: integration tests do not exercise concurrent
    edit + audit emission paths; coverage gap.
  Why this slipped past review: pattern in question was lifted from a
    sibling service with a different transactional shape.
  Was this a known risk? Adjacent to R-006 (Ingres-to-SQL semantics)
    but not previously flagged.

Fix plan:
  Reproduce in isolated test (5h)            P. Iyer
  Code change: explicit transactional shape (4h)   P. Iyer
  Add concurrent-edit integration test (3h)        T. Khan
  Validate in SIT (next nightly run)               T. Khan
  Operator validation: not required (parity is restored, no UX change)

Validation: pending

Audit / safety implication review:
  ✅ Compliance officer notified (J. Reyes)
  ⏳ Audit log gap: SQL audit forensics in progress to identify all affected cards
  ⏳ Regulator notification: pending decision after forensics
  ⏳ Affected card IDs: captured (forensics ongoing)
  ⏳ Lessons learned: will add to risk register once root cause confirmed
```

---

## Anti-patterns

| Anti-pattern | Fix |
|---|---|
| "Doesn't work" with no reproduction | Reject; ask reporter for steps |
| Severity assigned without operator-impact assessment | Re-triage with operator SME |
| S1 fix shipped without root-cause analysis | Block close until RCA recorded |
| Bug closed without a regression test | Block close until test exists |
| Bug closed without operator validation for parity issues | Block close until operator confirms |
