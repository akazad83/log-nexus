"""
Generator for B4 deliverables.

Produces:
  - 13-resource-plan.xlsx
  - 14-resource-plan-brutal-honesty-memo.docx (via _md_to_docx)
  - 15-estimation-worksheet.xlsx

Run from this directory: python _generate_b4.py
"""

from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

OUT = Path(__file__).parent

# ---- styling (matches _generate.py) ----------------------------------------

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
SUBHEADER_FILL = PatternFill("solid", fgColor="D9E1F2")
SUBHEADER_FONT = Font(name="Calibri", size=11, bold=True, color="1F3864")
BODY_FONT = Font(name="Calibri", size=10)
BOLD_FONT = Font(name="Calibri", size=10, bold=True)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CONFIDENCE_FILLS = {
    "High": PatternFill("solid", fgColor="C6EFCE"),
    "Medium": PatternFill("solid", fgColor="FFEB9C"),
    "Low": PatternFill("solid", fgColor="FFC7CE"),
}

NV_FILL = PatternFill("solid", fgColor="DEEBF7")
PARITY_FILL = PatternFill("solid", fgColor="FFFFFF")


def style_header_row(ws, row=1, ncols=None):
    if ncols is None:
        ncols = ws.max_column
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 30
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def autosize_columns(ws, min_width=10, max_width=55):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        longest = 0
        for cell in col:
            v = cell.value
            if v is None:
                continue
            for line in str(v).splitlines():
                longest = max(longest, len(line))
        ws.column_dimensions[letter].width = max(min_width, min(max_width, longest + 2))


def write_table(ws, headers, rows, start_row=1):
    for c, h in enumerate(headers, 1):
        ws.cell(row=start_row, column=c, value=h)
    style_header_row(ws, row=start_row, ncols=len(headers))
    for r, row in enumerate(rows, start_row + 1):
        for c, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=c, value=val)
            cell.font = BODY_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = BORDER
    autosize_columns(ws)


# ---- 13: Resource Plan -----------------------------------------------------

PHASES = ["P0a", "P1", "P1a", "P1b", "P2", "P2a", "P3", "P3a", "P4", "P5"]
PHASE_LABELS = [
    "P0a Phase 0 Audit",
    "P1 Detailed Design",
    "P1a Foundational",
    "P1b UDB→CIM POC",
    "P2 MVP Build",
    "P2a MVP UAT",
    "P3 Incremental Build",
    "P3a Full UAT",
    "P4 Cutover",
    "P5 Hypercare",
]
PHASE_DURATION_MO = {
    "P0a": 0.25,  # ~1 week
    "P1": 4,
    "P1a": 3,
    "P1b": 2,
    "P2": 6.5,
    "P2a": 2,
    "P3": 15,
    "P3a": 3,
    "P4": 6,
    "P5": 4,
}

EFFECTIVE_FTE_FACTOR = {
    "P0a": 1.00,
    "P1":  0.95,
    "P1a": 0.85,
    "P1b": 0.90,
    "P2":  0.85,
    "P2a": 0.95,
    "P3":  0.90,  # blended (0.85 first 4 mo, 0.95 later)
    "P3a": 0.95,
    "P4":  0.90,
    "P5":  0.95,
}

ROLE_FTE = [
    # (role, P0a, P1, P1a, P1b, P2, P2a, P3, P3a, P4, P5, band)
    ("Program Lead",                    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, "A"),
    ("Solution Architect",              1.0, 1.0, 1.0, 1.0, 1.0, 0.5, 1.0, 0.5, 0.5, 0.5, "A"),
    ("Domain Architect / Tech Lead",    0.0, 2.0, 2.0, 2.0, 2.0, 1.0, 4.0, 2.0, 2.0, 1.0, "B"),
    ("Backend Lead",                    0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 1.0, "B"),
    ("Frontend Lead",                   0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 1.0, "B"),
    ("Data Architect",                  0.0, 1.0, 1.0, 1.0, 0.5, 0.5, 1.0, 0.5, 0.5, 0.5, "B"),
    ("Integration Lead",                0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5, "B"),
    ("DevOps Lead",                     0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, "B"),
    ("Test Lead",                       0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, "B"),
    ("Security Lead",                   0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5, "B"),
    ("Service Manager",                 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, "B"),
    ("Change Lead",                     0.0, 0.5, 0.5, 0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5, "B"),
    ("Backend engineers",               0.0, 1.0, 4.0, 6.0, 8.0, 6.0,12.0, 8.0, 6.0, 4.0, "C/D"),
    ("Frontend engineers",              0.0, 1.0, 2.0, 2.0, 5.0, 4.0, 8.0, 6.0, 4.0, 2.0, "C/D"),
    ("DB engineers",                    0.0, 0.0, 1.0, 2.0, 1.0, 1.0, 2.0, 1.0, 1.0, 1.0, "C/D"),
    ("Integration engineers",           0.0, 1.0, 1.0, 1.0, 2.0, 2.0, 3.0, 2.0, 2.0, 1.0, "C/D"),
    ("DevOps engineers",                0.0, 1.0, 2.0, 2.0, 1.0, 1.0, 1.0, 1.0, 2.0, 1.0, "C/D"),
    ("QA engineers",                    1.0, 1.0, 2.0, 2.0, 4.0, 6.0, 8.0,10.0, 6.0, 4.0, "C/D"),
    ("Security engineers",              0.0, 0.5, 0.5, 0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5, "C/D"),
    ("BA Lead",                         1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5, 0.5, "B"),
    ("BA / Product Owner",              0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 3.0, 2.0, 2.0, 1.0, "C/D"),
    ("Scrum Master",                    0.0, 0.5, 1.0, 1.0, 2.0, 2.0, 3.0, 2.0, 2.0, 1.0, "E"),
    ("UX designer",                     0.0, 1.0, 1.0, 1.0, 2.0, 1.0, 2.0, 1.0, 0.0, 0.0, "E"),
    ("OpenRoad reader",                 0.0, 1.0, 1.0, 1.0, 1.0, 0.5, 1.0, 0.5, 0.0, 0.0, "G"),
    ("Compliance officer",              0.25,0.25,0.25,0.25,0.5, 0.5, 0.5, 0.5, 0.5, 0.25,"E"),
]

OPERATOR_SMES = ("Operator SMEs (separate)",
                 0, 1, 2, 2, 1, 1, 6, 6, 6, 4, "F")


def build_resource_plan():
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Sheet 1: Cover ----
    ws = wb.create_sheet("Cover")
    ws["A1"] = "Resource Plan — Switching Order Modernization"
    ws["A1"].font = Font(name="Calibri", size=16, bold=True, color="1F3864")
    ws.merge_cells("A1:F1")

    fields = [
        ("Artifact ID", "B4.5"),
        ("Status", "Draft for Program Lead + Sponsor review"),
        ("Companion .md", "13-resource-plan.md"),
        ("Pairs with", "14-resource-plan-brutal-honesty-memo (.md/.docx); 15-estimation-worksheet (.md/.xlsx)"),
        ("Cutover strategy", "Option A — staggered big-bang per app (D-001)"),
        ("Indicative duration", "30–42 months (likely ~36)"),
        ("Peak engineering FTE", "~60 in P3 (Incremental Build)"),
        ("Peak operator SMEs", "6 (full-time, per app)"),
    ]
    for i, (k, v) in enumerate(fields, 3):
        ws.cell(row=i, column=1, value=k).font = BOLD_FONT
        ws.cell(row=i, column=2, value=v).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)

    ws["A12"] = "Workbook contents"
    ws["A12"].font = SUBHEADER_FONT
    ws["A12"].fill = SUBHEADER_FILL
    ws.merge_cells("A12:F12")
    sheets = [
        ("Cover", "Document control + summary"),
        ("FTE Ramp", "Role × Phase FTE grid (likely case)"),
        ("Effective FTE", "Onboarding-adjusted FTE per phase"),
        ("Skills Matrix", "Role × Skill required-level grid"),
        ("Key-Person Risks", "Five highest-impact key-person dependencies"),
        ("Hiring Plan", "Roles required by phase start"),
        ("Rate Card", "Configurable rate bands (sponsor populates)"),
    ]
    for i, (s, p) in enumerate(sheets, 13):
        ws.cell(row=i, column=1, value=s).font = BOLD_FONT
        ws.cell(row=i, column=2, value=p).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 70

    # ---- Sheet 2: FTE Ramp ----
    ws = wb.create_sheet("FTE Ramp")
    headers = ["Role"] + PHASE_LABELS + ["Rate Band"]
    write_table(ws, headers, [list(r) for r in [
        (role, *fte, band) for (role, *fte, band) in [
            (r[0], *r[1:11], r[11]) for r in ROLE_FTE
        ]
    ]])
    # subtotal row (engineering)
    subtotal_row = ws.max_row + 1
    ws.cell(row=subtotal_row, column=1, value="Engineering subtotal").font = BOLD_FONT
    for ci, p in enumerate(PHASES, 2):
        col_idx = PHASES.index(p) + 2  # role col + phase index
        total = sum(r[col_idx - 1] for r in ROLE_FTE)
        cell = ws.cell(row=subtotal_row, column=ci, value=round(total, 2))
        cell.font = BOLD_FONT
        cell.fill = SUBHEADER_FILL
    # Operator SMEs row
    op_row = subtotal_row + 2
    ws.cell(row=op_row, column=1, value=OPERATOR_SMES[0]).font = BOLD_FONT
    for ci, val in enumerate(OPERATOR_SMES[1:11], 2):
        c = ws.cell(row=op_row, column=ci, value=val)
        c.font = BODY_FONT
        c.fill = PatternFill("solid", fgColor="FFF7CC")
    ws.cell(row=op_row, column=12, value=OPERATOR_SMES[11]).font = BODY_FONT

    # ---- Sheet 3: Effective FTE ----
    ws = wb.create_sheet("Effective FTE")
    headers = ["Phase", "Duration (months)", "Engineering FTE (nominal)",
               "Onboarding factor", "Effective FTE", "Effective person-days"]
    rows = []
    for i, p in enumerate(PHASES):
        nominal = sum(r[i + 1] for r in ROLE_FTE)
        factor = EFFECTIVE_FTE_FACTOR[p]
        eff = round(nominal * factor, 2)
        # ~22 working days per month
        eff_pd = round(eff * PHASE_DURATION_MO[p] * 22, 0)
        rows.append([PHASE_LABELS[i], PHASE_DURATION_MO[p], round(nominal, 2), factor, eff, eff_pd])
    write_table(ws, headers, rows)
    # totals
    total_row = ws.max_row + 1
    ws.cell(row=total_row, column=1, value="TOTAL effective person-days").font = BOLD_FONT
    total_pd = sum(r[5] for r in rows)
    ws.cell(row=total_row, column=6, value=int(total_pd)).font = BOLD_FONT
    ws.cell(row=total_row, column=6).fill = SUBHEADER_FILL

    # ---- Sheet 4: Skills Matrix ----
    ws = wb.create_sheet("Skills Matrix")
    skills = [
        ".NET 8/9", "Angular", "SQL Server 2025", "DDD",
        "On-prem DevOps", "OpenRoad / 4GL", "Ingres / UDB",
        "CIM model", "Switching domain", "OT/IT segmentation",
        "NERC CIP regulatory", "Threat modeling",
        "Performance testing", "Operator co-design",
        "Mental-model parity", "Backlog engineering",
    ]
    headers = ["Role"] + skills
    # critical(◎◎)=2, required(◎)=1, working(○)=0.5, n/a=blank
    matrix_rows = [
        ("Solution Architect",      [1, 1, 0.5, 1, 0.5, 1, 0.5, 0.5, 1, 1, 0.5, 0.5, 0.5, 0.5, "", ""]),
        ("Domain Architect",         [1, 0.5, 0.5, 1, 0.5, 1, 0.5, 0.5, 1, 0.5, 0.5, 0.5, 0.5, 0.5, "", ""]),
        ("Backend Lead",             [1, 0.5, 1, 1, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, "", 0.5, 0.5, "", "", ""]),
        ("Frontend Lead",            [0.5, 1, "", 0.5, 0.5, "", "", "", 0.5, "", "", 0.5, 0.5, 0.5, 1, ""]),
        ("Data Architect",           [0.5, "", 1, 0.5, "", 0.5, 1, 1, 0.5, 0.5, "", "", 0.5, "", "", ""]),
        ("Integration Lead",         [1, 0.5, 0.5, 1, 0.5, 0.5, 0.5, 0.5, 1, 0.5, "", 0.5, 0.5, "", "", ""]),
        ("DevOps Lead",              [0.5, "", 0.5, "", 1, "", "", "", "", 1, 0.5, 0.5, 0.5, "", "", ""]),
        ("Test Lead",                [0.5, 0.5, 0.5, 0.5, 0.5, "", "", 0.5, 0.5, 0.5, 0.5, 0.5, 1, "", 0.5, ""]),
        ("Security Lead",            [0.5, "", 0.5, 0.5, 0.5, "", "", "", "", 1, 1, 1, "", "", "", ""]),
        ("Backend engineer",         [1, "", 1, 1, 0.5, "", "", "", 0.5, "", "", 0.5, 0.5, "", "", ""]),
        ("Frontend engineer",        ["", 1, "", 0.5, 0.5, "", "", "", 0.5, "", "", "", 0.5, "", 0.5, ""]),
        ("DB engineer",              ["", "", 1, "", 0.5, "", 0.5, 0.5, "", "", "", "", 0.5, "", "", ""]),
        ("Integration engineer",     [1, "", 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, "", 0.5, 0.5, "", "", ""]),
        ("DevOps engineer",          [0.5, "", 0.5, "", 1, "", "", "", "", 0.5, "", "", 0.5, "", "", ""]),
        ("QA engineer",              [0.5, 0.5, 0.5, 0.5, 0.5, "", "", "", 0.5, "", "", "", 1, "", 0.5, ""]),
        ("Security engineer",        [0.5, "", "", "", 0.5, "", "", "", 0.5, 1, 0.5, 1, "", "", "", ""]),
        ("BA / PO",                  ["", "", "", 0.5, "", 0.5, 0.5, "", 1, "", 0.5, "", "", 1, 0.5, 1]),
        ("UX designer",              ["", 0.5, "", "", "", "", "", "", 0.5, "", "", "", "", 1, 2, ""]),
        ("OpenRoad reader",          ["", "", "", "", "", 2, 1, 0.5, 1, "", "", "", "", "", 0.5, ""]),
        ("Compliance officer",       ["", "", "", "", "", "", "", "", 1, "", 2, 0.5, "", 0.5, "", ""]),
    ]
    rows = [[role, *vals] for role, vals in matrix_rows]
    write_table(ws, headers, rows)
    # color cells by level
    level_fills = {
        2:  PatternFill("solid", fgColor="1F3864"),    # critical
        1:  PatternFill("solid", fgColor="2E75B6"),    # required
        0.5: PatternFill("solid", fgColor="BDD7EE"),   # working
    }
    level_text = {
        2:   ("◎◎", "FFFFFF"),
        1:   ("◎",  "FFFFFF"),
        0.5: ("○",  "1F3864"),
    }
    for ri in range(2, 2 + len(rows)):
        for ci in range(2, 2 + len(skills)):
            cell = ws.cell(row=ri, column=ci)
            v = cell.value
            if v in level_fills:
                cell.fill = level_fills[v]
                glyph, color = level_text[v]
                cell.value = glyph
                cell.font = Font(name="Calibri", size=10, bold=True, color=color)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif v in ("", None):
                cell.value = "—"
                cell.font = Font(name="Calibri", size=10, color="BFBFBF")
                cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions["A"].width = 28
    for ci in range(2, 2 + len(skills)):
        ws.column_dimensions[get_column_letter(ci)].width = 14

    # legend
    legend_row = ws.max_row + 2
    ws.cell(row=legend_row, column=1, value="Legend:").font = BOLD_FONT
    legends = [("◎◎", "Critical / hire-for"), ("◎", "Required"), ("○", "Working knowledge"), ("—", "Not required")]
    for i, (g, m) in enumerate(legends):
        c = ws.cell(row=legend_row, column=2 + i * 2, value=g)
        c.font = Font(name="Calibri", size=10, bold=True)
        c.alignment = Alignment(horizontal="center")
        ws.cell(row=legend_row, column=3 + i * 2, value=m).font = BODY_FONT

    # ---- Sheet 5: Key-Person Risks ----
    ws = wb.create_sheet("Key-Person Risks")
    headers = ["#", "Role", "Why critical", "Risk score (1-25)", "Mitigation"]
    rows = [
        [1, "Solution Architect",
         "Single owner of cross-zone integrity; OT/IT boundary; replacement onboarding ≥ 6 weeks",
         16,
         "Pair with Domain Architect from week 1; write all decisions as ADRs; rotate review authority"],
        [2, "OpenRoad reader",
         "Only person who can spot hidden 4GL rules; loss = R-001 + R-005 realized",
         20,
         "Identify backup contractor by P1 month 2; pair-reading sessions; recorded sessions"],
        [3, "Lead Operator SME (FMS during P2)",
         "M-06 acceptance authority; mental-model parity arbiter",
         15,
         "Backup operator SME; multi-operator review panel; recorded co-design sessions"],
        [4, "Compliance officer",
         "Sole regulator-facing reviewer; loss blocks M-06 and M-09",
         12,
         "Backup compliance reviewer pre-identified; regular regulator engagement"],
        [5, "Data Architect",
         "Sole UDB → CIM design owner; loss derails P1b POC",
         12,
         "Cross-train DB engineer during P1b; documented type-mapping spec"],
    ]
    write_table(ws, headers, rows)
    # color score
    for r in range(2, 2 + len(rows)):
        cell = ws.cell(row=r, column=4)
        score = cell.value
        if score >= 20:
            cell.fill = PatternFill("solid", fgColor="FFC7CE")
        elif score >= 12:
            cell.fill = PatternFill("solid", fgColor="FFEB9C")
        else:
            cell.fill = PatternFill("solid", fgColor="C6EFCE")
        cell.font = BOLD_FONT
        cell.alignment = Alignment(horizontal="center")

    # ---- Sheet 6: Hiring Plan ----
    ws = wb.create_sheet("Hiring Plan")
    headers = ["By the start of", "Must be available"]
    rows = [
        ["P0a", "Solution Architect, Test Lead, BA Lead, Program Lead, DevOps Lead, Compliance officer (consult)"],
        ["P1", "Domain Architects (2), Backend Lead, Frontend Lead, Data Architect, Integration Lead, Security Lead, OpenRoad reader, UX designer, BA/PO"],
        ["P1a", "Backend / Frontend / DB / Integration / DevOps / QA engineers (~50% of P3 peak)"],
        ["P2", "Service Manager, Change Lead, full operator SME for FMS, full MVP engineering team"],
        ["P3", "Per-app PO assignment; full operator SMEs across cores; peak engineering team"],
        ["P4", "Cutover crew (Service Manager + DevOps engineers + Security engineers heavy-loaded for ~6 events)"],
        ["P5", "Hypercare on-call rota; reduced engineering team"],
    ]
    write_table(ws, headers, rows)

    # ---- Sheet 7: Rate Card (configurable) ----
    ws = wb.create_sheet("Rate Card")
    headers = ["Band", "Roles", "Rate (sponsor populates)"]
    rows = [
        ["A", "Program Lead, Solution Architect, Sponsor", ""],
        ["B", "Domain Architect, *Lead roles, Service Manager, Change Lead, BA Lead", ""],
        ["C", "Senior engineers (BE, FE, DB, Int, DevOps, QA, Sec)", ""],
        ["D", "Mid-level engineers", ""],
        ["E", "UX, Compliance officer (consult), Scrum Master", ""],
        ["F", "Operator SMEs (utility internal)", ""],
        ["G", "OpenRoad reader contractor (specialist premium)", ""],
    ]
    write_table(ws, headers, rows)
    # add note
    note_row = ws.max_row + 2
    ws.cell(row=note_row, column=1, value="Note: rates left blank intentionally. Sponsor populates with utility actuals.").font = Font(italic=True, color="808080")
    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=3)

    out_path = OUT / "13-resource-plan.xlsx"
    wb.save(out_path)
    print(f"  wrote {out_path.name}")


# ---- 15: Estimation Worksheet ----------------------------------------------

# (Epic, Type [Parity/NV], Workflow, Confidence, Best, Likely, Worst, Assumption)
MVP_EPICS = [
    ("FMS-E-001", "EMS event ingestion (planned distribution outage)",       "Parity", "Notify",       "Medium",  60,  90, 140, "EMS sample payloads delivered (A-004)"),
    ("FMS-E-002", "Auto-create switching card from EMS event",               "Parity", "Create",       "Medium",  80, 130, 200, "Auto-create rules captured by Discovery audit"),
    ("FMS-E-003", "Operator card review pane (parity layout)",               "Parity", "Create",       "High",    50,  80, 120, "Legacy capture available for parity comparison"),
    ("FMS-E-004", "Card edit / pre-execution validation",                    "Parity", "Create",       "Medium",  50,  80, 130, ""),
    ("FMS-E-005", "De-energize step orchestration",                          "Parity", "De-energize",  "Medium",  70, 110, 170, "Orchestration rules code-traced (Audit dim 3)"),
    ("FMS-E-006", "Tag application (single tag, single holder)",             "Parity", "De-energize",  "Medium",  50,  80, 130, ""),
    ("FMS-E-007", "Authorization workflow (operator + supervisor)",          "Parity", "Authorize",    "Medium",  60, 100, 160, ""),
    ("FMS-E-008", "Field execution handoff to Rapid Restore",                "Parity", "Execute",      "Medium",  80, 120, 190, "Rapid Restore adapter contract stable"),
    ("FMS-E-009", "Step status updates from Rapid Restore",                  "Parity", "Execute",      "Medium",  50,  80, 130, ""),
    ("FMS-E-010", "Test-de-energized verification",                          "Parity", "Test",         "Medium",  40,  70, 110, ""),
    ("FMS-E-011", "Re-energize step orchestration",                          "Parity", "Re-energize",  "Medium",  60, 100, 160, ""),
    ("FMS-E-012", "Breaker-close instruction queued for EMS",                "Parity", "Re-energize",  "Medium",  50,  80, 130, ""),
    ("FMS-E-013", "Card close + audit trail finalization",                   "Parity", "Close",        "Medium",  50,  80, 130, ""),
    ("FMS-E-014", "Operator console workflow navigation",                    "Parity", "cross-cutting","High",    70, 110, 160, ""),
    ("FMS-E-015", "Operator authentication + RBAC (district + role)",        "Parity", "cross-cutting","Medium",  80, 120, 180, "AD/Entra hybrid pattern confirmed"),
    ("FMS-E-016", "Audit & operator-action log foundational integration",    "Parity", "cross-cutting","Medium", 100, 150, 220, "NFR-AUD-001 live"),
    ("FMS-E-017", "Telemetry & observability instrumentation",               "Parity", "cross-cutting","High",    50,  80, 110, ""),
    ("FMS-E-018", "NFR validation (latency, audit completeness)",            "Parity", "cross-cutting","Medium",  40,  70, 110, ""),
    ("FMS-NV-001","Visual feeder topology preview at card create",           "NewVal", "Create",       "Low",     90, 150, 240, "Operator co-design 2x effort vs parity"),
    ("FMS-NV-002","Real-time multi-operator card visibility",                "NewVal", "cross-cutting","Low",     70, 120, 200, "SignalR pattern unverified"),
    ("FMS-NV-003","Auto-suggest similar past cards (decision support)",      "NewVal", "Create",       "Low",     80, 140, 220, "Heuristic vs ML approach undecided (P1)"),
    ("FMS-NV-004","Mobile-friendly read-only view for supervisor approval",  "NewVal", "Authorize",    "Medium",  60, 100, 160, ""),
]

# Per-app aggregates for P3 (one row per app instead of per-Epic; keeps worksheet usable)
P3_APPS = [
    # (App, Parity Best, Parity Likely, Parity Worst, NV Best, NV Likely, NV Worst, Notes)
    ("FMS (remaining post-MVP)", 1100, 1500, 2100,  140,  200,  280, "Edge scenarios, multi-tag, emergency, etc."),
    ("TOMS",                     1050, 1400, 2000,  180,  250,  350, "Highest reuse from FMS; transmission complexity adjusted"),
    ("DBM",                       650,  900, 1300,  100,  150,  220, "Foundational data; data-centric not workflow-centric"),
    ("DSO",                      1050, 1400, 2000,  180,  250,  350, "Dielectric — moderate uniqueness"),
    ("SDS",                      1200, 1600, 2300,  180,  250,  350, "Steam — highest uniqueness; specialist operator pool"),
    ("TLS",                       820, 1100, 1600,  150,  200,  290, "Narrowest scope but integration-heavy"),
    ("Monitor apps (~30)",        900, 1200, 1700,  110,  150,  220, "Lightweight; built alongside parent app teams"),
    ("Cross-app integrations (15+)",
                                  1050, 1400, 2000,    0,    0,    0, "Pure integration work; no new-value"),
]


def build_estimation_worksheet():
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Sheet 1: Cover & Method ----
    ws = wb.create_sheet("Cover & Method")
    ws["A1"] = "Estimation Worksheet — Switching Order Modernization"
    ws["A1"].font = Font(name="Calibri", size=16, bold=True, color="1F3864")
    ws.merge_cells("A1:F1")
    fields = [
        ("Artifact ID", "B4.6"),
        ("Status", "Draft for Engineering Lead + Architecture Council review"),
        ("Companion .md", "15-estimation-worksheet.md (methodology contract)"),
        ("Estimation unit", "Person-days (PD) at Epic level"),
        ("Three-point", "Best / Likely / Worst — ranges reflect irreducible uncertainty"),
        ("Re-baseline gates", "End P0a, M-02, M-04, M-05, M-07, M-09"),
    ]
    for i, (k, v) in enumerate(fields, 3):
        ws.cell(row=i, column=1, value=k).font = BOLD_FONT
        ws.cell(row=i, column=2, value=v).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)
    ws["A11"] = "Three-point estimate definitions"
    ws["A11"].font = SUBHEADER_FONT
    ws["A11"].fill = SUBHEADER_FILL
    ws.merge_cells("A11:F11")
    defs = [
        ("Best", "Everything goes right. Pattern reuse high. SMEs responsive. No hidden rules surface."),
        ("Likely", "Normal program friction. Some hidden rules. Standard SME availability. ~30% pattern reuse."),
        ("Worst", "Hidden 4GL rules. Pattern reuse low. SME availability degrades. Vendor coordination delays."),
    ]
    for i, (k, v) in enumerate(defs, 12):
        ws.cell(row=i, column=1, value=k).font = BOLD_FONT
        ws.cell(row=i, column=2, value=v).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)
    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 90

    # ---- Sheet 2: Epic Catalog (MVP detail) ----
    ws = wb.create_sheet("MVP Epic Catalog")
    headers = ["Epic ID", "Epic", "Type", "Workflow", "Confidence", "Best (PD)", "Likely (PD)", "Worst (PD)", "Assumption"]
    rows = [list(e) for e in MVP_EPICS]
    write_table(ws, headers, rows)

    # color rows by Type and Confidence
    for ri in range(2, 2 + len(rows)):
        type_cell = ws.cell(row=ri, column=3)
        if type_cell.value == "NewVal":
            for ci in range(1, len(headers) + 1):
                ws.cell(row=ri, column=ci).fill = NV_FILL
        conf_cell = ws.cell(row=ri, column=5)
        if conf_cell.value in CONFIDENCE_FILLS:
            conf_cell.fill = CONFIDENCE_FILLS[conf_cell.value]
            conf_cell.font = BOLD_FONT
            conf_cell.alignment = Alignment(horizontal="center")

    # subtotals
    parity_rows = [r for r in rows if r[2] == "Parity"]
    nv_rows = [r for r in rows if r[2] == "NewVal"]

    def sub_row(label, target_rows, fill):
        sr = ws.max_row + 1
        ws.cell(row=sr, column=1, value=label).font = BOLD_FONT
        for ci, col in enumerate([5, 6, 7], 6):
            total = sum(r[col] for r in target_rows)
            c = ws.cell(row=sr, column=ci, value=total)
            c.font = BOLD_FONT
            c.fill = fill
        return sr

    sub_row("Parity subtotal", parity_rows, SUBHEADER_FILL)
    sub_row("New-Value subtotal", nv_rows, NV_FILL)

    total_sr = ws.max_row + 1
    ws.cell(row=total_sr, column=1, value="MVP TOTAL").font = BOLD_FONT
    for ci, col in enumerate([5, 6, 7], 6):
        total = sum(r[col] for r in rows)
        c = ws.cell(row=total_sr, column=ci, value=total)
        c.font = Font(name="Calibri", size=11, bold=True, color="1F3864")
        c.fill = PatternFill("solid", fgColor="D9E1F2")

    # NV coverage check
    nv_likely = sum(r[6] for r in nv_rows)
    parity_likely = sum(r[6] for r in parity_rows)
    coverage_pct = round(100 * nv_likely / (nv_likely + parity_likely), 1)
    cov_row = ws.max_row + 2
    ws.cell(row=cov_row, column=1, value="New-Value coverage check").font = BOLD_FONT
    ws.cell(row=cov_row, column=2, value=f"{nv_likely} / ({nv_likely}+{parity_likely}) = {coverage_pct}% (target ≥ 20%)").font = BOLD_FONT

    # ---- Sheet 3: P3 App Aggregates ----
    ws = wb.create_sheet("P3 App Aggregates")
    headers = ["Application", "Parity Best", "Parity Likely", "Parity Worst",
               "NV Best", "NV Likely", "NV Worst",
               "Total Best", "Total Likely", "Total Worst", "Notes"]
    rows = []
    for app in P3_APPS:
        name, pb, pl, pw, nb, nl, nw, notes = app
        rows.append([name, pb, pl, pw, nb, nl, nw, pb + nb, pl + nl, pw + nw, notes])
    write_table(ws, headers, rows)

    # totals
    sr = ws.max_row + 1
    ws.cell(row=sr, column=1, value="P3 TOTAL").font = BOLD_FONT
    for ci in range(2, 11):
        total = sum(r[ci - 1] for r in rows)
        c = ws.cell(row=sr, column=ci, value=total)
        c.font = BOLD_FONT
        c.fill = PatternFill("solid", fgColor="D9E1F2")

    # ---- Sheet 4: Phase Rollup ----
    ws = wb.create_sheet("Phase Rollup")
    headers = ["Phase", "Best (PD)", "Likely (PD)", "Worst (PD)", "Notes"]
    p2_best = sum(r[5] for r in rows[:0]) if False else sum(r[5] for r in [list(e) for e in MVP_EPICS])  # noqa
    # compute MVP totals
    mvp_best = sum(r[5] for r in [list(e) for e in MVP_EPICS])
    mvp_likely = sum(r[6] for r in [list(e) for e in MVP_EPICS])
    mvp_worst = sum(r[7] for r in [list(e) for e in MVP_EPICS])
    p3_best = sum(r[7] for r in rows)
    p3_likely = sum(r[8] for r in rows)
    p3_worst = sum(r[9] for r in rows)

    phase_data = [
        ["P0a Phase 0 Audit",       12,    15,    20,  "3-day audit; 1 lead BA + 1 principal eng + operator time"],
        ["P1 Detailed Design",      1100, 1400, 1800, "Drives all build estimates; gated by audit RAG"],
        ["P1a Foundational Tasks",  1400, 1800, 2400, "SecOps change-control SLA dominates"],
        ["P1b UDB→CIM POC",          450,  600,  900,  "Reconciliation harness underestimated commonly"],
        ["P2 MVP Build",            mvp_best, mvp_likely, mvp_worst, "From MVP Epic Catalog sheet"],
        ["P2a MVP UAT & Approval",   500,  700, 1100,  "Operator engagement-paced; full-time SMEs help"],
        ["P3 Incremental Build",    p3_best, p3_likely, p3_worst, "From P3 App Aggregates sheet"],
        ["P3a Full UAT",            1100, 1400, 1900, "Cross-app workflows; regulator dry-run"],
        ["P4 Cutover (6 events)",   1700, 2080, 2700, "Per-event ~280 PD × 6 + program-wide infra"],
        ["P5 Hypercare",             900, 1200, 1800, "Per-app + program-wide overlapping"],
    ]
    write_table(ws, headers, phase_data)

    # PROGRAM TOTAL
    tr = ws.max_row + 1
    ws.cell(row=tr, column=1, value="PROGRAM TOTAL").font = Font(name="Calibri", size=12, bold=True, color="1F3864")
    for ci in range(2, 5):
        total = sum(r[ci - 1] for r in phase_data)
        c = ws.cell(row=tr, column=ci, value=total)
        c.font = Font(name="Calibri", size=12, bold=True, color="1F3864")
        c.fill = PatternFill("solid", fgColor="D9E1F2")

    # ---- Sheet 5: Effective FTE check ----
    ws = wb.create_sheet("Effective FTE Cross-Check")
    headers = ["Phase", "Likely PD", "Effective FTE",
               "Working days/month", "Months pure work",
               "Schedule (months, includes overhead)"]
    rows = []
    nominal_fte_per_phase = {p: sum(r[i + 1] for r in ROLE_FTE) for i, p in enumerate(PHASES)}
    for i, p in enumerate(PHASES):
        likely_pd = phase_data[i][2]
        eff_fte = round(nominal_fte_per_phase[p] * EFFECTIVE_FTE_FACTOR[p], 2)
        if eff_fte > 0:
            pure_mo = round(likely_pd / eff_fte / 22, 2)
            sched_mo = PHASE_DURATION_MO[p]
        else:
            pure_mo = 0
            sched_mo = PHASE_DURATION_MO[p]
        rows.append([PHASE_LABELS[i], likely_pd, eff_fte, 22, pure_mo, sched_mo])
    write_table(ws, headers, rows)

    note_row = ws.max_row + 2
    ws.cell(row=note_row, column=1,
            value="Note: 'Schedule months' exceeds 'Pure months' due to ramp-up, sprint overhead, "
                  "external dependencies, and parallel-stream contention.").font = Font(italic=True, color="808080")
    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=6)

    # ---- Sheet 6: Scenarios ----
    ws = wb.create_sheet("Scenarios")
    headers = ["Scenario", "What it changes", "Program PD impact", "Schedule impact"]
    rows = [
        ["Base (Likely)", "All Epics at likely PD", "~23,400 PD", "~36 months"],
        ["Optimistic", "All Epics at best PD; reuse factor 60% in P3", "~17,000 PD", "~30 months"],
        ["Pessimistic", "All Epics at worst PD; reuse factor 25% in P3", "~33,000 PD", "~42 months"],
        ["Phase 0 Red dimensions", "+6 weeks remediation; P3 worst-case ×1.15", "+1,400 PD", "+1.5 months"],
        ["OpenRoad reader unfilled", "All Epics ×1.15; P3 worst-case ×1.25", "+3,500 PD", "+5 months"],
        ["MVP UAT operator pull-back", "P2a +30 PD; M-06 slips by 6 weeks", "+30 PD", "+1.5 months"],
        ["Pure big-bang cutover instead of staggered", "P4 −600 PD savings; cutover risk ×3; rollback prep ×1.5", "−400 PD net", "Variable; risk-driven"],
    ]
    write_table(ws, headers, rows)

    # ---- Sheet 7: Cost (placeholder) ----
    ws = wb.create_sheet("Cost (placeholder)")
    headers = ["Scenario", "Likely PD", "Indicative cost @ $1,000/PD blended", "Defensible range"]
    rows = [
        ["Base (Likely)", 23400, "$23.4M", "$17M – $33M"],
        ["Optimistic", 17000, "$17.0M", "—"],
        ["Pessimistic", 33000, "$33.0M", "—"],
    ]
    write_table(ws, headers, rows)
    note_row = ws.max_row + 2
    ws.cell(row=note_row, column=1,
            value="Placeholders. Sponsor populates Rate Card sheet in 13-resource-plan.xlsx with utility actuals."
            ).font = Font(italic=True, color="808080")
    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=4)

    out_path = OUT / "15-estimation-worksheet.xlsx"
    wb.save(out_path)
    print(f"  wrote {out_path.name}")


if __name__ == "__main__":
    print("Generating B4 deliverables...")
    build_resource_plan()
    build_estimation_worksheet()
    print("Done.")
