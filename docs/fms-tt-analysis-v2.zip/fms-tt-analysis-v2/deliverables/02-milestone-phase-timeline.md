# Milestone & Phase Timeline — Switching Order Modernization

**Artifact ID:** B1.2
**Format:** This file is the source-of-truth specification. The companion `.xlsx` (timeline grid) and `.docx` (narrative + brutal-honesty memo) are generated from it.

---

## 1. Indicative timeline — at a glance

Cutover strategy: **Option A** (staggered big-bang per application).
Indicative total: **30–42 months** from Phase 1 start to program-wide hypercare exit. No hard external deadline — internal milestone discipline must be manufactured by the program lead.

Best / Likely / Worst-case ranges below assume:
- Internal team of 15–20 .NET/Angular engineers + 2–4 architects (per A-001)
- At least one OpenRoad reader available within 4 weeks of P1 start (per A-002)
- 4–8 operator-hours/week per app + 1 dedicated UAT operator per app (per A-003)
- ~150K switching cards/year aggregate, 7-year retention (per A-005)
- All Discovery audit dimensions return Green or Amber (no Reds requiring re-discovery)

**If any of those assumptions invalidate, the worst-case column becomes the likely column.**

| Phase | ID | Best | Likely | Worst | Driver of variance |
|---|---|---|---|---|---|
| Phase 0 Audit | P0a | 3 days | 5 days | 10 days | Operator availability for 4GL spot-reads |
| Detailed Design | P1 | 3 mo | 4 mo | 5 mo | Discovery audit RAG; integration contract gaps; SME engagement |
| Foundational Tasks | P1a | 2 mo | 3 mo | 4 mo | SecOps change-control velocity for OpNET/DMZ/CorpNET; on-prem agent provisioning |
| UDB → CIM POC | P1b | 1.5 mo | 2 mo | 3 mo | UDB schema complexity; CIM coverage gaps; reconciliation tooling maturity |
| MVP Build (FMS) | P2 | 5 mo | 6.5 mo | 8 mo | Operator SME engagement depth; frontend complexity; EMS event-schema firmness |
| MVP UAT & Approval | P2a | 1.5 mo | 2 mo | 3 mo | Operator engagement depth; defect tail; mental-model parity issues surfaced |
| Incremental Build | P3 | 12 mo | 15 mo | 20 mo | Pattern reuse vs. app uniqueness; integration count per app; hidden 4GL rules |
| Full UAT | P3a | 2 mo | 3 mo | 4 mo | Cross-app workflow density; regulatory audit prep |
| Cutover (6 events, staggered) | P4 | 4 mo | 6 mo | 8 mo | Per-app rehearsal cycles; rollback events; soak duration between cutovers |
| Hypercare (overlapping) | P5 | 3 mo | 4 mo | 6 mo | Field defect volume; integration regression rate |

### Sequencing notes (overlap)

- **P1a (Foundational Tasks) overlaps the back third of P1 (Detailed Design).** Foundational work doesn't need final design — it needs target-architecture skeleton and identity model.
- **P1b (UDB → CIM POC) overlaps the front of P2 (MVP Build).** POC informs migration approach; MVP frontend can start before POC closes.
- **P5 (Hypercare) starts per-app at each cutover event** and runs in parallel with later cutovers.

So total elapsed program time is *less* than the sum of phase durations:

| Composite | Elapsed time |
|---|---|
| Best case (all overlap, no surprises) | **~30 months** |
| Likely case | **~36 months** |
| Worst case (Reds, hidden rules, vendor delays) | **~42 months** |

---

## 2. Phase-by-phase detail

### P0a — Phase 0 Discovery Audit (3–10 days)

**Purpose:** Stress-test Discovery outputs before Phase 1 design depends on them. See `00-phase0-discovery-audit-memo.md`.

**Entry criteria:** Discovery package available; audit team identified.

**Exit criteria:** RAG dashboard published; per-dimension decision recorded; Phase 1 plan adjusted for Amber dimensions or paused for Reds.

**Drivers of variance:** Operator availability for 4GL spot-reads; severity of Reds requiring partial re-discovery.

---

### P1 — Detailed Design (3–5 months)

**Purpose:** Convert Discovery outputs into design artifacts that estimation, build, and test can run against.

**Workstreams active:** All. Heaviest in Architecture (WS-ARC), Data (WS-DATA), Integration (WS-INT).

**Key outputs:**
- Domain models for all 6 cores (entities, aggregates, state machines for switching workflows)
- API contracts and event schemas (REST + asynchronous)
- Integration contracts for all 15–20 integrations (with EMS/XA21 and Rapid Restore prioritized)
- Non-functional requirements baseline (latency, audit, availability, security)
- Detailed boundary design across OpNET / DMZ / CorpNET
- Data migration approach (output of P1b POC feeds back into this)
- Test strategy outline

**Drivers of variance:**
- Discovery audit RAG outcome (Amber adds remediation epics; Red pauses parts of P1)
- Integration contract gaps (vendor-side delays for EMS/XA21 schemas)
- SME engagement depth (Operations + Security + Compliance must contribute, not observe)

**Critical risk:** Architectural decisions made now without 4GL code triangulation will be re-litigated during Build. Don't over-design where Discovery is shaky.

---

### P1a — Foundational Tasks (2–4 months, overlapping with late P1)

**Purpose:** Stand up the platform skeleton so Build can start without environment friction.

**Scope:**
- Dev / SIT / Pre-Prod / Prod environment topology across OpNET / DMZ / CorpNET
- On-prem Azure DevOps + on-prem Azure Repo
- CI/CD pipeline skeleton (build, unit test, security scan, deploy to IIS)
- CodeQL integration (or alternative — see B5 DevOps blueprint for recommended SAST stack)
- Identity & authorization framework (SSO, role model, audit logging)
- Database skeleton (SQL Server 2025 Enterprise, audit/temporal tables, partitioning scaffolding)
- Native SQL Server message broker setup (with custom modifications per stack)
- Frontend Angular skeleton + design-system foundation
- Backend .NET 8/9 skeleton + cross-cutting concerns (logging, telemetry, error contracts)
- Test platform (unit + contract + integration test harnesses)

**Drivers of variance:**
- SecOps change-control cycle time for OpNET/DMZ network rules
- On-prem Azure DevOps agent pool provisioning
- Identity vendor coordination (if AD/Entra hybrid)

**Critical risk:** Underestimating the network change-control latency. Plan for 2-week round-trip on every OpNET/DMZ rule change. Pre-stage approvals during P1.

---

### P1b — UDB → CIM Migration POC (1.5–3 months, overlapping with early P2)

**Purpose:** Prove the data-model conversion approach before the migration scope is sized.

**Why this is gated, not optional:**
The CIM (Common Information Model) is the target data model for utility hierarchy. UDB (legacy Ingres model) does not map cleanly to CIM. Without a POC, the migration estimate in B4 is fiction. With a POC, the team learns:

- Which UDB constructs require custom CIM extensions
- Reconciliation tolerance for floating-point and date-time semantics
- ETL throughput on production-volume samples
- Edge cases in feeder hierarchies that break naive mappings

**Scope:**
- Convert FMS feeder hierarchy from UDB to CIM (single app, full vertical slice)
- Build reconciliation harness comparing source vs. target row-by-row
- Document type mapping spec
- Document custom CIM extensions required

**Exit criteria (Milestone M-04):**
- Reconciliation report shows ≥99.9% row-level fidelity on FMS sample
- Type mapping spec covers all observed UDB types
- Throughput projection viable for full data volume

**Drivers of variance:**
- UDB schema complexity (especially around DSO and SDS, which use heavier extensions)
- CIM 17 coverage of dielectric and steam constructs
- Reconciliation tooling maturity

---

### P2 — MVP Build (5–8 months)

**Purpose:** Deliver the first vertical slice — FMS — to operator-facing UAT.

**Why FMS first (proposed):**
- Highest operational volume of the 6 cores → richest test of workflow patterns
- Mature internal documentation
- Patterns established here are reused for TOMS, DSO, TLS, SDS, DBM
- Operator pool is largest, supporting parallel UAT cohorts

**MVP scope (story slicing per Section 7 of original prompt):**
Each story is a vertical slice through the workflow:
1. **Notify** — receive EMS event, validate, persist
2. **Create Card** — auto-create switching card; operator review/edit
3. **De-energize** — operator orchestrates de-energization steps; tag and isolate
4. **Authorize** — issue authorization; track approvals
5. **Execute** — coordinate field crew via Rapid Restore handoff; track execution
6. **Test** — verify de-energized state; record test results
7. **Re-energize** — coordinate restore; issue breaker-close to EMS
8. **Close** — close card; audit trail finalized; reports

Each step is a vertical slice through frontend + backend + DB + integration. Each is independently demo-able. None is "done" until operator-validated.

**Drivers of variance:**
- Operator SME engagement depth (4 hrs/wk vs. 8 hrs/wk doubles design throughput)
- Frontend complexity (operator console mental-model parity is non-negotiable)
- EMS/XA21 event-schema firmness
- Hidden business rules surfacing during build

**Critical risk:** Compromising on operator mental-model parity to hit a date. M-06 won't pass; you'll lose 2 months and credibility recovering.

---

### P2a — MVP UAT & Approval (1.5–3 months) — **HARDEST GATE**

**Purpose:** Operator panel signs off that FMS modernization preserves their workflow and adds tangible value.

**Why this is the program's hardest gate:**
- Three non-negotiables from sponsor brief: feature parity, tangible new value, MVP approval
- Operators are deeply satisfied with current workflow → high parity bar
- "Tangible new value" must be demonstrable in MVP, not promised for Phase 3
- Failure here means scope expansion stops; program is paused or re-scoped

**Activities:**
- Operator-in-the-loop UAT cycles (2-week iterations)
- Mental-model audit (do screen flows match operator expectations without re-training?)
- Defect triage with operator-facing severity (operator confusion is severity 1)
- Tangible-value demo (concrete features added beyond parity — to be defined in P1)
- Sign-off panel: operators from each district + Operations Lead + Sponsor

**Drivers of variance:**
- Operator engagement depth (less = more cycles)
- Defect volume from hidden rules
- Mental-model gaps surfaced in UAT (each gap is a re-design, not a tweak)

**Decision criteria (Milestone M-06):**
- Operator panel signs off (yes/no per panel member; majority not enough — need consensus or escalation)
- All severity-1 defects closed
- Tangible new-value features demonstrated and operator-validated
- Audit trail completeness verified by Compliance

---

### P3 — Incremental Build (12–20 months)

**Purpose:** Deliver remaining 5 core applications (TOMS, DSO, TLS, SDS, DBM) plus the 30–35 monitor applications.

**Sequencing (proposed):**

| Order | App | Rationale |
|---|---|---|
| 1 | TOMS | Highest pattern reuse from FMS; transmission workflow shares structure with distribution |
| 2 | DBM | Foundational data model; should land before remaining apps depend on shared hierarchy |
| 3 | DSO | Dielectric — moderate uniqueness; benefits from TOMS patterns |
| 4 | SDS | Steam — high uniqueness; some patterns from DSO; specialized operator pool |
| 5 | TLS | Telephonic line — narrowest scope; benefits from all prior infra investment |

Monitors are built alongside their parent app (e.g., FMS monitors during TOMS build window — FMS team has capacity after MVP).

**Drivers of variance (most sensitive phase):**
- Pattern reuse rate (best case: 60–70% reuse from FMS; worst case: 30%)
- Hidden 4GL rules per app
- Integration count per app (TLS has many; DBM has few)
- Cross-app dependencies surfacing
- Team velocity stability after MVP

**Critical risk:** "MVP velocity" is not a stable predictor for incremental velocity. Operators are fully bought-in by M-06; they expect the rest to be fast. Manage that expectation explicitly with a mid-point review (M-07).

---

### P3a — Full UAT (2–4 months)

**Purpose:** Validate cross-app workflows that don't exist within a single core.

**Scope:**
- Cross-app workflows (e.g., a transmission outage that cascades into distribution feeder management — TOMS + FMS interaction)
- Cross-system regression with all integrations
- Performance under combined load
- Disaster-recovery / islanding drill on standby OpNET environment
- Regulatory audit dry-run

**Drivers of variance:** Cross-app workflow density; regulator engagement timing.

---

### P4 — Cutover (4–8 months total, 6 staggered events)

**Purpose:** Migrate each application to production sequentially per Option A.

**Per-app cutover pattern (4–8 weeks each):**

| Week | Activity |
|---|---|
| -4 | Cutover dress rehearsal #1 (full failover path, simulated load) |
| -3 | Dry-run + go/no-go review |
| -2 | Dress rehearsal #2 (issues from #1 fixed) |
| -1 | Final go/no-go; freeze; rehearsal #3 |
| 0 | **Cutover weekend** |
| +1 | Stabilization week (live with elevated on-call) |
| +2 to +4 | Soak period; legacy hot-standby retained on OpNET |

**Cutover order (matches build order):**
1. FMS (the heaviest, the one you've validated since MVP)
2. TOMS
3. DBM
4. DSO
5. SDS
6. TLS

**Drivers of variance:**
- Rehearsal cycle results (a failed rehearsal restarts the cycle)
- Soak duration before next cutover (4 weeks minimum recommended)
- Defect volume in early cutovers (informs later cutover budget)

**Critical risk:** Compressing soak period between cutovers because earlier cutovers went well. Staggering exists to absorb surprises; eliminating soak eliminates the safety margin.

---

### P5 — Hypercare (3–6 months, overlapping)

**Purpose:** Heightened-support window per app + program-wide.

**Per-app hypercare:** Starts at each app's cutover, runs 4–8 weeks.

**Program-wide hypercare:** Starts at last cutover, runs 3 months.

**Exit criteria (Milestone M-11):**
- Defect rate ≤ steady-state threshold for 30 consecutive days
- All P1 severity defects closed
- Operations team formally accepts service ownership

---

## 3. Brutal-honesty memo — where these estimates are most likely to be wrong

This section becomes the appendix of the `.docx` deliverable.

### Most-likely overrun zones, ranked

1. **Incremental Build (P3).** Largest hours; broadest scope; highest exposure to hidden 4GL rules. Single biggest single risk to the program's likely-case duration. Pattern reuse rate from MVP is overestimated by every team that's done this. **Plan for 30% reuse, not 60%.**
2. **MVP UAT (P2a).** Operator validation is process-heavy. Defect tail is long. Mental-model gaps surface late. If MVP UAT slips past 3 months, the program has an operator-engagement problem, not an engineering problem.
3. **Cutover (P4).** Rehearsal cycles compound. Each rehearsal that fails resets a 4-week window. Six cutovers means six chances to consume budget.
4. **Foundational (P1a).** Network change-control is the silent killer. SecOps round-trip dominates. Plan 2-week SLA per network rule change.
5. **POC (P1b).** Reconciliation harness scope is consistently underestimated. Building the diff tool is half the POC.

### Why these estimates *cannot* be tighter than ranges

- We have no body-of-work history for this team on this stack
- Discovery shakiness (pending P0a outcome) feeds straight into estimate confidence
- 4GL hidden rules are unknowable until measured
- Vendor coordination (EMS/XA21) is not under direct program control
- Operator availability is forecast, not contracted

Anyone giving you a single-point estimate at this stage is selling, not estimating.

### What reduces variance

In priority order:
1. **Run the Phase 0 audit.** Largest single variance reducer.
2. **Lock cutover decision (Option A) and don't relitigate.** Re-baselining late is expensive.
3. **Identify the OpenRoad reader within 4 weeks of P1 start.** Without one, every estimate has a phantom +20%.
4. **Pre-stage SecOps approvals during P1.** Saves 4–8 weeks across P1a/P1b.
5. **Dedicate operator SMEs for MVP UAT, not borrow them.** Halves UAT cycle count.
6. **Anchor sponsor on a dollar-and-time range from B4 estimation worksheet, with the assumption that the worst-case column is the working-case until proven otherwise.**

### Where I will refuse to pad

- Per-app cutover soak period (4 weeks minimum). Compressing this is the cheapest decision and the most expensive consequence.
- Phase 0 audit duration (3 days). One day is theater.
- Operator SME hours per week (4 hrs minimum). Less, and MVP UAT cycle count doubles.
- Number of dress rehearsals per cutover (3 minimum). Two means an unrehearsed failure mode goes to production.

### Where I am willing to compress (with named trade-offs)

- **Detailed Design (P1)** can compress from 4 to 3 months by deferring NFR baselining to early P2. Trade-off: NFRs surface as defects, not requirements.
- **Foundational Tasks (P1a)** can compress by 1 month by reusing an existing internal CI/CD template (if one exists). Trade-off: locks you into prior tooling decisions.
- **Hypercare (P5)** program-wide can compress from 4 to 3 months if defect rate trends consistently below threshold. Trade-off: less buffer for late-surfacing regressions.

---

## 4. Open questions for sponsor before B1 ratification

These do not block production of B1; they block *commitment* to B1 numbers.

1. Confirm proposed first-MVP application: **FMS**.
2. Confirm proposed incremental build sequence: TOMS → DBM → DSO → SDS → TLS.
3. Confirm operator SME availability assumption (A-003): 4–8 hrs/wk per app + 1 dedicated UAT operator per app.
4. Confirm OpenRoad reader plan (A-002): identify internal candidate or contractor within 4 weeks of P1 start.
5. Confirm "tangible new value" features for MVP that go beyond parity. (This must be defined in P1; without it, M-06 has no demonstrable criterion for value.)
6. Confirm regulatory/audit stakeholder attendance at M-06 and M-09.
