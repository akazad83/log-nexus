"""
Generator for B6 deliverable: Materials & Templates Catalog.

Produces:
  - 21-materials-catalog.xlsx  (multi-sheet workbook)

Run from this directory: python _generate_b6.py
"""

from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

OUT = Path(__file__).parent

# ---- styling (matches sister generators) -----------------------------------

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
SUBHEADER_FILL = PatternFill("solid", fgColor="D9E1F2")
SUBHEADER_FONT = Font(name="Calibri", size=11, bold=True, color="1F3864")
BODY_FONT = Font(name="Calibri", size=10)
BOLD_FONT = Font(name="Calibri", size=10, bold=True)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CATEGORY_FILLS = {
    "Memo": PatternFill("solid", fgColor="FFE5B4"),
    "Planning": PatternFill("solid", fgColor="D6E5FF"),
    "Architecture": PatternFill("solid", fgColor="DEEBF7"),
    "Backlog Engineering": PatternFill("solid", fgColor="E8F0E8"),
    "Resource & Estimation": PatternFill("solid", fgColor="FFF2CC"),
    "Engineering Depth": PatternFill("solid", fgColor="F4CCCC"),
    "Tooling": PatternFill("solid", fgColor="EAEAEA"),
    "Index": PatternFill("solid", fgColor="D0E0E3"),
}

STATUS_FILLS = {
    "Draft": PatternFill("solid", fgColor="FFEB9C"),
    "Reviewed": PatternFill("solid", fgColor="D9E1F2"),
    "Approved": PatternFill("solid", fgColor="C6EFCE"),
    "Authoritative": PatternFill("solid", fgColor="C6EFCE"),
    "Outline": PatternFill("solid", fgColor="FCE4D6"),
    "Working": PatternFill("solid", fgColor="C6EFCE"),
    "Final": PatternFill("solid", fgColor="C6EFCE"),
}


def style_header_row(ws, row=1, ncols=None):
    if ncols is None:
        ncols = ws.max_column
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 30
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def autosize_columns(ws, min_width=10, max_width=50):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        longest = 0
        for cell in col:
            v = cell.value
            if v is None:
                continue
            for line in str(v).splitlines():
                longest = max(longest, len(line))
        ws.column_dimensions[letter].width = max(min_width, min(max_width, longest + 2))


def write_table(ws, headers, rows, start_row=1):
    for c, h in enumerate(headers, 1):
        ws.cell(row=start_row, column=c, value=h)
    style_header_row(ws, row=start_row, ncols=len(headers))
    for r, row in enumerate(rows, start_row + 1):
        for c, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=c, value=val)
            cell.font = BODY_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = BORDER
    autosize_columns(ws)


# ---- catalog data ---------------------------------------------------------

# Each row: ID, Title, Category, Formats, Filename(s), Purpose, Owner role,
#           Audience, Stage of use, Status, Re-baseline cadence
CATALOG = [
    # Memo
    ("00", "Phase 0 Discovery Audit Memo", "Memo", ".md",
     "00-phase0-discovery-audit-memo.md",
     "Stress-test Discovery outputs (600+ features, 650+ FRs, 1000+ rules) before Phase 1 begins. 3-day audit, 10 RAG dimensions, decision matrix.",
     "Program Lead",
     "Sponsor, Program Lead, Delivery Lead",
     "Pre-P1 → P0a",
     "Approved (D-002)",
     "Static once executed"),

    # Planning
    ("01", "Master Project Plan Template", "Planning", ".md, .xlsx",
     "01-master-project-plan-template.md / .xlsx",
     "10-sheet PMO workbook: Cover, Phases, Workstreams, Master Schedule (full 442-row WBS: 10 phase summaries + 79 area summaries + 342 work packages + 11 milestones), Milestones & Gates, RACI, Risk Register, Assumption Log, Issue Log, Decision Log.",
     "Program Lead",
     "PMO, all Leads, Sponsor",
     "All phases (live PMO doc)",
     "Draft",
     "Continuous"),
    ("02", "Milestone & Phase Timeline", "Planning", ".md, .xlsx, .docx",
     "02-milestone-phase-timeline.md / .xlsx / .docx",
     "Indicative 30–42 month timeline; phase-by-phase narrative; brutal-honesty appendix. Best/Likely/Worst per phase.",
     "Program Lead",
     "Sponsor, Steering Committee, all Leads",
     "Pre-P1 (sign-off) and per gate review",
     "Draft",
     "Per phase gate"),

    # Architecture
    ("03", "Technical Architecture Outline", "Architecture", ".md (Mermaid)",
     "03-technical-architecture-outline.md",
     "14 sections, 4 Mermaid diagrams. Service inventory, layer model, EMS boundary detail, Rapid Restore boundary, standby/islanding, data flow scenarios.",
     "Solution Architect",
     "Architecture Council, Engineering Leads, Security",
     "P1 (detailed-design input)",
     "Draft",
     "M-02 detailed-design lock"),
    ("04", "Network & Boundary Design", "Architecture", ".md (Mermaid)",
     "04-network-boundary-design.md",
     "Zone topology, cross-zone protocol matrix, auth/encryption rules, failure modes, network change-control SLA.",
     "Solution Architect + Security Lead",
     "SecOps, Network Engineering, Architecture Council",
     "P1 (SecOps approval gate)",
     "Draft",
     "M-02 detailed-design lock"),

    # Backlog Engineering
    ("05", "Backlog Engineering Pipeline Guide", "Backlog Engineering", ".md, .docx",
     "05-backlog-pipeline-guide.md / .docx",
     "Translation rules Feature→Epic→Story→AC→Task. DoR (24 items). DoD (parity-aware). 9 story-splitting heuristics for switching workflows. 4 audit AC patterns. 20% new-value enforcement.",
     "BA Lead + PO",
     "PO, BA Lead, Scrum Masters, Engineering Leads, Test Lead",
     "P1 onwards",
     "Authoritative",
     "Annual review"),
    ("06", "Epic Template", "Backlog Engineering", ".md",
     "06-epic-template.md",
     "Epic structure with worked example for FMS-E-014.",
     "BA Lead",
     "PO, BA, Service teams",
     "P1 onwards",
     "Authoritative",
     "As-needed"),
    ("07", "User Story Template", "Backlog Engineering", ".md",
     "07-user-story-template.md",
     "Story structure with INVEST checklist + vertical-slice anatomy.",
     "BA Lead",
     "PO, BA, Service teams",
     "P1 onwards",
     "Authoritative",
     "As-needed"),
    ("08", "Acceptance Criteria Template", "Backlog Engineering", ".md",
     "08-acceptance-criteria-template.md",
     "Gherkin AC patterns (7 categories) + NFR addendum. [REG] tagging. Worked example.",
     "BA Lead + Test Lead",
     "BA, Test, Service teams",
     "P1 onwards",
     "Authoritative",
     "As-needed"),
    ("09", "Spike Template", "Backlog Engineering", ".md",
     "09-spike-template.md",
     "Time-boxed investigation pattern. Worked example for SP-018 (EMS event schema).",
     "Engineering Lead",
     "Engineering, BA",
     "P1 onwards",
     "Authoritative",
     "As-needed"),
    ("10", "Task Template", "Backlog Engineering", ".md",
     "10-task-template.md",
     "Engineer-day units with task-level DoD.",
     "Engineering Lead",
     "Engineers",
     "P1 onwards",
     "Authoritative",
     "As-needed"),
    ("11", "Bug Template", "Backlog Engineering", ".md",
     "11-bug-template.md",
     "Operator-impact-aware severity scale (operator confusion = S1). RCA fields. Audit/safety implication review.",
     "Test Lead",
     "Test, Service teams, Compliance",
     "P1 onwards (especially P2a, P3a, P5)",
     "Authoritative",
     "As-needed"),
    ("12", "NFR Template", "Backlog Engineering", ".md",
     "12-nfr-template.md",
     "Cross-cutting NFR template. Worked example for NFR-AUD-001 (audit log tamper-evidence).",
     "Security Lead + Test Lead",
     "Security, Test, Service teams",
     "P1 onwards",
     "Authoritative",
     "As-needed"),

    # Resource & Estimation
    ("13", "Resource Plan", "Resource & Estimation", ".md, .xlsx",
     "13-resource-plan.md / .xlsx",
     "27-role inventory, FTE ramp by phase, effective-FTE adjustments, skills matrix, key-person risks, hiring plan, configurable rate card. Peak ~60 FTE in P3.",
     "Program Lead",
     "Sponsor, HR, Engineering Leads",
     "Pre-P1 onwards (live)",
     "Draft",
     "Per phase gate"),
    ("14", "Resource Plan Brutal-Honesty Memo", "Resource & Estimation", ".md, .docx",
     "14-resource-plan-brutal-honesty-memo.md / .docx",
     "12-section memo on where estimates are most likely wrong, what reduces variance, what I refuse to compress, what I might be wrong about myself.",
     "Program Lead",
     "Sponsor, Steering Committee, Program Lead",
     "Pre-P1 (sponsor sign-off) and per estimate revision",
     "Draft",
     "Each major estimate revision"),
    ("15", "Estimation Worksheet", "Resource & Estimation", ".md, .xlsx",
     "15-estimation-worksheet.md / .xlsx",
     "Three-point estimates (Best/Likely/Worst) per Epic. MVP catalog (22 Epics). P3 per-app aggregates. Phase rollup. ~23,400 PD likely with $17M–$33M defensible range.",
     "Engineering Lead",
     "Sponsor, Program Lead, Engineering Leads, PMO",
     "Pre-P1 onwards",
     "Draft",
     "M-02 / M-04 / M-05 / M-07 / M-09"),

    # Engineering Depth
    ("16", "Database Design Principles", "Engineering Depth", ".md",
     "16-database-design-principles.md",
     "Schema-per-service, audit/temporal strategy, partitioning + retention, indexing discipline, AG topology, migration discipline.",
     "Data Architect",
     "Data Architecture, DB Engineers, Backend Lead, Security",
     "P1 onwards",
     "Draft",
     "M-02 detailed-design lock"),
    ("17", "Data Migration Strategy", "Engineering Depth", ".md, .docx",
     "17-data-migration-strategy.md / .docx",
     "UDB→CIM conversion approach. ETL pattern. 3-layer reconciliation. Audit data continuity. Per-app cutover sequencing. Fallback authority by phase.",
     "Data Architect",
     "Data Architecture, DB Engineers, Integration Lead, Compliance",
     "P1 onwards (P1b POC critical)",
     "Draft",
     "M-04 (P1b POC outcome)"),
    ("18", "DevOps / CI-CD Blueprint", "Engineering Depth", ".md",
     "18-devops-cicd-blueprint.md",
     "Tooling decisions, repo structure, branching, CI/CD pipelines, environment topology, cross-zone deployment workflow, secrets, rollback.",
     "DevOps Lead",
     "DevOps, Engineering Leads, SecOps, Security Lead",
     "P1 → P1a primarily",
     "Draft",
     "M-03 platform-live lock"),
    ("19", "Test Strategy", "Engineering Depth", ".md, .docx",
     "19-test-strategy.md / .docx",
     "Test pyramid + every test layer. Operator-in-the-loop methodology. UAT M-06 criteria. Parity test harness. Resilience/chaos. Audit/regulatory testing.",
     "Test Lead",
     "Test, Engineering Leads, Operations, Security, Compliance",
     "P1 onwards",
     "Draft",
     "Per release; M-08 lock for full UAT"),
    ("20", "Cutover Playbook Outline", "Engineering Depth", ".md",
     "20-cutover-playbook-outline.md",
     "4-week cutover window structure. DR1/DR2/DR3 gate authorities. Hour-by-hour cutover-weekend sequence. Inter-cutover learning loop.",
     "Operations Lead",
     "Operations, Service Manager, DevOps, Data Architect, Operator panel, CIO",
     "P3a → P4 primarily",
     "Outline (full runbook P4)",
     "Per cutover event"),

    # Tooling
    ("T-1", "_generate.py", "Tooling", ".py",
     "_generate.py",
     "Generates B1 binary artifacts from markdown sources (master plan xlsx, milestone timeline xlsx + docx).",
     "DevOps Lead",
     "PMO, DevOps",
     "Maintenance",
     "Working",
     "As-needed"),
    ("T-2", "_generate_b4.py", "Tooling", ".py",
     "_generate_b4.py",
     "Generates B4 binary artifacts (resource plan xlsx, estimation worksheet xlsx).",
     "DevOps Lead",
     "PMO, DevOps",
     "Maintenance",
     "Working",
     "As-needed"),
    ("T-3", "_md_to_docx.py", "Tooling", ".py",
     "_md_to_docx.py",
     "Focused markdown→docx converter for the patterns used in this folder.",
     "DevOps Lead",
     "DevOps, anyone producing markdown that needs Word distribution",
     "Reusable",
     "Working",
     "As-needed"),
    ("T-4", "_generate_b6.py", "Tooling", ".py",
     "_generate_b6.py",
     "Generates this catalog (.xlsx) from canonical row data. Update when new artifacts are produced.",
     "DevOps Lead",
     "PMO, DevOps",
     "Maintenance",
     "Working",
     "As-needed"),

    # Index
    ("21", "Materials & Templates Catalog", "Index", ".md, .xlsx",
     "21-materials-catalog.md / .xlsx",
     "This catalog. Index of every artifact with purpose, owner, stage of use, cross-references, and forthcoming items.",
     "Program Lead",
     "Sponsor, PMO, all Leads, new joiners",
     "All phases",
     "Final",
     "When new artifacts produced"),
]


# By Stage data
BY_STAGE = [
    ("Pre-P1 (sponsor sign-off)", "00, 02, 14, 15, 21"),
    ("P0a Phase 0 Audit", "00 (executes), 21 (RAG output added)"),
    ("P1 Detailed Design", "03 → detailed design; 04 → SecOps approval; 16 → per-service DB design; 13 → hiring; 15 → re-baseline at M-02; 05–12 → first refinement sessions; 17 → P1b POC plan; 18 → P1a kickoff; 19 → test platform planning"),
    ("P1a Foundational", "18 → CI/CD build; 16 → schema scaffolding; 13 → ramp-up; 19 → test platform stand-up"),
    ("P1b UDB→CIM POC", "17 → POC execution; 16 → CIM schema; 19 → reconciliation harness build"),
    ("P2 MVP Build", "05–12 → every story; 03 → reference; 16, 18, 19 → engineering reference; 15 → M-05 re-baseline"),
    ("P2a MVP UAT", "19 → UAT execution; 11 → defect lifecycle; 14 → expectation calibration; 01 → M-06 gate"),
    ("P3 Incremental Build", "All B3 templates; 15 → M-07 mid-point; 17 → per-app; 19 → ongoing"),
    ("P3a Full UAT", "19 → cross-app UAT; 11 → bugs; 17 → regulator dry-run"),
    ("P4 Cutover", "20 → per-app runbook; 17 → per-app execution; 19 → cutover testing"),
    ("P5 Hypercare", "11 → bugs; 19 → regression; 01 → M-11 exit"),
    ("All phases", "01 master plan; 21 catalog"),
]


# Forthcoming (post-Phase-1-planning)
FORTHCOMING = [
    # P0a outputs
    ("P0a", "Phase 0 audit RAG dashboard", "00 §6", "Program Lead"),
    ("P0a", "Phase 0 audit recommendation memo", "00 §6", "Program Lead"),
    # P1
    ("P1", "Per-service domain models", "03 §13", "Domain Architects"),
    ("P1", "API contract specifications (OpenAPI per service)", "03", "Backend Lead per service"),
    ("P1", "Async event schemas", "03 §5.1", "Integration Lead"),
    ("P1", "Integration contracts (15+ external)", "03 §5.2; 04 §5.4", "Integration Lead"),
    ("P1", "Threat models per service (STRIDE)", "03 §4.4; 19 §10.4", "Security Lead"),
    ("P1", "Architecture Decision Records (ADRs)", "implicit in 03, 16, 18", "Solution Architect"),
    ("P1", "Per-service NFR definitions", "12 + 03", "Each service team"),
    ("P1", "Identity flow diagrams", "03 §4.1", "Security Lead"),
    ("P1", "Detailed sequence diagrams per workflow", "03 §8", "Domain Architects"),
    ("P1", "Boundary firewall rule list", "04 §10", "DevOps + SecOps"),
    ("P1", "IP addressing scheme per zone", "04 §10", "Network team"),
    # P1a
    ("P1a", "Azure DevOps YAML pipelines", "18 §20", "DevOps Lead"),
    ("P1a", "Per-service repo scaffolding", "18 §3", "DevOps Lead"),
    ("P1a", "Vault path structure (production)", "18 §9.2", "Security Lead + DevOps Lead"),
    ("P1a", "Pipeline agent provisioning runbooks", "18 §16", "DevOps Lead"),
    ("P1a", "Identity & RBAC configuration", "03 §4.1", "Security Lead"),
    ("P1a", "SQL Server schema scaffolding (per service)", "16 §3", "Data Architect"),
    ("P1a", "Audit & temporal foundational implementation (FOUND-S-022)", "16 §9; 12", "Data Architect + Security"),
    ("P1a", "Observability stack deployment", "03 §4.2", "DevOps Lead"),
    # P1b
    ("P1b", "UDB→CIM type mapping specification", "17 §4.3", "Data Architect"),
    ("P1b", "CIM extension catalog", "17 §4.3", "Data Architect"),
    ("P1b", "Reconciliation harness (reusable)", "17 §6", "Data engineers"),
    ("P1b", "Profiling report (Ingres source)", "17 §2.3", "Data engineers"),
    ("P1b", "Failure-mode catalog (UDB constructs that don't map)", "17 §4.3", "Data Architect"),
    ("P1b", "ETL throughput projection", "17 §4.3", "Data engineers"),
    # P2/P3
    ("P2/P3", "Per-service runbooks", "03 §11; 18", "Service Manager + service team"),
    ("P2/P3", "Per-service operations dashboards", "03 §4.2", "Service Manager + service team"),
    ("P2/P3", "Operator parity capture corpus", "19 §8", "QA + Operator panel"),
    ("P2/P3", "Recorded sprint demos with operator commentary", "19 §5.4", "Test Lead + Operator panel"),
    ("P2/P3", "Operator co-design session recordings", "19 §5.4", "Operator panel + UX"),
    ("P2/P3", "Defect tail reports per release", "19 §16", "Test Lead"),
    # P3a/P4
    ("P3a/P4", "Cross-app workflow test suite", "19 §6.2", "QA engineers"),
    ("P3a/P4", "Disaster-recovery / islanding drill report", "19 §12", "DevOps + Operations"),
    ("P3a/P4", "Regulator audit dry-run packet", "19 §13.4", "Compliance"),
    ("P3a/P4", "Per-app cutover runbook (full, 50–80 pages)", "20 outline", "Operations Lead per app"),
    ("P3a/P4", "Per-app dress rehearsal results (DR1, DR2, DR3)", "20 §3–6", "Operations Lead per app"),
    ("P3a/P4", "Cutover-weekend war-room comms plan (per app)", "20 §11.2", "Communications Lead"),
    # P5
    ("P5", "Hypercare exit memo (per app + program-wide)", "20 §10", "Service Manager"),
    ("P5", "Compliance audit packet (regulator-facing)", "19 §13", "Compliance"),
    ("P5", "Inter-cutover lessons log", "20 §15", "Operations Lead"),
    ("P5", "Operations service-ownership acceptance", "20 §10.2", "Service Manager"),
]


# Owners — by role
BY_OWNER = [
    ("Sponsor", "Approval authority (D-001, D-002, D-003); M-06 sign-off", ""),
    ("Program Lead", "00, 01, 02, 13, 14, 21", "All gates; lessons log"),
    ("Solution Architect", "03, 04 (co)", "ADRs; per-service architecture reviews"),
    ("Domain Architects", "(consume 03)", "Per-service domain models; sequence diagrams"),
    ("Backend Lead", "(consume 16, 18, 19)", "Per-service API contracts"),
    ("Frontend Lead", "(consume 03, 19)", "Operator console parity validation"),
    ("Data Architect", "16, 17", "UDB→CIM type mapping; CIM extensions; reconciliation harness"),
    ("Integration Lead", "(consume 03, 04, 17, 18)", "EMS endpoint contract; integration contracts (15+)"),
    ("DevOps Lead", "18 + tooling", "YAML pipelines; Vault paths; runbooks"),
    ("Test Lead", "19, 11", "Test platform; parity harness; UAT cycles"),
    ("Security Lead", "04 (co), 12", "Threat models; vault access policies; cert lifecycle"),
    ("Operations Lead", "20", "Per-app cutover runbooks; cutover decisions"),
    ("Service Manager", "(consume 18, 20)", "Per-service runbooks; hypercare"),
    ("Change Lead", "(consume 19)", "Operator engagement plans"),
    ("BA Lead", "05–12", "First refinement sessions; DoR enforcement"),
    ("Compliance officer", "(consume 16, 17, 19)", "Regulator engagement; audit packets"),
]


def build_catalog():
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Cover ----
    ws = wb.create_sheet("Cover")
    ws["A1"] = "Materials & Templates Catalog"
    ws["A1"].font = Font(name="Calibri", size=18, bold=True, color="1F3864")
    ws.merge_cells("A1:F1")
    ws["A2"] = "Switching Order Modernization — Phase 1 Planning Index"
    ws["A2"].font = Font(name="Calibri", size=12, italic=True, color="808080")
    ws.merge_cells("A2:F2")

    info = [
        ("Artifact ID", "B6.13"),
        ("Status", "Final"),
        ("Companion .md", "21-materials-catalog.md"),
        ("Total artifacts", "22 deliverables + 4 tooling scripts"),
        ("Format inventory", ".md (22), .xlsx (5), .docx (5), .py (4)"),
    ]
    for i, (k, v) in enumerate(info, 4):
        ws.cell(row=i, column=1, value=k).font = BOLD_FONT
        ws.cell(row=i, column=2, value=v).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)

    ws["A11"] = "Workbook contents"
    ws["A11"].font = SUBHEADER_FONT
    ws["A11"].fill = SUBHEADER_FILL
    ws.merge_cells("A11:F11")
    sheets_info = [
        ("Cover", "Document control + this contents listing"),
        ("Catalog", "Main index of every artifact with metadata"),
        ("By Category", "Catalog grouped by category with counts"),
        ("By Stage", "What's used at each program phase"),
        ("Forthcoming", "Artifacts expected later in the program"),
        ("Owners", "Roles and what each owns"),
        ("Format Inventory", "Roll-up of formats produced"),
        ("Status Legend", "Status definitions"),
    ]
    for i, (s, p) in enumerate(sheets_info, 12):
        ws.cell(row=i, column=1, value=s).font = BOLD_FONT
        ws.cell(row=i, column=2, value=p).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)

    ws["A22"] = "The one-paragraph summary"
    ws["A22"].font = SUBHEADER_FONT
    ws["A22"].fill = SUBHEADER_FILL
    ws.merge_cells("A22:F22")
    summary = (
        "The program is feasible in 30–42 months with an internal team peaking at ~60 FTE, delivered as 6 staggered "
        "cutovers with FMS first as a partial-MVP. The variance bands are real, dominated by hidden 4GL rules and "
        "pattern-reuse rate from MVP to incremental build. The single most cost-effective risk-reduction action is "
        "the 3-day Phase 0 audit. The single most consequential decision still pending is whether the sponsor's "
        "stated bench (15–20 .NET/Angular engineers) is total program staff or just engineers — those are very "
        "different programs. Run the audit. Confirm the headcount. Then proceed."
    )
    cell = ws.cell(row=23, column=1, value=summary)
    cell.font = BODY_FONT
    cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.merge_cells(start_row=23, start_column=1, end_row=27, end_column=6)
    ws.row_dimensions[23].height = 90

    ws.column_dimensions["A"].width = 25
    ws.column_dimensions["B"].width = 60

    # ---- Catalog (main sheet) ----
    ws = wb.create_sheet("Catalog")
    headers = ["ID", "Title", "Category", "Formats", "Filename(s)",
               "Purpose", "Owner Role", "Audience", "Stage of Use",
               "Status", "Re-baseline Cadence"]
    rows = [list(r) for r in CATALOG]
    write_table(ws, headers, rows)

    # color rows by category
    for ri in range(2, 2 + len(rows)):
        category = ws.cell(row=ri, column=3).value
        if category in CATEGORY_FILLS:
            ws.cell(row=ri, column=3).fill = CATEGORY_FILLS[category]
            ws.cell(row=ri, column=3).font = BOLD_FONT
        # color status
        status = ws.cell(row=ri, column=10).value
        if status in STATUS_FILLS:
            ws.cell(row=ri, column=10).fill = STATUS_FILLS[status]
            ws.cell(row=ri, column=10).font = BOLD_FONT

    # tighten column widths
    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 36
    ws.column_dimensions["C"].width = 22
    ws.column_dimensions["D"].width = 18
    ws.column_dimensions["E"].width = 36
    ws.column_dimensions["F"].width = 50
    ws.column_dimensions["G"].width = 22
    ws.column_dimensions["H"].width = 32
    ws.column_dimensions["I"].width = 28
    ws.column_dimensions["J"].width = 14
    ws.column_dimensions["K"].width = 24

    # ---- By Category ----
    ws = wb.create_sheet("By Category")
    headers = ["Category", "Artifact Count", "Artifact IDs"]
    rows = []
    cats = {}
    for r in CATALOG:
        cats.setdefault(r[2], []).append(r[0])
    for cat, ids in cats.items():
        rows.append([cat, len(ids), ", ".join(ids)])
    write_table(ws, headers, rows)
    for ri in range(2, 2 + len(rows)):
        cat = ws.cell(row=ri, column=1).value
        if cat in CATEGORY_FILLS:
            ws.cell(row=ri, column=1).fill = CATEGORY_FILLS[cat]
            ws.cell(row=ri, column=1).font = BOLD_FONT

    # ---- By Stage ----
    ws = wb.create_sheet("By Stage")
    headers = ["Stage", "Active Artifacts"]
    write_table(ws, headers, [list(r) for r in BY_STAGE])
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 100

    # ---- Forthcoming ----
    ws = wb.create_sheet("Forthcoming")
    headers = ["Phase", "Forthcoming Artifact", "Defined In", "Owner"]
    write_table(ws, headers, [list(r) for r in FORTHCOMING])

    # color by phase
    PHASE_COLORS = {
        "P0a": "FFE5B4",
        "P1":  "D6E5FF",
        "P1a": "DEEBF7",
        "P1b": "FFF2CC",
        "P2/P3": "E8F0E8",
        "P3a/P4": "F4CCCC",
        "P5": "EAEAEA",
    }
    for ri in range(2, 2 + len(FORTHCOMING)):
        ph = ws.cell(row=ri, column=1).value
        color = PHASE_COLORS.get(ph)
        if color:
            ws.cell(row=ri, column=1).fill = PatternFill("solid", fgColor=color)
            ws.cell(row=ri, column=1).font = BOLD_FONT

    # ---- Owners ----
    ws = wb.create_sheet("Owners")
    headers = ["Role", "Owns (artifacts)", "Owns (forthcoming)"]
    write_table(ws, headers, [list(r) for r in BY_OWNER])

    # ---- Format Inventory ----
    ws = wb.create_sheet("Format Inventory")
    headers = ["Format", "Count", "Files (IDs)"]
    rows = [
        [".md (source-of-truth + standalone)", 22, "00–21 markdown sources"],
        [".xlsx", 5, "01, 02, 13, 15, 21"],
        [".docx", 5, "02, 05, 14, 17, 19"],
        [".py (tooling)", 4, "_generate.py, _generate_b4.py, _generate_b6.py, _md_to_docx.py"],
    ]
    write_table(ws, headers, rows)

    # ---- Status Legend ----
    ws = wb.create_sheet("Status Legend")
    headers = ["Status", "Meaning"]
    rows = [
        ["Draft", "Produced; awaiting sponsor / council review"],
        ["Reviewed", "Peer-reviewed but not formally approved"],
        ["Approved", "Formally approved by named gate authority"],
        ["Authoritative", "Becomes the rulebook — like backlog templates"],
        ["Outline", "Structure produced; full artifact emerges in later phase"],
        ["Working", "Tooling that runs and produces output"],
        ["Final", "Completed and not expected to change without explicit revision request"],
    ]
    write_table(ws, headers, rows)
    for ri in range(2, 2 + len(rows)):
        st = ws.cell(row=ri, column=1).value
        if st in STATUS_FILLS:
            ws.cell(row=ri, column=1).fill = STATUS_FILLS[st]
            ws.cell(row=ri, column=1).font = BOLD_FONT

    out_path = OUT / "21-materials-catalog.xlsx"
    wb.save(out_path)
    print(f"  wrote {out_path.name}")


if __name__ == "__main__":
    print("Generating B6 deliverable...")
    build_catalog()
    print("Done.")
