# NFR Template — Non-Functional Requirement

**Use:** NFRs that apply across multiple stories or services are tracked as first-class items using this template. Per-story NFRs are captured in the AC NFR Addendum (see [08-acceptance-criteria-template.md](08-acceptance-criteria-template.md)). This template is for cross-cutting NFRs that need their own entry.

**Pairs with:** [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §2 (adjuncts) and §7 (audit patterns).

---

## NFR header

| Field | Value |
|---|---|
| **NFR ID** | (e.g., `NFR-AUD-001`) |
| **Title** | (one line; what the NFR enforces) |
| **Category** | Latency / Availability / Security / Audit / Performance / Compliance / Operability / Accessibility / Privacy |
| **Owner** | (single accountable role — usually a Lead) |
| **Applicability** | service-wide / cross-service / specific workflow / per-integration |
| **Phase target** | When the NFR must be met (P1a / P2 / P3 / Cutover / Hypercare) |
| **Status** | Draft / Approved / Active / Deprecated |
| **Linked stories** | (story IDs that explicitly inherit this NFR) |

---

## Statement

A clear, testable assertion. Avoid abstract goals; state the contract.

> e.g., *"Every operator action that changes the state of a domain entity emits an immutable record to the operator-action log within the same transaction, with the row's hash chained to the previous row."*

---

## Target metric & measurement

| Metric | Target | Measurement approach |
|---|---|---|
| | | |

For latency NFRs: state percentile (p50 / p95 / p99 / max) and the measurement boundary (e.g., "BFF entry to BFF response").

For availability NFRs: state the time window and the calculation (e.g., "monthly availability = uptime / total time, excluding planned maintenance windows").

For audit NFRs: state the completeness target (typically 100%) and the verification approach.

---

## Verification approach

How we know the NFR is met. Concrete and ongoing.

| Verification type | Cadence | Owner |
|---|---|---|
| (e.g., automated test in CI) | (every PR) | (Test Lead) |
| (e.g., periodic audit query) | (weekly) | (Compliance) |
| (e.g., load test) | (per release) | (Test Lead) |
| (e.g., observability dashboard alert) | (continuous) | (Service Manager) |

---

## Failure mode & response

What happens if the NFR is violated? Who is paged, what is the SLA, what is the escalation?

| Trigger | Detection | Response | Escalation |
|---|---|---|---|
| | | | |

---

## Trade-offs being accepted

NFRs have costs. Name them.

| Cost | Why we accept it |
|---|---|
| | |

---

## Linked stories / Epics

Stories or Epics that explicitly inherit this NFR. The NFR addendum in those ACs references this NFR ID.

| ID | Title | Status |
|---|---|---|
| | | |

---

## Open questions for design lock

| Question | Owner | Required by |
|---|---|---|
| | | |

---

## Worked example

```
NFR ID:        NFR-AUD-001
Title:         Operator-action log: tamper-evident, transactional, complete
Category:      Audit + Compliance
Owner:         Security Lead
Applicability: All services with operator-action endpoints (FMS, TOMS, DSO, TLS, SDS, DBM, Messaging, Task Manager)
Phase target:  P1a (foundational)
Status:        Approved
Linked stories: foundational story FOUND-S-022 implements; every state-changing
                story across services inherits.

Statement:
  Every operator action that changes the state of a domain entity emits an
  immutable record to the operator-action log within the same transaction
  as the entity change. Each row's hash includes the previous row's hash,
  forming a chain that detects post-write tampering. The log is queryable
  for at least 7 years from the action timestamp.

Target metric & measurement:
  | Completeness         | 100% of state-changing actions logged | Daily reconciliation: count of state changes vs count of audit rows |
  | Latency to write     | p99 < 50 ms (within transaction)      | Trace span: action commit duration |
  | Tamper detection     | Detection within 24 h of tamper       | Daily hash-chain validation job |
  | Retention            | 7 years from action timestamp         | Partition retention policy |

Verification approach:
  | Automated test in CI       | Every PR        | Test Lead    |
  | Daily reconciliation query | Daily 02:00     | Compliance   |
  | Hash-chain validation job  | Daily 03:00     | Security Lead |
  | Partition retention check  | Monthly          | DBA          |

Failure mode & response:
  | Reconciliation finds gap         | Daily query mismatch | S1 incident; Security Lead paged | If gap > 0.01% or any [REG]-tagged action: regulator notification considered |
  | Hash-chain validation fails      | Daily job alert      | S1 incident; SecOps + Security Lead paged | Forensic investigation; tamper analysis |
  | Audit write transactionally fails | Trace span error    | S1 incident; on-call paged | Block the operator's action — fail closed, never silently |

Trade-offs being accepted:
  | Cost: ~50ms latency added to every state-changing action | Acceptable; operators do not perceive 50ms |
  | Cost: hash-chain prevents bulk-deletion of audit rows even for legitimate retention cleanup | Mitigation: retention by partition switch-out, not per-row delete |
  | Cost: cross-service hash chain coordination | Mitigation: per-service chains; program-wide reconciliation joins them |

Linked stories / Epics:
  | FOUND-S-022       | Operator-action log foundational implementation       | Done    |
  | NFR-inherited by  | All [REG]-tagged stories across services             | rolling |
```

---

## Cross-NFR dependencies

Many NFRs interact. Document any tensions.

> e.g., *"NFR-AUD-001 (audit completeness) and NFR-PERF-002 (operator action latency p99 < 200ms) are in tension because audit emission adds latency. Resolution: audit emission is in the same transaction as the action commit, and is included in the latency budget. The 200ms target accommodates a 50ms audit cost."*

---

## NFR taxonomy reference

For readers building new NFRs, use these category buckets:

| Category | Typical examples |
|---|---|
| Latency | Operator action response time; integration round-trip; UI interaction render |
| Availability | Service uptime; dependency-loss behavior; degraded-mode definition |
| Security | Authentication; authorization; input validation; secrets handling; cert rotation |
| Audit | Completeness; tamper-evidence; retention; reconstruction capability |
| Performance | Throughput targets; concurrency; load tolerances |
| Compliance | Regulatory citations; retention buckets; data residency |
| Operability | Observability standards; runbook coverage; on-call ergonomics |
| Accessibility | WCAG conformance; keyboard navigation parity; assistive-tech support |
| Privacy | Data classification; minimization; access controls |

A single NFR may have a primary and secondary category. Pick the primary for filtering; capture the secondary in the NFR header notes.
