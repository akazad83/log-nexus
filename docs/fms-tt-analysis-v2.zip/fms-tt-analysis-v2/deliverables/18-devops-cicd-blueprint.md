# DevOps / CI-CD Blueprint

**Artifact ID:** B5.12
**Status:** Draft for DevOps Lead + Architecture Council + SecOps review
**Audience:** DevOps Lead, DevOps Engineers, Engineering Leads, SecOps, Security Lead
**Pairs with:** [03-technical-architecture-outline.md](03-technical-architecture-outline.md), [04-network-boundary-design.md](04-network-boundary-design.md), [16-database-design-principles.md](16-database-design-principles.md)

This blueprint specifies the engineering infrastructure that every service deploys through. It is on-prem, multi-zone, IIS-based, and constrained by the OT/IT segmentation. Generic CI/CD best practices are referenced; this document focuses on what is **specific to this program**.

---

## 1. Purpose & scope

In scope:
- Source control strategy + branching + PR workflow
- CI / CD pipeline structure
- Environment topology (Dev / SIT / Pre-Prod / Prod / Standby OpNET)
- Build artifact strategy (.NET + Angular + DACPAC)
- IIS deployment patterns across CorpNET / DMZ / OpNET
- Secrets, configuration, and certificate management
- Database deployment strategy (DACPAC discipline)
- Release gates per environment
- Rollback strategy per Option A staggered cutover
- Security in pipeline (SAST/DAST/dependency/license)
- Cross-zone deployment workflow

Out of scope:
- Specific Azure DevOps YAML pipeline syntax (P1a build artifact)
- Specific dashboards (B5 observability deliverables)
- Network firewall rules (covered in B2 [04-network-boundary-design.md](04-network-boundary-design.md))
- Disaster recovery runbooks (P4 cutover playbook)

---

## 2. Tooling decisions — locked

| Tool | Choice | Rationale |
|---|---|---|
| Source control | **On-prem Azure Repos** | Aligned with on-prem strategy; sponsor decision (D-004) |
| CI/CD | **On-prem Azure DevOps Server** | Same; integrates natively with Azure Repos |
| Artifact store | **Azure DevOps Artifacts (on-prem)** | Built into ADO Server; supports NuGet, npm, Maven |
| SAST | **Microsoft Defender for DevOps + CodeQL** | CodeQL provides deep semantic analysis; Defender adds policy enforcement |
| DAST | **OWASP ZAP (self-hosted) in pipeline** | Mature, scriptable, no licensing |
| Dependency scan | **OWASP Dependency-Check + GitHub Advisory feed** | NPM + NuGet coverage; on-prem feed sync |
| License compliance | **OWASP Dependency-Check** + per-org allowlist | Internal policy enforcement |
| Container registry | **Not used initially** — IIS hosting is bare-metal | Containers reserved for non-domain services if needed |
| Secrets management | **HashiCorp Vault on-prem (recommended)** OR **CyberArk Conjur** OR **on-prem Azure Key Vault appliance** | Selection in P1; pattern is the same |
| Configuration management | **Per-environment ASP.NET Core appsettings + Azure DevOps Library** | Standard .NET pattern |
| IIS deployment | **Web Deploy (msdeploy)** with structured deployment manifests | On-prem standard |
| Database deployment | **DACPAC + SqlPackage** | SQL Server-native; idempotent |
| Pipeline agents | **Self-hosted agents per zone** (CorpNET-Dev, CorpNET-Prod, DMZ-deploy, OpNET-deploy) | Network constraints prevent cross-zone agent reuse |

### Why CodeQL instead of an alternative

CodeQL was suggested in the original stack with "please suggest better approach." Considered alternatives:

| Tool | Strength | Weakness | Decision |
|---|---|---|---|
| **CodeQL** (chosen) | Deep semantic analysis; widely deployed; free for on-prem internal use; security-research lineage | Slower than syntactic scanners on large codebases | Best for safety-critical OT software where semantic correctness matters |
| SonarQube Enterprise | Mature; multi-language | Annual licensing cost; less semantic depth | Acceptable alternative if licensing fits |
| Snyk Enterprise | Strong dependency + license | Same | Acceptable alternative |
| Veracode | Strong policy enforcement | Heavyweight; SaaS-leaning | Not preferred for on-prem-first program |

**Recommendation: CodeQL for SAST + Dependency-Check for dependencies + ZAP for DAST.** Total cost: nil for licensing; engineering cost for integration is one-time in P1a.

---

## 3. Source control strategy

### 3.1 Repository organization

**Mono-repo per bounded context** is the default. Each domain service has its own repo:

| Repo | Owns |
|---|---|
| `repo/fms` | FMS service (.NET) + FMS frontend module (Angular) + FMS DACPACs |
| `repo/toms` | Same shape, TOMS |
| `repo/dso`, `repo/tls`, `repo/sds`, `repo/dbm` | Same shape per service |
| `repo/messaging`, `repo/task` | Same shape |
| `repo/ems-endpoint` | EMS polling endpoint (sensitive boundary) |
| `repo/integration-adapters` | All external adapters (RR, GIS, FeederBoard, CPMS, etc.) |
| `repo/shared-libs` | Cross-service NuGet packages: identity, audit, telemetry, hash-chain |
| `repo/operator-console-shell` | Angular app shell + cross-feature navigation |
| `repo/data-migration` | UDB→CIM migration code, harness, reference data |
| `repo/infra` | Pipeline templates, Terraform-equivalent if used, environment configs |

### 3.2 Why per-service repos (and not mono-repo for everything)

| Driver | Effect |
|---|---|
| Bounded-context boundaries are real | Cross-repo PRs prevent silent coupling |
| CI pipeline scoping | One service's pipeline failure doesn't block another |
| Permission isolation | Some repos (`ems-endpoint`, `data-migration`) have stricter access controls |
| Branching simplicity per repo | No need for code-owners-as-firewalls |

### 3.3 Branching model — trunk-based with short-lived feature branches

```
main (always-deployable)
  ├── feature/FMS-S-104 (lifespan ≤ 3 days)
  ├── feature/FMS-S-110 (lifespan ≤ 3 days)
  └── hotfix/INC-2026-... (lifespan ≤ 1 day)
```

| Rule | Why |
|---|---|
| Feature branch lifespan ≤ 3 working days | Larger scope = bigger merge; small batches integrate cleanly |
| `main` is always deployable to SIT | Catches integration issues immediately |
| No long-lived release branches | Releases are tags + pipeline artifacts |
| Hotfixes branch from latest deployed prod tag | Direct, traceable |

### 3.4 Pull request workflow

| Step | Required? |
|---|---|
| Branch from `main` | Yes |
| Push triggers CI build | Yes |
| Open PR | Yes (must reference work-item ID) |
| At least 2 approvers (1 for non-security) | Yes (1 for tasks; 2 for stories; 2 + Security Lead for `[REG]`-tagged stories) |
| All CI checks pass | Yes (build, unit, contract tests, SAST, dependency scan) |
| No new high-severity SAST findings | Yes |
| No new high-severity vulnerabilities in dependencies | Yes |
| Linked work item is `Ready` (DoR satisfied) | Yes |
| Commit message references work item | Yes |
| Squash-merge to `main` | Yes (preserves clean history) |

### 3.5 Code ownership

`CODEOWNERS` file per repo. Every change to a sensitive area (e.g., audit code, EMS contract, hash-chain implementation) requires the owning team's approval in addition to standard reviewers.

---

## 4. CI pipeline stages

CI runs on every push to a feature branch and every PR.

```mermaid
flowchart LR
    PUSH[Push / PR] --> CHK[Checks]
    CHK --> BLD[Build]
    BLD --> UT[Unit + Contract Tests]
    UT --> SAST[SAST: CodeQL]
    SAST --> DEP[Dependency Scan]
    DEP --> LIC[License Compliance]
    LIC --> ART[Publish Build Artifact]
    ART --> ITEST[Integration Test Suite<br/>against CI test env]
    ITEST --> CISTAT[CI status: green/red]
```

| Stage | Tool | Threshold |
|---|---|---|
| Checks | Format check, lint, commit-message format | All green |
| Build | dotnet, npm, sqlpackage | All green; warnings as errors in CI |
| Unit + contract tests | xUnit / Jest / Pact | 100% green; coverage targets met |
| SAST | CodeQL | No new high-severity findings |
| Dependency scan | OWASP Dependency-Check | No new high-severity vulnerabilities |
| License compliance | OWASP Dep-Check + allowlist | All deps under allowed licenses |
| Publish artifact | ADO Artifacts | Versioned artifact built (semver + commit SHA) |
| Integration test suite | xUnit + Testcontainers / shared CI test env | All green |

**CI must complete in ≤ 15 minutes for the median PR.** Slow CI is the silent killer of trunk-based development. Pipeline performance is a P1a deliverable, not an afterthought.

---

## 5. CD pipeline stages

CD runs on every successful build of `main` (auto-deploy to SIT) and on tagged release (manual-approval to Pre-Prod, then Prod).

```mermaid
flowchart TD
    MAIN[main green build] --> SIT[Auto-deploy to SIT]
    SIT --> SMOKE_SIT[Smoke + E2E in SIT]
    SMOKE_SIT --> TAG{Release tag?}
    TAG -->|no| END_SIT[Stop]
    TAG -->|yes| APPROVE_PP[Approval gate<br/>Engineering Lead + Test Lead]
    APPROVE_PP --> PP[Deploy to Pre-Prod]
    PP --> SMOKE_PP[Smoke + perf + DAST]
    SMOKE_PP --> APPROVE_PROD[Approval gate<br/>Operations Lead + Security Lead]
    APPROVE_PROD --> PROD[Deploy to Prod CorpNET]
    PROD --> SMOKE_PROD[Smoke; canary]
    SMOKE_PROD --> STDBY[Replicate to Standby OpNET]
```

| Environment | Deployment trigger | Approval | Smoke + verification |
|---|---|---|---|
| Dev (per-developer) | Local; ad-hoc | None | Developer-driven |
| SIT (CorpNET) | Automatic on `main` green | None | Auto-smoke + E2E |
| Pre-Prod (CorpNET) | Tagged release with manual approval | Engineering Lead + Test Lead | Auto-smoke + DAST + perf test |
| Prod CorpNET | Tagged release with manual approval | Operations Lead + Security Lead | Auto-smoke + canary + monitor |
| Standby OpNET | Automatic post-Prod-CorpNET via cross-zone deploy pipeline | Implicit (the prod approval) | Auto-smoke from OpNET agent |

---

## 6. Environment topology

### 6.1 Environment matrix

| Environment | Zone | Purpose | Data | Resemblance to Prod |
|---|---|---|---|---|
| Dev (per-developer) | Local | Developer iteration | Synthetic, small | Low (Docker SQL Server, mocks) |
| Dev (shared) | CorpNET-Dev | Shared dev integration | Synthetic, varied | Medium |
| SIT | CorpNET-SIT | Continuous integration target | Refreshed daily from anonymized Pre-Prod subset | High in shape, low in volume |
| Pre-Prod | CorpNET-PreProd + DMZ + OpNET-PreProd | Pre-release validation; perf test; DAST | Production-shape data (anonymized) at production volume | Very high |
| Prod | CorpNET-Prod + DMZ + OpNET-Standby | Live | Real data | — |

Pre-Prod is the **most expensive** environment because it must mirror production topology including OpNET standby and DMZ. It is also the one that catches the largest class of issues. Justify the cost.

### 6.2 Network connectivity per environment

Each environment respects the same OT/IT segmentation as Prod:
- CorpNET ↔ DMZ ↔ OpNET segmentation enforced (even in lower environments)
- Pipeline agents are zone-resident (one set of agents per zone per environment)
- No cross-zone agent reuse (ever)

---

## 7. Build artifact strategy

### 7.1 What gets built

Per service repo, the build produces:

| Artifact | Purpose |
|---|---|
| `.NET service` (folder + msdeploy package) | Backend service; IIS-deployable |
| `Angular module bundle` | Frontend feature; consumed by `operator-console-shell` |
| `DACPAC` | SQL Server schema bundle for the service's DB schema |
| `migration-only DACPAC` | Just the migration scripts (for reverse-deploy flexibility) |
| `helm chart / deployment manifest` | If containerized (not in MVP scope) |
| `release notes` | Auto-generated from PR descriptions linked in the build |

### 7.2 Versioning

- SemVer (`major.minor.patch`)
- Patch auto-increments per build (`1.4.7-build-1234+abc1234`)
- Major / minor advance manually on contract changes; CI rejects if a contract change does not advance minor

### 7.3 Reproducibility

- Build is reproducible from a given commit SHA
- Agent OS image is versioned; agent images are themselves built artifacts
- Artifact retention: 90 days online; release artifacts retained for the program lifetime

---

## 8. Deployment to IIS — multi-zone

### 8.1 IIS topology per zone

Each zone has an IIS farm:

| Zone | Role | App pools |
|---|---|---|
| CorpNET-Prod | Primary application tier | One app pool per service (FMS, TOMS, DSO, TLS, SDS, DBM, Messaging, Task Manager, BFF, RR Adapter, External Adapters) |
| OpNET-Standby | Functionally equivalent standby | Same set of app pools, normally idle |
| OpNET (active) | EMS Polling Endpoint | Dedicated app pool for the EMS endpoint (always active) |
| DMZ | Replication broker, audit forwarder, External GW | Specific app pools per DMZ component |

### 8.2 Deployment workflow per service

```
1. Build artifact arrives at CorpNET-Prod-Agent
2. Agent stops target service's app pool (or sets to drain mode)
3. Agent backs up current app folder
4. Agent unpacks new artifact
5. Agent runs DACPAC against the service's DB schema
6. Agent starts app pool
7. Smoke tests run from in-zone test runner
8. Cross-zone replication kicks in (CorpNET-Prod to OpNET-Standby)
9. OpNET-Standby agent unpacks the same artifact (deployment is identical)
10. OpNET-Standby smoke tests run from OpNET test runner
11. Health check signals success to ADO; release is `Deployed`
```

### 8.3 Deployment rules

| Rule | Why |
|---|---|
| **Blue-green per service is preferred where capacity allows** | Reduces downtime to near-zero for the service |
| **Rolling deploy across IIS instances within the zone** | Acceptable when blue-green not feasible |
| **No rolling deploy across zones** | Prod CorpNET fully deployed and verified before OpNET Standby |
| **App pool restart, not server restart** | Server-level restarts are runbook events |
| **DACPAC applied before service start** | Schema changes must precede app-tier expectation |
| **Smoke must include audit emission verification** | Every deploy verifies audit pipeline is intact (NFR-AUD-001) |

### 8.4 The EMS Polling Endpoint is special

- Lives on OpNET (not CorpNET); its deployment doesn't mirror to CorpNET
- Backed by EMS-vendor-managed certs; cert rotation is part of deployment runbook
- Cannot deploy during active EMS poll cycle without coordination — pipeline pauses if EMS poll rate detected mid-deploy

---

## 9. Secrets management

### 9.1 Principles

- **No secrets in source code, config files, or pipeline variables.** Period.
- Secrets are **referenced by name** in config files; resolved at startup
- Pipeline variables can hold non-secret values; secrets pass through via Vault references
- Secret rotation is **automated** for service-account passwords; manual + tracked for vendor-issued certs

### 9.2 Vault structure

```
vault/
├── shared/
│   ├── observability/
│   ├── identity/
│   └── audit/
├── fms/
│   ├── prod/{db-conn-string, ems-cert, app-secret}
│   ├── pre-prod/...
│   └── sit/...
├── toms/...
└── ems-endpoint/  # restricted access; only DevOps Lead + Security Lead
```

### 9.3 Cert lifecycle

| Cert | Rotation | Owner |
|---|---|---|
| Service-to-service mTLS (internal CA) | 90 days, automated | DevOps Lead |
| EMS endpoint mTLS (vendor CA) | Per vendor schedule (typically 1 year) | Integration Lead + EMS Vendor |
| External adapter certs (per-vendor) | Per vendor schedule | Integration Lead |
| Backup encryption keys (HSM) | 1 year, manual | Security Lead |
| Always Encrypted column keys | 1 year, manual | Security Lead |

### 9.4 Pipeline access to secrets

- Build pipelines have **no secret access** by default
- Deploy pipelines fetch secrets via Vault agent at deployment time
- Per-stage Vault paths; pipeline cannot read another stage's secrets
- Secret access is logged to audit; reviewed weekly

---

## 10. Configuration management

### 10.1 Layered configuration

```
appsettings.json                # base config, in repo
appsettings.{Environment}.json  # env overrides, in repo
{Vault references}              # secrets, runtime resolved
{Environment variables}         # platform/process overrides
```

### 10.2 Configuration as code

- Environment-specific config files in repo (no secrets in them)
- Diffs reviewed via PR like any code
- No "production-only" untracked config; if it exists, the build is broken

### 10.3 Feature flags

- Used sparingly; flags are technical debt
- Flags must have a removal date in the work item that creates them
- Flag state is observable in telemetry
- No "permanent" feature flags — that pattern is hidden config branching

---

## 11. Database deployment — DACPAC discipline

### 11.1 The pattern

| Step | Tool |
|---|---|
| Author migrations as Visual Studio SQL DB project | Schema-as-code |
| Build produces DACPAC | `sqlpackage /Action:Extract` |
| Deploy applies DACPAC against target | `sqlpackage /Action:Publish` with options |
| Verification: schema-state matches expectations | DACPAC compare |

### 11.2 Migration safety

- DACPAC publish in **dry-run mode first** in Pre-Prod
- Generated DDL reviewed by DBA before production deploy
- Block patterns: **"Drop column"**, **"Drop table"**, **"Change column type narrowing"** are blocked unless explicitly authorized via a special pipeline step
- Rollback path: forward-only; new DACPAC compensates if needed

### 11.3 Hot-table changes

Changes to tables > 10M rows go through a special review (per [16-database-design-principles.md](16-database-design-principles.md) §16.3). Pipeline blocks the deploy if such a change is detected without explicit approval annotation.

### 11.4 Reference data

DBM reference data (substations, feeders, breakers) is deployed via separate seed scripts, version-controlled, idempotent. Changes go through normal PR review.

---

## 12. Frontend deployment

### 12.1 Build & artifact

- Angular build produces a static bundle
- Bundle is versioned (commit SHA in URL for cache busting)
- Bundle deployed to IIS as static content under the BFF path

### 12.2 Deploy strategy

- Atomic swap (build artifact directory swap) → no partial-deploy state visible to operators
- Browser-side cache invalidated via versioned URLs
- Worker scripts (if any, e.g., service workers) versioned with explicit lifecycle

---

## 13. Release gates

### 13.1 Per-environment gates

| Environment | Gate | Authority | Criteria |
|---|---|---|---|
| SIT | Auto | None | CI passes |
| Pre-Prod | Manual | Engineering Lead + Test Lead | CI green; release notes complete; SIT smoke clean for ≥ 24h |
| Prod CorpNET | Manual | Operations Lead + Security Lead | Pre-Prod smoke + DAST + perf clean; change ticket approved; rollback plan documented |
| Prod OpNET (Standby) | Auto post-CorpNET | Implicit | CorpNET deploy succeeded; smoke clean |
| **Cutover deploys** (P4) | Manual + Operator panel | Operations Lead + CIO + Operator panel | Per cutover playbook; outside normal release cadence |

### 13.2 Change ticketing integration

- Every Prod deploy creates a change ticket (auto-populated from release notes + CI artifacts)
- Cutover deploys go through change-advisory-board (CAB) for ITSM compliance
- CAB approval is a release gate; pipeline waits

---

## 14. Rollback strategy

### 14.1 Per-deploy rollback

- Any Prod deploy can be rolled back via redeploying the previous tagged build
- Rollback runbook is part of every release (auto-generated; service owner reviews)
- Rollback time SLO: ≤ 10 minutes from decision to old-version-live
- Rollback rolls forward (does not undo time); audit captures both forward deploy and rollback as separate events

### 14.2 Cutover rollback (P4)

This is fundamentally different — see [19-cutover-playbook-outline.md](19-cutover-playbook-outline.md) and [17-data-migration-strategy.md](17-data-migration-strategy.md) §10.

- Cutover rollback is not an automated pipeline action
- It is a runbook-driven coordinated operation involving DBAs, operators, ops
- The 4-week soak window keeps legacy hot-standby on OpNET as the rollback plane
- Rollback authority: Steering Committee (not just Operations Lead)

### 14.3 Forward fix vs. rollback

The team's bias should be **forward fix** for non-cutover events:
- Most production issues are faster to fix forward than to roll back
- Rollback is reserved for genuine regressions caught in smoke / canary
- Forward-fix discipline requires fast CI/CD, which we've engineered for

---

## 15. Security in pipeline

### 15.1 SAST policy

- CodeQL runs on every PR
- New high-severity findings block PR merge
- Existing findings tracked as tech debt with remediation owner
- Suppressions require Security Lead approval, recorded in the suppression file with justification + expiry

### 15.2 Dependency scan policy

- Runs on every PR + nightly against `main`
- New high-severity vulnerabilities block PR merge
- Allowlist for false positives, expires every 90 days
- Critical CVE published mid-flight: nightly scan auto-creates a P1 ticket; pipeline pauses Prod deploys until reviewed

### 15.3 DAST policy

- Runs nightly against Pre-Prod
- Findings ranked by exploitability
- High-severity DAST findings block next Prod deploy until triaged

### 15.4 License compliance

- Allowlist of approved OSS licenses
- New license categories require Security Lead + legal review
- Build fails on disallowed license

### 15.5 Threat modeling integration

- Threat model per service reviewed quarterly + after major changes (P1 detailed design output)
- Threat-model-derived test scenarios part of nightly DAST run
- Identified mitigations tracked as user stories in backlog

---

## 16. Cross-zone deployment workflow

The hardest part of the entire pipeline. Deserves its own section.

### 16.1 The constraint

- No pipeline agent in CorpNET can connect into OpNET
- No pipeline agent in OpNET can connect into CorpNET
- Agents in DMZ can connect to both, but DMZ is policy-only (no logic)

### 16.2 Pattern: artifact replication via DMZ

```mermaid
flowchart LR
    BUILD[Build agent<br/>CorpNET]
    ARTIFACT[Artifact store<br/>CorpNET]
    DEPLOY_CORP[Deploy agent<br/>CorpNET]
    DMZ_BRIDGE[Replication broker<br/>DMZ]
    DEPLOY_OP[Deploy agent<br/>OpNET]
    PROD_CORP[Prod CorpNET]
    STDBY_OP[Standby OpNET]

    BUILD --> ARTIFACT
    ARTIFACT --> DEPLOY_CORP
    DEPLOY_CORP --> PROD_CORP
    ARTIFACT -- via mTLS --> DMZ_BRIDGE
    DMZ_BRIDGE -- via mTLS --> DEPLOY_OP
    DEPLOY_OP --> STDBY_OP
```

### 16.3 The deploy agent in OpNET

- Runs on OpNET infra
- Pulls artifacts from a DMZ-resident artifact mirror
- Executes deploy locally; reports back via DMZ
- Cannot fetch from public internet; relies on DMZ-mirrored package feeds

### 16.4 Standby vs. active in OpNET

- Most services on OpNET are **standby** (deployed but not serving traffic)
- One service is **active**: the EMS Polling Endpoint
- Active service deploy follows blue-green within OpNET; standby services swap in place

### 16.5 DMZ deploy

DMZ-resident services (Replication broker, Audit forwarder, External GW, App Gateway) deploy via a separate DMZ pipeline:

- Build same artifacts; deploy to DMZ agents
- Stricter approval gate (Security Lead approval required for any DMZ-resident service deploy)
- DMZ-resident services have minimal change cadence by design

---

## 17. Pipeline performance & efficiency

### 17.1 SLOs

| SLO | Target |
|---|---|
| Median PR CI time | ≤ 15 minutes |
| Median deploy-to-SIT | ≤ 10 minutes |
| Median deploy-to-Prod (per service) | ≤ 20 minutes |
| Median rollback (per service) | ≤ 10 minutes |
| Pipeline availability | ≥ 99% during business hours |

### 17.2 Practices to hit them

- Test parallelization across agents
- Layered test runs (fast tests first; slow tests after)
- Caching of dependencies (NuGet, npm) per agent
- Incremental builds where supported
- Pre-warmed agents for hot pipelines (avoid agent provisioning latency)

---

## 18. Observability of the pipeline itself

| Signal | Source | Destination |
|---|---|---|
| Build duration per stage | ADO | Grafana / equivalent |
| Build success rate | ADO | Same |
| Time-to-deploy by service | ADO | Same |
| Rollback frequency | ADO | Same; alert if > 1/week |
| SAST / DAST trend | CodeQL / ZAP | Same |
| Mean Time to Recovery (MTTR) | ADO + incident system | Same |

---

## 19. Open decisions for P1a

| ID | Decision | Driver | Blocks |
|---|---|---|---|
| DO-01 | Confirm Vault product (HashiCorp / CyberArk / Azure Key Vault on-prem) | Security Lead + DevOps Lead | Secrets management implementation |
| DO-02 | Confirm SAST stack (CodeQL alone or with SonarQube) | Security Lead | Pipeline configuration |
| DO-03 | Confirm IIS deployment tooling (msdeploy vs. alternative) | DevOps Lead | Deployment scripts |
| DO-04 | Confirm DACPAC vs. EF Core migrations vs. hybrid for DB deploy | Data Architect + DevOps Lead | Database deployment pipeline |
| DO-05 | Confirm cross-zone artifact replication transport (DMZ broker vs. dedicated channel) | SecOps + DevOps Lead | Cross-zone pipeline |
| DO-06 | Confirm pipeline agent OS baseline (Windows Server version) | DevOps Lead + Infra | Agent provisioning |
| DO-07 | Confirm change-management ticketing integration (ServiceNow? other?) | Operations + IT | Release gate automation |
| DO-08 | Confirm ZAP integration depth in pipeline | Security Lead | DAST automation |
| DO-09 | Confirm artifact retention policy for compliance | Compliance + DevOps Lead | Storage planning |
| DO-10 | Confirm canary strategy in production (blue-green vs. rolling per service) | Operations Lead + Engineering Lead | Production deployment shape |

---

## 20. What this document does not specify

- Specific YAML pipelines (P1a build artifact)
- Specific Azure DevOps project structure (P1a)
- Specific Vault access policies (P1a after DO-01)
- Specific dashboard definitions (B5 observability deliverables; emerges in P1a)
- Disaster-recovery runbooks (P4 cutover playbook outline + per-service runbooks)
- Capacity planning for build agents (P1a infrastructure design)
