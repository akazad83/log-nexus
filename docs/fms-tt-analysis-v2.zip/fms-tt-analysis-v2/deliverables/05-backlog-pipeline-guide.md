# Backlog Engineering Pipeline Guide

**Artifact ID:** B3.3
**Status:** Authoritative — this is how the program engineers its backlog
**Audience:** Product Owner, BA Lead, Scrum Masters, Engineering Leads, Test Lead, Compliance Officer
**Pairs with:** templates 06–12 in this folder

This guide defines how the **600+ features, 650+ functional requirements, and 1000+ business rules** from Phase 0 Discovery become a build-ready backlog. It is opinionated, switching-workflow-specific, and designed to enforce the program's three sponsor non-negotiables structurally — through Definition of Ready, Definition of Done, and AC patterns — rather than through goodwill.

---

## 1. The non-negotiables — and how this pipeline enforces them

| Non-negotiable | How the pipeline enforces it |
|---|---|
| **Feature parity** | Every Epic and Story is tagged Parity / New-Value. Parity stories require operator SME sign-off in DoD. Mental-model parity is verified at sprint demo, not at UAT. |
| **20% tangible new value** | Every Epic carries a Parity-vs-New-Value classification. Backlog metric tracks rolling new-value coverage. MVP DoR requires the 20% target to be explicitly allocated across Epics before Build starts. |
| **MVP operator approval (M-06)** | Story DoD for parity-critical MVP stories requires operator panel demo, not just operator SME signoff. M-06 acceptance is operationalized as the MVP-scoped subset of stories all hitting that DoD. |

**Audit / regulatory** is not a fourth pillar — it is woven into every AC pattern. See §7.

---

## 2. The hierarchy

```mermaid
flowchart LR
    F[Feature<br/>Discovery output]
    E[Epic<br/>Bounded slice of value]
    S[User Story<br/>One vertical slice]
    AC[Acceptance Criteria<br/>Gherkin + NFR]
    T[Task<br/>Engineering unit]

    F -->|decomposes into| E
    E -->|decomposes into| S
    S -->|specified by| AC
    S -->|implemented via| T
```

| Level | Owner | Granularity | Lifespan |
|---|---|---|---|
| Feature | Product Owner | Coarse capability ("Manage switching cards"); from Discovery | Multi-quarter |
| Epic | Product Owner | A bounded slice of a feature ("Auto-create card from EMS event"); fits in 1–2 quarters | Quarter-scale |
| User Story | Product Owner + BA | One vertical slice of an Epic; demo-able in a sprint | Sprint-scale |
| Acceptance Criteria | BA + Test Lead | Concrete pass/fail tests for a Story | Lifespan of the story |
| Task | Engineering Lead | A single engineer-day of work | Day-scale |

**Hard rule:** *every level is a strict refinement, not a renaming*. A Feature does not get reworded into an Epic. A Feature decomposes into multiple Epics.

### Adjuncts (not in the main hierarchy)

| Type | When used | Tracked in |
|---|---|---|
| Spike | Investigative work to remove uncertainty before a Story can be Estimated | [09-spike-template.md](09-spike-template.md) |
| Bug | A defect against a built capability | [10-bug-template.md](10-bug-template.md) |
| NFR | A non-functional requirement applied across stories | [11-nfr-template.md](11-nfr-template.md) — and woven into every AC |

---

## 3. Translation rules — Feature → Epic

### 3.1 What's a good Feature → Epic split?

A Feature decomposes into Epics by **cohesive slices of operator value**. Each Epic must:

1. Stand on its own as a unit of value (cancel one Epic mid-program; the rest still ship coherently)
2. Belong to exactly one bounded context (FMS, TOMS, etc.) — cross-context Epics are split per context
3. Belong to one phase of the workflow (Notify, Create, De-energize, Authorize, Execute, Test, Re-energize, Close) — Epics that span all 8 are too coarse
4. Carry a Parity / New-Value classification at this level (one Epic, one classification)

### 3.2 Concrete pattern for switching workflows

```
Feature: "Manage switching cards" (from Discovery)
  ↓ split by bounded context
  Epic FMS-1: Auto-create switching card from EMS event (FMS context)
  Epic TOMS-1: Auto-create switching card from EMS event (TOMS context)
  ↓ if needed, further split by workflow phase or scenario
  Epic FMS-1a: Auto-create card for planned distribution outage
  Epic FMS-1b: Auto-create card for emergency outage
```

### 3.3 Anti-patterns (reject these in backlog grooming)

| Anti-pattern | Why it's wrong |
|---|---|
| One Epic per cross-app workflow | Spans bounded contexts; can't deploy independently; can't estimate |
| One Epic per feature category ("All Reporting") | Too coarse; will be in flight for years; no clear delivery rhythm |
| Parity + New-Value mixed in same Epic | Defeats the 20%-coverage tracking |
| Epic that touches all 8 workflow steps | Almost certainly should be 8 Epics |

---

## 4. Translation rules — Epic → User Story

### 4.1 Vertical slicing is mandatory

Every Story is **a vertical slice through frontend + backend + data + integration where applicable**. Horizontal slicing (e.g., "build the data model" as a story) is forbidden. Reasons:

- Operators can demo it
- Audit/observability/security all get exercised story-by-story
- Hidden dependencies surface early
- "Feature complete but not deployable" is impossible

### 4.2 Story-splitting heuristics specific to switching workflows

In priority order — try splits in this order. Stop when stories fit a sprint.

1. **Split by workflow step.** Notify → Create → De-energize → Authorize → Execute → Test → Re-energize → Close. Each step is a candidate slice.
2. **Split by scenario.** Planned outage; emergency switching; scheduled maintenance; islanding-mode operation. Start with the most common scenario; defer edge scenarios.
3. **Split by topology complexity.** Single feeder, single substation → multi-feeder, single substation → multi-feeder, cross-substation. Build simplest first.
4. **Split by tag/clearance complexity.** Single tag → multi-tag → tag with multiple holders → tag with conditional release.
5. **Split by integration depth.** Decoupled (mock EMS, mock Rapid Restore) → integrated (real EMS, real RR). Operators can demo decoupled stories; integration adds in subsequent stories.
6. **Split by happy-path / error-path.** Happy path first; specific error scenarios as separate stories.
7. **Split by operator role.** Operator-only flows → operator + supervisor flows → operator + supervisor + auditor flows.
8. **Split by data variant.** One feeder type → multiple feeder types; one card type → multiple card types.
9. **Split by audit-trail depth.** Basic audit (entity-history) → expanded audit (operator-action log) → tamper-evident audit (hash-chain).

**Rule of thumb:** if a story is bigger than 8 story points, you have not finished splitting.

### 4.3 The vertical slice anatomy for a switching workflow story

A story like *"Operator can de-energize step on a card and have the system enforce isolation rules"* must include:

| Slice element | Required? |
|---|---|
| Frontend interaction (Angular component + state) | Yes |
| BFF endpoint | Yes |
| Service domain logic (business rules + state machine) | Yes |
| DB persistence (entity state + temporal history) | Yes |
| Audit trail emission (operator action log) | **Yes — non-negotiable** |
| Integration call (if any — e.g., status to Rapid Restore) | If applicable |
| Telemetry instrumentation (logs / metrics / trace span) | Yes |
| NFR validation (latency, audit completeness) | Yes |
| Operator demo path (running flow that operator can see end-to-end) | Yes |

A story missing any non-applicable element is **not vertical**, and DoR rejects it.

---

## 5. Translation rules — Story → Acceptance Criteria

### 5.1 Format

ACs are **Gherkin** (Given / When / Then) plus an **NFR addendum**. See [08-acceptance-criteria-template.md](08-acceptance-criteria-template.md).

### 5.2 Required AC categories per story

Every story has, at minimum, one AC from each applicable category:

| Category | When required | Example |
|---|---|---|
| Happy path | Always | "Given a valid card, when operator clicks De-energize, then card moves to De-energized state" |
| Error path (one or more) | Always | "Given a card with unmet preconditions, when operator clicks De-energize, then state does not change and operator sees corrective action" |
| Authorization | Whenever the action requires it | "Given an operator without authorization for this district, then the De-energize action is not visible/enabled" |
| Audit trail | **Whenever a state changes** | "Given any state transition, then operator action log records principal, timestamp, before-state, after-state, and reason if provided" |
| Integration | Whenever the story crosses a system boundary | "Given a successful de-energize, when status update is sent to Rapid Restore adapter, then it is delivered with idempotency key and logged in integration audit" |
| Resilience | Whenever an external dependency exists | "Given Rapid Restore is unreachable, when operator de-energizes, then local state still transitions and outbound update is queued for retry" |
| Operator visibility | For all operator-facing changes | "Given the de-energize completes, then operator console reflects new state within 1 second" |

### 5.3 NFR addendum (always present)

Even when "no special NFR applies," the addendum makes that explicit. Categories:

- **Latency** — operator-perceptible interactions: target p99
- **Availability** — what happens during dependency loss
- **Security** — auth requirement, role check, data sensitivity
- **Audit** — what is logged, retention bucket
- **Performance** — load characteristics if applicable

See [11-nfr-template.md](11-nfr-template.md) for the full taxonomy.

---

## 6. Translation rules — Story → Tasks

Tasks are **engineer-day units of work**. Tasks are not visible to operators or PO; they exist for engineering planning.

A typical vertical-slice story produces 4–10 tasks across:

- Domain model + business rules (1–3 tasks)
- DB migration / temporal table addition (1 task)
- Service endpoint + tests (1–2 tasks)
- BFF endpoint + tests (1 task)
- Frontend component + state + tests (1–2 tasks)
- Integration adapter changes if applicable (0–2 tasks)
- Audit + telemetry instrumentation (1 task)
- E2E test (1 task)
- Documentation updates (1 task)

**Hard rule:** if a single task takes more than 2 engineer-days, it's a story, not a task.

---

## 7. Regulatory & audit AC patterns (woven into every applicable story)

Audit is the program's regulatory exposure. AC patterns enforce coverage.

### 7.1 The four audit AC patterns

For any story that touches operator action, data state, authorization, or external integration — at least one of these patterns is required:

#### Pattern A — Entity-history AC

> Given a domain entity is in state X, when an action transitions it to state Y, then the entity's temporal history records (X → Y) with timestamp, principal, and the action ID.

#### Pattern B — Operator-action AC

> Given an operator performs an action, when the action completes (success or failure), then an immutable record is written to the operator action log including: operator identity, action type, target entity, timestamp, success/failure, before-state hash, after-state hash, reason if provided, request correlation ID.

#### Pattern C — Authorization-decision AC

> Given an authorization decision is made (allow or deny), when the decision is computed, then the auth-decision log records: principal, action requested, target, decision, policy version, timestamp.

#### Pattern D — Integration-call AC

> Given a call is made to an external system, when the call completes (success, failure, or timeout), then the integration audit log records: caller service, target system, endpoint, request payload hash, response payload hash, status, latency, retry count, idempotency key.

### 7.2 Tamper-evidence

Operator-action logs are written with a hash chain — each row's hash includes the previous row's hash. AC pattern: 

> Given a sequence of operator actions, when any row in the operator action log is altered post-write, then a tamper-detection job reports the discrepancy within 24 hours.

This pattern lives in a single dedicated story (one of the foundational stories in P1a), not repeated per story. But every story that writes to the operator action log inherits the property.

### 7.3 Regulatory AC tagging

Every AC that exists *because* of a regulatory requirement is tagged `[REG]` and links to the citation. This makes regulatory regression testing tractable: filter by tag, run the suite, attach to audit packet.

### 7.4 Anti-patterns

| Anti-pattern | Why it's wrong |
|---|---|
| "Audit is added later as cross-cutting" | Late-added audit misses state transitions. Audit ACs are story-by-story. |
| "Audit AC is the same for all stories" | Different state transitions need different audit detail. Don't copy-paste. |
| "We'll just enable SQL Server temporal tables, that's enough" | Temporal tables capture data state; not operator behavior. Both are needed. |
| Logging operator actions only on success | Failed actions must also be audited. |

---

## 8. Definition of Ready (DoR)

A story is Ready to enter a sprint when **every** item below is true. Anything else is grounds for sprint-rejection by Engineering Lead — without apology.

### 8.1 Functional readiness

- [ ] Story has a clear "As a [role], I want [action], So that [outcome]" statement
- [ ] Story is linked to its parent Epic
- [ ] Story is tagged Parity or New-Value (mandatory)
- [ ] Story is tagged with the workflow step it slices into (Notify / Create / De-energize / Authorize / Execute / Test / Re-energize / Close — or "cross-cutting" with explicit rationale)
- [ ] Story is tagged with the bounded service (FMS / TOMS / DSO / TLS / SDS / DBM / Messaging / Task Manager / Integration)
- [ ] Story has identified the operator SME by name (not "TBD")

### 8.2 AC readiness

- [ ] At least one happy-path AC
- [ ] At least one error-path AC
- [ ] AC for authorization if applicable
- [ ] **AC for audit trail if a state changes — non-negotiable**
- [ ] AC for integration if a system boundary is crossed
- [ ] AC for resilience if an external dependency exists
- [ ] AC for operator visibility (for operator-facing stories)
- [ ] NFR addendum present (even if "no special requirements" — make it explicit)

### 8.3 Engineering readiness

- [ ] Integration touch-points enumerated (which adapters, which contracts)
- [ ] Dependencies identified (other stories, foundational work, spikes)
- [ ] Risks called out (R-IDs from Risk Register if applicable)
- [ ] Story is sized (story points) — if it's >8 points, it's split before entering sprint
- [ ] Spikes resolved — no story enters a sprint with unresolved investigative uncertainty

### 8.4 Regulatory readiness

- [ ] If story has any `[REG]`-tagged AC, the regulator citation is linked
- [ ] If story affects retention, the retention bucket is named
- [ ] If story crosses an OT/IT boundary, the network-design implications are noted

### 8.5 The "5 Whys" gate

Before a story is Ready, the BA asks the operator SME "why?" five times against the goal. This catches stories that are "we always did it this way" rather than stories that capture *current operator intent*. New-value stories pass this naturally; parity stories often surface buried business reasons that become ACs.

---

## 9. Definition of Done (DoD)

A story is Done when **every** item below is true. Anything else is "in progress."

### 9.1 Engineering DoD

- [ ] Code merged to main with required reviews (minimum 2 approvers; security review for `[REG]`-tagged stories)
- [ ] All unit tests passing
- [ ] All contract tests passing (consumer + producer side for cross-service)
- [ ] All integration tests passing (against real dependencies in SIT)
- [ ] All E2E tests passing (against Pre-Prod environment)
- [ ] Static analysis (SAST) clean — no new high-severity findings
- [ ] Dependency scan clean — no new high-severity vulnerabilities
- [ ] Telemetry instrumented (logs structured + correlation IDs propagated; metrics emitted; trace span created)

### 9.2 Audit & compliance DoD

- [ ] Audit trail validated by automated test (entity-history + operator-action log entries verified for the AC scenarios)
- [ ] If `[REG]`-tagged: compliance officer reviews the AC test evidence
- [ ] If retention-affecting: data lifecycle test passes (data exists in correct partition; deletion-protection in place)

### 9.3 Operator DoD (parity & MVP stories)

- [ ] **Operator SME has reviewed and signed off on parity stories**
- [ ] **For MVP stories: demo'd to operator panel before "Done"**
- [ ] For new-value stories: operator co-design notes attached; operator panel agrees value is delivered

### 9.4 Documentation DoD

- [ ] README / runbook section for any new operational behavior
- [ ] API documentation (OpenAPI) updated for new/changed endpoints
- [ ] Service-level documentation updated if domain model changed
- [ ] Operator-facing help / training material flagged for the Change Management team

### 9.5 Demo DoD

- [ ] Demo'd at sprint review with operator SME in attendance (parity) or operator co-designer (new-value)
- [ ] Sprint demo recording archived (operator panel reviews these between demos)

---

## 10. The 20% new-value enforcement mechanism

The sponsor's commitment is **20% tangible new value** beyond parity. This is enforced structurally:

### 10.1 Allocation gate (before MVP build starts)

Before P2 (MVP Build) starts, the PO + Operations Lead jointly allocate **at least 20% of MVP story points** to new-value stories. This allocation is reviewed at MVP Detailed Design exit (gate M-02).

If less than 20% is allocated, MVP build does not start. This is a sponsor-policy gate, not a technical gate.

### 10.2 Tracking metric

The backlog reports, every sprint:

```
new_value_coverage = sum(story_points where parity_or_value=NewValue) / sum(story_points done)
```

Trending this metric weekly catches drift early. If new-value drops below 18% rolling 4-sprint average during MVP build, escalation to PO + sponsor.

### 10.3 New-value criteria

A story qualifies as `NewValue` when **all** of:
- It does not exist in the legacy system (or is qualitatively different)
- Operator SME has confirmed the new behavior is desired (not just "might be nice")
- It has measurable success criterion (e.g., "operator effort drops by X" or "new visibility unlocks Y decision")

Stories that "improve" parity behaviors (faster, cleaner UI) are still **Parity** unless they unlock a behavior operators couldn't do before.

### 10.4 Anti-patterns

| Anti-pattern | Why it's wrong |
|---|---|
| Tagging parity stories as new-value to inflate the metric | Operators will detect this in UAT; sponsor confidence damaged |
| Adding "shiny" new-value stories that operators didn't ask for | Misses the "tangible to operators" criterion |
| Deferring all new-value to Phase 3 | M-06 cannot demonstrate value; gate fails |
| One mega-Epic of "all new value" | Bypasses the per-Epic 20% distribution |

---

## 11. Backlog states & lifecycle

```mermaid
stateDiagram-v2
    [*] --> Discovery_Output
    Discovery_Output --> Feature_Backlog: BA review
    Feature_Backlog --> Epic_Backlog: Epic decomposition
    Epic_Backlog --> Story_Backlog: Story decomposition
    Story_Backlog --> Refining: Brought into refinement
    Refining --> Ready: Passes DoR
    Refining --> Story_Backlog: Fails DoR; needs more work
    Ready --> In_Sprint: Selected for sprint
    In_Sprint --> In_Progress: Engineer starts
    In_Progress --> In_Review: Code review
    In_Review --> In_Test: Tests + ACs validated
    In_Test --> Operator_Review: Parity/MVP stories only
    In_Test --> Done: New-value or non-MVP
    Operator_Review --> Done: Operator signoff
    Operator_Review --> In_Progress: Rework needed
    Done --> [*]
```

**Hard rule:** stories don't skip states. A story that's "almost done" is `In Progress`, not `Done`.

---

## 12. Estimation discipline

| Practice | Required? |
|---|---|
| Estimate in story points (Fibonacci: 1, 2, 3, 5, 8, 13) | Yes |
| Re-estimate during refinement, not after sprint | Yes |
| Stories >8 points must be split | Yes |
| Hours estimates only at task level | Yes |
| Calibrate quarterly using "anchor stories" the team agrees on | Yes |
| Estimate as a team (planning poker or equivalent) | Yes |

Velocity is measured in **points completed per sprint**, not points started. The PO does not "borrow" capacity from future sprints.

---

## 13. Anti-patterns to reject in backlog grooming

In addition to anti-patterns called out per section above, the BA Lead and PO actively reject:

| Anti-pattern | Why |
|---|---|
| "Tech-debt" stories that have no operator-facing outcome | Either it improves a parity AC, or it's an engineering task — not a user story |
| Stories that exist "to enable future stories" with no immediate value | Fold into the future story or treat as a foundational task in P1a |
| "As a developer, I want…" stories | Engineering tasks, not user stories — track in P1a or as tasks |
| Stories without operator SME contact | DoR fails; cannot enter refinement |
| Stories that span 2+ sprints | Not split enough — block sprint commitment |
| Stories with NFR ACs but no NFR addendum | Force the NFR taxonomy use; reject otherwise |
| Stories without audit AC where state changes | Most common DoR failure for switching workflows; reject without exception |

---

## 14. How this pipeline meets Phase 0 Discovery output volume

| Discovery output | Pipeline path |
|---|---|
| 600+ features | → distributed across 6 cores + monitors as Features |
| 650+ FRs | → woven into ACs of relevant stories (FRs are not stories themselves) |
| 1000+ business rules | → encoded into ACs and domain-logic tests; sampling-based reviewed for coverage during sprint |

**Estimated story count for full program:** 1500–2500 stories (depending on splitting discipline). MVP target: 80–150 stories given partial-FMS scope and 20% new-value allocation. Incremental build: the remainder, distributed by app per the proposed sequence in B1.

This is a planning estimate, not a commitment. Actual count emerges from refinement.

---

## 15. Adoption checklist for the PMO

To stand this pipeline up at the start of P1:

- [ ] PO + BA Lead trained on this guide
- [ ] Templates 06–12 added to Azure DevOps work-item templates
- [ ] DoR / DoD added as required checklist on every story type
- [ ] AC patterns (A/B/C/D) added as templates in AC field
- [ ] `[REG]` tag created and configured for filtering
- [ ] New-value coverage metric configured in dashboard
- [ ] Sprint review template includes operator-panel demo segment
- [ ] Story-rejection authority delegated explicitly to Engineering Lead
- [ ] Anti-pattern list shared with all backlog contributors
- [ ] First refinement session run with this guide as the rulebook
