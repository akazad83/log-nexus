# Technical Architecture Outline — Switching Order Modernization

**Artifact ID:** B2.7
**Status:** Draft for Architecture Council review
**Audience:** Architecture Council, Engineering Leads, Security, Operations Readiness
**Pairs with:** [04-network-boundary-design.md](04-network-boundary-design.md)

This is an **outline**, not a final design document. It establishes principles, component layers, integration patterns, and the critical boundary behaviors that B4 estimates and B5 build artifacts must align to. Detailed designs (per-service DDD modeling, API contract specifications, sequence diagrams for every workflow) are produced inside Phase 1 (P1) against this outline.

---

## 1. Architectural principles (non-negotiable)

These are framing decisions. Every later design choice must be traceable to one of these.

| # | Principle | Why |
|---|---|---|
| 1 | **Operator workflow parity is the primary design driver.** | Three sponsor non-negotiables converge here. UI/UX changes require named justification + operator co-design. |
| 2 | **OT/IT segmentation is preserved.** | OpNET / DMZ / CorpNET zones are infrastructure law. No design erodes them. |
| 3 | **EMS/XA21 is a passive integration peer — they poll us, we never connect outbound.** | Confirmed by sponsor. Defines the entire EMS integration shape. |
| 4 | **Audit trail is regulatory, not optional.** | Every operator action and every state transition is durably logged with operator identity and timestamp. |
| 5 | **Zero unplanned outage tolerance during cutover.** | Drives staggered cutover (Option A), standby OpNET environment, and rollback design. |
| 6 | **Modular service architecture, not monolith and not microservices.** | Right-sized for an internal team of 15–20 with no hard deadline. Per-service deployment without per-service infra duplication. See §4. |
| 7 | **Idempotent integrations.** | Every cross-service and cross-system message handles replay. Polling integrations require this; we have a polling integration. |
| 8 | **Schema-per-service in a shared SQL Server instance.** | Avoid premature physical decomposition; preserve transactional integrity within bounded contexts; cross-schema access goes through service APIs only. |
| 9 | **Observability is a first-class workstream, not a build-time afterthought.** | Safety-critical operations require operational visibility from day 1 of MVP. |
| 10 | **Standby OpNET environment is functionally equivalent, not degraded.** | Islanding scenarios cannot run with a "best-effort" backup. |

---

## 2. Logical architecture — component layers

```mermaid
flowchart TB
    subgraph Presentation
        OPS_UI[Operator Console<br/>Angular SPA]
        MON_UIs[Monitor Apps<br/>Angular components]
        REPORT_UI[Reporting Tier<br/>Read-only views on CorpNET]
    end

    subgraph BFF [Backend-for-Frontend]
        BFF_API[BFF / API Gateway<br/>.NET 8/9]
    end

    subgraph CoreServices [Core Domain Services - .NET 8/9]
        FMS[FMS Service]
        TOMS[TOMS Service]
        DSO[DSO Service]
        TLS[TLS Service]
        SDS[SDS Service]
        DBM[DBM Service<br/>Foundational hierarchy]
        MSG[Messaging Module<br/>operator desk streams]
        TASK[Task Manager<br/>per-operator orchestration]
    end

    subgraph SharedInfra [Shared Infrastructure]
        IDP[Identity Provider<br/>AD / Entra hybrid]
        BROKER[(SQL Server<br/>Service Broker + queue tables)]
        AUDIT[(Audit + Temporal<br/>SQL Server)]
        OBS[Observability<br/>OpenTelemetry collectors<br/>+ on-prem ELK or equivalent]
    end

    subgraph DataPlane [Data Plane - SQL Server 2025 Enterprise]
        DB_PRIMARY[(Primary DB<br/>CorpNET<br/>schema-per-service)]
        DB_STANDBY[(Standby DB<br/>OpNET<br/>continuous replication)]
    end

    subgraph IntegrationLayer [Integration Layer]
        EMS_GW[EMS Polling Endpoint<br/>OpNET-resident]
        RR_GW[Rapid Restore Adapter<br/>CorpNET]
        EXT_GWs[GIS / FeederBoard / CPMS<br/>adapters]
        SOAP_LEGACY[Legacy SOAP wrappers<br/>where required]
    end

    OPS_UI --> BFF_API
    MON_UIs --> BFF_API
    REPORT_UI --> BFF_API
    BFF_API --> CoreServices
    CoreServices --> BROKER
    CoreServices --> DB_PRIMARY
    CoreServices --> AUDIT
    CoreServices --> IDP
    CoreServices --> OBS
    DB_PRIMARY -. continuous replication .-> DB_STANDBY
    CoreServices --> EMS_GW
    CoreServices --> RR_GW
    CoreServices --> EXT_GWs
    CoreServices --> SOAP_LEGACY
```

### Layer responsibilities

| Layer | Responsibility | Out of scope |
|---|---|---|
| Presentation | Render operator workflows; preserve mental-model parity; render monitor dashboards | Business logic; data transformation beyond display |
| BFF / API Gateway | Aggregate calls per screen; enforce auth on every request; translate REST ↔ internal contracts; rate-limit | Domain logic; cross-service orchestration of business rules |
| Core Domain Services | Bounded-context business logic; state machines; business rule enforcement; transactional boundaries | UI concerns; cross-service joins |
| Shared Infrastructure | Identity, messaging, audit, observability — used by all services, owned by no service | Domain logic |
| Data Plane | Durable storage; temporal/audit tables; partitioning; replication | Logic execution |
| Integration Layer | External system contracts; protocol translation; idempotency; circuit-breaking | Domain rules |

---

## 3. Service inventory (initial)

This is the proposed set of deployable services. Each has its own IIS app pool, its own DB schema, and its own CI/CD pipeline. They share infrastructure (DB instance, broker, identity, observability).

| Service | Purpose | Bounded context |
|---|---|---|
| **FMS** | Distribution feeder switching workflow | Distribution feeder cards, tags, authorizations |
| **TOMS** | Transmission feeder switching workflow | Transmission feeder cards, tags |
| **DSO** | Dielectric system switching | Dielectric feeders |
| **TLS** | Telephonic line systems (EMS↔RTU connectivity) | Carrier, route, comm-path management |
| **SDS** | Steam systems | Steam operations |
| **DBM** | Power system / utility hierarchical data model + system data + configurations | Foundational reference data: substations, feeders, breakers, circuits, equipment hierarchies |
| **Messaging Module** | Operator-desk message streams (incoming/outgoing); triggers workflow validations and safety checks | Inter-operator and inter-system messages |
| **Task Manager** | Orchestrate tasks associated with each operator | Per-operator task lifecycle |
| **EMS Polling Endpoint** | Passive endpoint EMS polls — exposes outbound queue, accepts inbound events | EMS interface contract |
| **Rapid Restore Adapter** | CorpNET-side handoff to field crews via Rapid Restore | Field execution contract |
| **External Adapters** | GIS, FeederBoard, CPMS, etc. (one adapter per external system) | Per-system integration contract |

### Why this decomposition (and not microservices)

- **Service boundaries match operator mental boundaries** — FMS is a service because operators think of FMS as a system. Mapping technology to operator mental model is the entire point of parity.
- **Per-service deployable** without per-service infrastructure duplication — shared DB instance with schema isolation, shared broker, shared identity. The cost of microservices' per-service infra (per-service DB, per-service ops) is not justified by team size.
- **Easier transactional integrity within a service** — switching workflow is rich in invariants (you can't authorize a card that's not de-energized). Keeping each workflow's state machine in a single service's DB is a strong design property.
- **Cross-service contracts via async messages by default**, REST where synchronous needed — supports loose coupling without microservices' operational tax.

### Trade-offs being accepted

| Trade-off | Cost | Mitigation |
|---|---|---|
| Shared DB instance — DB outage affects all services | Single failure domain on storage | Standby OpNET DB; AlwaysOn AG; partitioning; per-schema permissions |
| Schema isolation enforced by convention + permissions, not physical separation | Risk of cross-schema joins sneaking in | Code review checks; `dbo` access denied; only service accounts have schema access |
| Deployment coordination across services needed for cross-service contract changes | Releases must coordinate | Versioned contracts; consumer-driven tests; contract test gate in CI |
| Hard to scale one service independently of another | Some compute waste | Acceptable given team size and load profile |

---

## 4. Cross-cutting concerns

### 4.1 Identity & authorization

- **Identity provider:** on-prem AD with Entra hybrid (assume — confirm with SecOps).
- **Authentication:** Windows Integrated Authentication for operator console; OAuth2 for service-to-service; certificate-based for cross-zone (DMZ ↔ CorpNET).
- **Authorization model:** Role-Based Access Control (RBAC) with district + workflow-step granularity.
  - Roles: District Operator, District Supervisor, Field Crew Lead, Read-Only Auditor, System Admin, Compliance Officer
  - Permissions scoped by district + by workflow step (e.g., "can authorize but cannot create" for supervisors)
- **Audit hook:** every authorization decision (allow/deny) logs the principal, action, target, timestamp, and decision.
- **Operator identity is non-impersonatable** — every operator action carries the operator's unique identity to the audit log; service accounts cannot perform operator actions.

### 4.2 Observability

Three pillars. Vendor-neutral instrumentation; on-prem collectors per zone.

| Pillar | Tooling | Notes |
|---|---|---|
| Logs | Structured logs via Serilog → on-prem ELK (or equivalent) | Logs include correlation IDs propagated across services |
| Metrics | OpenTelemetry → Prometheus (or on-prem Grafana Mimir) | RED metrics per service; SLOs per workflow step |
| Traces | OpenTelemetry → Jaeger or on-prem Tempo | Traces span BFF → Service → DB and cross-service async (broker) |

**Design rule:** every operator-facing workflow has a named SLO (e.g., "card creation latency p99 < 800ms"). SLOs are reviewed at sprint demo, not at incident time.

### 4.3 Audit & traceability

Two distinct audit surfaces — these are different concerns and should not be conflated:

| Audit | What it captures | Storage | Retention |
|---|---|---|---|
| **Entity history** | Every change to a domain entity (switching card, tag, authorization) | SQL Server temporal tables, automatic | 7 years (per A-005) |
| **Operator action log** | Every operator action with full context (who, what, when, where, why) | Append-only audit table per service + program-wide aggregate | 7 years |
| **Authorization decision log** | Every allow/deny decision by the auth layer | Append-only auth-decision table | 7 years |
| **Integration call log** | Every cross-system call (EMS poll, Rapid Restore handoff) with full payload | Append-only integration log + payload archive | 7 years |

Audit data is **never in-place updated**. Append-only. Tamper-evident via hash chain on the operator action log (each row hashes the previous row).

### 4.4 Security

- **Secrets management:** on-prem secret store (assume Azure DevOps Library + an HSM-backed solution; confirm in P1). No secrets in code, in config files, or in pipelines.
- **SAST:** CodeQL in Azure DevOps pipeline (acceptable; alternative is SonarQube Enterprise — see B5 DevOps blueprint for trade-off comparison).
- **DAST:** OWASP ZAP in nightly pipeline against Pre-Prod.
- **Dependency scanning:** OWASP Dependency-Check or equivalent; weekly + on every PR.
- **Threat model:** STRIDE-based threat model produced per service in P1; reviewed quarterly thereafter.
- **OT/IT boundary:** see [04-network-boundary-design.md](04-network-boundary-design.md).

### 4.5 Configuration & secrets

- Configuration in versioned config files per environment (Dev / SIT / Pre-Prod / Prod / Standby).
- Secrets never in config files — referenced by name from secret store.
- No environment variable secrets in process — secrets pulled at startup from secret store with short-TTL cache.

### 4.6 Resilience patterns

| Pattern | Where applied |
|---|---|
| Circuit breaker | All external integrations (EMS, Rapid Restore, GIS, etc.) |
| Bulkhead | Per-integration thread pools / connection pools |
| Retry with exponential backoff + jitter | Idempotent operations only |
| Idempotency keys | All cross-service messages and external integration calls |
| Outbox pattern | Service → Broker writes (avoids dual-write to DB + queue) |
| Saga pattern | Long-running cross-service workflows (e.g., card lifecycle spanning de-energize → authorize → execute) |

---

## 5. Integration patterns

### 5.1 Internal communication

| Communication | Pattern | Tooling |
|---|---|---|
| UI → BFF | REST + JSON | HTTPS, mTLS optional inside CorpNET |
| BFF → Service | REST + JSON | Internal mTLS |
| Service → Service (sync) | REST + JSON | Internal mTLS; circuit-broken |
| Service → Service (async) | Domain events on broker | SQL Server Service Broker for transactional fanout; queue tables for simple reliable delivery |
| Service → DB | EF Core | Per-service DB schema; no cross-schema reads |
| Service → Audit | Direct DB write within transactional boundary | Avoids audit loss during failure |

### 5.2 External integrations

| External | Pattern | Initiator | Sync/Async |
|---|---|---|---|
| **EMS/XA21** | Passive polling endpoint (OpNET) | EMS polls us | Async (long-poll or scheduled) |
| **Rapid Restore** | REST API (CorpNET adapter) | Either side | Sync for handoff; async for status updates |
| **GIS** | REST + scheduled batch | We initiate | Mixed |
| **FeederBoard** | REST | We initiate | Sync read; async push for board updates |
| **CPMS** | REST + scheduled reconciliation | We initiate | Mixed |
| **Other (15+ integrations)** | Per-system; documented in P1 integration contract | Mixed | Mixed |

### 5.3 Legacy SOAP wrappers

Some external systems still expose SOAP. Wrap each in a REST adapter inside our integration layer. SOAP stays at the edge; our internal services see only REST or events. Adapter responsibilities:

- WSDL-driven contract pinning
- SOAP fault → typed error translation
- Retry & circuit-break around the SOAP call
- Logging (request/response) to integration audit log

---

## 6. The EMS/XA21 boundary — most important integration

This is the load-bearing integration of the entire program. Every other integration is replaceable. EMS is not.

### 6.1 Boundary rules (sponsor-confirmed)

- EMS lives on the **EMS network** (separate segment, distinct from OpNET/DMZ/CorpNET).
- EMS **polls** our application suite for the data it consumes.
- Our application **never** initiates a connection to EMS, **never** pushes to EMS, **never** makes any request to EMS.

### 6.2 What that implies

We expose a passive endpoint that EMS polls. Two flows go through this endpoint:

1. **EMS reads from us** — EMS polls for outbound data (e.g., breaker-close instructions queued by operators, card statuses).
2. **EMS writes to us** — EMS posts events into our endpoint (e.g., breaker-trip events that trigger card auto-creation).

Both interactions are **EMS-initiated network connections.** Our endpoint is purely passive.

### 6.3 Where the endpoint lives

Logically, the endpoint sits in **OpNET** — the zone closest to the EMS network and the zone our standby system already occupies (see Section 4.103 of the original prompt). This minimizes cross-zone hops on a critical-path integration.

```mermaid
flowchart LR
    subgraph EMSnet [EMS Network]
        EMS[EMS / XA21]
    end

    subgraph OpNET
        EMS_EP[EMS Polling Endpoint<br/>passive REST + queue]
        STANDBY[Standby App + DB<br/>functionally equivalent]
    end

    subgraph CorpNET
        PRIMARY[Primary App + DB]
    end

    EMS -- polls / posts --> EMS_EP
    EMS_EP <-- replication --> PRIMARY
    EMS_EP <-- replication --> STANDBY
    PRIMARY <-- continuous replication --> STANDBY

    classDef ems fill:#FFE5B4,stroke:#D2691E
    classDef op fill:#FFD6D6,stroke:#B22222
    classDef corp fill:#D6E5FF,stroke:#1F3864
    class EMS ems
    class EMS_EP,STANDBY op
    class PRIMARY corp
```

### 6.4 Endpoint contract

| Endpoint | Method | Purpose | Idempotency |
|---|---|---|---|
| `GET /ems/outbound/instructions?since={cursor}` | EMS reads pending instructions | Cursor-based; EMS advances cursor on ack | Naturally idempotent (read) |
| `POST /ems/outbound/instructions/{id}/ack` | EMS acknowledges receipt of an instruction | Idempotent via instruction ID | ack table keyed by instruction ID |
| `POST /ems/inbound/events` | EMS posts a breaker-trip or other event | Idempotency key in payload | Reject duplicates by key |
| `GET /ems/heartbeat` | EMS health-checks our endpoint | None needed | — |

### 6.5 Standby behavior

- The polling endpoint runs identically on Primary (CorpNET) and Standby (OpNET). 
- During islanding (cyber event or CorpNET unreachable), EMS is unaware — it continues polling the endpoint that's still reachable on OpNET.
- All EMS-originated events landed during islanding are captured on the Standby DB and reconciled into Primary when CorpNET reachability returns.
- Outbound instructions queued on Primary that did not replicate to Standby before the event are flagged for operator re-issue (no auto-replay; operator confirms).

### 6.6 Why this design is defensible

| Question | Answer |
|---|---|
| What if the endpoint is unreachable? | EMS's poll fails; EMS retries per its own schedule. We don't lose data — events EMS holds will replay on next successful poll. We must publish a maintenance window plan. |
| What if we deploy a new version? | Endpoint contract is versioned; new version backward-compatible; deployment is rolling within OpNET. EMS sees no interruption. |
| What if the queue fills up? | Operational alert; we throttle creation of outbound instructions; never silently drop. |
| How do we test it without EMS? | Integration test harness simulates EMS polling behavior; vendor provides sample event payloads (per A-004). |

---

## 7. The Rapid Restore boundary

Field crews use Rapid Restore on CorpNET to execute switching steps. Rapid Restore is the consumer of our authorized switching steps.

### 7.1 Boundary rules

- Rapid Restore lives on **CorpNET**.
- Our adapter and Rapid Restore communicate via REST.
- Hand-off is bidirectional but bounded: we send authorized steps; Rapid Restore returns execution status and field results.

### 7.2 Pattern

```mermaid
sequenceDiagram
    autonumber
    participant Op as Operator
    participant FMS as FMS Service
    participant RR as Rapid Restore Adapter
    participant Field as Rapid Restore (CorpNET)

    Op->>FMS: Authorize step
    FMS->>FMS: Persist authorization + audit
    FMS->>RR: Hand off step (REST POST)
    RR->>Field: Translate + forward
    Field-->>RR: Step accepted (sync)
    RR-->>FMS: Hand-off confirmed
    Note over Field: Field crew executes step
    Field-->>RR: Status update (push or poll)
    RR->>FMS: Update step status (event on broker)
    FMS->>FMS: Persist status + audit
    FMS-->>Op: Reflect status in console
```

### 7.3 Failure modes & handling

| Failure | Behavior |
|---|---|
| Rapid Restore unreachable | Step held in "pending hand-off" state with retry; operator notified after threshold; manual fallback to phone confirmation |
| Rapid Restore returns error | Operator sees error in console; corrective action surfaced |
| Field reports step failure | Step state machine moves to "failed"; operator must re-issue or abort card |
| Status update lost | Reconciliation job (15-min cadence) cross-checks Rapid Restore vs. our state and surfaces drifts |

---

## 8. Critical data flow scenarios

Three flows that exercise most architectural decisions. Each must work in MVP.

### 8.1 EMS event → switching card auto-creation

```mermaid
sequenceDiagram
    autonumber
    participant EMS
    participant EP as EMS Endpoint (OpNET)
    participant Repl as Replication
    participant FMS as FMS Service (CorpNET)
    participant Audit
    participant Op as Operator Console

    EMS->>EP: POST /ems/inbound/events (breaker-trip)
    EP->>EP: Validate idempotency key
    EP->>EP: Persist event (durable)
    EP-->>EMS: 202 Accepted
    EP->>Repl: Replicate event row
    Repl->>FMS: Event available
    FMS->>FMS: Apply business rules (auto-create card?)
    FMS->>FMS: Create card (state: New)
    FMS->>Audit: Log card creation + source event
    FMS->>Op: Push notification (SignalR or polling)
    Op->>Op: Operator reviews card
```

Critical properties:
- EMS endpoint never depends on CorpNET reachability for accepting events (durability guaranteed in OpNET)
- Card creation is a separate transaction from event ingestion (so that ingestion never fails because of card-creation rules)
- Idempotency at endpoint guarantees duplicate events from EMS retry don't create duplicate cards

### 8.2 Operator authorizes step → field execution → status update

(Covered in §7.2 above.)

### 8.3 Card close → breaker-close instruction back to EMS

```mermaid
sequenceDiagram
    autonumber
    participant Op as Operator
    participant FMS
    participant Q as Outbound Instruction Queue (OpNET)
    participant EMS

    Op->>FMS: Issue breaker-close instruction (close card)
    FMS->>FMS: Validate state (all steps closed, all conditions met)
    FMS->>FMS: Persist instruction + audit (entity history + operator action)
    FMS->>Q: Append to outbound queue (replicated to OpNET)
    FMS-->>Op: Instruction queued
    EMS->>Q: GET /ems/outbound/instructions?since=cursor
    Q-->>EMS: Returns instruction
    EMS->>EMS: Apply close to breaker
    EMS->>Q: POST /ems/outbound/instructions/{id}/ack
    Q->>FMS: Ack event on broker
    FMS->>FMS: Mark instruction acknowledged + audit
    FMS-->>Op: Reflect close confirmation
```

Critical properties:
- Instruction is durably persisted before operator sees confirmation
- EMS poll cadence determines latency; this is acceptable given operator workflow timing
- Operator console reflects ack only when EMS has confirmed, not on queue placement (avoids false-confirm UX)

---

## 9. Standby & islanding architecture

Section 4.103 of the original prompt requires an OpNET standby for cyber events and islanding. This section specifies behavior.

### 9.1 Steady-state

- Primary application + DB on CorpNET (active read/write)
- Standby application + DB on OpNET (continuously synchronized via SQL Server AlwaysOn AG with synchronous commit)
- EMS Polling Endpoint runs in **both** zones; OpNET copy is the EMS-facing instance during steady state
- Reporting tier on CorpNET reads from the primary

### 9.2 Cyber event / islanding trigger

- Trigger conditions: detection of cyber event affecting CorpNET; loss of CorpNET-OpNET link beyond threshold; manual operator declaration
- Standby promoted to active read/write within target RTO (TBD — see open questions)
- Operator console redirects to OpNET standby
- EMS continues polling the OpNET endpoint without behavior change
- Rapid Restore integration is **degraded** in islanded mode (CorpNET-side) — fallback to phone confirmation; this is operationally acceptable but must be documented in cutover playbook

### 9.3 Recovery

- Reverse replication (OpNET → CorpNET) when link restored
- Reconciliation harness validates row-level fidelity before promotion back
- Promote primary back to CorpNET only after operator + ops sign-off
- Audit log captures all actions taken during islanding; merged into program-wide audit

---

## 10. Frontend architecture (Angular)

Operator console is the most-scrutinized surface of the entire program. M-06 turns on it.

| Concern | Approach |
|---|---|
| State management | NgRx (recommended) with strict feature-state isolation per app | 
| Routing | Lazy-loaded module per core service (FMS, TOMS, …) |
| Real-time updates | SignalR over WebSocket from BFF; fallback to polling |
| Offline behavior | Read-only cache for last-known card state during transient connection loss; reject writes (operators must know they're offline) |
| Theming / design system | Single design system component library; mental-model parity with legacy where required |
| Accessibility | WCAG 2.2 AA target |
| Testing | Component tests (Karma/Jest); E2E (Playwright) with operator-flow scenarios |

**Mental-model parity is enforced by an operator panel review at every sprint demo, not at UAT.** Catch parity gaps in design, not in test.

---

## 11. Backend architecture (.NET 8/9)

| Concern | Approach |
|---|---|
| Service hosting | ASP.NET Core on IIS (HTTP.sys + Kestrel; assume IIS process model) |
| Data access | EF Core 8/9 with explicit `IDbContextFactory<>` per scope; no global context |
| Domain modeling | Domain-Driven Design — aggregates, value objects, domain events; explicit anti-corruption layer per external integration |
| Validation | FluentValidation at boundary; domain invariants enforced inside aggregates |
| Mediator | MediatR for CQRS-style command/query separation (recommended for the workflow-heavy services) |
| Background work | Hangfire on SQL Server (already in stack) for scheduled and durable jobs |
| Error contracts | RFC 7807 problem-details for REST errors |
| API versioning | URL segment versioning (`/api/v1/...`) — simple, explicit, ops-friendly |

---

## 12. Data architecture

Detailed design lives in the B5 deliverable [#9 Database Design Principles]. This section sets the architectural framing only.

| Concern | Approach |
|---|---|
| Engine | SQL Server 2025 Enterprise on CorpNET (primary); standby on OpNET |
| HA/DR | AlwaysOn Availability Group, synchronous commit between primary and standby; automatic failover on health-check failure |
| Schema strategy | Schema-per-service in single instance; cross-schema access only via service APIs |
| Audit & temporal | SQL Server temporal tables on every domain entity; explicit audit tables for operator actions and integration calls |
| Partitioning | Time-based partitioning on high-volume tables (audit, operator action log, integration log) — partition by month, retain 7 years |
| Indexing | Workload-based; reviewed quarterly |
| Read replicas | Read-only replica on CorpNET for the reporting tier (Section 4 OT/IT model — CorpNET reporting tier reads only) |
| Native messaging | SQL Server Service Broker for transactional fanout; queue tables for simple reliable delivery patterns (per stack decision) |

---

## 13. Open architecture decisions for P1

These are decisions B2 deliberately defers to Phase 1 detailed design. Listed here so they're not forgotten:

| ID | Decision | Driver |
|---|---|---|
| AD-01 | Confirm AD vs. Entra hybrid for identity | SecOps preference; existing infra |
| AD-02 | Confirm OpenTelemetry collector topology per zone | Network team approval |
| AD-03 | Choose Service Broker vs. queue tables for each async pattern | Performance test in P1a |
| AD-04 | Define RTO/RPO targets for islanding scenario | Operations + Compliance |
| AD-05 | Confirm Hangfire vs. alternative for background jobs | Developer experience eval |
| AD-06 | Define SLO targets per workflow step | Operations input |
| AD-07 | Confirm secrets management vendor on-prem | SecOps |
| AD-08 | Confirm IIS process model (in-process vs. out-of-process for ASP.NET Core) | Performance test in P1a |
| AD-09 | Confirm SignalR vs. polling default for real-time updates | Network constraints |
| AD-10 | Confirm specific NgRx vs. lighter-weight state mgmt for Angular | Frontend lead preference |

---

## 14. What this outline does not yet specify

To pre-empt scope creep on this document — these belong in subsequent artifacts, not here:

- Detailed sequence diagrams for every workflow (P1 detailed design)
- Per-service domain models (P1 detailed design)
- API contract specifications (P1 detailed design)
- Threat models per service (P1 detailed design)
- Performance test plans (B5 #11 test strategy)
- DR runbooks (B5 #11 cutover playbook outline)
- DB sizing and partition design (B5 #9 DB principles)
- Specific identity flow diagrams (P1 detailed design after AD-01)
- Specific monitoring dashboards (B5 #12 DevOps blueprint)
