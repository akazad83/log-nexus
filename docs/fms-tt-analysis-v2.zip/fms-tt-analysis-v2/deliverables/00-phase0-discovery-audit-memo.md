# Phase 0 Discovery Audit Memo

**Status:** Draft for sponsor sign-off
**Author:** Principal Solution Architect (modernization program)
**Audience:** Program sponsor, delivery lead, head of operations
**Decision required:** Approval to spend 2–3 elapsed days on Discovery audit before Phase 1 detailed design begins
**Effort:** 1 lead BA + 1 principal engineer + ~30 min/operator/app (≈ 3 person-days total)

---

## 1. Why this memo exists

Phase 0 Discovery has produced:

- 600+ identified features
- 650+ functional requirements
- 1,000+ critical business rules
- Inventory of 6 cores, 30–35 monitors, 15–20 integrations

Phase 1 detailed design and every artifact downstream — backlog, estimates, resource plan, cutover playbook — will be **built on top of those numbers**. If 30% of the business rules are analyst-inferred without 4GL code traceability, the resulting plan inherits that shakiness silently and reveals it during build, when it's expensive to fix and damaging to sponsor confidence.

This memo proposes a **3-day audit with a binary outcome per dimension**: trust as-is, trust with remediation, or remediate before planning.

This is not a redo of Discovery. This is a stress-test of Discovery's outputs.

---

## 2. The single largest known failure mode for 4GL modernizations

Hidden business rules in legacy code. OpenRoad/Ingres applications routinely contain 20–40% more rule logic than analysts capture in interviews — because:

1. Operators have internalized the rules to muscle memory and don't articulate them.
2. The 4GL code expresses many rules as imperative side effects, not declarative statements.
3. Edge-case rules ("if the breaker is in test mode AND the tag was issued by a substation operator AND it's during an islanding event…") only surface when developers try to encode them.

A 1,000-rule corpus that is 80% analyst-inferred (versus code-traced) is, statistically, hiding **200–400 additional rules** that will surface during build. That converts a 24-month plan into a 36-month plan, with sponsor confidence destroyed in month 18.

**Skipping this audit is a known, avoidable failure mode.**

---

## 3. Audit dimensions

Ten dimensions. Each has a sampling method and a Red/Amber/Green decision criterion.

| # | Dimension | What we check | Sampling method | RAG criterion |
|---|---|---|---|---|
| 1 | **Source traceability** | Every Discovery item links to a verifiable source: operator interview, doc, or 4GL code reference | 30 random items from each of: features, FRs, business rules | G: ≥90% traceable · A: 70–89% · R: <70% |
| 2 | **Operator validation coverage** | % of features operator-confirmed in workshop vs. analyst-inferred | Cross-reference workshop attendance log + sign-off list | G: ≥80% confirmed · A: 60–79% · R: <60% |
| 3 | **4GL code triangulation** | Critical workflows have at least one read of the OpenRoad code, not just operator narrative | 5 critical workflows per app × 6 apps = 30 spot-checks | G: 5/5 per app · A: 3–4/5 · R: <3/5 |
| 4 | **Granularity consistency** | Features at consistent altitude (workflow step or system capability), not mixed with task-level items | Histogram of feature size in story-point-equivalent | G: tight distribution · A: bimodal · R: chaotic |
| 5 | **Business rule encoding precision** | Rules expressed as testable IF/THEN logic, not narrative paragraphs | Sample 50 rules; classify as encoded vs. narrative | G: ≥75% encoded · A: 50–74% · R: <50% |
| 6 | **Aspirational vs. actual** | Items that are "as it should be" are explicitly tagged separately from "as it is" | Audit metadata schema | G: tag exists and is used · A: tag exists, inconsistently used · R: no distinction |
| 7 | **Conflict & duplication** | Rule conflicts within and across the 6 apps | Automated duplicate detection + manual sweep on top 20% by criticality | G: ≤5 conflicts · A: 6–25 · R: >25 |
| 8 | **Integration contract coverage** | For 15–20 integrations, payload/contract is captured (not just system name) | Per-integration checklist: schema? sample message? error semantics? | G: ≥80% with contract · A: 50–79% · R: <50% |
| 9 | **Audit/regulatory rule completeness** | Compliance rules are tagged separately and traceable to the regulator citation that drives them | Tag-based scan + spot-cite verification | G: tagged + cited · A: tagged not cited · R: neither |
| 10 | **Hidden behavior risk per app** | Has anyone read the OpenRoad code end-to-end for at least one critical workflow per app? | Confirm per app | G: 6/6 apps · A: 4–5/6 · R: <4/6 |

### Why these ten and not more

I am deliberately **not** auditing things that don't change planning behavior — completeness percentages, narrative quality, document formatting. Audit fatigue produces theater. Each dimension above will, if Red, change what we do in Phase 1. That is the bar.

---

## 4. Method & effort

| Day | Activity | Owner |
|---|---|---|
| Day 1 | Dimensions 1–3 (traceability + operator validation + 4GL spot-reads) | Lead BA + Principal Engineer |
| Day 2 | Dimensions 4–7 (granularity, encoding, aspirational, conflicts) | Lead BA |
| Day 3 | Dimensions 8–10 (integrations, regulatory, end-to-end 4GL deep-read per app) | Principal Engineer + 1 operator per app (30 min each) |

Total: 3 elapsed days. ~3 person-days of effort plus ~3 hours of operator time across 6 apps.

This is not negotiable down. Compressing to 1 day means dimension 3 (4GL triangulation) and dimension 10 (hidden behavior risk) get skipped — those are precisely the ones that matter.

---

## 5. Decision matrix

After the audit, every dimension is Green, Amber, or Red. The composite outcome drives one of three actions:

| Composite | Action | Cost impact |
|---|---|---|
| **All Green** | Proceed to Phase 1 with Discovery as-is | None |
| **Any Amber, no Red** | Proceed to Phase 1; add remediation epics for each Amber dimension to the backlog | +5–10% effort across Phase 1 |
| **Any Red** | **Stop Phase 1 planning for that domain.** Re-run targeted discovery for that dimension before plans depend on it | +2–6 weeks per Red dimension |

The two highest-stakes Reds — by my judgment — are **dimension 3 (4GL triangulation)** and **dimension 10 (hidden behavior per app)**. If either comes back Red, no estimation worksheet produced before remediation will be defensible.

---

## 6. Output of the audit

Two artifacts, decision-ready in 3 days:

1. **One-page RAG dashboard.** Ten dimensions, color-coded, with the count of items sampled and the count that passed.
2. **Two-page recommendation memo.** Per-dimension finding, root-cause hypothesis where Amber/Red, and the remediation cost if Amber/Red.

That's it. No 40-page audit report. The point is the decision, not the documentation.

---

## 7. Risks if this audit is skipped

Listed in order of severity:

1. **Estimation worksheet (B4) becomes fiction.** Three-point estimates rely on a stable scope baseline. If scope is shaky, the worst-case column quietly becomes the likely column.
2. **MVP scope drifts during build.** Operators surface "missed" rules in UAT, not design — converting MVP from a 6-month effort into a 9–10-month one.
3. **Cutover playbook gaps.** Hidden integration semantics surface during dress rehearsal at the earliest, in production at the worst.
4. **Sponsor confidence collapse.** Programs that overshoot in month 18 by 30%+ rarely survive a budget review even when the team is strong. Internal political damage outlasts the engineering damage.

---

## 8. Recommendation

**Approve the 3-day audit. Run it before Phase 1 design begins, not in parallel.**

Running it in parallel is a false economy: design teams will start producing artifacts against an unaudited baseline, and re-baselining mid-design is more expensive than starting 3 days later.

If the audit comes back all-Green, you've spent 3 days for confidence. If it comes back with Reds, you've spent 3 days to avoid burning 2–3 months later in the program. Either way, the math favors running it.

---

## 9. What happens after this memo is signed

1. **Day 0 (this week):** Memo approved. Audit team identified (1 lead BA, 1 principal engineer, operator time blocked).
2. **Days 1–3:** Audit executed.
3. **Day 4:** Findings reviewed with program sponsor + delivery lead. Decision recorded against decision matrix above.
4. **Day 5+:** Phase 1 detailed design starts on either the as-is Discovery baseline (Green), the remediated baseline (Amber), or a pause-and-re-discover plan (Red).

Phase 1 should not start before Day 5, and should not start without a recorded decision against this matrix.

---

**Next decision needed from sponsor:** approve the audit (yes/no), and confirm operator availability (≈30 min × 6 operators within a 3-day window).
