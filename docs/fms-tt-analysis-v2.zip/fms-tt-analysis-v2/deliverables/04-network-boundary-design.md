# Network & Boundary Design — Switching Order Modernization

**Artifact ID:** B2.10
**Status:** Draft for SecOps + Architecture Council review
**Audience:** SecOps, Network Engineering, Architecture Council, Compliance
**Pairs with:** [03-technical-architecture-outline.md](03-technical-architecture-outline.md)

This document specifies the zone-by-zone responsibilities, allowed protocols, gateway behavior, and failure modes for the modernized application's deployment across the segmented network. It is the load-bearing security artifact of the program. Every later operational decision is constrained by this design.

---

## 1. Threat model context (why this matters)

Switching operations are safety-critical and regulator-watched. The network design exists to defend against three threat classes simultaneously:

| Threat class | Example | Defensive approach |
|---|---|---|
| **External cyber attack** | Adversary on Internet attempting OT compromise | OT/IT segmentation; no inbound paths from Internet to OpNET |
| **Lateral movement after IT compromise** | Adversary on CorpNET attempting to pivot to OpNET | DMZ-mediated traffic only; protocol restrictions; mutual auth |
| **Compromise of EMS network** | Adversary on EMS network attempting to pivot through us | EMS endpoint is passive; we never trust EMS-originated requests beyond the contract; EMS network treated as untrusted peer |

The Purdue Model alignment is **mandatory**, not aspirational. This design follows it.

---

## 2. Zone topology

```mermaid
flowchart TB
    subgraph Internet["Internet (untrusted)"]
        EXT[External users / vendors]
    end

    subgraph CorpNET ["CorpNET — IT zone (Purdue Level 4-5)"]
        OP_DESKS[Operator desktops]
        REPORT_TIER[Reporting tier - read-only]
        BFF_PRIMARY[BFF / API Gateway - primary]
        CORE_SERVICES[Core domain services<br/>FMS, TOMS, DSO, TLS, SDS, DBM]
        DB_PRIMARY[(Primary SQL Server 2025<br/>+ AlwaysOn AG)]
        BROKER[Service Broker / queue tables]
        OBS_CORP[Observability collectors]
        IDP[Identity provider]
        RR_INT[Rapid Restore<br/>integrated app]
        RR_ADAPTER[Rapid Restore adapter]
        EXT_ADAPTERS[External adapters<br/>GIS / FeederBoard / CPMS]
    end

    subgraph DMZ ["DMZ — controlled boundary (Purdue Level 3.5)"]
        APP_GW[Application Gateway / WAF]
        REPL_BROKER[Replication broker<br/>CorpNET ↔ OpNET]
        AUDIT_FORWARD[Audit forwarder<br/>OpNET → CorpNET]
        EXT_GW[External integration gateway<br/>vendor APIs]
    end

    subgraph OpNET ["OpNET — OT zone (Purdue Level 2-3)"]
        STANDBY_APP[Standby application services<br/>functionally equivalent]
        STANDBY_DB[(Standby SQL Server<br/>AlwaysOn AG replica)]
        EMS_EP[EMS Polling Endpoint<br/>passive REST + queue]
        OBS_OP[Observability collectors]
    end

    subgraph EMSnet ["EMS Network (separate OT segment)"]
        EMS[EMS / XA21]
    end

    EXT --> APP_GW
    APP_GW -.-> REPORT_TIER

    OP_DESKS --> BFF_PRIMARY
    BFF_PRIMARY --> CORE_SERVICES
    CORE_SERVICES --> DB_PRIMARY
    CORE_SERVICES --> BROKER
    CORE_SERVICES --> OBS_CORP
    CORE_SERVICES --> IDP
    CORE_SERVICES --> RR_ADAPTER
    RR_ADAPTER --> RR_INT
    CORE_SERVICES --> EXT_ADAPTERS
    EXT_ADAPTERS --> EXT_GW
    EXT_GW -.-> EXT

    DB_PRIMARY <-- replication via REPL_BROKER --> STANDBY_DB
    OBS_OP -- forwarded via AUDIT_FORWARD --> OBS_CORP

    EMS -- polls / posts --> EMS_EP
    EMS_EP --> STANDBY_APP
    STANDBY_APP --> STANDBY_DB

    classDef internet fill:#FFFFFF,stroke:#999
    classDef corp fill:#D6E5FF,stroke:#1F3864,stroke-width:2px
    classDef dmz fill:#FFF7B4,stroke:#806600,stroke-width:2px
    classDef op fill:#FFD6D6,stroke:#B22222,stroke-width:2px
    classDef ems fill:#FFE5B4,stroke:#D2691E,stroke-width:2px
    class EXT internet
    class OP_DESKS,REPORT_TIER,BFF_PRIMARY,CORE_SERVICES,DB_PRIMARY,BROKER,OBS_CORP,IDP,RR_INT,RR_ADAPTER,EXT_ADAPTERS corp
    class APP_GW,REPL_BROKER,AUDIT_FORWARD,EXT_GW dmz
    class STANDBY_APP,STANDBY_DB,EMS_EP,OBS_OP op
    class EMS ems
```

---

## 3. Zone responsibilities

### 3.1 EMS Network (separate, sponsor-owned)

| Property | Value |
|---|---|
| Owner | EMS vendor + utility OT |
| Trust level | Untrusted peer |
| Communication with our system | EMS-initiated polling + posting only; we never connect inbound to EMS |
| Crosses to | OpNET only (via passive endpoint) |

**Design rule:** treat the EMS network as an untrusted peer despite its OT-zone status. Validate every EMS-originated request against contract; never extend trust based on source IP alone.

### 3.2 OpNET — OT zone (Purdue Level 2–3)

**Purpose:** Hosts the standby application stack and the EMS-facing endpoint. Operates standalone during islanding events.

**Resident components:**
- Standby application services (functionally equivalent to CorpNET primary)
- Standby SQL Server 2025 (AlwaysOn AG replica)
- EMS Polling Endpoint (passive REST + outbound queue)
- OpNET-side observability collector
- Local audit storage (replicated to CorpNET on schedule)

**Operating modes:**
1. **Steady state** — passive standby; only the EMS endpoint is actively serving (EMS polls always hit the OpNET-resident endpoint)
2. **Islanded** — standby promoted to active; serves operator console; EMS continues polling without behavior change

**Allowed inbound:**
| Source zone | Protocol | Purpose |
|---|---|---|
| EMS Network | HTTPS (TLS 1.3, mutual auth via vendor-managed certs) | EMS polling + event posting |
| DMZ | mTLS over a designated replication channel | DB replication, audit forward, config sync |

**Allowed outbound:**
| Destination zone | Protocol | Purpose |
|---|---|---|
| DMZ | mTLS | Reverse replication during islanding recovery; audit forward |
| (No outbound to EMS Network) | — | We never initiate to EMS, by design |
| (No outbound to Internet) | — | Hard rule |

**Hard restrictions:**
- No DNS resolution outside OpNET-resident DNS
- No Internet egress (no outbound proxy access from OpNET)
- No SSH from CorpNET; admin access only via DMZ-mediated jump host with PAM
- No cleartext protocols (HTTP, FTP, Telnet) — even within zone

### 3.3 DMZ — controlled boundary (Purdue Level 3.5)

**Purpose:** Mediates all CorpNET ↔ OpNET traffic. No business logic — only protocol policy enforcement, replication transport, and external integration gateway functions.

**Resident components:**
- Application Gateway / WAF (terminates TLS for external-facing read-only reporting; not core operator console)
- Replication broker (CorpNET ↔ OpNET DB replication and config sync)
- Audit forwarder (OpNET-originated audit data to CorpNET central audit)
- External integration gateway (outbound calls to GIS, FeederBoard, CPMS, etc.)

**Allowed inbound:**
| Source zone | Protocol | Purpose |
|---|---|---|
| Internet (limited) | HTTPS to App Gateway (read-only reporting tier only — not core console) | External vendor / regulator access; if not required, drop this entirely |
| CorpNET | mTLS | App-to-app to External GW; replication initiator |
| OpNET | mTLS | Replication initiator (during recovery); audit forward |

**Allowed outbound:**
| Destination zone | Protocol | Purpose |
|---|---|---|
| CorpNET | mTLS | Replication and audit forward delivery |
| OpNET | mTLS | Replication and config sync delivery |
| Internet | HTTPS | External integration gateway only — outbound, no inbound |

**Hard restrictions:**
- No direct CorpNET ↔ OpNET path; everything goes through DMZ-resident brokers
- No application services run logic in DMZ — DMZ is for transport and policy only
- No persistent business data stored in DMZ (transient buffer only, e.g., replication queues with short TTL)

### 3.4 CorpNET — IT zone (Purdue Level 4–5)

**Purpose:** Active production tier for the application suite during steady state. Hosts operator console, BFF, all core domain services, primary database, integration adapters (except EMS), and all internal infrastructure.

**Resident components:**
- All core services (FMS, TOMS, DSO, TLS, SDS, DBM, Messaging Module, Task Manager)
- BFF / API Gateway (primary)
- Operator Console served from CorpNET
- Primary SQL Server 2025 (AlwaysOn AG primary)
- Service Broker / queue tables
- Identity Provider (AD / Entra hybrid)
- Observability stack (logs/metrics/traces)
- Rapid Restore adapter + Rapid Restore integrated app
- External adapters (GIS, FeederBoard, CPMS, etc.)
- Reporting tier (read-only)

**Allowed inbound:**
| Source zone | Protocol | Purpose |
|---|---|---|
| Operator desktops (CorpNET-internal) | HTTPS + Windows Integrated Auth | Operator console access |
| DMZ | mTLS (replication broker) | DB replication acks, audit replies, config sync |

**Allowed outbound:**
| Destination zone | Protocol | Purpose |
|---|---|---|
| DMZ | mTLS | Replication and audit forwarding initiation; outbound calls to external systems via External GW |
| Internet | (None directly — only via DMZ External GW) | All Internet-bound traffic transits DMZ |

**Hard restrictions:**
- No direct connection from CorpNET to OpNET (must traverse DMZ)
- No direct CorpNET → Internet (all egress via DMZ External GW)
- Operator desktop access is CorpNET-resident; remote operator access (if any) requires VPN that lands in CorpNET — see open question NQ-04

---

## 4. Cross-zone communication rules

### 4.1 Allowed protocols matrix

| From ↓ \ To → | EMS Net | OpNET | DMZ | CorpNET | Internet |
|---|---|---|---|---|---|
| **EMS Net** | n/a | HTTPS (TLS 1.3, mTLS) | ✗ | ✗ | ✗ |
| **OpNET** | ✗ (by design) | n/a | mTLS via DMZ broker | ✗ direct (must via DMZ) | ✗ |
| **DMZ** | ✗ | mTLS | n/a | mTLS | HTTPS (only via External GW; outbound only) |
| **CorpNET** | ✗ | ✗ direct (must via DMZ) | mTLS | n/a | ✗ direct (only via DMZ) |
| **Internet** | ✗ | ✗ | HTTPS to App GW (limited) | ✗ | n/a |

✗ = blocked; mTLS = mutual TLS with certificate-based auth.

### 4.2 No-direct-path rule

**There is no direct network path from CorpNET to OpNET.** All traffic that crosses these zones is mediated by a DMZ-resident broker that:
- Validates the request against an explicit allow-list of operations
- Logs every transit to the integration audit log
- Enforces protocol restrictions (no cleartext, no HTTP, etc.)
- Has its own change-control gate

This rule has cost (replication latency, broker complexity, ops overhead) but is non-negotiable. It is what makes islanding semantically clean — when OpNET islands, no in-flight CorpNET traffic can corrupt OpNET state mid-event.

### 4.3 Authentication & encryption rules

| Boundary | Authentication | Encryption |
|---|---|---|
| Operator desktop → CorpNET console | Windows Integrated Auth (Kerberos) | TLS 1.3 |
| Internal service → service (CorpNET) | mTLS + service identity | TLS 1.3 |
| CorpNET ↔ DMZ | mTLS via service certificates | TLS 1.3 |
| DMZ ↔ OpNET | mTLS via service certificates | TLS 1.3 |
| EMS Network ↔ OpNET endpoint | mTLS via vendor-managed certificates | TLS 1.3 |
| Replication channel CorpNET ↔ OpNET | mTLS + dedicated certificate authority | TLS 1.3, AES-256 at rest |
| External vendor APIs (via DMZ External GW) | Per-vendor (OAuth2 / API key / mTLS) | TLS 1.3 |

**Certificate authorities:**
- Internal CA for CorpNET / DMZ / OpNET service certificates
- Separate dedicated CA for the EMS-facing endpoint (vendor-managed; rotation cadence per vendor)
- Per-cert TTL: 90 days max with automated rotation
- HSM-backed root for the dedicated replication CA

---

## 5. Specific boundary specifications

### 5.1 EMS Network ↔ OpNET (the most-scrutinized boundary)

| Property | Specification |
|---|---|
| Direction | EMS-initiated only (EMS connects to us; we never connect to EMS) |
| Protocol | HTTPS (TLS 1.3) with mutual TLS — vendor-managed client certs on EMS side |
| Endpoints exposed | Per [#7 §6.4] — outbound queue read, ack, inbound event post, heartbeat |
| Rate limits | Per-EMS-instance limit configured at endpoint (prevent runaway polls) |
| Idempotency | All POSTs require idempotency key; duplicates rejected |
| Failure handling | Endpoint returns explicit HTTP status codes; no silent drops |
| Logging | Every request logged to integration audit log with request-id, principal, payload hash |
| Vendor coordination | Required for cert rotation, contract changes, schema evolution |

**Design rule:** treat EMS as untrusted despite OT zoning. Validate the contract on every request; reject anything outside the contract; never trust IP-based identity alone.

### 5.2 OpNET ↔ DMZ (replication and audit forward)

| Property | Specification |
|---|---|
| Direction | Bidirectional, mediated by DMZ-resident replication broker |
| Protocol | mTLS over dedicated replication channel; SQL Server AlwaysOn AG transport |
| Traffic types | DB replication (steady state); audit forward (OpNET → DMZ → CorpNET); config sync (CorpNET → DMZ → OpNET) |
| Rate / bandwidth | Sized for full DB write throughput + 30% headroom |
| Failure handling | Replication lag alerts at thresholds (default: 30s warn, 5min critical); islanding triggered on link loss > threshold (per AD-04) |

### 5.3 DMZ ↔ CorpNET

| Property | Specification |
|---|---|
| Direction | Bidirectional, mediated by DMZ-resident brokers per traffic type |
| Protocol | mTLS |
| Traffic types | Replication acks, External GW outbound calls, audit replies |
| Rate | Sized for normal load; rate limits applied at broker |

### 5.4 Internet ↔ DMZ (limited)

Two flows only:

| Flow | Protocol | Constraints |
|---|---|---|
| External read-only reporting access (if scoped in) | HTTPS via App Gateway | Authenticated; rate-limited; WAF-protected; read-only views only; **drop entirely if not in scope** |
| External GW outbound calls (GIS, FeederBoard, CPMS, etc.) | HTTPS (vendor-specific auth) | Outbound-initiated only; per-destination allow-list |

**No inbound Internet traffic reaches CorpNET or OpNET. Ever.**

---

## 6. Failure modes & isolation behaviors

### 6.1 CorpNET ↔ OpNET link loss

**Trigger conditions:**
- Network link physically unavailable
- DMZ replication broker unreachable
- Loss exceeds threshold (default: 60 seconds; tunable per AD-04)

**Behavior:**
1. Replication broker detects loss; raises alert
2. OpNET standby continues to serve EMS polling endpoint (passive mode preserved)
3. CorpNET continues to serve operator console (operator authority preserved)
4. **Both sides have valid state up to the moment of loss** — no split-brain because EMS endpoint runs on OpNET and is the only EMS-facing component
5. Operator-issued instructions queued post-loss are not visible to OpNET; EMS receives nothing new from us during the loss
6. EMS-posted events post-loss are received and durably stored on OpNET; visible to CorpNET on link restoration via reverse replication

**Recovery:**
- Replication catches up (OpNET → CorpNET first to flush queued EMS events)
- Then CorpNET → OpNET to flush queued instructions
- Reconciliation job validates row-level fidelity
- Alerting clears only on completion of reconciliation, not on link return

### 6.2 Cyber event affecting CorpNET

**Trigger conditions:**
- IDS/IPS alerts above threshold
- SecOps manual declaration
- Specific compromise indicators in the threat-detection runbook

**Behavior:**
1. CorpNET application services taken out of service (programmatic or manual per runbook)
2. Standby on OpNET promoted to active read/write
3. Operator console redirected (DNS / load-balancer cutover) to OpNET-served endpoint
4. EMS continues polling OpNET endpoint with no behavior change
5. Rapid Restore is **degraded** — RR adapter is on CorpNET; field crews fall back to phone confirmation
6. External integrations (GIS, FeederBoard, CPMS) are **degraded** — adapters are on CorpNET; defer non-urgent calls
7. All actions taken during this mode are tagged `mode=islanded` in audit log

**Recovery:**
- CorpNET restored, validated by SecOps
- Reverse-replicate OpNET → CorpNET
- Reconcile
- Promote primary back to CorpNET only after operator + ops sign-off

### 6.3 EMS endpoint unavailability

**Behavior:**
- EMS polling fails; EMS retries per its own schedule
- No data loss on our side (we don't push)
- No data loss on EMS side (events held in EMS until successful post)
- Latency increases until restored; operator console continues to function but EMS-originated events queue up
- Alert raised at threshold (e.g., 5 min of failed polls)

### 6.4 Rapid Restore unavailability

**Behavior:**
- Steps held in "pending hand-off" state with retry
- Operator notified after threshold
- Manual fallback to phone confirmation (documented in operator runbook)
- This is **operationally acceptable** — Rapid Restore failure is not a safety event; phone confirmation has been the fallback for decades

---

## 7. Network change-control SLA assumption

This deserves its own section because it is the silent killer of program timelines.

| Change type | Assumed SLA |
|---|---|
| Inter-zone firewall rule change (CorpNET ↔ DMZ ↔ OpNET) | 10–15 business days from request to active |
| Intra-zone firewall rule change | 5–10 business days |
| Certificate renewal (automated rotation) | 0 (automated) |
| New service certificate issuance | 3–5 business days |
| New zone-spanning data path | 20+ business days (often requires SecOps + Compliance review) |

**Implication for the program:**

- Foundational Tasks phase (P1a) cannot start until network design is approved by SecOps. Plan **2 weeks** for that approval cycle (R-007).
- Every new external integration requires firewall rule changes — pre-stage rules at the integration design stage in P1, not at integration build time in P3.
- Rules are paper-trail-bound; treat them as immutable artifacts, not configuration.

**Mitigations:**

1. Pre-stage firewall approvals during P1 detailed design
2. Maintain a rule registry under version control
3. SecOps embed in architecture council during P1
4. Single network architect owns the rule registry end-to-end (no diffusion of responsibility)

---

## 8. Zone-by-zone deployment matrix

Quick reference for engineers and ops.

| Component | CorpNET | DMZ | OpNET | EMS Net |
|---|---|---|---|---|
| Operator Console (active) | ✅ | — | (during islanding) | — |
| BFF / API Gateway | ✅ | — | (during islanding) | — |
| FMS / TOMS / DSO / TLS / SDS / DBM | ✅ | — | (standby) | — |
| Messaging Module | ✅ | — | (standby) | — |
| Task Manager | ✅ | — | (standby) | — |
| Primary SQL Server | ✅ | — | — | — |
| Standby SQL Server | — | — | ✅ | — |
| Service Broker / Queue Tables | ✅ | — | (standby) | — |
| Identity Provider | ✅ | — | (read-only replica) | — |
| Observability stack | ✅ | — | (collector only) | — |
| EMS Polling Endpoint | (cold standby) | — | ✅ (active) | — |
| Rapid Restore + Adapter | ✅ | — | — | — |
| External Adapters (GIS, etc.) | ✅ | — | — | — |
| Replication Broker | — | ✅ | — | — |
| Audit Forwarder | — | ✅ | — | — |
| External Integration Gateway | — | ✅ | — | — |
| Application Gateway / WAF (if external access in scope) | — | ✅ | — | — |

---

## 9. Open network decisions for P1

Listed here so they're not forgotten. Each blocks specific later artifacts.

| ID | Decision | Driver | Blocks |
|---|---|---|---|
| NQ-01 | Confirm external read-only reporting access scope (in or out) | Sponsor + Compliance | App Gateway design; Internet-facing surface area |
| NQ-02 | Confirm RTO/RPO targets for islanding scenario | Operations + Compliance | Standby behavior tuning; replication SLA |
| NQ-03 | Confirm EMS vendor cert management process (rotation cadence, contact) | Vendor + SecOps | EMS endpoint cert lifecycle |
| NQ-04 | Confirm whether remote operator access is in scope (if yes, VPN/Bastion design) | Operations + SecOps | CorpNET inbound surface |
| NQ-05 | Confirm DNS architecture per zone (split-horizon? per-zone resolvers?) | Network team | All service-to-service comms |
| NQ-06 | Confirm jump-host / PAM solution for OpNET admin access | SecOps | Admin operability |
| NQ-07 | Confirm SecOps' acceptance of `replication broker in DMZ` pattern | SecOps | Foundational architecture; cannot start P1a build without |
| NQ-08 | Confirm how External Integration GW handles vendor cert pinning vs. trust-store updates | Network + SecOps | External integration adapter behavior |
| NQ-09 | Confirm islanding trigger automation (manual / automated / hybrid) | Operations + SecOps | Failover runbook |
| NQ-10 | Confirm CorpNET ↔ OpNET bandwidth allocation (steady-state + recovery burst) | Network team | Replication tuning |

---

## 10. What this design does not yet specify

To pre-empt scope creep on this document — these belong in subsequent artifacts, not here:

- IP addressing scheme per zone (P1a infrastructure design)
- Specific firewall rule list (P1a infrastructure design + SecOps)
- Specific IDS/IPS signatures and tuning (B5 #11 security strategy)
- Per-service network policies (P1 detailed design after service decomposition lock)
- Disaster-recovery runbooks (B5 #11 cutover playbook outline)
- Penetration testing scope and cadence (B5 #11 security strategy)
- Specific CA topology and HSM model (B5 secrets / DevOps blueprint)
- Specific load-balancer / traffic-director product choice (P1a infrastructure design)
