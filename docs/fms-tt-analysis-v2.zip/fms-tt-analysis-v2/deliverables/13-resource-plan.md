# Resource Plan

**Artifact ID:** B4.5
**Status:** Draft for Program Lead + Sponsor review
**Audience:** Program Lead, Sponsor, HR / Resource Manager, Engineering Leads
**Pairs with:** [14-resource-plan-brutal-honesty-memo.md](14-resource-plan-brutal-honesty-memo.md) and [15-estimation-worksheet.md](15-estimation-worksheet.md)

The companion `.xlsx` (`13-resource-plan.xlsx`) holds the working FTE grid and skills matrix that the PMO maintains. This `.md` is the source-of-truth methodology and the rationale for the numbers in the workbook.

---

## 1. Inputs to this plan

| Input | Source | Value |
|---|---|---|
| Internal team | A-001 (B1) | 15–20 .NET/Angular engineers + 2–4 architects |
| OpenRoad reader | A-002 (B1) | Confirmed: yes, identified within 4 weeks of P1 start |
| Operator SMEs | Sponsor update | **Full-time dedicated SMEs per core app** |
| Cutover strategy | D-001 | Option A — staggered big-bang per app |
| Indicative duration | B1 | 30–42 months (likely ~36) |
| MVP scope | Sponsor update | Partial FMS — single canonical scenario, end-to-end |
| New-value target | Sponsor update | 20% beyond parity |
| Budget envelope | Sponsor update | Flexible — anchor with worksheet output |

---

## 2. Role inventory

The program runs on these roles. Each row in the FTE grid corresponds to one of these.

| Role | Workstream | Phase span | Notes |
|---|---|---|---|
| Program Lead | All | P0a–P5 | Single accountable for delivery |
| Sponsor (consulted) | All | P0a–P5 | Decision authority on M-06, M-09, M-10 |
| Solution Architect | WS-ARC | P0a–P5 | Owns boundary integrity; cross-zone design |
| Domain Architect / Tech Lead | WS-ARC | P1–P4 | One per 1–2 cores; load-bearing for service decomposition |
| Backend Lead (.NET) | WS-BE | P1–P5 | Code review authority on backend |
| Frontend Lead (Angular) | WS-FE | P1a–P5 | Mental-model parity gatekeeper |
| Data Architect | WS-DATA | P1–P5 | Schema-per-service discipline; UDB→CIM owner |
| Integration Lead | WS-INT | P1–P5 | EMS, Rapid Restore, external systems |
| DevOps Lead | WS-DO | P0a–P5 | On-prem ADO + IIS + zone-aware infra |
| Test Lead | WS-QA | P0a–P5 | Owns test strategy, parity harness, test platform |
| Security Lead | WS-SEC | P0a–P5 | OT/IT boundary, audit, compliance liaison |
| Service Manager | WS-OPS | P2–P5 | Runbooks, on-call, hypercare exit |
| Change Lead | WS-CHM | P2–P5 | Operator engagement, training, comms |
| Backend engineer (.NET) | WS-BE | P1a–P5 | Build / extend services |
| Frontend engineer (Angular) | WS-FE | P1a–P5 | Operator console + monitor apps |
| DB engineer | WS-DATA | P1a–P5 | Migration, partitioning, perf tuning |
| Integration engineer | WS-INT | P1–P5 | Per-system adapters; EMS endpoint owner |
| DevOps engineer | WS-DO | P0a–P5 | Pipelines, environments, observability infra |
| QA engineer | WS-QA | P1a–P5 | Test authoring, parity harness, automation |
| Security engineer | WS-SEC | P1a–P5 | SAST, threat modeling, secrets, cert lifecycle |
| BA Lead | WS-CHM (cross) | P0a–P5 | Backlog discipline; DoR/DoD enforcement |
| BA / Product Owner | WS-CHM (cross) | P0a–P5 | Per-app PO during P3; one PO during MVP |
| Scrum Master | All | P1–P5 | One per 2 squads typically |
| UX designer | WS-FE | P1–P3a | Mental-model parity is design work, not just code |
| Operator SME (per app) | WS-OPS | P1–P5 | **Full-time dedicated** per sponsor update; 6 by P3 |
| OpenRoad reader | WS-ARC | P1–P3 | Specialist; may be contractor; criticality high |
| Compliance officer | WS-SEC | P1–P5 | 0.25–0.5 FTE consult; full review at M-06, M-09 |

---

## 3. FTE ramp curve by phase

The numbers below are **likely-case** FTE allocations. The `.xlsx` has best/likely/worst columns. Operator SME row is broken out separately because operator FTEs are not interchangeable with engineering FTEs.

| Role | P0a | P1 | P1a | P1b | P2 | P2a | P3 | P3a | P4 | P5 |
|---|---|---|---|---|---|---|---|---|---|---|
| Program Lead | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Solution Architect | 1 | 1 | 1 | 1 | 1 | 0.5 | 1 | 0.5 | 0.5 | 0.5 |
| Domain Architect / Tech Lead | 0 | 2 | 2 | 2 | 2 | 1 | 4 | 2 | 2 | 1 |
| Backend Lead | 0 | 1 | 1 | 1 | 1 | 1 | 2 | 1 | 1 | 1 |
| Frontend Lead | 0 | 1 | 1 | 1 | 1 | 1 | 2 | 1 | 1 | 1 |
| Data Architect | 0 | 1 | 1 | 1 | 0.5 | 0.5 | 1 | 0.5 | 0.5 | 0.5 |
| Integration Lead | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0.5 |
| DevOps Lead | 0.5 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Test Lead | 0.5 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Security Lead | 0.5 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0.5 |
| Service Manager | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 |
| Change Lead | 0 | 0.5 | 0.5 | 0.5 | 1 | 1 | 1 | 1 | 1 | 0.5 |
| Backend engineers | 0 | 1 | 4 | 6 | 8 | 6 | 12 | 8 | 6 | 4 |
| Frontend engineers | 0 | 1 | 2 | 2 | 5 | 4 | 8 | 6 | 4 | 2 |
| DB engineers | 0 | 0 | 1 | 2 | 1 | 1 | 2 | 1 | 1 | 1 |
| Integration engineers | 0 | 1 | 1 | 1 | 2 | 2 | 3 | 2 | 2 | 1 |
| DevOps engineers | 0 | 1 | 2 | 2 | 1 | 1 | 1 | 1 | 2 | 1 |
| QA engineers | 1 | 1 | 2 | 2 | 4 | 6 | 8 | 10 | 6 | 4 |
| Security engineers | 0 | 0.5 | 0.5 | 0.5 | 1 | 1 | 1 | 1 | 1 | 0.5 |
| BA Lead | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0.5 | 0.5 |
| BA / Product Owner | 0 | 1 | 1 | 1 | 1 | 1 | 3 | 2 | 2 | 1 |
| Scrum Master | 0 | 0.5 | 1 | 1 | 2 | 2 | 3 | 2 | 2 | 1 |
| UX designer | 0 | 1 | 1 | 1 | 2 | 1 | 2 | 1 | 0 | 0 |
| OpenRoad reader | 0 | 1 | 1 | 1 | 1 | 0.5 | 1 | 0.5 | 0 | 0 |
| Compliance officer | 0.25 | 0.25 | 0.25 | 0.25 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.25 |
| **Engineering subtotal** | **5** | **18.75** | **27.25** | **31.25** | **37** | **34** | **59.5** | **45** | **38** | **24.75** |
| Operator SMEs (separate) | 0 | 1 | 2 | 2 | 1 | 1 | 6 | 6 | 6 | 4 |

**Peak FTE: ~60 engineering + 6 operators = 66 in P3 (Incremental Build).**

This is higher than the user's "15–20 .NET/Angular engineers" assumption (A-001) because the count above includes architects, leads, BAs, QA, DevOps, security, ops, and PMs — the full delivery org, not just .NET/Angular code-writers. Pure backend-engineer + frontend-engineer headcount peaks at 20 in P3 (12 backend + 8 frontend), aligning with A-001 with modest stretch.

If A-001 is constrained to 20 total (engineers + everyone else), the program will not deliver at the indicated 30–42 month likely-case duration. This is documented as a critical assumption flag in the brutal-honesty memo.

---

## 4. Skills matrix

For each role, the skills required. Skills not listed are assumed.

| Skill ↓ \ Role → | Sol Arch | Dom Arch | BE Lead | FE Lead | Data Arch | Int Lead | DevOps Lead | Test Lead | Sec Lead | BE Eng | FE Eng | DB Eng | Int Eng | DevOps Eng | QA Eng | Sec Eng | BA | UX | OR Reader | Compliance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| .NET 8/9 | ◎ | ◎ | ◎ | ○ | ○ | ◎ | ○ | ○ | ○ | ◎ | — | — | ◎ | ○ | ○ | ○ | — | — | — | — |
| Angular | ◎ | ○ | ○ | ◎ | — | ○ | — | ○ | — | — | ◎ | — | — | — | ○ | — | — | ○ | — | — |
| SQL Server 2025 | ○ | ○ | ◎ | — | ◎ | ○ | ○ | ○ | ○ | ◎ | — | ◎ | ○ | ○ | ○ | — | — | — | — | — |
| Domain-Driven Design | ◎ | ◎ | ◎ | ○ | ○ | ◎ | — | ○ | ○ | ◎ | ○ | — | ○ | — | ○ | — | ○ | — | — | — |
| On-prem DevOps (ADO + IIS) | ○ | ○ | ○ | ○ | — | ○ | ◎ | ○ | ○ | ○ | ○ | ○ | ○ | ◎ | ○ | ○ | — | — | — | — |
| OpenRoad / 4GL reading | ◎ | ◎ | ○ | — | ○ | ○ | — | — | — | — | — | — | ○ | — | — | — | ○ | — | ◎◎ | — |
| Ingres / UDB | ○ | ○ | ○ | — | ◎ | ○ | — | — | — | — | — | ○ | ○ | — | — | — | ○ | — | ◎ | — |
| CIM model | ○ | ○ | ○ | — | ◎ | ○ | — | ○ | — | — | — | ○ | ○ | — | — | — | — | — | ○ | — |
| Switching domain knowledge | ◎ | ◎ | ○ | ○ | ○ | ◎ | — | ○ | — | ○ | ○ | — | ○ | — | ○ | ○ | ◎ | ○ | ◎ | ◎ |
| OT/IT segmentation, Purdue | ◎ | ○ | ○ | — | ○ | ○ | ◎ | ○ | ◎ | — | — | — | ○ | ○ | — | ◎ | — | — | — | — |
| NERC CIP regulatory | ○ | ○ | — | — | — | — | ○ | ○ | ◎ | — | — | — | — | — | — | ○ | ○ | — | — | ◎◎ |
| Threat modeling (STRIDE) | ○ | ○ | ○ | ○ | — | ○ | ○ | ○ | ◎ | ○ | — | — | ○ | — | — | ◎ | — | — | — | ○ |
| Performance / load testing | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ◎ | — | ○ | ○ | ○ | ○ | ○ | ◎ | — | — | — | — | — |
| Operator co-design / facilitation | ○ | ○ | — | ○ | — | — | — | — | — | — | — | — | — | — | — | — | ◎ | ◎ | — | ○ |
| Mental-model parity audit | — | — | — | ◎ | — | — | — | ○ | — | — | ○ | — | — | — | ○ | — | ○ | ◎◎ | ○ | — |
| Product backlog engineering | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | ◎◎ | — | — | — |

**Legend:** ◎◎ = critical / hire-for; ◎ = required; ○ = working knowledge; — = not required.

### Skills risks surfaced by this matrix

| Skill | Risk | Mitigation |
|---|---|---|
| OpenRoad / 4GL reading | Single-person-of-failure (the OR Reader role) | Backup reader contracted by P1; pair-reading sessions with Domain Architects from week 1 |
| CIM model | Specialist; 1 Data Architect deep | Cross-train at least one DB engineer during P1b POC |
| Switching domain knowledge | Concentrated in operator SMEs, not engineers | Pair-programming pattern: engineer + SME for every parity AC; targeted brown-bag from operators |
| Mental-model parity audit | Concentrated in UX designers and Frontend Lead | Multi-operator panel reviews; UX + FE Lead both required at sprint demo |
| OT/IT segmentation, Purdue | Concentrated in Solution Architect + Security Lead | Document architectural decisions thoroughly (ADRs); pair-design with SecOps |

---

## 5. Key-person risks

The five roles where losing the named individual mid-program would be catastrophic, with the named risk score (1–25 from B1 risk register convention) and the mitigation:

| # | Role | Why critical | Risk score | Mitigation |
|---|---|---|---|---|
| 1 | Solution Architect | Single owner of cross-zone integrity; OT/IT boundary; replacement onboarding ≥ 6 weeks | 16 | Pair with Domain Architect from week 1; write all decisions as ADRs in the repo; rotate review authority |
| 2 | OpenRoad reader | Only person who can spot hidden 4GL rules; loss = R-001 + R-005 realized | 20 | Identify backup contractor by P1 month 2; pair-reading sessions; recorded reading sessions |
| 3 | Lead Operator SME (FMS during P2) | M-06 acceptance authority; mental-model parity arbiter | 15 | Backup operator SME; multi-operator review panel; recorded co-design sessions |
| 4 | Compliance officer | Sole regulator-facing reviewer; loss blocks M-06 and M-09 | 12 | Backup compliance reviewer pre-identified; regular regulator engagement via Compliance Officer |
| 5 | Data Architect | Sole UDB → CIM design owner; loss derails P1b POC | 12 | Cross-train DB engineer during P1b; documented type-mapping spec |

These are higher-priority than the program-level risks in the B1 Risk Register because they manifest as immediate program-pause events, not gradual schedule slippage.

---

## 6. Onboarding & ramp assumptions

Hidden in any FTE plan is the assumption that *new joiners produce work immediately*. They don't. Onboarding factors:

| Phase | Onboarding factor | Why |
|---|---|---|
| First 2 weeks | 0% productive | Environment access, repo familiarity, security training |
| Weeks 3–6 | 30% productive | Pair programming; small bug fixes; reading code |
| Weeks 7–12 | 70% productive | First independent stories; code reviews accepted |
| Months 4+ | 100% productive | Steady-state |

The FTE numbers in the ramp grid are **adjusted** for ramp-up in the worksheet — see `13-resource-plan.xlsx` "Effective FTE" sheet. A nominal "8 backend engineers in P2" produces less effort than 8 × duration if 4 of them just joined.

This is the most-frequently-overlooked correction in modernization estimates. It is the second-largest source of estimate inflation we should expect. (Largest: hidden 4GL rules — see brutal-honesty memo.)

---

## 7. On-shore / off-shore mix

User confirmed internal team. Treat the program as **all on-shore**.

**Exception: OpenRoad reader.** If no internal candidate is found within 4 weeks of P1 start (per A-002), a contractor is acceptable. They may be on-shore or off-shore based on availability — the constraint is skill, not location. Specialist contractor with switching-domain context is preferred.

No other roles are off-shoreable in this program because:
- Operator SMEs are utility employees by definition
- Compliance / regulatory work requires presence
- Security / OT work requires presence
- Architects are integrated with operations

---

## 8. Cost rate brackets

This document does not commit to specific dollar rates — sponsor controls those. The estimation worksheet supports configurable rate brackets. Indicative bracket structure (each utility plugs in its actuals):

| Rate band | Roles |
|---|---|
| Band A | Program Lead, Solution Architect, Sponsor |
| Band B | Domain Architect, Backend Lead, Frontend Lead, Data Architect, Integration Lead, DevOps Lead, Test Lead, Security Lead, Service Manager, Change Lead, BA Lead |
| Band C | Senior backend / frontend / DB / integration / DevOps / QA / security engineers |
| Band D | Mid-level engineers (most of the team) |
| Band E | UX designer, Compliance officer (consult), Scrum Master |
| Band F | Operator SMEs (utility internal cost; not vendor rate) |
| Band G | OpenRoad reader contractor (specialist premium) |

The worksheet computes total program cost per scenario when sponsor provides actual rates.

---

## 9. Hiring & retention plan

Roles that must be filled (or confirmed available) before each phase starts:

| By the start of | Must be available |
|---|---|
| P0a | Solution Architect, Test Lead, BA Lead, Program Lead, DevOps Lead, Compliance officer (consult) |
| P1 | Domain Architects (2), Backend Lead, Frontend Lead, Data Architect, Integration Lead, Security Lead, OpenRoad reader, UX designer, BA/PO |
| P1a | Backend / Frontend / DB / Integration / DevOps / QA engineers (subset; ~50% of P3 peak) |
| P2 | Service Manager, Change Lead, full operator SME for FMS, full MVP engineering team |
| P3 | Per-app PO assignment; full operator SMEs across cores; peak engineering team |
| P4 | Cutover crew (Service Manager + DevOps engineers + Security engineers heavy-loaded for ~6 events) |
| P5 | Hypercare on-call rota; reduced engineering team |

### Retention risks

A 30–42 month program is long enough that attrition is a planning input, not just a risk:

- Industry baseline tech attrition: 15–20% per year
- Modernization-program attrition is typically *higher* in months 12–18 (post-MVP, pre-incremental-grind), then *lower* in months 24+ (program-completion bonus motivates stay)
- Plan **20% buffer over likely-case FTE** for backfill across the program

This 20% buffer is **not** in the headline ramp grid above. It's an additive in the cost worksheet.

---

## 10. Cross-references

- Estimation per-Epic effort: see [15-estimation-worksheet.md](15-estimation-worksheet.md) and `15-estimation-worksheet.xlsx`
- Brutal-honesty memo on where these numbers are most likely wrong: [14-resource-plan-brutal-honesty-memo.md](14-resource-plan-brutal-honesty-memo.md)
- Ramp curve in workbook form: `13-resource-plan.xlsx`
- Risk register entries (R-005 OpenRoad shortage, R-008 budget cap): `01-master-project-plan-template.xlsx` Risk Register sheet
