# Test Strategy

**Artifact ID:** B5.11
**Status:** Draft for Test Lead + Architecture Council review
**Audience:** Test Lead, QA Engineers, Engineering Leads, Operations Lead, Security Lead, Compliance Officer
**Pairs with:** [20-cutover-playbook-outline.md](20-cutover-playbook-outline.md), [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md), [16-database-design-principles.md](16-database-design-principles.md), [18-devops-cicd-blueprint.md](18-devops-cicd-blueprint.md)

This document specifies how the program tests itself. It is opinionated about what each test layer is for, what it must detect, and where it lives in the pipeline. The two non-negotiable testing surfaces — **operator-in-the-loop** and **audit/regulatory** — get explicit treatment because they are the load-bearing tests against M-06 and against the regulator audit window.

---

## 1. Purpose & scope

In scope:
- Test layers and what each is responsible for
- Test environments per phase
- Test data strategy
- CI/CD integration points
- Operator-in-the-loop methodology (load-bearing for M-06)
- UAT methodology and exit criteria
- Regression testing strategy
- Parity test harness
- Performance, security, accessibility testing
- Resilience / chaos testing
- Cutover testing (cross-reference to playbook outline)
- Defect linkage to backlog
- Test ownership matrix

Out of scope:
- Specific test cases per story (lives in stories' AC)
- Specific tool configuration (P1a build artifact)
- Cutover-weekend runbooks (P4 deliverable; outline in [20-cutover-playbook-outline.md](20-cutover-playbook-outline.md))

---

## 2. Test strategy principles

| # | Principle | Why |
|---|---|---|
| 1 | **Operator workflow correctness is the primary correctness criterion.** | Three sponsor non-negotiables converge on operator workflow. |
| 2 | **Audit completeness is tested as a first-class behavior**, not as a side effect. | Regulatory exposure. Audit-AC patterns from B3 §7. |
| 3 | **Parity is a tested property**, not a manually-asserted claim. | A parity harness compares legacy vs. new system on a captured corpus. |
| 4 | **Tests are owned by the team that writes the code**, not by a separate QA org. | QA engineers own test infrastructure + parity harness; service teams own the tests of their service. |
| 5 | **Test pyramid is enforced by CI gates**, not by guideline. | Teams that try to pile up E2E tests get caught. |
| 6 | **Production-like environments matter more than production-like test scripts.** | Pre-Prod fidelity is an investment with high return. |
| 7 | **Test data is anonymized production data**, not synthetic data, except where regulatory or topology constraints prevent. | Synthetic data hides production-shape defects. |
| 8 | **Resilience is tested before it is needed.** | Chaos testing in Pre-Prod, not in incident response. |
| 9 | **Operator validation is integral**, not gating-only. | Sprint demos, not just UAT, are operator-validated. |
| 10 | **Regression is automated by default; manual regression is a smell.** | Build-time test suites, not test-team checklists. |

---

## 3. Test pyramid

The shape we enforce — for every service:

```
                  /\
                 /  \   E2E (≤ 5%)
                /----\
               / Comp \  Integration / Contract (15%)
              /-------\
             /  Compo  \  Component / API (25%)
            /-----------\
           /    Unit     \   Unit (≥ 55%)
          /---------------\
```

| Layer | Coverage target | Run frequency | Owner |
|---|---|---|---|
| Unit | ≥ 80% line coverage on domain logic; ≥ 90% on rules engines | Every commit | Service team |
| Component / API | All public service endpoints | Every commit | Service team |
| Contract | All cross-service interactions (consumer + producer) | Every commit | Service teams (paired) |
| Integration | Service against real DB + real broker + real identity | Every commit (in CI test env) | Service team |
| E2E | Critical operator workflows only | Nightly + per-release | QA engineers |
| Performance | Per-service + cross-service | Per-release | QA + service team |
| Security | SAST every PR; DAST nightly Pre-Prod | Continuous | Security engineers |
| Operator-in-the-loop | Per-sprint + per-release | Per-sprint demo + UAT | Operator SME + UX + Test Lead |
| Parity | Daily during P2/P3; per-release pre-cutover | Daily | QA engineers |
| Chaos / resilience | Quarterly; per-release for critical paths | Quarterly + per-release | QA engineers + DevOps |

---

## 4. Test layers in detail

### 4.1 Unit tests

| Property | Decision |
|---|---|
| Tooling | xUnit (.NET), Jest (Angular) |
| Mocking | Moq (.NET), `jest.mock` (Angular) |
| Coverage target | ≥ 80% domain-logic lines; ≥ 90% on business-rule engines |
| Run | On every commit; required before PR merge |
| Speed target | < 5s per service unit suite at the median PR |
| Scope | Pure domain logic; no DB; no HTTP; no real broker |

**Anti-patterns blocked:**
- Unit tests that hit a real DB ("integration tests pretending to be unit tests")
- Tests that mock domain logic ("we mocked the rule we wrote")
- Tests with snapshot-only assertions on complex behaviors

### 4.2 Component / API tests

- Service in-process; DB stubbed or in-memory
- Validate endpoint behavior, request/response contracts, validation, error codes
- Run on every commit
- Coverage target: every public endpoint with happy path + at least one error path

### 4.3 Contract tests (consumer-driven)

- Tooling: Pact (recommended) or equivalent
- Producer and consumer maintain contract files in repo
- CI fails if a service breaks a contract its consumers depend on
- Mandatory for: BFF ↔ each Service; Service ↔ Service async messages; integration adapter ↔ external system (where contract is captured)

### 4.4 Integration tests

- Service runs against real SQL Server (CI test instance, not shared); real broker; real identity (test tenant)
- Validate: full request → DB → audit → integration call paths
- Run on every commit in CI test environment
- Test environment data is reset between test runs

### 4.5 E2E tests

- Tooling: Playwright (recommended)
- Cover: top operator workflows per service (≤ 10 per service in MVP; grows to ~25 per service across P3)
- Run nightly + per-release
- Failure budget: any failure blocks next Pre-Prod deploy
- Maintained by QA engineers; service teams contribute scenarios

**Why so few?** E2E tests are slow and brittle. Discipline the suite to high-value scenarios; rely on lower layers for breadth.

---

## 5. Operator-in-the-loop testing — load-bearing for M-06

### 5.1 What this is and isn't

This is **not** UAT. UAT happens in P2a (per B1). Operator-in-the-loop is *continuous* throughout P2 and P3.

| Activity | Cadence | Participants |
|---|---|---|
| Sprint demo with operator review | Every sprint (2 weeks) | Operator SME + service team + Test Lead + UX |
| Mental-model parity audit | Every story marked as Parity in DoD | Operator SME + UX |
| Operator panel review of MVP scope | Monthly during P2 | Multi-operator panel + Operations Lead |
| Tangible new-value demo + co-design | Per new-value Epic | Operator panel + service team |
| Defect triage with operator-facing severity | Continuous | Operator SME + Engineering Lead |

### 5.2 The mental-model parity audit

For every Parity story, before DoD is signed:

1. Operator SME walks the workflow on the new system
2. Operator SME walks the same workflow on legacy (or recorded reference)
3. Side-by-side note-taking: where do they diverge? Field order? Defaults? Keyboard shortcuts? Visual hierarchy?
4. Each divergence becomes either a defect (fix) or an explicit change-decision (with operator concurrence and Change Lead documentation)
5. Story does not move to Done until divergences are reconciled

### 5.3 Operator panel composition

- 3–5 operators across districts (cross-district variance catches local muscle-memory differences)
- Mix of senior + mid-career operators
- Same panel sees demos throughout P2 (continuity matters; learning happens)
- Backup operators identified per panel member (key-person risk in resource plan)

### 5.4 Recording sessions

- Sprint demos recorded with operator commentary
- Co-design sessions recorded
- Recordings archived to support knowledge transfer + onboarding

---

## 6. UAT methodology

### 6.1 MVP UAT (P2a) — the hard gate

This is the program's hardest gate (M-06). Treated as a phase, not a checklist.

**Activities:**
- 2-week UAT cycles (4 cycles in the typical 8-week P2a window)
- Each cycle: scenarios run by operators, defects logged, triaged, fixed, re-tested
- Sign-off panel review at end of cycle 4
- M-06 decision: panel consensus required (majority not sufficient — need consensus or explicit escalation path)

**Entry criteria:**
- All MVP stories meet engineering DoD
- Pre-Prod environment matches Prod in shape and data
- Operator panel + Operations Lead + Sponsor stakeholders identified
- Backup operator SMEs identified and aware

**Exit criteria (M-06):**
- All severity-1 defects closed
- ≤ N severity-2 defects deferred (N agreed at gate-design time)
- Operator panel signs off on parity (consensus, recorded)
- Tangible new-value features demonstrated and operator-validated (20% target)
- Audit trail completeness verified by Compliance against AC patterns A/B/C/D
- Cutover-readiness sub-gate: rollback plan documented and tested

### 6.2 Full UAT (P3a)

- Cross-app workflows tested
- Regulator audit dry-run (Compliance executes a synthetic audit)
- Performance under combined load
- Disaster-recovery / islanding drill
- Sign-off by Operations Lead

### 6.3 Anti-patterns

| Anti-pattern | Why it's wrong |
|---|---|
| UAT running before story DoD | UAT is for production-readiness; stories should be technically Done first |
| UAT that documents but doesn't decide | Without a clear pass/fail per scenario, UAT becomes paperwork |
| Operator panel changing every cycle | Continuity matters; same operators across cycles |
| Severity inflation under deadline pressure | An S1 doesn't become an S2 because of timing |

---

## 7. Regression testing strategy

### 7.1 The build-time regression suite

- Built incrementally: every closed story adds its E2E + integration tests to the suite
- Runs nightly against `main` Pre-Prod-fidelity environment
- Failure blocks next release until triaged

### 7.2 What's automated

- 100% of operator-facing workflow regressions
- 100% of audit-AC patterns
- 100% of integration contracts
- All `[REG]`-tagged stories' regression scenarios

### 7.3 What's manual (and that's OK)

- Cosmetic / UI polish regressions (caught at sprint demo)
- Edge cases that aren't worth automating (documented exception with Test Lead approval)
- Operator-felt regressions discovered in production (drives manual exploratory before automation)

### 7.4 Manual regression is a smell

- If manual regression accumulates, automate it
- If a regression happens in prod that wasn't caught by automation, the test gap is filed with the bug
- Quarterly review: % automated vs. manual; trend toward 100% automated

---

## 8. Parity test harness

### 8.1 What it is

A separate test infrastructure that takes a captured corpus of legacy-system inputs and outputs and replays the inputs against the modernized system, comparing outputs.

### 8.2 What's captured from legacy

| Capture | Source | Use |
|---|---|---|
| EMS event payloads (anonymized) | Legacy system production capture | Auto-create card scenarios |
| Operator action sequences (anonymized) | Legacy system audit log | Workflow execution scenarios |
| Card lifecycle states with timestamps | Legacy DB | State-transition validation |
| Authorization decisions with context | Legacy DB | RBAC parity validation |
| Final audit reports for regulator | Legacy DB | Regulatory query parity |

### 8.3 What it tests

- Same input → same output (semantically; not byte-identical)
- Same audit trail emission pattern
- Same authorization decisions for same input
- Same field layout rendering (visual diff)
- Same time-to-completion (within tolerance)

### 8.4 What it doesn't test

- Whether the legacy system was correct (we trust legacy as the parity baseline)
- New-value features (those have their own ACs and operator co-design validation)

### 8.5 Operationally

- Built during P1b (feeder-context conversion sub-task)
- Reused for every parity story in P2
- Reused for cutover go/no-go (legacy capture vs. modern execution comparison)
- Run nightly against Pre-Prod throughout P2/P3

---

## 9. Performance & load testing

### 9.1 Targets (per [16-database-design-principles.md](16-database-design-principles.md) §12)

| Workload | p50 | p95 | p99 |
|---|---|---|---|
| Operator-facing point read | 5 ms (DB) → ≤ 200 ms end-to-end | 20 ms → ≤ 500 ms | 50 ms → ≤ 800 ms |
| Operator-facing list read | 50 ms → ≤ 600 ms | 200 ms → ≤ 1 s | 500 ms → ≤ 2 s |
| Operator-facing write (state transition + audit) | 30 ms → ≤ 300 ms | 100 ms → ≤ 800 ms | 250 ms → ≤ 1.5 s |
| EMS poll response | — | ≤ 100 ms | ≤ 200 ms |
| RR handoff latency | — | ≤ 500 ms | ≤ 1 s |

### 9.2 Test types

| Test | Cadence | Environment |
|---|---|---|
| Load test (steady-state) | Per-release | Pre-Prod |
| Stress test (find breaking point) | Quarterly | Pre-Prod |
| Soak test (24h sustained) | Per-release pre-cutover | Pre-Prod |
| Burst test (operational surge — e.g., storm response) | Per-release pre-cutover | Pre-Prod |

### 9.3 Tooling

- k6 (recommended) or JMeter for HTTP load
- Custom harness for EMS polling simulation
- Realistic data shapes (anonymized production)
- Telemetry captured and dashboarded; results trend-tracked release over release

### 9.4 What we will not chase

- Single-digit-millisecond DB latency (covered in DB principles §12.3)
- Synthetic 99.99% availability targets that the OT/IT segmentation cannot deliver without islanding behavior

---

## 10. Security testing

### 10.1 SAST (CodeQL)

- Runs on every PR (per [18-devops-cicd-blueprint.md](18-devops-cicd-blueprint.md) §15.1)
- New high-severity findings block merge
- Suppression requires Security Lead approval + recorded justification

### 10.2 DAST (OWASP ZAP)

- Runs nightly against Pre-Prod
- Scope: BFF + each service endpoint + EMS Polling Endpoint + External GW
- Authentication-context tests included
- High-severity findings block next Prod deploy

### 10.3 Dependency scan

- Runs nightly against `main`
- New high-severity vulnerabilities in dependencies = P1 ticket auto-created
- Critical CVE in a deployed dependency = pipeline pauses Prod deploys

### 10.4 Threat-model-driven test scenarios

- Threat model per service (P1 detailed design output)
- Each identified attack scenario translated to a test (in DAST or in integration tests)
- Threat model reviewed quarterly; new scenarios added to test suite

### 10.5 Penetration testing

- External pen-test pre-cutover (per app); coordinated with regulator
- Internal red-team assessment annually
- Findings tracked as bugs; severity per OWASP risk rating

### 10.6 Security regression suite

- Authorization tests for every role × workflow step combination
- Audit emission tests for every state transition (NFR-AUD-001)
- Hash-chain tamper-detection tests
- Cert rotation tests

---

## 11. Accessibility testing

| Standard | Target |
|---|---|
| WCAG | 2.2 AA |
| Keyboard navigation | Parity with legacy where operator muscle memory exists |
| Screen reader | Functional support; not optimized for primary use |
| Color contrast | AAA where information is colored-coded (e.g., card status) |

Testing:
- Automated: axe-core in E2E pipeline; failures block release
- Manual: per-sprint review of new components by UX + accessibility-trained QA
- User testing: not in MVP scope unless legal requires; consider for P3

---

## 12. Resilience / chaos testing

### 12.1 What we test

| Scenario | When |
|---|---|
| Service dependency unavailable (DB, broker, identity) | Per release |
| Network partition CorpNET ↔ DMZ ↔ OpNET | Per release pre-cutover |
| EMS endpoint unreachable | Per release |
| Rapid Restore unreachable | Per release |
| External adapter timeout / error storm | Per release |
| Audit collector unavailable | Per release (workflow must continue) |
| Disk full at primary | Quarterly |
| AG failover (intra-zone) | Monthly drill |
| AG failover (cross-zone, OpNET promotion) | Quarterly drill |
| Pipeline agent failure | Continuous (passive — alerts catch) |

### 12.2 Tooling

- Custom chaos harness for service-level injection
- Network shaping (`tc` / Windows equivalent) for partition simulation
- Manual drill cards for AG failover and DR scenarios

### 12.3 Acceptance

- Each scenario has a documented expected behavior + recovery time
- Scenario results trend-tracked over time
- Regression: a previously-passing scenario that now fails blocks the release

---

## 13. Audit & regulatory testing

### 13.1 The audit AC patterns from B3 §7

Every story with state transitions has audit ACs of patterns A/B/C/D. Testing them:

| Pattern | Test |
|---|---|
| A — Entity history | Temporal query verifies the (X→Y) transition exists with required fields |
| B — Operator action | Audit table query verifies row with required columns + hash chain link |
| C — Authorization decision | Auth-decision table query verifies allow/deny is recorded |
| D — Integration call | Integration log query verifies request + response logged with hash + idempotency key |

### 13.2 Tamper-evidence test

- Synthetic tamper of audit row (test environment)
- Daily hash-chain validation job detects within SLA (NFR-AUD-001 §verification)

### 13.3 Regulatory query corpus

- Compliance maintains a corpus of regulator-pattern queries
- Corpus runs against Pre-Prod monthly; against Prod quarterly
- Results compared to expected (where comparable from legacy capture)

### 13.4 Compliance dry-run

- Quarterly synthetic audit by Compliance team
- Walk-through: regulator-style request → query → result → packet generated
- Identifies gaps in audit coverage before real audit

---

## 14. Test environments per phase

| Phase | Environments active |
|---|---|
| P0a Phase 0 audit | Dev only (audit team uses developer envs for harness build) |
| P1 Detailed Design | Dev + planning |
| P1a Foundational | Dev + SIT (basic) |
| P1b POC | Dev + SIT + Pre-Prod (POC) — Pre-Prod pattern emerges |
| P2 MVP Build | Dev + SIT + Pre-Prod (full Pre-Prod stood up) |
| P2a MVP UAT | Pre-Prod (Prod-shape) |
| P3 Incremental Build | Dev + SIT + Pre-Prod |
| P3a Full UAT | Pre-Prod (Prod-mirror including OpNET standby) |
| P4 Cutover | Pre-Prod for rehearsals; Prod for cutover |
| P5 Hypercare | All; defects tracked back through environments |

### 14.1 Environment discipline

- No production data in Dev or SIT (anonymized only)
- Production-like data in Pre-Prod (anonymized; refreshed monthly from Prod with audit log of refresh)
- Pre-Prod = Prod minus credentials + minus secrets — same shape, same volume
- Smoke tests run after every refresh

---

## 15. Test data strategy

### 15.1 Anonymized production data

- Operator names, district codes (in some cases), customer-related fields anonymized
- PII protection per regulatory requirements
- Anonymization is reproducible — same input always produces same output (for cross-environment correlation)
- Refresh cadence: monthly to Pre-Prod; on-demand to Dev

### 15.2 Edge-case curated dataset

- Maintained per service
- Covers boundary conditions (year transitions, leap days, NULL combinations, max-length strings, non-ASCII)
- Re-validated against new edge cases discovered in production
- Lives alongside test code in repo

### 15.3 Synthetic event streams

- For load tests + chaos tests
- Generator service in test infra produces realistic EMS event streams + operator action streams
- Profiles: steady-state, surge (storm), idle (overnight)

---

## 16. Defect linkage to backlog

| Defect found in | Tracked as |
|---|---|
| Unit test failure | Engineer fixes; no formal bug ticket |
| Integration / E2E failure pre-merge | Engineer fixes; no formal ticket |
| Pre-Prod / Prod / Operator review | **Bug ticket per [11-bug-template.md](11-bug-template.md)** |
| Performance regression | Bug ticket; severity per impact |
| Security finding (SAST/DAST/dep) | Bug ticket if not auto-suppressed |
| Operator-reported parity gap | Bug ticket with severity = S1 if operator confusion |
| Audit gap | Bug ticket S1 + Compliance notification |

Defect rate trends per service tracked in observability; a service trending up in defect rate triggers Engineering Lead review.

---

## 17. Test ownership matrix

| Test type | Owner | Reviewer |
|---|---|---|
| Unit | Service engineer | Code review |
| Component / API | Service engineer | Code review |
| Contract | Both consumer and producer engineers | Test Lead |
| Integration | Service engineer | Test Lead |
| E2E | QA engineer | Service team |
| Performance | QA engineer + service team | Test Lead |
| Security (SAST/DAST/dep) | Security engineer | Security Lead |
| Threat-model-driven | Security engineer | Security Lead |
| Operator-in-the-loop | Operator SME + UX + Test Lead | Engineering Lead |
| UAT | Operator panel | Operations Lead |
| Parity | QA engineer | Test Lead + Operator SME |
| Resilience / chaos | QA engineer + DevOps | Test Lead |
| Audit / regulatory | Test engineer | Compliance + Security Lead |
| Migration / reconciliation | Data engineer | Data Architect |

---

## 18. Cutover testing

Cross-references [20-cutover-playbook-outline.md](20-cutover-playbook-outline.md) — cutover testing is a distinct discipline from release testing.

| Test | Cadence | Environment |
|---|---|---|
| Migration end-to-end | Per dress rehearsal | Pre-Prod |
| Reconciliation harness | Per dress rehearsal + nightly during P3 | Pre-Prod |
| Rollback (cutover-weekend) | Per dress rehearsal | Pre-Prod |
| Smoke (post-cutover) | Per cutover | Prod |
| Operator-driven readiness checks | Per cutover | Prod |
| Audit reconstruction post-cutover | Per cutover | Prod |
| Soak monitoring | Continuous during 4-week soak | Prod |

---

## 19. Open decisions for P1 detailed design

| ID | Decision | Driver | Blocks |
|---|---|---|---|
| TS-01 | Confirm Playwright vs. Cypress for E2E | Test Lead | E2E pipeline |
| TS-02 | Confirm k6 vs. JMeter for performance | Test Lead | Performance pipeline |
| TS-03 | Confirm Pact (or equivalent) for contract tests | Test Lead + service teams | Contract pipeline |
| TS-04 | Confirm anonymization tooling for Prod-to-Pre-Prod refresh | Compliance + DevOps | Pre-Prod data lifecycle |
| TS-05 | Confirm mental-model parity audit format (worksheet, recording, etc.) | UX + Operator panel | Sprint demo template |
| TS-06 | Confirm regulator query corpus content + maintenance | Compliance | Regulatory test pipeline |
| TS-07 | Confirm pen-test cadence + scope | Security Lead + Compliance | Pre-cutover validation |
| TS-08 | Confirm chaos engineering tooling | DevOps + Test Lead | Chaos pipeline |
| TS-09 | Confirm test-data refresh frequency | Compliance + DevOps | Pre-Prod operational planning |
| TS-10 | Confirm UAT severity-2 deferral threshold for M-06 | Operations Lead + Sponsor | UAT exit criteria |

---

## 20. What this document does not specify

- Per-service test cases (live in stories' AC documents)
- Specific tool versions or configurations (P1a build)
- Per-environment infrastructure sizing (B5 DevOps blueprint + P1a)
- Specific scenarios in the operator parity harness (P1b POC + ongoing)
- Specific cutover-weekend runbooks (P4 deliverable; outline in [20-cutover-playbook-outline.md](20-cutover-playbook-outline.md))
- Specific dashboards for test-result trending (B5 observability)
