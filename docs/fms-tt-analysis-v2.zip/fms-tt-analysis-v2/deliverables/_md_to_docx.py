"""
Focused markdown-to-docx converter tuned for the patterns used in this folder's
.md deliverables. Not a general markdown converter — handles only what's used.

Patterns supported:
  - Headers: # ## ### ####
  - Paragraphs (plain text)
  - Bullet lists: lines starting "- "
  - Numbered lists: lines starting "1. " "2. " etc
  - Tables: pipe-delimited with header separator row
  - Code blocks: fenced with ```
  - Bold:   **text**
  - Italic: *text*  (only when not part of bold)
  - Inline code: `text`
  - Horizontal rules: standalone "---"
  - Blockquotes: lines starting "> "
  - Mermaid blocks: rendered as a placeholder note (docx cannot render mermaid)

Run: python _md_to_docx.py <input.md> <output.docx>
"""

import re
import sys
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


HEADER_BLUE = RGBColor(0x1F, 0x38, 0x64)
SUBTLE_GREY = RGBColor(0x80, 0x80, 0x80)
CODE_GREY = RGBColor(0x55, 0x55, 0x55)


def add_runs_with_inline(p, text):
    """Add runs to a paragraph honoring **bold**, *italic*, `code`, and links [text](url)."""
    # Handle markdown links first: [text](url) -> emit text as styled run; href dropped (docx hyperlink would need oxml)
    # Use a tokenizer
    pattern = re.compile(
        r"(\*\*[^*]+\*\*)"            # bold
        r"|(\*[^*]+\*)"                # italic
        r"|(`[^`]+`)"                  # inline code
        r"|(\[[^\]]+\]\([^)]+\))"      # markdown link
    )
    pos = 0
    for m in pattern.finditer(text):
        if m.start() > pos:
            run = p.add_run(text[pos:m.start()])
            run.font.size = Pt(11)
        token = m.group(0)
        if token.startswith("**"):
            run = p.add_run(token[2:-2])
            run.bold = True
            run.font.size = Pt(11)
        elif token.startswith("*"):
            run = p.add_run(token[1:-1])
            run.italic = True
            run.font.size = Pt(11)
        elif token.startswith("`"):
            run = p.add_run(token[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(10)
            run.font.color.rgb = CODE_GREY
        elif token.startswith("["):
            link_match = re.match(r"\[([^\]]+)\]\(([^)]+)\)", token)
            label = link_match.group(1)
            run = p.add_run(label)
            run.italic = True
            run.font.size = Pt(11)
            run.font.color.rgb = HEADER_BLUE
        pos = m.end()
    if pos < len(text):
        run = p.add_run(text[pos:])
        run.font.size = Pt(11)


def add_heading(doc, text, level):
    h = doc.add_heading("", level=min(level, 4))
    run = h.add_run(text)
    run.font.color.rgb = HEADER_BLUE
    run.font.size = Pt({1: 22, 2: 16, 3: 13, 4: 11}.get(level, 11))
    run.bold = True
    return h


def add_table_from_rows(doc, rows):
    """rows is a list of list of cell strings; rows[0] is header."""
    if not rows:
        return
    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.LEFT

    # header
    for i, cell in enumerate(rows[0]):
        c = table.rows[0].cells[i]
        c.text = ""
        p = c.paragraphs[0]
        run = p.add_run(cell)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.size = Pt(10)
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "1F3864")
        c._tc.get_or_add_tcPr().append(shd)

    # body
    for r, row in enumerate(rows[1:], 1):
        for ci, cell in enumerate(row):
            if ci >= len(table.rows[r].cells):
                continue
            tc = table.rows[r].cells[ci]
            tc.text = ""
            p = tc.paragraphs[0]
            add_runs_with_inline(p, cell)
            for run in p.runs:
                run.font.size = Pt(9)


def add_code_block(doc, code, language=""):
    p = doc.add_paragraph()
    if language == "mermaid":
        run = p.add_run("[Mermaid diagram — see source markdown for rendering]")
        run.italic = True
        run.font.size = Pt(10)
        run.font.color.rgb = SUBTLE_GREY
        # then add the code in monospace as preview
        p2 = doc.add_paragraph()
        run2 = p2.add_run(code)
        run2.font.name = "Consolas"
        run2.font.size = Pt(8)
        run2.font.color.rgb = CODE_GREY
    else:
        run = p.add_run(code)
        run.font.name = "Consolas"
        run.font.size = Pt(9)
        run.font.color.rgb = CODE_GREY
    # left indent
    p.paragraph_format.left_indent = Inches(0.25)


def parse_table_block(lines, start):
    """Parse a markdown table starting at `start`. Returns (rows, end_index)."""
    rows = []
    i = start
    while i < len(lines) and lines[i].strip().startswith("|"):
        line = lines[i].strip()
        # skip separator rows like |---|---|
        if re.match(r"^\|[\s:|-]+\|\s*$", line):
            i += 1
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        rows.append(cells)
        i += 1
    return rows, i


def convert(md_path: Path, docx_path: Path, title: str | None = None):
    text = md_path.read_text(encoding="utf-8")
    lines = text.splitlines()

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    i = 0
    in_code = False
    code_lang = ""
    code_buf = []

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Code block fences
        if stripped.startswith("```"):
            if not in_code:
                in_code = True
                code_lang = stripped[3:].strip()
                code_buf = []
            else:
                add_code_block(doc, "\n".join(code_buf), code_lang)
                in_code = False
                code_lang = ""
                code_buf = []
            i += 1
            continue
        if in_code:
            code_buf.append(line)
            i += 1
            continue

        # Headers
        if stripped.startswith("#"):
            level = len(stripped) - len(stripped.lstrip("#"))
            heading_text = stripped[level:].strip()
            add_heading(doc, heading_text, level)
            i += 1
            continue

        # Horizontal rule
        if stripped == "---":
            p = doc.add_paragraph()
            p.add_run("―" * 60).font.color.rgb = SUBTLE_GREY
            i += 1
            continue

        # Tables (start with |)
        if stripped.startswith("|") and "|" in stripped[1:]:
            rows, end = parse_table_block(lines, i)
            if rows:
                add_table_from_rows(doc, rows)
            i = end
            continue

        # Bullet list
        if stripped.startswith("- "):
            content = stripped[2:]
            p = doc.add_paragraph(style="List Bullet")
            add_runs_with_inline(p, content)
            i += 1
            continue

        # Checkbox bullet "- [ ]" or "- [x]"
        m = re.match(r"^- \[( |x|X)\] (.*)", stripped)
        if m:
            checked = m.group(1).lower() == "x"
            box = "☑" if checked else "☐"
            p = doc.add_paragraph(style="List Bullet")
            run = p.add_run(box + " ")
            run.font.size = Pt(11)
            add_runs_with_inline(p, m.group(2))
            i += 1
            continue

        # Numbered list
        m = re.match(r"^(\d+)\. (.*)", stripped)
        if m:
            content = m.group(2)
            p = doc.add_paragraph(style="List Number")
            add_runs_with_inline(p, content)
            i += 1
            continue

        # Blockquote
        if stripped.startswith("> "):
            content = stripped[2:]
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.4)
            run = p.add_run(content)
            run.italic = True
            run.font.color.rgb = SUBTLE_GREY
            i += 1
            continue

        # Empty line
        if stripped == "":
            i += 1
            continue

        # Default paragraph
        p = doc.add_paragraph()
        add_runs_with_inline(p, line)
        i += 1

    doc.save(docx_path)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: python _md_to_docx.py <input.md> <output.docx>")
        sys.exit(1)
    convert(Path(sys.argv[1]), Path(sys.argv[2]))
    print(f"wrote {sys.argv[2]}")
