# Spike Template

**Use:** A Spike exists to remove a specific uncertainty that is blocking estimation of a story or design decision. Spikes are time-boxed. The output is a decision or an artifact, not working production code.

**Pairs with:** [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §2 (adjuncts).

---

## Spike header

| Field | Value |
|---|---|
| **Spike ID** | (e.g., `SP-018`) |
| **Title** | (one line; phrased as a question) |
| **Owner** | (single person — accountable) |
| **Stakeholders** | (named people who need the answer) |
| **Time-box** | (e.g., 3 days, max 5) |
| **Triggered by** | (which story, Epic, or architectural decision) |
| **Phase** | P0a / P1 / P1a / P1b / P2 / etc. |
| **Status** | Backlog / Active / Concluded / Cancelled |

---

## The question to answer

Phrase as one specific question. If you need two questions, that's two spikes.

> e.g., *"What is the actual schema of EMS breaker-trip events for planned distribution outages, and which fields are required vs. optional in practice?"*

---

## Why this spike is needed

What downstream work is blocked? Be specific — name the story IDs, the design decision, or the estimate that depends on this answer.

> e.g., *"Story FMS-S-103 (Pre-populate feeder context fields) cannot be sized without confirmation of which fields EMS provides. Without this spike, story sizing is a guess."*

---

## Decision criteria

What does an answer look like? Be unambiguous.

| Outcome | Will trigger |
|---|---|
| (e.g., All fields confirmed required) | Story FMS-S-103 sized as 3 points; proceed |
| (e.g., Some fields optional or missing) | Story split into two stories; one for required, one for fallback handling |
| (e.g., Schema differs from documentation) | Raise integration risk; vendor coordination needed |

---

## Approach (planned)

How the spike is executed. Not a long plan — bullet points.

- Step 1: e.g., obtain sample EMS event payloads from vendor (per A-004)
- Step 2: cross-reference against vendor documentation
- Step 3: exercise via test endpoint
- Step 4: capture findings

---

## Time-box rules

- The spike runs for at most the time-box. Going over means the question is bigger than expected — stop, report what you learned, and plan the next step.
- Production code written during a spike is **prototype only** — not merged to main.
- Output is captured in the **Findings** section below, not in code.
- A spike that runs longer than its time-box without producing a decision is escalated to the Engineering Lead.

---

## Findings

### Summary
One paragraph. The decision-maker reads this first.

### Detailed observations
What was learned, in enough detail that another engineer could verify or extend.

### Decision recommended

| Recommendation | Rationale |
|---|---|
| | |

### Open follow-ups
Anything that surfaced but wasn't resolved within the time-box. Becomes input to backlog or another spike.

| Follow-up | Owner | Type (story / spike / risk / decision) |
|---|---|---|
| | | |

### Artifacts produced
Linked here. Includes: ADRs, prototype code repositories, captured payloads, screenshots, vendor correspondence.

| Artifact | Location |
|---|---|
| | |

---

## Worked example

```
Spike ID:     SP-018
Title:        What is the EMS breaker-trip event schema for planned distribution outages?
Owner:        K. Daniel (Integration engineer)
Stakeholders: J. Park (PO, FMS); R. Chen (Ops); Solution Architect
Time-box:     5 days
Triggered by: FMS-E-014 stories (sizing blocked); EMS endpoint contract design
Phase:        P1
Status:       Concluded

The question to answer:
  What is the actual schema of EMS breaker-trip events for planned distribution
  outages, and which fields are required vs. optional in practice?

Why this spike is needed:
  Stories FMS-S-101, S-102, S-103 are blocked from estimation. EMS endpoint
  payload validation rules cannot be specified without this answer. Risk R-002
  rated 20 (high) until confirmed.

Decision criteria:
  All required fields known           → S-103 sized as 3 points; AC-1 finalized
  Some fields optional with defaults  → split S-103 into core + edge stories
  Schema mismatch vs. vendor docs     → raise vendor coordination as P1 dependency

Approach:
  - Obtain 50+ sample event payloads from vendor (per A-004)
  - Compare schema vs. published vendor documentation
  - Run through test EMS endpoint stub
  - Identify required-vs-optional fields by frequency

Findings — Summary:
  EMS provides 18 fields per event. 12 are always populated. 4 are conditionally
  populated based on outage classification. 2 are vendor-specified as optional
  but never observed populated in 50-sample dataset. Schema matches vendor
  documentation v3.2 with one undocumented field (`originator_district_code`)
  consistently present.

Detailed observations:
  - Required (always populated): event_id, breaker_id, feeder_id, substation_id,
    timestamp, event_type, severity, outage_class, district_code, originator,
    message_revision, payload_version
  - Conditional: target_restoration_window (only for planned), affected_circuit_count,
    impacted_customer_estimate, weather_condition_code
  - Documented optional but never observed: vendor_metadata, internal_ref
  - Undocumented: originator_district_code (consistent across all 50 samples)

Decision recommended:
  - Treat all 12 always-populated fields as required in our endpoint validation
  - Treat 4 conditionals as required when outage_class=Planned, otherwise optional
  - Reject events missing required fields with explicit error
  - Accept and store the undocumented field as opaque blob; raise vendor query
  - Update FMS-S-103 estimate from "Spike-blocked" to 3 points

Open follow-ups:
  | Vendor query: confirm originator_district_code is intentional and stable | K. Daniel | Risk follow-up |
  | Story to handle outage_class=Emergency separately                        | J. Park   | Story (FMS-S-110) |

Artifacts produced:
  | ADR-022: EMS event validation policy           | /docs/adr/022.md |
  | Captured payload set (50 samples)              | /spikes/sp-018/payloads/ |
  | Endpoint validator prototype                   | /spikes/sp-018/prototype/ (not merged) |
```

---

## Closing the spike

A spike is `Concluded` when:
- [ ] Findings section populated
- [ ] Decision recommended
- [ ] Stakeholders notified of outcome
- [ ] Downstream items unblocked or follow-ups recorded
- [ ] Artifacts archived

A spike that produces "we don't know" after the time-box is still `Concluded` — capture what was tried, what's still unknown, and what to try next. Failed spikes are valuable; suppressed spikes are dangerous.
