# Epic Template

**Use:** Every Epic in the backlog must populate this template. Anything missing is grounds for rejection at backlog refinement.

**Pairs with:** [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §3.

---

## Epic header

| Field | Value |
|---|---|
| **Epic ID** | (e.g., `FMS-E-014`) |
| **Title** | (one sentence; verb-led; operator-meaningful) |
| **Owner (PO)** | (name) |
| **Operations sponsor** | (name) |
| **Bounded service** | FMS / TOMS / DSO / TLS / SDS / DBM / Messaging / Task Manager / Integration |
| **Workflow phase** | Notify / Create / De-energize / Authorize / Execute / Test / Re-energize / Close / cross-cutting |
| **Parity / New-Value** | one only — this Epic is not both |
| **Phase target** | P2 (MVP) / P3 (Incremental) / P4 (Cutover) / P5 (Hypercare) |
| **Status** | Backlog / Ready / In-progress / Done / Cancelled |

---

## Description

A short paragraph that an operator could read and recognize. State the value to the operator, not the technical mechanism. Avoid implementation language.

---

## Why this Epic exists (one paragraph)

Connect to the operator's reality. If `Parity`: which legacy capability does this preserve? If `New-Value`: what new operator decision or efficiency does this unlock — and which operator confirmed they want it?

---

## Success metric

How will we know this Epic delivered its intent?

| Metric | Target | Measurement |
|---|---|---|
| (e.g., Card creation latency) | (e.g., p99 < 800ms) | (e.g., trace span duration in Pre-Prod soak) |
| (e.g., Operator acceptance) | (e.g., panel sign-off) | (e.g., M-06 panel review) |

For `New-Value` Epics, at least one metric must be operator-experienced (not just technical).

---

## Scope (what's in)

Bullet list of capabilities. Be specific.

- 
- 
- 

## Out of scope (what's deliberately not in)

Equally important. State what this Epic does **not** cover, especially adjacent capabilities readers might assume.

- 
- 

---

## Linked stories (forward link)

Populated as the Epic decomposes. List each story with status.

| Story ID | Title | Workflow step | Status |
|---|---|---|---|
| | | | |

---

## Dependencies

| Type | Reference | Notes |
|---|---|---|
| Upstream Epic | (e.g., `FMS-E-002`) | Must complete first |
| Foundational task | (e.g., audit trail framework live) | From P1a |
| Spike | (e.g., `SP-018`) | Must resolve before story refinement |
| External | (e.g., EMS event-schema confirmation) | Vendor coordination |

---

## Risks

| Risk ID | Description | Mitigation |
|---|---|---|
| (R-XXX or new) | | |

---

## Operator SME

Single named operator who is the contract for this Epic's design and acceptance. Not a list — one accountable person plus optional consulted others.

| Role | Name | Time commitment |
|---|---|---|
| Primary SME | | (hrs/wk) |
| Backup SME | | (hrs/wk) |
| Consulted | | (ad-hoc) |

---

## Regulatory / audit notes

If this Epic touches regulatory-tagged capability, link the citation and name the compliance reviewer.

| Citation | Description | Reviewer |
|---|---|---|
| | | |

---

## Decision log (Epic-level)

Material decisions made during this Epic's design or build, beyond what's already in the program decision log.

| Date | Decision | Rationale | Decided by |
|---|---|---|---|
| | | | |

---

## Worked example

```
Epic ID:        FMS-E-014
Title:          Auto-create switching card from EMS breaker-trip event (planned distribution outage)
Owner (PO):     J. Park
Ops sponsor:    R. Chen (Distribution Operations Supervisor)
Bounded service: FMS
Workflow phase: Create
Parity / New-Value: Parity
Phase target:   P2 (MVP)
Status:         Ready

Description:
When EMS detects a breaker-trip on a planned distribution outage, the FMS system
auto-creates a switching card pre-populated with feeder context, defaulting to
the operator's district. Operator reviews and adjusts before promoting the card
to active workflow.

Why this Epic exists:
Operators in the legacy system rely on auto-creation to avoid manual transcription
errors during high-volume outage events. This is a parity capability — direct
replacement of the legacy flow. R. Chen confirms operators expect identical
auto-creation behavior on day one of cutover.

Success metric:
| Metric                              | Target               | Measurement                      |
| Card auto-creation latency (event → card visible) | p99 < 5s | trace span on EMS endpoint to FMS card persisted |
| Field-level parity vs legacy        | 100%                 | parity-test harness vs legacy capture |
| Operator acceptance                 | panel sign-off       | M-06 review                      |

In scope:
  - Card creation from EMS event for planned distribution outage (single feeder, single substation)
  - Default district + operator routing
  - Pre-population of feeder context, breaker, switching points
  - Operator review pane with editable fields per legacy parity

Out of scope:
  - Emergency outage scenarios (separate Epic FMS-E-015)
  - Multi-feeder cards (separate Epic)
  - Cross-substation coordination (separate Epic)
  - New-value features (visual feeder topology preview is in FMS-E-021)

Linked stories:
| FMS-S-101 | Receive EMS event and persist for ingestion          | Notify    | Ready |
| FMS-S-102 | Auto-create card from event for default scenario     | Create    | Ready |
| FMS-S-103 | Pre-populate feeder context fields                   | Create    | Refining |
| FMS-S-104 | Operator review pane with parity-matched layout      | Create    | Refining |
| FMS-S-105 | Audit trail for auto-created cards                   | Create    | Ready |

Dependencies:
| Spike            | SP-018 — Confirm EMS event schema for planned outage  | Must close before SS-103 |
| Foundational     | Audit framework live (P1a)                            | Done                  |
| External         | EMS vendor sample payloads delivered                  | Pending (A-004)       |

Risks:
| R-002 | EMS event schema regression | Contract test against EMS sample harness |
| R-001 | Hidden parity rules in legacy auto-creation | Operator pair-review for SS-104 |

Operator SME:
| Primary SME | R. Chen          | 4 hrs/wk during this Epic   |
| Backup SME  | M. Olusegun      | 1 hr/wk                     |
| Consulted   | District ops panel | 1 hr at sprint demo       |

Regulatory / audit notes:
| NERC CIP-008 (audit trail of card creation) | Operator-action log captured for every card create | Compliance officer J. Reyes |
```

---

## Checklist before this Epic enters Ready

- [ ] All header fields populated (no TBDs)
- [ ] Description is operator-readable
- [ ] Success metrics defined and measurable
- [ ] Scope and out-of-scope explicit
- [ ] Operator SME named (not "TBD")
- [ ] Parity/New-Value classification set
- [ ] Workflow phase tagged
- [ ] Dependencies and risks identified
- [ ] Regulatory citations attached if applicable
