"""
Full Work Breakdown Structure for the Switching Order Modernization program.

Used by _generate.py when populating the Master Schedule sheet of
01-master-project-plan-template.xlsx.

Row tuple structure:
  (WBS, Level, Type, Phase, Workstream, Task, Description,
   Duration_days, Predecessors, RiskRefs, AssumptionRefs, DecisionRefs, Notes)

Level: 1=phase summary, 2=area, 3=work package, 4=task
Type:  Summary | WorkPackage | Milestone
Duration: indicative elapsed days for the work package; summary rows show
         elapsed phase length (not sum of children) to be useful for Gantt views;
         milestones are 0.

Conventions:
  - Owner left as "(name)" — PMO populates per delivery
  - Start/End left as "TBD" — PMO populates per delivery
  - Status default "Not Started", RAG default "Green" until program runs
  - Predecessor refs use WBS IDs; cross-phase predecessors are explicit
"""

# Numbering convention:
# 0  P0a Phase 0 Audit
# 1  P1  Detailed Design
# 2  P1a Foundational
# 3  P1b UDB→CIM POC
# 4  P2  MVP Build (Partial FMS)
# 5  P2a MVP UAT & Approval
# 6  P3  Incremental Build
# 7  P3a Full UAT
# 8  P4  Cutover (6 staggered events)
# 9  P5  Hypercare


WBS_ROWS = [
    # ============================================================
    # 0  P0a — Phase 0 Discovery Audit
    # ============================================================
    ("0",     1, "Summary",     "P0a", "WS-ARC", "P0a — Phase 0 Discovery Audit",
     "Stress-test Discovery outputs (600+ features, 650+ FRs, 1000+ rules) before Phase 1 design depends on them",
     5, "", "R-001", "", "D-002", "Per 00-phase0-discovery-audit-memo.md"),

    ("0.1",   2, "Summary",     "P0a", "WS-ARC", "  Audit setup",
     "Pre-audit preparation", 1, "", "", "", "D-002", ""),
    ("0.1.1", 3, "WorkPackage", "P0a", "WS-ARC", "    Identify audit team (1 lead BA + 1 principal eng)",
     "Resource confirmation", 1, "", "", "A-001, A-002", "", ""),
    ("0.1.2", 3, "WorkPackage", "P0a", "WS-OPS", "    Block operator time (~30 min × 6)",
     "Schedule operator availability per app", 1, "", "", "A-003", "", ""),
    ("0.1.3", 3, "WorkPackage", "P0a", "WS-ARC", "    Prepare audit harness + sampling lists",
     "Tools and artifact list ready before kickoff", 1, "", "", "", "", ""),

    ("0.2",   2, "Summary",     "P0a", "WS-ARC", "  Audit execution (10 dimensions)",
     "RAG-graded audit across the ten dimensions", 3, "0.1.3", "R-001", "", "", ""),
    ("0.2.1", 3, "WorkPackage", "P0a", "WS-ARC", "    D1: Source traceability sampling",
     "30 random items per category; verify source", 1, "", "", "", "", ""),
    ("0.2.2", 3, "WorkPackage", "P0a", "WS-CHM", "    D2: Operator validation coverage check",
     "% confirmed vs analyst-inferred", 1, "", "", "A-003", "", ""),
    ("0.2.3", 3, "WorkPackage", "P0a", "WS-ARC", "    D3: 4GL code triangulation (5 workflows × 6 apps)",
     "Spot-reads of OpenRoad", 2, "", "R-001, R-005", "A-002", "", "Critical risk dimension"),
    ("0.2.4", 3, "WorkPackage", "P0a", "WS-CHM", "    D4: Granularity consistency analysis",
     "Histogram of feature-size distribution", 1, "", "", "", "", ""),
    ("0.2.5", 3, "WorkPackage", "P0a", "WS-ARC", "    D5: Business rule encoding precision sample",
     "50 rules classified encoded vs narrative", 1, "", "", "", "", ""),
    ("0.2.6", 3, "WorkPackage", "P0a", "WS-CHM", "    D6: Aspirational vs actual tag audit",
     "Tag metadata schema validation", 1, "", "", "", "", ""),
    ("0.2.7", 3, "WorkPackage", "P0a", "WS-ARC", "    D7: Conflict & duplication scan",
     "Cross-app + within-app rule conflicts", 1, "", "", "", "", ""),
    ("0.2.8", 3, "WorkPackage", "P0a", "WS-INT", "    D8: Integration contract coverage check",
     "15-20 integrations checklist", 1, "", "R-002", "", "", ""),
    ("0.2.9", 3, "WorkPackage", "P0a", "WS-SEC", "    D9: Audit/regulatory rule completeness",
     "Compliance citations + tagging", 1, "", "R-004", "", "", ""),
    ("0.2.10",3, "WorkPackage", "P0a", "WS-ARC", "    D10: Hidden behavior risk per app",
     "End-to-end 4GL deep-read for one critical workflow per app", 2, "", "R-001, R-005", "A-002", "", "Critical risk dimension"),

    ("0.3",   2, "Summary",     "P0a", "WS-ARC", "  Audit output",
     "Decision-ready outputs published", 1, "0.2", "", "", "", ""),
    ("0.3.1", 3, "WorkPackage", "P0a", "WS-ARC", "    Publish RAG dashboard (one page)",
     "Color-coded results across 10 dimensions", 0.5, "", "", "", "", ""),
    ("0.3.2", 3, "WorkPackage", "P0a", "WS-ARC", "    Recommendation memo (two pages)",
     "Per-dimension findings + remediation cost", 0.5, "", "", "", "", ""),
    ("0.3.3", 3, "WorkPackage", "P0a", "WS-ARC", "    Phase 1 plan adjustments",
     "Scope tweaks if Amber/Red dimensions", 0.5, "", "", "", "", ""),
    ("M-01",  3, "Milestone",   "P0a", "WS-ARC", "    M-01 Phase 0 Audit Complete",
     "All-Green or Amber-with-remediation; no Reds outstanding", 0, "0.3.3", "", "", "", "Gate owner: Program Lead"),


    # ============================================================
    # 1  P1 — Detailed Design (3-5 mo, 1,400 PD)
    # ============================================================
    ("1",     1, "Summary",     "P1", "WS-ARC", "P1 — Detailed Design",
     "Convert Discovery outputs into design artifacts that estimation, build, and test can run against",
     85, "M-01", "R-001, R-006", "", "", "Per 03-technical-architecture-outline.md"),

    ("1.1",   2, "Summary",     "P1", "WS-ARC", "  Architecture detailed design",
     "Per-service domain models + cross-cutting design", 25, "", "", "", "", ""),
    ("1.1.1", 3, "WorkPackage", "P1", "WS-ARC", "    FMS domain model + state machines",
     "Aggregates, value objects, switching workflow state machine", 8, "", "R-001", "A-002", "", ""),
    ("1.1.2", 3, "WorkPackage", "P1", "WS-ARC", "    TOMS domain model",
     "Transmission-specific aggregates", 6, "", "R-001", "", "", ""),
    ("1.1.3", 3, "WorkPackage", "P1", "WS-ARC", "    DSO domain model",
     "Dielectric-specific aggregates", 6, "", "R-001", "", "", ""),
    ("1.1.4", 3, "WorkPackage", "P1", "WS-ARC", "    TLS domain model",
     "Telephonic line domain", 5, "", "", "", "", ""),
    ("1.1.5", 3, "WorkPackage", "P1", "WS-ARC", "    SDS domain model",
     "Steam-specific aggregates", 6, "", "R-001", "", "", ""),
    ("1.1.6", 3, "WorkPackage", "P1", "WS-ARC", "    DBM domain model + reference data",
     "Foundational hierarchy", 8, "", "", "", "", ""),
    ("1.1.7", 3, "WorkPackage", "P1", "WS-ARC", "    Messaging Module design",
     "Operator desk message streams", 4, "", "", "", "", ""),
    ("1.1.8", 3, "WorkPackage", "P1", "WS-ARC", "    Task Manager design",
     "Per-operator orchestration", 3, "", "", "", "", ""),
    ("1.1.9", 3, "WorkPackage", "P1", "WS-ARC", "    ADR catalog + governance",
     "Architecture Decision Record templates + review process", 2, "", "", "", "", ""),
    ("1.1.10",3, "WorkPackage", "P1", "WS-ARC", "    Sequence diagrams per critical workflow",
     "8 workflow steps × 6 apps; key cross-app flows", 6, "", "", "", "", ""),

    ("1.2",   2, "Summary",     "P1", "WS-BE",  "  API & event contracts",
     "REST + async contract specifications", 12, "", "", "", "", ""),
    ("1.2.1", 3, "WorkPackage", "P1", "WS-BE",  "    BFF API contract spec",
     "Aggregating layer contract", 4, "", "", "", "", ""),
    ("1.2.2", 3, "WorkPackage", "P1", "WS-BE",  "    Per-service REST contracts (8 services)",
     "OpenAPI specs for FMS, TOMS, DSO, TLS, SDS, DBM, Messaging, Task Manager", 5, "", "", "", "", ""),
    ("1.2.3", 3, "WorkPackage", "P1", "WS-BE",  "    Async event schemas",
     "Domain events on broker", 3, "", "", "", "", ""),
    ("1.2.4", 3, "WorkPackage", "P1", "WS-QA",  "    Cross-service contract test plan",
     "Pact (or equivalent) consumer-driven contract approach", 2, "", "", "", "", ""),

    ("1.3",   2, "Summary",     "P1", "WS-INT", "  Integration contracts",
     "15-20 integrations specified in detail", 14, "", "R-002", "A-004", "", ""),
    ("1.3.1", 3, "WorkPackage", "P1", "WS-INT", "    EMS/XA21 endpoint contract design",
     "Passive polling endpoint; payload schemas; idempotency keys", 5, "", "R-002", "A-004", "", "Highest scrutiny"),
    ("1.3.2", 3, "WorkPackage", "P1", "WS-INT", "    Rapid Restore adapter contract",
     "Bidirectional REST + status events", 3, "", "", "", "", ""),
    ("1.3.3", 3, "WorkPackage", "P1", "WS-INT", "    GIS integration contract",
     "Spatial / hierarchy reference reads", 2, "", "", "", "", ""),
    ("1.3.4", 3, "WorkPackage", "P1", "WS-INT", "    FeederBoard integration contract",
     "Read + push board updates", 2, "", "", "", "", ""),
    ("1.3.5", 3, "WorkPackage", "P1", "WS-INT", "    CPMS integration contract",
     "Customer project sync", 2, "", "", "", "", ""),
    ("1.3.6", 3, "WorkPackage", "P1", "WS-INT", "    Other integrations (10+)",
     "Remaining external systems specified", 6, "", "", "", "", ""),
    ("1.3.7", 3, "WorkPackage", "P1", "WS-INT", "    Legacy SOAP wrapper specifications",
     "Edge SOAP-to-REST adapter pattern + per-system specs", 3, "", "", "", "", ""),

    ("1.4",   2, "Summary",     "P1", "WS-ARC", "  Network & boundary design (per artifact 04)",
     "Zone-by-zone responsibilities; cross-zone protocol matrix; firewall plan",
     12, "", "R-007", "", "", ""),
    ("1.4.1", 3, "WorkPackage", "P1", "WS-ARC", "    Zone topology finalization",
     "OpNET / DMZ / CorpNET responsibilities locked", 3, "", "", "", "", ""),
    ("1.4.2", 3, "WorkPackage", "P1", "WS-SEC", "    Firewall rule list per boundary",
     "Per-direction allow-list with protocols + ports", 4, "", "R-007", "", "", ""),
    ("1.4.3", 3, "WorkPackage", "P1", "WS-DO",  "    IP addressing scheme per zone",
     "Per-zone subnetting + DNS plan", 2, "", "", "", "", ""),
    ("1.4.4", 3, "WorkPackage", "P1", "WS-SEC", "    Cert authority topology",
     "Internal CA + dedicated EMS-vendor CA + HSM root", 3, "", "", "", "", ""),
    ("1.4.5", 3, "WorkPackage", "P1", "WS-DO",  "    SecOps approval workflow initiated",
     "Engagement; ticket workflow established", 1, "", "R-007", "", "", ""),
    ("1.4.6", 3, "WorkPackage", "P1", "WS-DO",  "    Pre-stage firewall approvals submitted",
     "Submit during P1 to absorb 10–15 day SLA before P1a needs them", 2, "", "R-007", "", "", "Variance reducer per memo §9.3"),

    ("1.5",   2, "Summary",     "P1", "WS-SEC", "  Identity & authorization design",
     "RBAC + AuthN/Z model", 7, "", "", "", "", ""),
    ("1.5.1", 3, "WorkPackage", "P1", "WS-SEC", "    RBAC role + permission model",
     "District + workflow-step granularity", 3, "", "", "", "", ""),
    ("1.5.2", 3, "WorkPackage", "P1", "WS-SEC", "    Identity flow diagrams",
     "AD/Entra hybrid pattern", 2, "", "", "", "", ""),
    ("1.5.3", 3, "WorkPackage", "P1", "WS-SEC", "    District-scoped authorization design",
     "Row-level security + policy-driven access", 1, "", "", "", "", ""),
    ("1.5.4", 3, "WorkPackage", "P1", "WS-SEC", "    Service-to-service auth design",
     "mTLS + service identity", 1, "", "", "", "", ""),

    ("1.6",   2, "Summary",     "P1", "WS-SEC", "  Threat modeling per service (STRIDE)",
     "10 threat models", 10, "", "", "", "", ""),
    ("1.6.1", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: FMS",                     "", 1, "", "", "", "", ""),
    ("1.6.2", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: TOMS",                    "", 1, "", "", "", "", ""),
    ("1.6.3", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: DSO",                     "", 1, "", "", "", "", ""),
    ("1.6.4", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: TLS",                     "", 1, "", "", "", "", ""),
    ("1.6.5", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: SDS",                     "", 1, "", "", "", "", ""),
    ("1.6.6", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: DBM",                     "", 1, "", "", "", "", ""),
    ("1.6.7", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: Messaging Module",        "", 0.5, "", "", "", "", ""),
    ("1.6.8", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: Task Manager",            "", 0.5, "", "", "", "", ""),
    ("1.6.9", 3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: Integration adapters",    "", 1, "", "R-002", "", "", ""),
    ("1.6.10",3, "WorkPackage", "P1", "WS-SEC", "    STRIDE: EMS Polling Endpoint",    "", 2, "", "R-002", "A-004", "", "Highest stakes integration"),

    ("1.7",   2, "Summary",     "P1", "WS-QA",  "  NFR baseline",
     "Latency / availability / audit / accessibility targets", 6, "", "", "", "", ""),
    ("1.7.1", 3, "WorkPackage", "P1", "WS-QA",  "    Latency SLOs per service",
     "Per [16-database-design-principles.md] §12 + service-level overlays", 2, "", "", "", "", ""),
    ("1.7.2", 3, "WorkPackage", "P1", "WS-OPS", "    Availability targets",
     "Steady-state + degraded-mode definition", 1, "", "", "", "", ""),
    ("1.7.3", 3, "WorkPackage", "P1", "WS-SEC", "    Audit completeness NFRs",
     "NFR-AUD-001 + per-service audit specifics", 1, "", "R-004", "", "", ""),
    ("1.7.4", 3, "WorkPackage", "P1", "WS-QA",  "    Performance + load targets",
     "Steady, burst, soak", 1, "", "", "", "", ""),
    ("1.7.5", 3, "WorkPackage", "P1", "WS-FE",  "    Accessibility targets (WCAG 2.2 AA)",
     "Operator console accessibility baseline", 1, "", "", "", "", ""),

    ("1.8",   2, "Summary",     "P1", "WS-QA",  "  Test strategy detailed",
     "Per-layer plans + parity harness design", 7, "", "", "", "", ""),
    ("1.8.1", 3, "WorkPackage", "P1", "WS-QA",  "    Per-layer test plan",
     "Unit / contract / integration / E2E / parity / perf / chaos", 3, "", "", "", "", ""),
    ("1.8.2", 3, "WorkPackage", "P1", "WS-QA",  "    Parity harness design",
     "Legacy capture format; replay engine; diff classification", 3, "", "R-001", "", "", ""),
    ("1.8.3", 3, "WorkPackage", "P1", "WS-QA",  "    Test data refresh plan",
     "Anonymization + Pre-Prod refresh cadence", 1, "", "", "", "", ""),

    ("1.9",   2, "Summary",     "P1", "WS-DATA","  Data architecture detailed design",
     "Per-service schema + audit/temporal + partitioning", 8, "", "R-006", "A-005", "", ""),
    ("1.9.1", 3, "WorkPackage", "P1", "WS-DATA","    Per-service schema design (8 schemas)",
     "fms, toms, dso, tls, sds, dbm, msg, task", 4, "", "", "", "", ""),
    ("1.9.2", 3, "WorkPackage", "P1", "WS-DATA","    Audit/temporal table specifications",
     "System-versioned + operator-action log + auth-decision log + integration log", 2, "", "R-004", "", "", ""),
    ("1.9.3", 3, "WorkPackage", "P1", "WS-DATA","    Partitioning scheme per high-volume table",
     "Time-based monthly partitions; 7-yr retention", 1, "", "", "A-005", "", ""),
    ("1.9.4", 3, "WorkPackage", "P1", "WS-DATA","    Indexing strategy per service",
     "Workload-driven NCI plan; filtered indexes", 1, "", "", "", "", ""),

    ("1.10",  2, "Summary",     "P1", "WS-OPS", "  Operations readiness design",
     "Runbook templates + on-call structure", 4, "", "", "", "", ""),
    ("1.10.1",3, "WorkPackage", "P1", "WS-OPS", "    Service runbook templates",
     "Per-service runbook structure", 2, "", "", "", "", ""),
    ("1.10.2",3, "WorkPackage", "P1", "WS-OPS", "    On-call rota structure",
     "Rotation, escalation, paging policy", 1, "", "", "", "", ""),
    ("1.10.3",3, "WorkPackage", "P1", "WS-OPS", "    SRE patterns adoption",
     "SLO ownership; error budgets", 1, "", "", "", "", ""),

    ("1.11",  2, "Summary",     "P1", "WS-ARC", "  Detailed design milestone",
     "Architecture Council review + M-02 gate", 4, "1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10", "", "", "", ""),
    ("1.11.1",3, "WorkPackage", "P1", "WS-ARC", "    Architecture Council review",
     "Cross-team review of all design artifacts", 2, "", "", "", "", ""),
    ("1.11.2",3, "WorkPackage", "P1", "WS-ARC", "    Re-baseline of estimates against detailed design",
     "B4 estimation worksheet refresh", 2, "", "", "", "", "Estimation gate per [15-estimation-worksheet.md] §5"),
    ("M-02",  3, "Milestone",   "P1", "WS-ARC", "    M-02 Detailed Design Approved",
     "All 6 cores have approved domain models, integration contracts, NFRs", 0, "1.11.1, 1.11.2", "", "", "", "Gate owner: Architecture Council"),


    # ============================================================
    # 2  P1a — Foundational Tasks (2-4 mo, 1,800 PD)
    # ============================================================
    ("2",     1, "Summary",     "P1a", "WS-DO", "P1a — Foundational Tasks",
     "Stand up the platform skeleton so Build can start without environment friction",
     65, "1.4.6", "R-007", "", "", "Per 18-devops-cicd-blueprint.md"),

    ("2.1",   2, "Summary",     "P1a", "WS-DO",  "  CI/CD platform",
     "On-prem ADO + agents + pipelines", 20, "", "R-007", "", "D-004", ""),
    ("2.1.1", 3, "WorkPackage", "P1a", "WS-DO",  "    On-prem Azure DevOps Server stand-up", "", 4, "", "", "", "D-004", ""),
    ("2.1.2", 3, "WorkPackage", "P1a", "WS-DO",  "    On-prem Azure Repos configuration",  "", 2, "", "", "", "D-004", ""),
    ("2.1.3", 3, "WorkPackage", "P1a", "WS-DO",  "    Per-zone agent pools (CorpNET-Dev, CorpNET-Prod, DMZ, OpNET)",
     "Self-hosted agents per zone; one set per environment", 5, "", "R-007", "", "", ""),
    ("2.1.4", 3, "WorkPackage", "P1a", "WS-DO",  "    Cross-zone artifact replication broker (DMZ-resident)",
     "DMZ broker for CorpNET → OpNET artifact transport", 4, "", "R-007", "", "", "Per [18] §16"),
    ("2.1.5", 3, "WorkPackage", "P1a", "WS-DO",  "    Pipeline templates per service shape",
     ".NET service + Angular module + DACPAC patterns", 3, "", "", "", "", ""),
    ("2.1.6", 3, "WorkPackage", "P1a", "WS-SEC", "    SAST integration (CodeQL)",          "", 1, "", "", "", "", ""),
    ("2.1.7", 3, "WorkPackage", "P1a", "WS-SEC", "    Dependency scan integration",        "", 0.5, "", "", "", "", ""),
    ("2.1.8", 3, "WorkPackage", "P1a", "WS-SEC", "    DAST integration (OWASP ZAP)",       "", 0.5, "", "", "", "", ""),

    ("2.2",   2, "Summary",     "P1a", "WS-DO",  "  Environment topology",
     "Dev / SIT / Pre-Prod / Prod / Standby OpNET", 18, "", "R-007", "A-007", "", ""),
    ("2.2.1", 3, "WorkPackage", "P1a", "WS-DO",  "    Dev shared environment provisioning",      "", 2, "", "", "", "", ""),
    ("2.2.2", 3, "WorkPackage", "P1a", "WS-DO",  "    SIT environment provisioning",             "", 3, "", "", "", "", ""),
    ("2.2.3", 3, "WorkPackage", "P1a", "WS-DO",  "    Pre-Prod CorpNET environment",             "", 4, "", "", "", "", ""),
    ("2.2.4", 3, "WorkPackage", "P1a", "WS-DO",  "    Pre-Prod DMZ environment",                 "", 2, "", "R-007", "", "", ""),
    ("2.2.5", 3, "WorkPackage", "P1a", "WS-DO",  "    Pre-Prod OpNET environment",               "", 3, "", "R-007", "A-007", "", ""),
    ("2.2.6", 3, "WorkPackage", "P1a", "WS-DO",  "    Prod environment baseline (CorpNET)",      "", 3, "", "", "", "", "Empty awaiting first deploy"),
    ("2.2.7", 3, "WorkPackage", "P1a", "WS-DO",  "    Standby OpNET environment baseline",       "", 3, "", "R-009", "A-007", "", ""),
    ("2.2.8", 3, "WorkPackage", "P1a", "WS-DO",  "    Test data refresh tooling",
     "Anonymization + Prod-to-PreProd refresh", 2, "", "", "", "", ""),

    ("2.3",   2, "Summary",     "P1a", "WS-SEC", "  Identity & authorization",
     "IdP integration + service accounts + RBAC + mTLS", 8, "", "", "", "", ""),
    ("2.3.1", 3, "WorkPackage", "P1a", "WS-SEC", "    IdP integration (AD/Entra hybrid)",        "", 3, "", "", "", "", ""),
    ("2.3.2", 3, "WorkPackage", "P1a", "WS-SEC", "    Service account provisioning (gMSA)",     "", 2, "", "", "", "", ""),
    ("2.3.3", 3, "WorkPackage", "P1a", "WS-SEC", "    RBAC role configuration",                  "", 2, "", "", "", "", ""),
    ("2.3.4", 3, "WorkPackage", "P1a", "WS-SEC", "    mTLS internal CA setup + automation",     "", 3, "", "", "", "", ""),

    ("2.4",   2, "Summary",     "P1a", "WS-DATA","  Database foundational",
     "SQL Server 2025 cluster + AG + temporal + audit + backups", 18, "", "R-009", "", "", "Per 16-database-design-principles.md"),
    ("2.4.1", 3, "WorkPackage", "P1a", "WS-DATA","    SQL Server 2025 cluster build (CorpNET)",  "", 3, "", "", "", "", ""),
    ("2.4.2", 3, "WorkPackage", "P1a", "WS-DATA","    SQL Server cluster build (OpNET)",         "", 3, "", "", "A-007", "", ""),
    ("2.4.3", 3, "WorkPackage", "P1a", "WS-DATA","    AlwaysOn AG configuration",                "", 2, "", "", "", "", ""),
    ("2.4.4", 3, "WorkPackage", "P1a", "WS-DATA","    Cross-zone replication (CorpNET ↔ OpNET)",
     "Synchronous commit; DMZ-mediated", 3, "", "R-009", "", "", ""),
    ("2.4.5", 3, "WorkPackage", "P1a", "WS-DATA","    Per-service schema baseline (8 schemas)",  "", 2, "", "", "", "", ""),
    ("2.4.6", 3, "WorkPackage", "P1a", "WS-DATA","    Audit & temporal foundational implementation",
     "FOUND-S-022; NFR-AUD-001 live", 4, "", "R-004", "", "", "Hash chain + temporal tables"),
    ("2.4.7", 3, "WorkPackage", "P1a", "WS-DATA","    Hash chain implementation + verification job",
     "Daily tamper-detection", 2, "", "R-004", "", "", ""),
    ("2.4.8", 3, "WorkPackage", "P1a", "WS-DATA","    Partitioning scaffolding",
     "Monthly partitions on high-volume tables", 2, "", "", "", "", ""),
    ("2.4.9", 3, "WorkPackage", "P1a", "WS-DATA","    Backup + recovery setup",                  "", 2, "", "", "", "", ""),
    ("2.4.10",3, "WorkPackage", "P1a", "WS-DATA","    First DR drill (intra-zone failover)",    "", 1, "", "", "", "", ""),

    ("2.5",   2, "Summary",     "P1a", "WS-BE",  "  Native message broker",
     "SQL Server Service Broker + queue table patterns", 7, "", "", "", "", ""),
    ("2.5.1", 3, "WorkPackage", "P1a", "WS-BE",  "    Service Broker setup",                     "", 3, "", "", "", "", ""),
    ("2.5.2", 3, "WorkPackage", "P1a", "WS-BE",  "    Queue table patterns",                     "", 2, "", "", "", "", ""),
    ("2.5.3", 3, "WorkPackage", "P1a", "WS-BE",  "    Outbox pattern reference implementation",  "", 2, "", "", "", "", ""),

    ("2.6",   2, "Summary",     "P1a", "WS-BE",  "  Backend skeleton (.NET 8/9)",
     "ASP.NET Core service template + cross-cutting concerns", 12, "", "", "", "", ""),
    ("2.6.1", 3, "WorkPackage", "P1a", "WS-BE",  "    ASP.NET Core service template",            "", 2, "", "", "", "", ""),
    ("2.6.2", 3, "WorkPackage", "P1a", "WS-BE",  "    Cross-cutting (logging/telemetry/error contracts)", "", 2, "", "", "", "", ""),
    ("2.6.3", 3, "WorkPackage", "P1a", "WS-BE",  "    EF Core integration template",             "", 1, "", "", "", "", ""),
    ("2.6.4", 3, "WorkPackage", "P1a", "WS-BE",  "    MediatR / CQRS template",                  "", 1, "", "", "", "", ""),
    ("2.6.5", 3, "WorkPackage", "P1a", "WS-BE",  "    Hangfire integration",                     "", 1, "", "", "", "", ""),
    ("2.6.6", 3, "WorkPackage", "P1a", "WS-BE",  "    Audit logger reference implementation",
     "IOperatorActionLogger across services", 3, "", "R-004", "", "", ""),
    ("2.6.7", 3, "WorkPackage", "P1a", "WS-BE",  "    Domain event dispatch reference",          "", 2, "", "", "", "", ""),

    ("2.7",   2, "Summary",     "P1a", "WS-FE",  "  Frontend skeleton (Angular)",
     "Operator console shell + design system + state mgmt + accessibility", 10, "", "", "", "", ""),
    ("2.7.1", 3, "WorkPackage", "P1a", "WS-FE",  "    Angular shell application",                "", 2, "", "", "", "", ""),
    ("2.7.2", 3, "WorkPackage", "P1a", "WS-FE",  "    Design system foundation",                 "", 3, "", "R-003", "", "", "Mental-model parity is design"),
    ("2.7.3", 3, "WorkPackage", "P1a", "WS-FE",  "    NgRx state management template",           "", 2, "", "", "", "", ""),
    ("2.7.4", 3, "WorkPackage", "P1a", "WS-FE",  "    Module-per-service routing",               "", 1, "", "", "", "", ""),
    ("2.7.5", 3, "WorkPackage", "P1a", "WS-FE",  "    SignalR integration template",             "", 1, "", "", "", "", ""),
    ("2.7.6", 3, "WorkPackage", "P1a", "WS-FE",  "    Accessibility baseline (WCAG 2.2 AA)",     "", 1, "", "", "", "", ""),

    ("2.8",   2, "Summary",     "P1a", "WS-DO",  "  Observability stack",
     "OpenTelemetry + ELK/Prometheus/Jaeger + Grafana + alerts", 9, "", "", "", "", ""),
    ("2.8.1", 3, "WorkPackage", "P1a", "WS-DO",  "    OpenTelemetry collectors per zone",        "", 2, "", "", "", "", ""),
    ("2.8.2", 3, "WorkPackage", "P1a", "WS-DO",  "    ELK / equivalent log aggregation",         "", 2, "", "", "", "", ""),
    ("2.8.3", 3, "WorkPackage", "P1a", "WS-DO",  "    Prometheus / Mimir metrics",               "", 1, "", "", "", "", ""),
    ("2.8.4", 3, "WorkPackage", "P1a", "WS-DO",  "    Jaeger / Tempo trace storage",             "", 1, "", "", "", "", ""),
    ("2.8.5", 3, "WorkPackage", "P1a", "WS-DO",  "    Grafana dashboards baseline",              "", 2, "", "", "", "", ""),
    ("2.8.6", 3, "WorkPackage", "P1a", "WS-DO",  "    Alerting rules baseline",                  "", 1, "", "", "", "", ""),

    ("2.9",   2, "Summary",     "P1a", "WS-SEC", "  Secrets management",
     "On-prem Vault deployment + pipeline integration", 5, "", "", "", "", ""),
    ("2.9.1", 3, "WorkPackage", "P1a", "WS-SEC", "    Vault deployment (HashiCorp / equivalent)", "", 2, "", "", "", "", ""),
    ("2.9.2", 3, "WorkPackage", "P1a", "WS-SEC", "    Pipeline integration",                     "", 2, "", "", "", "", ""),
    ("2.9.3", 3, "WorkPackage", "P1a", "WS-SEC", "    Cert rotation automation",                 "", 1, "", "", "", "", ""),

    ("2.10",  2, "Summary",     "P1a", "WS-QA",  "  Test platform",
     "Test harnesses across all layers", 8, "", "", "", "", ""),
    ("2.10.1",3, "WorkPackage", "P1a", "WS-QA",  "    xUnit test harness",                       "", 1, "", "", "", "", ""),
    ("2.10.2",3, "WorkPackage", "P1a", "WS-QA",  "    Pact contract test platform",              "", 2, "", "", "", "", ""),
    ("2.10.3",3, "WorkPackage", "P1a", "WS-QA",  "    Playwright E2E platform",                  "", 2, "", "", "", "", ""),
    ("2.10.4",3, "WorkPackage", "P1a", "WS-QA",  "    k6 / JMeter performance platform",         "", 2, "", "", "", "", ""),
    ("2.10.5",3, "WorkPackage", "P1a", "WS-QA",  "    Chaos engineering harness",                "", 1, "", "", "", "", ""),

    ("2.11",  2, "Summary",     "P1a", "WS-DO",  "  Foundational milestone",
     "M-03 gate", 2, "2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 2.10", "", "", "", ""),
    ("M-03",  3, "Milestone",   "P1a", "WS-DO",  "    M-03 Foundational Platform Live",
     "Dev/SIT envs operational; CI/CD green for skeleton; identity working", 0, "", "", "", "", "Gate owner: Engineering Lead"),


    # ============================================================
    # 3  P1b — UDB → CIM POC (1.5-3 mo, 600 PD)
    # ============================================================
    ("3",     1, "Summary",     "P1b", "WS-DATA","P1b — UDB → CIM POC",
     "Prove the data-model conversion approach before migration scope is sized",
     45, "M-03", "R-006", "A-008", "", "Per 17-data-migration-strategy.md §4.3"),

    ("3.1",   2, "Summary",     "P1b", "WS-DATA","  Source profiling",
     "Profile Ingres source before transform design", 10, "", "R-006", "", "", ""),
    ("3.1.1", 3, "WorkPackage", "P1b", "WS-DATA","    Ingres source profiling tooling",          "", 2, "", "", "", "", ""),
    ("3.1.2", 3, "WorkPackage", "P1b", "WS-DATA","    Per-table row count + distinct value analysis", "", 2, "", "", "", "", ""),
    ("3.1.3", 3, "WorkPackage", "P1b", "WS-DATA","    Type discovery (declared vs detected)",    "", 2, "", "", "", "", ""),
    ("3.1.4", 3, "WorkPackage", "P1b", "WS-DATA","    Date-range coverage per audit-relevant table", "", 2, "", "", "A-005", "", ""),
    ("3.1.5", 3, "WorkPackage", "P1b", "WS-DATA","    Referential integrity scan (orphan detection)", "", 2, "", "", "", "", ""),

    ("3.2",   2, "Summary",     "P1b", "WS-DATA","  CIM target design",
     "CIM mapping for FMS feeder hierarchy", 8, "", "R-006", "A-008", "", ""),
    ("3.2.1", 3, "WorkPackage", "P1b", "WS-DATA","    CIM 17 vs 18 selection",                   "", 1, "", "", "A-008", "", ""),
    ("3.2.2", 3, "WorkPackage", "P1b", "WS-DATA","    Feeder hierarchy CIM mapping (FMS)",       "", 4, "", "R-006", "", "", "Drives type mapping spec"),
    ("3.2.3", 3, "WorkPackage", "P1b", "WS-DATA","    CIM extension catalog start",
     "Document utility-specific extensions required", 3, "", "R-006", "", "", ""),

    ("3.3",   2, "Summary",     "P1b", "WS-DATA","  ETL pattern build",
     "Extract → stage → transform → load", 12, "", "R-006", "", "", ""),
    ("3.3.1", 3, "WorkPackage", "P1b", "WS-DATA","    Extract job (Ingres → staging)",           "", 3, "", "", "", "", ""),
    ("3.3.2", 3, "WorkPackage", "P1b", "WS-DATA","    Staging schema build",                     "", 2, "", "", "", "", ""),
    ("3.3.3", 3, "WorkPackage", "P1b", "WS-DATA","    Transform stored procedures (FMS)",
     "T-SQL transforms; versioned, repeatable, reviewable", 5, "", "R-006", "", "", ""),
    ("3.3.4", 3, "WorkPackage", "P1b", "WS-DATA","    Load procedures (staging → per-service)",  "", 2, "", "", "", "", ""),

    ("3.4",   2, "Summary",     "P1b", "WS-QA",  "  Reconciliation harness",
     "Three-layer harness — row, aggregate, behavioral", 12, "", "", "", "", ""),
    ("3.4.1", 3, "WorkPackage", "P1b", "WS-QA",  "    Row-level diff harness",                   "", 4, "", "", "", "", ""),
    ("3.4.2", 3, "WorkPackage", "P1b", "WS-QA",  "    Aggregate diff harness",                   "", 2, "", "", "", "", ""),
    ("3.4.3", 3, "WorkPackage", "P1b", "WS-QA",  "    Behavioral query corpus capture",
     "Capture from Ingres production logs", 3, "", "", "", "", ""),
    ("3.4.4", 3, "WorkPackage", "P1b", "WS-QA",  "    Behavioral diff harness",                  "", 2, "", "", "", "", ""),
    ("3.4.5", 3, "WorkPackage", "P1b", "WS-QA",  "    Mismatch reporting + classification",
     "Distinguish bugs from legitimate translations", 1, "", "", "", "", ""),

    ("3.5",   2, "Summary",     "P1b", "WS-DATA","  POC execution",
     "Initial run + iterations + projection", 10, "3.3, 3.4", "", "", "", ""),
    ("3.5.1", 3, "WorkPackage", "P1b", "WS-DATA","    Initial run + defect log",                 "", 2, "", "", "", "", ""),
    ("3.5.2", 3, "WorkPackage", "P1b", "WS-DATA","    Iteration cycle (3+)",                     "", 6, "", "", "", "", ""),
    ("3.5.3", 3, "WorkPackage", "P1b", "WS-DATA","    Throughput projection at production volume", "", 1, "", "", "", "", ""),
    ("3.5.4", 3, "WorkPackage", "P1b", "WS-DATA","    Failure-mode catalog (UDB constructs that don't map)", "", 1, "", "R-006", "", "", ""),

    ("3.6",   2, "Summary",     "P1b", "WS-DATA","  POC outputs + milestone",
     "Deliverables and gate decision", 3, "3.5", "", "", "", ""),
    ("3.6.1", 3, "WorkPackage", "P1b", "WS-DATA","    Type mapping specification",
     "Every UDB type → SQL Server type", 1, "", "", "", "", ""),
    ("3.6.2", 3, "WorkPackage", "P1b", "WS-DATA","    CIM extension catalog finalized",          "", 1, "", "", "", "", ""),
    ("3.6.3", 3, "WorkPackage", "P1b", "WS-DATA","    Reconciliation harness delivered (reusable)", "", 0.5, "", "", "", "", ""),
    ("3.6.4", 3, "WorkPackage", "P1b", "WS-DATA","    Re-baseline of P3 data work estimates",    "", 0.5, "", "", "", "", "Estimation gate"),
    ("M-04",  3, "Milestone",   "P1b", "WS-DATA","    M-04 UDB→CIM POC Pass",
     "Reconciliation report shows ≥99.9% row-level fidelity on FMS sample", 0, "3.6.1, 3.6.2, 3.6.3", "", "", "", "Gate owner: Data Architecture"),


    # ============================================================
    # 4  P2 — MVP Build (Partial FMS) (5-8 mo, 2,240 PD)
    # ============================================================
    ("4",     1, "Summary",     "P2", "WS-FE", "P2 — MVP Build (Partial FMS, single canonical scenario)",
     "Operator-facing first slice; vertical slice through 8 workflow steps for planned distribution outage",
     140, "M-03", "R-001, R-002, R-003", "A-003", "D-005", "Per 15-estimation-worksheet.md §2.1"),

    ("4.1",   2, "Summary",     "P2", "WS-OPS", "  MVP scope finalization",
     "Operator panel + Epic catalog + new-value features defined", 10, "", "", "A-003", "", ""),
    ("4.1.1", 3, "WorkPackage", "P2", "WS-OPS", "    MVP Epic catalog finalized (22 Epics)",
     "18 Parity + 4 New-Value", 3, "", "", "", "", ""),
    ("4.1.2", 3, "WorkPackage", "P2", "WS-OPS", "    New-value features defined (4 NV Epics)",
     "20% target validated by operator panel", 3, "", "", "", "", ""),
    ("4.1.3", 3, "WorkPackage", "P2", "WS-OPS", "    Operator panel composed (3-5 operators)", "", 2, "", "R-003", "A-003", "", ""),
    ("4.1.4", 3, "WorkPackage", "P2", "WS-OPS", "    Operator co-design workshops scheduled",  "", 2, "", "R-003", "A-003", "", ""),

    ("4.2",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 1: Notify",
     "EMS event ingestion", 8, "", "R-002", "A-004", "", ""),
    ("4.2.1", 3, "WorkPackage", "P2", "WS-INT", "    EMS event ingestion (FMS-E-001)",
     "Endpoint receives + persists; idempotent", 6, "", "R-002", "A-004", "", ""),
    ("4.2.2", 3, "WorkPackage", "P2", "WS-QA",  "    Endpoint smoke + unit + contract tests",   "", 2, "", "", "", "", ""),

    ("4.3",   2, "Summary",     "P2", "WS-FE",  "  Workflow Step 2: Create",
     "Auto-create + review pane + edit + new-value features", 28, "4.2", "R-001", "A-003", "", ""),
    ("4.3.1", 3, "WorkPackage", "P2", "WS-BE",  "    Auto-create card from EMS event (FMS-E-002)", "", 8, "", "R-001", "", "", ""),
    ("4.3.2", 3, "WorkPackage", "P2", "WS-FE",  "    Card review pane (parity layout) (FMS-E-003)", "", 5, "", "R-003", "A-003", "", ""),
    ("4.3.3", 3, "WorkPackage", "P2", "WS-BE",  "    Card edit / pre-execution validation (FMS-E-004)", "", 5, "", "R-001", "", "", ""),
    ("4.3.4", 3, "WorkPackage", "P2", "WS-FE",  "    Visual feeder topology preview (FMS-NV-001)",
     "New-value: visual topology overlay", 6, "", "R-003", "", "", "New-value Epic"),
    ("4.3.5", 3, "WorkPackage", "P2", "WS-BE",  "    Auto-suggest similar past cards (FMS-NV-003)",
     "New-value: decision support", 4, "", "", "", "", "New-value Epic"),

    ("4.4",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 3: De-energize",
     "De-energize orchestration + tag application", 14, "4.3", "R-001", "", "", ""),
    ("4.4.1", 3, "WorkPackage", "P2", "WS-BE",  "    De-energize step orchestration (FMS-E-005)", "", 8, "", "R-001", "", "", ""),
    ("4.4.2", 3, "WorkPackage", "P2", "WS-BE",  "    Tag application (single tag, single holder) (FMS-E-006)", "", 6, "", "", "", "", ""),

    ("4.5",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 4: Authorize",
     "Auth workflow + supervisor approval flow", 12, "4.4", "", "", "", ""),
    ("4.5.1", 3, "WorkPackage", "P2", "WS-BE",  "    Authorization workflow (FMS-E-007)",       "", 7, "", "", "", "", ""),
    ("4.5.2", 3, "WorkPackage", "P2", "WS-FE",  "    Mobile read-only supervisor view (FMS-NV-004)",
     "New-value: supervisor approval on mobile", 5, "", "", "", "", "New-value Epic"),

    ("4.6",   2, "Summary",     "P2", "WS-INT", "  Workflow Step 5: Execute",
     "RR handoff + status updates", 14, "4.5", "R-002", "", "", ""),
    ("4.6.1", 3, "WorkPackage", "P2", "WS-INT", "    Field execution handoff to Rapid Restore (FMS-E-008)", "", 8, "", "R-002", "", "", ""),
    ("4.6.2", 3, "WorkPackage", "P2", "WS-INT", "    Step status updates from Rapid Restore (FMS-E-009)",   "", 6, "", "", "", "", ""),

    ("4.7",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 6: Test",
     "Test-de-energized verification", 5, "4.6", "", "", "", ""),
    ("4.7.1", 3, "WorkPackage", "P2", "WS-BE",  "    Test-de-energized verification (FMS-E-010)", "", 5, "", "", "", "", ""),

    ("4.8",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 7: Re-energize",
     "Re-energize orchestration + breaker-close to EMS", 12, "4.7", "R-002", "A-004", "", ""),
    ("4.8.1", 3, "WorkPackage", "P2", "WS-BE",  "    Re-energize orchestration (FMS-E-011)",            "", 7, "", "", "", "", ""),
    ("4.8.2", 3, "WorkPackage", "P2", "WS-INT", "    Breaker-close instruction queued for EMS (FMS-E-012)", "", 5, "", "R-002", "A-004", "", ""),

    ("4.9",   2, "Summary",     "P2", "WS-BE",  "  Workflow Step 8: Close",
     "Card close + audit finalization", 5, "4.8", "R-004", "", "", ""),
    ("4.9.1", 3, "WorkPackage", "P2", "WS-BE",  "    Card close + audit trail finalization (FMS-E-013)", "", 5, "", "R-004", "", "", ""),

    ("4.10",  2, "Summary",     "P2", "WS-FE",  "  Cross-cutting MVP",
     "Console nav + auth + audit + telemetry + NFR + RT collab", 25, "", "R-004", "", "", ""),
    ("4.10.1",3, "WorkPackage", "P2", "WS-FE",  "    Operator console workflow navigation (FMS-E-014)", "", 7, "", "R-003", "A-003", "", ""),
    ("4.10.2",3, "WorkPackage", "P2", "WS-SEC", "    RBAC + AuthN/Z (FMS-E-015)",                       "", 7, "", "", "", "", ""),
    ("4.10.3",3, "WorkPackage", "P2", "WS-DATA","    Audit & operator-action log integration (FMS-E-016)", "", 9, "", "R-004", "", "", "Inherits NFR-AUD-001"),
    ("4.10.4",3, "WorkPackage", "P2", "WS-DO",  "    Telemetry instrumentation (FMS-E-017)",            "", 5, "", "", "", "", ""),
    ("4.10.5",3, "WorkPackage", "P2", "WS-QA",  "    NFR validation (latency + audit completeness) (FMS-E-018)", "", 4, "", "", "", "", ""),
    ("4.10.6",3, "WorkPackage", "P2", "WS-FE",  "    Real-time multi-operator card visibility (FMS-NV-002)",
     "New-value: SignalR-based collab", 7, "", "", "", "", "New-value Epic"),

    ("4.11",  2, "Summary",     "P2", "WS-CHM", "  Continuous integration activities",
     "Sprint demos + parity audits + defect cycles + refinement",
     "ongoing", "", "R-003", "A-003", "", ""),
    ("4.11.1",3, "WorkPackage", "P2", "WS-CHM", "    Sprint demos with operator panel (per sprint)",
     "13 sprints in P2; operator validation continuous", "ongoing", "", "R-003", "A-003", "", ""),
    ("4.11.2",3, "WorkPackage", "P2", "WS-FE",  "    Mental-model parity audits (per parity story)",
     "DoD requirement; UX + Operator SME", "ongoing", "", "R-003", "", "", ""),
    ("4.11.3",3, "WorkPackage", "P2", "WS-QA",  "    Defect triage cycles",
     "Per [11-bug-template.md] severity scale", "ongoing", "", "", "", "", ""),
    ("4.11.4",3, "WorkPackage", "P2", "WS-CHM", "    Story refinement (DoR enforcement)",
     "BA Lead + Engineering Lead enforce; per [05] §8", "ongoing", "", "", "", "", ""),

    ("4.12",  2, "Summary",     "P2", "WS-OPS", "  MVP completion",
     "M-05 gate + estimate re-baseline", 5, "4.2..4.10", "", "", "", ""),
    ("4.12.1",3, "WorkPackage", "P2", "WS-QA",  "    All MVP stories meet engineering DoD",      "", 3, "", "", "", "", ""),
    ("4.12.2",3, "WorkPackage", "P2", "WS-ARC", "    Re-baseline of P3 estimates against MVP velocity",
     "Estimation gate", 2, "", "", "", "", ""),
    ("M-05",  3, "Milestone",   "P2", "WS-BE",  "    M-05 MVP Feature-Complete (FMS)",
     "All MVP user stories Done per DoD", 0, "4.12.1, 4.12.2", "", "", "", "Gate owner: Engineering Lead"),


    # ============================================================
    # 5  P2a — MVP UAT & Approval (1.5-3 mo, 700 PD) — HARDEST GATE
    # ============================================================
    ("5",     1, "Summary",     "P2a", "WS-OPS", "P2a — MVP UAT & Approval (HARD GATE)",
     "Operator panel signs off on parity + tangible new value + audit completeness",
     45, "M-05", "R-003", "A-003", "", "Per 19-test-strategy.md §6"),

    ("5.1",   2, "Summary",     "P2a", "WS-QA",  "  UAT Cycle 1 (2 weeks)",
     "Initial scenario execution + defects",
     10, "", "R-003", "A-003", "", ""),
    ("5.1.1", 3, "WorkPackage", "P2a", "WS-QA",  "    Scenario execution",     "", 6, "", "", "", "", ""),
    ("5.1.2", 3, "WorkPackage", "P2a", "WS-QA",  "    Defect logging + triage", "", 2, "", "", "", "", ""),
    ("5.1.3", 3, "WorkPackage", "P2a", "WS-BE",  "    Defect fixes",            "", 2, "", "", "", "", ""),

    ("5.2",   2, "Summary",     "P2a", "WS-QA",  "  UAT Cycle 2 (2 weeks)",     "", 10, "5.1", "", "", "", ""),
    ("5.2.1", 3, "WorkPackage", "P2a", "WS-QA",  "    Scenario execution + regression", "", 6, "", "", "", "", ""),
    ("5.2.2", 3, "WorkPackage", "P2a", "WS-BE",  "    Defect logging + fixes", "", 4, "", "", "", "", ""),

    ("5.3",   2, "Summary",     "P2a", "WS-QA",  "  UAT Cycle 3 (2 weeks)",     "", 10, "5.2", "", "", "", ""),
    ("5.3.1", 3, "WorkPackage", "P2a", "WS-QA",  "    Scenario execution",      "", 6, "", "", "", "", ""),
    ("5.3.2", 3, "WorkPackage", "P2a", "WS-BE",  "    Defect logging + fixes",  "", 4, "", "", "", "", ""),

    ("5.4",   2, "Summary",     "P2a", "WS-QA",  "  UAT Cycle 4 (2 weeks)",
     "Final scenarios + sign-off prep", 10, "5.3", "", "", "", ""),
    ("5.4.1", 3, "WorkPackage", "P2a", "WS-QA",  "    Final scenarios",                  "", 5, "", "", "", "", ""),
    ("5.4.2", 3, "WorkPackage", "P2a", "WS-OPS", "    Sign-off panel preparation",       "", 3, "", "R-003", "", "", ""),
    ("5.4.3", 3, "WorkPackage", "P2a", "WS-BE",  "    Final defect fixes",               "", 2, "", "", "", "", ""),

    ("5.5",   2, "Summary",     "P2a", "WS-OPS", "  New-value validation",
     "Tangible new value features demoed and validated", 3, "", "", "", "", ""),
    ("5.5.1", 3, "WorkPackage", "P2a", "WS-OPS", "    New-value features demonstrated",  "", 1, "", "", "", "", ""),
    ("5.5.2", 3, "WorkPackage", "P2a", "WS-OPS", "    Operator panel concurrence (NV)",  "", 2, "", "R-003", "", "", ""),

    ("5.6",   2, "Summary",     "P2a", "WS-SEC", "  Audit & compliance verification",
     "AC patterns A/B/C/D verified", 3, "", "R-004", "", "", ""),
    ("5.6.1", 3, "WorkPackage", "P2a", "WS-SEC", "    Audit AC patterns verification",   "", 1, "", "R-004", "", "", ""),
    ("5.6.2", 3, "WorkPackage", "P2a", "WS-SEC", "    Compliance officer review",        "", 1, "", "", "", "", ""),
    ("5.6.3", 3, "WorkPackage", "P2a", "WS-SEC", "    Regulator dry-run consideration",  "", 1, "", "R-004", "", "", ""),

    ("5.7",   2, "Summary",     "P2a", "WS-OPS", "  M-06 gate — HARD GATE",
     "Hardest gate in program", 4, "5.4, 5.5, 5.6", "R-003", "A-003", "", "Hardest gate per 02-milestone-phase-timeline.md §2"),
    ("5.7.1", 3, "WorkPackage", "P2a", "WS-OPS", "    Operator panel sign-off (consensus)", "", 1, "", "R-003", "", "", ""),
    ("5.7.2", 3, "WorkPackage", "P2a", "WS-QA",  "    All severity-1 defects closed",       "", 1, "", "", "", "", ""),
    ("5.7.3", 3, "WorkPackage", "P2a", "WS-OPS", "    Tangible new-value validated",        "", 1, "", "", "", "", ""),
    ("5.7.4", 3, "WorkPackage", "P2a", "WS-SEC", "    Audit completeness verified",         "", 0.5, "", "", "", "", ""),
    ("5.7.5", 3, "WorkPackage", "P2a", "WS-OPS", "    Sponsor decision recorded",           "", 0.5, "", "", "", "", ""),
    ("M-06",  3, "Milestone",   "P2a", "WS-OPS", "    M-06 MVP Operator Approval",
     "Operator panel signs off; mental-model parity achieved; tangible new value validated", 0, "5.7.1..5.7.5",
     "R-003", "", "", "Gate owner: District Operators — HARDEST GATE"),


    # ============================================================
    # 6  P3 — Incremental Build (12-20 mo, 11,950 PD)
    # ============================================================
    ("6",     1, "Summary",     "P3", "WS-BE", "P3 — Incremental Build",
     "Remaining 5 cores + monitor apps + integrations; sequence FMS(rest) → TOMS → DBM → DSO → SDS → TLS",
     330, "M-06", "R-001, R-005", "", "", "Per 15-estimation-worksheet.md §2.3"),

    ("6.1",   2, "Summary",     "P3", "WS-OPS", "  Build planning + sequencing",
     "Sequencing + team formation", 10, "", "", "A-002", "", ""),
    ("6.1.1", 3, "WorkPackage", "P3", "WS-OPS", "    Sequencing finalized (TOMS → DBM → DSO → SDS → TLS)", "", 2, "", "", "", "", ""),
    ("6.1.2", 3, "WorkPackage", "P3", "WS-ARC", "    Pattern-reuse strategy from FMS",
     "Plan 30% reuse not 60% per memo §1.2", 2, "", "", "", "", ""),
    ("6.1.3", 3, "WorkPackage", "P3", "WS-OPS", "    Per-app team formation",                   "", 3, "", "", "A-001", "", ""),
    ("6.1.4", 3, "WorkPackage", "P3", "WS-OPS", "    Per-app PO assignment",                    "", 1, "", "", "", "", ""),
    ("6.1.5", 3, "WorkPackage", "P3", "WS-OPS", "    Per-app operator SME assignment",          "", 2, "", "R-003", "A-003", "", ""),

    ("6.2",   2, "Summary",     "P3", "WS-FE",  "  Remaining FMS scope (post-MVP)",
     "Multi-tag, emergency, multi-feeder, edge cases", 50, "M-06", "R-001", "", "", ""),
    ("6.2.1", 3, "WorkPackage", "P3", "WS-BE",  "    Multi-tag scenarios",                      "", 12, "", "R-001", "", "", ""),
    ("6.2.2", 3, "WorkPackage", "P3", "WS-BE",  "    Emergency switching scenarios",            "", 14, "", "R-001", "", "", ""),
    ("6.2.3", 3, "WorkPackage", "P3", "WS-BE",  "    Multi-feeder cards",                       "", 8, "", "R-001", "", "", ""),
    ("6.2.4", 3, "WorkPackage", "P3", "WS-BE",  "    Cross-substation coordination",            "", 8, "", "R-001", "", "", ""),
    ("6.2.5", 3, "WorkPackage", "P3", "WS-BE",  "    Edge-case business rules",                 "", 5, "", "R-001", "", "", ""),
    ("6.2.6", 3, "WorkPackage", "P3", "WS-BE",  "    Additional new-value features (FMS)",      "", 3, "", "", "", "", ""),

    ("6.3",   2, "Summary",     "P3", "WS-FE",  "  TOMS — Transmission Operations Management",
     "Transmission feeder switching", 60, "M-06, 6.2 partial", "R-001", "", "", ""),
    ("6.3.1", 3, "WorkPackage", "P3", "WS-OPS", "    TOMS Epic catalog + sequencing",           "", 3, "", "", "", "", ""),
    ("6.3.2", 3, "WorkPackage", "P3", "WS-BE",  "    TOMS workflow steps 1-4 (Notify→Authorize)", "", 18, "", "R-001", "", "", ""),
    ("6.3.3", 3, "WorkPackage", "P3", "WS-BE",  "    TOMS workflow steps 5-8 (Execute→Close)",   "", 16, "", "R-001", "", "", ""),
    ("6.3.4", 3, "WorkPackage", "P3", "WS-BE",  "    Cross-substation coordination (transmission)", "", 8, "", "R-001", "", "", ""),
    ("6.3.5", 3, "WorkPackage", "P3", "WS-FE",  "    TOMS new-value Epics",                      "", 7, "", "", "", "", ""),
    ("6.3.6", 3, "WorkPackage", "P3", "WS-QA",  "    TOMS UAT (per-app)",                        "", 8, "", "R-003", "A-003", "", ""),

    ("6.4",   2, "Summary",     "P3", "WS-DATA","  DBM — Basic System Data + Hierarchy",
     "Foundational data; data-centric not workflow-centric", 40, "6.3 partial", "", "", "", ""),
    ("6.4.1", 3, "WorkPackage", "P3", "WS-DATA","    DBM data model migration",                 "", 8, "", "", "", "", ""),
    ("6.4.2", 3, "WorkPackage", "P3", "WS-DATA","    Substation/feeder/breaker hierarchy",      "", 10, "", "", "", "", ""),
    ("6.4.3", 3, "WorkPackage", "P3", "WS-BE",  "    Configuration management",                 "", 8, "", "", "", "", ""),
    ("6.4.4", 3, "WorkPackage", "P3", "WS-FE",  "    Reference data CRUD interfaces",           "", 6, "", "", "", "", ""),
    ("6.4.5", 3, "WorkPackage", "P3", "WS-QA",  "    DBM UAT",                                  "", 8, "", "", "", "", ""),

    ("6.5",   2, "Summary",     "P3", "WS-FE",  "  DSO — Dielectric System Operations",
     "Dielectric feeders; moderate uniqueness", 60, "6.4 partial", "R-001", "", "", ""),
    ("6.5.1", 3, "WorkPackage", "P3", "WS-OPS", "    DSO Epic catalog",                          "", 3, "", "", "", "", ""),
    ("6.5.2", 3, "WorkPackage", "P3", "WS-BE",  "    DSO workflow steps 1-4",                    "", 16, "", "R-001", "", "", ""),
    ("6.5.3", 3, "WorkPackage", "P3", "WS-BE",  "    DSO workflow steps 5-8",                    "", 14, "", "R-001", "", "", ""),
    ("6.5.4", 3, "WorkPackage", "P3", "WS-DATA","    Dielectric extensions to CIM",              "", 10, "", "R-006", "", "", ""),
    ("6.5.5", 3, "WorkPackage", "P3", "WS-FE",  "    DSO new-value Epics",                       "", 8, "", "", "", "", ""),
    ("6.5.6", 3, "WorkPackage", "P3", "WS-QA",  "    DSO UAT",                                   "", 9, "", "", "", "", ""),

    ("6.6",   2, "Summary",     "P3", "WS-FE",  "  SDS — Steam Systems",
     "Steam operations; highest uniqueness", 70, "6.5 partial", "R-001", "", "", ""),
    ("6.6.1", 3, "WorkPackage", "P3", "WS-OPS", "    SDS Epic catalog",                          "", 3, "", "", "", "", ""),
    ("6.6.2", 3, "WorkPackage", "P3", "WS-BE",  "    SDS workflow steps 1-4",                    "", 18, "", "R-001", "", "", ""),
    ("6.6.3", 3, "WorkPackage", "P3", "WS-BE",  "    SDS workflow steps 5-8",                    "", 16, "", "R-001", "", "", ""),
    ("6.6.4", 3, "WorkPackage", "P3", "WS-DATA","    Steam extensions to CIM",                   "", 14, "", "R-006", "", "", ""),
    ("6.6.5", 3, "WorkPackage", "P3", "WS-FE",  "    SDS new-value Epics",                       "", 9, "", "", "", "", ""),
    ("6.6.6", 3, "WorkPackage", "P3", "WS-QA",  "    SDS UAT",                                   "", 10, "", "", "", "", ""),

    ("6.7",   2, "Summary",     "P3", "WS-INT", "  TLS — Telephonic Line Systems",
     "EMS↔RTU connectivity; integration-heavy", 50, "6.6 partial", "R-002", "", "", ""),
    ("6.7.1", 3, "WorkPackage", "P3", "WS-OPS", "    TLS Epic catalog",                          "", 2, "", "", "", "", ""),
    ("6.7.2", 3, "WorkPackage", "P3", "WS-BE",  "    EMS↔RTU connectivity management",          "", 14, "", "R-002", "", "", ""),
    ("6.7.3", 3, "WorkPackage", "P3", "WS-INT", "    Carrier integration (Verizon/AT&T)",       "", 12, "", "R-002", "", "", ""),
    ("6.7.4", 3, "WorkPackage", "P3", "WS-BE",  "    Route + comm-path management",              "", 10, "", "", "", "", ""),
    ("6.7.5", 3, "WorkPackage", "P3", "WS-FE",  "    TLS new-value Epics",                       "", 5, "", "", "", "", ""),
    ("6.7.6", 3, "WorkPackage", "P3", "WS-QA",  "    TLS UAT",                                   "", 7, "", "", "", "", ""),

    ("6.8",   2, "Summary",     "P3", "WS-FE",  "  Monitor applications (~30 apps)",
     "Lightweight; built alongside parent app teams", 50, "6.3", "", "", "", ""),
    ("6.8.1", 3, "WorkPackage", "P3", "WS-FE",  "    Monitor app pattern + framework",           "", 8, "", "", "", "", ""),
    ("6.8.2", 3, "WorkPackage", "P3", "WS-FE",  "    FMS monitors (5 apps)",                     "", 7, "", "", "", "", ""),
    ("6.8.3", 3, "WorkPackage", "P3", "WS-FE",  "    TOMS monitors (5 apps)",                    "", 7, "", "", "", "", ""),
    ("6.8.4", 3, "WorkPackage", "P3", "WS-FE",  "    DSO monitors (5 apps)",                     "", 7, "", "", "", "", ""),
    ("6.8.5", 3, "WorkPackage", "P3", "WS-FE",  "    SDS monitors (5 apps)",                     "", 7, "", "", "", "", ""),
    ("6.8.6", 3, "WorkPackage", "P3", "WS-FE",  "    TLS monitors (5 apps)",                     "", 5, "", "", "", "", ""),
    ("6.8.7", 3, "WorkPackage", "P3", "WS-FE",  "    DBM monitors (5 apps)",                     "", 5, "", "", "", "", ""),
    ("6.8.8", 3, "WorkPackage", "P3", "WS-QA",  "    Monitor app UAT",                           "", 4, "", "", "", "", ""),

    ("6.9",   2, "Summary",     "P3", "WS-INT", "  Cross-app integrations (15+ external)",
     "Per-system adapters fully built", 60, "6.3", "R-002", "", "", ""),
    ("6.9.1", 3, "WorkPackage", "P3", "WS-INT", "    EMS/XA21 endpoint full integration",
     "Beyond MVP scope; emergency events, multi-app dispatch", 12, "", "R-002", "A-004", "", ""),
    ("6.9.2", 3, "WorkPackage", "P3", "WS-INT", "    Rapid Restore adapter — full coverage",     "", 8, "", "R-002", "", "", ""),
    ("6.9.3", 3, "WorkPackage", "P3", "WS-INT", "    GIS integration",                           "", 6, "", "", "", "", ""),
    ("6.9.4", 3, "WorkPackage", "P3", "WS-INT", "    FeederBoard integration",                   "", 5, "", "", "", "", ""),
    ("6.9.5", 3, "WorkPackage", "P3", "WS-INT", "    CPMS integration",                          "", 5, "", "", "", "", ""),
    ("6.9.6", 3, "WorkPackage", "P3", "WS-INT", "    Other integrations (10+)",                  "", 18, "", "", "", "", ""),
    ("6.9.7", 3, "WorkPackage", "P3", "WS-INT", "    Legacy SOAP wrappers",                      "", 6, "", "", "", "", ""),

    ("6.10",  2, "Summary",     "P3", "WS-ARC", "  Mid-point review (M-07)",
     "50% checkpoint + re-baseline", 5, "6.3, 6.4", "", "", "", ""),
    ("6.10.1",3, "WorkPackage", "P3", "WS-ARC", "    Re-baseline of remaining P3 against actual reuse rate", "", 2, "", "R-001", "", "", "Estimation gate"),
    ("6.10.2",3, "WorkPackage", "P3", "WS-OPS", "    Risk re-assessment",                        "", 2, "", "", "", "", ""),
    ("M-07",  3, "Milestone",   "P3", "WS-OPS", "    M-07 Incremental Build Mid-Point Review",
     "50% of remaining cores feature-complete; no Red risks unmitigated", 0, "6.10.1, 6.10.2", "", "", "", "Gate owner: Program Lead"),

    ("6.11",  2, "Summary",     "P3", "WS-ARC", "  Cross-app workflow integration",
     "Multi-app coordination patterns", 25, "6.3..6.7", "", "", "", ""),
    ("6.11.1",3, "WorkPackage", "P3", "WS-BE",  "    Cross-app event flow",                      "", 8, "", "", "", "", ""),
    ("6.11.2",3, "WorkPackage", "P3", "WS-SEC", "    Cross-app authorization",                   "", 6, "", "", "", "", ""),
    ("6.11.3",3, "WorkPackage", "P3", "WS-DATA","    Cross-app reporting",                       "", 11, "", "", "", "", ""),


    # ============================================================
    # 7  P3a — Full UAT (2-4 mo, 1,400 PD)
    # ============================================================
    ("7",     1, "Summary",     "P3a", "WS-QA", "P3a — Full UAT",
     "Cross-app workflows + perf + DR + regulator dry-run + pen-test",
     65, "6", "R-002, R-004", "", "", "Per 19-test-strategy.md §6.2"),

    ("7.1",   2, "Summary",     "P3a", "WS-QA",  "  Cross-app workflow UAT",
     "Multi-system scenarios", 18, "", "", "", "", ""),
    ("7.1.1", 3, "WorkPackage", "P3a", "WS-QA",  "    TOMS + FMS cascade scenarios",             "", 6, "", "", "", "", ""),
    ("7.1.2", 3, "WorkPackage", "P3a", "WS-QA",  "    DBM-driven cross-app reference data",      "", 4, "", "", "", "", ""),
    ("7.1.3", 3, "WorkPackage", "P3a", "WS-QA",  "    Multi-system regression",                  "", 8, "", "", "", "", ""),

    ("7.2",   2, "Summary",     "P3a", "WS-QA",  "  Performance testing",
     "Combined-load + burst + soak", 12, "", "", "", "", ""),
    ("7.2.1", 3, "WorkPackage", "P3a", "WS-QA",  "    Combined-load performance",                "", 5, "", "", "", "", ""),
    ("7.2.2", 3, "WorkPackage", "P3a", "WS-QA",  "    Burst (storm) load",                       "", 4, "", "", "", "", ""),
    ("7.2.3", 3, "WorkPackage", "P3a", "WS-QA",  "    Soak (24h) test",                          "", 3, "", "", "", "", ""),

    ("7.3",   2, "Summary",     "P3a", "WS-OPS", "  Disaster recovery / islanding",
     "OpNET standby drill", 10, "", "R-009", "A-007", "", ""),
    ("7.3.1", 3, "WorkPackage", "P3a", "WS-OPS", "    Islanding drill on OpNET",                 "", 4, "", "R-009", "", "", ""),
    ("7.3.2", 3, "WorkPackage", "P3a", "WS-OPS", "    Recovery drill",                           "", 3, "", "R-009", "", "", ""),
    ("7.3.3", 3, "WorkPackage", "P3a", "WS-DO",  "    Cross-zone failover",                      "", 3, "", "R-009", "", "", ""),

    ("7.4",   2, "Summary",     "P3a", "WS-SEC", "  Regulatory audit dry-run",
     "Compliance executes synthetic audit", 8, "", "R-004", "", "", ""),
    ("7.4.1", 3, "WorkPackage", "P3a", "WS-SEC", "    Compliance synthetic audit",               "", 3, "", "R-004", "", "", ""),
    ("7.4.2", 3, "WorkPackage", "P3a", "WS-SEC", "    Regulator query corpus run",               "", 3, "", "R-004", "", "", ""),
    ("7.4.3", 3, "WorkPackage", "P3a", "WS-SEC", "    Gap remediation",                          "", 2, "", "R-004", "", "", ""),

    ("7.5",   2, "Summary",     "P3a", "WS-SEC", "  Penetration testing",
     "External + internal red team + remediation", 12, "", "", "", "", ""),
    ("7.5.1", 3, "WorkPackage", "P3a", "WS-SEC", "    External pen-test (per app)",              "", 6, "", "", "", "", ""),
    ("7.5.2", 3, "WorkPackage", "P3a", "WS-SEC", "    Internal red-team",                        "", 3, "", "", "", "", ""),
    ("7.5.3", 3, "WorkPackage", "P3a", "WS-SEC", "    Findings remediation",                     "", 3, "", "", "", "", ""),

    ("7.6",   2, "Summary",     "P3a", "WS-QA",  "  Full UAT exit (M-08)",
     "All cross-app workflows tested; defect tail meets exit criteria", 5, "7.1..7.5", "", "", "", ""),
    ("M-08",  3, "Milestone",   "P3a", "WS-QA",  "    M-08 Full UAT Pass",
     "Cross-app workflows tested; defect tail meets exit criteria", 0, "7.6", "", "", "", "Gate owner: Operations Lead"),


    # ============================================================
    # 8  P4 — Cutover (4-8 mo, 2,080 PD) — 6 staggered events
    # ============================================================
    ("8",     1, "Summary",     "P4", "WS-OPS", "P4 — Cutover (6 staggered events under Option A)",
     "FMS → TOMS → DBM → DSO → SDS → TLS; per-app 4-week pattern",
     130, "M-08", "R-002, R-004, R-010", "A-006, A-007", "D-001", "Per 20-cutover-playbook-outline.md"),

    ("8.0",   2, "Summary",     "P4", "WS-OPS", "  Program-wide cutover infra",
     "Rollback plane + observability + runbooks shared across all 6 events", 15, "", "R-009", "A-007", "D-001", ""),
    ("8.0.1", 3, "WorkPackage", "P4", "WS-DO",  "    Rollback plane infra (OpNET legacy hot-standby)", "", 5, "", "R-009", "A-007", "", ""),
    ("8.0.2", 3, "WorkPackage", "P4", "WS-DO",  "    Cutover observability dashboards",         "", 4, "", "", "", "", ""),
    ("8.0.3", 3, "WorkPackage", "P4", "WS-OPS", "    War-room comms infrastructure",            "", 3, "", "", "", "", ""),
    ("8.0.4", 3, "WorkPackage", "P4", "WS-OPS", "    CAB / change-ticketing integration",       "", 3, "", "", "", "", ""),

    # 8.1: FMS Cutover (1st event)
    ("8.1",   2, "Summary",     "P4", "WS-OPS", "  FMS Cutover (1st event)",
     "First cutover; longest soak; rehearsals exercise harness most rigorously", 40, "8.0", "R-002, R-010", "", "D-001", ""),
    ("8.1.1", 3, "WorkPackage", "P4", "WS-OPS", "    FMS cutover runbook authored (50-80 pages)", "", 5, "", "", "", "", ""),
    ("8.1.2", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Dress Rehearsal #1 (T-4 weeks)",         "", 3, "", "R-010", "", "", ""),
    ("8.1.3", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Dry-run + go/no-go review (T-3)",        "", 1, "", "", "", "", ""),
    ("8.1.4", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Dress Rehearsal #2 (T-2 weeks)",         "", 3, "", "R-010", "", "", ""),
    ("8.1.5", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Final go/no-go + Dress Rehearsal #3 (T-1)", "", 3, "", "R-010", "", "", ""),
    ("8.1.6", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Cutover weekend (T-0)",                 "", 3, "", "R-002, R-004", "A-006", "", ""),
    ("8.1.7", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Stabilization week (T+1)",              "", 5, "", "", "", "", ""),
    ("8.1.8", 3, "WorkPackage", "P4", "WS-OPS", "    FMS Soak period (T+2 to T+4)",              "", 15, "", "", "A-006", "", ""),
    ("M-09",  3, "Milestone",   "P4", "WS-OPS", "    M-09 FMS Cutover Live",
     "Dress rehearsal #3 clean; rollback plan tested", 0, "8.1.5", "", "", "", "Gate owner: Operations Lead + CIO"),
    ("8.1.9", 3, "WorkPackage", "P4", "WS-OPS", "    FMS post-cutover review + lessons logged",  "", 2, "", "", "", "", ""),

    # 8.2: TOMS Cutover
    ("8.2",   2, "Summary",     "P4", "WS-OPS", "  TOMS Cutover (2nd event)",
     "Inherits FMS lessons", 25, "8.1.8", "R-002", "", "", ""),
    ("8.2.1", 3, "WorkPackage", "P4", "WS-OPS", "    TOMS cutover runbook authored",             "", 3, "", "", "", "", ""),
    ("8.2.2", 3, "WorkPackage", "P4", "WS-OPS", "    TOMS DR1 / DR2 / DR3",                      "", 7, "", "R-010", "", "", ""),
    ("8.2.3", 3, "WorkPackage", "P4", "WS-OPS", "    TOMS Cutover weekend",                      "", 3, "", "", "A-006", "", ""),
    ("8.2.4", 3, "WorkPackage", "P4", "WS-OPS", "    TOMS Stabilization + Soak",                 "", 10, "", "", "", "", ""),
    ("8.2.5", 3, "WorkPackage", "P4", "WS-OPS", "    TOMS post-cutover review",                  "", 2, "", "", "", "", ""),

    # 8.3: DBM Cutover
    ("8.3",   2, "Summary",     "P4", "WS-OPS", "  DBM Cutover (3rd event)",
     "Foundational data; sequenced before remaining apps depend on shared hierarchy", 22, "8.2.4", "", "", "", ""),
    ("8.3.1", 3, "WorkPackage", "P4", "WS-OPS", "    DBM cutover runbook authored",              "", 3, "", "", "", "", ""),
    ("8.3.2", 3, "WorkPackage", "P4", "WS-OPS", "    DBM DR1 / DR2 / DR3",                       "", 6, "", "R-010", "", "", ""),
    ("8.3.3", 3, "WorkPackage", "P4", "WS-OPS", "    DBM Cutover weekend",                       "", 2, "", "", "A-006", "", ""),
    ("8.3.4", 3, "WorkPackage", "P4", "WS-OPS", "    DBM Stabilization + Soak",                  "", 9, "", "", "", "", ""),
    ("8.3.5", 3, "WorkPackage", "P4", "WS-OPS", "    DBM post-cutover review",                   "", 2, "", "", "", "", ""),

    # 8.4: DSO Cutover
    ("8.4",   2, "Summary",     "P4", "WS-OPS", "  DSO Cutover (4th event)",
     "Dielectric extensions add edge cases", 25, "8.3.4", "R-006", "", "", ""),
    ("8.4.1", 3, "WorkPackage", "P4", "WS-OPS", "    DSO cutover runbook authored",              "", 3, "", "", "", "", ""),
    ("8.4.2", 3, "WorkPackage", "P4", "WS-OPS", "    DSO DR1 / DR2 / DR3",                       "", 7, "", "R-010", "", "", ""),
    ("8.4.3", 3, "WorkPackage", "P4", "WS-OPS", "    DSO Cutover weekend",                       "", 3, "", "", "A-006", "", ""),
    ("8.4.4", 3, "WorkPackage", "P4", "WS-OPS", "    DSO Stabilization + Soak",                  "", 10, "", "", "", "", ""),
    ("8.4.5", 3, "WorkPackage", "P4", "WS-OPS", "    DSO post-cutover review",                   "", 2, "", "", "", "", ""),

    # 8.5: SDS Cutover
    ("8.5",   2, "Summary",     "P4", "WS-OPS", "  SDS Cutover (5th event)",
     "Steam-specific; longest cutover window expected", 28, "8.4.4", "R-006", "", "", ""),
    ("8.5.1", 3, "WorkPackage", "P4", "WS-OPS", "    SDS cutover runbook authored",              "", 4, "", "", "", "", ""),
    ("8.5.2", 3, "WorkPackage", "P4", "WS-OPS", "    SDS DR1 / DR2 / DR3",                       "", 8, "", "R-010", "", "", ""),
    ("8.5.3", 3, "WorkPackage", "P4", "WS-OPS", "    SDS Cutover weekend (extended window)",     "", 4, "", "", "A-006", "", ""),
    ("8.5.4", 3, "WorkPackage", "P4", "WS-OPS", "    SDS Stabilization + Soak",                  "", 10, "", "", "", "", ""),
    ("8.5.5", 3, "WorkPackage", "P4", "WS-OPS", "    SDS post-cutover review",                   "", 2, "", "", "", "", ""),

    # 8.6: TLS Cutover
    ("8.6",   2, "Summary",     "P4", "WS-OPS", "  TLS Cutover (6th event)",
     "Many integrations; coordinate adapter cutover same weekend", 22, "8.5.4", "R-002", "", "", ""),
    ("8.6.1", 3, "WorkPackage", "P4", "WS-OPS", "    TLS cutover runbook authored",              "", 3, "", "", "", "", ""),
    ("8.6.2", 3, "WorkPackage", "P4", "WS-OPS", "    TLS DR1 / DR2 / DR3",                       "", 6, "", "R-010", "", "", ""),
    ("8.6.3", 3, "WorkPackage", "P4", "WS-OPS", "    TLS Cutover weekend",                       "", 2, "", "", "A-006", "", ""),
    ("8.6.4", 3, "WorkPackage", "P4", "WS-OPS", "    TLS Stabilization + Soak",                  "", 9, "", "", "", "", ""),
    ("8.6.5", 3, "WorkPackage", "P4", "WS-OPS", "    TLS post-cutover review",                   "", 2, "", "", "", "", ""),
    ("M-10",  3, "Milestone",   "P4", "WS-OPS", "    M-10 All Cores Cut Over",
     "All 6 apps + monitors live; legacy retired", 0, "8.6.4", "", "", "", "Gate owner: Operations Lead + CIO"),


    # ============================================================
    # 9  P5 — Hypercare (3-6 mo, overlapping, 1,200 PD)
    # ============================================================
    ("9",     1, "Summary",     "P5", "WS-OPS", "P5 — Hypercare (per-app + program-wide)",
     "Heightened-support window; defect lifecycle; legacy decommission",
     90, "8.1.7", "", "A-006", "", "Per 20-cutover-playbook-outline.md §8-10"),

    ("9.1",   2, "Summary",     "P5", "WS-OPS", "  Per-app hypercare (overlapping with later cutovers)",
     "Each app's hypercare starts at its cutover", 40, "8.1.7", "", "", "", ""),
    ("9.1.1", 3, "WorkPackage", "P5", "WS-OPS", "    FMS hypercare (4-8 weeks)",                 "", 8, "", "", "", "", ""),
    ("9.1.2", 3, "WorkPackage", "P5", "WS-OPS", "    TOMS hypercare",                            "", 7, "", "", "", "", ""),
    ("9.1.3", 3, "WorkPackage", "P5", "WS-OPS", "    DBM hypercare",                             "", 6, "", "", "", "", ""),
    ("9.1.4", 3, "WorkPackage", "P5", "WS-OPS", "    DSO hypercare",                             "", 7, "", "", "", "", ""),
    ("9.1.5", 3, "WorkPackage", "P5", "WS-OPS", "    SDS hypercare",                             "", 8, "", "", "", "", ""),
    ("9.1.6", 3, "WorkPackage", "P5", "WS-OPS", "    TLS hypercare",                             "", 4, "", "", "", "", ""),

    ("9.2",   2, "Summary",     "P5", "WS-OPS", "  Program-wide hypercare",
     "Starts at last cutover; runs 3 months", 45, "M-10", "", "", "", ""),
    ("9.2.1", 3, "WorkPackage", "P5", "WS-OPS", "    Heightened on-call rotation",               "", 15, "", "", "", "", ""),
    ("9.2.2", 3, "WorkPackage", "P5", "WS-QA",  "    Defect lifecycle management (program-wide)", "", 15, "", "", "", "", ""),
    ("9.2.3", 3, "WorkPackage", "P5", "WS-OPS", "    Operations service-ownership transfer",     "", 10, "", "", "", "", ""),
    ("9.2.4", 3, "WorkPackage", "P5", "WS-SEC", "    Compliance audit packet preparation",       "", 5, "", "R-004", "", "", ""),

    ("9.3",   2, "Summary",     "P5", "WS-OPS", "  Hypercare exit (per-app + program-wide)",
     "Defect rate ≤ steady-state for 30 days", 5, "9.1, 9.2", "", "", "", ""),
    ("9.3.1", 3, "WorkPackage", "P5", "WS-OPS", "    Per-app hypercare exit memos",              "", 2, "", "", "", "", ""),
    ("9.3.2", 3, "WorkPackage", "P5", "WS-OPS", "    Program-wide hypercare exit memo",          "", 2, "", "", "", "", ""),
    ("9.3.3", 3, "WorkPackage", "P5", "WS-OPS", "    Operations formally accepts service ownership", "", 1, "", "", "", "", ""),

    ("9.4",   2, "Summary",     "P5", "WS-DATA","  Legacy decommissioning",
     "Per-app legacy stop; read-only mode for 7-yr retention", 8, "9.3", "", "", "", ""),
    ("9.4.1", 3, "WorkPackage", "P5", "WS-DATA","    Per-app legacy app pool stop (×6)",          "", 3, "", "", "", "", ""),
    ("9.4.2", 3, "WorkPackage", "P5", "WS-DATA","    Per-app legacy DB read-only mode (×6)",      "", 2, "", "R-004", "A-005", "", ""),
    ("9.4.3", 3, "WorkPackage", "P5", "WS-SEC", "    Decommission record filing (audit)",        "", 1, "", "R-004", "", "", ""),
    ("9.4.4", 3, "WorkPackage", "P5", "WS-OPS", "    Legacy infra archive lifecycle documented",  "", 2, "", "", "A-005", "", ""),

    ("9.5",   2, "Summary",     "P5", "WS-OPS", "  M-11 gate (Hypercare Exit)",
     "Defect rate ≤ steady-state threshold for 30 consecutive days", 1, "9.3, 9.4", "", "", "", ""),
    ("M-11",  3, "Milestone",   "P5", "WS-OPS", "    M-11 Hypercare Exit",
     "All P1 severity defects closed; Operations team formally accepts service ownership", 0, "9.5",
     "", "", "", "Gate owner: Service Owner — PROGRAM EXIT"),
]
