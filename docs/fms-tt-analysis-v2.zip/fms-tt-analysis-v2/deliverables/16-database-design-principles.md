# Database Design Principles

**Artifact ID:** B5.9
**Status:** Draft for Architecture Council + Data Architecture review
**Audience:** Data Architect, DB Engineers, Backend Lead, Security Lead, Compliance Officer
**Pairs with:** [17-data-migration-strategy.md](17-data-migration-strategy.md), [03-technical-architecture-outline.md](03-technical-architecture-outline.md)

This document specifies the design rules every service team follows when modeling, migrating, or evolving database schemas in the modernized stack. It is opinionated and tuned to the program's safety-critical, regulator-watched, OT-adjacent context. Generic SQL Server best-practices are referenced but not duplicated.

---

## 1. Purpose & scope

In scope:
- Schema strategy across the 6 cores + shared infrastructure
- Audit and temporal design (regulator-load-bearing)
- Partitioning, indexing, retention, performance targets
- HA/DR behavior between CorpNET primary and OpNET standby
- Migration / change management discipline
- Performance and observability targets

Out of scope:
- Specific table designs per service (P1 detailed design output)
- DB-level secrets management (covered in DevOps blueprint)
- Specific index lists (workload-driven; emerges in P2/P3)
- Application-level data contracts (covered in service architecture)

---

## 2. Engine choice — locked

| Property | Value |
|---|---|
| Engine | SQL Server 2025 Enterprise Edition |
| Hosting | On-prem (CorpNET primary; OpNET standby) |
| HA/DR | AlwaysOn Availability Group, synchronous commit |
| Editions used | Enterprise (required for AlwaysOn AG with synchronous commit + temporal tables + partitioning) |

Locked by sponsor (D-003 + stack decision). Not relitigated here.

---

## 3. Architectural framing

### 3.1 Schema-per-service in a single instance

Every domain service has its own schema. **Cross-schema reads are forbidden at the SQL level — services interact only via service APIs and async messages.**

| Domain service | Schema name |
|---|---|
| FMS | `fms` |
| TOMS | `toms` |
| DSO | `dso` |
| TLS | `tls` |
| SDS | `sds` |
| DBM | `dbm` |
| Messaging Module | `msg` |
| Task Manager | `task` |
| EMS Polling Endpoint | `ems` |
| Audit (program-wide aggregator) | `audit` |
| Identity (cached projection from IdP) | `identity` |
| Reporting (read-only views) | `report` |

### 3.2 Why not separate databases per service

| Option | Evaluated | Decision |
|---|---|---|
| One DB per service | Considered | Rejected: licensing inefficiency on Enterprise; 12+ instances to operate; backup complexity; cross-service reporting becomes harder, not easier |
| One DB, schema-per-service (chosen) | Selected | Single instance; clear logical isolation; lower ops cost; cross-service reporting via the `report` schema is straightforward |
| Single shared schema | Considered | Rejected: defeats service decomposition; cross-team coupling at DB level |

### 3.3 Schema isolation is enforced by permissions

- Each service's runtime SQL login has access only to its own schema (DDL + DML)
- No service login has cross-schema access
- The `report` schema is read-only and contains views over base tables; report views are owned by Data Architecture
- Cross-service joins at the SQL level are disallowed by permission grants — not by code-review goodwill

---

## 4. Naming conventions

Conventions are pedantic deliberately — operability under stress depends on predictability.

| Object | Convention | Example |
|---|---|---|
| Schema | lowercase, short | `fms` |
| Table | PascalCase, singular | `SwitchingCard` |
| Audit table | suffix `_Audit` (operator-action style) | `SwitchingCard_Audit` |
| Temporal history table | suffix `_History` | `SwitchingCard_History` |
| Column | PascalCase | `CardStatus`, `CreatedAtUtc` |
| Primary key | `Id` (always; even on weak entities) | |
| Foreign key | `<Table>Id` | `SwitchingCardId` |
| Index | `IX_<Table>_<Cols>` | `IX_SwitchingCard_DistrictId_CreatedAtUtc` |
| Unique index | `UX_<Table>_<Cols>` | `UX_SwitchingCard_ExternalRef` |
| Constraint (check) | `CK_<Table>_<Rule>` | `CK_SwitchingCard_StatusValid` |
| Foreign key constraint | `FK_<Table>_<Ref>` | `FK_SwitchingCardStep_SwitchingCard` |
| View | `vw_<Purpose>` | `vw_OperatorActiveCards` |
| Stored procedure | `sp_<Verb><Object>` (avoid `sp_` prefix conflict with system) | use `usp_` prefix: `usp_GetCardWithSteps` |
| Function | `fn_<Purpose>` | `fn_FormatFeederPath` |
| Sequence | `seq_<Purpose>` | `seq_CardNumber` |

Names that include time always specify time zone explicitly. **All timestamps are UTC at the DB layer.** Display conversion happens at the BFF or UI.

---

## 5. Normalization stance

### 5.1 3NF as default

All transactional tables are at least 3rd Normal Form by default. Denormalization happens only with named justification — a comment in the migration that names the trade-off.

### 5.2 When denormalization is acceptable

| Pattern | Example | Acceptable when |
|---|---|---|
| Read-model projection | Card-with-current-step pre-joined for operator console | Read frequency dominates write frequency by ≥10× |
| Aggregate cache | Per-district daily card counts | Source data is append-only and aggregate is bounded |
| Computed column | `vw_OperatorActiveCards.DurationMinutes` | Computation is deterministic and pure |
| Materialized view | Quarterly compliance report base | Refresh cadence acceptable; refresh is monitored |

**Forbidden denormalization patterns:**

- Writing the same data into two tables to "save a join"
- Storing comma-separated lists in a single column
- Embedding JSON for relational data (JSON allowed for genuinely schemaless payloads — e.g., integration audit payload archive)

### 5.3 Hierarchical / graph data

Power system hierarchies (substation → feeder → breaker → switch) are modeled with either:

- Adjacency list (parent_id) for shallow hierarchies up to ~6 levels deep
- Closure table for query-heavy hierarchical workloads (DBM uses this)
- Neither EAV nor "model in JSON" patterns

CIM-aligned modeling principles take precedence over generic hierarchy modeling — CIM hierarchy semantics are followed where they apply.

---

## 6. Data types — standardized

| Data | Type | Notes |
|---|---|---|
| Primary keys | `BIGINT` for high-volume tables; `INT` for small reference tables | No `NEWID()` / GUIDs as PKs (clustering cost) |
| External references / IDs | `UNIQUEIDENTIFIER` if from external system; `NVARCHAR(64)` if tokenized | |
| Timestamps | `DATETIME2(3)` (millisecond precision) | UTC always |
| Date-only | `DATE` | |
| Money | `DECIMAL(19,4)` | |
| Operational quantities (kV, A, etc.) | `DECIMAL(p,s)` with explicit precision/scale per CIM spec | |
| Booleans | `BIT` | |
| Short text | `NVARCHAR(N)` with explicit cap (50/100/255) | Never `VARCHAR` — Unicode default |
| Long text / notes | `NVARCHAR(MAX)` | |
| Binary blobs (rare) | `VARBINARY(MAX)` with FILESTREAM only when justified | Documents / images / large payloads |
| JSON payloads (sparingly) | `NVARCHAR(MAX)` with `CHECK (ISJSON())` | Integration audit payloads |
| Hashes (audit chain) | `VARBINARY(32)` (SHA-256) | |

**Forbidden:** `TEXT`, `NTEXT`, `IMAGE`, `MONEY`, `SMALLMONEY`, `DATETIME`, `FLOAT`/`REAL` for monetary or audit-relevant numbers.

---

## 7. NULL handling

- **NULL means "not known."** It does not mean zero, false, or empty string.
- Columns where "absence is meaningful" use `NOT NULL` with an explicit sentinel value (e.g., `'Unknown'`) only when the sentinel is part of the domain model.
- **Boolean columns are NOT NULL with explicit default.** Three-valued logic is more often a bug than a feature.
- Foreign keys are `NOT NULL` unless the relationship is genuinely optional (and that is named in the migration).

---

## 8. Constraints, foreign keys, triggers

### 8.1 Foreign keys: required

All references to other tables use foreign-key constraints. Cascading deletes are **forbidden** by default — use soft-delete + retention partition switch-out.

### 8.2 Check constraints: required for invariants

Every table defines check constraints for invariants that the DB can enforce. Examples:

- `CK_SwitchingCard_StatusValid` — `CardStatus IN ('PendingReview','Active','Closed','Cancelled')`
- `CK_SwitchingCard_DateOrder` — `EnergizedUtc IS NULL OR EnergizedUtc <= ClosedUtc`

Not "all invariants" — those that the DB can express cheaply. Complex invariants stay in the domain layer.

### 8.3 Triggers: forbidden by default

Triggers are forbidden for business logic. Two narrow exceptions:

| Allowed trigger | Purpose |
|---|---|
| Audit row emission (system-level) | Captures change to operator-action log; only for tables that require it; auto-generated by migration |
| Hash-chain link computation | Computes `RowHash` based on previous row's hash |

Both are infrastructural, not business logic. Application-level triggers that "fix up" data are forbidden — they hide bugs and break observability.

---

## 9. Audit & temporal strategy

This is the regulator-load-bearing section. See also B3 §7 (audit AC patterns) and B2.7 §4.3.

### 9.1 Two distinct audit surfaces — do not conflate

| Surface | Captures | Storage | Retention |
|---|---|---|---|
| **Entity history** | Every change to a domain entity (data state) | SQL Server **system-versioned temporal tables** (`SYSTEM_TIME`) | 7 years |
| **Operator action log** | Every operator action (behavior) | Append-only audit table, hash-chained | 7 years |
| **Authorization decision log** | Every allow/deny | Append-only auth-decision table | 7 years |
| **Integration call log** | Every cross-system call | Append-only integration log + payload archive | 7 years |

### 9.2 System-versioned temporal tables for entity history

All domain entities (cards, tags, authorizations, steps, etc.) are system-versioned with `PERIOD FOR SYSTEM_TIME (ValidFromUtc, ValidToUtc)`.

Rules:
- History tables share the same schema as their base table
- History tables use **time-based partitioning** (one partition per month)
- Retention is enforced via partition switch-out + archive (see §10)
- Querying historical state uses standard `FOR SYSTEM_TIME AS OF` syntax

### 9.3 Operator action log

Schema-per-service `_Audit` table holds operator actions. Required columns:

| Column | Notes |
|---|---|
| `Id` BIGINT IDENTITY | PK |
| `ActionId` UNIQUEIDENTIFIER | Idempotency key per action |
| `OperatorId` | From identity layer |
| `ActionType` NVARCHAR(64) | Domain action name |
| `TargetEntityType` | e.g., `SwitchingCard` |
| `TargetEntityId` | BIGINT |
| `BeforeStateHash` VARBINARY(32) | SHA-256 of pre-state |
| `AfterStateHash` VARBINARY(32) | SHA-256 of post-state |
| `Success` BIT | Failed actions are logged too |
| `Reason` NVARCHAR(500) NULL | Operator-provided when applicable |
| `CorrelationId` UNIQUEIDENTIFIER | Trace propagation |
| `CreatedAtUtc` DATETIME2(3) | UTC |
| `PreviousRowHash` VARBINARY(32) | Hash chain link |
| `RowHash` VARBINARY(32) | SHA-256 over (this row's content + PreviousRowHash) |

Append-only. No UPDATEs, no DELETEs (enforced by permissions). Hash chain is verified daily by a tamper-detection job (see NFR-AUD-001 in B3 [12-nfr-template.md](12-nfr-template.md)).

### 9.4 Audit emission is transactional with the action

Audit row write happens in **the same database transaction** as the entity change. If the audit write fails, the action fails. Fail-closed. No outbox-pattern for audit (correctness > throughput here).

This is a deliberate trade-off against latency. Justified by R-001 + the regulator-load-bearing nature.

### 9.5 No backdoor data fixes

Direct UPDATEs to the audit tables, the temporal history tables, or the hash chain — even by DBAs — are forbidden by permission. If a genuine correction is needed (e.g., GDPR right-to-erasure on an operator name field), it goes through a documented `usp_AuditCorrection` procedure that:

1. Creates a new audit row marking the correction
2. Writes the correction record with full justification
3. Re-computes the hash chain forward from the correction point
4. Notifies Compliance

Unaudited backdoor edits are a regulatory event in themselves.

---

## 10. Partitioning & retention

### 10.1 Partitioning strategy

| Table type | Partition by | Partition cadence | Rationale |
|---|---|---|---|
| Operator action log | `CreatedAtUtc` | Monthly | High volume; 7-year retention; reads dominated by recent + audit-window |
| Entity temporal history | `ValidFromUtc` | Monthly | Same |
| Auth-decision log | `CreatedAtUtc` | Monthly | Same |
| Integration call log | `CreatedAtUtc` | Monthly | Same |
| Hot domain tables (e.g., `SwitchingCard`) | Not partitioned in MVP; partition by `DistrictId` if hotspots emerge | — | Cardinality of districts is bounded; observed perf may not require partitioning |

### 10.2 Retention enforcement

7-year retention is enforced via:

1. Monthly partition switch-out at age 84 months
2. Switched-out partitions written to compressed archive storage (separate from operational DB)
3. Archive storage is read-only, encrypted at rest, accessible to Compliance via a defined process
4. Switch-out is a metadata operation (fast, no row-level deletes)

**No row-level DELETE operations on retention boundaries.** Hash chains and temporal tables don't tolerate row-level deletion semantically.

### 10.3 Anti-patterns

- Bulk DELETE WHERE on aging data — forbidden (chain breaks; query-time-window inconsistent)
- "Soft delete" via `IsDeleted = 1` column on tables that have temporal history — redundant; use temporal
- Partition by `Id` (round-robin) — defeats the purpose; partition by time

---

## 11. Indexing strategy

### 11.1 Index hygiene

- Every table has a clustered primary key (covered by `Id`)
- Every foreign key column is non-clustered indexed (one of: dedicated NCI or covered by composite)
- Indexes are reviewed quarterly against actual workload (Query Store)
- Index-add and index-remove are tracked in migrations; ad-hoc index creation in production is not allowed

### 11.2 The "every query has a supporting index" principle

For every operator-facing query, there is a supporting index. Operator-facing queries are explicitly identified during P1 detailed design and included in the index plan.

### 11.3 Filtered indexes

Filtered indexes are encouraged for:
- Hot subsets (e.g., `WHERE CardStatus IN ('Active','PendingReview')`)
- Active vs. closed/archived state distinctions

### 11.4 Indexes that we generally don't add

- Wide covering indexes that duplicate large fractions of the row (storage cost > read benefit)
- Indexes on low-cardinality columns alone (e.g., `BIT` flags)
- Indexes on columns we rarely filter on (intuition tests should fail; rely on Query Store)

---

## 12. Performance targets

### 12.1 Latency SLOs at the DB tier

| Workload | p50 | p95 | p99 |
|---|---|---|---|
| Operator-facing point read (single card) | 5 ms | 20 ms | 50 ms |
| Operator-facing list read (district active cards, ≤200 rows) | 50 ms | 200 ms | 500 ms |
| Operator-facing write (state transition + audit) | 30 ms | 100 ms | 250 ms |
| Reporting query (read replica) | 1 s | 5 s | 30 s |
| Audit reconstruction (regulator query) | 5 s | 30 s | 2 min |

These are DB-tier SLOs only. End-to-end SLOs (BFF → UI) are wider — see service-level NFRs.

### 12.2 Throughput targets

- Sustained writes: 200 ops/sec to audit log per service (typical operator load + monitoring) with headroom for 5× burst
- Sustained reads: cache-fronted; raw DB read peak ~1,000 q/s across services

### 12.3 What we will not chase

- Sub-millisecond latency at the DB tier — application-level cache (Redis / in-process) is a cheaper path
- Lock-free concurrent updates beyond what `SNAPSHOT ISOLATION` gives — application-level retry with idempotency keys is preferred

---

## 13. Concurrency control

| Setting | Value |
|---|---|
| Default isolation level | `READ COMMITTED SNAPSHOT` (RCSI) on all DBs |
| Snapshot isolation | Available; used for reporting reads |
| Serializable | Used only for explicit financial/audit transactions where required |
| Optimistic concurrency in app code | Use `RowVersion`/`Timestamp` columns on entities operators edit concurrently |
| Pessimistic locking | Avoided; never `SELECT ... WITH (UPDLOCK)` in default code paths |

`READ COMMITTED SNAPSHOT` on by default. Tested under load before locking in.

---

## 14. Security

### 14.1 Connections

- All connections are TLS 1.3, mTLS where service-to-service
- Service accounts are app-specific managed service accounts (gMSA on Windows / on-prem AD)
- No shared SQL logins; no SA usage in application code
- DBA breakglass access via PAM with full session recording

### 14.2 Row-level security (RLS)

- RLS enabled on the `audit`, `report`, and identity-projection tables
- District-scoped operator queries are filtered at the DB level for defense-in-depth (BFF authorization is the primary control)

### 14.3 Column-level encryption

Encrypted at the DB layer (`Always Encrypted` with HSM-backed key) for:
- PII (operator personal data; field crew personal data)
- Vendor credentials (where stored, e.g., EMS cert provisioning data)

**Not encrypted at column level:**
- Operational data (cards, steps, authorizations) — protected by access control
- Audit data — encryption would break tamper-detection (encrypted text isn't hashable in the chain)

### 14.4 Backup encryption

All backups encrypted at rest (AES-256). Backup encryption keys live in HSM. Restore path tested quarterly.

---

## 15. HA/DR — Always-On Availability Group

### 15.1 Topology

- **Primary replica:** CorpNET, synchronous commit, automatic failover within CorpNET
- **Secondary replica (intra-zone):** CorpNET, synchronous commit (read-routing for reporting)
- **Secondary replica (cross-zone):** OpNET, synchronous commit, manual failover (cyber event / islanding)
- Listener: split-listener pattern; CorpNET applications use intra-zone listener; failover to OpNET is operator-initiated

### 15.2 Failover semantics

| Trigger | Behavior |
|---|---|
| CorpNET primary unhealthy (intra-zone) | Automatic failover to CorpNET secondary; <10s downtime |
| CorpNET zone unreachable (cyber event / islanding) | Manual promotion of OpNET replica via runbook; coordinated with operator handoff (see B2 [04-network-boundary-design.md](04-network-boundary-design.md) §6.2) |
| Both CorpNET replicas down | Automatic failover to OpNET (degraded mode; documented as exception path) |

### 15.3 RPO / RTO targets

| Target | Value | Rationale |
|---|---|---|
| RPO (intra-zone) | 0 | Synchronous commit |
| RTO (intra-zone) | <30s | Automatic failover |
| RPO (cross-zone, cyber event) | <5s | Synchronous commit cross-zone (with link healthy) |
| RTO (cross-zone, cyber event) | 15 min | Manual failover + operator coordination |

These are pending P1 sign-off (NQ-02 in [04-network-boundary-design.md](04-network-boundary-design.md)).

### 15.4 Backup strategy

- Full backup: weekly
- Differential: daily
- Transaction log: every 15 min, replicated to off-site
- Retention: 90 days online, 7 years archive
- Restore tested: monthly drill; full system-restore drill quarterly

---

## 16. Migration & change management

### 16.1 All schema changes go through migrations

- Migrations are version-controlled in the service repo
- Migrations are applied via the CI/CD pipeline (DACPAC for SQL Server)
- No manual schema change in any environment beyond Dev — period
- Pre-prod and prod migrations are identical artifacts

### 16.2 Forward-only migrations

- Migrations are forward-only by default
- Rollback strategy: deploy a new forward migration that compensates
- "Down" migrations exist only in Dev

### 16.3 Breaking changes are coordinated

- Breaking schema changes go through a 2-step pattern: add new (non-breaking) → migrate code → remove old (separate release)
- Cross-service breaking changes require a contract version bump
- DBA / Data Architecture review required for any migration that:
  - Adds a column to a table > 10M rows
  - Changes an index on a hot table
  - Adds a foreign key
  - Changes a partitioning scheme
  - Touches an audit / temporal table

### 16.4 DBA breakglass for production data correction

- Forbidden by default
- Documented exception process for genuine emergencies
- Every breakglass action logged via PAM session recording
- Compliance reviewed within 24 hours of any breakglass

---

## 17. Observability of the DB tier

### 17.1 Telemetry collected

| Source | Destination |
|---|---|
| Query Store | Aggregated to observability stack (Grafana / equivalent) |
| Wait stats | Streaming to observability stack |
| Slow query log | Auto-paged at threshold |
| Lock / deadlock events | Auto-paged on any deadlock |
| AG health | Health probe per replica; latency between replicas |
| Backup success / failure | Auto-paged on failure |

### 17.2 Dashboards

Per-service DB dashboards include:
- p50/p95/p99 query latency by operation
- Top 10 slowest queries (rolling 24h)
- Connection pool utilization
- Audit log emission rate vs. action emission rate (must equal — divergence = bug)
- Hash chain validation status (last 24h)

---

## 18. Testing the DB layer

| Test type | Where |
|---|---|
| Unit tests against domain logic | Mocked DB / in-memory provider; not in this strategy |
| Integration tests | Real SQL Server in CI; per-service test DB |
| Migration tests | Migration applied to a representative dataset; reconciliation harness validates |
| Performance tests | Per-service against production-shape data in Pre-Prod |
| Audit/temporal tests | Verify temporal history exists for every state-changing test |
| Hash-chain tamper tests | Synthetic tampering detected within SLA |
| Reconciliation tests | Source vs. target row-by-row (during migration) |

Detailed in [18-test-strategy.md](18-test-strategy.md).

---

## 19. Open decisions for P1 detailed design

| ID | Decision | Driver | Blocks |
|---|---|---|---|
| DB-01 | Confirm RPO/RTO targets (cross-zone) | Operations + Compliance | AG configuration |
| DB-02 | Confirm Always Encrypted scope | Security Lead | PII column inventory |
| DB-03 | Confirm read-replica routing for reporting | Reporting tier design | App connection strings |
| DB-04 | Confirm partition switch-out target storage | Compliance + Storage team | Retention automation |
| DB-05 | Confirm backup-restore drill cadence | Operations | Runbook |
| DB-06 | Confirm closure-table vs. adjacency-list for DBM hierarchy | Data Architect + DBM team | DBM schema |
| DB-07 | Confirm CIM extensions modeled in DB vs. attribute soup | Data Architect | UDB→CIM POC (P1b) outcome |
| DB-08 | Confirm acceptable size of NVARCHAR(MAX) blobs in audit payload archive | Storage team | Integration audit storage |

---

## 20. What this document does not specify

- Per-service entity models (P1 detailed design)
- Specific index lists (workload-driven; emerges P2/P3)
- DBA runbooks (B5 cutover playbook outline + service-level runbooks)
- Specific monitoring dashboard definitions (B5 DevOps blueprint)
- Reporting tier specific schema (P1 detailed design)
- Read-model / CQRS-side projections (per service, in P1 detailed design)
