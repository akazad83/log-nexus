# Estimation Worksheet

**Artifact ID:** B4.6
**Status:** Draft for Engineering Lead + Architecture Council review
**Audience:** Sponsor, Program Lead, Engineering Leads, PMO
**Pairs with:** [13-resource-plan.md](13-resource-plan.md), [14-resource-plan-brutal-honesty-memo.md](14-resource-plan-brutal-honesty-memo.md)

The companion `.xlsx` (`15-estimation-worksheet.xlsx`) holds the live spreadsheet with formulas, configurable rates, and per-Epic three-point estimates. This `.md` documents the methodology, the indicative Epic catalog, and the assumptions baked into every cell.

**This is a planning estimate, not a commitment.** Variance bands are real. Re-baseline at every phase gate.

---

## 1. Methodology

### 1.1 Estimation unit

Effort is estimated in **person-days** at the Epic level. Per-Epic effort is the sum of:

- Engineering work (backend + frontend + DB + integration)
- QA work (test authoring + execution)
- BA / refinement work
- Operator co-design (for new-value Epics)
- Audit + telemetry instrumentation
- Code review + integration testing overhead

### 1.2 Three-point estimates

Each Epic carries Best / Likely / Worst person-day estimates. Methodology:

| Estimate | Definition |
|---|---|
| **Best** | Everything goes right. Pattern reuse is high. SMEs are responsive. No hidden rules surface. |
| **Likely** | Normal program friction. Some hidden rules. Standard SME availability. ~30% pattern reuse for non-FMS cores. |
| **Worst** | Hidden 4GL rules in this Epic. Pattern reuse low. SME availability degrades. Vendor coordination delays. |

**These are not ±20% bands around a midpoint.** Worst is what happens when 2–3 of the failure modes from `14-resource-plan-brutal-honesty-memo.md` §1 materialize. The spread between best and worst is real and reflects the program's irreducible uncertainty.

### 1.3 Confidence rating

Each Epic carries a confidence rating:

| Rating | Meaning |
|---|---|
| **High** | Bounded scope; comparable work done before; known patterns; reliable SME |
| **Medium** | Bounded scope but novel pattern, OR known pattern but uncertain SME |
| **Low** | Novel scope; uncertain hidden-rule density; SME unavailable; integration unverified |

Confidence rating drives the spread between Best and Worst. Low-confidence Epics have wider spreads. This is honest — narrowing a low-confidence range is mathematics, not estimation.

### 1.4 Story-point translation

Internal cross-check: every Epic's likely-case person-day estimate is reverse-checked against an estimated story-point total at ~1 point per 1.0–1.5 person-days at sustainable team velocity. Discrepancies > 25% trigger re-estimation.

### 1.5 Effective FTE adjustment

Person-day estimates assume **fully-productive engineers**. The companion xlsx's "Effective FTE" sheet applies onboarding factors per phase:

| Phase | Effective FTE multiplier (because of ramp-up) |
|---|---|
| P0a | 1.0 (small audit team, all senior) |
| P1 | 0.95 (mostly leads, some onboarding) |
| P1a | 0.85 (significant ramping) |
| P1b | 0.90 (specialist team, less ramping) |
| P2 | 0.85 (heavy ramping into MVP build) |
| P2a | 0.95 (team stabilized; QA ramp) |
| P3 | 0.85 in first 4 mo, 0.95 thereafter |
| P3a | 0.95 |
| P4 | 0.90 (cutover team forms; new ops engineers ramp) |
| P5 | 0.95 |

Total program effort in person-days × ramp factor → effective effort budget. Schedule is computed from effective effort ÷ phase FTE.

---

## 2. Indicative Epic catalog

The Epic catalog below is **indicative**, not the actual backlog. Real Epics emerge during P1 detailed design after Phase 0 audit clarifies scope. The catalog is sized to support rough capacity planning; per-Epic numbers will be re-baselined per Epic during refinement.

### 2.1 P2 — MVP (Partial FMS, single canonical scenario)

22 Epics — 18 Parity + 4 New-Value (≈18% new-value count, hits 20% by story-point weight after sizing).

#### Parity Epics

| ID | Epic | Workflow phase | Confidence | Best (PD) | Likely (PD) | Worst (PD) |
|---|---|---|---|---|---|---|
| FMS-E-001 | EMS event ingestion (planned distribution outage) | Notify | Medium | 60 | 90 | 140 |
| FMS-E-002 | Auto-create switching card from EMS event | Create | Medium | 80 | 130 | 200 |
| FMS-E-003 | Operator card review pane (parity layout) | Create | High | 50 | 80 | 120 |
| FMS-E-004 | Card edit / pre-execution validation | Create | Medium | 50 | 80 | 130 |
| FMS-E-005 | De-energize step orchestration | De-energize | Medium | 70 | 110 | 170 |
| FMS-E-006 | Tag application (single tag, single holder) | De-energize | Medium | 50 | 80 | 130 |
| FMS-E-007 | Authorization workflow (operator + supervisor) | Authorize | Medium | 60 | 100 | 160 |
| FMS-E-008 | Field execution handoff to Rapid Restore | Execute | Medium | 80 | 120 | 190 |
| FMS-E-009 | Step status updates from Rapid Restore | Execute | Medium | 50 | 80 | 130 |
| FMS-E-010 | Test-de-energized verification | Test | Medium | 40 | 70 | 110 |
| FMS-E-011 | Re-energize step orchestration | Re-energize | Medium | 60 | 100 | 160 |
| FMS-E-012 | Breaker-close instruction queued for EMS | Re-energize | Medium | 50 | 80 | 130 |
| FMS-E-013 | Card close + audit trail finalization | Close | Medium | 50 | 80 | 130 |
| FMS-E-014 | Operator console workflow navigation | cross-cutting | High | 70 | 110 | 160 |
| FMS-E-015 | Operator authentication + RBAC (district + role) | cross-cutting | Medium | 80 | 120 | 180 |
| FMS-E-016 | Audit & operator-action log foundational integration | cross-cutting | Medium | 100 | 150 | 220 |
| FMS-E-017 | Telemetry & observability instrumentation | cross-cutting | High | 50 | 80 | 110 |
| FMS-E-018 | NFR validation (latency, audit completeness) | cross-cutting | Medium | 40 | 70 | 110 |
| **Parity subtotal** | | | | **1,090** | **1,730** | **2,680** |

#### New-Value Epics

| ID | Epic | Workflow phase | Confidence | Best (PD) | Likely (PD) | Worst (PD) |
|---|---|---|---|---|---|---|
| FMS-NV-001 | Visual feeder topology preview at card create | Create | Low | 90 | 150 | 240 |
| FMS-NV-002 | Real-time multi-operator card visibility | cross-cutting | Low | 70 | 120 | 200 |
| FMS-NV-003 | Auto-suggest similar past cards (decision support) | Create | Low | 80 | 140 | 220 |
| FMS-NV-004 | Mobile-friendly read-only view for supervisor approval | Authorize | Medium | 60 | 100 | 160 |
| **New-Value subtotal** | | | | **300** | **510** | **820** |

**MVP TOTAL (P2):** Best **1,390 PD** · Likely **2,240 PD** · Worst **3,500 PD**

Cross-check: 2,240 PD likely / 28 effective FTE / ~22 working days/mo = 3.6 months pure development. Plus refinement, design overlap with P1, ramp-up factor 0.85, gives ~6.5 months elapsed — aligns with B1's likely case for P2.

#### MVP New-Value coverage check

By person-day weight: 510 / (1,730 + 510) = **22.8%** of MVP effort is new-value. Above the 20% target. ✓

---

### 2.2 P2a — MVP UAT & Approval

Not Epic-sized as build work. Effort is operator-facing cycles:

| Activity | Likely PD |
|---|---|
| UAT cycle execution (4 cycles × 2 weeks each) | 200 |
| Defect triage + fixes | 250 |
| Operator co-design sessions | 80 |
| Mental-model parity audits | 60 |
| Tangible new-value demo + iteration | 70 |
| M-06 panel preparation + sign-off | 40 |
| **TOTAL P2a** | **700 PD** |

Cross-check: 700 PD / 28 effective FTE / 22 days = ~1.1 months pure work. With UAT cycle wall-clock (each cycle is 2 weeks), elapsed is ~2 months — aligns with B1.

---

### 2.3 P3 — Incremental Build (5 cores + monitors)

Effort scales by app, with reuse factor applied to subsequent apps after FMS.

#### Per-app Epic groups (indicative)

Each core has roughly comparable Epic structure to FMS, scaled by complexity:

| App | Complexity factor vs FMS | Reuse factor | Notes |
|---|---|---|---|
| TOMS | 1.1× (transmission has more cross-substation) | 0.7 | Highest pattern reuse from FMS |
| DBM | 0.6× (foundational data, less workflow) | 0.5 | Different shape (data-centric) |
| DSO | 0.9× (dielectric — moderate uniqueness) | 0.6 | Some new patterns vs FMS/TOMS |
| SDS | 1.0× (steam — high uniqueness) | 0.5 | More custom workflow than common |
| TLS | 0.7× (telephonic line — narrower scope, but many integrations) | 0.5 | Integration-heavy |

Effort per app = (FMS-comparable scope × complexity factor) × (1 − reuse factor) + reuse-overhead.

Where:
- FMS-comparable parity scope (full FMS, not just MVP): ~3,000 PD likely (≈1.7× MVP since MVP is partial)
- Reuse-overhead = 15% of comparable scope (re-application, edge-case tuning, app-specific patterns)

Per-app likely estimates:

| App | Parity scope likely (PD) | New-value likely (PD) | Total likely (PD) |
|---|---|---|---|
| Remaining FMS scope (post-MVP) | 1,500 | 200 | 1,700 |
| TOMS | 1,400 | 250 | 1,650 |
| DBM | 900 | 150 | 1,050 |
| DSO | 1,400 | 250 | 1,650 |
| SDS | 1,600 | 250 | 1,850 |
| TLS | 1,100 | 200 | 1,300 |
| Monitor apps (~30) | 1,200 | 150 | 1,350 |
| Cross-app integrations (15+) | 1,400 | 0 | 1,400 |
| **P3 subtotal** | **10,500** | **1,450** | **11,950** |

Best/Worst spread: ~25% best-case savings; ~40% worst-case bloat (this is where hidden 4GL rules dominate).

| | Best (PD) | Likely (PD) | Worst (PD) |
|---|---|---|---|
| **P3 TOTAL** | **8,400** | **11,950** | **17,300** |

Cross-check: 11,950 PD / 50 effective FTE / 22 days = ~10.9 months pure work. Plus ramp-up, sprint overhead, dependencies, dispersion across 5 apps and integrations, gives 15 months elapsed — aligns with B1's likely case for P3.

---

### 2.4 P3a — Full UAT

| Activity | Likely PD |
|---|---|
| Cross-app workflow UAT | 350 |
| Cross-system regression | 250 |
| Performance under combined load | 180 |
| Disaster-recovery / islanding drill | 120 |
| Regulatory audit dry-run | 100 |
| Defect triage + fixes | 400 |
| **TOTAL P3a** | **1,400 PD** |

---

### 2.5 P4 — Cutover (6 staggered events)

Per-event budget × 6 + program-wide cutover infra:

| Event | Likely PD |
|---|---|
| Per-app cutover budget (rehearsals × 3, dry-run, weekend, stabilization, soak admin) | 280 × 6 = **1,680** |
| Program-wide cutover infra (rollback plane, observability, runbooks) | 400 |
| **TOTAL P4** | **2,080 PD** |

Per-event 280 PD breakdown:
- 3 dress rehearsals × 5 days × 4 people = 60 PD
- Dry-run + go/no-go reviews: 20 PD
- Cutover weekend ops: 30 PD
- Stabilization week: 50 PD
- Soak period support: 80 PD
- Documentation + audit pack: 40 PD

---

### 2.6 P5 — Hypercare (per-app + program-wide)

| Activity | Likely PD |
|---|---|
| Per-app hypercare (6 apps × ~4 weeks × ~4 FTE) | 480 |
| Program-wide hypercare (3 months × ~12 FTE) | 720 |
| **TOTAL P5** | **1,200 PD** |

---

### 2.7 P0a + P1 + P1a + P1b (front-end phases)

| Phase | Likely PD |
|---|---|
| P0a Phase 0 audit | 15 |
| P1 Detailed Design | 1,400 |
| P1a Foundational Tasks | 1,800 |
| P1b UDB → CIM POC | 600 |
| **Subtotal** | **3,815** |

---

### 2.8 Program totals (likely-case rollup)

| Phase | Likely PD |
|---|---|
| P0a Phase 0 Audit | 15 |
| P1 Detailed Design | 1,400 |
| P1a Foundational Tasks | 1,800 |
| P1b UDB→CIM POC | 600 |
| P2 MVP Build | 2,240 |
| P2a MVP UAT | 700 |
| P3 Incremental Build | 11,950 |
| P3a Full UAT | 1,400 |
| P4 Cutover | 2,080 |
| P5 Hypercare | 1,200 |
| **PROGRAM LIKELY** | **23,385 PD** |

Best/Worst program totals (the worksheet computes these by per-Epic Best/Worst rollup):

| | Best (PD) | Likely (PD) | Worst (PD) |
|---|---|---|---|
| **PROGRAM** | **~17,000** | **~23,385** | **~33,000** |

That ~16,000-PD spread between best and worst is the **honest cost of the irreducible uncertainty** described in `14-resource-plan-brutal-honesty-memo.md`. Anyone narrowing it without changing the underlying drivers is producing false confidence.

---

## 3. Cost calculation framework (for sponsor anchoring)

The companion xlsx has a configurable rate sheet. Sponsor populates rates in the rate bands; the worksheet computes:

```
Phase cost = Σ (Role FTE × Phase duration × Rate band)
Program cost = Σ Phase costs
```

**Without specific rates, no committed dollar figure is in this document.** However, indicative ranges using common utility-program rate magnitudes:

- Internal team blended rate $100–$150/hr → $800–$1,200/PD
- Specialist contractor (OpenRoad reader) $200–$300/hr → $1,600–$2,400/PD

Likely-case program cost at ~$1,000/PD blended: **~$23M USD**, with a defensible range of $17M–$33M depending on how variance materializes.

These are placeholders. Sponsor must populate real rates.

---

## 4. Scenarios in the worksheet

The `.xlsx` includes scenario columns:

| Scenario | What it changes |
|---|---|
| **Base (likely)** | All Epics at likely PD |
| **Optimistic** | All Epics at best PD; reuse factor 60% in P3 |
| **Pessimistic** | All Epics at worst PD; reuse factor 25% in P3 |
| **Phase 0 Red dimensions** | +6 weeks remediation; P3 worst-case ×1.15 |
| **OpenRoad reader unfilled** | All Epics ×1.15; P3 worst-case ×1.25 |
| **MVP UAT operator pull-back** | P2a +30 PD; M-06 slips by 6 weeks |
| **Pure big-bang cutover (instead of staggered)** | P4 −600 PD savings; cutover risk ×3; rollback prep ×1.5 |

Each scenario is a hypothesis about which variance drivers materialize. They are not equally likely; the worksheet does not weight them probabilistically.

---

## 5. Estimation gates (when these numbers get re-baselined)

| Gate | What gets re-estimated |
|---|---|
| End of P0a | Discovery audit RAG outcome triggers re-baseline of all P3 Epics if any Red dimensions |
| End of P1 (M-02) | Detailed-design output replaces indicative Epic catalog with real Epics; full re-estimation |
| End of P1b (M-04) | UDB→CIM POC outcome refines all data-migration estimates in P3 |
| End of P2 (M-05) | MVP velocity replaces velocity assumption for P3 |
| Mid-P3 (M-07) | Reuse-rate measured against actual TOMS + DBM completion; reset P3 worst-case |
| Pre-cutover (M-09) | Per-event cutover budget re-validated against rehearsal results |

**Re-baselining is not a sign of bad estimation. Refusing to re-baseline is.**

---

## 6. What this worksheet does not include (deliberately)

- **Specific dollar figures.** Sponsor controls rates.
- **Detailed task-level breakdown per Epic.** That's P1 detailed design output.
- **Vendor / procurement costs (EMS coordination, licensing, hardware).** Out of scope for this artifact.
- **Training / change-management cost outside the dedicated Change Lead.** The Change Lead's effort is in here; broader org training is a separate budget line.
- **Contingency reserve.** Recommendation: 15–20% on top of likely-case PD as a sponsor-controlled reserve. Not baked into the worksheet to keep PD numbers honest.

---

## 7. Reading the companion .xlsx

| Sheet | Purpose |
|---|---|
| Cover & Method | Documentation of the methodology summarized above |
| Epic Catalog | All Epics with Best/Likely/Worst PD, confidence, assumptions |
| Phase Rollup | Sum per phase; cross-check vs. duration |
| Effective FTE | Onboarding-adjusted productivity per phase |
| Scenarios | Optimistic / pessimistic / variance-trigger scenarios |
| Rate Card | Configurable rate bands (sponsor populates) |
| Program Total | Bottom-line rollup |

The `.xlsx` is the live working artifact. This `.md` is the methodology contract.
