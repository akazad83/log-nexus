# Materials & Templates Catalog

**Artifact ID:** B6.13
**Status:** Final — index of every artifact produced in Phase 1 planning
**Audience:** Sponsor, Program Lead, PMO, every Lead role
**Pairs with:** every other deliverable in this folder (this is the index)

This is the single PMO-facing reference that points to every artifact in the planning package. It enables a new joiner, an auditor, or a stakeholder to understand what exists, what each thing is for, who owns it, and when it gets used.

Companion `.xlsx` (`21-materials-catalog.xlsx`) holds the same content as a sortable/filterable workbook for live use.

---

## 1. How to use this catalog

Three lookups it supports:

| Question | Where to look |
|---|---|
| "What artifacts exist for {topic}?" | §3 Catalog (filter by Category column) |
| "What do I need at {phase}?" | §4 By Stage |
| "What artifacts will exist later that I should expect?" | §5 Forthcoming |
| "Who owns {artifact}?" | §6 Owners |
| "What does {artifact} reference and depend on?" | §7 Cross-References |

The catalog is **versioned with the program**. As Phase 1 detailed design produces ADRs, contract specs, and threat models, those move from §5 (Forthcoming) into §3 (Catalog).

---

## 2. Categories

Every artifact belongs to one primary category. The catalog groups by these.

| Category | Purpose |
|---|---|
| Memo | Decision-driver short-form documents |
| Planning | Phase / milestone / RACI / risk artifacts |
| Architecture | Technical and network architecture |
| Backlog Engineering | Pipeline guide + work-item templates |
| Resource & Estimation | FTE plans, estimation worksheets |
| Engineering Depth | DB, migration, DevOps, test, cutover artifacts |
| Tooling | Generators, converters, automation |
| Index | This catalog |

---

## 3. Catalog (the index)

Each row is one artifact. Multi-format artifacts (e.g., `.md` + `.xlsx`) are listed once with all formats noted.

### 3.1 Memo

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 00 | Phase 0 Discovery Audit Memo | `.md` | Stress-test Discovery outputs (600+ features, 650+ FRs, 1000+ rules) before Phase 1 begins. 3-day audit, 10 RAG dimensions, decision matrix. | Program Lead | Approved (D-002) | Static once executed |

### 3.2 Planning

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 01 | Master Project Plan Template | `.md` `.xlsx` | 10-sheet PMO workbook: Cover, Phases, Workstreams, **Master Schedule (full 442-row WBS — 10 phase summaries, 79 area summaries, 342 work packages, 11 milestones)**, Milestones & Gates, RACI, Risk Register, Assumption Log, Issue Log, Decision Log. | Program Lead | Draft | Continuous (live PMO doc) |
| 02 | Milestone & Phase Timeline | `.md` `.xlsx` `.docx` | Indicative 30–42 month timeline; phase-by-phase narrative; brutal-honesty appendix. Best/Likely/Worst per phase. | Program Lead | Draft | Per phase gate |

### 3.3 Architecture

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 03 | Technical Architecture Outline | `.md` (Mermaid) | 14 sections, 4 diagrams. Service inventory, layer model, EMS boundary detail, Rapid Restore boundary, standby/islanding, data flow scenarios. | Solution Architect | Draft | M-02 detailed-design lock |
| 04 | Network & Boundary Design | `.md` (Mermaid) | Zone topology, cross-zone protocol matrix, auth/encryption rules, failure modes, network change-control SLA. | Solution Architect + Security Lead | Draft | M-02 detailed-design lock |

### 3.4 Backlog Engineering

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 05 | Backlog Engineering Pipeline Guide | `.md` `.docx` | Translation rules Feature→Epic→Story→AC→Task. DoR (24 items). DoD (parity-aware). 9 story-splitting heuristics for switching workflows. 4 audit AC patterns. 20% new-value enforcement. | BA Lead + PO | Authoritative | Annual review |
| 06 | Epic Template | `.md` | Epic structure with worked example for FMS-E-014. | BA Lead | Authoritative | As-needed |
| 07 | User Story Template | `.md` | Story structure with INVEST checklist + vertical-slice anatomy. | BA Lead | Authoritative | As-needed |
| 08 | Acceptance Criteria Template | `.md` | Gherkin AC patterns (7 categories) + NFR addendum. `[REG]` tagging. Worked example. | BA Lead + Test Lead | Authoritative | As-needed |
| 09 | Spike Template | `.md` | Time-boxed investigation pattern. Worked example for SP-018 (EMS event schema). | Engineering Lead | Authoritative | As-needed |
| 10 | Task Template | `.md` | Engineer-day units with task-level DoD. | Engineering Lead | Authoritative | As-needed |
| 11 | Bug Template | `.md` | Operator-impact-aware severity scale. RCA fields. Audit/safety implication review. | Test Lead | Authoritative | As-needed |
| 12 | NFR Template | `.md` | Cross-cutting NFR template. Worked example for NFR-AUD-001 (audit log tamper-evidence). | Security Lead + Test Lead | Authoritative | As-needed |

### 3.5 Resource & Estimation

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 13 | Resource Plan | `.md` `.xlsx` | 27-role inventory, FTE ramp by phase, effective-FTE adjustments, skills matrix, key-person risks, hiring plan, configurable rate card. Peak ~60 FTE in P3. | Program Lead | Draft | Per phase gate |
| 14 | Resource Plan Brutal-Honesty Memo | `.md` `.docx` | 12-section memo on where estimates are most likely wrong, what reduces variance, what won't be compressed, and what I might be wrong about myself. | Program Lead | Draft | Each major estimate revision |
| 15 | Estimation Worksheet | `.md` `.xlsx` | Three-point estimates (Best/Likely/Worst) per Epic. MVP catalog (22 Epics). P3 per-app aggregates. Phase rollup. Scenario analysis. ~23,400 PD likely with $17M–$33M defensible range. | Engineering Lead | Draft | M-02 / M-04 / M-05 / M-07 / M-09 |

### 3.6 Engineering Depth (B5)

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| 16 | Database Design Principles | `.md` | Schema-per-service, audit/temporal strategy, partitioning + retention, indexing discipline, AG topology, migration discipline. | Data Architect | Draft | M-02 detailed-design lock |
| 17 | Data Migration Strategy | `.md` `.docx` | UDB→CIM conversion approach. ETL pattern. 3-layer reconciliation. Audit data continuity. Per-app cutover sequencing. Fallback authority by phase. | Data Architect | Draft | M-04 (P1b POC outcome) |
| 18 | DevOps / CI-CD Blueprint | `.md` | Tooling decisions, repo structure, branching, CI/CD pipelines, environment topology, cross-zone deployment workflow, secrets, rollback. | DevOps Lead | Draft | M-03 platform-live lock |
| 19 | Test Strategy | `.md` `.docx` | Test pyramid + every test layer. Operator-in-the-loop methodology. UAT M-06 criteria. Parity test harness. Resilience/chaos. Audit/regulatory testing. | Test Lead | Draft | Per release; M-08 lock for full UAT |
| 20 | Cutover Playbook Outline | `.md` | 4-week cutover window structure. DR1/DR2/DR3 gate authorities. Hour-by-hour cutover-weekend sequence. Inter-cutover learning loop. | Operations Lead | Outline (full runbook P4) | Per cutover event |

### 3.7 Tooling

| ID | Title | Formats | Purpose | Owner | Status | Re-baseline |
|---|---|---|---|---|---|---|
| T-1 | `_generate.py` | `.py` | Generates B1 binary artifacts from markdown sources (master plan xlsx with full WBS, milestone timeline xlsx + docx). | DevOps Lead | Working | As-needed |
| T-2 | `_generate_b4.py` | `.py` | Generates B4 binary artifacts (resource plan xlsx, estimation worksheet xlsx). | DevOps Lead | Working | As-needed |
| T-3 | `_md_to_docx.py` | `.py` | Focused markdown→docx converter for the patterns used in this folder. | DevOps Lead | Working | Reusable for future markdown deliverables |
| T-4 | `_generate_b6.py` | `.py` | Generates the materials catalog xlsx. | DevOps Lead | Working | As-needed |
| T-5 | `_wbs_data.py` | `.py` | Canonical WBS data — 442 rows covering all phases. Edit here; re-run `_generate.py` to refresh the master plan xlsx. | Program Lead + DevOps Lead | Working | When WBS revised at gate boundaries |

### 3.8 Index

| ID | Title | Formats | Purpose | Owner | Status |
|---|---|---|---|---|---|
| 21 | Materials & Templates Catalog | `.md` `.xlsx` | This document. | Program Lead | Final |

---

## 4. By Stage — when each artifact is used

| Stage | Artifacts in active use |
|---|---|
| **Pre-P1 (sponsor sign-off)** | 00 (audit memo); 02 (timeline); 14 (brutal-honesty memo); 15 (estimation); 21 (catalog) |
| **P0a Phase 0 Audit** | 00 (executes); 21 (catalog updated with audit RAG output) |
| **P1 Detailed Design** | 03 (architecture outline → detailed design); 04 (network design → SecOps approval); 16 (DB principles → per-service DB design); 13 (resource plan → hiring); 15 (estimation → re-baseline at M-02); 05–12 (templates → first refinement sessions); 17 (migration strategy → P1b POC plan); 18 (DevOps blueprint → P1a kickoff); 19 (test strategy → test platform planning) |
| **P1a Foundational** | 18 (DevOps blueprint → CI/CD build); 16 (DB principles → schema scaffolding); 13 (resource plan → ramp-up); 19 (test strategy → test platform stand-up) |
| **P1b UDB→CIM POC** | 17 (migration strategy → POC execution); 16 (DB principles → CIM schema); 19 (test strategy → reconciliation harness build) |
| **P2 MVP Build** | 05–12 (backlog engineering — every story passes through); 03 (architecture → reference); 16, 18, 19 (engineering reference); 15 (estimation → M-05 re-baseline) |
| **P2a MVP UAT** | 19 (test strategy → UAT execution); 11 (bug template → defect lifecycle); 14 (brutal-honesty memo → expectation calibration); 01 (master plan → M-06 gate) |
| **P3 Incremental Build** | All B3 templates; 15 (estimation → M-07 mid-point); 17 (migration → per-app); 19 (test strategy → ongoing) |
| **P3a Full UAT** | 19 (test strategy → cross-app UAT); 11 (bugs); 17 (regulator dry-run) |
| **P4 Cutover** | 20 (playbook outline → per-app runbook); 17 (migration strategy → per-app execution); 19 (test strategy → cutover testing) |
| **P5 Hypercare** | 11 (bugs); 19 (regression); 01 (master plan → M-11 exit) |
| **All phases** | 01 (master plan); 21 (catalog) |

---

## 5. Forthcoming — artifacts that will exist after this planning package

These are referenced throughout but not produced in B1–B6. They emerge from later phases. Each row points to where it gets defined.

### 5.1 P0a outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Phase 0 audit RAG dashboard | 00 audit memo §6 | Program Lead |
| Phase 0 audit recommendation memo | 00 audit memo §6 | Program Lead |

### 5.2 P1 detailed design outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Per-service domain models | 03 outline §13 (AD-decisions) | Domain Architects |
| API contract specifications (OpenAPI per service) | 03 outline | Backend Lead per service |
| Async event schemas | 03 outline §5.1 | Integration Lead |
| Integration contracts (15+ external) | 03 outline §5.2; 04 §5.4 | Integration Lead |
| Threat models per service (STRIDE) | 03 outline §4.4; 19 test strategy §10.4 | Security Lead |
| Architecture Decision Records (ADRs) | implicit in 03, 16, 18 | Solution Architect |
| Per-service NFR definitions | 12 NFR template + 03 outline | Each service team |
| Identity flow diagrams | 03 outline §4.1 | Security Lead |
| Detailed sequence diagrams per workflow | 03 outline §8 | Domain Architects |
| Boundary firewall rule list | 04 network design §10 | DevOps + SecOps |
| IP addressing scheme per zone | 04 network design §10 | Network team |

### 5.3 P1a foundational outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Azure DevOps YAML pipelines | 18 DevOps blueprint §20 | DevOps Lead |
| Per-service repo scaffolding | 18 DevOps blueprint §3 | DevOps Lead |
| Vault path structure (production) | 18 DevOps blueprint §9.2 | Security Lead + DevOps Lead |
| Pipeline agent provisioning runbooks | 18 DevOps blueprint §16 | DevOps Lead |
| Identity & RBAC configuration | 03 outline §4.1 | Security Lead |
| SQL Server schema scaffolding (per service) | 16 DB principles §3 | Data Architect |
| Audit & temporal foundational implementation (FOUND-S-022 implementation) | 16 DB principles §9; 12 NFR template | Data Architect + Security |
| Observability stack deployment | 03 outline §4.2 | DevOps Lead |

### 5.4 P1b POC outputs

| Artifact | Defined in | Owner |
|---|---|---|
| UDB→CIM type mapping specification | 17 migration §4.3 | Data Architect |
| CIM extension catalog | 17 migration §4.3 | Data Architect |
| Reconciliation harness (reusable) | 17 migration §6 | Data engineers |
| Profiling report (Ingres source) | 17 migration §2.3 | Data engineers |
| Failure-mode catalog (UDB constructs that don't map) | 17 migration §4.3 | Data Architect |
| ETL throughput projection | 17 migration §4.3 | Data engineers |

### 5.5 P2 / P3 ongoing outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Per-service runbooks | 03 outline §11; 18 DevOps blueprint | Service Manager + service team |
| Per-service operations dashboards | 03 outline §4.2 | Service Manager + service team |
| Operator parity capture corpus | 19 test strategy §8 | QA + Operator panel |
| Recorded sprint demos with operator commentary | 19 test strategy §5.4 | Test Lead + Operator panel |
| Operator co-design session recordings | 19 test strategy §5.4 | Operator panel + UX |
| Defect tail reports per release | 19 test strategy §16 | Test Lead |

### 5.6 P3a / P4 outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Cross-app workflow test suite | 19 test strategy §6.2 | QA engineers |
| Disaster-recovery / islanding drill report | 19 test strategy §12 | DevOps + Operations |
| Regulator audit dry-run packet | 19 test strategy §13.4 | Compliance |
| Per-app cutover runbook (full, 50–80 pages) | 20 cutover playbook outline | Operations Lead per app |
| Per-app dress rehearsal results (DR1, DR2, DR3) | 20 cutover playbook outline §3–6 | Operations Lead per app |
| Cutover-weekend war-room comms plan (per app) | 20 cutover playbook outline §11.2 | Communications Lead |

### 5.7 P5 outputs

| Artifact | Defined in | Owner |
|---|---|---|
| Hypercare exit memo (per app + program-wide) | 20 cutover playbook outline §10 | Service Manager |
| Compliance audit packet (regulator-facing) | 19 test strategy §13 | Compliance |
| Inter-cutover lessons log | 20 cutover playbook outline §15 | Operations Lead |
| Operations service-ownership acceptance | 20 cutover playbook outline §10.2 | Service Manager |

---

## 6. Owners — by role, what each owns

| Role | Owns (artifacts) | Owns (phase deliverables forthcoming) |
|---|---|---|
| Sponsor | Approval authority on D-001 cutover, D-002 audit, D-003 hosting | M-06 sign-off |
| Program Lead | 00, 01, 02, 13, 14, 21 | All gates; lessons log |
| Solution Architect | 03, 04 | ADRs; per-service architecture reviews |
| Domain Architects | (consume 03) | Per-service domain models; sequence diagrams |
| Backend Lead | (consume 16, 18, 19) | Per-service API contracts |
| Frontend Lead | (consume 03, 19) | Operator console parity validation |
| Data Architect | 16, 17 | UDB→CIM type mapping; CIM extensions; reconciliation harness |
| Integration Lead | (consume 03, 04, 17, 18) | EMS endpoint contract; integration contracts (15+) |
| DevOps Lead | 18 + tooling | YAML pipelines; Vault paths; runbooks |
| Test Lead | 19, 11 | Test platform; parity harness; UAT cycles |
| Security Lead | 04 (co-owner), 12 | Threat models; vault access policies; cert lifecycle |
| Operations Lead | 20 | Per-app cutover runbooks; cutover decisions |
| Service Manager | (consume 18, 20) | Per-service runbooks; hypercare |
| Change Lead | (consume 19) | Operator engagement plans |
| BA Lead | 05–12 | First refinement sessions; DoR enforcement |
| Compliance officer | (consume 16, 17, 19) | Regulator engagement; audit packets |

---

## 7. Cross-References — which artifact depends on which

```mermaid
flowchart TD
    M00[00 Audit Memo]
    M01[01 Master Plan]
    M02[02 Timeline + B-H Memo]
    M03[03 Architecture]
    M04[04 Network]
    M05[05 Pipeline Guide]
    M06[06-12 Templates]
    M13[13 Resource Plan]
    M14[14 Resource B-H Memo]
    M15[15 Estimation]
    M16[16 DB Principles]
    M17[17 Migration]
    M18[18 DevOps]
    M19[19 Test]
    M20[20 Cutover Outline]
    M21[21 Catalog]

    M00 --> M01
    M00 --> M02
    M01 --> M02
    M01 --> M13
    M02 --> M13
    M03 --> M04
    M03 --> M16
    M16 --> M17
    M03 --> M17
    M03 --> M18
    M04 --> M18
    M16 --> M18
    M03 --> M19
    M16 --> M19
    M18 --> M19
    M17 --> M19
    M19 --> M20
    M17 --> M20
    M04 --> M20
    M05 --> M06
    M05 --> M19
    M13 --> M14
    M13 --> M15
    M21 --> M00
    M21 --> M01
    M21 --> M02
    M21 --> M03
    M21 --> M04
    M21 --> M05
    M21 --> M13
    M21 --> M15
    M21 --> M16
    M21 --> M17
    M21 --> M18
    M21 --> M19
    M21 --> M20
```

(The catalog references everything; nothing references the catalog except as an index.)

---

## 8. Format inventory — what was produced

| Format | Count | Files |
|---|---|---|
| `.md` (source-of-truth + standalone) | 22 | 00–21 markdown sources |
| `.xlsx` | 5 | 01, 02, 13, 15, 21 |
| `.docx` | 5 | 02, 05, 14, 17, 19 |
| `.py` (tooling + WBS data) | 5 | _generate.py, _generate_b4.py, _generate_b6.py, _md_to_docx.py, _wbs_data.py |

**Total artifacts:** 22 distinct deliverables (multi-format counted once) + 5 tooling/data scripts.

---

## 9. Status legend

| Status | Meaning |
|---|---|
| Draft | Produced; awaiting sponsor / council review |
| Reviewed | Peer-reviewed but not formally approved |
| Approved | Formally approved by named gate authority |
| Authoritative | Becomes the rulebook — like backlog templates |
| Outline | Structure produced; full artifact emerges in later phase |
| Working | Tooling that runs and produces output |
| Final | Completed and not expected to change without explicit revision request |

---

## 10. Adoption checklist for the PMO

To move this package from "produced" to "in use":

- [ ] Sponsor sign-off on B1 (timeline, master plan template structure)
- [ ] Sponsor sign-off on B2 (architecture outline, network design)
- [ ] Sponsor sign-off on B3 (backlog pipeline, templates) → templates configured in Azure DevOps
- [ ] Sponsor sign-off on B4 (resource plan, brutal-honesty memo, estimation worksheet) → rate card populated; sponsor anchored
- [ ] Sponsor sign-off on B5 (DB, migration, DevOps, test, cutover) → leads briefed
- [ ] Phase 0 audit scheduled and executed (P0a)
- [ ] Open decisions in each artifact transferred to a master open-decisions register
- [ ] Each open decision has an owner and a required-by date
- [ ] First refinement session run with templates from B3
- [ ] Hiring plan (in 13) shared with HR
- [ ] OpNET / SecOps engaged for B5 #10 network firewall rule pre-staging

---

## 11. The one paragraph this catalog is really for

If you read nothing else in this package: **the program is feasible in 30–42 months with an internal team peaking at ~60 FTE, delivered as 6 staggered cutovers with FMS first as a partial-MVP.** The variance bands are real, dominated by hidden 4GL rules and pattern-reuse rate from MVP to incremental build. The single most cost-effective risk-reduction action is the 3-day Phase 0 audit. The single most consequential decision still pending is whether the sponsor's stated bench (15–20 .NET/Angular engineers) is total program staff or just engineers — those are very different programs. Run the audit. Confirm the headcount. Then proceed.
