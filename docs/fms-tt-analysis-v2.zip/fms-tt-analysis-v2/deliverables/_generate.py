"""
Generator for B1 deliverables.

Reads the markdown source-of-truth specs and produces:
  - 01-master-project-plan-template.xlsx
  - 02-milestone-phase-timeline.xlsx
  - 02-milestone-phase-timeline.docx

Run from this directory: python _generate.py
"""

from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

from _wbs_data import WBS_ROWS

OUT = Path(__file__).parent

# ---- styling helpers --------------------------------------------------------

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
SUBHEADER_FILL = PatternFill("solid", fgColor="D9E1F2")
SUBHEADER_FONT = Font(name="Calibri", size=11, bold=True, color="1F3864")
BODY_FONT = Font(name="Calibri", size=10)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

RAG_FILLS = {
    "Green": PatternFill("solid", fgColor="C6EFCE"),
    "Amber": PatternFill("solid", fgColor="FFEB9C"),
    "Red": PatternFill("solid", fgColor="FFC7CE"),
}


def style_header_row(ws, row=1, ncols=None):
    if ncols is None:
        ncols = ws.max_column
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 30
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def autosize_columns(ws, min_width=10, max_width=60):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        longest = 0
        for cell in col:
            v = cell.value
            if v is None:
                continue
            for line in str(v).splitlines():
                longest = max(longest, len(line))
        ws.column_dimensions[letter].width = max(min_width, min(max_width, longest + 2))


def write_table(ws, headers, rows, start_row=1):
    for c, h in enumerate(headers, 1):
        ws.cell(row=start_row, column=c, value=h)
    style_header_row(ws, row=start_row, ncols=len(headers))
    for r, row in enumerate(rows, start_row + 1):
        for c, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=c, value=val)
            cell.font = BODY_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = BORDER
    autosize_columns(ws)


# ---- 01: Master Project Plan template --------------------------------------

def build_master_plan():
    wb = Workbook()
    wb.remove(wb.active)

    # Sheet 1 — Cover & Legend
    ws = wb.create_sheet("Cover & Legend")
    ws["A1"] = "Master Project Plan — Switching Order Modernization"
    ws["A1"].font = Font(name="Calibri", size=16, bold=True, color="1F3864")
    ws.merge_cells("A1:D1")
    ws["A3"] = "Document Control"
    ws["A3"].font = SUBHEADER_FONT
    ws["A3"].fill = SUBHEADER_FILL
    ws.merge_cells("A3:D3")
    fields = [
        ("Program", "Switching Order Modernization"),
        ("Document", "Master Project Plan"),
        ("Version", "0.1 (template)"),
        ("Owner", "Program Lead"),
        ("Last Updated", ""),
        ("Sponsor", ""),
        ("Steering Committee", ""),
    ]
    for i, (k, v) in enumerate(fields, 4):
        ws.cell(row=i, column=1, value=k).font = Font(name="Calibri", size=11, bold=True)
        ws.cell(row=i, column=2, value=v).font = BODY_FONT

    ws["A12"] = "RAG Legend"
    ws["A12"].font = SUBHEADER_FONT
    ws["A12"].fill = SUBHEADER_FILL
    ws.merge_cells("A12:D12")
    rag = [
        ("Green", "On plan; no intervention required"),
        ("Amber", "At risk; mitigation in progress; recoverable within 1–2 sprints"),
        ("Red", "Off plan; escalation required; not recoverable without sponsor decision"),
    ]
    for i, (status, desc) in enumerate(rag, 13):
        c = ws.cell(row=i, column=1, value=status)
        c.font = Font(bold=True)
        c.fill = RAG_FILLS[status]
        ws.cell(row=i, column=2, value=desc).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=4)

    ws["A17"] = "Status Legend"
    ws["A17"].font = SUBHEADER_FONT
    ws["A17"].fill = SUBHEADER_FILL
    ws.merge_cells("A17:D17")
    statuses = [
        ("Not Started", "Work has not begun"),
        ("In Progress", "Active work"),
        ("Blocked", "Waiting on external dependency"),
        ("In Review", "Work submitted; awaiting acceptance"),
        ("Done", "Accepted and closed"),
        ("Cancelled", "Out of scope; documented why"),
    ]
    for i, (k, v) in enumerate(statuses, 18):
        ws.cell(row=i, column=1, value=k).font = Font(name="Calibri", size=11, bold=True)
        ws.cell(row=i, column=2, value=v).font = BODY_FONT
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=4)

    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 70

    # Sheet 2 — Phases
    ws = wb.create_sheet("Phases")
    headers = ["Phase ID", "Phase", "Start", "End", "Gate Owner", "Gate Status", "Notes"]
    rows = [
        ["P0", "Discovery", "(done)", "(done)", "Sponsor", "Closed", "600+ features, 650+ FRs, 1000+ rules captured"],
        ["P0a", "Phase 0 Audit", "TBD", "TBD", "Program Lead", "Pending", "3-day audit of Discovery outputs"],
        ["P1", "Detailed Design", "TBD", "TBD", "Architecture Council", "Pending", "Drives all build estimates"],
        ["P1a", "Foundational Tasks", "TBD", "TBD", "Engineering Lead", "Pending", "Env, skeletons, auth, CI/CD, broker"],
        ["P1b", "UDB → CIM POC", "TBD", "TBD", "Data Architecture", "Pending", "Gates the data migration approach"],
        ["P2", "MVP Build (FMS)", "TBD", "TBD", "Operations Lead", "Pending", "Operator-facing first slice"],
        ["P2a", "MVP UAT & Approval", "TBD", "TBD", "District Operators", "Pending", "HARD GATE — operator sign-off required"],
        ["P3", "Incremental Build", "TBD", "TBD", "Program Lead", "Pending", "Remaining 5 cores + monitors"],
        ["P3a", "Full UAT", "TBD", "TBD", "Operations Lead", "Pending", "Cross-app workflows"],
        ["P4", "Cutover (staggered per app)", "TBD", "TBD", "Operations Lead + CIO", "Pending", "Option A — staggered big-bang per app"],
        ["P5", "Hypercare", "TBD", "TBD", "Service Owner", "Pending", "Per-app + program-wide"],
    ]
    write_table(ws, headers, rows)

    # Sheet 3 — Workstreams
    ws = wb.create_sheet("Workstreams")
    headers = ["WS ID", "Workstream", "Lead Role", "Active In Phases", "Notes"]
    rows = [
        ["WS-ARC", "Architecture", "Solution Architect", "All", "Owns boundary integrity (OpNET/DMZ/CorpNET), tech-debt budget"],
        ["WS-BE", "Backend (.NET)", "Backend Lead", "P1a–P5", "Domain services, message broker integration"],
        ["WS-FE", "Frontend (Angular)", "Frontend Lead", "P1a–P5", "Operator console, monitor apps"],
        ["WS-DATA", "Data & DB", "Data Architect", "P1b–P5", "Ingres → SQL migration, partitioning, audit/temporal"],
        ["WS-INT", "Integration", "Integration Lead", "P1–P5", "EMS/XA21, Rapid Restore, GIS, FeederBoard, CPMS"],
        ["WS-DO", "DevOps / Infra", "DevOps Lead", "All", "Azure DevOps on-prem, IIS, environment topology, secrets"],
        ["WS-QA", "Quality Engineering", "Test Lead", "All", "Unit, contract, integration, performance, security, UAT"],
        ["WS-SEC", "Security & Compliance", "Security Lead", "All", "Identity, audit, regulatory traceability, SAST"],
        ["WS-OPS", "Operations Readiness", "Service Manager", "P2–P5", "Runbooks, on-call, SRE patterns, cutover playbooks"],
        ["WS-CHM", "Change Management", "Change Lead", "P2–P5", "Operator engagement, training, comms, adoption metrics"],
    ]
    write_table(ws, headers, rows)

    # Sheet 4 — Master Schedule (full WBS from _wbs_data.WBS_ROWS)
    ws = wb.create_sheet("Master Schedule")
    headers = [
        "WBS", "Level", "Type", "Phase ID", "Workstream", "Task", "Description",
        "Owner", "Start", "End", "Duration (days)", "Predecessors",
        "% Complete", "Status", "RAG",
        "Risk Refs", "Assumption Refs", "Issue Refs", "Decision Refs", "Notes",
    ]

    # Map _wbs_data tuples → row values with PMO defaults
    rows = []
    for wbs in WBS_ROWS:
        (wbs_id, level, wp_type, phase, workstream, task, description,
         duration, predecessors, risks, assumptions, decisions, notes) = wbs
        # Defaults per PMO conventions
        owner = "(name)"
        start = "TBD"
        end = "TBD"
        pct = 0
        if wp_type == "Milestone":
            status = "Pending"
            rag = ""
        else:
            status = "Not Started"
            rag = "Green"
        rows.append([
            wbs_id, level, wp_type, phase, workstream, task, description,
            owner, start, end, duration, predecessors,
            pct, status, rag,
            risks, assumptions, "", decisions, notes,
        ])

    write_table(ws, headers, rows)

    # Visual styling
    # Indices (1-based): WBS=1, Level=2, Type=3, Phase=4, WS=5, Task=6, ...
    # RAG=15, Status=14, Type=3, Level=2
    SUMMARY_FILL = PatternFill("solid", fgColor="D9E1F2")  # light blue
    MILESTONE_FILL = PatternFill("solid", fgColor="FFE5B4")  # light orange
    LEVEL1_FILL = PatternFill("solid", fgColor="1F3864")    # dark blue
    LEVEL2_FILL = PatternFill("solid", fgColor="BDD7EE")    # mid blue

    for r_idx in range(2, 2 + len(rows)):
        type_cell = ws.cell(row=r_idx, column=3).value
        level = ws.cell(row=r_idx, column=2).value

        if type_cell == "Milestone":
            for c in range(1, len(headers) + 1):
                ws.cell(row=r_idx, column=c).fill = MILESTONE_FILL
            ws.cell(row=r_idx, column=6).font = Font(name="Calibri", size=10, bold=True, color="8B4513")
        elif type_cell == "Summary":
            if level == 1:
                for c in range(1, len(headers) + 1):
                    ws.cell(row=r_idx, column=c).fill = LEVEL1_FILL
                    ws.cell(row=r_idx, column=c).font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
            elif level == 2:
                for c in range(1, len(headers) + 1):
                    ws.cell(row=r_idx, column=c).fill = LEVEL2_FILL
                ws.cell(row=r_idx, column=6).font = Font(name="Calibri", size=10, bold=True, color="1F3864")
            else:
                for c in range(1, len(headers) + 1):
                    ws.cell(row=r_idx, column=c).fill = SUMMARY_FILL

        # Color RAG cell (column 15) for non-summary, non-milestone rows
        if type_cell == "WorkPackage":
            rag = ws.cell(row=r_idx, column=15).value
            if rag in RAG_FILLS:
                ws.cell(row=r_idx, column=15).fill = RAG_FILLS[rag]

    # Column widths tuned for readability
    ws.column_dimensions["A"].width = 10  # WBS
    ws.column_dimensions["B"].width = 7   # Level
    ws.column_dimensions["C"].width = 13  # Type
    ws.column_dimensions["D"].width = 8   # Phase
    ws.column_dimensions["E"].width = 11  # WS
    ws.column_dimensions["F"].width = 60  # Task
    ws.column_dimensions["G"].width = 55  # Description
    ws.column_dimensions["H"].width = 14  # Owner
    ws.column_dimensions["I"].width = 11  # Start
    ws.column_dimensions["J"].width = 11  # End
    ws.column_dimensions["K"].width = 12  # Duration
    ws.column_dimensions["L"].width = 22  # Predecessors
    ws.column_dimensions["M"].width = 9   # % Complete
    ws.column_dimensions["N"].width = 12  # Status
    ws.column_dimensions["O"].width = 8   # RAG
    ws.column_dimensions["P"].width = 18  # Risk Refs
    ws.column_dimensions["Q"].width = 18  # Assumption Refs
    ws.column_dimensions["R"].width = 14  # Issue Refs
    ws.column_dimensions["S"].width = 14  # Decision Refs
    ws.column_dimensions["T"].width = 50  # Notes

    # Group rows by level for collapsibility (Excel outline)
    for r_idx in range(2, 2 + len(rows)):
        level = ws.cell(row=r_idx, column=2).value
        if isinstance(level, int) and level >= 2:
            ws.row_dimensions[r_idx].outline_level = level - 1
            ws.row_dimensions[r_idx].hidden = False
    ws.sheet_properties.outlinePr.summaryBelow = False
    ws.sheet_properties.outlinePr.summaryRight = False

    # Sheet 5 — Milestones & Gates
    ws = wb.create_sheet("Milestones & Gates")
    headers = ["Milestone ID", "Milestone", "Phase", "Gate Owner", "Decision Criteria", "Date", "Decision", "Decision Date", "Notes"]
    rows = [
        ["M-01", "Phase 0 Audit Complete", "P0a", "Program Lead",
         "All-Green or Amber-with-remediation; no Reds outstanding", "TBD", "Pending", "", ""],
        ["M-02", "Detailed Design Approved", "P1", "Architecture Council",
         "All 6 cores have approved domain models, integration contracts, NFRs", "TBD", "Pending", "", ""],
        ["M-03", "Foundational Platform Live", "P1a", "Engineering Lead",
         "Dev/SIT envs operational; CI/CD green for skeleton; identity working", "TBD", "Pending", "", ""],
        ["M-04", "UDB→CIM POC Pass", "P1b", "Data Architecture",
         "Reconciliation report shows ≥99.9% row-level fidelity on FMS sample", "TBD", "Pending", "", ""],
        ["M-05", "MVP Feature-Complete (FMS)", "P2", "Engineering Lead",
         "All MVP user stories Done per DoD", "TBD", "Pending", "", ""],
        ["M-06", "MVP Operator Approval (HARD GATE)", "P2a", "District Operators",
         "Operator panel signs off; mental-model parity achieved; tangible new value validated", "TBD", "Pending", "",
         "Hardest gate in program. Treat softening pressure as Red risk."],
        ["M-07", "Incremental Build Mid-Point Review", "P3", "Program Lead",
         "50% of remaining cores feature-complete; no Red risks unmitigated", "TBD", "Pending", "", ""],
        ["M-08", "Full UAT Pass", "P3a", "Operations Lead",
         "All cross-app workflows tested; defect tail meets exit criteria", "TBD", "Pending", "", ""],
        ["M-09", "FMS Cutover Live", "P4", "Operations Lead + CIO",
         "Dress rehearsal #3 clean; rollback plan tested", "TBD", "Pending", "", ""],
        ["M-10", "All Cores Cut Over", "P4", "Operations Lead + CIO",
         "All 6 apps + monitors live; legacy retired", "TBD", "Pending", "", ""],
        ["M-11", "Hypercare Exit", "P5", "Service Owner",
         "Defect rate ≤ steady-state threshold for 30 consecutive days", "TBD", "Pending", "", ""],
    ]
    write_table(ws, headers, rows)

    # Sheet 6 — RACI
    ws = wb.create_sheet("RACI")
    ws_cols = ["WS-ARC", "WS-BE", "WS-FE", "WS-DATA", "WS-INT", "WS-DO", "WS-QA", "WS-SEC", "WS-OPS", "WS-CHM"]
    headers = ["Role"] + ws_cols
    raci = [
        ["Program Lead",       "C", "I", "I", "I", "I", "I", "I", "I", "C", "C"],
        ["Solution Architect", "A", "C", "C", "C", "C", "C", "C", "C", "C", "I"],
        ["Backend Lead",       "C", "A", "C", "C", "R", "C", "C", "C", "I", "I"],
        ["Frontend Lead",      "C", "C", "A", "I", "I", "C", "C", "C", "I", "C"],
        ["Data Architect",     "C", "C", "I", "A", "C", "C", "C", "C", "I", "I"],
        ["Integration Lead",   "C", "R", "I", "C", "A", "C", "C", "C", "C", "I"],
        ["DevOps Lead",        "C", "C", "C", "C", "C", "A", "C", "C", "R", "I"],
        ["Test Lead",          "C", "C", "C", "C", "C", "C", "A", "C", "C", "I"],
        ["Security Lead",      "C", "C", "C", "C", "C", "C", "C", "A", "C", "I"],
        ["Service Manager",    "I", "I", "I", "I", "I", "C", "C", "C", "A", "C"],
        ["Change Lead",        "I", "I", "C", "I", "I", "I", "I", "I", "C", "A"],
        ["Sponsor",            "I", "I", "I", "I", "I", "I", "I", "I", "I", "I"],
        ["District Operators", "C", "I", "C", "I", "I", "I", "C", "I", "C", "R"],
    ]
    write_table(ws, headers, raci)
    # color A/R/C/I distinctively
    fill_map = {
        "A": PatternFill("solid", fgColor="1F3864"),
        "R": PatternFill("solid", fgColor="2E75B6"),
        "C": PatternFill("solid", fgColor="BDD7EE"),
        "I": PatternFill("solid", fgColor="EAF1F8"),
    }
    text_map = {"A": "FFFFFF", "R": "FFFFFF", "C": "1F3864", "I": "1F3864"}
    for r in range(2, 2 + len(raci)):
        for c in range(2, 2 + len(ws_cols)):
            cell = ws.cell(row=r, column=c)
            v = cell.value
            if v in fill_map:
                cell.fill = fill_map[v]
                cell.font = Font(name="Calibri", size=10, bold=True, color=text_map[v])
                cell.alignment = Alignment(horizontal="center", vertical="center")

    # Sheet 7 — Risk Register
    ws = wb.create_sheet("Risk Register")
    headers = ["Risk ID", "Description", "Category", "Probability (1-5)", "Impact (1-5)", "Score",
               "Mitigation", "Contingency", "Owner", "Status", "Last Reviewed"]
    risks = [
        ["R-001", "Hidden business rules in OpenRoad code surface during build, inflating Incremental Build estimates",
         "Scope", 5, 5, 25,
         "Phase 0 audit dimensions 3 + 10; budget remediation in Discovery",
         "Re-baseline Incremental Build estimates if 4GL reads surface >15% additional rules",
         "Solution Architect", "Open", ""],
        ["R-002", "EMS/XA21 integration regression during MVP UAT or cutover",
         "Integration", 4, 5, 20,
         "Contract tests; vendor co-design; canary tests during dress rehearsals",
         "Pause cutover; revert to legacy for affected workflow; vendor escalation",
         "Integration Lead", "Open", ""],
        ["R-003", "Operator change-management resistance delays MVP approval (M-06)",
         "Change", 3, 5, 15,
         "Operator embed during MVP build; mental-model audit; co-design sessions",
         "Extend MVP UAT cycle; targeted re-design for high-friction workflows",
         "Change Lead", "Open", ""],
        ["R-004", "Audit-trail gaps during per-app cutover (Option A)",
         "Compliance", 3, 5, 15,
         "Bidirectional audit replication during soak; reconciliation tooling",
         "Manual reconciliation reports filed with regulator until automated coverage proven",
         "Security Lead", "Open", ""],
        ["R-005", "OpenRoad-experienced engineer shortage limits 4GL reads",
         "Resource", 5, 4, 20,
         "Identify reader role early; consider short-term contractor",
         "Outsource targeted 4GL reads; shift Discovery audit dimension 10 ownership",
         "Program Lead", "Open", ""],
        ["R-006", "Ingres-to-SQL semantic mismatches (NULL handling, date semantics, numeric precision)",
         "Data", 4, 4, 16,
         "UDB→CIM POC + reconciliation harness; type-mapping spec",
         "Custom adapters for problematic types; expanded reconciliation runs",
         "Data Architect", "Open", ""],
        ["R-007", "OpNET / DMZ / CorpNET network change-control velocity bottlenecks env builds",
         "Infra", 4, 3, 12,
         "Engage SecOps on network design memo (B5) early; pre-stage approvals",
         "Parallel-track non-blocking work; escalate at program-lead level",
         "DevOps Lead", "Open", ""],
        ["R-008", "'Flexible' budget gets capped mid-program, forcing scope reduction post-M-06",
         "Governance", 3, 4, 12,
         "Anchor sponsor on B4 estimation worksheet; phase-gated funding",
         "Defined scope-reduction options ranked by operator-impact",
         "Program Lead", "Open", ""],
        ["R-009", "Standby OpNET environment drift from CorpNET primary",
         "Operations", 3, 4, 12,
         "Automated drift detection; weekly sync; islanding drills",
         "Manual reconciliation; targeted re-deploy from CI artifacts",
         "Service Manager", "Open", ""],
        ["R-010", "Cutover dress-rehearsal cycle insufficient for Option A's 6 cutover events",
         "Cutover", 3, 5, 15,
         "Minimum 3 dress rehearsals per app; shared rehearsal infra",
         "Defer next cutover; extend soak; rerun rehearsal cycle",
         "Operations Lead", "Open", ""],
    ]
    write_table(ws, headers, risks)
    # heatmap on Score (col 6)
    for r in range(2, 2 + len(risks)):
        score_cell = ws.cell(row=r, column=6)
        score = score_cell.value
        if isinstance(score, int):
            if score >= 20:
                fill_color = "FFC7CE"
            elif score >= 12:
                fill_color = "FFEB9C"
            else:
                fill_color = "C6EFCE"
            score_cell.fill = PatternFill("solid", fgColor=fill_color)
            score_cell.font = Font(name="Calibri", size=10, bold=True)
            score_cell.alignment = Alignment(horizontal="center")

    # Sheet 8 — Assumption Log
    ws = wb.create_sheet("Assumption Log")
    headers = ["Assumption ID", "Description", "Phase", "Validation Approach", "Validation Date", "Owner", "Status"]
    assumptions = [
        ["A-001", "Internal .NET/Angular team has 15–20 engineers available for ramp by P1a start", "P1a", "HR + resource manager confirm bench", "", "Program Lead", "Open"],
        ["A-002", "At least one engineer can read OpenRoad code; otherwise contractor identified within 4 weeks of P1 start", "P1", "Skill audit; contractor shortlist", "", "Program Lead", "Open"],
        ["A-003", "Operator SMEs available 4–8 hrs/week per app for design + 1 dedicated per app for UAT", "P1–P2a", "Schedule confirmation by Operations Lead", "", "Operations Lead", "Open"],
        ["A-004", "EMS/XA21 vendor provides sample event payloads + integration test harness", "P1", "Vendor engagement; SoW addendum if required", "", "Integration Lead", "Open"],
        ["A-005", "Switching card volume ~150K/year aggregate; 7-year retention; standard regulator query patterns", "P1b", "Data profiling on Ingres production sample", "", "Data Architect", "Open"],
        ["A-006", "Cutover Option A approved (staggered big-bang per app)", "All", "Sponsor + CIO sign-off", "", "Program Lead", "Validated"],
        ["A-007", "OpNET standby is in scope and will be provisioned for cutover hypercare", "P4–P5", "Infra design memo (B5); SecOps approval", "", "DevOps Lead", "Open"],
        ["A-008", "CIM 17 covers FMS, TOMS, DSO, SDS, TLS feeder hierarchy with ≤5% custom extensions", "P1b", "UDB→CIM POC", "", "Data Architect", "Open"],
        ["A-009", "'Flexible' budget translates to a sponsor-approvable range derived from B4", "P1", "Estimation worksheet review with sponsor", "", "Program Lead", "Open"],
        ["A-010", "Indicative target is 30–42 months total program duration", "All", "Confirmed in B1 milestone timeline", "", "Program Lead", "Open"],
    ]
    write_table(ws, headers, assumptions)

    # Sheet 9 — Issue Log
    ws = wb.create_sheet("Issue Log")
    headers = ["Issue ID", "Description", "Raised Date", "Owner", "Target Resolution", "Status", "Resolution Notes"]
    write_table(ws, headers, [])
    # add an example placeholder row
    ws.cell(row=2, column=1, value="(populated as program runs)").font = Font(italic=True, color="808080")

    # Sheet 10 — Decision Log
    ws = wb.create_sheet("Decision Log")
    headers = ["Decision ID", "Title", "Phase", "Decision", "Rationale", "Decided By", "Decision Date", "Reversibility", "Notes"]
    decisions = [
        ["D-001", "Cutover strategy", "All", "Option A — staggered big-bang per application",
         "Lower blast radius; +3–4 months program length acceptable given no hard deadline",
         "Sponsor + CIO", "", "Hard-to-reverse", ""],
        ["D-002", "Phase 0 audit", "P0a", "Approved 3-day audit before Phase 1",
         "Avoid baseline-shakiness propagating into estimates",
         "Sponsor", "", "Reversible", ""],
        ["D-003", "Target hosting", "All", "On-prem IIS (no cloud)",
         "Aligned with OT/IT segmentation policy", "CIO", "", "Hard-to-reverse", ""],
        ["D-004", "Source control + CI/CD", "P1a", "On-prem Azure Repo + Azure DevOps",
         "Aligned with on-prem strategy and compliance posture", "CIO", "", "Reversible", ""],
        ["D-005", "First MVP application", "P2", "FMS (proposed; pending sponsor confirm)",
         "Highest operational volume; richest workflow patterns; reusable for remaining 5 cores",
         "Pending", "", "Reversible", ""],
    ]
    write_table(ws, headers, decisions)

    out_path = OUT / "01-master-project-plan-template.xlsx"
    wb.save(out_path)
    print(f"  wrote {out_path.name}")


# ---- 02: Milestone & Phase Timeline (xlsx) ---------------------------------

def build_milestone_xlsx():
    wb = Workbook()
    wb.remove(wb.active)

    # Sheet 1 — Phase Durations (Best/Likely/Worst)
    ws = wb.create_sheet("Phase Durations")
    headers = ["Phase ID", "Phase", "Best", "Likely", "Worst", "Driver of Variance"]
    rows = [
        ["P0a", "Phase 0 Audit", "3 days", "5 days", "10 days", "Operator availability for 4GL spot-reads"],
        ["P1", "Detailed Design", "3 mo", "4 mo", "5 mo", "Discovery audit RAG; integration contract gaps; SME engagement"],
        ["P1a", "Foundational Tasks", "2 mo", "3 mo", "4 mo", "SecOps change-control velocity; on-prem agent provisioning"],
        ["P1b", "UDB → CIM POC", "1.5 mo", "2 mo", "3 mo", "UDB schema complexity; CIM coverage gaps; reconciliation tooling"],
        ["P2", "MVP Build (FMS)", "5 mo", "6.5 mo", "8 mo", "Operator SME engagement; frontend complexity; EMS event-schema firmness"],
        ["P2a", "MVP UAT & Approval", "1.5 mo", "2 mo", "3 mo", "Operator engagement depth; defect tail; mental-model parity"],
        ["P3", "Incremental Build", "12 mo", "15 mo", "20 mo", "Pattern reuse; integration count per app; hidden 4GL rules"],
        ["P3a", "Full UAT", "2 mo", "3 mo", "4 mo", "Cross-app workflow density; regulatory audit prep"],
        ["P4", "Cutover (6 events, staggered)", "4 mo", "6 mo", "8 mo", "Per-app rehearsal cycles; rollback events; soak between cutovers"],
        ["P5", "Hypercare (overlapping)", "3 mo", "4 mo", "6 mo", "Field defect volume; integration regression rate"],
    ]
    write_table(ws, headers, rows)
    # add summary rows
    last = ws.max_row + 2
    ws.cell(row=last, column=1, value="Composite (with overlap)").font = Font(bold=True, color="1F3864")
    ws.merge_cells(start_row=last, start_column=1, end_row=last, end_column=2)
    composite = [
        ["Best case (all overlap, no surprises)", "~30 months"],
        ["Likely case", "~36 months"],
        ["Worst case (Reds, hidden rules, vendor delays)", "~42 months"],
    ]
    for i, (label, val) in enumerate(composite, last + 1):
        ws.cell(row=i, column=1, value=label).font = Font(name="Calibri", size=10)
        ws.cell(row=i, column=2, value=val).font = Font(name="Calibri", size=10, bold=True)
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=2)

    # Sheet 2 — Indicative Timeline (month-numbered Gantt)
    ws = wb.create_sheet("Indicative Timeline")
    months = list(range(1, 43))  # 42 months
    header_row = ["Phase"] + [f"M{m}" for m in months]
    ws.append(header_row)
    style_header_row(ws, row=1, ncols=len(header_row))

    # likely-case month ranges
    timeline = [
        ("P0a Phase 0 Audit",       1, 1),
        ("P1 Detailed Design",      1, 4),
        ("P1a Foundational Tasks",  3, 6),
        ("P1b UDB→CIM POC",         5, 7),
        ("P2 MVP Build (FMS)",      6, 12),
        ("P2a MVP UAT & Approval",  12, 14),
        ("P3 Incremental Build",    14, 29),
        ("P3a Full UAT",            27, 30),
        ("P4 Cutover (staggered)",  29, 35),
        ("P5 Hypercare (overlapping)", 30, 36),
    ]
    phase_fill = PatternFill("solid", fgColor="2E75B6")
    for label, start, end in timeline:
        row = [label] + ["" for _ in months]
        ws.append(row)
        r = ws.max_row
        ws.cell(row=r, column=1).font = BODY_FONT
        for m in range(start, end + 1):
            cell = ws.cell(row=r, column=m + 1)
            cell.fill = phase_fill
        ws.row_dimensions[r].height = 18
    ws.column_dimensions["A"].width = 30
    for m in range(1, 43):
        ws.column_dimensions[get_column_letter(m + 1)].width = 4

    # Add legend
    ws.cell(row=ws.max_row + 2, column=1, value="Legend: each cell = 1 month; bars show likely-case schedule").font = Font(italic=True, size=10)

    # Sheet 3 — Milestones
    ws = wb.create_sheet("Milestones")
    headers = ["Milestone ID", "Milestone", "Phase", "Indicative Month", "Gate Owner", "Decision Criteria"]
    milestones = [
        ["M-01", "Phase 0 Audit Complete", "P0a", "M1", "Program Lead",
         "All-Green or Amber-with-remediation; no Reds outstanding"],
        ["M-02", "Detailed Design Approved", "P1", "M4", "Architecture Council",
         "All 6 cores have approved domain models, integration contracts, NFRs"],
        ["M-03", "Foundational Platform Live", "P1a", "M6", "Engineering Lead",
         "Dev/SIT envs operational; CI/CD green for skeleton; identity working"],
        ["M-04", "UDB→CIM POC Pass", "P1b", "M7", "Data Architecture",
         "Reconciliation report shows ≥99.9% row-level fidelity on FMS sample"],
        ["M-05", "MVP Feature-Complete (FMS)", "P2", "M12", "Engineering Lead",
         "All MVP user stories Done per DoD"],
        ["M-06", "MVP Operator Approval (HARD GATE)", "P2a", "M14", "District Operators",
         "Operator panel signs off; mental-model parity achieved; tangible new value validated"],
        ["M-07", "Incremental Build Mid-Point Review", "P3", "M22", "Program Lead",
         "50% of remaining cores feature-complete; no Red risks unmitigated"],
        ["M-08", "Full UAT Pass", "P3a", "M30", "Operations Lead",
         "All cross-app workflows tested; defect tail meets exit criteria"],
        ["M-09", "FMS Cutover Live", "P4", "M30", "Operations Lead + CIO",
         "Dress rehearsal #3 clean; rollback plan tested"],
        ["M-10", "All Cores Cut Over", "P4", "M35", "Operations Lead + CIO",
         "All 6 apps + monitors live; legacy retired"],
        ["M-11", "Hypercare Exit", "P5", "M36", "Service Owner",
         "Defect rate ≤ steady-state threshold for 30 consecutive days"],
    ]
    write_table(ws, headers, milestones)

    # Sheet 4 — Per-App Cutover Pattern
    ws = wb.create_sheet("Per-App Cutover Pattern")
    headers = ["Week (relative)", "Activity"]
    rows = [
        ["-4", "Cutover dress rehearsal #1 (full failover path, simulated load)"],
        ["-3", "Dry-run + go/no-go review"],
        ["-2", "Dress rehearsal #2 (issues from #1 fixed)"],
        ["-1", "Final go/no-go; freeze; rehearsal #3"],
        ["0",  "Cutover weekend"],
        ["+1", "Stabilization week (live with elevated on-call)"],
        ["+2 to +4", "Soak period; legacy hot-standby retained on OpNET"],
    ]
    write_table(ws, headers, rows)
    ws.cell(row=ws.max_row + 2, column=1,
            value="Cutover order: FMS → TOMS → DBM → DSO → SDS → TLS").font = Font(bold=True, color="1F3864")

    # Sheet 5 — Open Questions
    ws = wb.create_sheet("Open Questions")
    headers = ["#", "Question", "Owner", "Required By"]
    rows = [
        [1, "Confirm proposed first-MVP application: FMS", "Sponsor", "Pre-P1"],
        [2, "Confirm proposed incremental build sequence: TOMS → DBM → DSO → SDS → TLS", "Sponsor", "Pre-P3"],
        [3, "Confirm operator SME availability assumption (A-003): 4–8 hrs/wk per app + 1 dedicated UAT operator per app", "Operations Lead", "Pre-P1"],
        [4, "Confirm OpenRoad reader plan (A-002): identify internal candidate or contractor within 4 weeks of P1 start", "Program Lead", "Pre-P1"],
        [5, "Confirm 'tangible new value' features for MVP that go beyond parity", "Sponsor + Operations Lead", "Mid-P1"],
        [6, "Confirm regulatory/audit stakeholder attendance at M-06 and M-09", "Sponsor", "Pre-P2a"],
    ]
    write_table(ws, headers, rows)

    out_path = OUT / "02-milestone-phase-timeline.xlsx"
    wb.save(out_path)
    print(f"  wrote {out_path.name}")


# ---- 02: Milestone & Phase Timeline (docx narrative) -----------------------

def add_heading(doc, text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
    return h


def add_para(doc, text, bold=False, italic=False, size=11):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    return p


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = h
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            run.font.size = Pt(10)
        # blue header background via shading
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "1F3864")
        cell._tc.get_or_add_tcPr().append(shd)
    for r, row in enumerate(rows, 1):
        for c, val in enumerate(row):
            cell = table.rows[r].cells[c]
            cell.text = str(val)
            for run in cell.paragraphs[0].runs:
                run.font.size = Pt(9)
    if widths:
        for r in table.rows:
            for c, w in enumerate(widths):
                if c < len(r.cells):
                    r.cells[c].width = Inches(w)
    return table


def build_milestone_docx():
    doc = Document()

    # set default font
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # title
    title = doc.add_paragraph()
    run = title.add_run("Milestone & Phase Timeline")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
    sub = doc.add_paragraph()
    r2 = sub.add_run("Switching Order Modernization — Narrative & Brutal-Honesty Memo")
    r2.italic = True
    r2.font.size = Pt(13)
    r2.font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    add_para(doc, "Artifact ID: B1.2  |  Cutover strategy: Option A (staggered big-bang per app)  |  Indicative total: 30–42 months", italic=True, size=10)

    # Section 1
    add_heading(doc, "1. Indicative timeline at a glance", level=1)
    add_para(doc,
             "Cutover strategy is Option A — staggered big-bang per application. Indicative total program duration is 30–42 months from Phase 1 start to program-wide hypercare exit. There is no hard external deadline; internal milestone discipline must be manufactured by the program lead.")
    add_para(doc, "Best / Likely / Worst-case ranges below assume:", bold=True)
    for bullet in [
        "Internal team of 15–20 .NET/Angular engineers + 2–4 architects (per A-001)",
        "At least one OpenRoad reader available within 4 weeks of P1 start (per A-002)",
        "4–8 operator-hours/week per app + 1 dedicated UAT operator per app (per A-003)",
        "~150K switching cards/year aggregate, 7-year retention (per A-005)",
        "All Discovery audit dimensions return Green or Amber (no Reds requiring re-discovery)",
    ]:
        doc.add_paragraph(bullet, style="List Bullet")
    add_para(doc, "If any of those assumptions invalidate, the worst-case column becomes the likely column.", bold=True)

    add_table(doc,
              ["Phase", "Best", "Likely", "Worst", "Driver of variance"],
              [
                  ["P0a Phase 0 Audit", "3 days", "5 days", "10 days", "Operator availability for 4GL spot-reads"],
                  ["P1 Detailed Design", "3 mo", "4 mo", "5 mo", "Discovery audit RAG; integration contract gaps; SME engagement"],
                  ["P1a Foundational Tasks", "2 mo", "3 mo", "4 mo", "SecOps change-control; on-prem agent provisioning"],
                  ["P1b UDB→CIM POC", "1.5 mo", "2 mo", "3 mo", "UDB complexity; CIM coverage gaps; reconciliation tooling"],
                  ["P2 MVP Build (FMS)", "5 mo", "6.5 mo", "8 mo", "Operator SME depth; frontend complexity; EMS schema firmness"],
                  ["P2a MVP UAT & Approval", "1.5 mo", "2 mo", "3 mo", "Operator engagement; defect tail; mental-model parity"],
                  ["P3 Incremental Build", "12 mo", "15 mo", "20 mo", "Pattern reuse; integration count per app; hidden 4GL rules"],
                  ["P3a Full UAT", "2 mo", "3 mo", "4 mo", "Cross-app workflow density; regulatory audit prep"],
                  ["P4 Cutover (6 events, staggered)", "4 mo", "6 mo", "8 mo", "Per-app rehearsal cycles; rollback events; soak"],
                  ["P5 Hypercare (overlapping)", "3 mo", "4 mo", "6 mo", "Field defect volume; integration regression rate"],
              ],
              widths=[1.6, 0.6, 0.7, 0.7, 2.7])

    add_heading(doc, "Composite (with overlap)", level=2)
    add_table(doc, ["Composite", "Elapsed time"],
              [["Best case (all overlap, no surprises)", "~30 months"],
               ["Likely case", "~36 months"],
               ["Worst case (Reds, hidden rules, vendor delays)", "~42 months"]],
              widths=[3.5, 1.5])

    add_para(doc, "Sequencing notes (overlap):", bold=True)
    for bullet in [
        "P1a (Foundational Tasks) overlaps the back third of P1 (Detailed Design). Foundational work doesn't need final design — it needs target-architecture skeleton and identity model.",
        "P1b (UDB → CIM POC) overlaps the front of P2 (MVP Build). POC informs migration approach; MVP frontend can start before POC closes.",
        "P5 (Hypercare) starts per-app at each cutover event and runs in parallel with later cutovers.",
    ]:
        doc.add_paragraph(bullet, style="List Bullet")

    # Section 2 — Phase-by-phase
    doc.add_page_break()
    add_heading(doc, "2. Phase-by-phase detail", level=1)

    phases = [
        ("P0a — Phase 0 Discovery Audit (3–10 days)",
         "Stress-test Discovery outputs before Phase 1 design depends on them. See companion memo: 00-phase0-discovery-audit-memo.md.",
         [("Entry criteria", "Discovery package available; audit team identified."),
          ("Exit criteria", "RAG dashboard published; per-dimension decision recorded; Phase 1 plan adjusted for Amber dimensions or paused for Reds."),
          ("Drivers of variance", "Operator availability for 4GL spot-reads; severity of Reds requiring partial re-discovery.")]),
        ("P1 — Detailed Design (3–5 months)",
         "Convert Discovery outputs into design artifacts that estimation, build, and test can run against. Workstreams active: All. Heaviest in Architecture, Data, Integration.",
         [("Key outputs", "Domain models for all 6 cores; API contracts and event schemas; integration contracts for all 15–20 integrations (EMS/XA21 and Rapid Restore prioritized); NFR baseline; OpNET/DMZ/CorpNET boundary design; data migration approach (output of P1b POC feeds back); test strategy outline."),
          ("Drivers of variance", "Discovery audit RAG outcome; integration contract gaps (vendor-side delays); SME engagement depth — Operations + Security + Compliance must contribute, not observe."),
          ("Critical risk", "Architectural decisions made now without 4GL code triangulation will be re-litigated during Build. Don't over-design where Discovery is shaky.")]),
        ("P1a — Foundational Tasks (2–4 months, overlapping with late P1)",
         "Stand up the platform skeleton so Build can start without environment friction.",
         [("Scope", "Dev / SIT / Pre-Prod / Prod environment topology across OpNET / DMZ / CorpNET; on-prem Azure DevOps + Azure Repo; CI/CD pipeline skeleton; SAST integration; identity & authorization framework; SQL Server 2025 Enterprise skeleton with audit/temporal scaffolding and partitioning; native SQL Server message broker setup; Angular frontend skeleton + design-system foundation; .NET 8/9 backend skeleton with cross-cutting concerns; test platform (unit + contract + integration harnesses)."),
          ("Drivers of variance", "SecOps change-control cycle time for OpNET/DMZ network rules; on-prem Azure DevOps agent pool provisioning; identity vendor coordination."),
          ("Critical risk", "Underestimating network change-control latency. Plan for 2-week round-trip on every OpNET/DMZ rule change. Pre-stage approvals during P1.")]),
        ("P1b — UDB → CIM Migration POC (1.5–3 months, overlapping with early P2)",
         "Prove the data-model conversion approach before the migration scope is sized.",
         [("Why gated, not optional", "CIM is the target data model for utility hierarchy. UDB does not map cleanly to CIM. Without a POC, the migration estimate in B4 is fiction. With a POC, the team learns: which UDB constructs require custom CIM extensions; reconciliation tolerance for floating-point and date-time semantics; ETL throughput on production-volume samples; edge cases in feeder hierarchies that break naive mappings."),
          ("Scope", "Convert FMS feeder hierarchy from UDB to CIM (single app, full vertical slice); build reconciliation harness comparing source vs. target row-by-row; document type mapping spec; document custom CIM extensions required."),
          ("Exit criteria (M-04)", "Reconciliation report shows ≥99.9% row-level fidelity on FMS sample; type mapping spec covers all observed UDB types; throughput projection viable for full data volume."),
          ("Drivers of variance", "UDB schema complexity (especially DSO and SDS); CIM 17 coverage of dielectric and steam constructs; reconciliation tooling maturity.")]),
        ("P2 — MVP Build (5–8 months)",
         "Deliver the first vertical slice — FMS — to operator-facing UAT.",
         [("Why FMS first", "Highest operational volume of the 6 cores → richest test of workflow patterns; mature internal documentation; patterns reused for TOMS, DSO, TLS, SDS, DBM; operator pool is largest, supporting parallel UAT cohorts."),
          ("MVP scope (vertical slices)", "Notify → Create Card → De-energize → Authorize → Execute → Test → Re-energize → Close. Each slice goes through frontend + backend + DB + integration. Each is independently demo-able. None is 'done' until operator-validated."),
          ("Drivers of variance", "Operator SME engagement depth; frontend complexity; EMS/XA21 event-schema firmness; hidden business rules surfacing during build."),
          ("Critical risk", "Compromising on operator mental-model parity to hit a date. M-06 won't pass; you'll lose 2 months and credibility recovering.")]),
        ("P2a — MVP UAT & Approval (1.5–3 months) — HARDEST GATE",
         "Operator panel signs off that FMS modernization preserves their workflow and adds tangible value.",
         [("Why hardest gate", "Three non-negotiables: feature parity, tangible new value, MVP approval. Operators are deeply satisfied with current workflow → high parity bar. 'Tangible new value' must be demonstrable in MVP, not promised for Phase 3. Failure here means scope expansion stops."),
          ("Activities", "Operator-in-the-loop UAT cycles (2-week iterations); mental-model audit (do screen flows match operator expectations without re-training?); defect triage with operator-facing severity (operator confusion is severity 1); tangible-value demo (concrete features beyond parity, defined in P1); sign-off panel (operators per district + Operations Lead + Sponsor)."),
          ("Drivers of variance", "Operator engagement depth; defect volume from hidden rules; mental-model gaps surfaced in UAT (each gap is a re-design, not a tweak)."),
          ("Decision criteria (M-06)", "Operator panel signs off (consensus required); all severity-1 defects closed; tangible new-value features demonstrated and operator-validated; audit trail completeness verified by Compliance.")]),
        ("P3 — Incremental Build (12–20 months)",
         "Deliver remaining 5 core applications (TOMS, DSO, TLS, SDS, DBM) plus the 30–35 monitor applications.",
         [("Sequencing", "1) TOMS (highest pattern reuse from FMS); 2) DBM (foundational data model); 3) DSO (dielectric); 4) SDS (steam, high uniqueness); 5) TLS (telephonic line, narrowest scope). Monitors are built alongside their parent app."),
          ("Drivers of variance (most sensitive phase)", "Pattern reuse rate (best 60–70%, worst 30%); hidden 4GL rules per app; integration count per app; cross-app dependencies; team velocity stability after MVP."),
          ("Critical risk", "MVP velocity is not a stable predictor for incremental velocity. Operators are bought-in by M-06; they expect the rest to be fast. Manage that expectation explicitly with the M-07 mid-point review.")]),
        ("P3a — Full UAT (2–4 months)",
         "Validate cross-app workflows that don't exist within a single core.",
         [("Scope", "Cross-app workflows (e.g., transmission outage cascading into distribution feeder management — TOMS + FMS); cross-system regression with all integrations; performance under combined load; disaster-recovery / islanding drill on standby OpNET; regulatory audit dry-run."),
          ("Drivers of variance", "Cross-app workflow density; regulator engagement timing.")]),
        ("P4 — Cutover (4–8 months total, 6 staggered events)",
         "Migrate each application to production sequentially per Option A.",
         [("Per-app pattern", "W-4: dress rehearsal #1 (full failover, simulated load). W-3: dry-run + go/no-go. W-2: dress rehearsal #2 (issues fixed). W-1: final go/no-go; freeze; rehearsal #3. W0: cutover weekend. W+1: stabilization (elevated on-call). W+2 to W+4: soak; legacy hot-standby retained on OpNET."),
          ("Cutover order", "FMS → TOMS → DBM → DSO → SDS → TLS."),
          ("Drivers of variance", "Rehearsal cycle results; soak duration before next cutover (4 weeks minimum); defect volume in early cutovers."),
          ("Critical risk", "Compressing soak period between cutovers because earlier cutovers went well. Staggering exists to absorb surprises; eliminating soak eliminates the safety margin.")]),
        ("P5 — Hypercare (3–6 months, overlapping)",
         "Heightened-support window per app + program-wide.",
         [("Per-app", "Starts at each app's cutover, runs 4–8 weeks."),
          ("Program-wide", "Starts at last cutover, runs 3 months."),
          ("Exit criteria (M-11)", "Defect rate ≤ steady-state threshold for 30 consecutive days; all P1 severity defects closed; Operations team formally accepts service ownership.")]),
    ]
    for title, summary, fields in phases:
        add_heading(doc, title, level=2)
        add_para(doc, summary)
        for k, v in fields:
            p = doc.add_paragraph()
            r = p.add_run(f"{k}: ")
            r.bold = True
            p.add_run(v)

    # Section 3 — Brutal-Honesty Memo
    doc.add_page_break()
    add_heading(doc, "3. Brutal-honesty memo — where these estimates are most likely to be wrong", level=1)

    add_heading(doc, "Most-likely overrun zones, ranked", level=2)
    overruns = [
        ("Incremental Build (P3)", "Largest hours; broadest scope; highest exposure to hidden 4GL rules. Single biggest single risk to the program's likely-case duration. Pattern reuse rate from MVP is overestimated by every team that's done this. Plan for 30% reuse, not 60%."),
        ("MVP UAT (P2a)", "Operator validation is process-heavy. Defect tail is long. Mental-model gaps surface late. If MVP UAT slips past 3 months, the program has an operator-engagement problem, not an engineering problem."),
        ("Cutover (P4)", "Rehearsal cycles compound. Each rehearsal that fails resets a 4-week window. Six cutovers means six chances to consume budget."),
        ("Foundational (P1a)", "Network change-control is the silent killer. SecOps round-trip dominates. Plan 2-week SLA per network rule change."),
        ("POC (P1b)", "Reconciliation harness scope is consistently underestimated. Building the diff tool is half the POC."),
    ]
    for i, (title, body) in enumerate(overruns, 1):
        p = doc.add_paragraph()
        r = p.add_run(f"{i}. {title}. ")
        r.bold = True
        p.add_run(body)

    add_heading(doc, "Why these estimates cannot be tighter than ranges", level=2)
    for bullet in [
        "We have no body-of-work history for this team on this stack",
        "Discovery shakiness (pending P0a outcome) feeds straight into estimate confidence",
        "4GL hidden rules are unknowable until measured",
        "Vendor coordination (EMS/XA21) is not under direct program control",
        "Operator availability is forecast, not contracted",
    ]:
        doc.add_paragraph(bullet, style="List Bullet")
    add_para(doc, "Anyone giving you a single-point estimate at this stage is selling, not estimating.", bold=True)

    add_heading(doc, "What reduces variance", level=2)
    add_para(doc, "In priority order:")
    reducers = [
        "Run the Phase 0 audit. Largest single variance reducer.",
        "Lock cutover decision (Option A) and don't relitigate. Re-baselining late is expensive.",
        "Identify the OpenRoad reader within 4 weeks of P1 start. Without one, every estimate has a phantom +20%.",
        "Pre-stage SecOps approvals during P1. Saves 4–8 weeks across P1a/P1b.",
        "Dedicate operator SMEs for MVP UAT, not borrow them. Halves UAT cycle count.",
        "Anchor sponsor on a dollar-and-time range from B4 estimation worksheet, treating worst-case as the working-case until proven otherwise.",
    ]
    for i, item in enumerate(reducers, 1):
        doc.add_paragraph(f"{i}. {item}", style="List Number")

    add_heading(doc, "Where I will refuse to pad", level=2)
    for bullet in [
        "Per-app cutover soak period (4 weeks minimum). Compressing this is the cheapest decision and the most expensive consequence.",
        "Phase 0 audit duration (3 days). One day is theater.",
        "Operator SME hours per week (4 hrs minimum). Less, and MVP UAT cycle count doubles.",
        "Number of dress rehearsals per cutover (3 minimum). Two means an unrehearsed failure mode goes to production.",
    ]:
        doc.add_paragraph(bullet, style="List Bullet")

    add_heading(doc, "Where I am willing to compress (with named trade-offs)", level=2)
    compressions = [
        ("Detailed Design (P1)", "Compress from 4 to 3 months by deferring NFR baselining to early P2.", "NFRs surface as defects, not requirements."),
        ("Foundational Tasks (P1a)", "Compress by 1 month by reusing an existing internal CI/CD template (if one exists).", "Locks you into prior tooling decisions."),
        ("Hypercare (P5) program-wide", "Compress from 4 to 3 months if defect rate trends consistently below threshold.", "Less buffer for late-surfacing regressions."),
    ]
    for title, body, trade in compressions:
        p = doc.add_paragraph()
        r = p.add_run(f"{title}: ")
        r.bold = True
        p.add_run(body + " ")
        r2 = p.add_run("Trade-off: ")
        r2.italic = True
        p.add_run(trade)

    # Section 4 — Open Questions
    doc.add_page_break()
    add_heading(doc, "4. Open questions for sponsor before B1 ratification", level=1)
    add_para(doc, "These do not block production of B1; they block commitment to B1 numbers.")
    questions = [
        "Confirm proposed first-MVP application: FMS.",
        "Confirm proposed incremental build sequence: TOMS → DBM → DSO → SDS → TLS.",
        "Confirm operator SME availability assumption (A-003): 4–8 hrs/wk per app + 1 dedicated UAT operator per app.",
        "Confirm OpenRoad reader plan (A-002): identify internal candidate or contractor within 4 weeks of P1 start.",
        "Confirm 'tangible new value' features for MVP that go beyond parity. (This must be defined in P1; without it, M-06 has no demonstrable criterion for value.)",
        "Confirm regulatory/audit stakeholder attendance at M-06 and M-09.",
    ]
    for i, q in enumerate(questions, 1):
        doc.add_paragraph(f"{i}. {q}", style="List Number")

    out_path = OUT / "02-milestone-phase-timeline.docx"
    doc.save(out_path)
    print(f"  wrote {out_path.name}")


# ---- main ------------------------------------------------------------------

if __name__ == "__main__":
    print("Generating B1 deliverables...")
    build_master_plan()
    build_milestone_xlsx()
    build_milestone_docx()
    print("Done.")
