# Master Project Plan Template — Switching Order Modernization

**Artifact ID:** B1.1
**Format:** This file is the source-of-truth specification. The companion `.xlsx` is generated from it.
**Purpose:** Skeleton the delivery PMO uses to track every line of work across the program. Not a populated plan — a populated *template* with example rows that demonstrate intended use.

---

## Workbook structure

The generated `.xlsx` has 10 sheets:

| # | Sheet | Purpose |
|---|---|---|
| 1 | Cover & Legend | Document control, RAG legend, status legend, governance contacts |
| 2 | Phases | Top-level phase rollup (start/end/gate-status) |
| 3 | Workstreams | Cross-cutting workstreams (Architecture, Backend, Frontend, Data, Integration, DevOps, QA, Security, Operations, Change Mgmt) |
| 4 | Master Schedule | The line-item plan — every WBS task |
| 5 | Milestones & Gates | Named milestones + gate criteria + decision date + decision owner |
| 6 | RACI | Roles × Workstreams matrix |
| 7 | Risk Register | Risk ID, description, probability, impact, mitigation, owner |
| 8 | Assumption Log | Assumption ID, description, validation date, owner, status |
| 9 | Issue Log | Active impediments, owner, target resolution date |
| 10 | Decision Log | Material decisions, decision-maker, date, rationale |

The Master Schedule is the central sheet. Every row links by ID to one or more entries in Risk, Assumption, Issue, and Decision logs.

---

## Sheet 1 — Cover & Legend

| Field | Value |
|---|---|
| Program | Switching Order Modernization |
| Document | Master Project Plan |
| Version | 0.1 (template) |
| Owner | Program Lead |
| Last Updated | (date) |
| Sponsor | (name) |
| Steering Committee | (names) |

**RAG legend:**

| Color | Meaning |
|---|---|
| Green | On plan; no intervention required |
| Amber | At risk; mitigation in progress; recoverable within 1–2 sprints |
| Red | Off plan; escalation required; not recoverable without sponsor decision |

**Status legend:**

| Status | Meaning |
|---|---|
| Not Started | Work has not begun |
| In Progress | Active work |
| Blocked | Waiting on external dependency |
| In Review | Work submitted; awaiting acceptance |
| Done | Accepted and closed |
| Cancelled | Out of scope; documented why |

---

## Sheet 2 — Phases

| Phase ID | Phase | Start | End | Gate Owner | Gate Status | Notes |
|---|---|---|---|---|---|---|
| P0 | Discovery | (done) | (done) | Sponsor | Closed | 600+ features, 650+ FRs, 1000+ rules captured |
| P0a | Phase 0 Audit | TBD | TBD | Program Lead | Pending | 3-day audit of Discovery outputs |
| P1 | Detailed Design | TBD | TBD | Architecture Council | Pending | Drives all build estimates |
| P1a | Foundational Tasks | TBD | TBD | Engineering Lead | Pending | Env, skeletons, auth, CI/CD, broker |
| P1b | UDB → CIM POC | TBD | TBD | Data Architecture | Pending | Gates the data migration approach |
| P2 | MVP Build (FMS) | TBD | TBD | Operations Lead | Pending | Operator-facing first slice |
| P2a | MVP UAT & Approval | TBD | TBD | District Operators | Pending | **Hard gate** — operator sign-off required |
| P3 | Incremental Build | TBD | TBD | Program Lead | Pending | Remaining 5 cores + monitors |
| P3a | Full UAT | TBD | TBD | Operations Lead | Pending | Cross-app workflows |
| P4 | Cutover (staggered per app) | TBD | TBD | Operations Lead + CIO | Pending | Option A — staggered big-bang per app |
| P5 | Hypercare | TBD | TBD | Service Owner | Pending | Per-app hypercare + program-wide |

---

## Sheet 3 — Workstreams

| WS ID | Workstream | Lead Role | Active In Phases | Notes |
|---|---|---|---|---|
| WS-ARC | Architecture | Solution Architect | All | Owns boundary integrity (OpNET/DMZ/CorpNET), tech-debt budget |
| WS-BE | Backend (.NET) | Backend Lead | P1a–P5 | Domain services, message broker integration |
| WS-FE | Frontend (Angular) | Frontend Lead | P1a–P5 | Operator console, monitor apps |
| WS-DATA | Data & DB | Data Architect | P1b–P5 | Ingres → SQL migration, partitioning, audit/temporal |
| WS-INT | Integration | Integration Lead | P1–P5 | EMS/XA21, Rapid Restore, GIS, FeederBoard, CPMS |
| WS-DO | DevOps / Infra | DevOps Lead | All | Azure DevOps on-prem, IIS, environment topology, secrets |
| WS-QA | Quality Engineering | Test Lead | All | Unit, contract, integration, performance, security, UAT |
| WS-SEC | Security & Compliance | Security Lead | All | Identity, audit, regulatory traceability, CodeQL |
| WS-OPS | Operations Readiness | Service Manager | P2–P5 | Runbooks, on-call, SRE patterns, cutover playbooks |
| WS-CHM | Change Management | Change Lead | P2–P5 | Operator engagement, training, comms, adoption metrics |

---

## Sheet 4 — Master Schedule (template with example rows)

Columns:

| Column | Description | Example |
|---|---|---|
| WBS | Hierarchical ID | 2.1.3 |
| Phase ID | Links to Phases sheet | P2 |
| Workstream | Links to Workstreams sheet | WS-FE |
| Task | Imperative description | Build FMS switching card creation screen |
| Description | One-paragraph context | Operator-facing form for new switching cards triggered by EMS event |
| Owner | Single accountable person | (name) |
| Start | Planned start date | 2026-09-01 |
| End | Planned end date | 2026-10-15 |
| Duration (days) | Working days | 32 |
| Predecessors | WBS IDs of upstream tasks | 2.1.1, 1.4.7 |
| % Complete | Numeric | 0–100 |
| Status | From legend | In Progress |
| RAG | From legend | Green |
| Risk Refs | IDs from Risk Register | R-014 |
| Assumption Refs | IDs from Assumption Log | A-008 |
| Issue Refs | IDs from Issue Log | I-003 |
| Decision Refs | IDs from Decision Log | D-005 |
| Notes | Free text | Awaiting operator validation of field labels |

**Example rows demonstrating use:**

1. **Foundational task example** — `WBS 1.1.1` · P1a · WS-DO · "Establish Azure DevOps pipelines with on-prem agents" · 30 days · Risk: agent-pool capacity · Assumption: SecOps approves on-prem agents within 2 weeks.
2. **MVP epic example** — `WBS 2.1.0` · P2 · WS-FE+WS-BE · "FMS — Create switching card from EMS event" · 60 days · Predecessors: P1a foundational complete · Risk: EMS event schema unconfirmed · Assumption: vendor provides sample payloads.
3. **POC task example** — `WBS 1.3.5` · P1b · WS-DATA · "Convert FMS feeder hierarchy from UDB to CIM" · 25 days · Risk: CIM coverage gaps in DSO · Assumption: CIM 17 sufficient.
4. **Cutover task example** — `WBS 4.1.7` · P4 · WS-OPS · "FMS dress rehearsal #2 — full failover path" · 5 days · Predecessors: dress rehearsal #1 closed · RAG status updated daily during rehearsal week.
5. **Audit-prep task example** — `WBS 5.2.3` · P5 · WS-SEC · "Regulatory audit dry-run for switching action traceability" · 10 days · Owner: Security Lead · Decision Ref: D-Aud-001 (retention horizon).

These five rows are pre-populated in the template so a new PMO can copy the pattern.

---

## Sheet 5 — Milestones & Gates

Columns: Milestone ID · Name · Phase · Date · Gate Owner · Decision Criteria · Decision · Decision Date · Notes

**Pre-populated milestones (template):**

| ID | Milestone | Phase | Gate Owner | Decision Criteria |
|---|---|---|---|---|
| M-01 | Phase 0 Audit Complete | P0a | Program Lead | All-Green or Amber-with-remediation; no Reds outstanding |
| M-02 | Detailed Design Approved | P1 | Architecture Council | All 6 cores have approved domain models, integration contracts, NFRs |
| M-03 | Foundational Platform Live | P1a | Engineering Lead | Dev/SIT envs operational; CI/CD green for skeleton; identity working |
| M-04 | UDB→CIM POC Pass | P1b | Data Architecture | Reconciliation report shows ≥99.9% row-level fidelity on FMS sample |
| M-05 | MVP Feature-Complete (FMS) | P2 | Engineering Lead | All MVP user stories Done per DoD |
| M-06 | **MVP Operator Approval** | P2a | District Operators | Operator panel signs off; mental-model parity achieved |
| M-07 | Incremental Build Mid-Point Review | P3 | Program Lead | 50% of remaining cores feature-complete; no Red risks unmitigated |
| M-08 | Full UAT Pass | P3a | Operations Lead | All cross-app workflows tested; defect tail meets exit criteria |
| M-09 | FMS Cutover Live | P4 | Operations Lead + CIO | Dress rehearsal #3 clean; rollback plan tested |
| M-10 | All Cores Cut Over | P4 | Operations Lead + CIO | All 6 apps + monitors live; legacy retired |
| M-11 | Hypercare Exit | P5 | Service Owner | Defect rate ≤ steady-state threshold for 30 consecutive days |

**M-06 is the program's hardest gate.** No incremental scope expansion happens without it.

---

## Sheet 6 — RACI

Roles (rows): Program Lead, Solution Architect, Backend Lead, Frontend Lead, Data Architect, Integration Lead, DevOps Lead, Test Lead, Security Lead, Service Manager, Change Lead, Sponsor, District Operators

Workstreams (columns): WS-ARC, WS-BE, WS-FE, WS-DATA, WS-INT, WS-DO, WS-QA, WS-SEC, WS-OPS, WS-CHM

Cells: R / A / C / I (Responsible / Accountable / Consulted / Informed). Each workstream has exactly one A.

Sample (excerpt):

| Role | WS-ARC | WS-BE | WS-FE | WS-DATA | WS-INT | WS-DO | WS-QA | WS-SEC | WS-OPS | WS-CHM |
|---|---|---|---|---|---|---|---|---|---|---|
| Program Lead | C | I | I | I | I | I | I | I | C | C |
| Solution Architect | A | C | C | C | C | C | C | C | C | I |
| Backend Lead | C | A | C | C | R | C | C | C | I | I |
| Frontend Lead | C | C | A | I | I | C | C | C | I | C |
| Data Architect | C | C | I | A | C | C | C | C | I | I |
| Integration Lead | C | R | I | C | A | C | C | C | C | I |
| DevOps Lead | C | C | C | C | C | A | C | C | R | I |
| Test Lead | C | C | C | C | C | C | A | C | C | I |
| Security Lead | C | C | C | C | C | C | C | A | C | I |
| Service Manager | I | I | I | I | I | C | C | C | A | C |
| Change Lead | I | I | C | I | I | I | I | I | C | A |
| Sponsor | I | I | I | I | I | I | I | I | I | I |
| District Operators | C | I | C | I | I | I | C | I | C | R |

---

## Sheet 7 — Risk Register

Columns: Risk ID · Description · Category · Probability (1–5) · Impact (1–5) · Score · Mitigation · Contingency · Owner · Status · Last Reviewed

**Pre-populated risks (template — these are the ones I'd start with):**

| ID | Description | Category | Prob | Impact | Score | Mitigation | Owner |
|---|---|---|---|---|---|---|---|
| R-001 | Hidden business rules in OpenRoad code surface during build, inflating Incremental Build estimates | Scope | 5 | 5 | 25 | Phase 0 audit dim 3 + 10; budget remediation in Discovery | Solution Architect |
| R-002 | EMS/XA21 integration regression during MVP UAT or cutover | Integration | 4 | 5 | 20 | Contract tests; vendor co-design; canary tests on dress rehearsal | Integration Lead |
| R-003 | Operator change-management resistance delays MVP approval (M-06) | Change | 3 | 5 | 15 | Operator embed during MVP build; mental-model audit; co-design sessions | Change Lead |
| R-004 | Audit-trail gaps during per-app cutover (Option A) | Compliance | 3 | 5 | 15 | Bidirectional audit replication during soak; reconciliation tooling | Security Lead |
| R-005 | OpenRoad-experienced engineer shortage limits 4GL reads | Resource | 5 | 4 | 20 | Identify reader role early; consider short-term contractor | Program Lead |
| R-006 | Ingres-to-SQL semantic mismatches (NULL handling, date semantics, numeric precision) | Data | 4 | 4 | 16 | UDB→CIM POC + reconciliation harness; type-mapping spec | Data Architect |
| R-007 | OpNET / DMZ / CorpNET network change-control velocity bottlenecks env builds | Infra | 4 | 3 | 12 | Engage SecOps on the network design memo (B5) early; pre-stage approvals | DevOps Lead |
| R-008 | "Flexible" budget gets capped mid-program, forcing scope reduction post-M-06 | Governance | 3 | 4 | 12 | Anchor sponsor on B4 estimation worksheet; phase-gated funding | Program Lead |
| R-009 | Standby OpNET environment drift from CorpNET primary | Operations | 3 | 4 | 12 | Automated drift detection; weekly sync; islanding drills | Service Manager |
| R-010 | Cutover dress rehearsal cycle insufficient for Option A's 6 cutover events | Cutover | 3 | 5 | 15 | Minimum 3 dress rehearsals per app; shared rehearsal infra | Operations Lead |

---

## Sheet 8 — Assumption Log

Columns: Assumption ID · Description · Phase · Validation Approach · Validation Date · Owner · Status (Open / Validated / Invalidated)

**Pre-populated (the explicit ones from this engagement):**

| ID | Description | Validation Approach | Owner |
|---|---|---|---|
| A-001 | Internal .NET/Angular team has 15–20 engineers available for ramp by P1a start | HR + resource manager confirm bench | Program Lead |
| A-002 | At least one engineer can read OpenRoad code; otherwise contractor identified within 4 weeks of P1 start | Skill audit; contractor shortlist | Program Lead |
| A-003 | Operator SMEs available 4–8 hrs/week per app for design + 1 dedicated per app for UAT | Schedule confirmation by Operations Lead | Operations Lead |
| A-004 | EMS/XA21 vendor provides sample event payloads + integration test harness | Vendor engagement; SoW addendum if required | Integration Lead |
| A-005 | Switching card volume ~150K/year aggregate; 7-year retention; standard regulator query patterns | Data profiling on Ingres production sample | Data Architect |
| A-006 | Cutover Option A approved (staggered big-bang per app) | Sponsor + CIO sign-off | Program Lead |
| A-007 | OpNET standby is in scope and will be provisioned for cutover hypercare | Infra design memo (B5); SecOps approval | DevOps Lead |
| A-008 | CIM 17 covers FMS, TOMS, DSO, SDS, TLS feeder hierarchy with ≤5% custom extensions | UDB→CIM POC | Data Architect |
| A-009 | "Flexible" budget translates to a sponsor-approvable range derived from B4 | Estimation worksheet review with sponsor | Program Lead |
| A-010 | Indicative target is 30–42 months total program duration | Confirmed in B1 milestone timeline | Program Lead |

---

## Sheet 9 — Issue Log

Columns: Issue ID · Description · Raised Date · Owner · Target Resolution · Status (Open / In Progress / Resolved / Escalated) · Resolution Notes

(Empty in template — populated as program runs.)

---

## Sheet 10 — Decision Log

Columns: Decision ID · Title · Phase · Decision · Rationale · Decided By · Decision Date · Reversibility (Reversible / Hard-to-Reverse / Irreversible) · Notes

**Pre-populated (decisions already made by sponsor in this engagement):**

| ID | Title | Decision | Rationale | Decided By | Reversibility |
|---|---|---|---|---|---|
| D-001 | Cutover strategy | Option A — staggered big-bang per application | Lower blast radius; +3–4 months program length acceptable given no hard deadline | Sponsor + CIO | Hard-to-reverse |
| D-002 | Phase 0 audit | Approved 3-day audit before Phase 1 | Avoid baseline-shakiness propagating into estimates | Sponsor | Reversible |
| D-003 | Target hosting | On-prem IIS (no cloud) | Aligned with OT/IT segmentation policy | CIO | Hard-to-reverse |
| D-004 | Source control + CI/CD | On-prem Azure Repo + Azure DevOps | Aligned with on-prem strategy and compliance posture | CIO | Reversible |
| D-005 | First MVP application | FMS (proposed; pending sponsor confirm) | Highest operational volume; richest workflow patterns; reusable patterns for remaining 5 cores | Pending | Reversible |

---

## Notes for the PMO using this template

1. **Master Schedule is the single source of truth.** Do not maintain parallel plans in Project, Smartsheet, or Jira and let them drift.
2. **One owner per row.** Multiple owners means no owner. If a task needs three people, split it into three rows.
3. **Update RAG weekly, not at gate-time.** The point of RAG is early signal, not retroactive blame.
4. **Risks and assumptions feed estimates.** When a risk is realized or an assumption invalidated, the corresponding schedule rows must be re-baselined and the change logged in Decision Log.
5. **MVP Operator Approval (M-06) is the hardest gate.** Treat any pressure to soften its criteria as a Red risk in itself.
