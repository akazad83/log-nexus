# User Story Template (with INVEST checklist)

**Use:** Every User Story populates this template. DoR (in [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §8) is enforced against it.

---

## Story header

| Field | Value |
|---|---|
| **Story ID** | (e.g., `FMS-S-104`) |
| **Title** | (verb-led; one short line) |
| **Epic** | (link to Epic ID) |
| **Bounded service** | FMS / TOMS / DSO / TLS / SDS / DBM / Messaging / Task Manager / Integration |
| **Workflow step** | Notify / Create / De-energize / Authorize / Execute / Test / Re-energize / Close / cross-cutting |
| **Parity / New-Value** | one only |
| **Story points** | Fibonacci (1, 2, 3, 5, 8) — if 13+, split it |
| **Sprint target** | (sprint #) |
| **Operator SME** | (name) |
| **Status** | Backlog / Refining / Ready / In Sprint / In Progress / In Review / In Test / Operator Review / Done / Cancelled |

---

## Story statement

> **As a** [role]
> **I want to** [capability]
> **So that** [outcome that matters to the role]

Avoid system language. "As a system, I want to send a message" is not a user story. The role is human or, in rare cases, an external system acting on behalf of a human.

---

## Description

One short paragraph elaborating the story. Include the "why" in operator-meaningful terms.

---

## Acceptance Criteria

Link or embed. Use [08-acceptance-criteria-template.md](08-acceptance-criteria-template.md). At minimum:

- [ ] Happy path AC
- [ ] Error path AC (one or more)
- [ ] Authorization AC if applicable
- [ ] **Audit trail AC if a state changes — non-negotiable**
- [ ] Integration AC if a system boundary is crossed
- [ ] Resilience AC if external dependency exists
- [ ] Operator visibility AC for operator-facing changes
- [ ] NFR addendum present (always)

---

## Vertical slice anatomy

Confirm this story is a vertical slice. Tick all that apply; cross out (~~strikethrough~~) those genuinely not applicable.

- [ ] Frontend (Angular)
- [ ] BFF endpoint
- [ ] Service domain logic
- [ ] DB persistence + temporal
- [ ] Audit trail emission
- [ ] Integration call
- [ ] Telemetry instrumentation
- [ ] NFR validation
- [ ] Operator demo path

If only 1–2 boxes are ticked, this is probably a horizontal slice. Reconsider.

---

## INVEST checklist

INVEST is the gate for "is this a real story?". Every box must be tick-able before DoR.

| Letter | Meaning | Pass criterion | Result |
|---|---|---|---|
| **I**ndependent | Story can be developed and shipped without depending on stories not yet started | No upstream story is blocking this one in this sprint | ☐ |
| **N**egotiable | Scope can be adjusted up or down through conversation with PO | The story is not so prescriptive that it locks implementation choices | ☐ |
| **V**aluable | Story delivers a measurable outcome a user (operator) would notice | Operator could describe why this matters | ☐ |
| **E**stimable | Team can size it confidently | No unresolved spike; team agrees on points within a factor of 2 | ☐ |
| **S**mall | Fits in one sprint comfortably (≤8 points) | If 13+, split before entering sprint | ☐ |
| **T**estable | Pass/fail is unambiguous from ACs | A tester can write the test cases from the ACs without guessing | ☐ |

If any letter fails: stay in Refining; do not move to Ready.

---

## Integration touch-points

| External system | Direction | Contract | Mock available? |
|---|---|---|---|
| | (we → them / they → us) | (REST / async / SOAP / polling endpoint) | (Yes / No / partial) |

---

## Dependencies

| Type | Reference | Notes |
|---|---|---|
| Upstream story | (story ID) | Must be Done before this story can complete |
| Foundational task | (e.g., audit framework, identity flow) | From P1a |
| Spike | (spike ID) | Must close before refinement complete |
| External | (e.g., EMS schema sample) | Vendor / SME |
| NFR | (NFR ID from [11-nfr-template.md](11-nfr-template.md)) | Cross-cutting NFR applies |

---

## Risks specific to this story

| Risk | Mitigation |
|---|---|
| | |

(Most stories have none beyond the program-level Risk Register. Capture only story-specific risks.)

---

## Test ownership

| Test type | Owner | Notes |
|---|---|---|
| Unit | Engineer | Coverage target per service |
| Contract | Engineer + Test Lead | Both consumer + producer |
| Integration | Test engineer | Against SIT |
| E2E | Test engineer | Against Pre-Prod |
| Operator validation | Operator SME | Demo at sprint review |

---

## Regulatory / audit tagging

If any AC is tagged `[REG]`:

| `[REG]` AC | Citation | Compliance reviewer |
|---|---|---|
| | | |

---

## Worked example

```
Story ID:        FMS-S-104
Title:           Operator review pane for auto-created switching card (parity-matched layout)
Epic:            FMS-E-014
Bounded service: FMS
Workflow step:   Create
Parity / New-Value: Parity
Story points:    5
Sprint target:   P2 / Sprint 7
Operator SME:    R. Chen
Status:          Ready

Story statement:
  As a District Operator,
  I want to see a review pane for an auto-created switching card with the same
  field layout, ordering, and visual hierarchy as the legacy system,
  So that I can verify and adjust the card without re-learning the workflow.

Description:
  When FMS auto-creates a switching card from an EMS event, the operator must
  see a review pane that matches legacy layout. Fields are pre-populated from
  feeder context. Operator can edit and confirm before the card moves to
  De-energize phase. This story is parity-only — visual topology preview
  (FMS-S-141) is a separate new-value story.

Acceptance Criteria: [link to AC-104 file]

Vertical slice anatomy:
  ✅ Frontend (Angular) — review pane component + state
  ✅ BFF endpoint — GET card-with-context, PATCH card edits
  ✅ Service domain logic — pre-population rules + edit validation
  ✅ DB persistence + temporal — temporal table on Card entity captures edits
  ✅ Audit trail emission — operator action log on every edit
  ✅ Telemetry instrumentation
  ✅ NFR validation — review pane render p99 < 800ms
  ✅ Operator demo path
  ~~Integration call~~ (no external system boundary in this story)

INVEST:
  ✅ Independent (FMS-S-103 must be Done; that is upstream and is Done)
  ✅ Negotiable (field layout details negotiable; visual parity goal fixed)
  ✅ Valuable (operator workflow visibility)
  ✅ Estimable (no open spike)
  ✅ Small (5 points)
  ✅ Testable (parity test harness compares legacy capture vs new pane)

Integration touch-points: none

Dependencies:
  Upstream story | FMS-S-103 — Pre-populate feeder context | Done
  Foundational   | Audit framework live (P1a)              | Done

Test ownership:
  Unit              | Engineer
  Contract          | Engineer + Test Lead (BFF)
  Integration       | Test engineer
  E2E               | Test engineer
  Operator parity   | R. Chen sign-off at sprint demo

Regulatory: none for this story
```

---

## Checklist before this story enters Ready

Same as DoR in [05-backlog-pipeline-guide.md](05-backlog-pipeline-guide.md) §8 — tick every applicable box.
