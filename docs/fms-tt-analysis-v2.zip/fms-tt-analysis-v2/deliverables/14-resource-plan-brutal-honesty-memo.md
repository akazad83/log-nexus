# Brutal-Honesty Memo — Where the Resource Plan & Estimates Are Most Likely Wrong

**Artifact ID:** B4.5 (companion)
**Status:** Draft for sponsor review — read this before signing off on B1/B4 numbers
**Audience:** Sponsor, Steering Committee, Program Lead
**Pairs with:** [13-resource-plan.md](13-resource-plan.md), [15-estimation-worksheet.md](15-estimation-worksheet.md)

This memo exists because every modernization plan I have ever seen — including ones I have written — under-estimates the same kinds of things in the same kinds of ways. The numbers in `13-resource-plan.xlsx` and `15-estimation-worksheet.xlsx` are defensible. They are not safe. The difference matters.

If you read only one section of this memo, read **§1 (the four predictable failure modes)** and **§9 (the five things that, if changed, would make these numbers more reliable)**.

---

## 1. The four predictable failure modes

In rough order of how often they materialize and how much they hurt:

### 1.1 Hidden 4GL business rules (the most expensive one)

Discovery captured 1,000+ rules. The OpenRoad codebase contains more rules than any analyst can capture from operator interviews alone, because:

- Operators have internalized rules to muscle memory and don't articulate them when asked
- 4GL code expresses rules as imperative side effects, not declarative statements
- Edge-case rules surface only when developers attempt to encode them

**Expected magnitude:** 200–400 additional rules across the 6 cores beyond the 1,000+ Discovery captured. **Most will surface in P3 (Incremental Build), not P2 (MVP).** This is precisely why MVP is FMS-only — to absorb the first wave before scaling. Even with that, P3 is exposed.

**Why MVP doesn't fully insulate us:** FMS is the highest-volume application. TOMS, DSO, SDS, TLS, DBM each have their own hidden-rule profiles. Pattern-matching from FMS does not eliminate the rules in the other 5 cores — it only accelerates capturing them once they're seen.

**Cost if realized:** The P3 (Incremental Build) phase is the largest single phase by hours. Adding 20% effort there adds 3 months to the program likely-case duration.

**What's already in the plan:** Phase 0 audit dimensions 3 and 10 directly attack this; the OpenRoad reader role is funded; pair-reading is built into the resource plan. **None of these eliminate the risk — they bound it.**

**What you should expect to be told in month 18:** "We're seeing more rules in TOMS than FMS prepared us for; we're requesting a 6-week scope adjustment." This will happen. It is not a sign of bad delivery — it is the failure mode materializing despite mitigation. Plan for it.

### 1.2 Pattern-reuse rate from MVP to Incremental Build is overestimated

Every team that has done a multi-app modernization has overestimated the reuse rate of MVP work in subsequent apps. The optimistic instinct is "we built FMS, the others share the workflow shape, we'll do them in half the time."

**Reality:** typical reuse rate is **30%, not 60%**. The remaining 70% is:

- App-specific business rules (each core has its own)
- Domain model differences that don't surface until the second core's design (steam vs. dielectric vs. transmission)
- UX parity differences (operators of different cores have different muscle memories)
- Integration count and complexity differences (TLS has many; DBM has few)

**Cost if realized:** The 12–20-month range for P3 is partly there to accommodate this. If reuse rate is 30%, P3 is closer to 18–20 months. If 60% (rare), P3 is closer to 12.

**What's already in the plan:** B1's Incremental Build range explicitly includes this. **The variance is not because we don't know what we're doing — it's because we don't know yet what the reuse rate will be.** That is honest.

### 1.3 Operator SME availability is a dependency we don't fully control

The user confirmed full-time dedicated operator SMEs. This is the single biggest variance reducer in the entire plan. **It is also the assumption most likely to silently regress mid-program.**

Operators are pulled back to dispatch shifts when:
- A storm season hits
- A retirement leaves a shift uncovered
- A vendor-system outage demands operator expertise
- The utility's operational priorities shift

When this happens, "full-time SME" becomes "available 2 days a week for the next 6 weeks until we backfill." **MVP UAT cycle count doubles overnight in that scenario.**

**Cost if realized:** P2a (MVP UAT) goes from 2 months to 3+ months. M-06 slips. Knock-on effects on P3 start.

**What's already in the plan:** Backup operator SMEs identified as a key-person mitigation. The risk register entry R-003 (operator change resistance) covers part of this; the availability angle deserves its own entry — recommend adding **R-011: Operator SME pull-back to dispatch shifts** with score 12.

**What you should expect to be told in month 9:** "Storm response pulled R. Chen back to dispatch for two weeks; we're adding a sprint to MVP." Manage this expectation upfront with the operations leadership.

### 1.4 Onboarding & ramp-up dilutes effective FTE more than people plan for

A nominal "30 FTE in P2" produces less effort than 30 × P2 duration if 12 of those people joined in the first month of P2. New joiners are 0% productive for 2 weeks, ~30% for the next month, ~70% for the next 2 months. By month 4, they're full speed.

**Cost if not accounted:** ~15% effective effort loss in any phase that starts with significant ramping. P2 (MVP Build) is most exposed because the team peaks there from a smaller P1a base.

**What's already in the plan:** The estimation worksheet has an Effective FTE calculation that applies onboarding factors. This is a correction most plans skip and discover the hard way.

---

## 2. Why estimates cannot be tighter than ranges

Anyone giving you single-point estimates at this stage is selling, not estimating. The ranges in `15-estimation-worksheet.xlsx` reflect:

| Source of variance | Why it cannot be eliminated yet |
|---|---|
| Discovery audit RAG outcome (Phase 0 audit) | Audit hasn't run yet |
| Hidden 4GL rules per app | Unknowable without code-reading |
| Pattern-reuse rate from FMS to other cores | Unknowable until 2 cores complete |
| Operator SME effective availability | Forecast, not contracted |
| Vendor coordination (EMS/XA21) | Not under direct program control |
| Network change-control velocity | SecOps SLA is institutional, not project-controlled |
| Hiring time-to-fill for specialist roles | Market-dependent |

A plan that pretends to certainty here is not a more accurate plan — it's a less honest one.

---

## 3. The numbers most worth scrutinizing in B1/B4

If a sponsor or steering committee member asks "what number should I push back on?" — point them at these:

| Number | Why it deserves pushback |
|---|---|
| **P3 Incremental Build duration: 12–20 months** | The 8-month range is real. If forced to commit to a single point, the right answer is 18, not 15. Variance is dominated by hidden-rule discovery and reuse rate. |
| **MVP build duration: 5–8 months (likely 6.5)** | This is the *most* defensible number in the plan because partial-FMS scope is bounded and operator SMEs are full-time. If anything, this could come in shorter. But — see §4 below. |
| **Peak FTE: 60+ engineering** | Higher than user's stated bench (15–20 .NET/Angular). If actual bench is 20 *total*, the program shape collapses. See §5. |
| **20% new-value allocation in MVP** | Nominally fine, but each new-value Epic carries +30–50% effort vs. comparable parity Epics because operator co-design is heavier. Not yet priced in worksheet — flagged. |
| **Cutover phase: 4–8 months for 6 events** | Per-event budget is 4–8 weeks. **Compressing this is the single cheapest decision and the most expensive consequence**. Treat any pressure to compress as a Red signal. |
| **Hypercare exit at 30 consecutive days under threshold** | This number is conservative. If steady-state is reached cleanly, exit could be 14 days. If not, it could be 60. |

---

## 4. Where MVP could come in faster than the range — and why I'm not promising it

Three factors are unusually favorable on this program:

1. **Full-time dedicated operator SMEs.** Most modernizations get part-time. Full-time roughly halves UAT cycle count.
2. **Partial-FMS-as-MVP, single canonical scenario.** Bounded scope; resists creep.
3. **No external deadline pressure.** The team isn't cutting corners to hit a date.

In the best case, P2 + P2a runs 6 months total instead of 8.5. **I am not promising this**, because:

- Even with full-time SMEs, mental-model parity has a learning curve for the engineering team
- Tangible new-value features require operator co-design that is fundamentally slower than parity replication
- Hidden 4GL rules in even FMS-MVP scope will surface

**Sponsor positioning:** plan to the likely case (8.5 months for P2 + P2a). If MVP comes in faster, that is good news that creates space for early P3 ramping. Do not commit publicly to the best case.

---

## 5. The biggest hidden assumption in the resource plan

The user confirmed an internal team of 15–20 .NET/Angular engineers. The peak FTE in the resource plan is 60+. **The gap is real and intentional.**

The 60+ peak includes:
- Architects, leads (12 FTE)
- Engineers (20 FTE — within the user's bench)
- QA engineers (8 FTE)
- DevOps engineers (1–2 FTE)
- BAs, PMs, UX (8 FTE)
- Specialists (compliance, security, OpenRoad reader, ~5 FTE)

If the user's "15–20" cap is **total program staff**, not just engineers:
- The program does not deliver in 30–42 months
- The MVP date doubles
- Cutover risk increases
- Operator change-management work suffers

**This is a critical clarification before sponsor sign-off.** If "15–20" is a hard ceiling on total headcount, the program needs a different shape — likely fewer apps in scope, or longer duration, or vendor augmentation.

The 8-week recommendation: confirm with HR/Resource Manager before P1 starts whether the peak engineering FTE budget is actually approvable. If not, re-shape now, not in month 12.

---

## 6. Where I am willing to compress estimates (with named trade-offs)

Some compression is rational. These are honest:

| Compression | Where | Trade-off |
|---|---|---|
| Detailed Design (P1) from 4 mo to 3 mo | Defer NFR baselining to early P2 | NFRs surface as defects, not requirements; rework cost ≈ savings |
| Foundational Tasks (P1a) from 3 mo to 2 mo | Reuse internal CI/CD template if one exists | Locks into prior tooling decisions |
| Hypercare program-wide from 4 mo to 3 mo | If defect rate trends below threshold | Less buffer for late-surfacing regressions |
| MVP UAT (P2a) from 2 mo to 1.5 mo | Confirmed full-time SME availability | None — this compression is *already* baked in to the likely case for P2a given full-time SMEs |

## 7. Where I will refuse to compress

| Compression | Why I refuse |
|---|---|
| Per-app cutover soak (4 weeks minimum) | This is the difference between staggered and pure big-bang. Compressing this defeats the rationale for Option A. |
| Phase 0 audit (3 days) | One day is theater; misses dimensions 3 and 10 (the hidden-rule attacks). |
| Dress rehearsals per cutover (3 minimum) | Two means an unrehearsed failure mode goes to production. |
| Onboarding factor in worksheet | Dropping this hides 15% of effective effort loss; it surfaces as schedule slip in month 4. |
| Operator panel review at sprint demo | Without this, M-06 surfaces parity issues at gate, not at design. |

## 8. Three uncomfortable truths the plan implicitly accepts

These are not problems to solve — they are realities to design around:

1. **Internal teams typically deliver 20–30% slower than vendor-led delivery in raw velocity, and 30–40% better in long-term fit.** This program is internal by sponsor choice. The trade-off is the right one for safety-critical OT software with regulatory exposure. It does mean the plan's likely-case duration is honest, not pessimistic.

2. **The OpNET standby + islanding architecture costs ~10–15% of total program effort** for capability that is exercised maybe twice a year. It is not negotiable — the regulatory and operational case is clear — but it is real cost.

3. **The 20% new-value commitment converts a parity-modernization into a hybrid program.** Pure parity modernizations are predictable. Hybrid programs are less predictable because new-value features generate their own scope creep. The 20% allocation gate (B3 §10.1) helps but does not eliminate this.

---

## 9. The five things that, if changed, would make these numbers more reliable

Listed in order of variance reduction. Apply these and the worst-case columns shrink toward the likely case.

### 9.1 Run the Phase 0 audit before P1 starts (not in parallel)

Largest single variance reducer. Discussed in detail in [00-phase0-discovery-audit-memo.md](00-phase0-discovery-audit-memo.md). Three days of audit cost. Could shrink the worst-case-vs-likely gap by 6–8 weeks across the program.

### 9.2 Identify the OpenRoad reader within 4 weeks of P1 start, not "during P1"

Critical-path role. Every week without one inflates downstream estimates. If internal candidate not found within 4 weeks, contract aggressively — premium rate is justified.

### 9.3 Pre-stage SecOps approvals during P1 detailed design

Network change-control SLA is the silent killer. Submit firewall rule applications **as part of P1 design output**, not as a P1a task. Saves 4–8 weeks across P1a + P1b.

### 9.4 Confirm peak FTE budget before P1 starts

The 60+ peak vs. user's "15–20" needs explicit reconciliation. Reshape the program now if the peak isn't supportable, not in month 12.

### 9.5 Treat operator SME availability as a service-level commitment, not an aspiration

User confirmed full-time SMEs. Codify this as a written agreement with Operations leadership including:
- Backfill commitment for storm season
- Backup SME pre-identified per core
- Escalation path if availability degrades
- Quarterly review of actual availability

If this can't be codified, treat the resource plan's likely-case as the worst-case and re-baseline.

---

## 10. What I am most likely to be wrong about myself

In the spirit of brutal honesty applied to my own analysis:

| What I might be wrong about | Why | What you should do |
|---|---|---|
| The 30% reuse rate (vs. 60%) for P3 | I have not seen this team deliver. Some teams genuinely achieve 50–60% with strong patterns. | Re-evaluate at the 50% mark of P3 (M-07). |
| The OT/IT change-control SLA assumption (10–15 days for inter-zone) | Utility-by-utility variation is huge. Could be 5 days, could be 30. | Ask SecOps for actuals from a recent comparable change. |
| The 20% buffer for attrition | Could be too conservative for a strong team, too aggressive for a stretched one | Track actual attrition month-by-month; adjust forecast at each phase boundary. |
| Whether full-time operator SMEs will sustain | I am defaulting to skepticism. The user has stronger insight here. | Test the commitment in the first 2 sprints of P1; if it holds, my variance estimate is too pessimistic. |

The point of this section is that the plan is a hypothesis, not a forecast. **Treat it accordingly. Re-baseline at every phase gate.**

---

## 11. Recommended sponsor-facing position

When the steering committee asks "how confident are we?":

- **Highly confident** in the architectural approach and the cutover strategy
- **Moderately confident** in the MVP timeline (8.5 mo likely case)
- **Honestly uncertain** on the Incremental Build duration, dominated by hidden-rule discovery
- **Highly confident** that the resource plan is *correctly shaped*; uncertain whether the peak FTE budget will be approved
- **Highly confident** that running Phase 0 audit is the most cost-effective single risk-reduction action

Don't oversell. Sponsors who hear honest "we expect to learn things that will adjust this" tolerate adjustments later. Sponsors who hear false certainty don't.

---

## 12. What this memo is not

- It is not a recommendation to inflate estimates further. The numbers are calibrated.
- It is not a hedge against future failure. It is a calibration of confidence per number.
- It is not an argument against the program. The program is feasible. It is feasible in 30–42 months. It is feasible with the resource shape proposed. The variance bands are real and should be respected.

The point of this memo is that **a plan with honest variance is more useful than a plan with false precision.** Use it accordingly.
