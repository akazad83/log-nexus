using DocuHub.Core.Interfaces;
using DocuHub.Core.Models;

namespace DocuHub.Api.Endpoints;

public static class FileEndpoints
{
    public static void MapFileEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/files")
            .WithTags("Files");

        group.MapGet("/", ListFilesAsync)
            .WithName("ListFiles")
            .WithSummary("List all markdown files")
            .WithDescription("Returns a JSON index of all .md files in the docs directory")
            .Produces<IEnumerable<FileMetadata>>(StatusCodes.Status200OK);

        group.MapGet("/{*path}", GetFileAsync)
            .WithName("GetFile")
            .WithSummary("Get file content")
            .WithDescription("Returns the content of a specific markdown file")
            .Produces<FileContent>(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status403Forbidden);

        group.MapPut("/{*path}", UpdateFileAsync)
            .WithName("UpdateFile")
            .WithSummary("Update file content")
            .WithDescription("Updates the content of a specific markdown file")
            .Produces<FileMetadata>(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status403Forbidden);

        group.MapDelete("/{*path}", DeleteFileAsync)
            .WithName("DeleteFile")
            .WithSummary("Delete a file")
            .WithDescription("Deletes a specific markdown file")
            .Produces(StatusCodes.Status204NoContent)
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status403Forbidden);
    }

    private static async Task<IResult> ListFilesAsync(
        IFileIndexerService fileIndexer,
        CancellationToken cancellationToken)
    {
        var files = await fileIndexer.ScanAsync(cancellationToken);
        return Results.Ok(files);
    }

    private static async Task<IResult> GetFileAsync(
        string path,
        IFileIndexerService fileIndexer,
        CancellationToken cancellationToken)
    {
        var content = await fileIndexer.GetFileContentAsync(path, cancellationToken);
        return Results.Ok(content);
    }

    private static async Task<IResult> UpdateFileAsync(
        string path,
        UpdateFileRequest request,
        IFileIndexerService fileIndexer,
        CancellationToken cancellationToken)
    {
        var metadata = await fileIndexer.UpdateFileAsync(path, request.Content, cancellationToken);
        return Results.Ok(metadata);
    }

    private static async Task<IResult> DeleteFileAsync(
        string path,
        IFileIndexerService fileIndexer,
        CancellationToken cancellationToken)
    {
        await fileIndexer.DeleteFileAsync(path, cancellationToken);
        return Results.NoContent();
    }
}
