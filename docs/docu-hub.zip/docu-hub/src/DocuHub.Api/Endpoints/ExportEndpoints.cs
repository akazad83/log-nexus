using DocuHub.Core.Interfaces;
using DocuHub.Core.Models;

namespace DocuHub.Api.Endpoints;

public static class ExportEndpoints
{
    public static void MapExportEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/export")
            .WithTags("Export");

        group.MapPost("/pdf", ExportPdfAsync)
            .WithName("ExportPdf")
            .WithSummary("Export to PDF")
            .WithDescription("Exports markdown content to a PDF document")
            .Produces(StatusCodes.Status200OK, contentType: "application/pdf")
            .Produces(StatusCodes.Status400BadRequest);
    }

    private static async Task<IResult> ExportPdfAsync(
        ExportPdfRequest request,
        IPdfExportService pdfExport,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Markdown))
        {
            return Results.BadRequest(new { error = "Markdown content is required" });
        }

        var pdfBytes = await pdfExport.ExportAsync(request.Markdown, cancellationToken);

        var filename = string.IsNullOrWhiteSpace(request.FileName)
            ? "document.pdf"
            : request.FileName.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)
                ? request.FileName
                : $"{request.FileName}.pdf";

        return Results.File(pdfBytes, "application/pdf", filename);
    }
}
