using DocuHub.Api.Endpoints;
using DocuHub.Core.Interfaces;
using DocuHub.Core.Services;
using DocuHub.Infrastructure.Services;
using Microsoft.AspNetCore.Diagnostics;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new()
    {
        Title = "DocuHub API",
        Version = "v1",
        Description = "A local markdown file viewer and editor API"
    });
});

// Register application services
builder.Services.AddScoped<IFileIndexerService, FileIndexerService>();
builder.Services.AddScoped<IPdfExportService, PdfExportService>();

// Configure CORS
var corsOrigins = builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:5173"];
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins(corsOrigins)
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Global exception handler
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        var exception = context.Features.Get<IExceptionHandlerFeature>()?.Error;
        var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();

        var (statusCode, message) = exception switch
        {
            FileNotFoundException => (StatusCodes.Status404NotFound, "File not found"),
            UnauthorizedAccessException => (StatusCodes.Status403Forbidden, "Access denied"),
            BadHttpRequestException => (StatusCodes.Status400BadRequest, "Invalid request body"),
            ArgumentException ex => (StatusCodes.Status400BadRequest, ex.Message),
            InvalidOperationException ex => (StatusCodes.Status400BadRequest, ex.Message),
            _ => (StatusCodes.Status500InternalServerError, "An unexpected error occurred")
        };

        if (statusCode == StatusCodes.Status500InternalServerError)
        {
            logger.LogError(exception, "Unhandled exception occurred");
        }

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(new { error = message });
    });
});

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "DocuHub API v1");
        options.RoutePrefix = "swagger";
    });
}

app.UseCors("AllowFrontend");

// Health check endpoint
app.MapGet("/", () => Results.Ok(new { status = "healthy", service = "DocuHub API" }))
   .WithName("HealthCheck")
   .WithTags("Health");

// Map API endpoints
app.MapFileEndpoints();
app.MapExportEndpoints();

app.Run();

// Make Program class accessible for integration tests
public partial class Program { }
