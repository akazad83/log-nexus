using DocuHub.Core.Models;

namespace DocuHub.Core.Interfaces;

/// <summary>
/// Service interface for indexing and managing markdown files in the docs directory.
/// </summary>
public interface IFileIndexerService
{
    /// <summary>
    /// Gets the root path of the docs directory.
    /// </summary>
    string DocsRoot { get; }

    /// <summary>
    /// Scans the docs directory and returns metadata for all markdown files.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Collection of file metadata.</returns>
    Task<IEnumerable<FileMetadata>> ScanAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Validates and returns the full path for a requested file path.
    /// Ensures the path is within the docs directory and has .md extension.
    /// </summary>
    /// <param name="requestedPath">The relative path requested by the client.</param>
    /// <returns>The validated full path.</returns>
    /// <exception cref="UnauthorizedAccessException">Thrown when path attempts to escape docs directory.</exception>
    /// <exception cref="InvalidOperationException">Thrown when file doesn't have .md extension.</exception>
    string GetSafePath(string requestedPath);

    /// <summary>
    /// Gets the content of a markdown file.
    /// </summary>
    /// <param name="requestedPath">The relative path of the file.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The file content with metadata.</returns>
    /// <exception cref="FileNotFoundException">Thrown when file doesn't exist.</exception>
    Task<FileContent> GetFileContentAsync(string requestedPath, CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates the content of a markdown file.
    /// </summary>
    /// <param name="requestedPath">The relative path of the file.</param>
    /// <param name="content">The new content.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The updated file metadata.</returns>
    Task<FileMetadata> UpdateFileAsync(string requestedPath, string content, CancellationToken cancellationToken = default);

    /// <summary>
    /// Deletes a markdown file.
    /// </summary>
    /// <param name="requestedPath">The relative path of the file.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task DeleteFileAsync(string requestedPath, CancellationToken cancellationToken = default);
}
