namespace DocuHub.Core.Interfaces;

/// <summary>
/// Service interface for exporting markdown content to PDF.
/// </summary>
public interface IPdfExportService
{
    /// <summary>
    /// Exports markdown content to a PDF document.
    /// </summary>
    /// <param name="markdown">The markdown content to convert.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The PDF document as a byte array.</returns>
    Task<byte[]> ExportAsync(string markdown, CancellationToken cancellationToken = default);
}
