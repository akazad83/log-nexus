using DocuHub.Core.Interfaces;
using DocuHub.Core.Models;
using Microsoft.Extensions.Configuration;

namespace DocuHub.Core.Services;

/// <summary>
/// Service for indexing and managing markdown files in the docs directory.
/// Implements path traversal protection to prevent unauthorized file access.
/// </summary>
public class FileIndexerService : IFileIndexerService
{
    private readonly string _docsRoot;

    public string DocsRoot => _docsRoot;

    public FileIndexerService(IConfiguration configuration)
    {
        var configuredPath = configuration["DocsPath"] ?? "./docs";
        _docsRoot = Path.GetFullPath(configuredPath);

        // Ensure docs directory exists
        Directory.CreateDirectory(_docsRoot);
    }

    /// <summary>
    /// Constructor for testing with explicit docs root path.
    /// </summary>
    public FileIndexerService(string docsRoot)
    {
        _docsRoot = Path.GetFullPath(docsRoot);
        Directory.CreateDirectory(_docsRoot);
    }

    public async Task<IEnumerable<FileMetadata>> ScanAsync(CancellationToken cancellationToken = default)
    {
        var files = new List<FileMetadata>();

        var options = new EnumerationOptions
        {
            RecurseSubdirectories = true,
            IgnoreInaccessible = true
        };

        await Task.Run(() =>
        {
            foreach (var filePath in Directory.EnumerateFiles(_docsRoot, "*.md", options))
            {
                cancellationToken.ThrowIfCancellationRequested();

                var fileInfo = new FileInfo(filePath);
                var relativePath = Path.GetRelativePath(_docsRoot, filePath).Replace('\\', '/');

                files.Add(new FileMetadata(
                    Name: fileInfo.Name,
                    Path: relativePath,
                    Size: fileInfo.Length,
                    CreatedAt: fileInfo.CreationTimeUtc,
                    ModifiedAt: fileInfo.LastWriteTimeUtc
                ));
            }
        }, cancellationToken);

        // Sort by path for consistent ordering
        return files.OrderBy(f => f.Path);
    }

    public string GetSafePath(string requestedPath)
    {
        if (string.IsNullOrWhiteSpace(requestedPath))
        {
            throw new ArgumentException("Path cannot be empty", nameof(requestedPath));
        }

        // Normalize the path separators
        requestedPath = requestedPath.Replace('/', Path.DirectorySeparatorChar);

        // Combine with docs root and canonicalize
        var fullPath = Path.GetFullPath(Path.Combine(_docsRoot, requestedPath));

        // Ensure the path ends with .md (add if not present)
        if (!fullPath.EndsWith(".md", StringComparison.OrdinalIgnoreCase))
        {
            fullPath += ".md";
        }

        // Security check: verify path is within docs directory
        // Use directory separator to prevent partial path matches (e.g., /docs vs /docs2)
        var normalizedDocsRoot = _docsRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var normalizedFullPath = fullPath.Replace('/', Path.DirectorySeparatorChar);

        if (!normalizedFullPath.StartsWith(normalizedDocsRoot, StringComparison.OrdinalIgnoreCase))
        {
            throw new UnauthorizedAccessException("Access denied: path outside docs directory");
        }

        return fullPath;
    }

    public async Task<FileContent> GetFileContentAsync(string requestedPath, CancellationToken cancellationToken = default)
    {
        var fullPath = GetSafePath(requestedPath);

        if (!File.Exists(fullPath))
        {
            throw new FileNotFoundException($"File not found: {requestedPath}", requestedPath);
        }

        var fileInfo = new FileInfo(fullPath);
        var content = await File.ReadAllTextAsync(fullPath, cancellationToken);
        var relativePath = Path.GetRelativePath(_docsRoot, fullPath).Replace('\\', '/');

        return new FileContent(
            Name: fileInfo.Name,
            Path: relativePath,
            Content: content,
            Size: fileInfo.Length,
            CreatedAt: fileInfo.CreationTimeUtc,
            ModifiedAt: fileInfo.LastWriteTimeUtc
        );
    }

    public async Task<FileMetadata> UpdateFileAsync(string requestedPath, string content, CancellationToken cancellationToken = default)
    {
        var fullPath = GetSafePath(requestedPath);

        // Ensure parent directory exists
        var directory = Path.GetDirectoryName(fullPath);
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        await File.WriteAllTextAsync(fullPath, content, cancellationToken);

        var fileInfo = new FileInfo(fullPath);
        var relativePath = Path.GetRelativePath(_docsRoot, fullPath).Replace('\\', '/');

        return new FileMetadata(
            Name: fileInfo.Name,
            Path: relativePath,
            Size: fileInfo.Length,
            CreatedAt: fileInfo.CreationTimeUtc,
            ModifiedAt: fileInfo.LastWriteTimeUtc
        );
    }

    public Task DeleteFileAsync(string requestedPath, CancellationToken cancellationToken = default)
    {
        var fullPath = GetSafePath(requestedPath);

        if (!File.Exists(fullPath))
        {
            throw new FileNotFoundException($"File not found: {requestedPath}", requestedPath);
        }

        File.Delete(fullPath);

        return Task.CompletedTask;
    }
}
