namespace DocuHub.Core.Exceptions;

/// <summary>
/// Base exception for DocuHub application errors.
/// </summary>
public class DocuHubException : Exception
{
    public DocuHubException(string message) : base(message) { }
    public DocuHubException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>
/// Thrown when a requested file is not found.
/// </summary>
public class FileNotFoundExceptionEx : DocuHubException
{
    public string FilePath { get; }

    public FileNotFoundExceptionEx(string filePath)
        : base($"File not found: {filePath}")
    {
        FilePath = filePath;
    }
}

/// <summary>
/// Thrown when a path traversal attack is detected.
/// </summary>
public class PathTraversalException : DocuHubException
{
    public string AttemptedPath { get; }

    public PathTraversalException(string attemptedPath)
        : base("Access denied: path outside docs directory")
    {
        AttemptedPath = attemptedPath;
    }
}

/// <summary>
/// Thrown when an invalid file extension is requested.
/// </summary>
public class InvalidFileExtensionException : DocuHubException
{
    public string Extension { get; }

    public InvalidFileExtensionException(string extension)
        : base($"Invalid file extension: {extension}. Only .md files are accessible.")
    {
        Extension = extension;
    }
}

/// <summary>
/// Thrown when PDF export fails.
/// </summary>
public class PdfExportException : DocuHubException
{
    public PdfExportException(string message) : base(message) { }
    public PdfExportException(string message, Exception innerException) : base(message, innerException) { }
}
