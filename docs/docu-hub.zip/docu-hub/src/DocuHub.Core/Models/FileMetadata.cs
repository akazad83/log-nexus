namespace DocuHub.Core.Models;

/// <summary>
/// Represents metadata for a markdown file in the docs directory.
/// </summary>
public record FileMetadata(
    string Name,
    string Path,
    long Size,
    DateTime CreatedAt,
    DateTime ModifiedAt
);
