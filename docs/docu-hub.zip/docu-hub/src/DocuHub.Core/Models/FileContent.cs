namespace DocuHub.Core.Models;

/// <summary>
/// Represents the content of a markdown file along with its metadata.
/// </summary>
public record FileContent(
    string Name,
    string Path,
    string Content,
    long Size,
    DateTime CreatedAt,
    DateTime ModifiedAt
);
