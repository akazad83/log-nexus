namespace DocuHub.Core.Models;

/// <summary>
/// Request model for exporting markdown content to PDF.
/// </summary>
public record ExportPdfRequest(string Markdown, string? FileName = null);
