namespace DocuHub.Core.Models;

/// <summary>
/// Request model for updating a markdown file's content.
/// </summary>
public record UpdateFileRequest(string Content);
