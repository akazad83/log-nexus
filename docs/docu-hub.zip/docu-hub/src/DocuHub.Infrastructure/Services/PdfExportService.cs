using DocuHub.Core.Interfaces;
using Markdig;
using PuppeteerSharp;
using PuppeteerSharp.Media;

namespace DocuHub.Infrastructure.Services;

/// <summary>
/// Service for exporting markdown content to PDF using PuppeteerSharp (headless Chrome).
/// </summary>
public class PdfExportService : IPdfExportService
{
    private static bool _browserDownloaded;
    private static readonly SemaphoreSlim _downloadLock = new(1, 1);
    private static readonly MarkdownPipeline _pipeline = new MarkdownPipelineBuilder()
        .UseAdvancedExtensions()
        .Build();

    public async Task<byte[]> ExportAsync(string markdown, CancellationToken cancellationToken = default)
    {
        // Convert markdown to HTML
        var html = Markdown.ToHtml(markdown, _pipeline);

        // Ensure browser is downloaded (only once)
        await EnsureBrowserDownloadedAsync();

        // Launch browser
        await using var browser = await Puppeteer.LaunchAsync(new LaunchOptions
        {
            Headless = true,
            Args = ["--no-sandbox", "--disable-setuid-sandbox"]
        });

        // Create page and set content
        await using var page = await browser.NewPageAsync();

        var styledHtml = InjectStyles(html);
        await page.SetContentAsync(styledHtml, new NavigationOptions
        {
            WaitUntil = [WaitUntilNavigation.Networkidle0]
        });

        // Generate PDF
        var pdfBytes = await page.PdfDataAsync(new PdfOptions
        {
            Format = PaperFormat.A4,
            PrintBackground = true,
            MarginOptions = new MarginOptions
            {
                Top = "0.5in",
                Bottom = "0.5in",
                Left = "0.5in",
                Right = "0.5in"
            }
        });

        return pdfBytes;
    }

    private static async Task EnsureBrowserDownloadedAsync()
    {
        if (_browserDownloaded) return;

        await _downloadLock.WaitAsync();
        try
        {
            if (_browserDownloaded) return;

            var browserFetcher = new BrowserFetcher();
            await browserFetcher.DownloadAsync();
            _browserDownloaded = true;
        }
        finally
        {
            _downloadLock.Release();
        }
    }

    private static string InjectStyles(string html)
    {
        const string styles = """
            <style>
                * {
                    box-sizing: border-box;
                }

                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', Helvetica, Arial, sans-serif;
                    font-size: 14px;
                    line-height: 1.6;
                    color: #24292f;
                    background-color: #ffffff;
                    margin: 0;
                    padding: 20px;
                }

                h1, h2, h3, h4, h5, h6 {
                    margin-top: 24px;
                    margin-bottom: 16px;
                    font-weight: 600;
                    line-height: 1.25;
                }

                h1 {
                    font-size: 2em;
                    border-bottom: 1px solid #d0d7de;
                    padding-bottom: 0.3em;
                }

                h2 {
                    font-size: 1.5em;
                    border-bottom: 1px solid #d0d7de;
                    padding-bottom: 0.3em;
                }

                h3 { font-size: 1.25em; }
                h4 { font-size: 1em; }
                h5 { font-size: 0.875em; }
                h6 { font-size: 0.85em; color: #57606a; }

                p {
                    margin-top: 0;
                    margin-bottom: 16px;
                }

                a {
                    color: #0969da;
                    text-decoration: none;
                }

                a:hover {
                    text-decoration: underline;
                }

                code {
                    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace;
                    font-size: 85%;
                    background-color: rgba(175, 184, 193, 0.2);
                    padding: 0.2em 0.4em;
                    border-radius: 6px;
                }

                pre {
                    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace;
                    font-size: 85%;
                    background-color: #f6f8fa;
                    border-radius: 6px;
                    padding: 16px;
                    overflow: auto;
                    line-height: 1.45;
                    margin-top: 0;
                    margin-bottom: 16px;
                }

                pre code {
                    background-color: transparent;
                    padding: 0;
                    font-size: 100%;
                }

                blockquote {
                    margin: 0 0 16px 0;
                    padding: 0 1em;
                    color: #57606a;
                    border-left: 0.25em solid #d0d7de;
                }

                ul, ol {
                    margin-top: 0;
                    margin-bottom: 16px;
                    padding-left: 2em;
                }

                li + li {
                    margin-top: 0.25em;
                }

                table {
                    border-collapse: collapse;
                    border-spacing: 0;
                    width: 100%;
                    margin-bottom: 16px;
                }

                table th,
                table td {
                    padding: 6px 13px;
                    border: 1px solid #d0d7de;
                }

                table th {
                    font-weight: 600;
                    background-color: #f6f8fa;
                }

                table tr:nth-child(2n) {
                    background-color: #f6f8fa;
                }

                hr {
                    height: 0.25em;
                    padding: 0;
                    margin: 24px 0;
                    background-color: #d0d7de;
                    border: 0;
                }

                img {
                    max-width: 100%;
                    height: auto;
                }

                .markdown-body {
                    max-width: 980px;
                    margin: 0 auto;
                }
            </style>
            """;

        return $"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                {styles}
            </head>
            <body>
                <div class="markdown-body">
                    {html}
                </div>
            </body>
            </html>
            """;
    }
}
