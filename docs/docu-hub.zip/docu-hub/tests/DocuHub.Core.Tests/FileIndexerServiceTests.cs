using DocuHub.Core.Services;
using FluentAssertions;

namespace DocuHub.Core.Tests;

public class FileIndexerServiceTests : IDisposable
{
    private readonly string _testDocsRoot;
    private readonly FileIndexerService _service;

    public FileIndexerServiceTests()
    {
        // Create a temporary directory for testing
        _testDocsRoot = Path.Combine(Path.GetTempPath(), $"docuhub-tests-{Guid.NewGuid()}");
        Directory.CreateDirectory(_testDocsRoot);
        _service = new FileIndexerService(_testDocsRoot);
    }

    public void Dispose()
    {
        // Clean up test directory
        if (Directory.Exists(_testDocsRoot))
        {
            Directory.Delete(_testDocsRoot, recursive: true);
        }
    }

    #region ScanAsync Tests

    [Fact]
    public async Task ScanAsync_EmptyDirectory_ReturnsEmptyList()
    {
        // Act
        var result = await _service.ScanAsync();

        // Assert
        result.Should().BeEmpty();
    }

    [Fact]
    public async Task ScanAsync_WithMarkdownFiles_ReturnsFileMetadata()
    {
        // Arrange
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "test.md"), "# Test");
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "readme.md"), "# Readme");

        // Act
        var result = await _service.ScanAsync();

        // Assert
        result.Should().HaveCount(2);
        result.Select(f => f.Name).Should().Contain(["test.md", "readme.md"]);
    }

    [Fact]
    public async Task ScanAsync_WithNestedDirectories_ReturnsAllFiles()
    {
        // Arrange
        var subDir = Path.Combine(_testDocsRoot, "subdir");
        Directory.CreateDirectory(subDir);
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "root.md"), "# Root");
        await File.WriteAllTextAsync(Path.Combine(subDir, "nested.md"), "# Nested");

        // Act
        var result = await _service.ScanAsync();

        // Assert
        result.Should().HaveCount(2);
        result.Select(f => f.Path).Should().Contain(["root.md", "subdir/nested.md"]);
    }

    [Fact]
    public async Task ScanAsync_IgnoresNonMarkdownFiles()
    {
        // Arrange
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "test.md"), "# Test");
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "test.txt"), "Text file");
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "test.json"), "{}");

        // Act
        var result = await _service.ScanAsync();

        // Assert
        result.Should().HaveCount(1);
        result.First().Name.Should().Be("test.md");
    }

    #endregion

    #region GetSafePath Tests

    [Fact]
    public void GetSafePath_ValidPath_ReturnsFullPath()
    {
        // Arrange
        var testFile = Path.Combine(_testDocsRoot, "test.md");

        // Act
        var result = _service.GetSafePath("test.md");

        // Assert
        result.Should().Be(testFile);
    }

    [Fact]
    public void GetSafePath_PathWithoutExtension_AppendsExtension()
    {
        // Act
        var result = _service.GetSafePath("test");

        // Assert
        result.Should().EndWith(".md");
    }

    [Fact]
    public void GetSafePath_NestedPath_ReturnsCorrectPath()
    {
        // Act
        var result = _service.GetSafePath("subdir/test.md");

        // Assert
        result.Should().Contain("subdir");
        result.Should().EndWith("test.md");
    }

    [Fact]
    public void GetSafePath_PathTraversalAttempt_ThrowsUnauthorizedException()
    {
        // Act & Assert
        var act = () => _service.GetSafePath("../../../etc/passwd");
        act.Should().Throw<UnauthorizedAccessException>()
           .WithMessage("*outside docs directory*");
    }

    [Fact]
    public void GetSafePath_PathTraversalWithBackslash_ThrowsUnauthorizedException()
    {
        // Act & Assert
        var act = () => _service.GetSafePath("..\\..\\..\\windows\\system32\\config");
        act.Should().Throw<UnauthorizedAccessException>()
           .WithMessage("*outside docs directory*");
    }

    [Fact]
    public void GetSafePath_EmptyPath_ThrowsArgumentException()
    {
        // Act & Assert
        var act = () => _service.GetSafePath("");
        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void GetSafePath_WhitespacePath_ThrowsArgumentException()
    {
        // Act & Assert
        var act = () => _service.GetSafePath("   ");
        act.Should().Throw<ArgumentException>();
    }

    #endregion

    #region GetFileContentAsync Tests

    [Fact]
    public async Task GetFileContentAsync_ExistingFile_ReturnsContent()
    {
        // Arrange
        var content = "# Hello World\n\nThis is a test.";
        await File.WriteAllTextAsync(Path.Combine(_testDocsRoot, "hello.md"), content);

        // Act
        var result = await _service.GetFileContentAsync("hello.md");

        // Assert
        result.Name.Should().Be("hello.md");
        result.Path.Should().Be("hello.md");
        result.Content.Should().Be(content);
        result.Size.Should().BeGreaterThan(0);
    }

    [Fact]
    public async Task GetFileContentAsync_NonExistingFile_ThrowsFileNotFoundException()
    {
        // Act & Assert
        var act = async () => await _service.GetFileContentAsync("nonexistent.md");
        await act.Should().ThrowAsync<FileNotFoundException>();
    }

    [Fact]
    public async Task GetFileContentAsync_NestedFile_ReturnsCorrectPath()
    {
        // Arrange
        var subDir = Path.Combine(_testDocsRoot, "docs", "api");
        Directory.CreateDirectory(subDir);
        await File.WriteAllTextAsync(Path.Combine(subDir, "endpoints.md"), "# API");

        // Act
        var result = await _service.GetFileContentAsync("docs/api/endpoints.md");

        // Assert
        result.Path.Should().Be("docs/api/endpoints.md");
    }

    #endregion

    #region UpdateFileAsync Tests

    [Fact]
    public async Task UpdateFileAsync_NewFile_CreatesFile()
    {
        // Arrange
        var content = "# New File";

        // Act
        var result = await _service.UpdateFileAsync("new.md", content);

        // Assert
        result.Name.Should().Be("new.md");
        var fileContent = await File.ReadAllTextAsync(Path.Combine(_testDocsRoot, "new.md"));
        fileContent.Should().Be(content);
    }

    [Fact]
    public async Task UpdateFileAsync_ExistingFile_UpdatesContent()
    {
        // Arrange
        var filePath = Path.Combine(_testDocsRoot, "existing.md");
        await File.WriteAllTextAsync(filePath, "# Old Content");
        var newContent = "# Updated Content";

        // Act
        var result = await _service.UpdateFileAsync("existing.md", newContent);

        // Assert
        var fileContent = await File.ReadAllTextAsync(filePath);
        fileContent.Should().Be(newContent);
    }

    [Fact]
    public async Task UpdateFileAsync_NestedPath_CreatesDirectories()
    {
        // Arrange
        var content = "# Nested";

        // Act
        var result = await _service.UpdateFileAsync("deep/nested/path/file.md", content);

        // Assert
        var filePath = Path.Combine(_testDocsRoot, "deep", "nested", "path", "file.md");
        File.Exists(filePath).Should().BeTrue();
    }

    #endregion

    #region DeleteFileAsync Tests

    [Fact]
    public async Task DeleteFileAsync_ExistingFile_DeletesFile()
    {
        // Arrange
        var filePath = Path.Combine(_testDocsRoot, "todelete.md");
        await File.WriteAllTextAsync(filePath, "# Delete me");

        // Act
        await _service.DeleteFileAsync("todelete.md");

        // Assert
        File.Exists(filePath).Should().BeFalse();
    }

    [Fact]
    public async Task DeleteFileAsync_NonExistingFile_ThrowsFileNotFoundException()
    {
        // Act & Assert
        var act = async () => await _service.DeleteFileAsync("nonexistent.md");
        await act.Should().ThrowAsync<FileNotFoundException>();
    }

    #endregion
}
