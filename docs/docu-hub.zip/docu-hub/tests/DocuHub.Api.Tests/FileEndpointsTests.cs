using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using DocuHub.Core.Models;
using FluentAssertions;

namespace DocuHub.Api.Tests;

public class FileEndpointsTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory _factory;
    private readonly JsonSerializerOptions _jsonOptions;

    public FileEndpointsTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };
    }

    #region Health Check

    [Fact]
    public async Task HealthCheck_ReturnsOk()
    {
        // Act
        var response = await _client.GetAsync("/");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await response.Content.ReadAsStringAsync();
        content.Should().Contain("healthy");
    }

    #endregion

    #region GET /api/files

    [Fact]
    public async Task ListFiles_ReturnsOkWithJsonArray()
    {
        // Act
        var response = await _client.GetAsync("/api/files");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var files = await response.Content.ReadFromJsonAsync<FileMetadata[]>(_jsonOptions);
        files.Should().NotBeNull();
    }

    [Fact]
    public async Task ListFiles_WithFiles_ReturnsFileList()
    {
        // Arrange
        await File.WriteAllTextAsync(Path.Combine(_factory.TestDocsPath, "test1.md"), "# Test 1");
        await File.WriteAllTextAsync(Path.Combine(_factory.TestDocsPath, "test2.md"), "# Test 2");

        // Act
        var response = await _client.GetAsync("/api/files");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var files = await response.Content.ReadFromJsonAsync<FileMetadata[]>(_jsonOptions);
        files.Should().HaveCountGreaterThanOrEqualTo(2);
    }

    #endregion

    #region GET /api/files/{path}

    [Fact]
    public async Task GetFile_ExistingFile_ReturnsContent()
    {
        // Arrange
        var content = "# Hello World";
        await File.WriteAllTextAsync(Path.Combine(_factory.TestDocsPath, "hello.md"), content);

        // Act
        var response = await _client.GetAsync("/api/files/hello.md");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var fileContent = await response.Content.ReadFromJsonAsync<FileContent>(_jsonOptions);
        fileContent.Should().NotBeNull();
        fileContent!.Content.Should().Be(content);
        fileContent.Name.Should().Be("hello.md");
    }

    [Fact]
    public async Task GetFile_NonExistingFile_Returns404()
    {
        // Act
        var response = await _client.GetAsync("/api/files/nonexistent.md");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task GetFile_NestedPath_ReturnsContent()
    {
        // Arrange
        var subDir = Path.Combine(_factory.TestDocsPath, "docs");
        Directory.CreateDirectory(subDir);
        await File.WriteAllTextAsync(Path.Combine(subDir, "nested.md"), "# Nested");

        // Act
        var response = await _client.GetAsync("/api/files/docs/nested.md");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var fileContent = await response.Content.ReadFromJsonAsync<FileContent>(_jsonOptions);
        fileContent!.Path.Should().Be("docs/nested.md");
    }

    #endregion

    #region PUT /api/files/{path}

    [Fact]
    public async Task UpdateFile_NewFile_CreatesAndReturnsMetadata()
    {
        // Arrange
        var request = new UpdateFileRequest("# New Content");

        // Act
        var response = await _client.PutAsJsonAsync("/api/files/newfile.md", request);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var metadata = await response.Content.ReadFromJsonAsync<FileMetadata>(_jsonOptions);
        metadata.Should().NotBeNull();
        metadata!.Name.Should().Be("newfile.md");

        // Verify file was created
        var filePath = Path.Combine(_factory.TestDocsPath, "newfile.md");
        File.Exists(filePath).Should().BeTrue();
    }

    [Fact]
    public async Task UpdateFile_ExistingFile_UpdatesContent()
    {
        // Arrange
        var filePath = Path.Combine(_factory.TestDocsPath, "existing.md");
        await File.WriteAllTextAsync(filePath, "# Old");
        var request = new UpdateFileRequest("# Updated");

        // Act
        var response = await _client.PutAsJsonAsync("/api/files/existing.md", request);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await File.ReadAllTextAsync(filePath);
        content.Should().Be("# Updated");
    }

    #endregion

    #region DELETE /api/files/{path}

    [Fact]
    public async Task DeleteFile_ExistingFile_Returns204()
    {
        // Arrange
        var filePath = Path.Combine(_factory.TestDocsPath, "todelete.md");
        await File.WriteAllTextAsync(filePath, "# Delete me");

        // Act
        var response = await _client.DeleteAsync("/api/files/todelete.md");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NoContent);
        File.Exists(filePath).Should().BeFalse();
    }

    [Fact]
    public async Task DeleteFile_NonExistingFile_Returns404()
    {
        // Act
        var response = await _client.DeleteAsync("/api/files/nonexistent.md");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    #endregion

    #region Security Tests

    [Fact]
    public async Task GetFile_PathTraversalAttempt_Returns403Or404()
    {
        // Act - URL encoded path traversal
        var response = await _client.GetAsync("/api/files/..%2F..%2F..%2Fetc%2Fpasswd");

        // Assert - Should not succeed (either 403 or 404 is acceptable)
        response.StatusCode.Should().BeOneOf(HttpStatusCode.Forbidden, HttpStatusCode.NotFound);
    }

    #endregion
}
