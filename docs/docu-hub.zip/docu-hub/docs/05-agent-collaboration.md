# Agent Collaboration

> **Document**: 05 - Agent Collaboration
> **Audience**: All (System Analysts, Developers)

---

## 1. Overview

This document describes how the agents collaborate in the Renovo system, including their roles, responsibilities, and how they share information through the state management system.

---

## 2. Agent Roles and Responsibilities

### 2.1 Agent Summary Table

| Agent | Role | Model | Inputs | Outputs |
|-------|------|-------|--------|---------|
| Analysis Orchestrator | Workflow coordination | llama3.1:8b | Phase flags | Progress updates |
| Code Analyzer | Parse and analyze code | codestral:22b | Code files | Complexity, patterns, debt |
| Database Analyst | Schema analysis | llama3.1:70b | DDL scripts | Schema, relationships, migration plan |
| Document Analyst | Documentation mining | llama3.1:70b | Doc files | Features, requirements |
| Business Rule Extractor | Extract business rules | codestral:22b | Code patterns | Business rules catalog |
| Integration Mapper | Map integrations | llama3.1:70b | Code patterns | Integration inventory |
| System Architect | Architecture design | llama3.1:70b | All analysis | Target architecture |
| Requirements Writer | Documentation output | llama3.1:70b | All results | FR, NFR, BR, summary |

### 2.2 Agent Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AGENT HIERARCHY                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                    ┌───────────────────────────────┐                        │
│                    │   ANALYSIS ORCHESTRATOR       │                        │
│                    │   ┌───────────────────────┐   │                        │
│                    │   │ Responsibilities:     │   │                        │
│                    │   │ • Track workflow phase│   │                        │
│                    │   │ • Update progress     │   │                        │
│                    │   │ • Coordinate timing   │   │                        │
│                    │   └───────────────────────┘   │                        │
│                    └───────────────┬───────────────┘                        │
│                                    │                                        │
│            ┌───────────────────────┼───────────────────────┐                │
│            │                       │                       │                │
│            ▼                       ▼                       ▼                │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐          │
│  │  CODE ANALYZER  │    │DATABASE ANALYST │    │DOCUMENT ANALYST │          │
│  │  ┌───────────┐  │    │  ┌───────────┐  │    │  ┌───────────┐  │          │
│  │  │ Parse 4GL │  │    │  │ Parse DDL │  │    │  │ Categorize│  │          │
│  │  │ Parse VB  │  │    │  │ Map types │  │    │  │ Extract   │  │          │
│  │  │ Complexity│  │    │  │ Relations │  │    │  │ Coverage  │  │          │
│  │  └───────────┘  │    │  └───────────┘  │    │  └───────────┘  │          │
│  └────────┬────────┘    └────────┬────────┘    └────────┬────────┘          │
│           │                      │                      │                   │
│           │ code_analysis        │ database_schema      │ documented_       │
│           │ complexity_metrics   │ table_relationships  │ requirements      │
│           │ technical_debt       │ migration_plan       │ doc_coverage      │
│           │                      │                      │                   │
│           └──────────────────────┼──────────────────────┘                   │
│                                  │                                          │
│            ┌─────────────────────┼─────────────────────┐                    │
│            │                     │                     │                    │
│            ▼                     ▼                     ▼                    │
│  ┌─────────────────────┐  ┌─────────────────┐  ┌─────────────────────┐      │
│  │ BUSINESS RULE       │  │ INTEGRATION     │  │ CROSS-REFERENCE     │      │
│  │ EXTRACTOR           │  │ MAPPER          │  │ BUILDER             │      │
│  │  ┌─────────────┐    │  │  ┌───────────┐  │  │  ┌───────────────┐  │      │
│  │  │ Validation  │    │  │  │ HTTP/FTP  │  │  │  │ Code↔Table    │  │      │
│  │  │ Calculation │    │  │  │ MSMQ/SMTP │  │  │  │ Code↔Doc      │  │      │
│  │  │ Workflow    │    │  │  │ Criticality│  │  │  │ Visualization │  │     │
│  │  └─────────────┘    │  │  └───────────┘  │  │  └───────────────┘  │      │
│  └─────────┬───────────┘  └────────┬────────┘  └──────────┬──────────┘      │
│            │                       │                      │                 │
│            │ business_rules        │ integrations         │ cross_refs      │
│            │ rules_by_domain       │ integration_map      │ visualization   │
│            │                       │                      │                 │
│            └───────────────────────┼──────────────────────┘                 │
│                                    │                                        │
│                                    ▼                                        │
│                    ┌───────────────────────────────┐                        │
│                    │    SYSTEM ARCHITECT           │                        │
│                    │    ┌───────────────────────┐  │                        │
│                    │    │ • Current architecture│  │                        │
│                    │    │ • Target architecture │  │                        │
│                    │    │ • Migration strategy  │  │                        │
│                    │    │ • Tech stack          │  │                        │
│                    │    └───────────────────────┘  │                        │
│                    └───────────────┬───────────────┘                        │
│                                    │                                        │
│                                    │ enterprise_architecture                │
│                                    │ component_catalog                      │
│                                    │ migration_strategy                     │
│                                    │                                        │
│                                    ▼                                        │
│                    ┌───────────────────────────────┐                        │
│                    │   REQUIREMENTS WRITER         │                        │
│                    │   ┌───────────────────────┐   │                        │
│                    │   │ • Functional Reqs     │   │                        │
│                    │   │ • Non-Functional Reqs │   │                        │
│                    │   │ • Business Rules      │   │                        │
│                    │   │ • Data Dictionary     │   │                        │
│                    │   │ • Traceability Matrix │   │                        │
│                    │   │ • Executive Summary   │   │                        │
│                    │   └───────────────────────┘   │                        │
│                    └───────────────────────────────┘                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Information Flow Between Agents

### 3.1 State-Based Communication

All agents communicate through a **shared state object** (`LegacyAnalysisState`). There are no direct agent-to-agent calls.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    STATE-BASED COMMUNICATION                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      SHARED STATE                                   │    │
│  │                                                                     │    │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │    │
│  │  │ Project     │ │ Ingestion   │ │ Code        │ │ Database    │    │    │
│  │  │ Info        │ │ Results     │ │ Analysis    │ │ Analysis    │    │    │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │    │
│  │                                                                     │    │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │    │
│  │  │ Document    │ │ Business    │ │ Integration │ │ Cross       │    │    │
│  │  │ Analysis    │ │ Rules       │ │ Map         │ │ References  │    │    │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │    │
│  │                                                                     │    │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │    │
│  │  │ Architecture│ │ Requirements│ │ Messages    │ │ Errors      │    │    │
│  │  │ Synthesis   │ │ Output      │ │ (History)   │ │ & Warnings  │    │    │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│         Agent 1                Agent 2                Agent 3               │
│            │                      │                      │                  │
│            │ READ                 │ READ                 │ READ             │
│            ▼                      ▼                      ▼                  │
│      ┌──────────┐          ┌──────────┐          ┌──────────┐               │
│      │ state.get│          │ state.get│          │ state.get│               │
│      │ ("input")│          │ ("input")│          │ ("input")│               │
│      └────┬─────┘          └────┬─────┘          └────┬─────┘               │
│           │ PROCESS             │ PROCESS             │ PROCESS             │
│           ▼                     ▼                     ▼                     │
│      ┌──────────┐          ┌──────────┐          ┌──────────┐               │
│      │ Agent    │          │ Agent    │          │ Agent    │               │
│      │ Logic    │          │ Logic    │          │ Logic    │               │
│      └────┬─────┘          └────┬─────┘          └────┬─────┘               │
│           │ WRITE               │ WRITE               │ WRITE               │
│           ▼                     ▼                     ▼                     │
│      ┌──────────┐          ┌──────────┐          ┌──────────┐               │
│      │ return { │          │ return { │          │ return { │               │
│      │  output: │          │  output: │          │  output: │               │
│      │  value   │          │  value   │          │  value   │               │
│      │ }        │          │ }        │          │ }        │               │
│      └────┬─────┘          └────┬─────┘          └────┬─────┘               │
│           │                     │                     │                     │
│           └─────────────────────┼─────────────────────┘                     │
│                                 │                                           │
│                                 ▼                                           │
│                    ┌────────────────────────┐                               │
│                    │ LangGraph merges all   │                               │
│                    │ outputs into state     │                               │
│                    └────────────────────────┘                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DATA FLOW DIAGRAM                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────┐                                                          │
│  │   INGEST      │                                                          │
│  │   NODE        │                                                          │
│  └───────┬───────┘                                                          │
│          │                                                                  │
│          │ files_ingested, file_inventory                                   │
│          │ code_collection_id                                               │
│          ▼                                                                  │
│  ┌───────────────┐                                                          │
│  │  DEAD CODE    │                                                          │
│  │  DETECT       │                                                          │
│  └───────┬───────┘                                                          │
│          │                                                                  │
│          │ dead_code_candidates, dead_code_files                            │
│          ▼                                                                  │
│  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐              │
│  │ CODE ANALYSIS │     │DATABASE ANAL. │     │DOCUMENT ANAL. │              │
│  │               │     │               │     │               │              │
│  │ Reads:        │     │ Reads:        │     │ Reads:        │              │
│  │ • file_inv.   │     │ • file_inv.   │     │ • file_inv.   │              │
│  │ • dead_code   │     │               │     │               │              │
│  │               │     │               │     │               │              │
│  │ Writes:       │     │ Writes:       │     │ Writes:       │              │
│  │ • code_summary│     │ • db_schema   │     │ • doc_features│              │
│  │ • complexity  │     │ • relations   │     │ • doc_coverage│              │
│  │ • patterns    │     │ • migration   │     │ • doc_reqs    │              │
│  │ • tech_debt   │     │               │     │               │              │
│  └───────┬───────┘     └───────┬───────┘     └───────┬───────┘              │
│          │                     │                     │                      │
│          │                     │                     │                      │
│          ▼                     ▼                     ▼                      │
│  ┌───────────────┐     ┌───────────────┐                                    │
│  │BUSINESS RULE  │     │ INTEGRATION   │                                    │
│  │EXTRACTOR      │     │ MAPPER        │                                    │
│  │               │     │               │                                    │
│  │ Reads:        │     │ Reads:        │                                    │
│  │ • code_summary│     │ • code_summary│                                    │
│  │ • patterns    │     │ • file_inv.   │                                    │
│  │               │     │               │                                    │
│  │ Writes:       │     │ Writes:       │                                    │
│  │ • biz_rules   │     │ • integrations│                                    │
│  │ • rules_domain│     │ • integ_map   │                                    │
│  └───────┬───────┘     └───────┬───────┘                                    │
│          │                     │                                            │
│          │                     │                                            │
│          └──────────┬──────────┘                                            │
│                     │                                                       │
│                     ▼                                                       │
│          ┌───────────────────────┐                                          │
│          │   CROSS-REFERENCE     │                                          │
│          │   BUILD               │                                          │
│          │                       │                                          │
│          │   Reads: ALL above    │                                          │
│          │   Writes: cross_refs  │                                          │
│          └───────────┬───────────┘                                          │
│                      │                                                      │
│                      ▼                                                      │
│          ┌───────────────────────┐                                          │
│          │   SYSTEM ARCHITECT    │                                          │
│          │                       │                                          │
│          │   Reads:              │                                          │
│          │   • ALL above         │                                          │
│          │   • user_requirements │                                          │
│          │                       │                                          │
│          │   Writes:             │                                          │
│          │   • enterprise_arch   │                                          │
│          │   • component_catalog │                                          │
│          │   • migration_strategy│                                          │
│          │   • tech_stack        │                                          │
│          └───────────┬───────────┘                                          │
│                      │                                                      │
│                      ▼                                                      │
│          ┌───────────────────────┐                                          │
│          │   REQUIREMENTS WRITER │                                          │
│          │                       │                                          │
│          │   Reads: ALL above    │                                          │
│          │                       │                                          │
│          │   Writes:             │                                          │
│          │   • functional_reqs   │                                          │
│          │   • non_func_reqs     │                                          │
│          │   • business_rules    │                                          │
│          │   • data_dictionary   │                                          │
│          │   • traceability      │                                          │
│          │   • exec_summary      │                                          │
│          └───────────────────────┘                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Agent Execution Patterns

### 4.1 Sequential Execution

All agents execute **sequentially** due to GPU memory constraints:

```
Timeline:
─────────────────────────────────────────────────────────────────────────────►
│                                                                            │
│ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐            │
│ │Inges│→│Dead │→│Code │→│ DB  │→│ Doc │→│ BR  │→│Integ│→│Cross│→ ...       │
│ │ t   │ │Code │ │Anal │ │Anal │ │Anal │ │Extr │ │Map  │ │Ref  │            │
│ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘            │
│                                                                            │
│ ONLY ONE AGENT ACTIVE AT A TIME (GPU constraint)                           │
─────────────────────────────────────────────────────────────────────────────►
```

### 4.2 Model Switching

When agents use different LLM models, the system manages model loading:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MODEL SWITCHING                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  CODE ANALYZER (codestral:22b)                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  1. Request model: codestral:22b                                    │    │
│  │  2. Ollama loads model (if not already loaded)                      │    │
│  │  3. Execute inference                                               │    │
│  │  4. Keep model loaded                                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  DATABASE ANALYST (llama3.1:70b)                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  1. Request model: llama3.1:70b                                     │    │
│  │  2. Ollama unloads codestral:22b                                    │    │
│  │  3. Ollama loads llama3.1:70b (wait for warmup)                     │    │
│  │  4. Execute inference                                               │    │
│  │  5. Keep model loaded                                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  DOCUMENT ANALYST (llama3.1:70b)                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  1. Request model: llama3.1:70b                                     │    │
│  │  2. Model already loaded (reuse)                                    │    │
│  │  3. Execute inference immediately                                   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.3 Tool Sharing

Agents share common tools:

| Tool | Used By |
|------|---------|
| RAGSearchTool | Code Analyzer, Document Analyst, System Architect |
| CodeAnalysisTool | Code Analyzer, System Analyst |
| DatabaseAnalysisTool | Database Analyst |
| CodeGenerationTool | (Future: Development agents) |

---

## 5. Collaboration Patterns

### 5.1 Knowledge Accumulation

Each agent builds on previous agents' work:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     KNOWLEDGE ACCUMULATION                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Agent 1: CODE ANALYZER                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Discovers:                                                         │    │
│  │  • 47 files, 15,234 lines                                           │    │
│  │  • 23 procedures, 15 functions                                      │    │
│  │  • Pattern: "God procedure" anti-pattern in CustomerMain            │    │
│  │  • Tech debt: 12 items                                              │    │
│  │                                                                     │    │
│  │  Adds to state: code_analysis_summary, complexity_metrics           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Agent 2: DATABASE ANALYST                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Reads: code_analysis_summary (knows about procedures)              │    │
│  │                                                                     │    │
│  │  Discovers:                                                         │    │
│  │  • 15 tables, 3 views, 8 stored procedures                          │    │
│  │  • Relationships: CUSTOMER → CUSTOMER_ADDRESS (1:N)                 │    │
│  │  • CUSTOMER table accessed by CustomerMain procedure                │    │
│  │                                                                     │    │
│  │  Adds to state: database_schema, table_relationships                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Agent 3: BUSINESS RULE EXTRACTOR                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Reads: code_analysis (knows where business logic is)               │    │
│  │  Reads: database_schema (knows entity names)                        │    │
│  │                                                                     │    │
│  │  Discovers:                                                         │    │
│  │  • BR-001: "Customer ID must be positive" (from CustomerValidation) │    │
│  │  • BR-002: "Address required for active customers"                  │    │
│  │  • Confidence: 0.85 (high)                                          │    │
│  │                                                                     │    │
│  │  Adds to state: business_rules_catalog                              │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Agent 4: SYSTEM ARCHITECT                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Reads: ALL previous analysis                                       │    │
│  │                                                                     │    │
│  │  Synthesizes:                                                       │    │
│  │  • Current: 2-tier monolith with embedded business logic            │    │
│  │  • Target: Microservices with Customer API                          │    │
│  │  • Migration: Strangler Fig pattern (gradual replacement)           │    │
│  │                                                                     │    │
│  │  Adds to state: enterprise_architecture, migration_strategy         │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Agent 5: REQUIREMENTS WRITER                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Reads: ALL previous analysis                                       │    │
│  │                                                                     │    │
│  │  Produces:                                                          │    │
│  │  • FR-001: Customer Management (from CustomerMain procedure)        │    │
│  │  • NFR-001: Response time < 2 seconds                               │    │
│  │  • BR-001: Customer ID must be positive (validated)                 │    │
│  │  • Traceability: FR-001 → CustomerMain → CUSTOMER table             │    │
│  │                                                                     │    │
│  │  Final output: Requirements documentation                           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Error Propagation and Handling

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     ERROR HANDLING                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  IF any agent encounters an error:                                          │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  RECOVERABLE ERROR (e.g., parse failure on single file)             │    │
│  │                                                                     │    │
│  │  1. Log error with context                                          │    │
│  │  2. Add to state.warnings[]                                         │    │
│  │  3. Continue analysis with remaining files                          │    │
│  │  4. Note: "Analysis incomplete for CustomerBad.4gl"                 │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  CRITICAL ERROR (e.g., Qdrant unavailable)                          │    │
│  │                                                                     │    │
│  │  1. Log error with full stack trace                                 │    │
│  │  2. Add to state.errors[]                                           │    │
│  │  3. Try fallback (if available)                                     │    │
│  │     - RAG unavailable → Continue without vector search              │    │
│  │     - LLM unavailable → Use mock data                               │    │
│  │  4. Continue to next node                                           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Downstream agents check for errors:                                        │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  if state.get("errors"):                                            │    │
│  │      # Adjust expectations                                          │    │
│  │      # Use partial data where available                             │    │
│  │      # Mark outputs as "incomplete" in metadata                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Knowledge Graph Integration

### 6.1 Graph Building

Multiple agents contribute to the knowledge graph:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    KNOWLEDGE GRAPH BUILDING                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  CODE ANALYZER adds:                                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Nodes: PROCEDURE:CustomerMain, PROCEDURE:ValidateCustomer          │    │
│  │  Edges: CustomerMain --CALLS--> ValidateCustomer                    │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  DATABASE ANALYST adds:                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Nodes: TABLE:CUSTOMER, TABLE:CUSTOMER_ADDRESS                      │    │
│  │  Edges: CUSTOMER --FK_ADDRESS--> CUSTOMER_ADDRESS                   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  CROSS-REFERENCE BUILDER adds:                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Edges: CustomerMain --READS--> CUSTOMER                            │    │
│  │  Edges: ValidateCustomer --WRITES--> CUSTOMER                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  RESULT: Unified Knowledge Graph                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                                                                     │    │
│  │     ┌──────────────┐                                                │    │
│  │     │ CustomerMain │                                                │    │
│  │     │ (PROCEDURE)  │                                                │    │
│  │     └──────┬───────┘                                                │    │
│  │            │                                                        │    │
│  │     ┌──────┴──────┐                                                 │    │
│  │     │ CALLS       │ READS                                           │    │
│  │     ▼             ▼                                                 │    │
│  │  ┌──────────────┐  ┌──────────────┐                                 │    │
│  │  │ValidateCust. │  │   CUSTOMER   │◄─────FK_ADDRESS                 │    │
│  │  │ (PROCEDURE)  │  │   (TABLE)    │                                 │    │
│  │  └──────┬───────┘  └──────────────┘     ┌──────────────┐            │    │
│  │         │ WRITES                        │CUSTOMER_ADDR │            │    │
│  │         └───────────────────────────────│   (TABLE)    │            │    │
│  │                                         └──────────────┘            │    │
│  │                                                                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Summary

### 7.1 Key Collaboration Principles

1. **State-based communication**: All data passes through shared state
2. **Sequential execution**: One agent at a time (GPU constraint)
3. **Cumulative knowledge**: Each agent builds on previous results
4. **Graceful degradation**: Errors don't halt the workflow
5. **Knowledge graph**: Unified view of system relationships

### 7.2 Agent Dependencies

| Agent | Depends On | Required Fields |
|-------|------------|-----------------|
| Dead Code Detect | Ingest | file_inventory |
| Code Analyzer | Ingest, Dead Code | file_inventory, dead_code_files |
| Database Analyst | Ingest | file_inventory (SQL files) |
| Document Analyst | Ingest | file_inventory (docs) |
| Business Rule Extractor | Code Analyzer | code_analysis_summary |
| Integration Mapper | Code Analyzer | code_analysis_summary |
| Cross-Reference | All above | code, database, documents |
| System Architect | All above | All analysis results |
| Requirements Writer | All above | All analysis + architecture |
