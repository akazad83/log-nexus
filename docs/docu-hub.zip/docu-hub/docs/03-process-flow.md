# Process Flow

> **Document**: 03 - Process Flow
> **Audience**: System Analysts, Project Managers

---

## 1. End-to-End Process Overview

This document describes the complete process flow from project creation to analysis output, including all state transitions and decision points.

---

## 2. Project Lifecycle

### 2.1 Project Status Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PROJECT STATUS FLOW                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│      ┌──────────┐                                                           │
│      │ CREATED  │  ◄── POST /projects (Create new project)                  │
│      └────┬─────┘                                                           │
│           │                                                                 │
│           │ POST /projects/{id}/uploads/code (First file upload)            │
│           ▼                                                                 │
│      ┌──────────┐                                                           │
│      │UPLOADING │  ◄── Can upload more files (code, DB, docs)               │
│      └────┬─────┘                                                           │
│           │                                                                 │
│           │ POST /projects/{id}/analysis/start                              │
│           ▼                                                                 │
│      ┌──────────┐                                                           │
│      │ANALYZING │  ◄── LangGraph workflow running (13 nodes)                │
│      └────┬─────┘                                                           │
│           │                                                                 │
│           ├─────────────────────┐                                           │
│           │ (Success)           │ (Failure)                                 │
│           ▼                     ▼                                           │
│      ┌──────────┐         ┌──────────┐                                      │
│      │ PLANNING │         │  FAILED  │ ◄── Can retry analysis               │
│      └────┬─────┘         └────┬─────┘                                      │
│           │                    │                                            │
│           │                    │ POST /projects/{id}/analysis/start         │
│           │                    └──────────────┐                             │
│           │                                   │                             │
│           │ (Future: Planning phase)          │                             │
│           ▼                                   │                             │
│      ┌──────────┐                             │                             │
│      │COMPLETED │ ◄───────────────────────────┘                             │
│      └──────────┘                                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Status Descriptions

| Status | Description | Allowed Actions |
|--------|-------------|-----------------|
| CREATED | Project exists, no files uploaded | Upload files |
| UPLOADING | Files have been uploaded | Upload more files, Start analysis |
| ANALYZING | Analysis workflow is running | Poll status |
| PLANNING | Analysis complete, ready for planning | View results, Generate reports |
| FAILED | Analysis encountered errors | Retry analysis, Upload more files |
| COMPLETED | All phases finished | View results, Generate reports |

---

## 3. Upload Process Flow

### 3.1 File Upload Sequence

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          FILE UPLOAD PROCESS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  User Action: Upload legacy code files                                      │
│                                                                             │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐                        │
│  │  4GL Files  │   │ VB.NET Files│   │  SQL Files  │                        │
│  │ (.4gl .per) │   │ (.vb .aspx) │   │ (.sql .ddl) │                        │
│  └──────┬──────┘   └──────┬──────┘   └──────┬──────┘                        │
│         │                 │                 │                               │
│         └────────────────┬┴─────────────────┘                               │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  POST /api/v1/projects/{id}/uploads/code                              │  │
│  │  Content-Type: multipart/form-data                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  VALIDATION                                                           │  │
│  │  ├── Project exists?                                                  │  │
│  │  ├── Project status allows uploads?                                   │  │
│  │  └── Files have valid extensions?                                     │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  FOR EACH FILE:                                                       │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐  │  │
│  │  │  1. Generate unique filename:                                   │  │  │
│  │  │     {timestamp}_{sanitized_original_name}                       │  │  │
│  │  │                                                                 │  │  │
│  │  │  2. Create storage path:                                        │  │  │
│  │  │     {UPLOAD_DIR}/{project_id}/code/{filename}                   │  │  │
│  │  │                                                                 │  │  │
│  │  │  3. Save file to disk                                           │  │  │
│  │  │                                                                 │  │  │
│  │  │  4. Create database record:                                     │  │  │
│  │  │     UploadedFile(project_id, filename, path, size, type)        │  │  │
│  │  │                                                                 │  │  │
│  │  │  5. Update project status if first file:                        │  │  │
│  │  │     project.status = UPLOADING                                  │  │  │
│  │  └─────────────────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  RESPONSE: List of uploaded files with metadata                       │  │
│  │  [                                                                    │  │
│  │    {id: 1, filename: "...", file_type: "code", file_size: 45230},     │  │
│  │    {id: 2, filename: "...", file_type: "code", file_size: 12045},     │  │
│  │    ...                                                                │  │
│  │  ]                                                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Upload Categories

| Category | Endpoint | File Types | Purpose |
|----------|----------|------------|---------|
| Code | `/uploads/code` | .4gl, .per, .rep, .vb, .aspx, .asmx | Application logic |
| Database | `/uploads/database` | .sql, .ddl, .prc, .sp, .fnc, .trg | Schema definitions |
| Documentation | `/uploads/documentation` | .md, .txt, .pdf, .doc, .docx | Existing documentation |

---

## 4. Analysis Workflow Process

### 4.1 Analysis Trigger Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      ANALYSIS TRIGGER PROCESS                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  POST /api/v1/projects/{id}/analysis/start                                  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  PRE-CONDITIONS CHECK                                                 │  │
│  │                                                                       │  │
│  │  ┌─────────────────────┐    ┌─────────────────────┐                   │  │
│  │  │ Project exists?     │───▶│ Status = UPLOADING  │                  │  │
│  │  │                     │ NO │ or FAILED?          │                   │  │
│  │  │       ▼ YES         │    │       ▼ YES         │                   │  │
│  │  │  ┌─────────────┐    │    │  ┌─────────────┐    │                   │  │
│  │  │  │ Continue    │    │    │  │ Continue    │    │                   │  │
│  │  │  └─────────────┘    │    │  └─────────────┘    │                   │  │
│  │  │                     │    │       │ NO          │                   │  │
│  │  │       │ NO          │    │       ▼             │                   │  │
│  │  │       ▼             │    │  ┌─────────────┐    │                   │  │
│  │  │  ┌─────────────┐    │    │  │ 400 Error:  │    │                   │  │
│  │  │  │ 404 Error   │    │    │  │ Invalid     │    │                   │  │
│  │  │  └─────────────┘    │    │  │ status      │    │                   │  │
│  │  └─────────────────────┘    │  └─────────────┘    │                   │  │
│  │                             └─────────────────────┘                   │  │
│  │                                                                       │  │
│  │  ┌─────────────────────┐                                              │  │
│  │  │ Has uploaded files? │                                              │  │
│  │  │                     │                                              │  │
│  │  │       ▼ YES         │                                              │  │
│  │  │  ┌─────────────┐    │                                              │  │
│  │  │  │ Continue    │    │                                              │  │
│  │  │  └─────────────┘    │                                              │  │
│  │  │                     │                                              │  │
│  │  │       │ NO          │                                              │  │
│  │  │       ▼             │                                              │  │
│  │  │  ┌─────────────┐    │                                              │  │
│  │  │  │ 400 Error:  │    │                                              │  │
│  │  │  │ No files    │    │                                              │  │
│  │  │  └─────────────┘    │                                              │  │
│  │  └─────────────────────┘                                              │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  UPDATE PROJECT STATUS: ANALYZING                                     │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  QUEUE CELERY TASK                                                    │  │
│  │  task = run_analysis.delay(project_id)                                │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  RESPONSE (202 ACCEPTED)                                              │  │
│  │  {                                                                    │  │
│  │    "task_id": "abc-123-def-456",                                      │  │
│  │    "status": "pending",                                               │  │
│  │    "message": "Analysis task queued",                                 │  │
│  │    "progress": 0.0                                                    │  │
│  │  }                                                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 LangGraph Workflow Execution

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    LANGGRAPH WORKFLOW EXECUTION                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Celery Worker picks up task from Redis queue                               │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  INITIALIZE STATE                                                     │  │
│  │  create_initial_analysis_state(                                       │  │
│  │    project_id, project_name, sub_systems,                             │  │
│  │    code_path, db_path, doc_path, tech_stack                           │  │
│  │  )                                                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 1: INGEST (Progress: 0% → 10%)                                  │  │
│  │  ├── Scan uploaded file directories                                   │  │
│  │  ├── Categorize files by type (4GL, VB.NET, SQL, docs)                │  │
│  │  ├── Chunk code at semantic boundaries                                │  │
│  │  ├── Generate embeddings via nomic-embed-text                         │  │
│  │  └── Store vectors in Qdrant                                          │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 2: DEAD CODE DETECTION (Progress: 10% → 15%)                    │  │
│  │  ├── Build procedure call graph                                       │  │
│  │  ├── Identify unreferenced code                                       │  │
│  │  └── Flag dead code candidates for exclusion                          │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 3: CODE ANALYSIS (Progress: 15% → 30%)                          │  │
│  │  ├── Parse 4GL and VB.NET with language-specific parsers              │  │
│  │  ├── Extract procedures, functions, classes                           │  │
│  │  ├── Calculate cyclomatic complexity                                  │  │
│  │  ├── Detect patterns and anti-patterns (LLM: codestral:22b)           │  │
│  │  └── Identify technical debt and security issues                      │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 4: DATABASE ANALYSIS (Progress: 30% → 45%)                      │  │
│  │  ├── Parse Ingres DDL scripts                                         │  │
│  │  ├── Extract tables, views, stored procedures, triggers               │  │
│  │  ├── Map relationships (foreign keys, implicit refs)                  │  │
│  │  ├── Plan migration to target DB (LLM: llama3.1:70b)                  │  │
│  │  └── Generate type mappings (Ingres → PostgreSQL)                     │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 5: DOCUMENT ANALYSIS (Progress: 45% → 55%)                      │  │
│  │  ├── Categorize documents (feature, design, requirements)             │  │
│  │  ├── Extract features and requirements (LLM: llama3.1:70b)            │  │
│  │  ├── Identify design decisions and change history                     │  │
│  │  └── Calculate documentation coverage per sub-system                  │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 6: BUSINESS RULE EXTRACTION (Progress: 55% → 65%)               │  │
│  │  ├── Scan procedures for business logic patterns                      │  │
│  │  ├── Extract validation, calculation, workflow rules                  │  │
│  │  ├── Calculate confidence scores (0.0-1.0)                            │  │
│  │  ├── Flag low-confidence rules for SME review                         │  │
│  │  └── Organize rules by business domain                                │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 7: INTEGRATION MAPPING (Progress: 65% → 72%)                    │  │
│  │  ├── Detect integration patterns (HTTP, FTP, MSMQ, SMTP)              │  │
│  │  ├── Classify by type and direction (inbound/outbound)                │  │
│  │  ├── Assess criticality based on business context                     │  │
│  │  └── Create integration inventory                                     │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 8: CROSS-REFERENCE (Progress: 72% → 78%)                        │  │
│  │  ├── Build code-to-database references (reads/writes)                 │  │
│  │  ├── Build code-to-documentation references                           │  │
│  │  ├── Detect procedure call chains                                     │  │
│  │  └── Generate visualization data (nodes and edges)                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 9: KNOWLEDGE GRAPH FINALIZE (Progress: 78% → 80%)               │  │
│  │  ├── Export knowledge graph to JSON                                   │  │
│  │  └── Create timestamped snapshot for persistence                      │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 10: SYNTHESIS (Progress: 80% → 88%)                             │  │
│  │  ├── Analyze current legacy architecture                              │  │
│  │  ├── Design target modern architecture (LLM: llama3.1:70b)            │  │
│  │  ├── Map legacy components to modern equivalents                      │  │
│  │  ├── Define technology stack recommendations                          │  │
│  │  └── Plan migration strategy (Strangler Fig, Big Bang, etc.)          │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 11: REQUIREMENTS GENERATION (Progress: 88% → 95%)               │  │
│  │  ├── Generate Functional Requirements (FR-001, FR-002, ...)           │  │
│  │  ├── Generate Non-Functional Requirements (NFR-001, NFR-002, ...)     │  │
│  │  ├── Compile Business Rules Catalog (BR-001, BR-002, ...)             │  │
│  │  ├── Build Data Dictionary                                            │  │
│  │  ├── Create Traceability Matrix                                       │  │
│  │  └── Generate Executive Summary (LLM: llama3.1:70b)                   │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 12: SME PREPARATION (Progress: 95% → 98%)                       │  │
│  │  ├── Compile validation packets per sub-system                        │  │
│  │  ├── Flag items needing SME review                                    │  │
│  │  └── Generate validation questions                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  NODE 13: OUTPUT (Progress: 98% → 100%)                               │  │
│  │  ├── Set analysis_complete = True                                     │  │
│  │  ├── Set analysis_completed_at = now()                                │  │
│  │  └── Return final state                                               │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  SAVE RESULTS TO DATABASE                                             │  │
│  │  ├── Create AnalysisResult record                                     │  │
│  │  └── Update project.status = PLANNING                                 │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Results Retrieval Process

### 5.1 Status Polling Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      STATUS POLLING PROCESS                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Client polls at regular intervals (e.g., every 2 seconds)                  │
│                                                                             │
│  GET /api/v1/tasks/{task_id}                                                │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  Query Celery task state from Redis                                   │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│              ┌───────────┴───────────┐                                      │
│              │                       │                                      │
│              ▼                       ▼                                      │
│  ┌───────────────────┐   ┌───────────────────┐                              │
│  │  PENDING/STARTED  │   │  SUCCESS/FAILURE  │                              │
│  │                   │   │                   │                              │
│  │  {                │   │  {                │                              │
│  │    "task_id": ... │   │    "task_id": ... │                              │
│  │    "status":      │   │    "status":      │                              │
│  │      "STARTED",   │   │      "SUCCESS",   │                              │
│  │    "ready": false,│   │    "ready": true, │                              │
│  │    "progress": 45 │   │    "result": {...}│                              │
│  │  }                │   │  }                │                              │
│  │                   │   │                   │                              │
│  │  Continue polling │   │  Fetch results    │                              │
│  └───────────────────┘   └───────────────────┘                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Results Retrieval Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     RESULTS RETRIEVAL PROCESS                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  GET /api/v1/projects/{id}/analysis                                         │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  Query AnalysisResult from PostgreSQL                                 │  │
│  │  WHERE project_id = {id}                                              │  │
│  │  ORDER BY created_at DESC                                             │  │
│  │  LIMIT 1                                                              │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  RESPONSE: AnalysisResultResponse                                     │  │
│  │  {                                                                    │  │
│  │    "id": 789,                                                         │  │
│  │    "project_id": 123,                                                 │  │
│  │    "code_summary": {                                                  │  │
│  │      "total_files": 47,                                               │  │
│  │      "total_lines": 15234,                                            │  │
│  │      "languages": {...},                                              │  │
│  │      "complexity_metrics": {...}                                      │  │
│  │    },                                                                 │  │
│  │    "database_schema": {...},                                          │  │
│  │    "requirements": {                                                  │  │
│  │      "functional": [...],                                             │  │
│  │      "non_functional": [...],                                         │  │
│  │      "business_rules": [...]                                          │  │
│  │    },                                                                 │  │
│  │    "architecture": {...},                                             │  │
│  │    "analysis_summary": "...",                                         │  │
│  │    "created_at": "2024-01-18T12:30:00Z"                               │  │
│  │  }                                                                    │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Error Handling and Recovery

### 6.1 Error Recovery Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       ERROR RECOVERY FLOW                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Analysis fails at any node                                                 │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  CELERY TASK ERROR HANDLING                                           │  │
│  │  ├── Log detailed error information                                   │  │
│  │  ├── Set task state to FAILURE                                        │  │
│  │  └── Re-raise exception                                               │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  PROJECT STATUS UPDATE                                                │  │
│  │  project.status = FAILED                                              │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  USER OPTIONS                                                         │  │
│  │  ├── Upload additional/corrected files                                │  │
│  │  ├── POST /projects/{id}/analysis/start (retry)                       │  │
│  │  └── Check error details in task status                               │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                          │                                                  │
│                          ▼                                                  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  GRACEFUL DEGRADATION                                                 │  │
│  │  ├── If Qdrant unavailable → Continue with warnings                   │  │
│  │  ├── If Ollama unavailable → Use mock/fallback data                   │  │
│  │  └── If parser fails → Skip file, continue analysis                   │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Progress Tracking

### 7.1 Progress Update Points

| Node | Progress Start | Progress End | Duration Estimate |
|------|----------------|--------------|-------------------|
| INGEST | 0% | 10% | 2-5 min |
| DEAD_CODE_DETECT | 10% | 15% | 1-2 min |
| CODE_ANALYSIS | 15% | 30% | 5-10 min |
| DATABASE_ANALYSIS | 30% | 45% | 5-10 min |
| DOCUMENT_ANALYSIS | 45% | 55% | 3-5 min |
| BUSINESS_RULE_EXTRACTION | 55% | 65% | 5-8 min |
| INTEGRATION_MAPPING | 65% | 72% | 3-5 min |
| CROSS_REFERENCE | 72% | 78% | 2-3 min |
| GRAPH_FINALIZE | 78% | 80% | 1 min |
| SYNTHESIS | 80% | 88% | 5-8 min |
| REQUIREMENTS | 88% | 95% | 5-10 min |
| SME_PREP | 95% | 98% | 1-2 min |
| OUTPUT | 98% | 100% | < 1 min |

**Total Estimated Duration**: 40-70 minutes (depending on codebase size)

---

## 8. Summary

The Renovo analysis process follows these key stages:

1. **Project Setup**: Create project and upload legacy files
2. **Analysis Trigger**: Start analysis via API (queued to Celery)
3. **Workflow Execution**: 13-node LangGraph workflow processes files
4. **Progress Monitoring**: Poll task status for real-time updates
5. **Results Retrieval**: Fetch comprehensive analysis results via API

Key characteristics:
- **Asynchronous**: Long-running analysis doesn't block API
- **Resilient**: Graceful degradation when services unavailable
- **Observable**: Real-time progress tracking via task polling
- **Recoverable**: Failed analyses can be retried
