# Sequence Diagrams

> **Document**: 08 - Sequence Diagrams
> **Audience**: All (System Analysts, Developers)

---

## 1. Overview

This document provides visual sequence diagrams (text-based) showing the key interactions in the Renovo analysis system.

---

## 2. File Upload Sequence

```
┌────────┐     ┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌────────────┐
│ Client │     │ FastAPI │     │UploadService│     │  FileSystem  │     │ PostgreSQL │
└───┬────┘     └────┬────┘     └──────┬──────┘     └──────┬───────┘     └─────┬──────┘
    │               │                 │                   │                   │
    │ POST /uploads/code              │                   │                   │
    │ (multipart/form-data)           │                   │                   │
    │──────────────>│                 │                   │                   │
    │               │                 │                   │                   │
    │               │ validate project│                   │                   │
    │               │────────────────────────────────────────────────────────>│
    │               │                 │                   │          project  │
    │               │<────────────────────────────────────────────────────────│
    │               │                 │                   │                   │
    │               │ save_multiple_files(files)          │                   │
    │               │────────────────>│                   │                   │
    │               │                 │                   │                   │
    │               │                 │ FOR EACH file:    │                   │
    │               │                 │ ┌───────────────────────────────────┐ │
    │               │                 │ │ mkdir(project_id/code/)           │ │
    │               │                 │ │──────────────────>│               │ │
    │               │                 │ │                   │               │ │
    │               │                 │ │ write(content)    │               │ │
    │               │                 │ │──────────────────>│               │ │
    │               │                 │ │                   │               │ │
    │               │                 │ │ INSERT uploaded_files             │ │
    │               │                 │ │────────────────────────────────────>│
    │               │                 │ │                   │               │ │
    │               │                 │ │ UPDATE project status=UPLOADING   │ │
    │               │                 │ │────────────────────────────────────>│
    │               │                 │ └───────────────────────────────────┘ │
    │               │                 │                   │                   │
    │               │ [files metadata]│                   │                   │
    │               │<────────────────│                   │                   │
    │               │                 │                   │                   │
    │ 200 OK        │                 │                   │                   │
    │ [{id, filename, size, ...}]     │                   │                   │
    │<──────────────│                 │                   │                   │
    │               │                 │                   │                   │
```

---

## 3. Analysis Start Sequence

```
┌────────┐     ┌─────────┐     ┌───────────────┐     ┌────────┐     ┌──────────────┐
│ Client │     │ FastAPI │     │AnalysisService│     │ Celery │     │    Redis     │
└───┬────┘     └────┬────┘     └───────┬───────┘     └───┬────┘     └──────┬───────┘
    │               │                  │                 │                  │
    │ POST /analysis/start             │                 │                  │
    │──────────────>│                  │                 │                  │
    │               │                  │                 │                  │
    │               │ start_analysis() │                 │                  │
    │               │─────────────────>│                 │                  │
    │               │                  │                 │                  │
    │               │                  │ validate project│                  │
    │               │                  │ (status, files) │                  │
    │               │                  │─────────────────────────────────────────>
    │               │                  │                 │                  │
    │               │                  │ UPDATE status = ANALYZING          │
    │               │                  │─────────────────────────────────────────>
    │               │                  │                 │                  │
    │               │                  │ run_analysis.delay(project_id)     │
    │               │                  │────────────────>│                  │
    │               │                  │                 │                  │
    │               │                  │                 │ LPUSH task queue │
    │               │                  │                 │─────────────────>│
    │               │                  │                 │                  │
    │               │                  │ task_id         │                  │
    │               │                  │<────────────────│                  │
    │               │                  │                 │                  │
    │               │ {task_id, status}│                 │                  │
    │               │<─────────────────│                 │                  │
    │               │                  │                 │                  │
    │ 202 ACCEPTED  │                  │                 │                  │
    │ {task_id: "...", status: "pending"}                │                  │
    │<──────────────│                  │                 │                  │
    │               │                  │                 │                  │
```

---

## 4. Analysis Execution Sequence

```
┌───────────────┐  ┌──────────┐  ┌──────────────┐  ┌────────┐  ┌────────┐  ┌────────┐
│ Celery Worker │  │ LangGraph│  │    Agents    │  │ Qdrant │  │ Ollama │  │   DB   │
└───────┬───────┘  └────┬─────┘  └──────┬───────┘  └───┬────┘  └───┬────┘  └───┬────┘
        │               │               │              │           │           │
        │ run_analysis(project_id)      │              │           │           │
        │               │               │              │           │           │
        │ get project details           │              │           │           │
        │─────────────────────────────────────────────────────────────────────>│
        │               │               │              │           │           │
        │ create_initial_state()        │              │           │           │
        │──────────────>│               │              │           │           │
        │               │               │              │           │           │
        │ graph.ainvoke(state)          │              │           │           │
        │──────────────>│               │              │           │           │
        │               │               │              │           │           │
        │               │ NODE 1: INGEST│              │           │           │
        │               │──────────────>│              │           │           │
        │               │               │ read files   │           │           │
        │               │               │──────────────────────────────────────>
        │               │               │ chunk code   │           │           │
        │               │               │              │           │           │
        │               │               │ embed chunks │           │           │
        │               │               │─────────────────────────>│           │
        │               │               │              │           │           │
        │               │               │ store vectors│           │           │
        │               │               │─────────────>│           │           │
        │               │               │              │           │           │
        │               │ state update  │              │           │           │
        │               │<──────────────│              │           │           │
        │               │               │              │           │           │
        │               │ NODE 2: DEAD_CODE_DETECT     │           │           │
        │               │──────────────>│              │           │           │
        │               │ state update  │              │           │           │
        │               │<──────────────│              │           │           │
        │               │               │              │           │           │
        │               │ NODE 3: CODE_ANALYSIS        │           │           │
        │               │──────────────>│              │           │           │
        │               │               │ RAG search   │           │           │
        │               │               │─────────────>│           │           │
        │               │               │ results      │           │           │
        │               │               │<─────────────│           │           │
        │               │               │              │           │           │
        │               │               │ LLM inference│           │           │
        │               │               │─────────────────────────>│           │
        │               │               │ analysis     │           │           │
        │               │               │<─────────────────────────│           │
        │               │               │              │           │           │
        │               │ state update  │              │           │           │
        │               │<──────────────│              │           │           │
        │               │               │              │           │           │
        │               │ ... (NODES 4-12) ...         │           │           │
        │               │               │              │           │           │
        │               │ NODE 13: OUTPUT              │           │           │
        │               │──────────────>│              │           │           │
        │               │ final state   │              │           │           │
        │               │<──────────────│              │           │           │
        │               │               │              │           │           │
        │ final_state   │               │              │           │           │
        │<──────────────│               │              │           │           │
        │               │               │              │           │           │
        │ INSERT analysis_results       │              │           │           │
        │─────────────────────────────────────────────────────────────────────>│
        │               │               │              │           │           │
        │ UPDATE project status=PLANNING│              │           │           │
        │─────────────────────────────────────────────────────────────────────>│
        │               │               │              │           │           │
        │ return {status: "completed"}  │              │           │           │
        │               │               │              │           │           │
```

---

## 5. Agent Node Execution Sequence

```
┌─────────────┐  ┌──────────────┐  ┌────────────────┐  ┌───────────────┐  ┌────────┐
│  LangGraph  │  │  Agent Node  │  │  Agent Class   │  │    Tools      │  │ Ollama │
└──────┬──────┘  └──────┬───────┘  └───────┬────────┘  └───────┬───────┘  └───┬────┘
       │                │                  │                   │              │
       │ invoke node    │                  │                   │              │
       │───────────────>│                  │                   │              │
       │                │                  │                   │              │
       │                │ read state       │                   │              │
       │                │ state.get(...)   │                   │              │
       │                │                  │                   │              │
       │                │ create agent     │                   │              │
       │                │─────────────────>│                   │              │
       │                │                  │                   │              │
       │                │                  │ use tool          │              │
       │                │                  │──────────────────>│              │
       │                │                  │                   │              │
       │                │                  │                   │ (if RAG)     │
       │                │                  │                   │ query Qdrant │
       │                │                  │                   │              │
       │                │                  │ tool result       │              │
       │                │                  │<──────────────────│              │
       │                │                  │                   │              │
       │                │                  │ build prompt      │              │
       │                │                  │                   │              │
       │                │                  │ LLM inference     │              │
       │                │                  │─────────────────────────────────>│
       │                │                  │                   │              │
       │                │                  │ response          │              │
       │                │                  │<─────────────────────────────────│
       │                │                  │                   │              │
       │                │                  │ parse response    │              │
       │                │                  │                   │              │
       │                │ analysis result  │                   │              │
       │                │<─────────────────│                   │              │
       │                │                  │                   │              │
       │                │ build return dict│                   │              │
       │                │ {field: value, ...}                  │              │
       │                │                  │                   │              │
       │ state update   │                  │                   │              │
       │<───────────────│                  │                   │              │
       │                │                  │                   │              │
       │ merge into     │                  │                   │              │
       │ shared state   │                  │                   │              │
       │                │                  │                   │              │
```

---

## 6. RAG Pipeline Sequence

```
┌──────────────┐  ┌───────────────┐  ┌────────────┐  ┌────────────┐  ┌────────┐
│ Ingestion    │  │ Code Chunker  │  │ Embeddings │  │ Qdrant     │  │ Ollama │
│ Pipeline     │  │               │  │ Service    │  │ VectorStore│  │        │
└──────┬───────┘  └───────┬───────┘  └─────┬──────┘  └─────┬──────┘  └───┬────┘
       │                  │                │               │             │
       │ FOR EACH file (batch=10):         │               │             │
       │                  │                │               │             │
       │ read file        │                │               │             │
       │                  │                │               │             │
       │ chunk(content)   │                │               │             │
       │─────────────────>│                │               │             │
       │                  │                │               │             │
       │                  │ identify       │               │             │
       │                  │ PROCEDURE/     │               │             │
       │                  │ FUNCTION       │               │             │
       │                  │ boundaries     │               │             │
       │                  │                │               │             │
       │                  │ extract        │               │             │
       │                  │ metadata       │               │             │
       │                  │ (params, type) │               │             │
       │                  │                │               │             │
       │ chunks[]         │                │               │             │
       │<─────────────────│                │               │             │
       │                  │                │               │             │
       │ embed_codes(chunks)               │               │             │
       │──────────────────────────────────>│               │             │
       │                  │                │               │             │
       │                  │                │ FOR EACH chunk (batch=10):  │
       │                  │                │               │             │
       │                  │                │ POST /api/embeddings        │
       │                  │                │──────────────────────────────>
       │                  │                │               │             │
       │                  │                │ 768-dim vector│             │
       │                  │                │<──────────────────────────────
       │                  │                │               │             │
       │ embeddings[]     │                │               │             │
       │<──────────────────────────────────│               │             │
       │                  │                │               │             │
       │ add_code_chunks(chunks_with_vectors)              │             │
       │──────────────────────────────────────────────────>│             │
       │                  │                │               │             │
       │                  │                │               │ upsert      │
       │                  │                │               │ collection  │
       │                  │                │               │             │
       │ success          │                │               │             │
       │<──────────────────────────────────────────────────│             │
       │                  │                │               │             │
```

---

## 7. Status Polling Sequence

```
┌────────┐     ┌─────────┐     ┌────────┐     ┌─────────┐
│ Client │     │ FastAPI │     │ Celery │     │  Redis  │
└───┬────┘     └────┬────┘     └───┬────┘     └────┬────┘
    │               │              │               │
    │ LOOP (every 2 seconds):      │               │
    │               │              │               │
    │ GET /tasks/{task_id}         │               │
    │──────────────>│              │               │
    │               │              │               │
    │               │ AsyncResult(task_id)         │
    │               │─────────────>│               │
    │               │              │               │
    │               │              │ GET task state│
    │               │              │──────────────>│
    │               │              │               │
    │               │              │ state data    │
    │               │              │<──────────────│
    │               │              │               │
    │               │ task status  │               │
    │               │<─────────────│               │
    │               │              │               │
    │ {status: "STARTED", progress: 45}            │
    │<──────────────│              │               │
    │               │              │               │
    │   ... continue polling ...   │               │
    │               │              │               │
    │ GET /tasks/{task_id}         │               │
    │──────────────>│              │               │
    │               │              │               │
    │               │ (repeat process)             │
    │               │              │               │
    │ {status: "SUCCESS", result: {...}}           │
    │<──────────────│              │               │
    │               │              │               │
    │ END POLLING   │              │               │
    │               │              │               │
    │ GET /projects/{id}/analysis  │               │
    │──────────────>│              │               │
    │               │              │               │
    │ analysis results             │               │
    │<──────────────│              │               │
    │               │              │               │
```

---

## 8. Full Workflow Timeline

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           FULL WORKFLOW TIMELINE                                    │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  TIME    ACTION                              STATUS         PROGRESS                │
│  ─────── ──────────────────────────────────  ─────────────  ────────                │
│                                                                                     │
│  T+0     POST /projects (create)             CREATED                                │
│          │                                                                          │
│  T+1     POST /uploads/code                  UPLOADING                              │
│          │                                                                          │
│  T+2     POST /uploads/database              UPLOADING                              │
│          │                                                                          │
│  T+3     POST /uploads/documentation         UPLOADING                              │
│          │                                                                          │
│  T+4     POST /analysis/start                ANALYZING      0%                      │
│          │                                                                          │
│          │ ┌─ Celery Worker picks up task ─────────────────────────────────┐        │
│          │ │                                                               │        │
│  T+5     │ │ INGEST node                    ANALYZING      0%→10%          │        │
│          │ │ • Scan files                                                  │        │
│          │ │ • Chunk code                                                  │        │
│          │ │ • Generate embeddings                                         │        │
│          │ │ • Store in Qdrant                                             │        │
│          │ │                                                               │        │
│  T+7     │ │ DEAD_CODE_DETECT node          ANALYZING      10%→15%         │        │
│          │ │                                                               │        │
│  T+8     │ │ CODE_ANALYSIS node             ANALYZING      15%→30%         │        │
│          │ │ • Parse 4GL/VB.NET                                            │        │
│          │ │ • Extract complexity                                          │        │
│          │ │ • LLM: codestral:22b                                          │        │
│          │ │                                                               │        │
│  T+15    │ │ DATABASE_ANALYSIS node         ANALYZING      30%→45%         │        │
│          │ │ • Parse DDL                                                   │        │
│          │ │ • Map relationships                                           │        │
│          │ │ • LLM: llama3.1:70b                                           │        │
│          │ │                                                               │        │
│  T+22    │ │ DOCUMENT_ANALYSIS node         ANALYZING      45%→55%         │        │
│          │ │                                                               │        │
│  T+27    │ │ BUSINESS_RULE_EXTRACTION       ANALYZING      55%→65%         │        │
│          │ │                                                               │        │
│  T+35    │ │ INTEGRATION_MAPPING            ANALYZING      65%→72%         │        │
│          │ │                                                               │        │
│  T+38    │ │ CROSS_REFERENCE                ANALYZING      72%→78%         │        │
│          │ │                                                               │        │
│  T+40    │ │ GRAPH_FINALIZE                 ANALYZING      78%→80%         │        │
│          │ │                                                               │        │
│  T+42    │ │ SYNTHESIS node                 ANALYZING      80%→88%         │        │
│          │ │ • Design architecture                                         │        │
│          │ │ • LLM: llama3.1:70b                                           │        │
│          │ │                                                               │        │
│  T+50    │ │ REQUIREMENTS node              ANALYZING      88%→95%         │        │
│          │ │ • Generate FR/NFR/BR                                          │        │
│          │ │ • LLM: llama3.1:70b                                           │        │
│          │ │                                                               │        │
│  T+60    │ │ SME_PREP node                  ANALYZING      95%→98%         │        │
│          │ │                                                               │        │
│  T+62    │ │ OUTPUT node                    ANALYZING      98%→100%        │        │
│          │ │                                                               │        │
│          │ │ Save results to DB                                            │        │
│          │ │ Update project status                                         │        │
│          │ └───────────────────────────────────────────────────────────────┘        │
│          │                                                                          │
│  T+63    Task SUCCESS                        PLANNING       100%                    │
│          │                                                                          │
│  T+64    GET /projects/{id}/analysis         PLANNING                               │
│          │                                                                          │
│          ▼ Results available                                                        │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘

ESTIMATED TOTAL TIME: 45-70 minutes (varies by codebase size)
```

---

## 9. Error Recovery Sequence

```
┌────────────────┐  ┌───────────────┐  ┌──────────────┐  ┌────────────┐
│ Celery Worker  │  │   LangGraph   │  │  Agent Node  │  │ PostgreSQL │
└───────┬────────┘  └───────┬───────┘  └──────┬───────┘  └─────┬──────┘
        │                   │                 │                 │
        │ run_analysis()    │                 │                 │
        │──────────────────>│                 │                 │
        │                   │                 │                 │
        │                   │ invoke node     │                 │
        │                   │────────────────>│                 │
        │                   │                 │                 │
        │                   │                 │ ERROR!          │
        │                   │                 │ (e.g., LLM timeout)
        │                   │                 │                 │
        │                   │                 │ try fallback    │
        │                   │                 │                 │
        │                   │                 │ IF fallback OK: │
        │                   │ state + warning │                 │
        │                   │<────────────────│                 │
        │                   │                 │                 │
        │                   │ continue to     │                 │
        │                   │ next node       │                 │
        │                   │                 │                 │
        │                   │ IF NO fallback: │                 │
        │                   │ state + error   │                 │
        │                   │<────────────────│                 │
        │                   │                 │                 │
        │                   │ continue to     │                 │
        │                   │ next node       │                 │
        │                   │ (degraded)      │                 │
        │                   │                 │                 │
        │                   │ .. complete ..  │                 │
        │                   │                 │                 │
        │ final state       │                 │                 │
        │ (includes errors) │                 │                 │
        │<──────────────────│                 │                 │
        │                   │                 │                 │
        │ IF fatal error:   │                 │                 │
        │                   │                 │                 │
        │ UPDATE status=FAILED                │                 │
        │───────────────────────────────────────────────────────>
        │                   │                 │                 │
        │ raise exception   │                 │                 │
        │                   │                 │                 │
```

---

## 10. Summary

These sequence diagrams illustrate:

1. **Upload Flow**: File storage and metadata creation
2. **Analysis Trigger**: Celery task queuing
3. **Execution Flow**: LangGraph workflow with 13 nodes
4. **Agent Pattern**: State reading, tool use, LLM calls, state updates
5. **RAG Pipeline**: Chunking, embedding, vector storage
6. **Polling Pattern**: Client status checking
7. **Timeline**: Expected duration for each phase
8. **Error Recovery**: Graceful degradation and fallbacks

Use these diagrams to understand system interactions and debug issues.
