# State Management

> **Document**: 06 - State Management
> **Audience**: Developers, Technical Architects

---

## 1. Overview

The Renovo Agent System uses **LangGraph's TypedDict-based state management** to pass data between agents. This document details the state schema, initialization, and data flow patterns.

---

## 2. State Architecture

### 2.1 State Class Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        STATE CLASS HIERARCHY                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  MessageState (Base)                                                │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  messages: Annotated[Sequence[BaseMessage], add_messages]   │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  └───────────────────────────────────┬─────────────────────────────────┘    │
│                                      │ extends                              │
│                                      ▼                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  BaseState                                                          │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  + project_id, project_name                                 │    │    │
│  │  │  + current_phase, current_agent                             │    │    │
│  │  │  + errors, warnings                                         │    │    │
│  │  │  + metadata                                                 │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  └───────────────────────────────────┬─────────────────────────────────┘    │
│                                      │ extends                              │
│                                      ▼                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  ProjectState                                                       │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  + codebase_path, codebase_languages                        │    │    │
│  │  │  + database_type, database_schema                           │    │    │
│  │  │  + target_backend, target_frontend, target_database         │    │    │
│  │  │  + analysis_complete, planning_complete                     │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  └───────────────────────────────────┬─────────────────────────────────┘    │
│                                      │ extends                              │
│                                      ▼                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  AnalysisState                                                      │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  + code_analyzer_complete, database_analyst_complete, ...   │    │    │
│  │  │  + functional_requirements, use_cases, business_rules       │    │    │
│  │  │  + architecture_components, data_flow                       │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  PARALLEL (RECOMMENDED):                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LegacyAnalysisState (~343 fields)                                  │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  Comprehensive state for 25-30 sub-system analysis          │    │    │
│  │  │  Includes all fields needed for full workflow               │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. LegacyAnalysisState Schema

### 3.1 Field Categories

| Category | Fields Count | Description |
|----------|--------------|-------------|
| Project Identification | 3 | project_id, project_name, project_description |
| Legacy System Info | 6 | tech_stack, sub_systems, paths |
| Workflow Tracking | 6 | current_phase, progress, etc. |
| Ingestion Results | 7 | files_ingested, collection_ids |
| Sub-System Analyses | 1 (complex) | Array of SubSystemAnalysis |
| Code Analysis | 13 | Files, complexity, patterns |
| Database Analysis | 17 | Tables, relationships, migration |
| Document Analysis | 9 | Documents, coverage, gaps |
| Cross-System Analysis | 5 | Dependencies, integrations |
| Architecture Synthesis | 10 | Enterprise architecture |
| Requirements Output | 10 | FR, NFR, BR, traceability |
| Final Outputs | 7 | Summary, recommendations |
| Error Handling | 2 | errors, warnings |
| Metadata | 4 | timestamps, token counts |

### 3.2 Key Field Definitions

```python
class LegacyAnalysisState(TypedDict, total=False):
    """
    Comprehensive state for legacy system analysis.
    total=False means all fields are optional.
    """

    # === MESSAGE HISTORY ===
    messages: Annotated[Sequence[BaseMessage], add_messages]

    # === PROJECT IDENTIFICATION ===
    project_id: str
    project_name: str
    project_description: str

    # === LEGACY SYSTEM INFO ===
    legacy_tech_stack: dict  # {"language": "4GL", "database": "Ingres", ...}
    total_sub_systems: int
    sub_system_list: list[str]
    code_base_path: str
    database_scripts_path: str
    documentation_path: str

    # === WORKFLOW TRACKING ===
    current_phase: str       # "ingestion", "code_analysis", "synthesis", etc.
    current_agent: str       # Name of active agent
    current_sub_system: str | None
    current_sub_system_index: int
    sub_systems_analyzed: int
    total_progress_percent: float  # 0.0 to 100.0

    # === INGESTION RESULTS ===
    ingestion_complete: bool
    files_ingested: int
    documents_ingested: int
    database_objects_ingested: int
    code_collection_id: str      # Qdrant collection ID
    database_collection_id: str
    documentation_collection_id: str

    # === PER SUB-SYSTEM ANALYSIS ===
    sub_system_analyses: list[SubSystemAnalysis]  # Detailed per-subsystem

    # === CODE ANALYSIS (AGGREGATED) ===
    code_analyst_complete: bool
    total_code_files: int
    total_lines_of_code: int
    total_procedures: int
    total_functions: int
    fourgl_files: int
    vbnet_files: int
    sql_files: int
    overall_complexity_score: float
    complexity_distribution: dict  # {"low": 60, "medium": 30, "high": 10}
    high_complexity_modules: list[dict]
    code_patterns: list[dict]
    anti_patterns: list[dict]
    technical_debt_items: list[dict]
    security_issues: list[dict]

    # === DATABASE ANALYSIS ===
    database_analyst_complete: bool
    database_source_type: str     # "scripts" | "connection" | "hybrid"
    database_target_type: str     # "postgresql" | "mysql" | etc.
    total_tables: int
    total_views: int
    total_stored_procedures: int
    total_triggers: int
    table_relationships: list[dict]
    cross_system_data_flows: list[dict]
    shared_tables: list[dict]
    enterprise_data_model: dict
    entity_definitions: list[dict]
    data_dictionary: dict
    ingres_specific_features: list[dict]
    migration_complexity: dict

    # === DOCUMENT ANALYSIS ===
    document_analyst_complete: bool
    total_documents: int
    documents_by_type: dict       # {"feature": 10, "design": 5, ...}
    documents_by_subsystem: dict
    documented_features: list[dict]
    documented_requirements: list[dict]
    design_decisions: list[dict]
    change_history: list[dict]
    documentation_coverage: dict
    undocumented_areas: list[dict]
    documentation_gaps: list[dict]

    # === CROSS-SYSTEM ANALYSIS ===
    cross_system_analysis_complete: bool
    system_dependencies: list[dict]
    integration_map: dict
    shared_components: list[dict]
    data_flow_diagram: dict
    critical_data_paths: list[dict]

    # === ARCHITECTURE SYNTHESIS ===
    architect_complete: bool
    enterprise_architecture: dict
    component_catalog: list[dict]
    layer_architecture: dict
    context_diagram: dict
    component_diagram: dict
    data_flow_diagram_detailed: dict
    deployment_view: dict
    architecture_patterns: list[str]
    architecture_issues: list[dict]
    modernization_candidates: list[dict]

    # === REQUIREMENTS OUTPUT ===
    requirements_writer_complete: bool
    functional_requirements: list[dict]     # FR-001, FR-002, ...
    functional_requirements_by_subsystem: dict
    non_functional_requirements: list[dict]  # NFR-001, NFR-002, ...
    performance_requirements: list[dict]
    security_requirements: list[dict]
    scalability_requirements: list[dict]
    business_rules_catalog: list[dict]       # BR-001, BR-002, ...
    business_rules_by_domain: dict
    requirements_traceability: dict

    # === FINAL OUTPUTS ===
    analysis_complete: bool
    executive_summary: str
    key_findings: list[dict]
    risk_assessment: dict
    recommendations: list[dict]
    output_directory: str
    generated_documents: list[str]

    # === ERROR HANDLING ===
    errors: list[dict]
    warnings: list[dict]

    # === METADATA ===
    metadata: dict
    analysis_started_at: str
    analysis_completed_at: str | None
    total_llm_calls: int
    total_tokens_used: int
```

### 3.3 SubSystemAnalysis Structure

```python
class SubSystemAnalysis(TypedDict, total=False):
    """Per-subsystem detailed analysis."""

    # Identification
    sub_system_id: str
    sub_system_name: str
    description: str
    estimated_age_years: int
    primary_technology: str

    # Code Analysis
    code_analysis: dict
    total_files: int
    total_lines: int
    procedures_count: int
    functions_count: int
    complexity_score: float
    business_logic_patterns: list[dict]

    # Database Analysis
    database_analysis: dict
    tables_owned: list[str]
    tables_shared: list[str]
    stored_procedures: list[str]
    key_entities: list[dict]
    data_relationships: list[dict]

    # Documentation Analysis
    documentation_analysis: dict
    documents_found: list[dict]
    coverage_score: float
    extracted_requirements: list[dict]
    undocumented_features: list[str]

    # Integration Points
    integration_points: dict
    inbound_dependencies: list[dict]
    outbound_dependencies: list[dict]
    shared_data: list[dict]

    # Generated Requirements
    functional_requirements: list[dict]
    non_functional_requirements: list[dict]
    business_rules: list[dict]

    # Status
    analysis_complete: bool
    analysis_errors: list[str]
```

---

## 4. State Initialization

### 4.1 Factory Function

**Source**: `backend/app/agents/state/legacy_analysis_state.py:345`

```python
def create_initial_analysis_state(
    project_id: str,
    project_name: str,
    sub_systems: list[str],
    code_base_path: str,
    database_scripts_path: str,
    documentation_path: str,
    legacy_tech_stack: dict | None = None,
) -> LegacyAnalysisState:
    """
    Create initial state for analysis workflow.

    All fields initialized with sensible defaults:
    - Lists: []
    - Dicts: {}
    - Booleans: False
    - Numbers: 0
    - Timestamps: now() or None
    """
```

### 4.2 Default Values

| Field Type | Default | Example |
|------------|---------|---------|
| Lists | `[]` | `errors: []` |
| Dicts | `{}` | `metadata: {}` |
| Booleans | `False` | `analysis_complete: False` |
| Numbers | `0` | `total_code_files: 0` |
| Progress | `0.0` | `total_progress_percent: 0.0` |
| Timestamps | `now()` or `None` | `analysis_started_at: "2024-01-18T..."` |

---

## 5. State Update Patterns

### 5.1 Node Return Pattern

Each node function returns a dictionary with only changed fields:

```python
async def code_analysis_node(state: LegacyAnalysisState) -> Dict[str, Any]:
    """
    Node function pattern:
    1. Read needed state
    2. Process data
    3. Return ONLY changed fields
    """

    # Read from state (with defaults)
    project_id = state.get("project_id", "")
    file_inventory = state.get("metadata", {}).get("file_inventory", {})

    # Process data
    analysis_result = await analyze_code(file_inventory)

    # Return only changed fields
    return {
        "current_phase": "code_analysis",
        "current_agent": "code_analyzer",
        "code_analyst_complete": True,
        "total_code_files": analysis_result.file_count,
        "overall_complexity_score": analysis_result.complexity,
        "code_patterns": analysis_result.patterns,
        "messages": state.get("messages", []) + [
            AIMessage(content="Code analysis completed")
        ],
    }
```

### 5.2 LangGraph State Merging

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       STATE MERGING PROCESS                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  BEFORE Node Execution:                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  State = {                                                          │    │
│  │    project_id: "123",                                               │    │
│  │    current_phase: "ingestion",                                      │    │
│  │    code_analyst_complete: False,                                    │    │
│  │    total_code_files: 0,                                             │    │
│  │    messages: [Message1, Message2],                                  │    │
│  │    ...                                                              │    │
│  │  }                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Node Returns:                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  {                                                                  │    │
│  │    current_phase: "code_analysis",  ◄── Changed                     │    │
│  │    code_analyst_complete: True,     ◄── Changed                     │    │
│  │    total_code_files: 47,            ◄── Changed                     │    │
│  │    messages: [..., Message3],       ◄── Appended                    │    │
│  │  }                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼ LangGraph Merges                            │
│  AFTER Node Execution:                                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  State = {                                                          │    │
│  │    project_id: "123",               ◄── Unchanged                   │    │
│  │    current_phase: "code_analysis",  ◄── Updated                     │    │
│  │    code_analyst_complete: True,     ◄── Updated                     │    │
│  │    total_code_files: 47,            ◄── Updated                     │    │
│  │    messages: [M1, M2, M3],          ◄── Merged via add_messages     │    │
│  │    ...                              ◄── Unchanged                   │    │
│  │  }                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.3 Message Reducer

The `messages` field uses LangGraph's `add_messages` reducer:

```python
messages: Annotated[Sequence[BaseMessage], add_messages]
```

**Behavior**:
- Automatically appends new messages
- Prevents duplicate consecutive messages
- Maintains conversation history

---

## 6. State Access Patterns

### 6.1 Safe Reading

Always use `.get()` with defaults:

```python
# Good: Safe with default
project_id = state.get("project_id", "default")
errors = state.get("errors", [])
metadata = state.get("metadata", {})

# Bad: May raise KeyError
project_id = state["project_id"]  # Don't do this
```

### 6.2 Nested Access

```python
# Access nested data safely
metadata = state.get("metadata", {})
file_inventory = metadata.get("file_inventory", {})
code_files = file_inventory.get("code", {}).get("fourgl", [])

# Or with walrus operator
if file_inv := state.get("metadata", {}).get("file_inventory"):
    code_files = file_inv.get("code", {}).get("fourgl", [])
```

### 6.3 Accumulating Lists

```python
# Accumulate errors
existing_errors = state.get("errors", [])
new_errors = [{"agent": "code_analyzer", "message": "Parse failed"}]

return {
    "errors": existing_errors + new_errors,
}
```

### 6.4 Extending Metadata

```python
# Preserve existing metadata while adding new
return {
    "metadata": {
        **state.get("metadata", {}),  # Preserve existing
        "rag_ingestion": {             # Add new
            "chunks_stored": 1500,
            "timestamp": datetime.utcnow().isoformat(),
        },
    },
}
```

---

## 7. State Dependencies

### 7.1 Node Dependencies Chart

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      STATE DEPENDENCIES BY NODE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Node                    │ Reads                   │ Writes                 │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  INGEST                  │ project_id, paths       │ ingestion_complete,    │
│                          │                         │ files_ingested,        │
│                          │                         │ metadata.file_inventory│
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  DEAD_CODE_DETECT        │ metadata.file_inventory │ dead_code_candidates,  │
│                          │                         │ dead_code_files        │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  CODE_ANALYSIS           │ metadata.file_inventory │ code_analyst_complete, │
│                          │ dead_code_files         │ total_code_files,      │
│                          │                         │ complexity_metrics,    │
│                          │                         │ code_patterns          │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  DATABASE_ANALYSIS       │ metadata.file_inventory │ database_analyst_compl,│
│                          │                         │ total_tables,          │
│                          │                         │ table_relationships,   │
│                          │                         │ data_dictionary        │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  DOCUMENT_ANALYSIS       │ metadata.file_inventory │ document_analyst_compl,│
│                          │                         │ documented_requirements│
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  BUSINESS_RULE_EXTRACT   │ code_patterns           │ business_rules_catalog │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  INTEGRATION_MAPPING     │ code_analysis           │ integrations,          │
│                          │                         │ integration_map        │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  CROSS_REFERENCE         │ All above               │ cross_references,      │
│                          │                         │ cross_reference_stats  │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  SYNTHESIS               │ All above               │ enterprise_architecture│
│                          │                         │ component_catalog      │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  REQUIREMENTS            │ All above               │ functional_requirements│
│                          │                         │ non_functional_reqs,   │
│                          │                         │ executive_summary      │
│  ────────────────────────┼─────────────────────────┼────────────────────────│
│  OUTPUT                  │ All above               │ analysis_complete,     │
│                          │                         │ analysis_completed_at  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Checkpointing

### 8.1 Enabling Checkpoints

```python
from langgraph.checkpoint.sqlite import SqliteSaver

# Create checkpointer
checkpointer = SqliteSaver.from_conn_string(":memory:")

# Create graph with checkpointing
graph = create_legacy_analysis_graph_with_checkpointing(checkpointer)

# Run with thread_id for resumption
config = {"configurable": {"thread_id": project_id}}
result = await graph.ainvoke(initial_state, config=config)
```

### 8.2 Resuming Analysis

```python
# Resume from checkpoint
config = {"configurable": {"thread_id": project_id}}
result = await graph.ainvoke(None, config=config)  # None continues from checkpoint
```

---

## 9. Best Practices

### 9.1 Do's

1. **Always use `.get()` with defaults**
2. **Return only changed fields from nodes**
3. **Accumulate errors/warnings (don't replace)**
4. **Preserve existing metadata when updating**
5. **Use TypedDict for type safety**

### 9.2 Don'ts

1. **Don't access state with `[]` (KeyError risk)**
2. **Don't return entire state from nodes**
3. **Don't mutate state directly (return new values)**
4. **Don't store large binary data in state**
5. **Don't create circular dependencies**

---

## 10. Key Files Reference

| File | Purpose |
|------|---------|
| `state/base_state.py` | Base state classes |
| `state/project_state.py` | Project-level state |
| `state/analysis_state.py` | Analysis phase state |
| `state/legacy_analysis_state.py` | **Recommended** - Full workflow state |
| `state/__init__.py` | State exports |
