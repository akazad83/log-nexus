# Call Hierarchy

> **Document**: 02 - Call Hierarchy
> **Audience**: Developers, Technical Architects

---

## 1. Overview

This document traces the complete call hierarchy from HTTP request to agent execution, showing the exact function calls and module interactions.

---

## 2. Entry Point: HTTP Request

### 2.1 Upload Flow Call Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HTTP: POST /api/v1/projects/{project_id}/uploads/code                      │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/api/v1/routes/uploads.py                                       │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def upload_code_files(                                        │   │
│  │      project_id: int,                                                │   │
│  │      files: List[UploadFile],                                        │   │
│  │      db: AsyncSession = Depends(get_db)                              │   │
│  │  ) -> List[UploadedFileResponse]                                     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/services/project_service.py                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def get_project(db: AsyncSession, project_id: int)            │   │
│  │      → Validates project exists                                      │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/services/upload_service.py                                     │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def save_multiple_files(                                      │   │
│  │      db: AsyncSession,                                               │   │
│  │      project_id: int,                                                │   │
│  │      files: List[UploadFile],                                        │   │
│  │      file_type: FileType                                             │   │
│  │  ) -> List[UploadedFile]                                             │   │
│  │                                                                      │   │
│  │  FOR EACH file:                                                      │   │
│  │      ├── async def save_uploaded_file(...)                           │   │
│  │      │   ├── Create directory: {UPLOAD_DIR}/{project_id}/{type}      │   │
│  │      │   ├── Generate unique filename                                │   │
│  │      │   ├── Save to disk: await file.read() → write()               │   │
│  │      │   ├── Create UploadedFile DB record                           │   │
│  │      │   └── Update project.status → UPLOADING                       │   │
│  │      └── Continue to next file                                       │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  PostgreSQL                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  INSERT INTO uploaded_files (...)                                    │   │
│  │  UPDATE projects SET status = 'uploading' WHERE id = ...             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Analysis Start Call Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HTTP: POST /api/v1/projects/{project_id}/analysis/start                    │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/api/v1/routes/analysis.py:35                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  @router.post("/{project_id}/analysis/start")                        │   │
│  │  async def start_analysis(                                           │   │
│  │      project_id: int,                                                │   │
│  │      db: AsyncSession = Depends(get_db)                              │   │
│  │  ) -> TaskResponse                                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/services/analysis_service.py:25                                │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def start_analysis(                                           │   │
│  │      db: AsyncSession,                                               │   │
│  │      project_id: int                                                 │   │
│  │  ) -> dict                                                           │   │
│  │                                                                      │   │
│  │  1. project = await get_project(db, project_id)                      │   │
│  │  2. VALIDATE: project.status in [UPLOADING, FAILED]                  │   │
│  │  3. uploaded_files = await get_uploaded_files(db, project_id)        │   │
│  │  4. VALIDATE: len(uploaded_files) > 0                                │   │
│  │  5. await update_project_status(db, project_id, ANALYZING)           │   │
│  │  6. task = run_analysis.delay(project_id)  ◄── Celery async call     │   │
│  │  7. return {"task_id": task.id, "status": "pending", ...}            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  Redis (Message Broker)                                                     │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  LPUSH celery:analysis {"task": "run_analysis", "args": [123]}       │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        │ (Async - Worker picks up)
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  Celery Worker Process                                                      │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
                             [Continue to Section 3]
```

---

## 3. Celery Task Execution

### 3.1 Task Entry Point

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/workers/tasks.py:45                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  @shared_task(bind=True, name="app.workers.tasks.run_analysis")      │   │
│  │  def run_analysis(self, project_id: int) -> Dict[str, Any]:          │   │
│  │                                                                      │   │
│  │  1. self.update_state(state="ANALYZING")                             │   │
│  │  2. engine = create_sync_engine()                                    │   │
│  │  3. with Session(engine) as session:                                 │   │
│  │  4.   project = session.query(Project).get(project_id)               │   │
│  │  5.   sub_systems = build_sub_systems_list(project)                  │   │
│  │  6.   paths = build_workspace_paths(project_id)                      │   │
│  │  7.   tech_stack = {"language": "4GL", "database": "Ingres", ...}    │   │
│  │  8.   result = run_async(                                            │   │
│  │           run_legacy_analysis(                                       │   │
│  │               project_id=str(project_id),                            │   │
│  │               project_name=project.name,                             │   │
│  │               sub_systems=sub_systems,                               │   │
│  │               code_base_path=paths["code"],                          │   │
│  │               database_scripts_path=paths["database"],               │   │
│  │               documentation_path=paths["documentation"],             │   │
│  │               legacy_tech_stack=tech_stack                           │   │
│  │           )                                                          │   │
│  │       )  ◄── Bridges async LangGraph to sync Celery                  │   │
│  │  9.   analysis_result = map_to_analysis_result(result)               │   │
│  │  10.  session.add(analysis_result)                                   │   │
│  │  11.  project.status = ProjectStatus.PLANNING                        │   │
│  │  12.  session.commit()                                               │   │
│  │  13.  return {"project_id": ..., "status": "completed", ...}         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
                             [Continue to Section 4]
```

### 3.2 Async Bridge Helper

```python
# backend/app/workers/tasks.py:20

def run_async(coro):
    """Bridge async coroutine to sync Celery task."""
    loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    finally:
        # Cleanup pending tasks
        pending = asyncio.all_tasks(loop)
        for task in pending:
            task.cancel()
        loop.close()
```

---

## 4. LangGraph Workflow Execution

### 4.1 Graph Creation and Invocation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/graphs/legacy_analysis_graph.py:1700                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def run_legacy_analysis(                                      │   │
│  │      project_id: str,                                                │   │
│  │      project_name: str,                                              │   │
│  │      sub_systems: list[str],                                         │   │
│  │      code_base_path: str,                                            │   │
│  │      database_scripts_path: str,                                     │   │
│  │      documentation_path: str,                                        │   │
│  │      legacy_tech_stack: dict | None = None,                          │   │
│  │      checkpointer: BaseCheckpointSaver | None = None                 │   │
│  │  ) -> Dict[str, Any]:                                                │   │
│  │                                                                      │   │
│  │  1. initial_state = create_initial_analysis_state(                   │   │
│  │         project_id, project_name, sub_systems,                       │   │
│  │         code_base_path, database_scripts_path,                       │   │
│  │         documentation_path, legacy_tech_stack                        │   │
│  │     )                                                                │   │
│  │  2. graph = create_legacy_analysis_graph()                           │   │
│  │     # or create_legacy_analysis_graph_with_checkpointing(...)        │   │
│  │  3. config = {"configurable": {"thread_id": project_id}}             │   │
│  │  4. final_state = await graph.ainvoke(initial_state, config=config)  │   │
│  │  5. return extract_results(final_state)                              │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/graphs/legacy_analysis_graph.py:1600                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  def create_legacy_analysis_graph() -> CompiledGraph:                │   │
│  │                                                                      │   │
│  │  workflow = StateGraph(LegacyAnalysisState)                          │   │
│  │                                                                      │   │
│  │  # Add all 13 nodes                                                  │   │
│  │  workflow.add_node("ingest", ingest_node)                            │   │
│  │  workflow.add_node("dead_code_detect", dead_code_detection_node)     │   │
│  │  workflow.add_node("code_analysis", code_analysis_node)              │   │
│  │  workflow.add_node("database_analysis", database_analysis_node)      │   │
│  │  workflow.add_node("document_analysis", document_analysis_node)      │   │
│  │  workflow.add_node("business_rule_extraction", br_extraction_node)   │   │
│  │  workflow.add_node("integration_mapping", integration_mapping_node)  │   │
│  │  workflow.add_node("cross_reference", cross_reference_node)          │   │
│  │  workflow.add_node("graph_finalize", knowledge_graph_finalize_node)  │   │
│  │  workflow.add_node("synthesis", synthesis_node)                      │   │
│  │  workflow.add_node("requirements", requirements_generation_node)     │   │
│  │  workflow.add_node("sme_prep", sme_prep_node)                        │   │
│  │  workflow.add_node("output", output_node)                            │   │
│  │                                                                      │   │
│  │  # Set entry point                                                   │   │
│  │  workflow.set_entry_point("ingest")                                  │   │
│  │                                                                      │   │
│  │  # Define sequential edges                                           │   │
│  │  workflow.add_edge("ingest", "dead_code_detect")                     │   │
│  │  workflow.add_edge("dead_code_detect", "code_analysis")              │   │
│  │  workflow.add_edge("code_analysis", "database_analysis")             │   │
│  │  workflow.add_edge("database_analysis", "document_analysis")         │   │
│  │  workflow.add_edge("document_analysis", "business_rule_extraction")  │   │
│  │  workflow.add_edge("business_rule_extraction", "integration_mapping")│   │
│  │  workflow.add_edge("integration_mapping", "cross_reference")         │   │
│  │  workflow.add_edge("cross_reference", "graph_finalize")              │   │
│  │  workflow.add_edge("graph_finalize", "synthesis")                    │   │
│  │  workflow.add_edge("synthesis", "requirements")                      │   │
│  │  workflow.add_edge("requirements", "sme_prep")                       │   │
│  │  workflow.add_edge("sme_prep", "output")                             │   │
│  │  workflow.add_edge("output", END)                                    │   │
│  │                                                                      │   │
│  │  return workflow.compile()                                           │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
                             [Continue to Section 5]
```

---

## 5. Node Execution Chain

### 5.1 Ingest Node

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/graphs/legacy_analysis_graph.py:314                     │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def ingest_node(state: LegacyAnalysisState) -> Dict[str, Any]:│   │
│  │                                                                      │   │
│  │  1. paths = state.get("code_base_path"), state.get("db_path"), ...   │   │
│  │  2. file_inventory = scan_directories(paths)                         │   │
│  │     ├── Scan *.4gl, *.per, *.rep files                               │   │
│  │     ├── Scan *.vb, *.aspx files                                      │   │
│  │     ├── Scan *.sql, *.ddl files                                      │   │
│  │     └── Scan *.md, *.txt, *.pdf files                                │   │
│  │  3. rag_result = await _ingest_files_to_rag(file_inventory)          │   │
│  │  4. return {                                                         │   │
│  │         "current_phase": "ingestion",                                │   │
│  │         "ingestion_complete": True,                                  │   │
│  │         "files_ingested": total_count,                               │   │
│  │         "metadata": {"file_inventory": ..., "rag_ingestion": ...}    │   │
│  │     }                                                                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │ Calls RAG Pipeline
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/rag/ingestion/pipeline.py                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def _ingest_files_to_rag(file_inventory: dict) -> dict:       │   │
│  │                                                                      │   │
│  │  FOR EACH file in batches of 10:                                     │   │
│  │      1. content = read_file(file_path)                               │   │
│  │      2. chunks = chunker.chunk(content, language)                    │   │
│  │         ├── CodeChunker for 4GL/VB.NET                               │   │
│  │         └── SQLChunker for SQL/DDL                                   │   │
│  │      3. embeddings = await embedding_service.embed_codes(chunks)     │   │
│  │      4. await vectorstore.add_code_chunks(chunks_with_embeddings)    │   │
│  │                                                                      │   │
│  │  return {"chunks_stored": total, "status": "success"}                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
                            [Next: dead_code_detect node]
```

### 5.2 Code Analysis Node

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/graphs/legacy_analysis_graph.py:650                     │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def code_analysis_node(state: LegacyAnalysisState) -> Dict:   │   │
│  │                                                                      │   │
│  │  1. code_analyzer = CodeAnalyzerAgent()                              │   │
│  │  2. result = await code_analyzer.analyze(state)                      │   │
│  │  3. return {                                                         │   │
│  │         "current_phase": "code_analysis",                            │   │
│  │         "code_analyst_complete": True,                               │   │
│  │         "code_analysis_summary": result.summary,                     │   │
│  │         "complexity_metrics": result.complexity,                     │   │
│  │         ...                                                          │   │
│  │     }                                                                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/nodes/analysis/code_analyzer.py:45                      │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  class CodeAnalyzerAgent:                                            │   │
│  │                                                                      │   │
│  │  async def analyze(self, state: LegacyAnalysisState) -> Dict:        │   │
│  │      1. code_tool = CodeAnalysisTool()                               │   │
│  │      2. analysis = await code_tool.analyze(state["codebase_path"])   │   │
│  │      3. prompt = self._build_analysis_prompt(analysis, state)        │   │
│  │      4. llm = get_llm_for_task("code")  # codestral:22b              │   │
│  │      5. response = await llm.ainvoke(prompt)                         │   │
│  │      6. parsed = self._parse_llm_response(response)                  │   │
│  │      7. self._update_knowledge_graph(parsed)                         │   │
│  │      8. return parsed                                                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │ Calls Code Analysis Tool
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/tools/code_analysis.py                                  │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  class CodeAnalysisTool(BaseTool):                                   │   │
│  │                                                                      │   │
│  │  async def analyze(self, codebase_path: Path) -> Dict:               │   │
│  │      1. files = glob(codebase_path, "**/*.4gl|**/*.vb|**/*.sql")     │   │
│  │      2. FOR EACH file:                                               │   │
│  │           parser = ParserFactory.get_parser(language)                │   │
│  │           elements = parser.parse(content)                           │   │
│  │           metrics = calculate_complexity(elements)                   │   │
│  │      3. return aggregated_results                                    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │ Calls LLM
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/llm/ollama.py                                                  │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def ainvoke(prompt: str) -> str:                              │   │
│  │      POST http://localhost:11434/api/generate                        │   │
│  │      {"model": "codestral:22b-q4_K_M", "prompt": prompt}             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.3 Requirements Writer Node

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/graphs/legacy_analysis_graph.py:1350                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  async def requirements_generation_node(state: LegacyAnalysisState): │   │
│  │                                                                      │   │
│  │  1. requirements_writer = RequirementsWriterAgent()                  │   │
│  │  2. result = await requirements_writer.generate(state)               │   │
│  │  3. return {                                                         │   │
│  │         "requirements_writer_complete": True,                        │   │
│  │         "functional_requirements": result.fr,                        │   │
│  │         "non_functional_requirements": result.nfr,                   │   │
│  │         "business_rules_catalog": result.br,                         │   │
│  │         "executive_summary": result.summary,                         │   │
│  │         ...                                                          │   │
│  │     }                                                                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  backend/app/agents/nodes/analysis/requirements_writer.py:55                │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  class RequirementsWriterAgent:                                      │   │
│  │                                                                      │   │
│  │  async def generate(self, state: LegacyAnalysisState) -> Dict:       │   │
│  │      1. analysis_summary = self._compile_analysis_summary(state)     │   │
│  │      2. fr = await self._generate_functional_requirements(summary)   │   │
│  │      3. nfr = await self._generate_non_functional_requirements(...)  │   │
│  │      4. br = await self._generate_business_rules(summary)            │   │
│  │      5. data_dict = self._build_data_dictionary(state.entities)      │   │
│  │      6. traceability = self._create_traceability_matrix(fr, br)      │   │
│  │      7. exec_summary = await self._generate_executive_summary(...)   │   │
│  │      8. return {...all outputs...}                                   │   │
│  │                                                                      │   │
│  │  async def _generate_functional_requirements(self, summary) -> List: │   │
│  │      llm = get_llm_for_task("primary")  # llama3.1:70b               │   │
│  │      prompt = load_prompt("requirements_writer_fr")                  │   │
│  │      response = await llm.ainvoke(prompt.format(summary=summary))    │   │
│  │      return self._parse_requirements(response)                       │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Complete Module Dependency Graph

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        MODULE DEPENDENCY GRAPH                             │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  api/v1/routes/                                                            │
│  ├── analysis.py ─────────────┬──────────────────────────────────────────┐ │
│  ├── uploads.py ──────────────┤                                          │ │
│  └── projects.py ─────────────┤                                          │ │
│                               │                                          │ │
│                               ▼                                          │ │
│  services/                                                               │ │
│  ├── analysis_service.py ─────┬──────────────────────────────────────┐   │ │
│  ├── upload_service.py ───────┤                                      │   │ │
│  └── project_service.py ──────┘                                      │   │ │
│                               │                                      │   │ │
│                               ▼                                      │   │ │
│  workers/                                                            │   │ │
│  ├── celery_app.py            │                                      │   │ │
│  └── tasks.py ────────────────┼──────────────────────────────────┐   │   │ │
│                               │                                  │   │   │ │
│                               ▼                                  │   │   │ │
│  agents/                                                         │   │   │ │
│  ├── graphs/                                                     │   │   │ │
│  │   └── legacy_analysis_graph.py ───────────────────────────┐   │   │   │ │
│  │                            │                              │   │   │   │ │
│  ├── nodes/analysis/          ▼                              │   │   │   │ │
│  │   ├── code_analyzer.py ────┬──────────────────────────┐   │   │   │   │ │
│  │   ├── database_analyst.py ─┤                          │   │   │   │   │ │
│  │   ├── document_analyst.py ─┤                          │   │   │   │   │ │
│  │   ├── system_architect.py ─┤                          │   │   │   │   │ │
│  │   └── requirements_writer.py ─────────────────────────┤   │   │   │   │ │
│  │                            │                          │   │   │   │   │ │
│  ├── tools/                   ▼                          │   │   │   │   │ │
│  │   ├── rag_tools.py ────────┬──────────────────────┐   │   │   │   │   │ │
│  │   ├── code_analysis.py ────┤                      │   │   │   │   │   │ │
│  │   └── database_analysis.py ┘                      │   │   │   │   │   │ │
│  │                            │                      │   │   │   │   │   │ │
│  └── state/                   │                      │   │   │   │   │   │ │
│      └── legacy_analysis_state.py                    │   │   │   │   │   │ │
│                               │                      │   │   │   │   │   │ │
│                               ▼                      ▼   │   │   │   │   │ │
│  rag/                                                    │   │   │   │   │ │
│  ├── ingestion/pipeline.py ──────────────────────────────┘   │   │   │   │ │
│  ├── chunking/code_chunker.py                                │   │   │   │ │
│  ├── embeddings.py ──────────────────────────────────────────┘   │   │   │ │
│  ├── vectorstore.py ─────────────────────────────────────────────┘   │   │ │
│  └── retriever.py                                                    │   │ │
│                               │                                      │   │ │
│                               ▼                                      │   │ │
│  llm/                                                                │   │ │
│  └── ollama.py ──────────────────────────────────────────────────────┘   │ │
│                               │                                          │ │
│                               ▼                                          │ │
│  models/                                                                 │ │
│  ├── project.py                                                          │ │
│  ├── uploaded_file.py ───────────────────────────────────────────────────┘ │
│  └── analysis_result.py                                                    │
│                                                                            │
│  External Dependencies:                                                    │
│  ├── PostgreSQL (database)                                                 │
│  ├── Redis (celery broker)                                                 │
│  ├── Qdrant (vectors)                                                      │
│  └── Ollama (LLM inference)                                                │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Key File References

| Call | Source File | Line | Target |
|------|-------------|------|--------|
| Upload endpoint | `api/v1/routes/uploads.py` | 35 | `upload_service.save_multiple_files()` |
| Start analysis | `api/v1/routes/analysis.py` | 45 | `analysis_service.start_analysis()` |
| Queue task | `services/analysis_service.py` | 67 | `run_analysis.delay()` |
| Run analysis | `workers/tasks.py` | 45 | `run_legacy_analysis()` |
| Create graph | `agents/graphs/legacy_analysis_graph.py` | 1600 | `StateGraph.compile()` |
| Ingest node | `agents/graphs/legacy_analysis_graph.py` | 314 | RAG pipeline |
| Code analysis | `agents/nodes/analysis/code_analyzer.py` | 45 | `CodeAnalysisTool` |
| DB analysis | `agents/nodes/analysis/database_analyst.py` | 52 | `DatabaseAnalysisTool` |
| Requirements | `agents/nodes/analysis/requirements_writer.py` | 55 | LLM inference |
| RAG search | `agents/tools/rag_tools.py` | 85 | `CodeRetriever.retrieve()` |
| Embedding | `rag/embeddings.py` | 35 | Ollama embed API |
| Vector store | `rag/vectorstore.py` | 67 | Qdrant client |

---

## 8. Summary

The call hierarchy follows this pattern:

```
HTTP Request
    → FastAPI Route Handler
        → Service Layer (business logic)
            → Celery Task Queue (async)
                → run_async() bridge
                    → LangGraph Workflow
                        → Node Functions
                            → Agent Classes
                                → Tools (RAG, Code Analysis, DB Analysis)
                                    → External Services (Qdrant, Ollama)
```

Each layer has clear responsibilities:
- **Routes**: Request validation and response formatting
- **Services**: Business logic and workflow coordination
- **Tasks**: Background execution and state management
- **Agents**: LLM-powered analysis logic
- **Tools**: Reusable capabilities (search, parse, analyze)
