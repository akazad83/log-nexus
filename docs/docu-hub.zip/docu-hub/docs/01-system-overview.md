# System Overview

> **Document**: 01 - System Overview
> **Audience**: All (System Analysts, Developers, Architects)

---

## 1. Introduction

The Renovo Agent System is a sophisticated multi-agent AI architecture designed to analyze legacy codebases and generate comprehensive modernization documentation. It uses LangGraph for workflow orchestration, Ollama for local LLM inference, and Qdrant for vector-based code retrieval.

---

## 2. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                        React Frontend                                │   │
│  │    • Project Management    • Upload Interface    • Results Viewer    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │ HTTP/REST
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              API LAYER                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                        FastAPI Backend                               │   │
│  │    • /projects/*           • /uploads/*         • /analysis/*        │   │
│  │    • /tasks/*              • /reports/*                              │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                    ▼               ▼               ▼
┌──────────────────────┐ ┌──────────────┐ ┌────────────────────────────────┐
│     PostgreSQL       │ │    Redis     │ │       Celery Workers           │
│   ┌──────────────┐   │ │  ┌────────┐  │ │  ┌────────────────────────┐    │
│   │ Projects     │   │ │  │ Queue  │  │ │  │  run_analysis Task     │    │
│   │ UploadedFiles│   │ │  │ Cache  │  │ │  │  ┌──────────────────┐  │    │
│   │ AnalysisResults│ │ │  │ State  │  │ │  │  │ LangGraph        │  │    │
│   └──────────────┘   │ │  └────────┘  │ │  │  │ Workflow         │  │    │
└──────────────────────┘ └──────────────┘ │  │  └──────────────────┘  │    │
                                          │  └────────────────────────┘    │
                                          └────────────────────────────────┘
                                                          │
                                          ┌───────────────┼───────────────┐
                                          │               │               │
                                          ▼               ▼               ▼
                                    ┌──────────┐   ┌──────────┐   ┌──────────┐
                                    │  Qdrant  │   │  Ollama  │   │  File    │
                                    │ (Vectors)│   │  (LLMs)  │   │  System  │
                                    └──────────┘   └──────────┘   └──────────┘
```

---

## 3. Component Responsibilities

### 3.1 Frontend (React)

| Responsibility | Description |
|----------------|-------------|
| Project Management | Create, view, update, delete projects |
| File Upload | Multi-file upload for code, database, documentation |
| Analysis Control | Start analysis, monitor progress |
| Results Display | View requirements, architecture, business rules |
| Report Generation | Download analysis reports |

### 3.2 API Layer (FastAPI)

| Responsibility | Description |
|----------------|-------------|
| Request Handling | Validate and route HTTP requests |
| Authentication | JWT-based authentication (planned) |
| Business Logic | Coordinate services and workflows |
| Response Formatting | Serialize results to JSON |
| Error Handling | Consistent error responses |

### 3.3 Service Layer

| Service | Responsibility |
|---------|----------------|
| `ProjectService` | CRUD operations for projects |
| `UploadService` | File storage and metadata management |
| `AnalysisService` | Trigger analysis, manage results |
| `ParsingService` | Code parsing utilities |

### 3.4 Worker Layer (Celery)

| Responsibility | Description |
|----------------|-------------|
| Task Execution | Run long-running analysis tasks |
| Queue Management | Priority-based task scheduling |
| Progress Tracking | Real-time progress updates |
| Error Recovery | Retry failed tasks |

### 3.5 Agent Layer (LangGraph)

| Component | Responsibility |
|-----------|----------------|
| State Graph | Define workflow nodes and edges |
| Agent Nodes | Execute specific analysis tasks |
| State Management | Pass data between agents |
| Tools | Provide agent capabilities (RAG, parsing) |

### 3.6 Infrastructure

| Component | Purpose |
|-----------|---------|
| PostgreSQL | Persistent storage for projects and results |
| Redis | Message queue and caching |
| Qdrant | Vector storage for code embeddings |
| Ollama | Local LLM inference |
| File System | Uploaded file storage |

---

## 4. Agent System Overview

### 4.1 Agent Types

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            AGENT HIERARCHY                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ORCHESTRATION LAYER                                                        │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  Analysis Orchestrator (llama3.1:8b)                                 │   │
│  │  • Coordinates workflow phases                                       │   │
│  │  • Tracks progress across sub-systems                                │   │
│  │  • Manages phase transitions                                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ANALYSIS LAYER                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐              │
│  │ Code Analyzer   │  │ Database Analyst│  │ Document Analyst│              │
│  │ (codestral:22b) │  │ (llama3.1:70b)  │  │ (llama3.1:70b)  │              │
│  │ • Parse 4GL     │  │ • Ingres DDL    │  │ • Feature docs  │              │
│  │ • Parse VB.NET  │  │ • Stored procs  │  │ • Design docs   │              │
│  │ • Complexity    │  │ • Relationships │  │ • Changelogs    │              │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘              │
│                                                                             │
│  EXTRACTION LAYER                                                           │
│  ┌─────────────────────────────────┐  ┌──────────────────────────────────┐  │
│  │ Business Rule Extractor         │  │ Integration Mapper               │  │
│  │ (codestral:22b)                 │  │ (llama3.1:70b)                   │  │
│  │ • Validation rules              │  │ • External systems               │  │
│  │ • Calculation logic             │  │ • Data flows                     │  │
│  │ • Confidence scoring            │  │ • Protocol mapping               │  │
│  └─────────────────────────────────┘  └──────────────────────────────────┘  │
│                                                                             │
│  SYNTHESIS LAYER                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  System Architect (llama3.1:70b)                                     │   │
│  │  • Current architecture analysis                                     │   │
│  │  • Target architecture design                                        │   │
│  │  • Migration strategy                                                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  OUTPUT LAYER                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  Requirements Writer (llama3.1:70b)                                  │   │
│  │  • Functional Requirements (FR-XXX)                                  │   │
│  │  • Non-Functional Requirements (NFR-XXX)                             │   │
│  │  • Business Rules Catalog (BR-XXX)                                   │   │
│  │  • Traceability Matrix                                               │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Agent-Model Mapping

| Agent | LLM Model | Quantization | Rationale |
|-------|-----------|--------------|-----------|
| Analysis Orchestrator | llama3.1:8b-instruct | Q4_K_M | Fast decisions, low resource usage |
| Code Analyzer | codestral:22b | Q4_K_M | Best code understanding |
| Database Analyst | llama3.1:70b-instruct | Q4_K_M | Complex schema reasoning |
| Document Analyst | llama3.1:70b-instruct | Q4_K_M | Natural language understanding |
| Business Rule Extractor | codestral:22b | Q4_K_M | Code pattern recognition |
| Integration Mapper | llama3.1:70b-instruct | Q4_K_M | System integration reasoning |
| System Architect | llama3.1:70b-instruct | Q4_K_M | Architecture decisions |
| Requirements Writer | llama3.1:70b-instruct | Q4_K_M | High-quality documentation |

---

## 5. Workflow Overview

### 5.1 Analysis Workflow Stages

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ANALYSIS WORKFLOW STAGES                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  STAGE 1: INGESTION (10%)                                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  • Scan uploaded files (4GL, VB.NET, SQL)                            │   │
│  │  • Categorize by type and language                                   │   │
│  │  • Chunk code at semantic boundaries                                 │   │
│  │  • Generate embeddings (nomic-embed-text)                            │   │
│  │  • Store in Qdrant vector database                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 2: DEAD CODE DETECTION (15%)                                         │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  • Build call graph from procedures                                  │   │
│  │  • Identify unreferenced code                                        │   │
│  │  • Flag dead code candidates                                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 3: PARALLEL ANALYSIS (40%)                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                          │
│  │    Code     │  │  Database   │  │  Document   │                          │
│  │  Analysis   │  │  Analysis   │  │  Analysis   │                          │
│  │  (15%)      │  │  (15%)      │  │  (10%)      │                          │
│  └─────────────┘  └─────────────┘  └─────────────┘                          │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 4: EXTRACTION (25%)                                                  │
│  ┌───────────────────────────┐  ┌───────────────────────────┐               │
│  │  Business Rule Extraction │  │  Integration Mapping      │               │
│  │  (15%)                    │  │  (10%)                    │               │
│  └───────────────────────────┘  └───────────────────────────┘               │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 5: CROSS-REFERENCE (10%)                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Build code-to-database references                                │    │
│  │  • Build code-to-documentation references                           │    │
│  │  • Create visualization data                                        │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 6: KNOWLEDGE GRAPH (5%)                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Export knowledge graph to JSON                                   │    │
│  │  • Create timestamped snapshot                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 7: SYNTHESIS (15%)                                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • System Architect designs target architecture                     │    │
│  │  • Creates migration strategy                                       │    │
│  │  • Generates technology stack recommendations                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 8: REQUIREMENTS (15%)                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Requirements Writer generates FR/NFR/BR                          │    │
│  │  • Creates traceability matrix                                      │    │
│  │  • Produces executive summary                                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  STAGE 9: SME PREPARATION (5%)                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Compile validation packets for SMEs                              │    │
│  │  • Flag low-confidence findings                                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  OUTPUT                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  • analysis_complete = True                                          │   │
│  │  • Results saved to database                                         │   │
│  │  • Project status → PLANNING                                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Output Artifacts

### 6.1 Generated Documentation

| Artifact | Description | Format |
|----------|-------------|--------|
| Functional Requirements | FR-001 to FR-XXX | Structured JSON/MD |
| Non-Functional Requirements | NFR-001 to NFR-XXX | Structured JSON/MD |
| Business Rules Catalog | BR-001 to BR-XXX | Structured JSON/MD |
| Data Dictionary | Entity definitions and relationships | JSON |
| Architecture Design | Current and target architecture | JSON |
| Traceability Matrix | Requirement to source mapping | JSON |
| Executive Summary | High-level findings | Markdown |

### 6.2 Output Directory Structure

```
analysis_output/
├── 00_executive_summary/
│   └── executive_summary.md
├── 01_architecture/
│   ├── current_architecture.json
│   ├── target_architecture.json
│   └── migration_strategy.md
├── 02_sub_systems/
│   ├── CustomerManagement/
│   ├── OrderProcessing/
│   └── ...
├── 03_requirements/
│   ├── functional_requirements.md
│   ├── non_functional_requirements.md
│   └── business_rules_catalog.md
├── 04_data/
│   └── data_dictionary.md
└── 05_technical_debt/
    └── technical_debt_assessment.md
```

---

## 7. Key Design Decisions

### 7.1 Single Model Loading

Due to 8GB VRAM constraint, only one LLM model is loaded at a time:

```
Model Lifecycle:
1. Agent needs model → Unload previous model
2. Load new model → Wait for warmup
3. Execute inference → Generate response
4. Keep loaded → Reuse if same agent next
```

### 7.2 Sequential Workflow

Agents execute sequentially (not parallel) to:
- Respect GPU memory constraints
- Ensure deterministic state progression
- Simplify error handling and recovery

### 7.3 State-Based Communication

All inter-agent communication happens through shared state:
- No direct agent-to-agent calls
- State is the single source of truth
- Each agent reads state, produces updates

### 7.4 RAG-Enhanced Analysis

Agents use RAG (Retrieval-Augmented Generation) to:
- Retrieve relevant code context
- Reduce token usage
- Improve accuracy with grounded examples

---

## 8. Configuration Reference

### 8.1 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | - | PostgreSQL connection string |
| `REDIS_URL` | `redis://localhost:6379/0` | Redis connection string |
| `QDRANT_HOST` | `localhost` | Qdrant server host |
| `QDRANT_PORT` | `6333` | Qdrant server port |
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama API endpoint |
| `LLM_PRIMARY_MODEL` | `llama3.1:70b-instruct-q4_K_M` | Primary LLM model |
| `LLM_CODE_MODEL` | `codestral:22b-q4_K_M` | Code analysis model |
| `LLM_FAST_MODEL` | `llama3.1:8b-instruct-q4_K_M` | Fast orchestration model |
| `EMBEDDING_MODEL` | `nomic-embed-text` | Embedding model |

### 8.2 Celery Configuration

| Setting | Value | Reason |
|---------|-------|--------|
| `worker_concurrency` | 2 | GPU constraint |
| `worker_prefetch_multiplier` | 1 | Long-running tasks |
| `task_time_limit` | 3600s | Analysis can take 1 hour |
| Rate limit (analysis) | 1/minute | GPU memory management |

---

## 9. Next Steps

- Continue to [Call Hierarchy](./02-call-hierarchy.md) for detailed code tracing
- Review [Process Flow](./03-process-flow.md) for state transitions
- Study [Agent Collaboration](./05-agent-collaboration.md) for inter-agent dynamics
