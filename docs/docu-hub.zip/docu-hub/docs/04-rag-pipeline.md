# RAG Pipeline

> **Document**: 04 - RAG Pipeline
> **Audience**: Developers, Technical Architects

---

## 1. Overview

The RAG (Retrieval-Augmented Generation) Pipeline is responsible for:
1. **Ingesting** legacy code into a vector database
2. **Embedding** code chunks using language-aware embeddings
3. **Retrieving** relevant context for agent queries
4. **Enhancing** LLM responses with grounded code examples

---

## 2. Pipeline Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          RAG PIPELINE ARCHITECTURE                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        INGESTION PHASE                              │    │
│  │                                                                     │    │
│  │  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐          │    │
│  │  │ 4GL      │   │ VB.NET   │   │ SQL      │   │ Docs     │          │    │
│  │  │ Files    │   │ Files    │   │ Files    │   │ Files    │          │    │
│  │  └────┬─────┘   └────┬─────┘   └────┬─────┘   └────┬─────┘          │    │
│  │       │              │              │              │                │    │
│  │       └──────────────┴──────────────┴──────────────┘                │    │
│  │                              │                                      │    │
│  │                              ▼                                      │    │
│  │                     ┌──────────────────┐                            │    │
│  │                     │  FILE SCANNER    │                            │    │
│  │                     │  (Batch: 10)     │                            │    │
│  │                     └────────┬─────────┘                            │    │
│  │                              │                                      │    │
│  │                              ▼                                      │    │
│  │                     ┌──────────────────┐                            │    │
│  │                     │   CHUNKING       │                            │    │
│  │                     │  ┌────────────┐  │                            │    │
│  │                     │  │CodeChunker │  │  ◄── Semantic boundaries   │    │
│  │                     │  │SQLChunker  │  │      (procedures, tables)  │    │
│  │                     │  └────────────┘  │                            │    │
│  │                     └────────┬─────────┘                            │    │
│  │                              │                                      │    │
│  │                              ▼                                      │    │
│  │                     ┌──────────────────┐                            │    │
│  │                     │   EMBEDDING      │                            │    │
│  │                     │  nomic-embed-text│                            │    │
│  │                     │  (768 dims)      │                            │    │
│  │                     └────────┬─────────┘                            │    │
│  │                              │                                      │    │
│  │                              ▼                                      │    │
│  │                     ┌──────────────────┐                            │    │
│  │                     │   QDRANT         │                            │    │
│  │                     │  Vector Store    │                            │    │
│  │                     │  (Upsert)        │                            │    │
│  │                     └──────────────────┘                            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        RETRIEVAL PHASE                              │    │
│  │                                                                     │    │
│  │  ┌──────────────────┐                                               │    │
│  │  │   AGENT QUERY    │                                               │    │
│  │  │   "Find customer │                                               │    │
│  │  │    validation"   │                                               │    │
│  │  └────────┬─────────┘                                               │    │
│  │           │                                                         │    │
│  │           ▼                                                         │    │
│  │  ┌──────────────────┐                                               │    │
│  │  │  QUERY EMBEDDING │                                               │    │
│  │  │  "search_query:" │  ◄── Query prefix for disambiguation          │    │
│  │  │  + query text    │                                               │    │
│  │  └────────┬─────────┘                                               │    │
│  │           │                                                         │    │
│  │           ▼                                                         │    │
│  │  ┌──────────────────┐                                               │    │
│  │  │  VECTOR SEARCH   │                                               │    │
│  │  │  ├── Filters     │  ◄── language, element_type, file_path        │    │
│  │  │  └── Threshold   │  ◄── Default: 0.5 (cosine similarity)         │    │
│  │  └────────┬─────────┘                                               │    │
│  │           │                                                         │    │
│  │           ▼                                                         │    │
│  │  ┌──────────────────┐                                               │    │
│  │  │  RETRIEVED       │                                               │    │
│  │  │  CHUNKS          │                                               │    │
│  │  │  [{content,      │                                               │    │
│  │  │    score,        │                                               │    │
│  │  │    metadata}]    │                                               │    │
│  │  └──────────────────┘                                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Ingestion Pipeline

### 3.1 File Discovery

**Source**: `backend/app/rag/ingestion/pipeline.py`

```python
# Supported file patterns
CODE_PATTERNS = [
    "**/*.4gl", "**/*.per", "**/*.rep",  # 4GL
    "**/*.vb", "**/*.aspx", "**/*.asmx",  # VB.NET
    "**/*.sql", "**/*.ddl", "**/*.prc"    # SQL
]

DOC_PATTERNS = [
    "**/*.md", "**/*.txt", "**/*.pdf", "**/*.doc", "**/*.docx"
]
```

### 3.2 Chunking Strategies

#### Code Chunking (4GL/VB.NET)

**Source**: `backend/app/rag/chunking/code_chunker.py`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CODE CHUNKING PROCESS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Input: CustomerForm.4gl                                                    │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  PROCEDURE InitializeForm;                                           │   │
│  │      -- Initialize customer form                                     │   │
│  │      CALL LoadDefaults;                                              │   │
│  │      ...                                                             │   │
│  │  ENDPROC;                                                            │   │
│  │                                                                      │   │
│  │  PROCEDURE ValidateCustomer(p_id INTEGER);                           │   │
│  │      -- Validate customer data                                       │   │
│  │      IF p_id <= 0 THEN                                               │   │
│  │          RAISE ERROR 'Invalid customer ID';                          │   │
│  │      ENDIF;                                                          │   │
│  │      ...                                                             │   │
│  │  ENDPROC;                                                            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                               │                                             │
│                               ▼                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  PARSER: FourGLParser                                                │   │
│  │  ├── Identify PROCEDURE...ENDPROC boundaries                         │   │
│  │  ├── Extract procedure name, parameters                              │   │
│  │  └── Calculate line ranges                                           │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                               │                                             │
│                               ▼                                             │
│  Output: 2 Chunks                                                           │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  CHUNK 1:                                                            │   │
│  │  # PROCEDURE: InitializeForm                                         │   │
│  │  # Parameters: none                                                  │   │
│  │  # Lines: 1-15                                                       │   │
│  │                                                                      │   │
│  │  PROCEDURE InitializeForm;                                           │   │
│  │      -- Initialize customer form                                     │   │
│  │      CALL LoadDefaults;                                              │   │
│  │      ...                                                             │   │
│  │  ENDPROC;                                                            │   │
│  │                                                                      │   │
│  │  Metadata: {                                                         │   │
│  │    "element_type": "procedure",                                      │   │
│  │    "element_name": "InitializeForm",                                 │   │
│  │    "language": "4GL",                                                │   │
│  │    "start_line": 1,                                                  │   │
│  │    "end_line": 15,                                                   │   │
│  │    "complexity": "low"                                               │   │
│  │  }                                                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  CHUNK 2:                                                            │   │
│  │  # PROCEDURE: ValidateCustomer                                       │   │
│  │  # Parameters: p_id: INTEGER                                         │   │
│  │  # Lines: 17-35                                                      │   │
│  │                                                                      │   │
│  │  PROCEDURE ValidateCustomer(p_id INTEGER);                           │   │
│  │      ...                                                             │   │
│  │  ENDPROC;                                                            │   │
│  │                                                                      │   │
│  │  Metadata: {                                                         │   │
│  │    "element_type": "procedure",                                      │   │
│  │    "element_name": "ValidateCustomer",                               │   │
│  │    "language": "4GL",                                                │   │
│  │    "parameters": [{"name": "p_id", "type": "INTEGER"}],              │   │
│  │    "complexity": "medium"                                            │   │
│  │  }                                                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### SQL Chunking

**Source**: `backend/app/rag/chunking/sql_chunker.py`

| Statement Type | Chunk Boundaries | Metadata Extracted |
|----------------|------------------|-------------------|
| CREATE TABLE | Full DDL statement | columns, constraints, primary key |
| CREATE VIEW | Full DDL statement | source tables |
| CREATE PROCEDURE | Full body | parameters, return type |
| CREATE TRIGGER | Full body | target table, timing, event |

### 3.3 Embedding Generation

**Source**: `backend/app/rag/embeddings.py`

```python
class EmbeddingService:
    model = "nomic-embed-text"  # 768 dimensions

    async def embed_code(self, code: str, language: str) -> List[float]:
        """
        Language-aware code embedding.
        Prefix: "# LANGUAGE code\n{code}"
        """
        prefixed = f"# {language.upper()} code\n{code}"
        return await self._embed(prefixed)

    async def embed_query(self, query: str) -> List[float]:
        """
        Query embedding with search prefix.
        Prefix: "search_query: {query}"
        """
        prefixed = f"search_query: {query}"
        return await self._embed(prefixed)
```

**Embedding Dimensions**: 768 (nomic-embed-text)

### 3.4 Vector Storage

**Source**: `backend/app/rag/vectorstore.py`

```python
@dataclass
class CodeChunk:
    id: str                    # Deterministic UUID5
    content: str               # Code content
    embedding: List[float]     # 768-dim vector
    file_path: str             # Source file
    language: str              # 4GL, VB.NET, SQL
    element_type: str          # procedure, function, table, etc.
    element_name: str          # Name of the element
    start_line: int            # Starting line number
    end_line: int              # Ending line number
    metadata: Dict[str, Any]   # Additional metadata
    created_at: str            # Timestamp
```

**Chunk ID Generation**:
```python
def create_chunk_id(file_path: str, element_name: str) -> str:
    """Deterministic ID using UUID5 for consistent re-ingestion."""
    namespace = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
    return str(uuid.uuid5(namespace, f"{file_path}:{element_name}"))
```

---

## 4. Retrieval System

### 4.1 Basic Retrieval

**Source**: `backend/app/rag/retriever.py`

```python
async def retrieve(
    query: str,
    limit: int = 10,
    filters: Dict[str, Any] = None,
    score_threshold: float = 0.5
) -> List[RetrievedChunk]:
    """
    Semantic search over indexed code.

    Args:
        query: Natural language or code query
        limit: Maximum results to return
        filters: Optional metadata filters
        score_threshold: Minimum similarity score (0-1)

    Returns:
        List of matching chunks with scores
    """
```

### 4.2 Filter Types

| Filter | Description | Example |
|--------|-------------|---------|
| `language` | Filter by programming language | `{"language": "4GL"}` |
| `element_type` | Filter by code element type | `{"element_type": "procedure"}` |
| `file_path` | Filter by source file | `{"file_path": "src/*.4gl"}` |

**Filter Logic**:
- Multiple keys: AND logic
- Multiple values per key: OR logic

```python
# Example: Find 4GL or SQL procedures
filters = {
    "language": ["4GL", "SQL"],  # OR: 4GL OR SQL
    "element_type": "procedure"   # AND: element_type = procedure
}
```

### 4.3 Score Thresholds

| Use Case | Threshold | Rationale |
|----------|-----------|-----------|
| General search | 0.5 | Balance precision/recall |
| Code similarity | 0.6 | Higher for code patterns |
| File-specific | 0.3 | Lower for local context |

### 4.4 Advanced Retrieval: Fusion Retriever

**Source**: `backend/app/rag/fusion_retriever.py`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        FUSION RETRIEVAL PROCESS                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Query: "Find CUSTOMER_TABLE validation logic"                              │
│                               │                                             │
│           ┌───────────────────┼───────────────────┐                         │
│           │                   │                   │                         │
│           ▼                   ▼                   ▼                         │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐                │
│  │ VECTOR SEARCH   │ │ KEYWORD SEARCH  │ │  GRAPH SEARCH   │                │
│  │                 │ │                 │ │                 │                │
│  │ Semantic        │ │ BM25            │ │ Knowledge Graph │                │
│  │ similarity      │ │ exact match     │ │ traversal       │                │
│  │                 │ │                 │ │                 │                │
│  │ Results:        │ │ Results:        │ │ Results:        │                │
│  │ [A:0.8, B:0.7,  │ │ [C:0.9, A:0.6,  │ │ [D:0.7, E:0.6]  │                │
│  │  F:0.6]         │ │  G:0.5]         │ │                 │                │
│  └────────┬────────┘ └────────┬────────┘ └────────┬────────┘                │
│           │                   │                   │                         │
│           └───────────────────┼───────────────────┘                         │
│                               │                                             │
│                               ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  RECIPROCAL RANK FUSION (RRF)                                       │    │
│  │                                                                     │    │
│  │  Formula: score = Σ (1 / (k + rank))  where k = 60                  │    │
│  │                                                                     │    │
│  │  Example:                                                           │    │
│  │  A: Vector rank=1, Keyword rank=2 → 1/(60+1) + 1/(60+2) = 0.0325    │    │
│  │  C: Keyword rank=1 only          → 1/(60+1) = 0.0164                │    │
│  │  ...                                                                │    │
│  │                                                                     │    │
│  │  Final ranking: [A, C, B, D, E, F, G]                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  MERGED RESULTS                                                     │    │
│  │  [                                                                  │    │
│  │    {chunk_id: "A", score: 0.0325, strategies: [VECTOR, KEYWORD]},   │    │
│  │    {chunk_id: "C", score: 0.0164, strategies: [KEYWORD]},           │    │
│  │    ...                                                              │    │
│  │  ]                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Cross-Reference System

**Source**: `backend/app/rag/cross_reference.py`

### 5.1 Reference Types

| Type | Description | Detection Method | Confidence |
|------|-------------|------------------|------------|
| READS_TABLE | Code reads from table | Static analysis (SELECT) | 0.95 |
| WRITES_TABLE | Code writes to table | Static analysis (INSERT/UPDATE/DELETE) | 0.95 |
| CALLS_PROC | Code calls procedure | Static analysis (CALL) | 0.90 |
| CALLS_SPROC | Code calls stored proc | Static analysis | 0.90 |
| INCLUDES_FILE | Code includes another file | Static analysis (INCLUDE) | 0.90 |
| DOCUMENTED_BY | Code documented in file | Text matching | 0.70 |
| FOREIGN_KEY | Table references another | DDL analysis | 0.95 |
| IMPLICIT_REF | Same column names | Text matching | 0.60 |

### 5.2 Cross-Reference Building

```python
async def build_references(
    subsystem_id: str,
    code_files: List[str],
    doc_files: List[str]
) -> List[CrossReference]:
    """
    Build all cross-references for a subsystem.

    Detects:
    1. Table access (reads/writes)
    2. Procedure calls
    3. Documentation references
    4. Implicit references (same column names)
    """
```

---

## 6. Hierarchical Memory

**Source**: `backend/app/rag/hierarchical_memory.py`

### 6.1 Memory Levels

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       HIERARCHICAL MEMORY LEVELS                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Level 1: REPOSITORY (~2K tokens)                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Project overview                                                 │    │
│  │  • Total sub-systems: 25                                            │    │
│  │  • Technologies: [4GL, VB.NET, Ingres]                              │    │
│  │  • Total LOC: 2,500,000                                             │    │
│  │  • Total tables: 450                                                │    │
│  │  ALWAYS in context                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Level 2: SUBSYSTEM (~500 tokens each)                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Subsystem: CustomerManagement                                    │    │
│  │  • Purpose: Handles customer data lifecycle                         │    │
│  │  • Key modules: [CustomerForm, CustomerValidation, CustomerReport]  │    │
│  │  • Tables owned: [CUSTOMER, CUSTOMER_ADDRESS, CUSTOMER_HISTORY]     │    │
│  │  • Complexity: high                                                 │    │
│  │  CACHED in Qdrant, loaded on demand                                 │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Level 3: MODULE (~1K tokens each)                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Module: CustomerValidation.4gl                                   │    │
│  │  • Procedures: [ValidateCustomer, ValidateAddress, CheckDuplicates] │    │
│  │  • Tables accessed: [CUSTOMER, CUSTOMER_ADDRESS]                    │    │
│  │  • Business rules: ["Customer ID must be positive", ...]            │    │
│  │  LOADED on demand                                                   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                               │                                             │
│                               ▼                                             │
│  Level 4: CODE (~2K tokens each)                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  • Actual code chunks from Qdrant                                   │    │
│  │  • Retrieved via semantic search                                    │    │
│  │  • Used for specific code understanding                             │    │
│  │  RETRIEVED on demand                                                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 Context Assembly

```python
async def get_context(query: str, token_budget: int = 8000) -> str:
    """
    Assemble context within token budget.

    Priority:
    1. Level 1 (Repository) - Always included (~2K)
    2. Level 2 (Relevant subsystems) - Max 3 (~1.5K)
    3. Level 3 (Module details) - If specific query, max 2 (~2K)
    4. Level 4 (Code chunks) - Remaining budget (~2.5K)
    """
```

---

## 7. RAG Tool Interface

**Source**: `backend/app/agents/tools/rag_tools.py`

### 7.1 Tool Methods

```python
class RAGSearchTool(BaseTool):
    """RAG search tool for agents."""

    async def execute(
        query: str,
        top_k: int = 10,
        filters: Dict[str, Any] = None,
        score_threshold: float = 0.5
    ) -> ToolResult:
        """
        Execute semantic search with health checks and retries.
        """

    async def search_by_language(
        query: str,
        language: str,
        top_k: int = 10
    ) -> List[RetrievedChunk]:
        """Search within specific language."""

    async def find_similar_code(
        code_snippet: str,
        language: str = None,
        top_k: int = 10
    ) -> List[RetrievedChunk]:
        """Find code similar to a snippet."""

    async def get_element_context(
        element_name: str,
        language: str = None
    ) -> List[RetrievedChunk]:
        """Get all chunks for an element."""
```

### 7.2 Health Checks and Resilience

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      RAG TOOL RESILIENCE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  HEALTH CHECK SYSTEM                                                │    │
│  │  ├── Qdrant connectivity: Cached 60 seconds                         │    │
│  │  ├── Embedding service: Test with "test" string                     │    │
│  │  └── Retriever availability: Component instantiation                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  RETRY STRATEGY                                                     │    │
│  │  ├── Max retries: 3                                                 │    │
│  │  ├── Initial delay: 0.5 seconds                                     │    │
│  │  ├── Backoff factor: 2.0 (exponential)                              │    │
│  │  └── Max delay: 10 seconds                                          │    │
│  │                                                                     │    │
│  │  Timeline: 0.5s → 1s → 2s → (fail)                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  GRACEFUL FALLBACK                                                  │    │
│  │  If Qdrant unavailable:                                             │    │
│  │  {                                                                  │    │
│  │    "success": false,                                                │    │
│  │    "data": [],                                                      │    │
│  │    "error": "RAG search service unavailable",                       │    │
│  │    "metadata": {                                                    │    │
│  │      "fallback": true,                                              │    │
│  │      "suggestion": "Analysis continues with other tools"            │    │
│  │    }                                                                │    │
│  │  }                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Configuration

### 8.1 Pipeline Settings

| Setting | Value | Description |
|---------|-------|-------------|
| Collection name | `legacy_code` | Qdrant collection |
| Embedding dimension | 768 | nomic-embed-text |
| Distance metric | Cosine | Similarity measure |
| Batch size | 10 | Files per batch |
| Code chunk max | 2000 chars | Max chunk size |
| SQL chunk max | 3000 chars | Max chunk size |
| Chunk overlap | 100 chars | Overlap between chunks |

### 8.2 External Dependencies

| Service | Purpose | Endpoint |
|---------|---------|----------|
| Qdrant | Vector storage | `localhost:6333` |
| Ollama | Embeddings | `localhost:11434` |

---

## 9. Key Files Reference

| Component | File | Purpose |
|-----------|------|---------|
| Ingestion | `rag/ingestion/pipeline.py` | Main ingestion pipeline |
| Code Chunker | `rag/chunking/code_chunker.py` | 4GL/VB.NET chunking |
| SQL Chunker | `rag/chunking/sql_chunker.py` | SQL DDL chunking |
| Embeddings | `rag/embeddings.py` | Embedding generation |
| Vector Store | `rag/vectorstore.py` | Qdrant operations |
| Retriever | `rag/retriever.py` | Search interface |
| Fusion | `rag/fusion_retriever.py` | Multi-strategy search |
| Cross-Ref | `rag/cross_reference.py` | Reference building |
| Memory | `rag/hierarchical_memory.py` | Context management |
| RAG Tool | `agents/tools/rag_tools.py` | Agent tool interface |
