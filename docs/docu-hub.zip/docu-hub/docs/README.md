# Renovo Agent System - Deep Dive Documentation

> **Version**: 1.0
> **Last Updated**: January 2026
> **Audience**: System Analysts, Software Developers, Technical Architects

---

## Table of Contents

| # | Document | Description | Audience |
|---|----------|-------------|----------|
| 1 | [System Overview](./01-system-overview.md) | High-level architecture and component overview | All |
| 2 | [Call Hierarchy](./02-call-hierarchy.md) | Complete call flow from API to agent execution | Developers |
| 3 | [Process Flow](./03-process-flow.md) | End-to-end workflow with state transitions | System Analysts |
| 4 | [RAG Pipeline](./04-rag-pipeline.md) | Code ingestion, vectorization, and retrieval | Developers |
| 5 | [Agent Collaboration](./05-agent-collaboration.md) | How agents work together and share state | All |
| 6 | [State Management](./06-state-management.md) | LangGraph state definitions and data flow | Developers |
| 7 | [API Reference](./07-api-reference.md) | API endpoints for upload and analysis | Developers |
| 8 | [Sequence Diagrams](./08-sequence-diagrams.md) | Visual process flows (text-based) | All |

---

## Quick Reference

### What is Renovo?

Renovo is an **AI-powered legacy system analysis tool** that uses a multi-agent architecture to analyze, document, and extract requirements from legacy codebases. The current focus is on the **Analysis Phase** for legacy modernization planning.

### Target Legacy System

| Component | Technology |
|-----------|------------|
| Application Logic | OpenROAD 4GL / Informix 4GL |
| Database | Actian Ingres |
| Web Services | VB.NET |
| Scale | 25-30 sub-applications, 36+ years of code |

### System Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                         RENOVO SYSTEM                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────┐  │
│  │  Frontend   │──▶│  FastAPI    │───▶│  Background Workers     │  │
│  │  (React)    │    │  Backend    │    │  (Celery + LangGraph)   │  │
│  └─────────────┘    └─────────────┘    └─────────────────────────┘  │
│                            │                      │                 │
│                            ▼                      ▼                 │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────┐  │
│  │  PostgreSQL │    │   Redis     │    │   Ollama (Local LLMs)   │  │
│  │  (Database) │    │  (Queue)    │    │   + Qdrant (Vectors)    │  │
│  └─────────────┘    └─────────────┘    └─────────────────────────┘  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Agent Architecture (5 Core Agents)

```
                    ┌─────────────────────────────┐
                    │   ANALYSIS ORCHESTRATOR     │
                    │   (Workflow Coordinator)    │
                    └─────────────┬───────────────┘
                                  │
          ┌───────────────────────┼───────────────────────┐
          │                       │                       │
          ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  CODE ANALYST   │    │ DATABASE ANALYST│    │DOCUMENT ANALYST │
│  (codestral)    │    │ (llama3.1:70b)  │    │ (llama3.1:70b)  │
└────────┬────────┘    └────────┬────────┘    └────────┬────────┘
         │                      │                      │
         └──────────────────────┼──────────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │    SYSTEM ARCHITECT         │
                    │    (llama3.1:70b)           │
                    └─────────────┬───────────────┘
                                  │
                                  ▼
                    ┌─────────────────────────────┐
                    │   REQUIREMENTS WRITER       │
                    │   (llama3.1:70b)            │
                    └─────────────────────────────┘
```

---

## Key Files Reference

### Entry Points

| File | Purpose |
|------|---------|
| `backend/app/main.py` | FastAPI application entry |
| `backend/app/api/v1/routes/analysis.py` | Analysis API endpoints |
| `backend/app/workers/tasks.py` | Celery background tasks |
| `backend/app/agents/graphs/legacy_analysis_graph.py` | Main LangGraph workflow |

### Agent Implementations

| File | Agent |
|------|-------|
| `backend/app/agents/nodes/analysis/code_analyzer.py` | Code Analyzer |
| `backend/app/agents/nodes/analysis/database_analyst.py` | Database Analyst |
| `backend/app/agents/nodes/analysis/document_analyst.py` | Document Analyst |
| `backend/app/agents/nodes/analysis/system_architect.py` | System Architect |
| `backend/app/agents/nodes/analysis/requirements_writer.py` | Requirements Writer |

### State and Tools

| File | Purpose |
|------|---------|
| `backend/app/agents/state/legacy_analysis_state.py` | State definitions |
| `backend/app/agents/tools/rag_tools.py` | RAG search tool |
| `backend/app/rag/ingestion/pipeline.py` | Code ingestion |

---

## Process Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                    END-TO-END PROCESS FLOW                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  STAGE 1: UPLOAD                                                    │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ POST /projects/{id}/uploads/code       → Upload 4GL/VB.NET  │    │
│  │ POST /projects/{id}/uploads/database   → Upload Ingres DDL  │    │
│  │ POST /projects/{id}/uploads/documentation → Upload docs     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                      │
│                              ▼                                      │
│  STAGE 2: TRIGGER ANALYSIS                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ POST /projects/{id}/analysis/start → Queues Celery task     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                      │
│                              ▼                                      │
│  STAGE 3: LANGGRAPH WORKFLOW (13 Nodes)                             │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ INGEST → DEAD_CODE_DETECT → CODE_ANALYSIS → DB_ANALYSIS     │    │
│  │ → DOC_ANALYSIS → BR_EXTRACTION → INTEGRATION_MAPPING        │    │
│  │ → CROSS_REFERENCE → GRAPH_FINALIZE → SYNTHESIS              │    │
│  │ → REQUIREMENTS → SME_PREP → OUTPUT                          │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                      │
│                              ▼                                      │
│  STAGE 4: RETRIEVE RESULTS                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ GET /projects/{id}/analysis → Returns complete results      │    │
│  │ GET /projects/{id}/analysis/requirements → FR/NFR/BR        │    │
│  │ GET /projects/{id}/analysis/business-rules → Rules catalog  │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Technology Stack

### Backend

| Component | Technology |
|-----------|------------|
| Framework | FastAPI |
| Agent Framework | LangGraph |
| LLM Framework | LangChain |
| Local LLM | Ollama |
| Vector Database | Qdrant |
| Database | PostgreSQL |
| Task Queue | Celery + Redis |
| ORM | SQLAlchemy 2.0 (async) |

### LLM Models

| Task | Model | Quantization |
|------|-------|--------------|
| Primary Analysis | llama3.1:70b-instruct | Q4_K_M |
| Code Analysis | codestral:22b | Q4_K_M |
| Fast/Orchestration | llama3.1:8b-instruct | Q4_K_M |
| Embeddings | nomic-embed-text | - |

### Hardware Constraints

| Component | Specification |
|-----------|---------------|
| GPU | NVIDIA RTX 4070 (8GB VRAM) |
| RAM | 64GB |
| Strategy | Single model loaded at a time |

---

## Getting Started

### For System Analysts

1. Start with [System Overview](./01-system-overview.md) to understand the architecture
2. Read [Process Flow](./03-process-flow.md) for end-to-end workflow
3. Review [Agent Collaboration](./05-agent-collaboration.md) for agent responsibilities
4. Check [Sequence Diagrams](./08-sequence-diagrams.md) for visual flows

### For Developers

1. Start with [Call Hierarchy](./02-call-hierarchy.md) for code tracing
2. Study [RAG Pipeline](./04-rag-pipeline.md) for vector database operations
3. Review [State Management](./06-state-management.md) for LangGraph state
4. Reference [API Reference](./07-api-reference.md) for endpoint integration

---

## Related Documentation

- [Main Architecture Document](../architecture/analysis-phase-architecture.md) - Source of truth
- [CLAUDE.md](../../CLAUDE.md) - Project instructions and quick reference
- [Changelog](../requirements/CHANGELOG.md) - Development history

---

## Contact

For questions about this documentation or the Renovo system, please refer to the project repository.
