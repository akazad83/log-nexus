# API Reference

> **Document**: 07 - API Reference
> **Audience**: Developers, Frontend Engineers

---

## 1. Overview

This document covers the API endpoints related to the analysis workflow, including uploads, analysis control, and results retrieval.

---

## 2. Base URL

```
http://localhost:8000/api/v1
```

---

## 3. Upload Endpoints

### 3.1 Upload Code Files

Upload legacy code files (4GL, VB.NET) to a project.

```
POST /projects/{project_id}/uploads/code
```

**Request**:
```
Content-Type: multipart/form-data

files: [File]  # One or more files
```

**Supported Extensions**:
- 4GL: `.4gl`, `.per`, `.rep`, `.frm`, `.w`, `.i`, `.p`
- VB.NET: `.vb`, `.aspx`, `.asmx`

**Response** (200 OK):
```json
[
  {
    "id": 1,
    "project_id": 123,
    "filename": "20240118_120000_CustomerForm.4gl",
    "original_filename": "CustomerForm.4gl",
    "file_type": "code",
    "file_size": 45230,
    "mime_type": "text/plain",
    "uploaded_at": "2024-01-18T12:00:00Z"
  }
]
```

---

### 3.2 Upload Database Scripts

Upload Ingres DDL and database scripts.

```
POST /projects/{project_id}/uploads/database
```

**Supported Extensions**: `.sql`, `.ddl`, `.prc`, `.sp`, `.fnc`, `.trg`

**Response**: Same format as code upload.

---

### 3.3 Upload Documentation

Upload existing documentation files.

```
POST /projects/{project_id}/uploads/documentation
```

**Supported Extensions**: `.md`, `.txt`, `.pdf`, `.doc`, `.docx`

**Response**: Same format as code upload.

---

### 3.4 List Uploaded Files

```
GET /projects/{project_id}/uploads
```

**Query Parameters**:
| Parameter | Type | Description |
|-----------|------|-------------|
| `file_type` | string | Filter by type: "code", "database", "documentation" |
| `limit` | integer | Max results (default: 100) |
| `offset` | integer | Pagination offset |

**Response** (200 OK):
```json
{
  "items": [
    {
      "id": 1,
      "filename": "...",
      "file_type": "code",
      "file_size": 45230,
      "uploaded_at": "2024-01-18T12:00:00Z"
    }
  ],
  "total": 47,
  "limit": 100,
  "offset": 0
}
```

---

## 4. Analysis Endpoints

### 4.1 Start Analysis

Trigger the analysis workflow for a project.

```
POST /projects/{project_id}/analysis/start
```

**Pre-conditions**:
- Project must exist
- Project status must be `UPLOADING` or `FAILED`
- Project must have uploaded files

**Response** (202 Accepted):
```json
{
  "task_id": "abc-123-def-456",
  "status": "pending",
  "message": "Analysis task queued",
  "progress": 0.0
}
```

**Error Responses**:
- `404 Not Found`: Project not found
- `400 Bad Request`: Invalid project status or no files uploaded

---

### 4.2 Get Analysis Status

Get the current status of analysis for a project.

```
GET /projects/{project_id}/analysis/status
```

**Response** (200 OK):
```json
{
  "project_id": 123,
  "status": "analyzing",
  "has_results": false,
  "analysis_id": null,
  "task_id": "abc-123-def-456",
  "progress": 45.0,
  "current_phase": "database_analysis",
  "started_at": "2024-01-18T12:00:00Z",
  "completed_at": null,
  "error": null
}
```

**Status Values**:
| Status | Description |
|--------|-------------|
| `pending` | Analysis queued but not started |
| `analyzing` | Analysis in progress |
| `completed` | Analysis finished successfully |
| `failed` | Analysis encountered errors |

---

### 4.3 Get Analysis Results

Retrieve complete analysis results.

```
GET /projects/{project_id}/analysis
```

**Response** (200 OK):
```json
{
  "id": 789,
  "project_id": 123,
  "code_summary": {
    "total_files": 47,
    "total_lines": 15234,
    "languages": {
      "4GL": {"files": 28, "lines": 9845},
      "VB.NET": {"files": 12, "lines": 4123},
      "SQL": {"files": 7, "lines": 1266}
    },
    "complexity_metrics": {
      "average": 8.3,
      "high_complexity_count": 12,
      "maintainability_index": 62.5
    }
  },
  "database_schema": {
    "tables": [...],
    "views": [...],
    "stored_procedures": [...],
    "relationships": [...]
  },
  "requirements": {
    "functional": [...],
    "non_functional": [...],
    "business_rules": [...]
  },
  "architecture": {
    "current": {...},
    "proposed": {...},
    "migration_strategy": {...}
  },
  "analysis_summary": "...",
  "created_at": "2024-01-18T12:30:00Z"
}
```

---

### 4.4 Get Specific Result Components

#### Code Summary
```
GET /projects/{project_id}/analysis/code-summary
```

#### Database Schema
```
GET /projects/{project_id}/analysis/database-schema
```

#### Requirements
```
GET /projects/{project_id}/analysis/requirements
```

#### Functional Requirements
```
GET /projects/{project_id}/analysis/functional-requirements
```

**Query Parameters**:
| Parameter | Type | Description |
|-----------|------|-------------|
| `priority` | string | Filter: "high", "medium", "low" |
| `subsystem` | string | Filter by subsystem name |

#### Non-Functional Requirements
```
GET /projects/{project_id}/analysis/non-functional-requirements
```

#### Business Rules
```
GET /projects/{project_id}/analysis/business-rules
```

**Query Parameters**:
| Parameter | Type | Description |
|-----------|------|-------------|
| `domain` | string | Filter by business domain |
| `type` | string | Filter: "validation", "calculation", "workflow" |
| `min_confidence` | float | Minimum confidence score (0-1) |

#### Architecture
```
GET /projects/{project_id}/analysis/architecture
```

#### Executive Summary
```
GET /projects/{project_id}/analysis/executive-summary
```

#### Sub-Systems
```
GET /projects/{project_id}/analysis/sub-systems
```

Returns per-subsystem analysis details.

---

## 5. Task Status Endpoints

### 5.1 Get Task Status

Check the status of a Celery task.

```
GET /tasks/{task_id}
```

**Response** (200 OK):
```json
{
  "task_id": "abc-123-def-456",
  "status": "STARTED",
  "ready": false,
  "successful": null,
  "result": null,
  "error": null,
  "progress": 45,
  "message": "Running database analysis"
}
```

**Task States**:
| State | Description |
|-------|-------------|
| `PENDING` | Task queued, not yet picked up |
| `STARTED` | Task is running |
| `SUCCESS` | Task completed successfully |
| `FAILURE` | Task failed with error |
| `RETRY` | Task is being retried |

---

### 5.2 Get Workflow Progress

Get detailed workflow progress with per-step status.

```
GET /tasks/workflows/{workflow_id}/progress
```

**Response** (200 OK):
```json
{
  "workflow_id": "wf-abc-123",
  "workflow_type": "analysis",
  "project_id": "123",
  "total_steps": 13,
  "completed_steps": 5,
  "current_step": "database_analysis",
  "status": "in_progress",
  "percentage": 38.5,
  "steps": [
    {
      "name": "ingest",
      "status": "completed",
      "progress": 100,
      "started_at": "2024-01-18T12:00:00Z",
      "completed_at": "2024-01-18T12:02:00Z"
    },
    {
      "name": "dead_code_detect",
      "status": "completed",
      "progress": 100,
      "started_at": "2024-01-18T12:02:00Z",
      "completed_at": "2024-01-18T12:03:00Z"
    },
    {
      "name": "code_analysis",
      "status": "completed",
      "progress": 100,
      "started_at": "2024-01-18T12:03:00Z",
      "completed_at": "2024-01-18T12:08:00Z"
    },
    {
      "name": "database_analysis",
      "status": "in_progress",
      "progress": 60,
      "started_at": "2024-01-18T12:08:00Z",
      "completed_at": null
    },
    {
      "name": "document_analysis",
      "status": "pending",
      "progress": 0
    }
  ],
  "errors": [],
  "warnings": []
}
```

---

## 6. Report Endpoints

### 6.1 Generate Report

Generate a downloadable report from analysis results.

```
POST /projects/{project_id}/reports/generate
```

**Request Body**:
```json
{
  "format": "pdf",
  "sections": [
    "executive_summary",
    "code_analysis",
    "database_schema",
    "requirements",
    "architecture"
  ],
  "include_charts": true
}
```

**Response** (202 Accepted):
```json
{
  "report_id": "rpt-xyz-789",
  "status": "generating",
  "message": "Report generation started"
}
```

---

### 6.2 List Reports

```
GET /projects/{project_id}/reports
```

**Response** (200 OK):
```json
{
  "items": [
    {
      "id": "rpt-xyz-789",
      "project_id": 123,
      "format": "pdf",
      "status": "ready",
      "file_size": 1245678,
      "created_at": "2024-01-18T13:00:00Z"
    }
  ]
}
```

---

### 6.3 Download Report

```
GET /reports/{report_id}/download
```

**Response**: Binary file download with appropriate Content-Type header.

---

## 7. Error Response Format

All error responses follow this format:

```json
{
  "detail": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "field": "field_name",
    "context": {}
  }
}
```

**Common Error Codes**:

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `PROJECT_NOT_FOUND` | 404 | Project does not exist |
| `INVALID_PROJECT_STATUS` | 400 | Action not allowed in current status |
| `NO_FILES_UPLOADED` | 400 | Cannot start analysis without files |
| `ANALYSIS_NOT_FOUND` | 404 | No analysis results for project |
| `TASK_NOT_FOUND` | 404 | Celery task not found |
| `INVALID_FILE_TYPE` | 400 | Unsupported file extension |
| `FILE_TOO_LARGE` | 413 | File exceeds size limit |

---

## 8. Rate Limits

| Endpoint | Limit |
|----------|-------|
| `POST /analysis/start` | 1 request/minute |
| `POST /uploads/*` | 10 requests/minute |
| `GET /*` | 60 requests/minute |

---

## 9. Example: Complete Workflow

### Step 1: Create Project

```bash
curl -X POST http://localhost:8000/api/v1/projects \
  -H "Content-Type: application/json" \
  -d '{"name": "Legacy Modernization", "description": "Customer management system"}'
```

### Step 2: Upload Files

```bash
# Upload code
curl -X POST http://localhost:8000/api/v1/projects/123/uploads/code \
  -F "files=@CustomerForm.4gl" \
  -F "files=@OrderProcessor.4gl"

# Upload database scripts
curl -X POST http://localhost:8000/api/v1/projects/123/uploads/database \
  -F "files=@schema.sql"

# Upload documentation
curl -X POST http://localhost:8000/api/v1/projects/123/uploads/documentation \
  -F "files=@README.md"
```

### Step 3: Start Analysis

```bash
curl -X POST http://localhost:8000/api/v1/projects/123/analysis/start
```

### Step 4: Poll Status

```bash
# Poll every 2 seconds
while true; do
  curl http://localhost:8000/api/v1/tasks/abc-123-def-456
  sleep 2
done
```

### Step 5: Get Results

```bash
curl http://localhost:8000/api/v1/projects/123/analysis
```

---

## 10. Key Files Reference

| File | Description |
|------|-------------|
| `api/v1/routes/projects.py` | Project CRUD endpoints |
| `api/v1/routes/uploads.py` | File upload endpoints |
| `api/v1/routes/analysis.py` | Analysis control endpoints |
| `api/v1/routes/tasks.py` | Task status endpoints |
| `api/v1/routes/reports.py` | Report generation endpoints |
| `schemas/project.py` | Request/response schemas |
| `schemas/analysis.py` | Analysis result schemas |
