# Welcome to MD Viewer

This is a sample markdown file to demonstrate the viewer.

## Features

- Browse markdown files from the sidebar
- View file content in the main panel
- Secure file access (no directory traversal)

## Getting Started

1. Add your `.md` files to the `./docs` folder
2. Start the backend: `cd backend && cargo run`
3. Start the frontend: `cd frontend && npm install && npm run dev`
4. Open http://localhost:5173 in your browser
