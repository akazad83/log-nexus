# API Reference

This document describes the REST API endpoints available in DocuHub.

## Endpoints

### List Files

```
GET /api/files
```

Returns a JSON array of all markdown files in the docs directory.

**Response:**
```json
[
  {
    "name": "welcome.md",
    "path": "welcome.md",
    "size": 1234,
    "createdAt": "2025-01-19T12:00:00Z",
    "modifiedAt": "2025-01-19T12:00:00Z"
  }
]
```

### Get File Content

```
GET /api/files/{path}
```

Returns the content of a specific markdown file.

**Response:**
```json
{
  "name": "welcome.md",
  "path": "welcome.md",
  "content": "# Welcome...",
  "size": 1234,
  "createdAt": "2025-01-19T12:00:00Z",
  "modifiedAt": "2025-01-19T12:00:00Z"
}
```

### Update File

```
PUT /api/files/{path}
```

Updates or creates a markdown file.

**Request Body:**
```json
{
  "content": "# Updated content..."
}
```

### Delete File

```
DELETE /api/files/{path}
```

Deletes a markdown file.

**Response:** `204 No Content`

### Export to PDF

```
POST /api/export/pdf
```

Converts markdown content to a PDF document.

**Request Body:**
```json
{
  "markdown": "# Document Title...",
  "fileName": "document"
}
```

**Response:** Binary PDF file
