# DocuHub - MD Viewer

A local markdown file viewer with a **.NET backend** and Angular frontend.

## Tech Stack

- **Backend**: .NET 9 with ASP.NET Core Minimal APIs (C# 13)
- **Frontend**: Angular 19 with TypeScript, Standalone Components, Signals, and Tailwind CSS

## Project Structure

```
docu-hub/
├── CLAUDE.md              # Project documentation (this file)
├── ARCHITECTURE.md        # Detailed system architecture
├── md-viewer.sln          # Solution file
├── src/
│   ├── DocuHub.Api/       # ASP.NET Core Web API
│   │   ├── Program.cs     # Entry point & endpoint definitions
│   │   ├── Endpoints/     # Minimal API endpoint classes
│   │   ├── appsettings.json
│   │   └── DocuHub.Api.csproj
│   ├── DocuHub.Core/      # Core library (business logic)
│   │   ├── Services/
│   │   │   └── FileIndexerService.cs
│   │   ├── Models/
│   │   │   └── FileMetadata.cs
│   │   ├── Interfaces/
│   │   └── DocuHub.Core.csproj
│   └── DocuHub.Infrastructure/  # Infrastructure (PDF export, etc.)
│       ├── Services/
│       │   └── PdfExportService.cs
│       └── DocuHub.Infrastructure.csproj
├── tests/
│   ├── DocuHub.Api.Tests/
│   └── DocuHub.Core.Tests/
├── frontend/              # Angular application
│   ├── angular.json       # Angular CLI configuration
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   └── src/
│       ├── app/
│       │   ├── app.component.ts
│       │   ├── app.config.ts
│       │   ├── app.routes.ts
│       │   ├── core/          # Services, guards, interceptors
│       │   ├── shared/        # Shared components, pipes, directives
│       │   └── features/      # Feature modules (files, editor, etc.)
│       ├── environments/
│       └── styles.css
└── docs/                  # Markdown files to serve
```

## Core Business Requirements

1. Scan the local `./docs` folder for `.md` files
2. Generate a JSON index of all markdown files
3. Serve markdown file content via REST API
4. Display and navigate files through Angular UI
5. Support file editing, deletion, and PDF export

## Security

**Directory Traversal Prevention**: All file paths are canonicalized using `Path.GetFullPath()` and validated to ensure they remain within the `./docs` directory. Paths containing `..` or attempting to escape the docs root are rejected with a 403 Forbidden response.

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/files` | Returns JSON index of all .md files in ./docs |
| GET | `/api/files/{*path}` | Returns content of a specific .md file |
| PUT | `/api/files/{*path}` | Updates content of a specific .md file |
| DELETE | `/api/files/{*path}` | Deletes a specific .md file |
| POST | `/api/export/pdf` | Exports markdown content to PDF |

## Development Commands

### Backend (.NET)
```bash
cd src/DocuHub.Api

# Run development server (with hot reload)
dotnet watch run

# Run without hot reload
dotnet run

# Build
dotnet build

# Run tests
dotnet test

# Publish for production
dotnet publish -c Release -o ./publish
```

### Frontend (Angular)
```bash
cd frontend

# Install dependencies
npm install

# Run development server
ng serve
# or
npm start

# Production build
ng build
# or
npm run build

# Run linter
ng lint

# Run unit tests
ng test

# Run e2e tests
ng e2e

# Generate component
ng generate component features/my-feature --standalone

# Generate service
ng generate service core/services/my-service
```

### Solution-level Commands
```bash
# Restore all packages
dotnet restore

# Build entire solution
dotnet build

# Run all tests
dotnet test
```

## Default Ports

- Backend: `http://localhost:5001` (HTTPS: `https://localhost:5002`)
- Frontend: `http://localhost:4200`

## Configuration

### appsettings.json
```json
{
  "DocsPath": "./docs",
  "AllowedHosts": "*",
  "Cors": {
    "Origins": ["http://localhost:4200"]
  }
}
```

### Environment Variables
- `ASPNETCORE_ENVIRONMENT`: Development | Staging | Production
- `ASPNETCORE_URLS`: Override default URLs (e.g., `http://localhost:5001`)

## Key Dependencies

### Backend NuGet Packages
```xml
<PackageReference Include="Swashbuckle.AspNetCore" Version="10.*" />
<PackageReference Include="PuppeteerSharp" Version="20.*" />
```

### Frontend npm Packages
```json
{
  "@angular/core": "^19.0.0",
  "@angular/material": "^19.0.0",
  "@angular/cdk": "^19.0.0",
  "ngx-markdown": "^18.0.0",
  "ngx-monaco-editor-v2": "^19.0.0",
  "marked": "^15.0.0",
  "tailwindcss": "^3.4.0",
  "lucide-angular": "^0.400.0"
}
```

## Angular Architecture Standards

### Project Organization
- **Standalone Components**: All components use standalone architecture (no NgModules)
- **Signals**: Use Angular Signals for reactive state management
- **Functional Guards/Resolvers**: Use functional approach for route guards
- **Typed Forms**: Use strongly-typed reactive forms
- **OnPush Change Detection**: Default to OnPush for better performance

### Folder Structure Convention
```
src/app/
├── core/                    # Singleton services, guards, interceptors
│   ├── services/
│   │   ├── api.service.ts
│   │   ├── theme.service.ts
│   │   └── file.service.ts
│   ├── interceptors/
│   │   └── error.interceptor.ts
│   └── guards/
├── shared/                  # Reusable components, pipes, directives
│   ├── components/
│   │   ├── logo/
│   │   └── loading-spinner/
│   ├── pipes/
│   └── directives/
├── features/                # Feature-based modules
│   ├── file-browser/
│   │   ├── file-browser.component.ts
│   │   ├── components/
│   │   │   ├── sidebar/
│   │   │   └── file-tree/
│   │   └── file-browser.routes.ts
│   └── file-viewer/
│       ├── file-viewer.component.ts
│       ├── components/
│       │   ├── markdown-preview/
│       │   └── code-editor/
│       └── file-viewer.routes.ts
├── app.component.ts
├── app.config.ts
└── app.routes.ts
```

### Code Style Guidelines
- Use `inject()` function instead of constructor injection
- Prefer signals over BehaviorSubject for component state
- Use `input()` and `output()` signal-based component APIs
- Implement `trackBy` for all `@for` loops
- Use `@defer` for lazy loading heavy components

## Testing

### Backend Tests
```bash
# Run all tests
dotnet test

# Run with verbose output
dotnet test --logger "console;verbosity=detailed"

# Run specific test project
dotnet test tests/DocuHub.Core.Tests

# Run with coverage
dotnet test --collect:"XPlat Code Coverage"
```

### Frontend Tests
```bash
cd frontend

# Run unit tests
ng test

# Run unit tests with coverage
ng test --code-coverage

# Run e2e tests
ng e2e
```

## Deployment

### Docker Support
```dockerfile
# Backend Dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:9.0 AS base
WORKDIR /app
EXPOSE 5001

FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src
COPY . .
RUN dotnet publish -c Release -o /app/publish

FROM base AS final
WORKDIR /app
COPY --from=build /app/publish .
ENTRYPOINT ["dotnet", "DocuHub.Api.dll"]
```

```dockerfile
# Frontend Dockerfile
FROM node:22-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist/frontend/browser /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
```

### Build Commands
```bash
# Build Docker images
docker build -t docuhub-api:latest -f Dockerfile.api .
docker build -t docuhub-frontend:latest -f frontend/Dockerfile ./frontend

# Run with docker-compose
docker-compose up -d
```

## Claude Code Usage Tips

### Useful Prompts for Angular Development
- "Create a standalone component for the file sidebar with signals"
- "Implement the FileService with HttpClient and error handling"
- "Add theme toggle using Angular signals and localStorage"
- "Create a markdown preview component using ngx-markdown"
- "Implement the Monaco editor component for file editing"
- "Add route guards for unsaved changes confirmation"
- "Create an error interceptor for API error handling"
