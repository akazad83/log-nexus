import {
  Component,
  ElementRef,
  OnInit,
  OnDestroy,
  input,
  output,
  effect,
  viewChild,
  inject,
  PLATFORM_ID
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

declare const monaco: typeof import('monaco-editor');

@Component({
  selector: 'app-monaco-editor',
  standalone: true,
  template: `<div #editorContainer class="w-full h-full"></div>`,
  styles: [':host { display: block; width: 100%; height: 100%; }']
})
export class MonacoEditorComponent implements OnInit, OnDestroy {
  private readonly platformId = inject(PLATFORM_ID);

  readonly value = input<string>('');
  readonly language = input<string>('markdown');
  readonly theme = input<'vs-dark' | 'vs'>('vs-dark');
  readonly readOnly = input<boolean>(false);

  readonly valueChange = output<string>();

  private editorContainer = viewChild.required<ElementRef<HTMLDivElement>>('editorContainer');
  private editor: import('monaco-editor').editor.IStandaloneCodeEditor | null = null;
  private static monacoLoaded = false;

  constructor() {
    effect(() => {
      const newValue = this.value();
      if (this.editor && this.editor.getValue() !== newValue) {
        this.editor.setValue(newValue);
      }
    });

    effect(() => {
      const newTheme = this.theme();
      if (this.editor && isPlatformBrowser(this.platformId)) {
        monaco.editor.setTheme(newTheme);
      }
    });

    effect(() => {
      const newReadOnly = this.readOnly();
      if (this.editor) {
        this.editor.updateOptions({ readOnly: newReadOnly });
      }
    });
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.loadMonaco();
    }
  }

  ngOnDestroy(): void {
    if (this.editor) {
      this.editor.dispose();
    }
  }

  private async loadMonaco(): Promise<void> {
    if (!MonacoEditorComponent.monacoLoaded) {
      await this.loadMonacoScript();
      MonacoEditorComponent.monacoLoaded = true;
    }
    this.initEditor();
  }

  private loadMonacoScript(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (typeof monaco !== 'undefined') {
        resolve();
        return;
      }

      const loaderScript = document.createElement('script');
      loaderScript.src = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/loader.js';
      loaderScript.onload = () => {
        (window as any).require.config({
          paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }
        });
        (window as any).require(['vs/editor/editor.main'], () => {
          resolve();
        });
      };
      loaderScript.onerror = reject;
      document.head.appendChild(loaderScript);
    });
  }

  private initEditor(): void {
    const container = this.editorContainer().nativeElement;

    this.editor = monaco.editor.create(container, {
      value: this.value(),
      language: this.language(),
      theme: this.theme(),
      readOnly: this.readOnly(),
      automaticLayout: true,
      minimap: { enabled: false },
      wordWrap: 'on',
      lineNumbers: 'on',
      scrollBeyondLastLine: false,
      fontSize: 14,
      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
      padding: { top: 16, bottom: 16 }
    });

    this.editor.onDidChangeModelContent(() => {
      if (this.editor) {
        this.valueChange.emit(this.editor.getValue());
      }
    });
  }
}
