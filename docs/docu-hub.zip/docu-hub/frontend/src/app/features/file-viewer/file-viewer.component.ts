import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MarkdownComponent } from 'ngx-markdown';
import { FileService, FileStateService, ThemeService } from '../../core/services';
import { MonacoEditorComponent } from '../../shared/components';

@Component({
  selector: 'app-file-viewer',
  standalone: true,
  imports: [MarkdownComponent, MonacoEditorComponent],
  template: `
    <div class="h-full flex flex-col">
      <!-- Toolbar -->
      <div class="h-12 flex items-center justify-between px-4 border-b border-light-border dark:border-dark-border bg-light-bg-secondary dark:bg-dark-bg-secondary">
        <div class="flex items-center gap-3">
          <button
            (click)="goBack()"
            class="p-1.5 rounded-md hover:bg-light-border dark:hover:bg-dark-border transition-colors"
            aria-label="Go back"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-light-text dark:text-dark-text" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="19" y1="12" x2="5" y2="12"></line>
              <polyline points="12 19 5 12 12 5"></polyline>
            </svg>
          </button>
          <span class="text-sm font-medium text-light-text dark:text-dark-text">
            {{ fileState.fileContent()?.name || 'Loading...' }}
          </span>
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="toggleEdit()"
            class="btn btn-secondary text-sm"
          >
            {{ isEditing() ? 'Preview' : 'Edit' }}
          </button>
          @if (isEditing()) {
            <button
              (click)="saveFile()"
              [disabled]="isSaving()"
              class="btn btn-primary text-sm"
            >
              {{ isSaving() ? 'Saving...' : 'Save' }}
            </button>
          }
          <button
            (click)="exportPdf()"
            [disabled]="isExporting()"
            class="btn btn-secondary text-sm"
          >
            {{ isExporting() ? 'Exporting...' : 'Export PDF' }}
          </button>
          <button
            (click)="deleteFile()"
            class="btn text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
          >
            Delete
          </button>
        </div>
      </div>

      <!-- Content -->
      <div class="flex-1 overflow-hidden">
        @if (fileState.isLoading()) {
          <div class="h-full flex items-center justify-center text-light-text-secondary dark:text-dark-text-secondary">
            Loading...
          </div>
        } @else if (fileState.error()) {
          <div class="h-full flex items-center justify-center text-red-500">
            {{ fileState.error() }}
          </div>
        } @else if (isEditing()) {
          <app-monaco-editor
            [value]="editContent()"
            [theme]="monacoTheme()"
            language="markdown"
            (valueChange)="onContentChange($event)"
          />
        } @else {
          <div class="h-full overflow-y-auto p-6">
            <article class="prose dark:prose-invert max-w-4xl mx-auto">
              <markdown [data]="fileState.fileContent()?.content || ''"></markdown>
            </article>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class FileViewerComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly fileService = inject(FileService);
  private readonly themeService = inject(ThemeService);
  readonly fileState = inject(FileStateService);

  readonly isEditing = signal(false);
  readonly editContent = signal('');
  readonly isSaving = signal(false);
  readonly isExporting = signal(false);

  readonly monacoTheme = computed(() =>
    this.themeService.theme() === 'dark' ? 'vs-dark' : 'vs'
  );

  ngOnInit(): void {
    const path = this.route.snapshot.queryParamMap.get('path');
    if (path) {
      this.loadFile(path);
    } else {
      this.router.navigate(['/']);
    }
  }

  private loadFile(path: string): void {
    this.fileState.setLoading(true);
    this.fileState.setError(null);

    this.fileService.getFile(path).subscribe({
      next: (content) => {
        this.fileState.setFileContent(content);
        this.fileState.selectFile(path);
        this.editContent.set(content.content);
        this.fileState.setLoading(false);
      },
      error: (err) => {
        this.fileState.setError(err.message);
        this.fileState.setLoading(false);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/']);
  }

  toggleEdit(): void {
    if (!this.isEditing()) {
      this.editContent.set(this.fileState.fileContent()?.content || '');
    }
    this.isEditing.update(v => !v);
  }

  onContentChange(value: string): void {
    this.editContent.set(value);
  }

  saveFile(): void {
    const path = this.fileState.selectedFilePath();
    if (!path) return;

    this.isSaving.set(true);

    this.fileService.updateFile(path, this.editContent()).subscribe({
      next: (metadata) => {
        this.fileState.updateFile(metadata);
        const current = this.fileState.fileContent();
        if (current) {
          this.fileState.setFileContent({
            ...current,
            content: this.editContent()
          });
        }
        this.isEditing.set(false);
        this.isSaving.set(false);
      },
      error: (err) => {
        alert('Failed to save: ' + err.message);
        this.isSaving.set(false);
      }
    });
  }

  exportPdf(): void {
    const content = this.fileState.fileContent();
    if (!content) return;

    this.isExporting.set(true);

    this.fileService.exportToPdf(content.content, content.name.replace('.md', '')).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = content.name.replace('.md', '.pdf');
        a.click();
        URL.revokeObjectURL(url);
        this.isExporting.set(false);
      },
      error: (err) => {
        alert('Failed to export: ' + err.message);
        this.isExporting.set(false);
      }
    });
  }

  deleteFile(): void {
    const path = this.fileState.selectedFilePath();
    if (!path) return;

    if (!confirm('Are you sure you want to delete this file?')) {
      return;
    }

    this.fileService.deleteFile(path).subscribe({
      next: () => {
        this.fileState.removeFile(path);
        this.router.navigate(['/']);
      },
      error: (err) => {
        alert('Failed to delete: ' + err.message);
      }
    });
  }
}
