import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ThemeService } from '../../core/services';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <div class="h-full flex flex-col">
      <header class="h-14 flex items-center justify-between px-4 border-b border-light-border dark:border-dark-border bg-light-bg-secondary dark:bg-dark-bg-secondary">
        <!-- Logo and Brand -->
        <div class="flex items-center gap-3">
          <!-- DocuHub Logo -->
          <svg class="h-8 w-8" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Document base -->
            <rect x="6" y="4" width="28" height="32" rx="3" class="fill-light-link dark:fill-dark-link"/>
            <!-- Document fold -->
            <path d="M26 4V12H34L26 4Z" class="fill-light-bg dark:fill-dark-bg" opacity="0.3"/>
            <!-- Markdown "M" symbol -->
            <path d="M12 16V26H14V19.5L17 23.5L20 19.5V26H22V16H20L17 20.5L14 16H12Z" fill="white"/>
            <!-- Down arrow (representing content/docs) -->
            <path d="M25 18V24H23L27 28L31 24H29V18H25Z" fill="white" opacity="0.8"/>
          </svg>
          <h1 class="text-lg font-semibold text-light-text dark:text-dark-text">DocuHub</h1>
        </div>

        <!-- Theme Toggle -->
        <button
          (click)="themeService.toggleTheme()"
          class="p-2 rounded-md hover:bg-light-border dark:hover:bg-dark-border transition-colors"
          [attr.aria-label]="themeService.theme() === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'"
        >
          @if (themeService.theme() === 'dark') {
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-dark-text" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="5"></circle>
              <line x1="12" y1="1" x2="12" y2="3"></line>
              <line x1="12" y1="21" x2="12" y2="23"></line>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
              <line x1="1" y1="12" x2="3" y2="12"></line>
              <line x1="21" y1="12" x2="23" y2="12"></line>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
            </svg>
          } @else {
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-light-text" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
            </svg>
          }
        </button>
      </header>
      <main class="flex-1 overflow-hidden">
        <router-outlet></router-outlet>
      </main>
    </div>
  `
})
export class LayoutComponent {
  readonly themeService = inject(ThemeService);
}
