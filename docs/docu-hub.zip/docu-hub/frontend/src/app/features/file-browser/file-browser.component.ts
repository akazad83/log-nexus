import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { MarkdownComponent } from 'ngx-markdown';
import { FileService, FileStateService, ThemeService } from '../../core/services';
import { FileMetadata } from '../../core/models';
import { MonacoEditorComponent } from '../../shared/components';

type ViewMode = 'preview' | 'code' | 'edit';

@Component({
  selector: 'app-file-browser',
  standalone: true,
  imports: [MarkdownComponent, MonacoEditorComponent],
  template: `
    <div class="h-full flex">
      <!-- Sidebar -->
      <aside class="w-64 flex-shrink-0 border-r border-light-border dark:border-dark-border bg-light-bg-secondary dark:bg-dark-bg-secondary overflow-y-auto">
        <div class="p-3">
          <div class="flex items-center gap-2 px-2 py-1.5 mb-2">
            <svg class="w-4 h-4 text-light-text-secondary dark:text-dark-text-secondary" viewBox="0 0 16 16" fill="currentColor">
              <path d="M1.75 1A1.75 1.75 0 0 0 0 2.75v10.5C0 14.216.784 15 1.75 15h12.5A1.75 1.75 0 0 0 16 13.25v-8.5A1.75 1.75 0 0 0 14.25 3H7.5a.25.25 0 0 1-.2-.1l-.9-1.2C6.07 1.26 5.55 1 5 1H1.75Z"/>
            </svg>
            <span class="text-sm font-semibold text-light-text dark:text-dark-text">docs</span>
          </div>

          @if (fileState.isLoading() && fileState.files().length === 0) {
            <div class="px-2 py-4 text-light-text-secondary dark:text-dark-text-secondary text-sm">
              Loading...
            </div>
          } @else {
            <ul class="space-y-0.5">
              @for (file of fileState.files(); track file.path) {
                <li>
                  <button
                    (click)="selectFile(file)"
                    class="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors"
                    [class.bg-light-link]="fileState.selectedFilePath() === file.path"
                    [class.bg-opacity-10]="fileState.selectedFilePath() === file.path"
                    [class.dark:bg-dark-link]="fileState.selectedFilePath() === file.path"
                    [class.dark:bg-opacity-20]="fileState.selectedFilePath() === file.path"
                    [class.text-light-link]="fileState.selectedFilePath() === file.path"
                    [class.dark:text-dark-link]="fileState.selectedFilePath() === file.path"
                    [class.hover:bg-light-border]="fileState.selectedFilePath() !== file.path"
                    [class.dark:hover:bg-dark-border]="fileState.selectedFilePath() !== file.path"
                  >
                    <svg class="w-4 h-4 flex-shrink-0" viewBox="0 0 16 16" fill="currentColor" [class.text-light-text-secondary]="fileState.selectedFilePath() !== file.path" [class.dark:text-dark-text-secondary]="fileState.selectedFilePath() !== file.path">
                      <path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"/>
                    </svg>
                    <span class="truncate" [class.text-light-text]="fileState.selectedFilePath() !== file.path" [class.dark:text-dark-text]="fileState.selectedFilePath() !== file.path">{{ file.name }}</span>
                  </button>
                </li>
              } @empty {
                <li class="px-2 py-4 text-light-text-secondary dark:text-dark-text-secondary text-sm">
                  No markdown files found
                </li>
              }
            </ul>
          }
        </div>
      </aside>

      <!-- Content Area -->
      <div class="flex-1 flex flex-col overflow-hidden">
        @if (fileState.fileContent()) {
          <!-- GitHub-style Toolbar -->
          <div class="flex items-center justify-between px-4 py-2 border-b border-light-border dark:border-dark-border bg-light-bg-secondary dark:bg-dark-bg-secondary">
            <div class="flex items-center gap-3">
              <span class="text-sm font-medium text-light-text dark:text-dark-text">
                {{ fileState.fileContent()?.name }}
              </span>
              <span class="text-xs text-light-text-secondary dark:text-dark-text-secondary">
                {{ lineCount() }} lines · {{ formatBytes(fileState.fileContent()?.size || 0) }}
              </span>
            </div>

            <div class="flex items-center">
              <!-- View Mode Toggle (Preview/Code) -->
              <div class="flex items-center border border-light-border dark:border-dark-border rounded-md mr-2 overflow-hidden">
                <button
                  (click)="setViewMode('preview')"
                  class="px-3 py-1 text-xs font-medium transition-colors"
                  [class.bg-light-link]="viewMode() === 'preview'"
                  [class.text-white]="viewMode() === 'preview'"
                  [class.dark:bg-dark-link]="viewMode() === 'preview'"
                  [class.text-light-text]="viewMode() !== 'preview'"
                  [class.dark:text-dark-text]="viewMode() !== 'preview'"
                  [class.hover:bg-light-border]="viewMode() !== 'preview'"
                  [class.dark:hover:bg-dark-border]="viewMode() !== 'preview'"
                >
                  Preview
                </button>
                <button
                  (click)="setViewMode('code')"
                  class="px-3 py-1 text-xs font-medium border-l border-light-border dark:border-dark-border transition-colors"
                  [class.bg-light-link]="viewMode() === 'code'"
                  [class.text-white]="viewMode() === 'code'"
                  [class.dark:bg-dark-link]="viewMode() === 'code'"
                  [class.text-light-text]="viewMode() !== 'code'"
                  [class.dark:text-dark-text]="viewMode() !== 'code'"
                  [class.hover:bg-light-border]="viewMode() !== 'code'"
                  [class.dark:hover:bg-dark-border]="viewMode() !== 'code'"
                >
                  Code
                </button>
              </div>

              <!-- Action Buttons -->
              <div class="flex items-center gap-1">
                <!-- Copy Raw -->
                <button
                  (click)="copyToClipboard()"
                  class="p-1.5 rounded-md hover:bg-light-border dark:hover:bg-dark-border transition-colors"
                  [class.text-green-500]="copied()"
                  [class.text-light-text-secondary]="!copied()"
                  [class.dark:text-dark-text-secondary]="!copied()"
                  title="Copy raw content"
                >
                  @if (copied()) {
                    <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                      <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"/>
                    </svg>
                  } @else {
                    <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                      <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"/>
                      <path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"/>
                    </svg>
                  }
                </button>

                <!-- Edit -->
                <button
                  (click)="setViewMode('edit')"
                  class="p-1.5 rounded-md hover:bg-light-border dark:hover:bg-dark-border transition-colors"
                  [class.text-light-link]="viewMode() === 'edit'"
                  [class.dark:text-dark-link]="viewMode() === 'edit'"
                  [class.text-light-text-secondary]="viewMode() !== 'edit'"
                  [class.dark:text-dark-text-secondary]="viewMode() !== 'edit'"
                  title="Edit file"
                >
                  <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"/>
                  </svg>
                </button>

                <!-- Export PDF -->
                <button
                  (click)="exportPdf()"
                  [disabled]="isExporting()"
                  class="p-1.5 rounded-md hover:bg-light-border dark:hover:bg-dark-border transition-colors text-light-text-secondary dark:text-dark-text-secondary disabled:opacity-50"
                  title="Export to PDF"
                >
                  <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"/>
                    <path d="M7.25 7.689V2a.75.75 0 0 1 1.5 0v5.689l1.97-1.969a.749.749 0 1 1 1.06 1.06l-3.25 3.25a.749.749 0 0 1-1.06 0L4.22 6.78a.749.749 0 1 1 1.06-1.06l1.97 1.969Z"/>
                  </svg>
                </button>

                <!-- Delete -->
                <button
                  (click)="deleteFile()"
                  class="p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-light-text-secondary dark:text-dark-text-secondary hover:text-red-500"
                  title="Delete file"
                >
                  <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M11 1.75V3h2.25a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1 0-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75ZM4.496 6.675l.66 6.6a.25.25 0 0 0 .249.225h5.19a.25.25 0 0 0 .249-.225l.66-6.6a.75.75 0 0 1 1.492.149l-.66 6.6A1.748 1.748 0 0 1 10.595 15h-5.19a1.75 1.75 0 0 1-1.741-1.575l-.66-6.6a.75.75 0 1 1 1.492-.15ZM6.5 1.75V3h3V1.75a.25.25 0 0 0-.25-.25h-2.5a.25.25 0 0 0-.25.25Z"/>
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <!-- Edit Mode Toolbar -->
          @if (viewMode() === 'edit') {
            <div class="flex items-center justify-between px-4 py-2 border-b border-light-border dark:border-dark-border bg-yellow-50 dark:bg-yellow-900/20">
              <span class="text-sm text-yellow-700 dark:text-yellow-400">
                Editing {{ fileState.fileContent()?.name }}
              </span>
              <div class="flex items-center gap-2">
                <button
                  (click)="cancelEdit()"
                  class="px-3 py-1 text-sm rounded-md border border-light-border dark:border-dark-border hover:bg-light-border dark:hover:bg-dark-border transition-colors text-light-text dark:text-dark-text"
                >
                  Cancel
                </button>
                <button
                  (click)="saveFile()"
                  [disabled]="isSaving()"
                  class="px-3 py-1 text-sm rounded-md bg-green-600 hover:bg-green-700 text-white transition-colors disabled:opacity-50"
                >
                  {{ isSaving() ? 'Saving...' : 'Commit changes' }}
                </button>
              </div>
            </div>
          }

          <!-- Content -->
          <div class="flex-1 overflow-hidden">
            @if (isLoadingContent()) {
              <div class="h-full flex items-center justify-center text-light-text-secondary dark:text-dark-text-secondary">
                <svg class="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                </svg>
                Loading...
              </div>
            } @else if (viewMode() === 'edit') {
              <app-monaco-editor
                [value]="editContent()"
                [theme]="monacoTheme()"
                language="markdown"
                (valueChange)="onContentChange($event)"
              />
            } @else if (viewMode() === 'code') {
              <app-monaco-editor
                [value]="fileState.fileContent()?.content || ''"
                [theme]="monacoTheme()"
                [readOnly]="true"
                language="markdown"
              />
            } @else {
              <div class="h-full overflow-y-auto p-6 bg-light-bg dark:bg-dark-bg">
                <article class="prose dark:prose-invert max-w-4xl mx-auto prose-headings:border-b prose-headings:border-light-border prose-headings:dark:border-dark-border prose-headings:pb-2">
                  <markdown [data]="fileState.fileContent()?.content || ''"></markdown>
                </article>
              </div>
            }
          </div>
        } @else if (fileState.error()) {
          <div class="h-full flex items-center justify-center text-red-500">
            {{ fileState.error() }}
          </div>
        } @else {
          <!-- Empty State -->
          <div class="h-full flex flex-col items-center justify-center text-light-text-secondary dark:text-dark-text-secondary">
            <svg class="w-16 h-16 mb-4 opacity-50" viewBox="0 0 16 16" fill="currentColor">
              <path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"/>
            </svg>
            <p class="text-lg font-medium mb-1">Select a file to view</p>
            <p class="text-sm">Choose a markdown file from the sidebar</p>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class FileBrowserComponent implements OnInit {
  private readonly fileService = inject(FileService);
  private readonly themeService = inject(ThemeService);
  readonly fileState = inject(FileStateService);

  readonly viewMode = signal<ViewMode>('preview');
  readonly editContent = signal('');
  readonly isSaving = signal(false);
  readonly isExporting = signal(false);
  readonly isLoadingContent = signal(false);
  readonly copied = signal(false);

  readonly monacoTheme = computed(() =>
    this.themeService.theme() === 'dark' ? 'vs-dark' : 'vs'
  );

  readonly lineCount = computed(() => {
    const content = this.fileState.fileContent()?.content || '';
    return content.split('\n').length;
  });

  ngOnInit(): void {
    this.loadFiles();
  }

  private loadFiles(): void {
    this.fileState.setLoading(true);
    this.fileState.setError(null);

    this.fileService.getFiles().subscribe({
      next: (files) => {
        this.fileState.setFiles(files);
        this.fileState.setLoading(false);
      },
      error: (err) => {
        this.fileState.setError(err.message);
        this.fileState.setLoading(false);
      }
    });
  }

  selectFile(file: FileMetadata): void {
    if (this.fileState.selectedFilePath() === file.path) {
      return;
    }

    this.fileState.selectFile(file.path);
    this.viewMode.set('preview');
    this.loadFileContent(file.path);
  }

  private loadFileContent(path: string): void {
    this.isLoadingContent.set(true);
    this.fileState.setError(null);

    this.fileService.getFile(path).subscribe({
      next: (content) => {
        this.fileState.setFileContent(content);
        this.editContent.set(content.content);
        this.isLoadingContent.set(false);
      },
      error: (err) => {
        this.fileState.setError(err.message);
        this.isLoadingContent.set(false);
      }
    });
  }

  setViewMode(mode: ViewMode): void {
    if (mode === 'edit') {
      this.editContent.set(this.fileState.fileContent()?.content || '');
    }
    this.viewMode.set(mode);
  }

  cancelEdit(): void {
    this.editContent.set(this.fileState.fileContent()?.content || '');
    this.viewMode.set('preview');
  }

  onContentChange(value: string): void {
    this.editContent.set(value);
  }

  async copyToClipboard(): Promise<void> {
    const content = this.fileState.fileContent()?.content;
    if (!content) return;

    try {
      await navigator.clipboard.writeText(content);
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch {
      console.error('Failed to copy to clipboard');
    }
  }

  saveFile(): void {
    const path = this.fileState.selectedFilePath();
    if (!path) return;

    this.isSaving.set(true);

    this.fileService.updateFile(path, this.editContent()).subscribe({
      next: (metadata) => {
        this.fileState.updateFile(metadata);
        const current = this.fileState.fileContent();
        if (current) {
          this.fileState.setFileContent({
            ...current,
            content: this.editContent()
          });
        }
        this.viewMode.set('preview');
        this.isSaving.set(false);
      },
      error: (err) => {
        alert('Failed to save: ' + err.message);
        this.isSaving.set(false);
      }
    });
  }

  exportPdf(): void {
    const content = this.fileState.fileContent();
    if (!content) return;

    this.isExporting.set(true);

    this.fileService.exportToPdf(content.content, content.name.replace('.md', '')).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = content.name.replace('.md', '.pdf');
        a.click();
        URL.revokeObjectURL(url);
        this.isExporting.set(false);
      },
      error: (err) => {
        alert('Failed to export: ' + err.message);
        this.isExporting.set(false);
      }
    });
  }

  deleteFile(): void {
    const path = this.fileState.selectedFilePath();
    if (!path) return;

    if (!confirm('Are you sure you want to delete this file?')) {
      return;
    }

    this.fileService.deleteFile(path).subscribe({
      next: () => {
        this.fileState.removeFile(path);
      },
      error: (err) => {
        alert('Failed to delete: ' + err.message);
      }
    });
  }

  formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}
