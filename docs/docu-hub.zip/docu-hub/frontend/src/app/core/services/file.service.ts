import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FileMetadata, FileContent, UpdateFileRequest } from '../models';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiUrl;

  getFiles(): Observable<FileMetadata[]> {
    return this.http.get<FileMetadata[]>(`${this.baseUrl}/files`);
  }

  getFile(path: string): Observable<FileContent> {
    return this.http.get<FileContent>(`${this.baseUrl}/files/${path}`);
  }

  updateFile(path: string, content: string): Observable<FileMetadata> {
    const request: UpdateFileRequest = { content };
    return this.http.put<FileMetadata>(`${this.baseUrl}/files/${path}`, request);
  }

  deleteFile(path: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/files/${path}`);
  }

  exportToPdf(markdown: string, fileName?: string): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/export/pdf`, { markdown, fileName }, {
      responseType: 'blob'
    });
  }
}
