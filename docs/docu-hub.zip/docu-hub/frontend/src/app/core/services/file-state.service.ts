import { Injectable, signal, computed } from '@angular/core';
import { FileMetadata, FileContent } from '../models';

@Injectable({
  providedIn: 'root'
})
export class FileStateService {
  readonly files = signal<FileMetadata[]>([]);
  readonly selectedFilePath = signal<string | null>(null);
  readonly fileContent = signal<FileContent | null>(null);
  readonly isLoading = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly isEditing = signal<boolean>(false);

  readonly selectedFile = computed(() => {
    const path = this.selectedFilePath();
    if (!path) return null;
    return this.files().find(f => f.path === path) ?? null;
  });

  setFiles(files: FileMetadata[]): void {
    this.files.set(files);
  }

  selectFile(path: string | null): void {
    this.selectedFilePath.set(path);
    if (!path) {
      this.fileContent.set(null);
    }
  }

  setFileContent(content: FileContent | null): void {
    this.fileContent.set(content);
  }

  setLoading(loading: boolean): void {
    this.isLoading.set(loading);
  }

  setError(error: string | null): void {
    this.error.set(error);
  }

  toggleEditing(): void {
    this.isEditing.update(v => !v);
  }

  setEditing(editing: boolean): void {
    this.isEditing.set(editing);
  }

  removeFile(path: string): void {
    this.files.update(files => files.filter(f => f.path !== path));
    if (this.selectedFilePath() === path) {
      this.selectedFilePath.set(null);
      this.fileContent.set(null);
    }
  }

  updateFile(metadata: FileMetadata): void {
    this.files.update(files => {
      const index = files.findIndex(f => f.path === metadata.path);
      if (index >= 0) {
        const updated = [...files];
        updated[index] = metadata;
        return updated;
      }
      return [...files, metadata];
    });
  }
}
