export interface UpdateFileRequest {
  content: string;
}
