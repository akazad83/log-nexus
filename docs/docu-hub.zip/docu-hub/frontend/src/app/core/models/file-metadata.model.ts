export interface FileMetadata {
  name: string;
  path: string;
  size: number;
  createdAt: Date;
  modifiedAt: Date;
}
