export interface ExportPdfRequest {
  markdown: string;
  fileName?: string;
}
