import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      {
        path: '',
        loadComponent: () => import('./features/file-browser/file-browser.component').then(m => m.FileBrowserComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];
