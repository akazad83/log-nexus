/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // GitHub-style dark theme
        dark: {
          bg: '#0d1117',
          'bg-secondary': '#161b22',
          text: '#c9d1d9',
          'text-secondary': '#8b949e',
          border: '#30363d',
          link: '#58a6ff',
        },
        // GitHub-style light theme
        light: {
          bg: '#ffffff',
          'bg-secondary': '#f6f8fa',
          text: '#24292f',
          'text-secondary': '#57606a',
          border: '#d0d7de',
          link: '#0969da',
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
}
