# DocuHub System Architecture (.NET + Angular Edition)

## Overview

DocuHub is a local markdown document viewer and editor built with a **.NET 9 backend** and **Angular 19 frontend**. It provides a GitHub-style interface for viewing, editing, and managing markdown documents stored in a local `./docs` directory.

```
┌─────────────────────────────────────────────────────────────────┐
│                         DocuHub                                  │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────┐         ┌─────────────────────┐        │
│  │   Angular Frontend  │  HTTP   │   .NET 9 Backend    │        │
│  │   (Port 4200)       │◄───────►│   (Port 5001)       │        │
│  │                     │  REST   │                     │        │
│  └─────────────────────┘         └──────────┬──────────┘        │
│                                             │                   │
│                                             ▼                   │
│                                  ┌─────────────────────┐        │
│                                  │   File System       │        │
│                                  │   (./docs/*.md)     │        │
│                                  └─────────────────────┘        │
└─────────────────────────────────────────────────────────────────┘
```

## System Components

### 1. Backend Architecture

The backend follows Clean Architecture principles with three main projects:

```
src/
├── DocuHub.Api/              # Presentation Layer (Minimal APIs)
│   ├── Program.cs            # Entry point, DI, endpoints
│   ├── Endpoints/
│   │   ├── FileEndpoints.cs  # File CRUD endpoints
│   │   └── ExportEndpoints.cs
│   └── appsettings.json
│
├── DocuHub.Core/             # Domain/Application Layer
│   ├── Interfaces/
│   │   ├── IFileIndexerService.cs
│   │   └── IPdfExportService.cs
│   ├── Services/
│   │   └── FileIndexerService.cs
│   ├── Models/
│   │   ├── FileMetadata.cs
│   │   └── FileContent.cs
│   └── Exceptions/
│       └── DocuHubException.cs
│
└── DocuHub.Infrastructure/   # Infrastructure Layer
    └── Services/
        └── PdfExportService.cs
```

#### 1.1 Core Library (`DocuHub.Core`)

**Key Components:**

| Component | Description |
|-----------|-------------|
| `IFileIndexerService` | Interface for async file scanning operations |
| `FileIndexerService` | Implementation that recursively finds `.md` files |
| `FileMetadata` | Record containing file name, path, size, timestamps |
| `FileContent` | Record containing file content with metadata |

**FileMetadata Model:**

```csharp
public record FileMetadata(
    string Name,
    string Path,
    long Size,
    DateTime CreatedAt,
    DateTime ModifiedAt
);
```

#### 1.2 API Layer (`DocuHub.Api`)

**API Endpoints:**

| Method | Endpoint | Handler | Description |
|--------|----------|---------|-------------|
| GET | `/api/files` | `ListFilesAsync` | List all markdown files |
| GET | `/api/files/{*path}` | `GetFileAsync` | Read file content |
| PUT | `/api/files/{*path}` | `UpdateFileAsync` | Update file content |
| DELETE | `/api/files/{*path}` | `DeleteFileAsync` | Delete file |
| POST | `/api/export/pdf` | `ExportPdfAsync` | Export to PDF |

**Security Measures:**

1. **Path Traversal Prevention**: All paths canonicalized with `Path.GetFullPath()`
2. **Extension Validation**: Only `.md` files are accessible
3. **Directory Boundary**: Requests cannot escape `./docs` directory

### 2. Frontend Architecture (Angular 19)

The frontend is built with Angular 19 using modern patterns and standalone components.

```
frontend/
├── angular.json              # Angular CLI configuration
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── src/
    ├── index.html
    ├── main.ts               # Application bootstrap
    ├── styles.css            # Global styles (Tailwind)
    ├── environments/
    │   ├── environment.ts
    │   └── environment.prod.ts
    └── app/
        ├── app.component.ts      # Root component
        ├── app.config.ts         # Application configuration
        ├── app.routes.ts         # Route definitions
        ├── core/                 # Singleton services
        │   ├── services/
        │   │   ├── api.service.ts
        │   │   ├── file.service.ts
        │   │   └── theme.service.ts
        │   ├── interceptors/
        │   │   └── error.interceptor.ts
        │   └── models/
        │       ├── file-metadata.model.ts
        │       └── file-content.model.ts
        ├── shared/               # Reusable components
        │   ├── components/
        │   │   ├── logo/
        │   │   ├── loading-spinner/
        │   │   └── confirm-dialog/
        │   ├── pipes/
        │   │   └── file-size.pipe.ts
        │   └── directives/
        └── features/             # Feature components
            ├── layout/
            │   ├── layout.component.ts
            │   ├── header/
            │   └── sidebar/
            ├── file-browser/
            │   ├── file-browser.component.ts
            │   └── components/
            │       └── file-tree/
            └── file-viewer/
                ├── file-viewer.component.ts
                └── components/
                    ├── markdown-preview/
                    └── code-editor/
```

#### 2.1 Application Configuration

**app.config.ts:**
```typescript
import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { routes } from './app.routes';
import { errorInterceptor } from './core/interceptors/error.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([errorInterceptor])),
    provideAnimationsAsync(),
  ]
};
```

#### 2.2 Routing Structure

**app.routes.ts:**
```typescript
import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/layout/layout.component')
      .then(m => m.LayoutComponent),
    children: [
      {
        path: '',
        loadComponent: () => import('./features/file-browser/file-browser.component')
          .then(m => m.FileBrowserComponent)
      },
      {
        path: 'view/:path',
        loadComponent: () => import('./features/file-viewer/file-viewer.component')
          .then(m => m.FileViewerComponent)
      }
    ]
  }
];
```

#### 2.3 Core Services

**FileService with Signals:**
```typescript
import { Injectable, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { toSignal } from '@angular/core/rxjs-interop';

@Injectable({ providedIn: 'root' })
export class FileService {
  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:5001/api';

  // State signals
  private _files = signal<FileMetadata[]>([]);
  private _selectedFile = signal<FileContent | null>(null);
  private _loading = signal(false);

  // Public readonly signals
  readonly files = this._files.asReadonly();
  readonly selectedFile = this._selectedFile.asReadonly();
  readonly loading = this._loading.asReadonly();

  // Computed signals
  readonly fileCount = computed(() => this._files().length);
  readonly hasSelection = computed(() => this._selectedFile() !== null);

  async loadFiles(): Promise<void> {
    this._loading.set(true);
    try {
      const files = await firstValueFrom(
        this.http.get<FileMetadata[]>(`${this.apiUrl}/files`)
      );
      this._files.set(files);
    } finally {
      this._loading.set(false);
    }
  }

  async loadFile(path: string): Promise<void> {
    this._loading.set(true);
    try {
      const content = await firstValueFrom(
        this.http.get<FileContent>(`${this.apiUrl}/files/${path}`)
      );
      this._selectedFile.set(content);
    } finally {
      this._loading.set(false);
    }
  }

  async updateFile(path: string, content: string): Promise<void> {
    await firstValueFrom(
      this.http.put(`${this.apiUrl}/files/${path}`, { content })
    );
    await this.loadFiles();
  }

  async deleteFile(path: string): Promise<void> {
    await firstValueFrom(
      this.http.delete(`${this.apiUrl}/files/${path}`)
    );
    this._selectedFile.set(null);
    await this.loadFiles();
  }
}
```

**ThemeService with Signals:**
```typescript
import { Injectable, signal, effect } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private _isDark = signal(this.getInitialTheme());

  readonly isDark = this._isDark.asReadonly();

  constructor() {
    effect(() => {
      const theme = this._isDark() ? 'dark' : 'light';
      document.documentElement.classList.toggle('dark', this._isDark());
      localStorage.setItem('docuhub-theme', theme);
    });
  }

  toggle(): void {
    this._isDark.update(v => !v);
  }

  private getInitialTheme(): boolean {
    const stored = localStorage.getItem('docuhub-theme');
    if (stored) return stored === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
}
```

#### 2.4 Component Architecture

**Standalone Component Pattern:**
```typescript
import { Component, inject, signal, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-file-tree',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="file-tree">
      @for (node of nodes(); track node.path) {
        <div
          class="file-node"
          [class.selected]="node.path === selectedPath()"
          (click)="onSelect(node)">
          {{ node.name }}
        </div>
      }
    </div>
  `
})
export class FileTreeComponent {
  // Signal-based inputs
  nodes = input.required<FileNode[]>();
  selectedPath = input<string>('');

  // Signal-based outputs
  fileSelected = output<FileNode>();

  onSelect(node: FileNode): void {
    this.fileSelected.emit(node);
  }
}
```

#### 2.5 Component Hierarchy

```
<app-root>
  └── <app-layout>
        ├── <app-header>
        │     ├── <app-logo />
        │     └── <app-theme-toggle />
        ├── <app-sidebar>
        │     ├── <app-search-input />
        │     ├── <app-file-count />
        │     └── <app-file-tree>
        │           ├── <app-folder-node />
        │           └── <app-file-node />
        └── <router-outlet>
              └── <app-file-viewer>
                    ├── <app-file-header />
                    ├── <app-view-mode-toggle />
                    ├── <app-action-buttons />
                    └── <app-content-area>
                          ├── <app-markdown-preview />  (@defer)
                          └── <ngx-monaco-editor />     (@defer)
```

### 3. PDF Export System

The PDF export uses PuppeteerSharp (headless Chrome) for high-fidelity rendering.

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Angular    │     │   Backend   │     │  Chromium   │
│  Frontend   │     │   (.NET)    │     │  (Headless) │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       │ POST /api/export/pdf                  │
       │ { html, filename }│                   │
       │──────────────────►│                   │
       │                   │  Launch browser   │
       │                   │──────────────────►│
       │                   │  Generate PDF     │
       │                   │──────────────────►│
       │                   │◄──────────────────│
       │◄──────────────────│  PDF bytes        │
       │  application/pdf  │                   │
```

### 4. Theme System

```
┌─────────────────────────────────────────────────────────────┐
│                      Theme Architecture                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐   │
│  │ localStorage │◄──►│ThemeService  │◄──►│  Components  │   │
│  │'docuhub-     │    │              │    │              │   │
│  │ theme'       │    │isDark: Signal│    │isDark: bool  │   │
│  └──────────────┘    │toggle()      │    │colors: {...} │   │
│                      └──────────────┘    └──────────────┘   │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│            Tailwind Dark Mode (class strategy)               │
├──────────────────────────┬──────────────────────────────────┤
│         Dark             │            Light                  │
├──────────────────────────┼──────────────────────────────────┤
│ bg:       #0d1117        │ bg:       #ffffff                │
│ bgSecond: #161b22        │ bgSecond: #f6f8fa                │
│ text:     #c9d1d9        │ text:     #24292f                │
│ textSec:  #8b949e        │ textSec:  #57606a                │
│ border:   #30363d        │ border:   #d0d7de                │
│ link:     #58a6ff        │ link:     #0969da                │
└──────────────────────────┴──────────────────────────────────┘
```

### 5. File Tree Construction

Same algorithm as before - builds tree from flat file list in the Sidebar component.

```
Input (flat):                    Output (tree):
[                                {
  { path: "a.md" },                name: "",
  { path: "dir/b.md" },            children: [
  { path: "dir/sub/c.md" }           { name: "dir", isFolder: true,
]                                      children: [
                                         { name: "sub", isFolder: true,
                                           children: [
                                             { name: "c.md", isFolder: false }
                                           ]
                                         },
                                         { name: "b.md", isFolder: false }
                                       ]
                                     },
                                     { name: "a.md", isFolder: false }
                                   ]
                                 }
```

## Technology Stack

### Backend (.NET 9)

| Technology | Version | Purpose |
|------------|---------|---------|
| .NET | 9.0 | Runtime |
| C# | 13 | Programming language |
| ASP.NET Core | 9.0 | Web framework (Minimal APIs) |
| PuppeteerSharp | 20.x | PDF generation (headless Chrome) |
| Swashbuckle | 10.x | OpenAPI/Swagger documentation |
| xUnit | 2.x | Testing framework |
| FluentAssertions | 8.x | Test assertions |

### Frontend (Angular 19)

| Technology | Version | Purpose |
|------------|---------|---------|
| Angular | 19.x | UI framework |
| TypeScript | 5.6+ | Type safety |
| Angular Material | 19.x | UI components |
| Angular CDK | 19.x | Component development kit |
| ngx-markdown | 18.x | Markdown rendering |
| ngx-monaco-editor-v2 | 19.x | Code editing |
| Tailwind CSS | 3.4 | Styling |
| Lucide Angular | 0.400+ | Icons |
| RxJS | 7.8+ | Reactive programming |

## Security Considerations

### Path Traversal Prevention

```csharp
public string GetSafePath(string requestedPath)
{
    // 1. Combine with docs root and canonicalize
    var fullPath = Path.GetFullPath(Path.Combine(_docsRoot, requestedPath));

    // 2. Verify path is within docs directory
    if (!fullPath.StartsWith(_docsRoot, StringComparison.OrdinalIgnoreCase))
    {
        throw new UnauthorizedAccessException(
            "Access denied: path outside docs directory");
    }

    return fullPath;
}
```

### CORS Configuration

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});
```

## Performance Considerations

### Backend
1. **Async I/O**: All file operations use `async/await`
2. **Lazy Loading**: Files loaded on-demand
3. **Efficient Enumeration**: Use `EnumerateFiles` for large directories

### Frontend (Angular)
1. **OnPush Change Detection**: All components use OnPush
2. **Lazy Loading**: Routes and heavy components loaded on demand
3. **Signals**: Efficient reactivity with minimal change detection
4. **@defer**: Heavy components like Monaco editor deferred
5. **trackBy**: All loops use trackBy for efficient DOM updates

## Deployment

### Development

```bash
# Terminal 1: Backend
cd src/DocuHub.Api
dotnet watch run

# Terminal 2: Frontend
cd frontend
ng serve
```

### Production Build

```bash
# Backend
dotnet publish -c Release -o ./publish

# Frontend
cd frontend
ng build --configuration production
```

### Docker Compose (Full Stack)

```yaml
version: '3.8'
services:
  backend:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "5001:5001"
    volumes:
      - ./docs:/app/docs
    environment:
      - ASPNETCORE_ENVIRONMENT=Production
      - ASPNETCORE_URLS=http://+:5001

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "80:80"
    depends_on:
      - backend
```

### Environment Configuration

| Service | Default Port | Environment Variable |
|---------|-------------|---------------------|
| Backend | 5001 | `ASPNETCORE_URLS` |
| Backend HTTPS | 5002 | `ASPNETCORE_URLS` |
| Frontend Dev | 4200 | Via angular.json |
| Frontend Prod | 80 | Nginx configuration |

## Implementation Phases

### Completed
- [x] Phase 1: .NET Solution Setup
- [x] Phase 2: Core Library (Models & Interfaces)
- [x] Phase 3: Core Services (FileIndexerService)
- [x] Phase 4: API Layer (Minimal API endpoints)
- [x] Phase 5: Infrastructure (PdfExportService)
- [x] Phase 6: Backend Tests

### Remaining
- [ ] Phase 7: Angular Setup (CLI, Tailwind, project structure)
- [ ] Phase 8: Angular Core (Services, routing, theme)
- [ ] Phase 9: Angular Components (Sidebar, FileViewer, Editor)
- [ ] Phase 10: Integration & Testing

## Future Architecture Considerations

1. **Real-time Updates**: SignalR for live file watching
2. **State Management**: NgRx for complex state (if needed)
3. **PWA Support**: Service workers for offline access
4. **Authentication**: Angular guards with ASP.NET Core Identity
5. **Search**: Full-text search with Lucene.NET or MeiliSearch
6. **Collaborative Editing**: WebSocket-based real-time editing
