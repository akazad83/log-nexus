# QrDiode — One-Way Optical Data Diode (OT → IT) over Animated QR Codes

QrDiode moves transactional data (files, XML, JSON) from an OT (operational technology)
environment to an IT environment **with no network path whatsoever**: an OT screen plays an
animated stream of QR codes, an IT camera watches it. The channel is strictly one-way —
true data-diode semantics, with fountain coding instead of ACKs.

Unlike the projects that inspired it, **every transfer is signed, encrypted, replay-protected
and content-validated**. Security is not optional and not a later phase.

```
┌─ OT machine ─────────────┐        light        ┌─ IT machine ──────────────────┐
│  QrDiode.Sender (WPF)    │  ═══════════════▶   │  QrDiode.Receiver (WPF)       │
│  encrypt→sign→LT→QR      │   QR carousel       │  camera→decode→verify→store   │
└──────────────────────────┘                     └───────────────────────────────┘
```

## Projects

| Project | What it is |
|---|---|
| `src/QrDiode.Core` | UI-agnostic protocol library: framing, LT fountain codec, crypto envelope, manifest, pipelines. No camera or screen needed — fully unit-testable. |
| `src/QrDiode.Sender` | WPF app for the OT side: fullscreen QR carousel, ring-buffered renderer, live fps control. |
| `src/QrDiode.Receiver` | WPF app for the IT side: webcam capture (FlashCap), native QR decode (zxing-cpp), verification chain, quarantine storage, SQLite journal, audit log. |
| `src/QrDiode.KeyCeremony` | Console tool for the offline key ceremony: keygen (TPM-preferred, non-exportable), public-bundle export/import, fingerprint comparison. |
| `tests/QrDiode.Core.Tests` | 52 tests: LT property tests under loss/shuffle, parser bit-flip fuzzing, crypto tamper/replay/XXE negative paths, full optical loopback through real QR images. |
| `tests/QrDiode.Bench` | Software throughput bench (everything except the physical screen→camera hop). |

## Quick start

**→ Full walkthrough (5-minute single-machine demo + production ceremony): [docs/USER_GUIDE.md](docs/USER_GUIDE.md)**

The fastest way to see it working: build, launch both apps, click **⚡ Demo setup** in each
(provisions and cross-trusts demo keys with full security active), point your webcam at the
sender's screen. Details in the guide.

Requires .NET 10 SDK on Windows.

```powershell
dotnet build
dotnet test tests/QrDiode.Core.Tests
dotnet run --project tests/QrDiode.Bench -c Release
```

### 1. Key ceremony (once, before anything can flow)

```powershell
# On the OT machine
dotnet run --project src/QrDiode.KeyCeremony -- init ot-line-1
dotnet run --project src/QrDiode.KeyCeremony -- export ot-line-1 E:\ot-line-1.json

# On the IT machine
dotnet run --project src/QrDiode.KeyCeremony -- init it-recv-1
dotnet run --project src/QrDiode.KeyCeremony -- export it-recv-1 E:\it-recv-1.json

# Cross-import via removable media, then COMPARE FINGERPRINTS out-of-band (voice):
dotnet run --project src/QrDiode.KeyCeremony -- import E:\it-recv-1.json   # on OT
dotnet run --project src/QrDiode.KeyCeremony -- import E:\ot-line-1.json   # on IT
```

Private keys are created **non-exportable** in Windows CNG (TPM-backed via the Platform
Crypto Provider when available). Only public bundles ever leave a machine.

### 2. Transfer

1. **OT**: run `QrDiode.Sender` → open keys (`ot-line-1`) → pick the receiver → pick a file → Start. The QR carousel plays fullscreen (Esc stops, ↑/↓ adjusts fps).
2. **IT**: run `QrDiode.Receiver` → open keys (`it-recv-1`) → pick the camera → Start receiving → point it at the OT screen. Progress shows blocks decoded; on completion the file lands in the quarantine folder.
3. **Both operators compare the receipt hash** shown on each screen.

Received files are stored under `%LocalAppData%\QrDiode\quarantine\` as
`<sessionId>_<sanitizedName>`; the journal (`journal.db`) and hash-chained audit logs
(`audit\*.jsonl`) live alongside.

## Security model (summary)

* **Confidentiality** — payload is AES-256-GCM encrypted with a per-session key from static-static ECDH P-256 + HKDF-SHA256. Filming the screen yields ciphertext.
* **Authenticity** — the manifest is ECDSA P-256 signed; the receiver verifies against offline-provisioned keys **before touching a single payload byte**.
* **Binding** — the signed manifest carries the ciphertext hash; the GCM AAD carries the session identity. Manifest and ciphertext cannot be mixed and matched.
* **Anti-replay** — session GUID dedupe + per-sender-key monotonic counter high-watermark + ±48 h timestamp window; all three enforced in a transactional SQLite store.
* **Hostile input** — span-based frame parser (fail-fast, allocation-free on reject), CRC-32 pre-filter, XXE-prohibited XML / depth-capped JSON validation, decompression hard-capped at the signed size (zip-bomb guard), filenames sanitized, atomic write-then-rename materialization.
* **Audit** — append-only hash-chained JSONL logs on both ends; `AuditLog.Verify` detects any edit.

Full details, threat model and phased roadmap: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Throughput expectations

Software is not the bottleneck (measured on this repo's bench: QR generation ~1,100 codes/s,
native decode ~370/s, the entire 64 MB receive pipeline ~1 s of CPU). The screen→camera hop
dominates. With a single V30-L lane:

| Effective unique frames/s | Payload rate | 64 MB takes |
|---|---|---|
| 10 | ~13 KB/s | ~83 min |
| 15 | ~20 KB/s | ~55 min |
| 30 | ~40 KB/s | ~28 min |

Small transactional XML/JSON (the common case) completes in seconds. Multi-lane rendering
and camera tuning (Phase 2) raise the ceiling several-fold.
