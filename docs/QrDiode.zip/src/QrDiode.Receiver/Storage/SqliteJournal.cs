using Microsoft.Data.Sqlite;
using QrDiode.Core.Pipeline;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// SQLite-backed (WAL) transfer journal + anti-replay store. One file, fully transactional.
/// Status flow: verified → stored (or duplicate). A 'verified' row without a quarantine file
/// indicates a crash between verification and materialization and is surfaced to the operator.
/// </summary>
public sealed class SqliteJournal : IReplayGuard, IDisposable
{
    private readonly SqliteConnection _connection;
    private readonly TimeProvider _clock;
    private readonly TimeSpan _window;
    private readonly object _lock = new();

    public SqliteJournal(string dbPath, TimeProvider? clock = null, TimeSpan? replayWindow = null)
    {
        _clock = clock ?? TimeProvider.System;
        _window = replayWindow ?? TimeSpan.FromHours(48);
        _connection = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = dbPath,
            Mode = SqliteOpenMode.ReadWriteCreate,
        }.ToString());
        _connection.Open();

        Execute("PRAGMA journal_mode=WAL;");
        Execute("PRAGMA synchronous=FULL;");
        Execute("""
            CREATE TABLE IF NOT EXISTS transfers (
                session_guid     TEXT PRIMARY KEY,
                sender_key_id    TEXT NOT NULL,
                counter          INTEGER NOT NULL,
                plaintext_sha256 TEXT NOT NULL,
                filename         TEXT NOT NULL,
                size             INTEGER NOT NULL,
                received_utc     TEXT NOT NULL,
                status           TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_transfers_hash ON transfers(sender_key_id, plaintext_sha256);
            CREATE TABLE IF NOT EXISTS key_watermarks (
                key_id  TEXT PRIMARY KEY,
                counter INTEGER NOT NULL
            );
            """);
    }

    public ReplayVerdict Check(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter, long timestampUnixMs)
    {
        lock (_lock)
        {
            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "SELECT 1 FROM transfers WHERE session_guid = $g";
                cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
                if (cmd.ExecuteScalar() is not null) return ReplayVerdict.DuplicateSession;
            }

            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "SELECT counter FROM key_watermarks WHERE key_id = $k";
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                if (cmd.ExecuteScalar() is long mark && counter <= (ulong)mark) return ReplayVerdict.StaleCounter;
            }

            long nowMs = _clock.GetUtcNow().ToUnixTimeMilliseconds();
            if (Math.Abs(nowMs - timestampUnixMs) > _window.TotalMilliseconds) return ReplayVerdict.TimestampOutOfWindow;

            return ReplayVerdict.Fresh;
        }
    }

    public void Commit(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter)
    {
        // The engine calls this at verification time; the row is completed by RecordTransfer.
        lock (_lock)
        {
            using var tx = _connection.BeginTransaction();
            using (var cmd = _connection.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = """
                    INSERT INTO key_watermarks(key_id, counter) VALUES ($k, $c)
                    ON CONFLICT(key_id) DO UPDATE SET counter = MAX(counter, excluded.counter);
                    """;
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                cmd.Parameters.AddWithValue("$c", unchecked((long)counter));
                cmd.ExecuteNonQuery();
            }
            using (var cmd = _connection.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = """
                    INSERT OR IGNORE INTO transfers(session_guid, sender_key_id, counter, plaintext_sha256, filename, size, received_utc, status)
                    VALUES ($g, $k, $c, '', '', 0, $t, 'verified');
                    """;
                cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                cmd.Parameters.AddWithValue("$c", unchecked((long)counter));
                cmd.Parameters.AddWithValue("$t", _clock.GetUtcNow().ToString("O"));
                cmd.ExecuteNonQuery();
            }
            tx.Commit();
        }
    }

    /// <summary>True if this sender has already delivered a payload with this plaintext hash.</summary>
    public bool IsDuplicateContent(ReadOnlySpan<byte> senderSigningKeyId, ReadOnlySpan<byte> plaintextSha256)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = "SELECT 1 FROM transfers WHERE sender_key_id = $k AND plaintext_sha256 = $h AND status = 'stored'";
            cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
            cmd.Parameters.AddWithValue("$h", Convert.ToHexString(plaintextSha256));
            return cmd.ExecuteScalar() is not null;
        }
    }

    /// <summary>Completes the journal row for a materialized (or deduplicated) transfer.</summary>
    public void RecordTransfer(Guid sessionId, ReadOnlySpan<byte> plaintextSha256, string filename, long size, string status)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = """
                UPDATE transfers SET plaintext_sha256 = $h, filename = $f, size = $s, status = $st
                WHERE session_guid = $g;
                """;
            cmd.Parameters.AddWithValue("$h", Convert.ToHexString(plaintextSha256));
            cmd.Parameters.AddWithValue("$f", filename);
            cmd.Parameters.AddWithValue("$s", size);
            cmd.Parameters.AddWithValue("$st", status);
            cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
            cmd.ExecuteNonQuery();
        }
    }

    private void Execute(string sql)
    {
        using var cmd = _connection.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    public void Dispose() => _connection.Dispose();
}
