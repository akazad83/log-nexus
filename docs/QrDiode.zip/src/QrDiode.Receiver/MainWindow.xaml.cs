using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using FlashCap;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Pipeline;
using QrDiode.Receiver.Capture;
using QrDiode.Receiver.Storage;

namespace QrDiode.Receiver;

public partial class MainWindow : Window
{
    private CngEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    private SqliteJournal? _journal;
    private ReceiveEngine? _engine;
    private QrDecodePipeline? _pipeline;
    private readonly AuditLog _audit;
    private WriteableBitmap? _previewBitmap;
    private QrDecodePipeline.LumFrame _pendingPreview;
    private readonly DispatcherTimer _uiTimer;
    private DateTime _startedUtc;
    private bool _resultHandled;
    private long _lastQrHits;

    private sealed record CameraChoice(CaptureDeviceDescriptor Descriptor, VideoCharacteristics Characteristics)
    {
        public string Label => $"{Descriptor.Name} — {Characteristics.Width}×{Characteristics.Height}@{Characteristics.FramesPerSecond}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "receiver-audit.jsonl"));
        _uiTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(150) };
        _uiTimer.Tick += OnUiTick;
        RefreshCameras_Click(this, null!);
        RefreshTrustPill();
    }

    private void RefreshTrustPill()
    {
        using var trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);
        int senders = trust.Peers.Count(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId));
        TrustPillText.Text = $"{senders} trusted sender{(senders == 1 ? "" : "s")}";
        TrustPillText.Foreground = (Brush)FindResource(senders > 0 ? "SuccessBrush" : "SubTextBrush");
        TrustPill.Background = new SolidColorBrush(senders > 0
            ? Color.FromArgb(0x33, 0x3D, 0xDC, 0x84)
            : Color.FromArgb(0x33, 0x55, 0x55, 0x66));
    }

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _keys?.Dispose();
            _keys = CngEndpointKeys.OpenOrCreate(EndpointNameBox.Text.Trim());
            KeyInfoText.Text =
                $"kex {KeyId.ToHex(_keys.AgreementKeyId)}  ·  {(_keys.IsTpmBacked ? "TPM-backed" : "software KSP")}\n" +
                "Senders must address transfers to this kex key.";
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            _keys = null;
        }
        RefreshTrustPill();
        UpdateButtons();
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.ItEndpoint;
            OpenKeys_Click(sender, e);
            ProgressText.Text =
                $"Demo ready — full security active.\n" +
                $"ot fingerprint {ids.OtFingerprint}\n" +
                $"it fingerprint {ids.ItFingerprint}\n" +
                "Pick a camera, Start receiving, and point it at the Sender's screen.";
        }
        catch (Exception ex)
        {
            ProgressText.Text = $"Demo setup failed: {ex.Message}";
        }
    }

    private void RefreshCameras_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            CameraCombo.ItemsSource = QrDecodePipeline.EnumerateCameras()
                .Select(c => new CameraChoice(c.Descriptor, c.Characteristics)).ToList();
            if (CameraCombo.Items.Count > 0) CameraCombo.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            ProgressText.Text = $"Camera enumeration failed: {ex.Message}";
        }
        UpdateButtons();
    }

    private void UpdateButtons()
    {
        bool running = _pipeline is not null;
        StartButton.IsEnabled = !running && _keys is not null && CameraCombo.SelectedItem is not null;
        StopButton.IsEnabled = running;
        EndpointNameBox.IsEnabled = !running;
        CameraCombo.IsEnabled = !running;
        StrictModeCheck.IsEnabled = !running;
    }

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (_keys is null || CameraCombo.SelectedItem is not CameraChoice camera) return;

        try
        {
            _trust?.Dispose();
            _trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);
            RefreshTrustPill();
            if (_trust.Peers.Count == 0)
            {
                ProgressText.Text = "Trust store is empty — import the OT sender's bundle (KeyCeremony tool) or use ⚡ Demo setup on both apps.";
                return;
            }

            // Strict mode: shrink the replay acceptance window from 48 h to 15 min.
            var window = StrictModeCheck.IsChecked == true ? TimeSpan.FromMinutes(15) : TimeSpan.FromHours(48);
            _journal?.Dispose();
            _journal = new SqliteJournal(QrDiodePaths.JournalDb, replayWindow: window);

            _engine = new ReceiveEngine(_trust, _journal, _keys);
            _resultHandled = false;
            _startedUtc = DateTime.UtcNow;
            _lastQrHits = 0;
            ResultCard.Visibility = Visibility.Collapsed;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "";
            ProgressText.Text = "waiting for a manifest…";

            _pipeline = new QrDecodePipeline(OnQrPayload, frame => _pendingPreview = frame);
            await _pipeline.StartAsync(camera.Descriptor, camera.Characteristics);

            _audit.Append("receive.started", new Dictionary<string, string>
            {
                ["camera"] = camera.Label,
                ["endpoint"] = EndpointNameBox.Text.Trim(),
                ["strictMode"] = (StrictModeCheck.IsChecked == true).ToString(),
            });

            PreviewHint.Visibility = Visibility.Collapsed;
            ScanPill.Visibility = Visibility.Visible;
            _uiTimer.Start();
        }
        catch (Exception ex)
        {
            ProgressText.Text = $"Failed to start: {ex.Message}";
            if (_pipeline is not null) { await _pipeline.DisposeAsync(); _pipeline = null; }
        }
        UpdateButtons();
    }

    private async void Stop_Click(object sender, RoutedEventArgs e)
    {
        _uiTimer.Stop();
        if (_pipeline is not null)
        {
            await _pipeline.DisposeAsync();
            _pipeline = null;
        }
        PreviewHint.Visibility = Visibility.Visible;
        ScanPill.Visibility = Visibility.Collapsed;
        PreviewBorder.BorderBrush = (Brush)FindResource("CardBorderBrush");
        UpdateButtons();
    }

    /// <summary>Called from the capture thread for every decoded QR payload.</summary>
    private void OnQrPayload(byte[] payload)
    {
        var engine = _engine;
        if (engine is null) return;

        var result = engine.Feed(payload);
        if (result == FeedResult.Completed)
            Dispatcher.BeginInvoke(HandleCompletion);
        else if (result == FeedResult.Rejected)
            Dispatcher.BeginInvoke(() => HandleRejection(engine.LastRejection));
    }

    private void HandleRejection(string reason)
    {
        _audit.Append("receive.rejected", new Dictionary<string, string> { ["reason"] = reason });
        ResultCard.Visibility = Visibility.Visible;
        ResultCard.BorderBrush = (Brush)FindResource("DangerBrush");
        ResultTitle.Text = "✖ Rejected";
        ResultTitle.Foreground = (Brush)FindResource("DangerBrush");
        ResultText.Text = reason;
    }

    private void HandleCompletion()
    {
        if (_resultHandled || _engine?.Completed is not { } completed) return;
        _resultHandled = true;

        var manifest = completed.Manifest;
        try
        {
            if (_journal!.IsDuplicateContent(manifest.SenderSigningKeyId, manifest.PlaintextSha256))
            {
                _journal.RecordTransfer(manifest.SessionId, manifest.PlaintextSha256, manifest.Filename,
                    manifest.OriginalSize, "duplicate");
                _audit.Append("receive.duplicate", new Dictionary<string, string>
                {
                    ["session"] = manifest.SessionId.ToString(),
                    ["file"] = manifest.Filename,
                });
                ShowResult("◎ Duplicate detected", "WarningBrush",
                    $"This exact content from this sender was already stored earlier.\nsession {manifest.SessionId:N}\nNothing was written — idempotency guaranteed.");
                return;
            }

            // Atomic materialization: staging write + fsync, then rename into quarantine.
            string safeName = SanitizeFilename(manifest.Filename);
            string finalName = $"{manifest.SessionId:N}_{safeName}";
            string stagingPath = Path.Combine(QrDiodePaths.QuarantineStagingDir, finalName + ".tmp");
            string finalPath = Path.Combine(QrDiodePaths.QuarantineDir, finalName);

            using (var stream = new FileStream(stagingPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(completed.Plaintext);
                stream.Flush(flushToDisk: true);
            }
            File.Move(stagingPath, finalPath, overwrite: false);

            _journal.RecordTransfer(manifest.SessionId, manifest.PlaintextSha256, manifest.Filename,
                manifest.OriginalSize, "stored");
            _audit.Append("receive.completed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["file"] = manifest.Filename,
                ["stored"] = finalPath,
                ["size"] = manifest.OriginalSize.ToString(),
                ["sha256"] = Convert.ToHexString(manifest.PlaintextSha256),
                ["receipt"] = completed.ReceiptHash,
            });

            double seconds = (DateTime.UtcNow - _startedUtc).TotalSeconds;
            TransferProgress.Value = 1;
            ProgressPercent.Text = "100%";
            ShowResult("✔ Transfer complete", "SuccessBrush",
                $"{manifest.Filename}  ({manifest.OriginalSize:N0} bytes in {seconds:0.0}s)\n" +
                $"sha256   {Convert.ToHexString(manifest.PlaintextSha256)}\n" +
                $"receipt  {completed.ReceiptHash}   ← compare with the sender's screen\n" +
                $"stored   {finalPath}");
        }
        catch (Exception ex)
        {
            ShowResult("✖ Materialization failed", "DangerBrush", ex.Message);
            _audit.Append("receive.store_failed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["error"] = ex.Message,
            });
        }
    }

    private void ShowResult(string title, string brushKey, string body)
    {
        ResultCard.Visibility = Visibility.Visible;
        ResultCard.BorderBrush = (Brush)FindResource(brushKey);
        ResultTitle.Text = title;
        ResultTitle.Foreground = (Brush)FindResource(brushKey);
        ResultText.Text = body;
    }

    private static string SanitizeFilename(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = name.Select(c => invalid.Contains(c) ? '_' : c).ToArray();
        string safe = new string(chars).TrimStart('.').Trim();
        return safe.Length == 0 ? "payload.bin" : safe;
    }

    private void OnUiTick(object? sender, EventArgs e)
    {
        var engine = _engine;
        var pipeline = _pipeline;
        if (engine is null || pipeline is null) return;

        if (engine.ActiveManifest is { } manifest && !_resultHandled)
        {
            TransferProgress.Value = engine.Progress;
            ProgressPercent.Text = $"{engine.Progress * 100:0}%";
            ProgressText.Text =
                $"{manifest.Filename} ({manifest.OriginalSize:N0} B)\n" +
                $"blocks {engine.DecodedSourceCount}/{engine.K} · symbols {engine.UniqueSymbolsReceived}\n" +
                $"session {manifest.SessionId:N}";
        }

        double elapsed = Math.Max(0.1, (DateTime.UtcNow - _startedUtc).TotalSeconds);
        TelemetryText.Text =
            $"frames {pipeline.FramesSeen} · analyzed {pipeline.FramesDecoded} · QR hits {pipeline.QrHits}\n" +
            $"{pipeline.FramesDecoded / elapsed:0.0} analyzed/s · {pipeline.QrHits / elapsed:0.0} hits/s";

        // Live lock-on feedback: green border + pill while QR codes are actively decoding.
        long hits = pipeline.QrHits;
        bool locked = hits > _lastQrHits;
        _lastQrHits = hits;
        PreviewBorder.BorderBrush = (Brush)FindResource(locked ? "SuccessBrush" : "CardBorderBrush");
        ScanDot.Fill = (Brush)FindResource(locked ? "SuccessBrush" : "SubTextBrush");
        ScanPillText.Text = locked ? "LOCKED — decoding" : "SEARCHING";
        ScanPillText.Foreground = (Brush)FindResource(locked ? "SuccessBrush" : "SubTextBrush");

        var preview = _pendingPreview;
        if (preview.Pixels is { Length: > 0 })
        {
            _pendingPreview = default;
            if (_previewBitmap is null || _previewBitmap.PixelWidth != preview.Width || _previewBitmap.PixelHeight != preview.Height)
            {
                _previewBitmap = new WriteableBitmap(preview.Width, preview.Height, 96, 96, System.Windows.Media.PixelFormats.Gray8, null);
                PreviewImage.Source = _previewBitmap;
            }
            _previewBitmap.WritePixels(new Int32Rect(0, 0, preview.Width, preview.Height), preview.Pixels, preview.Width, 0);
        }
    }

    protected override async void OnClosed(EventArgs e)
    {
        _uiTimer.Stop();
        if (_pipeline is not null) await _pipeline.DisposeAsync();
        _journal?.Dispose();
        _trust?.Dispose();
        _keys?.Dispose();
        base.OnClosed(e);
    }
}
