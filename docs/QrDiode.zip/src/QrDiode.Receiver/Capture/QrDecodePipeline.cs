using System.Buffers.Binary;
using FlashCap;
using ZXingCpp;

namespace QrDiode.Receiver.Capture;

/// <summary>
/// Camera → luminance → ZXingCpp QR decode pipeline.
/// FlashCap transcodes camera output to a DIB (BMP) buffer; we convert to a reusable
/// top-down luminance plane and hand it to the native decoder. Frames arriving while a
/// decode is in flight are dropped — the sender carousel makes drops free.
/// </summary>
public sealed class QrDecodePipeline : IAsyncDisposable
{
    private readonly ReaderOptions _readerOptions = new()
    {
        Formats = BarcodeFormat.QRCode,
        TryHarder = false,
        TryRotate = false,
        TryInvert = false,
        MaxNumberOfSymbols = 2,
    };

    private readonly Action<byte[]> _onQrPayload;
    private readonly Action<LumFrame>? _onPreview;
    private CaptureDevice? _device;
    private byte[] _lumBuffer = Array.Empty<byte>();
    private int _decodeBusy;

    public long FramesSeen;
    public long FramesDecoded;
    public long QrHits;

    public readonly record struct LumFrame(byte[] Pixels, int Width, int Height);

    public QrDecodePipeline(Action<byte[]> onQrPayload, Action<LumFrame>? onPreview = null)
    {
        _onQrPayload = onQrPayload;
        _onPreview = onPreview;
    }

    public static IReadOnlyList<(CaptureDeviceDescriptor Descriptor, VideoCharacteristics Characteristics)> EnumerateCameras()
    {
        var result = new List<(CaptureDeviceDescriptor, VideoCharacteristics)>();
        foreach (var descriptor in new CaptureDevices().EnumerateDescriptors())
        {
            var best = descriptor.Characteristics
                .Where(c => c.PixelFormat != PixelFormats.Unknown)
                .OrderByDescending(c => c.FramesPerSecond.Numerator / Math.Max(1.0, c.FramesPerSecond.Denominator))
                .ThenByDescending(c => Math.Min(c.Width * c.Height, 1280 * 720)) // prefer ≤720p at max fps
                .ThenBy(c => c.Width * c.Height)
                .FirstOrDefault();
            if (best is not null)
                result.Add((descriptor, best));
        }
        return result;
    }

    public async Task StartAsync(CaptureDeviceDescriptor descriptor, VideoCharacteristics characteristics)
    {
        _device = await descriptor.OpenAsync(characteristics, OnPixelBuffer);
        await _device.StartAsync();
    }

    private void OnPixelBuffer(PixelBufferScope scope)
    {
        Interlocked.Increment(ref FramesSeen);

        // Drop the frame if a decode is already running.
        if (Interlocked.CompareExchange(ref _decodeBusy, 1, 0) != 0)
            return;

        try
        {
            var image = scope.Buffer.ReferImage();
            if (!TryToLuminance(image, out int width, out int height))
                return;

            Interlocked.Increment(ref FramesDecoded);

            var view = new ImageView(_lumBuffer, width, height, ImageFormat.Lum);
            var barcodes = BarcodeReader.Read(view, _readerOptions);
            foreach (var barcode in barcodes)
            {
                byte[] payload = barcode.Bytes;
                if (payload.Length > 0)
                {
                    Interlocked.Increment(ref QrHits);
                    _onQrPayload(payload);
                }
            }

            if (_onPreview is not null)
            {
                // Hand the UI a copy so the reusable buffer can be overwritten immediately.
                var copy = new byte[width * height];
                Array.Copy(_lumBuffer, copy, copy.Length);
                _onPreview(new LumFrame(copy, width, height));
            }
        }
        finally
        {
            Volatile.Write(ref _decodeBusy, 0);
        }
    }

    /// <summary>
    /// Converts FlashCap's transcoded DIB (BMP, bottom-up BGR24/BGRA32) into a top-down
    /// luminance plane in the reusable buffer. Fails closed on anything unexpected.
    /// </summary>
    private bool TryToLuminance(ArraySegment<byte> bmp, out int width, out int height)
    {
        width = 0;
        height = 0;
        var data = bmp.AsSpan();
        if (data.Length < 54 || data[0] != 'B' || data[1] != 'M') return false;

        int pixelOffset = BinaryPrimitives.ReadInt32LittleEndian(data[10..]);
        width = BinaryPrimitives.ReadInt32LittleEndian(data[18..]);
        int rawHeight = BinaryPrimitives.ReadInt32LittleEndian(data[22..]);
        int bpp = BinaryPrimitives.ReadUInt16LittleEndian(data[28..]);
        if (width <= 0 || rawHeight == 0 || (bpp != 24 && bpp != 32)) return false;

        bool bottomUp = rawHeight > 0;
        height = Math.Abs(rawHeight);
        int bytesPerPixel = bpp / 8;
        int stride = (width * bytesPerPixel + 3) & ~3;
        long needed = pixelOffset + (long)stride * height;
        if (pixelOffset < 54 || needed > data.Length) return false;

        if (_lumBuffer.Length != width * height)
            _lumBuffer = new byte[width * height];

        for (int y = 0; y < height; y++)
        {
            int srcRow = bottomUp ? height - 1 - y : y;
            var src = data.Slice(pixelOffset + srcRow * stride, width * bytesPerPixel);
            int dst = y * width;
            for (int x = 0; x < width; x++)
            {
                int p = x * bytesPerPixel;
                // Fast luma approximation: (B + 2G + R) / 4
                _lumBuffer[dst + x] = (byte)((src[p] + (src[p + 1] << 1) + src[p + 2]) >> 2);
            }
        }
        return true;
    }

    public async ValueTask DisposeAsync()
    {
        if (_device is not null)
        {
            try { await _device.StopAsync(); } catch (Exception) { /* device may already be gone */ }
            _device.Dispose();
            _device = null;
        }
    }
}
