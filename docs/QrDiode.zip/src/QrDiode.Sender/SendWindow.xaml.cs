using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using QrDiode.Core.Audit;
using QrDiode.Core.Pipeline;
using QrDiode.Sender.Rendering;

namespace QrDiode.Sender;

/// <summary>
/// Fullscreen QR carousel. A background pump pre-renders frames; this window blits them into a
/// WriteableBitmap on CompositionTarget.Rendering, gated to the target fps by a stopwatch.
/// Esc stops. Up/Down adjusts fps live.
/// </summary>
public partial class SendWindow : Window
{
    private readonly SendSession _session;
    private readonly AuditLog _audit;
    private readonly CarouselPump _pump;
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private WriteableBitmap? _bitmap;
    private double _fps;
    private long _framesShown;
    private double _nextFrameDue;

    public SendWindow(SendSession session, int fps, AuditLog audit)
    {
        InitializeComponent();
        _session = session;
        _audit = audit;
        _fps = fps;
        _pump = new CarouselPump(session);

        Loaded += OnLoaded;
        Closed += OnClosedInternal;
    }

    private void OnLoaded(object? sender, RoutedEventArgs e)
    {
        int dim = _pump.Renderer.PixelSize;
        _bitmap = new WriteableBitmap(dim, dim, 96, 96, PixelFormats.Gray8, null);
        QrImage.Source = _bitmap;

        // Integer scaling: crisp modules, no interpolation artifacts.
        double usable = Math.Min(ActualWidth, ActualHeight - 40);
        int scale = Math.Max(1, (int)(usable / dim));
        QrImage.Width = dim * scale;
        QrImage.Height = dim * scale;

        KeepDisplayAwake(true);
        CompositionTarget.Rendering += OnRendering;
    }

    private void OnRendering(object? sender, EventArgs e)
    {
        double now = _clock.Elapsed.TotalSeconds;
        if (now < _nextFrameDue) return;

        var buffer = _pump.TryTake();
        if (buffer is null) return; // producer briefly behind — keep showing the current frame

        _nextFrameDue = now + 1.0 / _fps;

        int dim = _pump.Renderer.PixelSize;
        _bitmap!.WritePixels(new Int32Rect(0, 0, dim, dim), buffer, dim, 0);
        _pump.Recycle(buffer);
        _framesShown++;

        if (_framesShown % 15 == 0)
        {
            long framesPerLoop = (long)_session.K * _session.Options.Redundancy;
            long loops = framesPerLoop > 0 ? _framesShown / framesPerLoop : 0;
            double effFps = _framesShown / Math.Max(now, 0.001);
            StatusText.Text =
                $"QR v{_pump.Renderer.Version} · {_fps:0} fps target ({effFps:0.0} actual) · " +
                $"frame {_framesShown} · loop {loops} · K={_session.K} · " +
                $"receipt {_session.ReceiptHash} · Esc to stop, ↑/↓ fps";
        }
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Escape:
                Close();
                break;
            case Key.Up:
                _fps = Math.Min(30, _fps + 1);
                break;
            case Key.Down:
                _fps = Math.Max(5, _fps - 1);
                break;
        }
    }

    private void OnClosedInternal(object? sender, EventArgs e)
    {
        CompositionTarget.Rendering -= OnRendering;
        KeepDisplayAwake(false);
        _pump.Dispose();
        _audit.Append("send.stopped", new Dictionary<string, string>
        {
            ["session"] = _session.Manifest.SessionId.ToString(),
            ["framesShown"] = _framesShown.ToString(),
            ["receipt"] = _session.ReceiptHash,
        });
    }

    private static void KeepDisplayAwake(bool on)
    {
        const uint ES_CONTINUOUS = 0x80000000;
        const uint ES_DISPLAY_REQUIRED = 0x00000002;
        const uint ES_SYSTEM_REQUIRED = 0x00000001;
        SetThreadExecutionState(on ? ES_CONTINUOUS | ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED : ES_CONTINUOUS);
    }

    [DllImport("kernel32.dll")]
    private static extern uint SetThreadExecutionState(uint esFlags);
}
