using System.IO;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;

namespace QrDiode.Sender;

public partial class MainWindow : Window
{
    private CngEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    private string? _payloadPath;
    private readonly AuditLog _audit;

    private sealed record ReceiverChoice(PeerPublicKeys Peer)
    {
        public string Label => $"{Peer.Name}   ·   kex {KeyId.ToHex(Peer.AgreementKeyId)}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "sender-audit.jsonl"));
        ReloadTrust();
    }

    private void ReloadTrust()
    {
        _trust?.Dispose();
        _trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);

        // Everyone in the trust store except ourselves is a valid destination.
        var choices = _trust.Peers
            .Where(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId))
            .Select(p => new ReceiverChoice(p))
            .ToList();
        ReceiverCombo.ItemsSource = choices;
        if (choices.Count > 0) ReceiverCombo.SelectedIndex = 0;
        UpdateStartEnabled();
    }

    private void ReloadTrust_Click(object sender, RoutedEventArgs e) => ReloadTrust();

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _keys?.Dispose();
            _keys = CngEndpointKeys.OpenOrCreate(EndpointNameBox.Text.Trim());
            KeyInfoText.Text =
                $"sign {KeyId.ToHex(_keys.SigningKeyId)}   kex {KeyId.ToHex(_keys.AgreementKeyId)}";
            SetPill(KeyStatusPill, KeyStatusPillText,
                _keys.IsTpmBacked ? "TPM-backed" : "software KSP", success: true);
            ReloadTrust();
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            SetPill(KeyStatusPill, KeyStatusPillText, "error", success: false);
            _keys = null;
        }
        UpdateStartEnabled();
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.OtEndpoint;
            OpenKeys_Click(sender, e);

            foreach (ReceiverChoice choice in ReceiverCombo.Items)
            {
                if (choice.Peer.Name == DemoProvisioner.ItEndpoint)
                {
                    ReceiverCombo.SelectedItem = choice;
                    break;
                }
            }

            ShowStatus(
                $"Demo ready — full security active (real signatures, encryption, anti-replay).\n" +
                $"ot fingerprint {ids.OtFingerprint}\n" +
                $"it fingerprint {ids.ItFingerprint}\n" +
                $"Now open the Receiver app and press its ⚡ Demo setup button.", ok: true);
        }
        catch (Exception ex)
        {
            ShowStatus($"Demo setup failed: {ex.Message}", ok: false);
        }
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Title = "Select payload to transmit" };
        if (dialog.ShowDialog() != true) return;

        var info = new FileInfo(dialog.FileName);
        if (info.Length == 0)
        {
            ShowStatus("File is empty — nothing to transmit.", ok: false);
            return;
        }
        if (info.Length > 64L * 1024 * 1024)
        {
            ShowStatus($"File is {info.Length / (1024 * 1024)} MB — beyond the 64 MB design envelope.", ok: false);
            return;
        }

        _payloadPath = dialog.FileName;
        FileBox.Text = dialog.FileName;
        var kind = DetectKind(dialog.FileName);
        SetPill(PayloadPill, PayloadPillText, $"{kind} · {FormatSize(info.Length)}", success: true);
        StatusCard.Visibility = Visibility.Collapsed;
        UpdateStartEnabled();
    }

    private void UpdateStartEnabled()
        => StartButton.IsEnabled = _keys is not null && _payloadPath is not null && ReceiverCombo.SelectedItem is not null;

    private static ContentKind DetectKind(string path) => Path.GetExtension(path).ToLowerInvariant() switch
    {
        ".xml" => ContentKind.Xml,
        ".json" => ContentKind.Json,
        _ => ContentKind.File,
    };

    private static string FormatSize(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        _ => $"{bytes / (1024.0 * 1024):0.#} MB",
    };

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (_keys is null || _payloadPath is null || ReceiverCombo.SelectedItem is not ReceiverChoice choice)
            return;

        StartButton.IsEnabled = false;
        ShowStatus("Preparing session: hash → compress → encrypt → sign …", ok: true);
        try
        {
            string path = _payloadPath;
            string filename = Path.GetFileName(path);
            var kind = DetectKind(path);
            var keys = _keys;
            var peer = choice.Peer;

            // Counter is reserved (and durably persisted) BEFORE the session exists, so a
            // crash can never reuse a value.
            var counterStore = new CounterStore(QrDiodePaths.CounterFile);
            ulong counter = counterStore.Next();

            var session = await Task.Run(() =>
            {
                byte[] payload = File.ReadAllBytes(path);
                return SendSession.Create(payload, filename, kind, keys, peer, counter);
            });

            _audit.Append("send.started", new Dictionary<string, string>
            {
                ["session"] = session.Manifest.SessionId.ToString(),
                ["counter"] = counter.ToString(),
                ["file"] = filename,
                ["size"] = session.Manifest.OriginalSize.ToString(),
                ["receiver"] = peer.Name,
                ["receipt"] = session.ReceiptHash,
            });

            var window = new SendWindow(session, (int)FpsSlider.Value, _audit) { Owner = this };
            window.ShowDialog();
            ShowStatus(
                $"Session ended.  receipt {session.ReceiptHash}  ← compare with the receiver's screen\n" +
                $"session {session.Manifest.SessionId:N} · {filename}", ok: true);
        }
        catch (Exception ex)
        {
            ShowStatus($"Failed to start: {ex.Message}", ok: false);
        }
        finally
        {
            UpdateStartEnabled();
        }
    }

    private void ShowStatus(string message, bool ok)
    {
        StatusCard.Visibility = Visibility.Visible;
        StatusText.Text = message;
        StatusText.Foreground = (Brush)FindResource(ok ? "SuccessBrush" : "DangerBrush");
    }

    private void SetPill(System.Windows.Controls.Border pill, System.Windows.Controls.TextBlock text, string label, bool success)
    {
        text.Text = label;
        pill.Background = new SolidColorBrush(success ? Color.FromArgb(0x33, 0x3D, 0xDC, 0x84) : Color.FromArgb(0x33, 0xFF, 0x5C, 0x5C));
        text.Foreground = (Brush)FindResource(success ? "SuccessBrush" : "DangerBrush");
    }

    protected override void OnClosed(EventArgs e)
    {
        _keys?.Dispose();
        _trust?.Dispose();
        base.OnClosed(e);
    }
}
