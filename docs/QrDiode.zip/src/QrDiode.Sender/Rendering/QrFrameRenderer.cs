using Net.Codecrete.QrCodeGenerator;

namespace QrDiode.Sender.Rendering;

/// <summary>
/// Renders wire frames into fixed-size Gray8 pixel buffers (1 byte/pixel, 1 px/module plus
/// quiet zone). A fixed QR version is chosen up front so every frame in a session has an
/// identical module count — the camera never has to refocus on a size change.
/// </summary>
public sealed class QrFrameRenderer
{
    public const int QuietZoneModules = 8;

    public int Version { get; }
    public int ModulesPerSide { get; }
    /// <summary>Pixel side length of the rendered bitmap (modules + 2 × quiet zone).</summary>
    public int PixelSize { get; }

    public QrFrameRenderer(int maxFrameLength)
    {
        Version = PickVersion(maxFrameLength);
        ModulesPerSide = 17 + Version * 4;
        PixelSize = ModulesPerSide + QuietZoneModules * 2;
    }

    /// <summary>Smallest QR version whose byte-mode capacity at ECC L fits the frame.</summary>
    public static int PickVersion(int frameLength)
    {
        var probe = new byte[frameLength];
        var segments = new List<DataSegment> { DataSegment.MakeSegment(DataSegmentMode.Binary, new ArraySegment<byte>(probe)) };
        for (int v = 1; v <= 40; v++)
        {
            try
            {
                QrCode.EncodeSegments(segments, QrCode.Ecc.Low, v, v, false);
                return v;
            }
            catch (DataTooLongException)
            {
                // try next version
            }
        }
        throw new ArgumentOutOfRangeException(nameof(frameLength), "Frame does not fit any QR version.");
    }

    /// <summary>Renders one frame into a caller-owned Gray8 buffer of PixelSize² bytes.</summary>
    public void Render(byte[] frame, byte[] gray8Buffer)
    {
        if (gray8Buffer.Length != PixelSize * PixelSize)
            throw new ArgumentException("Buffer size mismatch.", nameof(gray8Buffer));

        var segments = new List<DataSegment> { DataSegment.MakeSegment(DataSegmentMode.Binary, new ArraySegment<byte>(frame)) };
        var qr = QrCode.EncodeSegments(segments, QrCode.Ecc.Low, Version, Version, false);

        Array.Fill(gray8Buffer, (byte)255);
        int n = qr.Size;
        for (int y = 0; y < n; y++)
        {
            int row = (y + QuietZoneModules) * PixelSize + QuietZoneModules;
            for (int x = 0; x < n; x++)
            {
                if (qr.GetModule(x, y))
                    gray8Buffer[row + x] = 0;
            }
        }
    }
}
