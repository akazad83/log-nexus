using System.Threading.Channels;
using QrDiode.Core.Pipeline;

namespace QrDiode.Sender.Rendering;

/// <summary>
/// Background producer that walks the session carousel and pre-renders QR pixel buffers into a
/// bounded channel, keeping the UI thread's only job a cheap WritePixels blit. Buffers are
/// recycled through a return channel to avoid per-frame allocation.
/// </summary>
public sealed class CarouselPump : IDisposable
{
    private readonly Channel<byte[]> _ready;
    private readonly Channel<byte[]> _recycle;
    private readonly CancellationTokenSource _cts = new();
    private readonly Task _producer;

    public QrFrameRenderer Renderer { get; }
    public long FramesProduced => Interlocked.Read(ref _framesProduced);
    private long _framesProduced;

    public CarouselPump(SendSession session, int bufferedFrames = 16)
    {
        int maxFrame = Math.Max(session.ManifestFrame.Length,
            QrDiode.Core.Framing.FrameFormat.DataOverhead + session.Manifest.SymbolSize);
        Renderer = new QrFrameRenderer(maxFrame);

        _ready = Channel.CreateBounded<byte[]>(new BoundedChannelOptions(bufferedFrames)
        {
            SingleReader = true,
            SingleWriter = true,
            FullMode = BoundedChannelFullMode.Wait,
        });
        _recycle = Channel.CreateUnbounded<byte[]>();

        int pixels = Renderer.PixelSize * Renderer.PixelSize;
        for (int i = 0; i < bufferedFrames + 2; i++)
            _recycle.Writer.TryWrite(new byte[pixels]);

        _producer = Task.Run(() => ProduceAsync(session, _cts.Token));
    }

    /// <summary>Takes the next rendered frame, or null if none is ready yet. Return it via Recycle.</summary>
    public byte[]? TryTake()
        => _ready.Reader.TryRead(out var buffer) ? buffer : null;

    public void Recycle(byte[] buffer) => _recycle.Writer.TryWrite(buffer);

    private async Task ProduceAsync(SendSession session, CancellationToken ct)
    {
        try
        {
            foreach (var frame in session.Carousel())
            {
                var buffer = await _recycle.Reader.ReadAsync(ct).ConfigureAwait(false);
                Renderer.Render(frame, buffer);
                await _ready.Writer.WriteAsync(buffer, ct).ConfigureAwait(false);
                Interlocked.Increment(ref _framesProduced);
            }
        }
        catch (OperationCanceledException)
        {
            // normal shutdown
        }
        finally
        {
            _ready.Writer.TryComplete();
        }
    }

    public void Dispose()
    {
        _cts.Cancel();
        try { _producer.Wait(TimeSpan.FromSeconds(2)); } catch (AggregateException) { }
        _cts.Dispose();
    }
}
