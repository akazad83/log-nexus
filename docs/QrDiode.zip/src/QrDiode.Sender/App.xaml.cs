﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace QrDiode.Sender;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}

