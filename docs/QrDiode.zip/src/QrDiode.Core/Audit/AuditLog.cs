using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace QrDiode.Core.Audit;

/// <summary>
/// Append-only, hash-chained audit log (JSONL). Each record embeds the SHA-256 of the previous
/// record's serialized bytes, so any edit or deletion breaks the chain from that point on.
/// </summary>
public sealed class AuditLog
{
    private readonly string _path;
    private readonly TimeProvider _clock;
    private readonly object _lock = new();
    private string _prevHash;

    public AuditLog(string path, TimeProvider? clock = null)
    {
        _path = path;
        _clock = clock ?? TimeProvider.System;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        _prevHash = ReadLastHash(path);
    }

    public void Append(string eventType, IReadOnlyDictionary<string, string> data)
    {
        lock (_lock)
        {
            var record = new Dictionary<string, object>
            {
                ["ts"] = _clock.GetUtcNow().ToString("O"),
                ["event"] = eventType,
                ["data"] = data,
                ["prev"] = _prevHash,
            };
            string json = JsonSerializer.Serialize(record);
            string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
            string line = JsonSerializer.Serialize(new Dictionary<string, object>
            {
                ["ts"] = record["ts"],
                ["event"] = eventType,
                ["data"] = data,
                ["prev"] = _prevHash,
                ["hash"] = hash,
            });

            using var stream = new FileStream(_path, FileMode.Append, FileAccess.Write, FileShare.Read);
            using var writer = new StreamWriter(stream, new UTF8Encoding(false));
            writer.WriteLine(line);
            writer.Flush();
            stream.Flush(flushToDisk: true);

            _prevHash = hash;
        }
    }

    /// <summary>Verifies the whole chain. Returns the index of the first broken record, or -1 if intact.</summary>
    public static long Verify(string path)
    {
        if (!File.Exists(path)) return -1;
        string prev = "";
        long index = 0;
        foreach (var line in File.ReadLines(path))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            using var doc = JsonDocument.Parse(line);
            var root = doc.RootElement;
            string recordedPrev = root.GetProperty("prev").GetString() ?? "";
            string recordedHash = root.GetProperty("hash").GetString() ?? "";
            if (recordedPrev != prev) return index;

            // Recompute hash over the record without its own hash member.
            var replica = new Dictionary<string, object?>
            {
                ["ts"] = root.GetProperty("ts").GetString(),
                ["event"] = root.GetProperty("event").GetString(),
                ["data"] = JsonSerializer.Deserialize<Dictionary<string, string>>(root.GetProperty("data").GetRawText()),
                ["prev"] = recordedPrev,
            };
            string json = JsonSerializer.Serialize(replica);
            string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
            if (hash != recordedHash) return index;

            prev = hash;
            index++;
        }
        return -1;
    }

    private static string ReadLastHash(string path)
    {
        if (!File.Exists(path)) return "";
        string lastHash = "";
        foreach (var line in File.ReadLines(path))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            try
            {
                using var doc = JsonDocument.Parse(line);
                lastHash = doc.RootElement.GetProperty("hash").GetString() ?? lastHash;
            }
            catch (JsonException)
            {
                // Torn final line from a crash mid-write — chain continues from the last intact record.
            }
        }
        return lastHash;
    }
}
