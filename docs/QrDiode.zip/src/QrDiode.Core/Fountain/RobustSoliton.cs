namespace QrDiode.Core.Fountain;

/// <summary>
/// Robust soliton degree distribution for LT codes (Luby 2002).
/// Precomputes the CDF once per session; degree sampling is a binary search.
/// </summary>
public sealed class RobustSoliton
{
    private readonly double[] _cdf; // _cdf[d-1] = P(degree <= d)
    public int K { get; }

    /// <param name="k">Number of source symbols.</param>
    /// <param name="c">Tuning constant, typically 0.02–0.1.</param>
    /// <param name="delta">Decoding failure bound, typically 0.05–0.5.</param>
    public RobustSoliton(int k, double c = 0.1, double delta = 0.05)
    {
        if (k < 1) throw new ArgumentOutOfRangeException(nameof(k));
        K = k;
        _cdf = new double[k];

        if (k == 1)
        {
            _cdf[0] = 1.0;
            return;
        }

        double r = c * Math.Log(k / delta) * Math.Sqrt(k);
        if (r < 1) r = 1;
        int spike = (int)Math.Round(k / r);
        if (spike < 1) spike = 1;
        if (spike > k) spike = k;

        var p = new double[k + 1]; // 1-indexed by degree
        // Ideal soliton rho
        p[1] += 1.0 / k;
        for (int d = 2; d <= k; d++)
            p[d] += 1.0 / ((double)d * (d - 1));
        // Robust addition tau
        for (int d = 1; d < spike; d++)
            p[d] += r / ((double)d * k);
        p[spike] += r * Math.Log(r / delta) / k;

        double sum = 0;
        for (int d = 1; d <= k; d++) sum += p[d];

        double acc = 0;
        for (int d = 1; d <= k; d++)
        {
            acc += p[d] / sum;
            _cdf[d - 1] = acc;
        }
        _cdf[k - 1] = 1.0;
    }

    public int SampleDegree(ref DeterministicRandom rng)
    {
        double u = rng.NextDouble();
        int lo = 0, hi = _cdf.Length - 1;
        while (lo < hi)
        {
            int mid = (lo + hi) >> 1;
            if (_cdf[mid] < u) lo = mid + 1;
            else hi = mid;
        }
        return lo + 1;
    }
}
