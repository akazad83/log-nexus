namespace QrDiode.Core.Fountain;

/// <summary>
/// xoshiro256++ seeded via splitmix64. Deterministic across platforms and .NET versions —
/// sender and receiver must derive identical degree/neighbor sets from (sessionSeed, symbolId).
/// Never use System.Random here: its algorithm is not a cross-version contract.
/// </summary>
public struct DeterministicRandom
{
    private ulong _s0, _s1, _s2, _s3;

    public DeterministicRandom(ulong seed)
    {
        ulong sm = seed;
        _s0 = SplitMix64(ref sm);
        _s1 = SplitMix64(ref sm);
        _s2 = SplitMix64(ref sm);
        _s3 = SplitMix64(ref sm);
    }

    public static ulong SplitMix64(ref ulong state)
    {
        ulong z = state += 0x9E3779B97F4A7C15UL;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return z ^ (z >> 31);
    }

    public ulong NextUInt64()
    {
        ulong result = RotateLeft(_s0 + _s3, 23) + _s0;
        ulong t = _s1 << 17;
        _s2 ^= _s0;
        _s3 ^= _s1;
        _s1 ^= _s2;
        _s0 ^= _s3;
        _s2 ^= t;
        _s3 = RotateLeft(_s3, 45);
        return result;
    }

    /// <summary>Uniform double in [0, 1). Deterministic: derived from the top 53 bits.</summary>
    public double NextDouble() => (NextUInt64() >> 11) * (1.0 / (1UL << 53));

    /// <summary>Uniform integer in [0, bound) without modulo bias (rejection sampling).</summary>
    public uint NextUInt32(uint bound)
    {
        if (bound == 0) throw new ArgumentOutOfRangeException(nameof(bound));
        // Lemire-style rejection using 64-bit multiply on a 32-bit draw.
        while (true)
        {
            uint x = (uint)(NextUInt64() >> 32);
            ulong m = (ulong)x * bound;
            uint low = (uint)m;
            if (low >= bound || low >= unchecked((uint)(-bound) % bound))
                return (uint)(m >> 32);
        }
    }

    private static ulong RotateLeft(ulong x, int k) => (x << k) | (x >> (64 - k));
}
