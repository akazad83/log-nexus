namespace QrDiode.Core.Fountain;

/// <summary>
/// Systematic LT encoder over a fixed payload. Stateless per symbol: any symbolId can be
/// generated at any time, which is what makes the carousel loop cheap.
/// </summary>
public sealed class LtEncoder
{
    private readonly byte[] _payload;
    private readonly int _symbolSize;
    private readonly RobustSoliton _soliton;
    private readonly ulong _sessionSeed;

    public int K { get; }

    public LtEncoder(byte[] payload, int symbolSize, ulong sessionSeed)
    {
        ArgumentNullException.ThrowIfNull(payload);
        if (payload.Length == 0) throw new ArgumentException("Payload must not be empty.", nameof(payload));
        _payload = payload;
        _symbolSize = symbolSize;
        _sessionSeed = sessionSeed;
        K = LtCode.SourceBlockCount(payload.Length, symbolSize);
        _soliton = new RobustSoliton(K);
    }

    /// <summary>Writes the symbol for <paramref name="symbolId"/> into <paramref name="destination"/> (symbolSize bytes).</summary>
    public void GenerateSymbol(uint symbolId, Span<byte> destination)
    {
        if (destination.Length != _symbolSize)
            throw new ArgumentException($"Destination must be exactly {_symbolSize} bytes.", nameof(destination));

        if (symbolId < (uint)K)
        {
            CopySourceBlock((int)symbolId, destination);
            return;
        }

        var neighbors = LtCode.GetNeighbors(_sessionSeed, symbolId, _soliton);
        destination.Clear();
        foreach (int n in neighbors)
        {
            int offset = n * _symbolSize;
            int available = Math.Min(_symbolSize, _payload.Length - offset);
            var block = _payload.AsSpan(offset, available);
            for (int i = 0; i < available; i++)
                destination[i] ^= block[i];
            // bytes beyond 'available' are zero padding — XOR with zero is a no-op
        }
    }

    private void CopySourceBlock(int index, Span<byte> destination)
    {
        int offset = index * _symbolSize;
        int available = Math.Min(_symbolSize, _payload.Length - offset);
        _payload.AsSpan(offset, available).CopyTo(destination);
        if (available < _symbolSize)
            destination[available..].Clear(); // zero-pad the final block
    }
}
