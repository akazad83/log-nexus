namespace QrDiode.Core.Fountain;

/// <summary>
/// Incremental LT decoder using belief-propagation peeling. Symbols may arrive in any order,
/// duplicated, or not at all — the carousel guarantees more will come.
/// </summary>
public sealed class LtDecoder
{
    private sealed class CodedSymbol
    {
        public required HashSet<int> Remaining;
        public required byte[] Data;
    }

    private readonly int _symbolSize;
    private readonly long _payloadLength;
    private readonly ulong _sessionSeed;
    private readonly RobustSoliton _soliton;

    private readonly byte[]?[] _source;
    private readonly Dictionary<int, List<CodedSymbol>> _bySource = new();
    private readonly List<CodedSymbol> _buffered = new();
    private readonly HashSet<uint> _seenSymbolIds = new();

    public int K { get; }
    public int DecodedSourceCount { get; private set; }
    public int UniqueSymbolsReceived => _seenSymbolIds.Count;
    public bool IsComplete => DecodedSourceCount == K;

    public LtDecoder(long payloadLength, int symbolSize, ulong sessionSeed)
    {
        if (payloadLength <= 0) throw new ArgumentOutOfRangeException(nameof(payloadLength));
        _payloadLength = payloadLength;
        _symbolSize = symbolSize;
        _sessionSeed = sessionSeed;
        K = LtCode.SourceBlockCount(payloadLength, symbolSize);
        _soliton = new RobustSoliton(K);
        _source = new byte[]?[K];
    }

    /// <summary>Feeds one received symbol. Returns true if it advanced decoding (new + useful).</summary>
    public bool AddSymbol(uint symbolId, ReadOnlySpan<byte> payload)
    {
        if (IsComplete) return false;
        if (payload.Length != _symbolSize) return false;
        if (!_seenSymbolIds.Add(symbolId)) return false;

        if (symbolId < (uint)K)
        {
            Resolve((int)symbolId, payload.ToArray());
            return true;
        }

        var neighbors = LtCode.GetNeighbors(_sessionSeed, symbolId, _soliton);
        var remaining = new HashSet<int>(neighbors.Length);
        var data = payload.ToArray();

        foreach (int n in neighbors)
        {
            var src = _source[n];
            if (src is not null)
                Xor(data, src);
            else
                remaining.Add(n);
        }

        if (remaining.Count == 0)
            return false; // fully redundant

        if (remaining.Count == 1)
        {
            int only = remaining.First();
            Resolve(only, data);
            return true;
        }

        var coded = new CodedSymbol { Remaining = remaining, Data = data };
        _buffered.Add(coded);
        foreach (int n in remaining)
        {
            if (!_bySource.TryGetValue(n, out var list))
                _bySource[n] = list = new List<CodedSymbol>();
            list.Add(coded);
        }
        return true;
    }

    private void Resolve(int sourceIndex, byte[] data)
    {
        if (_source[sourceIndex] is not null) return;

        var queue = new Queue<(int Index, byte[] Data)>();
        queue.Enqueue((sourceIndex, data));

        while (queue.Count > 0)
        {
            var (idx, resolved) = queue.Dequeue();
            if (_source[idx] is not null) continue;
            _source[idx] = resolved;
            DecodedSourceCount++;

            if (!_bySource.Remove(idx, out var dependents)) continue;
            foreach (var coded in dependents)
            {
                if (!coded.Remaining.Remove(idx)) continue;
                Xor(coded.Data, resolved);
                if (coded.Remaining.Count == 1)
                {
                    int only = coded.Remaining.First();
                    coded.Remaining.Clear();
                    if (_source[only] is null)
                        queue.Enqueue((only, coded.Data));
                }
            }
        }
    }

    /// <summary>Assembles the decoded payload. Only valid when <see cref="IsComplete"/>.</summary>
    public byte[] Assemble()
    {
        if (!IsComplete) throw new InvalidOperationException("Decoding is not complete.");
        var result = new byte[_payloadLength];
        for (int i = 0; i < K; i++)
        {
            long offset = (long)i * _symbolSize;
            int len = (int)Math.Min(_symbolSize, _payloadLength - offset);
            _source[i]!.AsSpan(0, len).CopyTo(result.AsSpan((int)offset, len));
        }
        return result;
    }

    private static void Xor(byte[] target, byte[] operand)
    {
        for (int i = 0; i < target.Length; i++)
            target[i] ^= operand[i];
    }
}
