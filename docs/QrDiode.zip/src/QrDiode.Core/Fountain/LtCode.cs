namespace QrDiode.Core.Fountain;

/// <summary>
/// Shared LT code parameters and the deterministic symbolId → (degree, neighbors) mapping.
/// Systematic: symbolId &lt; K encodes source block symbolId verbatim.
/// Coded: symbolId ≥ K derives degree and neighbor set from (sessionSeed, symbolId).
/// </summary>
public static class LtCode
{
    /// <summary>
    /// Computes the neighbor set for a coded symbol. Returned indices are distinct, in [0, K).
    /// Both sides must call this with identical (seed, symbolId, soliton) to stay in sync.
    /// </summary>
    public static int[] GetNeighbors(ulong sessionSeed, uint symbolId, RobustSoliton soliton)
    {
        int k = soliton.K;
        // Domain-separate the per-symbol seed so nearby symbolIds get independent streams.
        ulong mix = symbolId * 0x9E3779B97F4A7C15UL ^ sessionSeed;
        var rng = new DeterministicRandom(DeterministicRandom.SplitMix64(ref mix));

        int degree = soliton.SampleDegree(ref rng);
        if (degree > k) degree = k;

        var neighbors = new int[degree];
        if (degree > k / 2)
        {
            // Dense symbol: partial Fisher-Yates avoids rejection stalls.
            var pool = new int[k];
            for (int i = 0; i < k; i++) pool[i] = i;
            for (int i = 0; i < degree; i++)
            {
                int j = i + (int)rng.NextUInt32((uint)(k - i));
                (pool[i], pool[j]) = (pool[j], pool[i]);
                neighbors[i] = pool[i];
            }
        }
        else
        {
            // Sparse symbol: rejection sampling against a small set.
            var seen = new HashSet<int>(degree);
            int filled = 0;
            while (filled < degree)
            {
                int candidate = (int)rng.NextUInt32((uint)k);
                if (seen.Add(candidate))
                    neighbors[filled++] = candidate;
            }
        }
        return neighbors;
    }

    /// <summary>Number of source blocks for a payload of the given length.</summary>
    public static int SourceBlockCount(long payloadLength, int symbolSize)
    {
        if (payloadLength <= 0) throw new ArgumentOutOfRangeException(nameof(payloadLength));
        if (symbolSize <= 0) throw new ArgumentOutOfRangeException(nameof(symbolSize));
        return (int)((payloadLength + symbolSize - 1) / symbolSize);
    }
}
