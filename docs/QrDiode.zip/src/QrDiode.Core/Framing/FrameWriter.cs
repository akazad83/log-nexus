using System.Buffers.Binary;
using System.IO.Hashing;

namespace QrDiode.Core.Framing;

/// <summary>Builds wire frames. Sender-side only; output arrays feed the QR encoder directly.</summary>
public static class FrameWriter
{
    public static byte[] WriteDataFrame(ReadOnlySpan<byte> sessionTag, uint symbolId, ReadOnlySpan<byte> symbolPayload)
    {
        if (sessionTag.Length != FrameFormat.SessionTagSize)
            throw new ArgumentException("Session tag must be 8 bytes.", nameof(sessionTag));

        var frame = new byte[FrameFormat.DataOverhead + symbolPayload.Length];
        WriteHeader(frame, FrameFormat.TypeDataSymbol, sessionTag);
        BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(FrameFormat.HeaderSize, 4), symbolId);
        symbolPayload.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 4));
        AppendCrc(frame);
        return frame;
    }

    public static byte[] WriteManifestFrame(ReadOnlySpan<byte> sessionTag, ReadOnlySpan<byte> manifestBody, ReadOnlySpan<byte> signature)
    {
        if (sessionTag.Length != FrameFormat.SessionTagSize)
            throw new ArgumentException("Session tag must be 8 bytes.", nameof(sessionTag));
        if (signature.Length != FrameFormat.SignatureSize)
            throw new ArgumentException("Signature must be 64 bytes (P-256 r||s).", nameof(signature));
        if (manifestBody.Length > ushort.MaxValue)
            throw new ArgumentException("Manifest body too large.", nameof(manifestBody));

        var frame = new byte[FrameFormat.ManifestOverhead + manifestBody.Length];
        WriteHeader(frame, FrameFormat.TypeManifest, sessionTag);
        BinaryPrimitives.WriteUInt16LittleEndian(frame.AsSpan(FrameFormat.HeaderSize, 2), (ushort)manifestBody.Length);
        manifestBody.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 2));
        signature.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 2 + manifestBody.Length));
        AppendCrc(frame);
        return frame;
    }

    private static void WriteHeader(Span<byte> frame, byte type, ReadOnlySpan<byte> sessionTag)
    {
        frame[0] = FrameFormat.Magic0;
        frame[1] = FrameFormat.Magic1;
        frame[2] = FrameFormat.ProtocolVersion;
        frame[3] = type;
        sessionTag.CopyTo(frame.Slice(FrameFormat.SessionTagOffset, FrameFormat.SessionTagSize));
    }

    private static void AppendCrc(Span<byte> frame)
    {
        uint crc = Crc32.HashToUInt32(frame[..^FrameFormat.CrcSize]);
        BinaryPrimitives.WriteUInt32LittleEndian(frame[^FrameFormat.CrcSize..], crc);
    }
}
