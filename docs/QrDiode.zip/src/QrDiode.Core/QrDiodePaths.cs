namespace QrDiode.Core;

/// <summary>Well-known local paths shared by the Sender, Receiver and KeyCeremony tools.</summary>
public static class QrDiodePaths
{
    public static string Root { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "QrDiode");

    public static string TrustDir => Path.Combine(Root, "trust");
    public static string AuditDir => Path.Combine(Root, "audit");
    public static string QuarantineDir => Path.Combine(Root, "quarantine");
    public static string QuarantineStagingDir => Path.Combine(QuarantineDir, ".staging");
    public static string JournalDb => Path.Combine(Root, "journal.db");
    public static string CounterFile => Path.Combine(Root, "sender-counter.bin");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(Root);
        Directory.CreateDirectory(TrustDir);
        Directory.CreateDirectory(AuditDir);
        Directory.CreateDirectory(QuarantineDir);
        Directory.CreateDirectory(QuarantineStagingDir);
    }
}
