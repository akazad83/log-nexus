using System.IO.Compression;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

public sealed class SendOptions
{
    /// <summary>Max symbol payload bytes per frame. Frame = symbolSize + 20 bytes overhead must fit the QR version.</summary>
    public int MaxSymbolSize { get; init; } = 1350; // fits V30-L (1370 B capacity)
    /// <summary>Total data frames emitted per carousel loop, as a multiple of K.</summary>
    public ushort Redundancy { get; init; } = 3;
    /// <summary>A manifest frame is re-emitted every N frames so late joiners sync fast.</summary>
    public int ManifestInterval { get; init; } = 20;
}

/// <summary>
/// Sender-side pipeline for one transfer:
/// plaintext → SHA-256 → Brotli (keep smaller) → ECDH+HKDF → AES-256-GCM → sign manifest → LT-encode → frames.
/// </summary>
public sealed class SendSession
{
    private readonly LtEncoder _encoder;
    private readonly byte[] _sessionTag;
    private readonly int _symbolSize;
    private uint _nextCodedSymbolId;

    public TransferManifest Manifest { get; }
    public byte[] ManifestFrame { get; }
    public string ReceiptHash { get; }
    public int K => _encoder.K;
    public SendOptions Options { get; }

    private SendSession(TransferManifest manifest, byte[] manifestFrame, string receiptHash,
        LtEncoder encoder, int symbolSize, SendOptions options)
    {
        Manifest = manifest;
        ManifestFrame = manifestFrame;
        ReceiptHash = receiptHash;
        _encoder = encoder;
        _symbolSize = symbolSize;
        _sessionTag = manifest.SessionTag;
        _nextCodedSymbolId = (uint)encoder.K;
        Options = options;
    }

    public static SendSession Create(
        byte[] plaintext,
        string filename,
        ContentKind contentType,
        IEndpointKeys senderKeys,
        PeerPublicKeys receiver,
        ulong counter,
        SendOptions? options = null,
        TimeProvider? clock = null)
    {
        ArgumentNullException.ThrowIfNull(plaintext);
        if (plaintext.Length == 0) throw new ArgumentException("Payload must not be empty.", nameof(plaintext));
        options ??= new SendOptions();
        clock ??= TimeProvider.System;

        byte[] plaintextHash = SHA256.HashData(plaintext);

        // Compress, keep the smaller representation.
        byte[] compressed = CompressBrotli(plaintext);
        CompressionAlg alg = CompressionAlg.Brotli;
        if (compressed.Length >= plaintext.Length)
        {
            compressed = plaintext;
            alg = CompressionAlg.None;
        }

        var sessionId = Guid.NewGuid();
        byte[] salt = RandomNumberGenerator.GetBytes(Envelope.SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(Envelope.NonceSize);
        ulong ltSeed = BitConverter.ToUInt64(RandomNumberGenerator.GetBytes(8));

        byte[] aad = Envelope.BuildAad(sessionId, salt, counter, senderKeys.SigningKeyId, receiver.AgreementKeyId);
        byte[] key = Envelope.DeriveKey(senderKeys.AgreementKey, receiver.AgreementPublicKey.PublicKey, salt, sessionId);
        byte[] ciphertext;
        try
        {
            ciphertext = Envelope.Seal(compressed, key, nonce, aad);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }

        int symbolSize = Math.Min(options.MaxSymbolSize, ciphertext.Length);
        int k = LtCode.SourceBlockCount(ciphertext.Length, symbolSize);

        var manifest = new TransferManifest
        {
            SessionId = sessionId,
            TimestampUnixMs = clock.GetUtcNow().ToUnixTimeMilliseconds(),
            Counter = counter,
            SenderSigningKeyId = senderKeys.SigningKeyId,
            ReceiverAgreementKeyId = receiver.AgreementKeyId,
            Salt = salt,
            Nonce = nonce,
            SymbolSize = checked((ushort)symbolSize),
            SourceSymbolCount = (uint)k,
            LtSeed = ltSeed,
            RedundancyHint = options.Redundancy,
            OriginalSize = plaintext.Length,
            CompressedSize = compressed.Length,
            CiphertextSize = ciphertext.Length,
            Compression = alg,
            CiphertextSha256 = SHA256.HashData(ciphertext),
            PlaintextSha256 = plaintextHash,
            ContentType = contentType,
            Filename = filename,
        };

        byte[] body = manifest.Serialize();
        byte[] signature = manifest.Sign(senderKeys.SigningKey, body);
        byte[] manifestFrame = FrameWriter.WriteManifestFrame(manifest.SessionTag, body, signature);
        string receipt = TransferManifest.ReceiptHash(body, signature);

        var encoder = new LtEncoder(ciphertext, symbolSize, ltSeed);
        return new SendSession(manifest, manifestFrame, receipt, encoder, symbolSize, options);
    }

    /// <summary>Builds the wire frame for one data symbol.</summary>
    public byte[] GetDataFrame(uint symbolId)
    {
        var payload = new byte[_symbolSize];
        _encoder.GenerateSymbol(symbolId, payload);
        return FrameWriter.WriteDataFrame(_sessionTag, symbolId, payload);
    }

    /// <summary>
    /// Infinite carousel: manifest first, then re-emitted every ManifestInterval frames.
    /// Each loop = systematic pass (0..K-1) + (Redundancy-1)×K fresh coded symbols;
    /// coded symbolIds keep increasing across loops so every loop adds new information.
    /// </summary>
    public IEnumerable<byte[]> Carousel()
    {
        while (true)
        {
            int emittedSinceManifest = int.MaxValue; // force manifest as very first frame
            long framesThisLoop = (long)K * Options.Redundancy;

            for (long i = 0; i < framesThisLoop; i++)
            {
                if (emittedSinceManifest >= Options.ManifestInterval)
                {
                    yield return ManifestFrame;
                    emittedSinceManifest = 0;
                }

                uint symbolId = i < K ? (uint)i : NextCodedId();
                yield return GetDataFrame(symbolId);
                emittedSinceManifest++;
            }
        }
    }

    private uint NextCodedId()
    {
        uint id = _nextCodedSymbolId++;
        if (_nextCodedSymbolId < (uint)K) // wrapped around the 32-bit space
            _nextCodedSymbolId = (uint)K;
        return id;
    }

    internal static byte[] CompressBrotli(byte[] data)
    {
        // Max quality pays off on small transactional payloads; on multi-MB files it costs
        // minutes of CPU for little gain over Optimal, so scale the effort down.
        var level = data.Length <= 4 * 1024 * 1024 ? CompressionLevel.SmallestSize : CompressionLevel.Optimal;
        using var output = new MemoryStream();
        using (var brotli = new BrotliStream(output, level, leaveOpen: true))
            brotli.Write(data);
        return output.ToArray();
    }
}
