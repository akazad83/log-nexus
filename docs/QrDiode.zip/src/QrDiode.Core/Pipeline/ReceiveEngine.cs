using System.IO.Compression;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

public enum FeedResult
{
    /// <summary>Not a valid frame, wrong session, or already-seen symbol. Safe to ignore.</summary>
    Ignored = 0,
    ManifestAccepted,
    SymbolAccepted,
    Completed,
    /// <summary>Frame or manifest actively rejected by a security check. See LastRejection.</summary>
    Rejected,
}

public sealed class CompletedTransfer
{
    public required TransferManifest Manifest { get; init; }
    public required byte[] Plaintext { get; init; }
    public required string ReceiptHash { get; init; }
}

/// <summary>
/// Receiver-side engine. Feed raw QR payloads; the engine enforces the verification chain in
/// strict order and fails closed at every step:
/// CRC → signature → anti-replay → LT decode → ciphertext hash → AES-GCM → decompress cap →
/// plaintext hash → content gate.
/// </summary>
public sealed class ReceiveEngine
{
    private readonly ITrustStore _trust;
    private readonly IReplayGuard _replayGuard;
    private readonly IEndpointKeys _receiverKeys;
    private readonly object _lock = new();

    private TransferManifest? _manifest;
    private byte[]? _manifestBody;
    private byte[]? _manifestSignature;
    private byte[] _sessionTag = Array.Empty<byte>();
    private LtDecoder? _decoder;
    private CompletedTransfer? _completed;

    public string LastRejection { get; private set; } = "";
    public TransferManifest? ActiveManifest => _manifest;
    public CompletedTransfer? Completed => _completed;
    public int DecodedSourceCount => _decoder?.DecodedSourceCount ?? 0;
    public int K => _decoder?.K ?? 0;
    public int UniqueSymbolsReceived => _decoder?.UniqueSymbolsReceived ?? 0;
    public double Progress => _decoder is { K: > 0 } d ? (double)d.DecodedSourceCount / d.K : 0;

    public ReceiveEngine(ITrustStore trust, IReplayGuard replayGuard, IEndpointKeys receiverKeys)
    {
        _trust = trust;
        _replayGuard = replayGuard;
        _receiverKeys = receiverKeys;
    }

    /// <summary>Feeds the raw byte payload of one decoded QR code.</summary>
    public FeedResult Feed(ReadOnlySpan<byte> qrPayload)
    {
        lock (_lock)
        {
            if (_completed is not null) return FeedResult.Ignored;

            if (!FrameParser.TryParse(qrPayload, out var frame, out _))
                return FeedResult.Ignored; // noise, misdecode, or tamper — CRC/structure said no

            return frame.Type switch
            {
                FrameType.Manifest => FeedManifest(frame),
                FrameType.DataSymbol => FeedSymbol(frame),
                _ => FeedResult.Ignored,
            };
        }
    }

    private FeedResult FeedManifest(ParsedFrame frame)
    {
        // Already locked onto a session? Ignore repeats of it, and ignore other sessions.
        if (_manifest is not null)
            return FeedResult.Ignored;

        // 1. Structural parse (no trust yet).
        if (!TransferManifest.TryParse(frame.Payload, out var candidate, out string parseError))
            return Reject($"Manifest parse: {parseError}");

        // 2. Signature: the sender must be in the trust store, and the signature must verify
        //    over the exact received body bytes. Nothing downstream runs on failure.
        var peer = _trust.FindBySigningKeyId(candidate!.SenderSigningKeyId);
        if (peer is null)
            return Reject($"Unknown sender key {KeyId.ToHex(candidate.SenderSigningKeyId)}");
        if (!TransferManifest.VerifySignature(peer.SigningPublicKey, frame.Payload, frame.Signature))
            return Reject("Manifest signature verification failed");

        // 3. This transfer must be addressed to us.
        if (!candidate.ReceiverAgreementKeyId.AsSpan().SequenceEqual(_receiverKeys.AgreementKeyId))
            return Reject("Manifest addressed to a different receiver key");

        // 4. Anti-replay.
        var verdict = _replayGuard.Check(candidate.SenderSigningKeyId, candidate.SessionId, candidate.Counter, candidate.TimestampUnixMs);
        if (verdict != ReplayVerdict.Fresh)
            return Reject($"Replay check failed: {verdict}");

        _manifest = candidate;
        _manifestBody = frame.Payload.ToArray();
        _manifestSignature = frame.Signature.ToArray();
        _sessionTag = candidate.SessionTag;
        _decoder = new LtDecoder(candidate.CiphertextSize, candidate.SymbolSize, candidate.LtSeed);
        return FeedResult.ManifestAccepted;
    }

    private FeedResult FeedSymbol(ParsedFrame frame)
    {
        // No verified manifest yet → we do not touch payload bytes at all. The carousel
        // re-emits everything, so dropping here costs time, never data.
        if (_manifest is null || _decoder is null)
            return FeedResult.Ignored;

        if (!frame.SessionTag.SequenceEqual(_sessionTag))
            return FeedResult.Ignored;
        if (frame.Payload.Length != _manifest.SymbolSize)
            return FeedResult.Ignored;

        bool advanced = _decoder.AddSymbol(frame.SymbolId, frame.Payload);
        if (!_decoder.IsComplete)
            return advanced ? FeedResult.SymbolAccepted : FeedResult.Ignored;

        return FinishTransfer();
    }

    private FeedResult FinishTransfer()
    {
        var manifest = _manifest!;
        byte[] ciphertext = _decoder!.Assemble();

        // 5. Ciphertext hash must match the signed manifest before we spend crypto on it.
        if (!SHA256.HashData(ciphertext).AsSpan().SequenceEqual(manifest.CiphertextSha256))
            return RejectAndReset("Ciphertext hash mismatch after decode");

        // 6. AES-GCM open with AAD rebuilt from the signed manifest.
        byte[] aad = Envelope.BuildAad(manifest.SessionId, manifest.Salt, manifest.Counter,
            manifest.SenderSigningKeyId, manifest.ReceiverAgreementKeyId);

        var peer = _trust.FindBySigningKeyId(manifest.SenderSigningKeyId)!;
        byte[] key = Envelope.DeriveKey(_receiverKeys.AgreementKey, peer.AgreementPublicKey.PublicKey, manifest.Salt, manifest.SessionId);
        byte[] compressed;
        try
        {
            compressed = Envelope.Open(ciphertext, key, manifest.Nonce, aad);
        }
        catch (CryptographicException)
        {
            return RejectAndReset("AES-GCM authentication failed");
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }

        // 7. Decompress with a hard output cap (zip-bomb guard).
        byte[] plaintext;
        if (manifest.Compression == CompressionAlg.Brotli)
        {
            if (!TryDecompressBrotli(compressed, manifest.OriginalSize, out plaintext))
                return RejectAndReset("Decompression failed or exceeded declared size");
        }
        else
        {
            plaintext = compressed;
        }

        // 8. Plaintext hash must match the signed manifest.
        if (plaintext.LongLength != manifest.OriginalSize ||
            !SHA256.HashData(plaintext).AsSpan().SequenceEqual(manifest.PlaintextSha256))
            return RejectAndReset("Plaintext hash mismatch");

        // 9. Content gate.
        if (!ContentGate.Validate(manifest.ContentType, plaintext, out string gateError))
            return RejectAndReset($"Content gate: {gateError}");

        // Commit anti-replay state only for fully verified transfers.
        _replayGuard.Commit(manifest.SenderSigningKeyId, manifest.SessionId, manifest.Counter);

        _completed = new CompletedTransfer
        {
            Manifest = manifest,
            Plaintext = plaintext,
            ReceiptHash = TransferManifest.ReceiptHash(_manifestBody!, _manifestSignature!),
        };
        return FeedResult.Completed;
    }

    private static bool TryDecompressBrotli(byte[] compressed, long declaredSize, out byte[] plaintext)
    {
        plaintext = Array.Empty<byte>();
        try
        {
            var output = new byte[declaredSize];
            using var input = new MemoryStream(compressed, writable: false);
            using var brotli = new BrotliStream(input, CompressionMode.Decompress);

            int total = 0;
            while (total < output.Length)
            {
                int read = brotli.Read(output, total, output.Length - total);
                if (read == 0) return false; // stream ended short of the declared size
                total += read;
            }
            // Anything beyond the declared size means the stream lies — fail closed.
            if (brotli.ReadByte() != -1) return false;
            plaintext = output;
            return true;
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException)
        {
            return false;
        }
    }

    private FeedResult Reject(string reason)
    {
        LastRejection = reason;
        return FeedResult.Rejected;
    }

    /// <summary>A post-decode failure poisons the whole session — reset so a re-send can start clean.</summary>
    private FeedResult RejectAndReset(string reason)
    {
        LastRejection = reason;
        _manifest = null;
        _manifestBody = null;
        _manifestSignature = null;
        _decoder = null;
        _sessionTag = Array.Empty<byte>();
        return FeedResult.Rejected;
    }
}
