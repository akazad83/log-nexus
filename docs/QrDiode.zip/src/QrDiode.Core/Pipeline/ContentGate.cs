using System.Text.Json;
using System.Xml;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

/// <summary>
/// Receiver-side content validation, applied AFTER all cryptographic checks pass and BEFORE
/// the payload leaves quarantine staging. XML and JSON are structurally validated with
/// hardened parsers; opaque files are never interpreted.
/// </summary>
public static class ContentGate
{
    public const int MaxXmlDepth = 64;
    public const int MaxJsonDepth = 64;

    public static bool Validate(ContentKind kind, byte[] plaintext, out string error)
    {
        try
        {
            switch (kind)
            {
                case ContentKind.Xml:
                    return ValidateXml(plaintext, out error);
                case ContentKind.Json:
                    return ValidateJson(plaintext, out error);
                case ContentKind.File:
                    error = "";
                    return true; // opaque bytes; integrity/authenticity already proven
                default:
                    error = "Unknown content kind.";
                    return false;
            }
        }
        catch (Exception ex)
        {
            // Fail closed on anything a hostile document manages to throw.
            error = $"Content validation error: {ex.GetType().Name}";
            return false;
        }
    }

    private static bool ValidateXml(byte[] data, out string error)
    {
        var settings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit, // XXE off, entirely
            XmlResolver = null,                     // no external resource resolution
            MaxCharactersFromEntities = 0,
            MaxCharactersInDocument = 256L * 1024 * 1024,
            IgnoreProcessingInstructions = false,
            CloseInput = true,
        };

        using var stream = new MemoryStream(data, writable: false);
        using var reader = XmlReader.Create(stream, settings);
        int depth = 0;
        try
        {
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && !reader.IsEmptyElement)
                {
                    depth = reader.Depth + 1;
                    if (depth > MaxXmlDepth) { error = "XML nesting too deep."; return false; }
                }
            }
        }
        catch (XmlException ex)
        {
            error = $"Malformed XML at line {ex.LineNumber}.";
            return false;
        }
        error = "";
        return true;
    }

    private static bool ValidateJson(byte[] data, out string error)
    {
        var options = new JsonReaderOptions
        {
            MaxDepth = MaxJsonDepth,
            AllowTrailingCommas = false,
            CommentHandling = JsonCommentHandling.Disallow,
        };
        try
        {
            var reader = new Utf8JsonReader(data, options);
            while (reader.Read()) { }
            error = "";
            return true;
        }
        catch (JsonException ex)
        {
            error = $"Malformed JSON at position {ex.BytePositionInLine}.";
            return false;
        }
    }
}
