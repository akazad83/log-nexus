namespace QrDiode.Core.Pipeline;

public enum ReplayVerdict
{
    Fresh = 0,
    DuplicateSession,
    StaleCounter,
    TimestampOutOfWindow,
}

/// <summary>
/// Anti-replay policy. All three checks must pass: unseen session id, counter strictly above
/// the per-sender-key high-watermark, and timestamp within the acceptance window.
/// </summary>
public interface IReplayGuard
{
    ReplayVerdict Check(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter, long timestampUnixMs);

    /// <summary>Records a completed transfer so the same session/counter can never be accepted again.</summary>
    void Commit(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter);
}

/// <summary>In-memory guard for tests and single-process use. The receiver app uses the SQLite-backed one.</summary>
public sealed class InMemoryReplayGuard : IReplayGuard
{
    public static readonly TimeSpan DefaultWindow = TimeSpan.FromHours(48);

    private readonly TimeProvider _clock;
    private readonly TimeSpan _window;
    private readonly HashSet<Guid> _sessions = new();
    private readonly Dictionary<string, ulong> _watermarks = new();

    public InMemoryReplayGuard(TimeProvider? clock = null, TimeSpan? window = null)
    {
        _clock = clock ?? TimeProvider.System;
        _window = window ?? DefaultWindow;
    }

    public ReplayVerdict Check(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter, long timestampUnixMs)
    {
        if (_sessions.Contains(sessionId)) return ReplayVerdict.DuplicateSession;

        string key = Convert.ToHexString(senderSigningKeyId);
        if (_watermarks.TryGetValue(key, out ulong mark) && counter <= mark) return ReplayVerdict.StaleCounter;

        long nowMs = _clock.GetUtcNow().ToUnixTimeMilliseconds();
        if (Math.Abs(nowMs - timestampUnixMs) > _window.TotalMilliseconds) return ReplayVerdict.TimestampOutOfWindow;

        return ReplayVerdict.Fresh;
    }

    public void Commit(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter)
    {
        _sessions.Add(sessionId);
        string key = Convert.ToHexString(senderSigningKeyId);
        if (!_watermarks.TryGetValue(key, out ulong mark) || counter > mark)
            _watermarks[key] = counter;
    }
}
