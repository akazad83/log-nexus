using System.Runtime.Versioning;
using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Endpoint keys persisted as named, non-exportable keys in Windows CNG.
/// Prefers the Platform Crypto Provider (TPM-backed); falls back to the software KSP.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class CngEndpointKeys : IEndpointKeys
{
    private const string PlatformProvider = "Microsoft Platform Crypto Provider";

    public ECDsa SigningKey { get; }
    public ECDiffieHellman AgreementKey { get; }
    public byte[] SigningKeyId { get; }
    public byte[] AgreementKeyId { get; }
    public bool IsTpmBacked { get; }

    private CngEndpointKeys(ECDsa signing, ECDiffieHellman agreement, bool tpm)
    {
        SigningKey = signing;
        AgreementKey = agreement;
        IsTpmBacked = tpm;
        SigningKeyId = KeyId.FromPublicKey(signing);
        AgreementKeyId = KeyId.FromPublicKey(agreement);
    }

    public static bool Exists(string endpointName)
        => CngKey.Exists(SignKeyName(endpointName)) && CngKey.Exists(KexKeyName(endpointName));

    /// <summary>Opens existing named keys, or creates them (non-exportable) on first use.</summary>
    public static CngEndpointKeys OpenOrCreate(string endpointName, bool preferTpm = true)
    {
        ValidateName(endpointName);
        var (signCng, tpm1) = OpenOrCreateKey(SignKeyName(endpointName), CngAlgorithm.ECDsaP256, preferTpm);
        var (kexCng, tpm2) = OpenOrCreateKey(KexKeyName(endpointName), CngAlgorithm.ECDiffieHellmanP256, preferTpm);
        return new CngEndpointKeys(new ECDsaCng(signCng), new ECDiffieHellmanCng(kexCng), tpm1 && tpm2);
    }

    public static void Delete(string endpointName)
    {
        ValidateName(endpointName);
        foreach (var name in new[] { SignKeyName(endpointName), KexKeyName(endpointName) })
        {
            if (CngKey.Exists(name))
            {
                using var key = CngKey.Open(name);
                key.Delete();
            }
        }
    }

    private static (CngKey Key, bool Tpm) OpenOrCreateKey(string name, CngAlgorithm algorithm, bool preferTpm)
    {
        if (CngKey.Exists(name))
        {
            var opened = CngKey.Open(name);
            return (opened, opened.Provider?.Provider == PlatformProvider);
        }

        var creation = new CngKeyCreationParameters
        {
            ExportPolicy = CngExportPolicies.None, // non-exportable, by design
            KeyUsage = CngKeyUsages.AllUsages,
        };

        if (preferTpm)
        {
            try
            {
                creation.Provider = new CngProvider(PlatformProvider);
                return (CngKey.Create(algorithm, name, creation), true);
            }
            catch (CryptographicException)
            {
                // No TPM / PCP unavailable — fall through to software KSP.
            }
        }

        creation.Provider = CngProvider.MicrosoftSoftwareKeyStorageProvider;
        return (CngKey.Create(algorithm, name, creation), false);
    }

    private static string SignKeyName(string endpointName) => $"QrDiode.{endpointName}.sign";
    private static string KexKeyName(string endpointName) => $"QrDiode.{endpointName}.kex";

    private static void ValidateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length > 64 || name.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-' && c != '_'))
            throw new ArgumentException("Endpoint name must be 1-64 chars of [A-Za-z0-9-_].", nameof(name));
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        AgreementKey.Dispose();
    }
}
