using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Authenticated-encryption envelope: static-static ECDH P-256 → HKDF-SHA256 → AES-256-GCM.
/// The AAD binds the ciphertext to the session identity carried in the signed manifest,
/// so a ciphertext can never be paired with a foreign manifest (and vice versa).
/// </summary>
public static class Envelope
{
    public const int SaltSize = 32;
    public const int NonceSize = 12;
    public const int TagSize = 16;
    public const int KeySize = 32;
    private static readonly byte[] InfoPrefix = "QrDiode.v1"u8.ToArray();

    /// <summary>AAD = sessionGuid(16) ‖ salt(32) ‖ counter(8) ‖ senderSigKeyId(8) ‖ receiverKexKeyId(8).</summary>
    public static byte[] BuildAad(Guid sessionId, ReadOnlySpan<byte> salt, ulong counter,
        ReadOnlySpan<byte> senderSigningKeyId, ReadOnlySpan<byte> receiverAgreementKeyId)
    {
        if (salt.Length != SaltSize) throw new ArgumentException("Bad salt length.", nameof(salt));
        if (senderSigningKeyId.Length != KeyId.Size) throw new ArgumentException("Bad key id length.", nameof(senderSigningKeyId));
        if (receiverAgreementKeyId.Length != KeyId.Size) throw new ArgumentException("Bad key id length.", nameof(receiverAgreementKeyId));

        var aad = new byte[16 + SaltSize + 8 + KeyId.Size + KeyId.Size];
        sessionId.TryWriteBytes(aad.AsSpan(0, 16));
        salt.CopyTo(aad.AsSpan(16));
        System.Buffers.Binary.BinaryPrimitives.WriteUInt64LittleEndian(aad.AsSpan(16 + SaltSize, 8), counter);
        senderSigningKeyId.CopyTo(aad.AsSpan(16 + SaltSize + 8));
        receiverAgreementKeyId.CopyTo(aad.AsSpan(16 + SaltSize + 8 + KeyId.Size));
        return aad;
    }

    public static byte[] DeriveKey(ECDiffieHellman ownAgreementKey, ECDiffieHellmanPublicKey peerPublicKey,
        ReadOnlySpan<byte> salt, Guid sessionId)
    {
        byte[] sharedSecret = ownAgreementKey.DeriveRawSecretAgreement(peerPublicKey);
        try
        {
            var info = new byte[InfoPrefix.Length + 16];
            InfoPrefix.CopyTo(info, 0);
            sessionId.TryWriteBytes(info.AsSpan(InfoPrefix.Length, 16));
            return HKDF.DeriveKey(HashAlgorithmName.SHA256, sharedSecret, KeySize, salt.ToArray(), info);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(sharedSecret);
        }
    }

    /// <summary>Encrypts. Output = ciphertext ‖ 16-byte GCM tag.</summary>
    public static byte[] Seal(ReadOnlySpan<byte> plaintext, byte[] key, ReadOnlySpan<byte> nonce, ReadOnlySpan<byte> aad)
    {
        var output = new byte[plaintext.Length + TagSize];
        using var gcm = new AesGcm(key, TagSize);
        gcm.Encrypt(nonce, plaintext, output.AsSpan(0, plaintext.Length), output.AsSpan(plaintext.Length, TagSize), aad);
        return output;
    }

    /// <summary>Decrypts and authenticates. Throws <see cref="AuthenticationTagMismatchException"/> on any tamper.</summary>
    public static byte[] Open(ReadOnlySpan<byte> ciphertextWithTag, byte[] key, ReadOnlySpan<byte> nonce, ReadOnlySpan<byte> aad)
    {
        if (ciphertextWithTag.Length < TagSize) throw new CryptographicException("Ciphertext too short.");
        var plaintext = new byte[ciphertextWithTag.Length - TagSize];
        using var gcm = new AesGcm(key, TagSize);
        gcm.Decrypt(nonce,
            ciphertextWithTag[..^TagSize],
            ciphertextWithTag[^TagSize..],
            plaintext,
            aad);
        return plaintext;
    }
}
