using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// An endpoint's own key material: one ECDSA P-256 signing pair and one ECDH P-256
/// key-agreement pair. Backed either by ephemeral keys (tests) or Windows CNG named keys.
/// </summary>
public interface IEndpointKeys : IDisposable
{
    ECDsa SigningKey { get; }
    ECDiffieHellman AgreementKey { get; }
    byte[] SigningKeyId { get; }
    byte[] AgreementKeyId { get; }
}

/// <summary>In-memory keys for tests and loopback benches. Never persisted.</summary>
public sealed class EphemeralEndpointKeys : IEndpointKeys
{
    public ECDsa SigningKey { get; }
    public ECDiffieHellman AgreementKey { get; }
    public byte[] SigningKeyId { get; }
    public byte[] AgreementKeyId { get; }

    public EphemeralEndpointKeys()
    {
        SigningKey = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        AgreementKey = ECDiffieHellman.Create(ECCurve.NamedCurves.nistP256);
        SigningKeyId = KeyId.FromPublicKey(SigningKey);
        AgreementKeyId = KeyId.FromPublicKey(AgreementKey);
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        AgreementKey.Dispose();
    }
}

/// <summary>A peer's public keys as imported from a trust bundle.</summary>
public sealed class PeerPublicKeys : IDisposable
{
    public required string Name { get; init; }
    public required ECDsa SigningPublicKey { get; init; }
    public required ECDiffieHellman AgreementPublicKey { get; init; }
    public required byte[] SigningKeyId { get; init; }
    public required byte[] AgreementKeyId { get; init; }

    public void Dispose()
    {
        SigningPublicKey.Dispose();
        AgreementPublicKey.Dispose();
    }
}
