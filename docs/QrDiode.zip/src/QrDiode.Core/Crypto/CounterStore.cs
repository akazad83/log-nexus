using System.Buffers.Binary;
using System.Runtime.Versioning;
using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Sender-side monotonic counter, persisted DPAPI-protected (current user scope).
/// The counter is part of the anti-replay contract: it must never move backwards,
/// so it is incremented and flushed BEFORE a session is created with its value.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class CounterStore
{
    private static readonly byte[] Entropy = "QrDiode.counter.v1"u8.ToArray();
    private readonly string _path;
    private readonly object _lock = new();

    public CounterStore(string path)
    {
        _path = path;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
    }

    /// <summary>Atomically reserves and returns the next counter value (starting at 1).</summary>
    public ulong Next()
    {
        lock (_lock)
        {
            ulong current = Read();
            ulong next = checked(current + 1);
            Write(next);
            return next;
        }
    }

    public ulong Peek()
    {
        lock (_lock) return Read();
    }

    private ulong Read()
    {
        if (!File.Exists(_path)) return 0;
        byte[] protectedBytes = File.ReadAllBytes(_path);
        byte[] plain = ProtectedData.Unprotect(protectedBytes, Entropy, DataProtectionScope.CurrentUser);
        if (plain.Length != 8) throw new InvalidDataException("Corrupt counter state.");
        return BinaryPrimitives.ReadUInt64LittleEndian(plain);
    }

    private void Write(ulong value)
    {
        var plain = new byte[8];
        BinaryPrimitives.WriteUInt64LittleEndian(plain, value);
        byte[] protectedBytes = ProtectedData.Protect(plain, Entropy, DataProtectionScope.CurrentUser);

        // Write-temp-then-rename so a crash never leaves a torn state file.
        string tmp = _path + ".tmp";
        using (var stream = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            stream.Write(protectedBytes);
            stream.Flush(flushToDisk: true);
        }
        File.Move(tmp, _path, overwrite: true);
    }
}
