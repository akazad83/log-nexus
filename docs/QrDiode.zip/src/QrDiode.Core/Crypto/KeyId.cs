using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Key identifier = first 8 bytes of SHA-256 over the key's SubjectPublicKeyInfo (DER).
/// Used to select trust-store entries; never a substitute for signature verification.
/// </summary>
public static class KeyId
{
    public const int Size = 8;

    public static byte[] FromPublicKey(ECDsa key)
        => SHA256.HashData(key.ExportSubjectPublicKeyInfo()).AsSpan(0, Size).ToArray();

    public static byte[] FromPublicKey(ECDiffieHellman key)
        => SHA256.HashData(key.ExportSubjectPublicKeyInfo()).AsSpan(0, Size).ToArray();

    public static byte[] FromSubjectPublicKeyInfo(ReadOnlySpan<byte> spki)
        => SHA256.HashData(spki).AsSpan(0, Size).ToArray();

    public static string ToHex(ReadOnlySpan<byte> keyId) => Convert.ToHexString(keyId);
}
