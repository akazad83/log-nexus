using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace QrDiode.Core.Crypto;

/// <summary>Serializable public-key bundle carried between environments on removable media.</summary>
public sealed class PublicKeyBundle
{
    [JsonPropertyName("format")] public string Format { get; set; } = "qrdiode-pubkeys-v1";
    [JsonPropertyName("name")] public required string Name { get; set; }
    [JsonPropertyName("signingPublicKey")] public required string SigningPublicKeySpki { get; set; }   // base64 DER SPKI
    [JsonPropertyName("agreementPublicKey")] public required string AgreementPublicKeySpki { get; set; } // base64 DER SPKI
    [JsonPropertyName("createdUtc")] public DateTimeOffset CreatedUtc { get; set; }

    public static PublicKeyBundle FromKeys(string name, IEndpointKeys keys, TimeProvider? clock = null) => new()
    {
        Name = name,
        SigningPublicKeySpki = Convert.ToBase64String(keys.SigningKey.ExportSubjectPublicKeyInfo()),
        AgreementPublicKeySpki = Convert.ToBase64String(keys.AgreementKey.ExportSubjectPublicKeyInfo()),
        CreatedUtc = (clock ?? TimeProvider.System).GetUtcNow(),
    };

    public string ToJson() => JsonSerializer.Serialize(this, BundleJson.Options);

    public static PublicKeyBundle Parse(string json)
    {
        var bundle = JsonSerializer.Deserialize<PublicKeyBundle>(json, BundleJson.Options)
            ?? throw new FormatException("Empty bundle.");
        if (bundle.Format != "qrdiode-pubkeys-v1") throw new FormatException($"Unknown bundle format '{bundle.Format}'.");
        if (string.IsNullOrWhiteSpace(bundle.Name) || bundle.Name.Length > 64)
            throw new FormatException("Invalid bundle name.");
        return bundle;
    }

    public PeerPublicKeys ToPeerKeys()
    {
        byte[] signSpki = Convert.FromBase64String(SigningPublicKeySpki);
        byte[] kexSpki = Convert.FromBase64String(AgreementPublicKeySpki);

        var sign = ECDsa.Create();
        sign.ImportSubjectPublicKeyInfo(signSpki, out _);
        var kex = ECDiffieHellman.Create();
        kex.ImportSubjectPublicKeyInfo(kexSpki, out _);

        return new PeerPublicKeys
        {
            Name = Name,
            SigningPublicKey = sign,
            AgreementPublicKey = kex,
            SigningKeyId = KeyId.FromSubjectPublicKeyInfo(signSpki),
            AgreementKeyId = KeyId.FromSubjectPublicKeyInfo(kexSpki),
        };
    }

    /// <summary>
    /// Human-comparable fingerprint of the whole bundle (both public keys), shown on both
    /// sides after import and compared out-of-band during the key ceremony.
    /// </summary>
    public string Fingerprint()
    {
        byte[] hash = SHA256.HashData(
            Convert.FromBase64String(SigningPublicKeySpki)
                .Concat(Convert.FromBase64String(AgreementPublicKeySpki)).ToArray());
        var groups = new string[8];
        for (int i = 0; i < 8; i++)
            groups[i] = Convert.ToHexString(hash, i * 2, 2);
        return string.Join("-", groups);
    }
}

internal static class BundleJson
{
    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        // Strict: unknown members rejected so a tampered/extended bundle fails loudly.
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
    };
}

/// <summary>Lookup of trusted peer keys, loaded from imported bundles.</summary>
public interface ITrustStore
{
    /// <summary>Finds a peer whose signing key id matches, or null if untrusted.</summary>
    PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId);
}

/// <summary>Directory-backed trust store: one JSON bundle per trusted peer.</summary>
public sealed class DirectoryTrustStore : ITrustStore, IDisposable
{
    private readonly List<PeerPublicKeys> _peers = new();

    public DirectoryTrustStore(string directory)
    {
        if (!Directory.Exists(directory)) return;
        foreach (var file in Directory.EnumerateFiles(directory, "*.json"))
        {
            try
            {
                _peers.Add(PublicKeyBundle.Parse(File.ReadAllText(file)).ToPeerKeys());
            }
            catch (Exception ex) when (ex is FormatException or JsonException or CryptographicException)
            {
                // A corrupt bundle must not take the store down; it is simply not trusted.
            }
        }
    }

    public IReadOnlyList<PeerPublicKeys> Peers => _peers;

    public PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId)
    {
        foreach (var peer in _peers)
            if (signingKeyId.SequenceEqual(peer.SigningKeyId))
                return peer;
        return null;
    }

    public void Dispose()
    {
        foreach (var p in _peers) p.Dispose();
    }
}

/// <summary>In-memory trust store for tests.</summary>
public sealed class InMemoryTrustStore : ITrustStore
{
    private readonly List<PeerPublicKeys> _peers = new();
    public void Add(PeerPublicKeys peer) => _peers.Add(peer);

    public PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId)
    {
        foreach (var peer in _peers)
            if (signingKeyId.SequenceEqual(peer.SigningKeyId))
                return peer;
        return null;
    }
}
