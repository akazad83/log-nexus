using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using QrDiode.Core.Crypto;

namespace QrDiode.Core.Manifest;

public enum ContentKind : byte
{
    File = 0,
    Xml = 1,
    Json = 2,
}

public enum CompressionAlg : byte
{
    None = 0,
    Brotli = 1,
}

/// <summary>
/// The transfer manifest: everything a receiver needs to reconstruct, decrypt and verify
/// one transfer. Serialized to a fixed binary layout and signed with the sender's ECDSA key.
/// </summary>
public sealed class TransferManifest
{
    public const int MaxFilenameBytes = 255;
    private const int FixedSize = 199; // bytes before the variable-length filename

    public required Guid SessionId { get; init; }
    public required long TimestampUnixMs { get; init; }
    public required ulong Counter { get; init; }
    public required byte[] SenderSigningKeyId { get; init; }      // 8
    public required byte[] ReceiverAgreementKeyId { get; init; }  // 8
    public required byte[] Salt { get; init; }                    // 32
    public required byte[] Nonce { get; init; }                   // 12
    public required ushort SymbolSize { get; init; }
    public required uint SourceSymbolCount { get; init; }         // K
    public required ulong LtSeed { get; init; }
    public required ushort RedundancyHint { get; init; }
    public required long OriginalSize { get; init; }
    public required long CompressedSize { get; init; }
    public required long CiphertextSize { get; init; }
    public required CompressionAlg Compression { get; init; }
    public required byte[] CiphertextSha256 { get; init; }        // 32
    public required byte[] PlaintextSha256 { get; init; }         // 32
    public required ContentKind ContentType { get; init; }
    public required string Filename { get; init; }

    public byte[] SessionTag => SessionId.ToByteArray().AsSpan(0, 8).ToArray();

    public byte[] Serialize()
    {
        byte[] nameBytes = Encoding.UTF8.GetBytes(Filename);
        if (nameBytes.Length > MaxFilenameBytes)
            throw new InvalidOperationException("Filename exceeds 255 UTF-8 bytes.");

        var body = new byte[FixedSize + nameBytes.Length];
        var span = body.AsSpan();

        SessionId.TryWriteBytes(span[..16]);
        BinaryPrimitives.WriteInt64LittleEndian(span[16..], TimestampUnixMs);
        BinaryPrimitives.WriteUInt64LittleEndian(span[24..], Counter);
        Require(SenderSigningKeyId, KeyId.Size).CopyTo(span[32..]);
        Require(ReceiverAgreementKeyId, KeyId.Size).CopyTo(span[40..]);
        Require(Salt, Envelope.SaltSize).CopyTo(span[48..]);
        Require(Nonce, Envelope.NonceSize).CopyTo(span[80..]);
        BinaryPrimitives.WriteUInt16LittleEndian(span[92..], SymbolSize);
        BinaryPrimitives.WriteUInt32LittleEndian(span[94..], SourceSymbolCount);
        BinaryPrimitives.WriteUInt64LittleEndian(span[98..], LtSeed);
        BinaryPrimitives.WriteUInt16LittleEndian(span[106..], RedundancyHint);
        BinaryPrimitives.WriteInt64LittleEndian(span[108..], OriginalSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[116..], CompressedSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[124..], CiphertextSize);
        span[132] = (byte)Compression;
        Require(CiphertextSha256, 32).CopyTo(span[133..]);
        Require(PlaintextSha256, 32).CopyTo(span[165..]);
        span[197] = (byte)ContentType;
        span[198] = (byte)nameBytes.Length;
        nameBytes.CopyTo(span[FixedSize..]);
        return body;
    }

    /// <summary>
    /// Parses a manifest body. Structural validation only — signature verification is the
    /// caller's job and MUST happen against these exact bytes before the result is trusted.
    /// </summary>
    public static bool TryParse(ReadOnlySpan<byte> body, out TransferManifest? manifest, out string error)
    {
        manifest = null;

        if (body.Length < FixedSize) { error = "Manifest body too short."; return false; }
        int nameLen = body[198];
        if (body.Length != FixedSize + nameLen) { error = "Manifest body length mismatch."; return false; }

        byte compression = body[132];
        if (compression > (byte)CompressionAlg.Brotli) { error = "Unknown compression algorithm."; return false; }
        byte contentType = body[197];
        if (contentType > (byte)ContentKind.Json) { error = "Unknown content type."; return false; }

        long originalSize = BinaryPrimitives.ReadInt64LittleEndian(body[108..]);
        long compressedSize = BinaryPrimitives.ReadInt64LittleEndian(body[116..]);
        long ciphertextSize = BinaryPrimitives.ReadInt64LittleEndian(body[124..]);
        ushort symbolSize = BinaryPrimitives.ReadUInt16LittleEndian(body[92..]);
        uint k = BinaryPrimitives.ReadUInt32LittleEndian(body[94..]);

        // Sanity bounds: fail-closed on anything outside the design envelope (64 MB payloads).
        const long maxPayload = 128L * 1024 * 1024;
        if (originalSize <= 0 || originalSize > maxPayload) { error = "Original size out of range."; return false; }
        if (compressedSize <= 0 || compressedSize > maxPayload) { error = "Compressed size out of range."; return false; }
        if (ciphertextSize != compressedSize + Envelope.TagSize) { error = "Ciphertext size inconsistent."; return false; }
        if (compression == (byte)CompressionAlg.None && compressedSize != originalSize) { error = "Uncompressed size mismatch."; return false; }
        if (compression == (byte)CompressionAlg.Brotli && compressedSize > originalSize) { error = "Compressed larger than original."; return false; }
        if (symbolSize == 0) { error = "Symbol size must be positive."; return false; }
        long expectedK = (ciphertextSize + symbolSize - 1) / symbolSize;
        if (k == 0 || k != expectedK) { error = "Source symbol count inconsistent."; return false; }

        string filename;
        try
        {
            filename = Encoding.UTF8.GetString(body.Slice(FixedSize, nameLen));
        }
        catch (ArgumentException) { error = "Invalid filename encoding."; return false; }

        manifest = new TransferManifest
        {
            SessionId = new Guid(body[..16]),
            TimestampUnixMs = BinaryPrimitives.ReadInt64LittleEndian(body[16..]),
            Counter = BinaryPrimitives.ReadUInt64LittleEndian(body[24..]),
            SenderSigningKeyId = body.Slice(32, KeyId.Size).ToArray(),
            ReceiverAgreementKeyId = body.Slice(40, KeyId.Size).ToArray(),
            Salt = body.Slice(48, Envelope.SaltSize).ToArray(),
            Nonce = body.Slice(80, Envelope.NonceSize).ToArray(),
            SymbolSize = symbolSize,
            SourceSymbolCount = k,
            LtSeed = BinaryPrimitives.ReadUInt64LittleEndian(body[98..]),
            RedundancyHint = BinaryPrimitives.ReadUInt16LittleEndian(body[106..]),
            OriginalSize = originalSize,
            CompressedSize = compressedSize,
            CiphertextSize = ciphertextSize,
            Compression = (CompressionAlg)compression,
            CiphertextSha256 = body.Slice(133, 32).ToArray(),
            PlaintextSha256 = body.Slice(165, 32).ToArray(),
            ContentType = (ContentKind)contentType,
            Filename = filename,
        };
        error = "";
        return true;
    }

    public byte[] Sign(ECDsa signingKey, byte[] serializedBody)
        => signingKey.SignData(serializedBody, HashAlgorithmName.SHA256); // IEEE P1363: 64 bytes for P-256

    public static bool VerifySignature(ECDsa signingPublicKey, ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
        => signingPublicKey.VerifyData(body, signature, HashAlgorithmName.SHA256);

    /// <summary>Receipt hash: SHA-256 over body ‖ signature. Shown on both screens for comparison.</summary>
    public static string ReceiptHash(ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
    {
        var buf = new byte[body.Length + signature.Length];
        body.CopyTo(buf);
        signature.CopyTo(buf.AsSpan(body.Length));
        return Convert.ToHexString(SHA256.HashData(buf).AsSpan(0, 8));
    }

    private static byte[] Require(byte[] value, int length)
        => value.Length == length ? value : throw new InvalidOperationException($"Expected {length}-byte field, got {value.Length}.");
}
