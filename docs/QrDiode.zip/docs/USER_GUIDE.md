# QrDiode — Step-by-Step User Guide

This guide walks you from a fresh checkout to a completed, verified OT → IT transfer.
Two paths are covered:

- **Part A — 5-minute demo on one machine** (recommended first run; full security active)
- **Part B — production setup on two machines** (the real key ceremony)

Everything requires **Windows** and the **.NET 10 SDK**.

> Command note: `dotnet run` forwards trailing arguments to the tool directly — no `--`
> separator is needed (and Windows PowerShell 5.1 actually swallows `--`, so omit it).

---

## Part A · 5-Minute Demo (one machine, full security)

The demo uses one PC as both sides: the Sender plays the QR stream on your monitor and the
Receiver watches it through your webcam. **Nothing is weakened** — real ECDSA signatures,
real ECDH + AES-256-GCM encryption, and anti-replay all run exactly as in production. The
only demo concession is that both key pairs live on the same machine.

### Step 1 — Build

```powershell
cd d:\WORKSPACE\qr-code
dotnet build -c Release
```

### Step 2 — Launch both apps

```powershell
dotnet run --project src/QrDiode.Sender  -c Release     # window 1
dotnet run --project src/QrDiode.Receiver -c Release    # window 2
```

### Step 3 — One click on each side

1. In the **Sender**, click **⚡ Demo setup** (top-right).
   It provisions the `demo-ot` and `demo-it` key pairs in Windows CNG, cross-trusts their
   public bundles, opens the sender keys, and pre-selects `demo-it` as the destination.
2. In the **Receiver**, click **⚡ Demo setup**.
   It opens the `demo-it` keys. The security card should now show **1 trusted sender** (green).
3. Both apps display the same two key **fingerprints** — in a real deployment you would read
   these aloud between rooms; for the demo just eyeball that they match.

### Step 4 — Transfer something

1. **Receiver**: pick your webcam in *Camera*, leave **Strict mode** checked
   (15-minute replay window instead of 48 hours — the "stricter security" demo setting),
   press **● Start receiving**.
2. **Sender**: *Browse…* to any XML/JSON/file up to 64 MB (start with something < 1 MB),
   press **▶ Start transmission**. The QR carousel takes over the screen.
3. Point the webcam at the monitor, 20–40 cm away, as square-on and steady as you can.
   The preview border and the pill in its corner turn **green ("LOCKED — decoding")** while
   codes are being read; the progress bar shows decoded blocks.
4. When the bar hits 100% the result card appears: filename, SHA-256, storage path, and the
   **receipt hash**.
5. Press **Esc** on the sender. Its status line shows the same receipt hash —
   **the two hashes matching is your end-to-end proof.**

The received file is in `%LocalAppData%\QrDiode\quarantine\`, journaled in
`%LocalAppData%\QrDiode\journal.db`, with hash-chained audit logs in
`%LocalAppData%\QrDiode\audit\`.

### Step 5 — See the security actually working (optional but fun)

- **Replay attack**: send the same file again → the sender reserves a *new* counter and
  session, so it works. But close and re-open the Receiver, then feed it a *screen recording*
  of the previous transmission → rejected with `Replay check failed: DuplicateSession`.
- **Duplicate content**: send the same file twice normally → second run completes but the
  result card shows **◎ Duplicate detected** and nothing is written twice (idempotency).
- **Unknown sender**: run `demo-clean` then `demo` again in the KeyCeremony tool on the
  sender side only — the receiver now rejects with `Unknown sender key` until it re-trusts.
- **Tamper check**: `dotnet run --project src/QrDiode.KeyCeremony list` shows the trust
  store; edit any byte of a stored quarantine file and compare its SHA-256 against the
  journal — the mismatch is immediately evident.

### Cleaning up demo keys

```powershell
dotnet run --project src/QrDiode.KeyCeremony demo-clean
```

Run this before provisioning a machine for production use.

---

## Part B · Production Setup (two machines)

### Overview

```
   OT machine (sender)                       IT machine (receiver)
   -------------------                       ---------------------
1. init ot-line-1                         1. init it-recv-1
2. export ot-line-1  -> ot.json  --+   +--  2. export it-recv-1 -> it.json
                                  |USB|
3. import it.json    <------------+   +-->  3. import ot.json
4. COMPARE FINGERPRINTS BY VOICE  <------>  (both sides read the same value aloud)
```

### Step 1 — Provision keys on each machine

On the **OT machine**:

```powershell
dotnet run --project src/QrDiode.KeyCeremony init ot-line-1
dotnet run --project src/QrDiode.KeyCeremony export ot-line-1 E:\ot-line-1.json
```

On the **IT machine**:

```powershell
dotnet run --project src/QrDiode.KeyCeremony init it-recv-1
dotnet run --project src/QrDiode.KeyCeremony export it-recv-1 E:\it-recv-1.json
```

Notes:
- Keys are created **non-exportable** in Windows CNG. If a TPM is present the tool uses the
  Platform Crypto Provider automatically (`init` prints which storage was used).
- Only **public** bundles are exported. Private keys never leave the machine, ever.

### Step 2 — Exchange bundles on removable media

Carry `ot-line-1.json` to the IT machine and `it-recv-1.json` to the OT machine
(USB stick, or any approved one-way media process).

```powershell
# On IT:
dotnet run --project src/QrDiode.KeyCeremony import E:\ot-line-1.json
# On OT:
dotnet run --project src/QrDiode.KeyCeremony import E:\it-recv-1.json
```

### Step 3 — Verify fingerprints (do not skip)

Each `import` prints a fingerprint like `3F2A-91CC-07B1-…`. The **exporting** operator runs
`fingerprint <bundle.json>` on their original file, and both operators compare the values
by phone or in person. **If they differ, someone tampered with the bundle in transit —
delete it immediately.** This step is what defeats a swapped-USB-stick attack.

### Step 4 — Daily operation

**Sender (OT):**
1. Launch `QrDiode.Sender` → *Step 1*: endpoint name `ot-line-1` → **Open / create keys**.
2. *Step 2*: pick the IT receiver from the destination list.
3. *Step 3*: browse to the payload (`.xml` / `.json` are content-validated on arrival;
   anything else travels as opaque verified bytes; 64 MB max).
4. *Step 4*: **▶ Start transmission**. Fullscreen carousel starts.
   - `Esc` stops · `↑`/`↓` changes speed live (start at 15 fps).
   - The status bar shows the QR version, loop count and **receipt hash**.

**Receiver (IT):**
1. Launch `QrDiode.Receiver` → *Step 1*: endpoint `it-recv-1` → **Open keys**.
2. *Step 2*: select the camera (the list pre-picks each camera's fastest mode).
3. *Step 3*: leave **Strict mode** on if OT and IT clocks are reasonably synchronized;
   turn it off only if clock drift between the environments can exceed minutes.
4. *Step 4*: **● Start receiving**, aim the camera at the OT screen.
   - Green border + **LOCKED** pill = codes are decoding; keep the camera steady.
   - Progress shows `blocks decoded / K`. Late joining and dropped frames are harmless —
     the carousel keeps looping until you have everything.
5. On completion: **compare the receipt hash with the sender's screen** (this is the
   operator-level end-to-end check), then collect the file from the quarantine folder.

### Camera tips (this is the whole bottleneck)

| Symptom | Fix |
|---|---|
| Pill stays "SEARCHING" | Move closer (QR should fill ~½ the frame height), square up the angle |
| Hits/s very low | Kill reflections/glare on the monitor; increase monitor brightness; lower sender fps with `↓` |
| Progress stalls near 100% | Normal for a few seconds — the last blocks arrive via coded symbols; just wait |
| Blurry preview | Lock focus if your camera app allows it; avoid autofocus hunting |

### Key rotation & revocation

1. Provision a new endpoint (`init ot-line-2`), export/import/verify as above.
2. Both old and new sender keys can be trusted simultaneously during the overlap window.
3. Revoke by deleting the old bundle from `%LocalAppData%\QrDiode\trust\` on the receiver
   and `delete ot-line-1` on the sender.

### Where everything lives

| Path | Contents |
|---|---|
| `%LocalAppData%\QrDiode\trust\` | Imported public-key bundles (the trust store) |
| `%LocalAppData%\QrDiode\quarantine\` | Received, fully verified files (`<session>_<name>`) |
| `%LocalAppData%\QrDiode\journal.db` | SQLite transfer journal + anti-replay watermarks |
| `%LocalAppData%\QrDiode\audit\*.jsonl` | Hash-chained audit logs (verify with `AuditLog.Verify`) |
| `%LocalAppData%\QrDiode\sender-counter.bin` | DPAPI-protected monotonic send counter |
| Windows CNG | Private keys (non-exportable, TPM when available) |

---

## Security cheat-sheet

What is **always on** (cannot be disabled anywhere in the UI):

| Layer | Mechanism |
|---|---|
| Authenticity | ECDSA P-256 signature verified **before any payload byte is parsed** |
| Confidentiality | AES-256-GCM, per-session key via static-static ECDH P-256 + HKDF-SHA256 |
| Anti-replay | Session GUID dedupe + per-key monotonic counter + timestamp window |
| Integrity | CRC-32 per frame → ciphertext SHA-256 → GCM tag → plaintext SHA-256 |
| Hostile input | XXE-prohibited XML, depth-capped JSON, decompression size cap, sanitized filenames |
| Traceability | Hash-chained audit logs both ends + matching receipt hashes |

What **Strict mode** adds: replay acceptance window shrinks 48 h → 15 min.

What the **demo** changes: nothing in the security stack — it only co-locates both key pairs
on one machine so you can evaluate without two PCs. Run `demo-clean` before going to production.
