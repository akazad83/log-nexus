# QrDiode — One-Way QR Streaming Data Diode (OT → IT) in .NET

> **Status: Phase 1 (MVP) implemented.** All Core protocol pieces, both WPF apps, the
> KeyCeremony tool, 52 passing tests (including a full optical loopback through real QR
> images) and a software bench are in this repository. See "As-built notes" at the end for
> the small deviations from this design and the measured performance numbers.

## Context

The goal is to move transactional data (files, XML payloads, JSON) from an OT (industrial/control) environment to an IT environment **with no network path** — an optical "data diode" where an OT screen displays an animated QR stream and an IT camera decodes it. Inspired by two repos, both researched:

- **decimen-optical-transfer** — Luby Transform fountain codes, one-way carousel streaming, SHA-256 verification, 400–600 KB/s. **No encryption.**
- **QRFerry (deedy/qr-data-transfer)** — RFC 6330 RaptorQ, Brotli compression, binary frame header + CRC-32, multi-lane QR display up to ~1.4 Mbps lab. **No encryption.**

Both prove the protocol shape (fountain-coded symbols, one symbol per QR frame, carousel until the receiver has enough) but treat "no network" as the whole security story. For OT→IT that is not acceptable — this plan adds authenticity, encryption, anti-replay, and receiver-side content quarantine as first-class, day-one requirements.

**User decisions (locked):**
1. Two Windows desktop apps (WPF): Sender on OT PC (fullscreen QR carousel), Receiver on IT PC (webcam decode).
2. **Strictly one-way** — no back-channel of any kind, true data-diode semantics.
3. Payloads: small XML/JSON transactions (<1 MB common case) up to ~64 MB files. Transactional: atomic, auditable, idempotent (dedupe on re-send).
4. **Sign + encrypt** with offline-provisioned keys, FIPS-friendly in-box .NET crypto.

## Verified Stack (Aug 2026)

| Concern | Choice | Notes |
|---|---|---|
| Runtime | **.NET 10 (LTS)** | Supported to Nov 2028; self-contained single-file publish for OT (no runtime install) |
| UI | **WPF** both apps | Borderless fullscreen + `WriteableBitmap` blit + `CompositionTarget.Rendering` pacing; avoids Windows App SDK deployment burden on locked-down OT machines |
| Fountain coding | **In-house systematic Luby Transform codec** (pure C#) | **No maintained .NET RaptorQ exists** (only Rust/C++/Java/Go). ~600 lines of auditable C# beats a P/Invoked native blob for a security tool. LT overhead ~5–10% vs RaptorQ's ~0.2% — acceptable; Rust `raptorq` FFI kept as a Phase 2 option behind the codec interface |
| QR generation | **Net.Codecrete.QrCodeGenerator 3.0.0** | Pure C#, byte mode, all versions/ECC levels, fast enough for 30+ codes/s |
| QR decoding | **ZXingCpp 0.5.3** (native zxing-cpp 3.1.1, win-x64/arm64) | Native speed is the only way to sustain 30–60 fps decode of V30–V40 codes |
| Camera capture | **FlashCap 1.11.0** | Zero-dependency, raw frame-pointer access (zero-copy Y-plane → ZXingCpp), DirectShow + Media Foundation |
| Compression | In-box `BrotliStream` | Keep smaller of raw vs brotli |
| Crypto | In-box `System.Security.Cryptography` | ECDSA P-256 (sign) + ECDH P-256 + HKDF-SHA256 (key derivation) + AES-256-GCM (encrypt). CNG/TPM-backed, FIPS-capable. No third-party crypto supply chain |
| Frame CRC | `System.IO.Hashing` (CRC-32) | Cheap pre-filter before any crypto work |
| Receiver journal | **Microsoft.Data.Sqlite** (WAL) | Transactional dedupe + watermark store; single file, no server |

## Solution Structure

```
QrDiode.sln
├── src/QrDiode.Core/            # UI-agnostic protocol library — fully unit-testable, no screen/camera
│   ├── Fountain/                #   LT encoder/decoder (systematic, robust soliton, seeded PRNG)
│   ├── Framing/                 #   FrameWriter / FrameParser (span-based, allocation-bounded)
│   ├── Crypto/                  #   Envelope seal/open, key-store abstraction (CNG-TPM / DPAPI)
│   ├── Manifest/                #   Manifest serialize / parse / sign / verify
│   └── Pipeline/                #   SendPipeline (bytes→frames), ReceivePipeline (frames→bytes)
├── src/QrDiode.Sender/          # WPF: fullscreen QR carousel renderer (OT side)
├── src/QrDiode.Receiver/        # WPF: capture → decode → verify → quarantine → journal (IT side)
├── src/QrDiode.KeyCeremony/     # Console: keygen, public-bundle export/import, fingerprint words
├── tests/QrDiode.Core.Tests/    # xunit: loopback property tests, negative-path tests, fuzz corpus
└── tests/QrDiode.Bench/         # BenchmarkDotNet + real screen↔camera soak harness
```

Hard rule: `QrDiode.Core` references only the BCL + `System.IO.Hashing` (SQLite journal lives behind an interface implemented in Receiver). A full encode → shuffled/lossy frames → decode round-trip runs as a unit test.

## Wire Protocol (v1)

One QR code = one frame, raw byte mode, little-endian, fixed offsets (no variable-length structures in the hot path).

**Common header (12 B):** magic `"OD"` (2) · protocol version (1) · frame type (1: manifest / data symbol) · session tag = first 8 bytes of session GUID (8). Every frame ends with **CRC-32 (4 B)** over all preceding bytes.

**Data symbol frame:** header + `symbolId: uint32` + fixed-size symbol payload + CRC. `symbolId` deterministically seeds the LT PRNG so both sides derive identical degree/neighbor sets from `(sessionSeed, symbolId)` — no per-symbol metadata. Systematic region: `symbolId < K` ⇒ symbol is source block `symbolId` verbatim.

**Manifest frame:** header + manifest body + ECDSA signature (64 B r‖s) + CRC. Manifest body (fits one V30-L code):
- Session GUID (16) · timestamp unix-ms (8) · **per-sender-key monotonic counter (8)**
- Sender key ID = SHA-256(pubkey)[0..8] (8) · receiver key ID (8) — pins intended recipient
- HKDF salt (32) · AES-GCM nonce (12)
- Coding params: symbolSize (2) · K source count (4) · LT session seed (8) · redundancy hint (2)
- Sizes: original (8) · compressed (8) · ciphertext (8) · compression alg (1)
- **SHA-256 of ciphertext (32)** and **SHA-256 of plaintext (32)**
- Content type (1: file/xml/json) · filename length (1) · filename UTF-8 (≤255 B)

**Carousel:** manifest frame re-emitted every ~20th frame (late joiners acquire it within ~1 s); data symbols cycle systematic pass (0..K−1) first, then fresh coded symbols, looping until the redundancy budget (3× K emitted) or operator stop.

## Transfer Pipeline (security-ordered, fail-closed)

**Sender:** plaintext → SHA-256 → Brotli (keep smaller) → `key = HKDF-SHA256(ECDH(sender_priv, receiver_pub), salt=random32, info="QrDiode.v1"‖sessionGuid)` → AES-256-GCM one-shot with **AAD = sessionGuid ‖ salt ‖ counter ‖ senderKeyId ‖ receiverKeyId** → SHA-256(ciphertext) into manifest → ECDSA-sign manifest → LT-encode ciphertext → frames → QR.

Binding is bidirectional and non-circular: the signature covers the manifest which contains the ciphertext hash; the GCM AAD reconstructs session identity from the manifest. Neither a foreign manifest nor a substituted ciphertext can be mixed and matched.

**Receiver — strict order, nothing later runs until the earlier step passes:**
1. Frame CRC-32 (no allocation on reject)
2. **Manifest ECDSA signature against provisioned sender key** — no payload byte is interpreted before this passes
3. Anti-replay: unseen session GUID ∧ counter > per-key high-watermark ∧ timestamp within ±48 h
4. LT decode completes → SHA-256(ciphertext) matches manifest
5. AES-GCM open with reconstructed AAD
6. Brotli decompress with **hard output cap = manifest original size** (zip-bomb guard)
7. SHA-256(plaintext) matches manifest
8. Content gate: XML via `XmlReader` (`DtdProcessing.Prohibit`, `XmlResolver = null`, depth/size limits); JSON via `Utf8JsonReader` (`MaxDepth`); files uninterpreted
9. Atomic materialization + journal + audit in one SQLite transaction

## Security Architecture ("brutally secure")

| Threat | Countermeasure |
|---|---|
| Rogue QR stream injected into receiver camera | Signature-before-processing; only offline-provisioned sender keys; unknown key ID → dropped + audited, never parsed |
| Replay of a previously filmed stream | Session-GUID replay cache **and** per-key monotonic counter watermark **and** timestamp window — all three must pass |
| Shoulder-surf exfil (someone films the OT screen) | Payload is AES-256-GCM ciphertext keyed to the provisioned receiver — filming yields ciphertext. Residual traffic analysis (size/timing) documented and accepted |
| Malformed frames attacking the parser | `ReadOnlySpan<byte>` parser, fixed offsets, up-front length checks, Try-pattern (no exceptions in hot path), zero allocation on reject; fuzzed in Phase 3 |
| Malicious payload content (XXE, zip bomb, path traversal) | XXE-disabled parsers; decompression cap; filename sanitized to `{sessionGuid}_{sanitizedName}`; quarantine dir with restrictive ACLs |
| Receiver as pivot into IT | Least-privilege dedicated account; app has zero network features; no `BinaryFormatter` / polymorphic deserialization anywhere; touches only camera, quarantine folder, journal DB |
| Key theft | Private keys non-exportable in Windows CNG Platform Crypto Provider (TPM) where available, else Software KSP + DPAPI; ceremony transports public bundles only |
| Audit tampering | Append-only hash-chained audit log (JSONL, each record embeds SHA-256 of previous) on both machines; receipt hash shown on both screens for out-of-band comparison |

**Key ceremony (`QrDiode.KeyCeremony`):** per-endpoint ECDSA + ECDH P-256 pairs generated in CNG (non-exportable); public bundles exported to removable media; on import each side displays a PGP-style **fingerprint word list** operators compare verbally. Rotation: new key provisioned alongside old (manifest carries key ID, receiver accepts either during overlap), revocation = delete from trust store; counter watermarks are per key ID so rotation resets cleanly.

## Runtime Design

**Sender:** pipeline thread pre-encodes QR frames into a ring buffer of reused pixel arrays (≥2× fps headroom); UI thread blits via `WriteableBitmap` on `CompositionTarget.Rendering`, stopwatch-gated (start 15 fps, operator-adjustable 10–30). Borderless topmost fullscreen, pure black/white, ~8-module quiet zone, `SetThreadExecutionState` keeps the display awake. Shows loop count + transfer receipt hash.

**Receiver:** FlashCap at highest-fps mode (prefer 60 fps 720p over 30 fps 1080p — temporal diversity wins); YUY2 Y-plane passed zero-copy as luminance `ImageView` to ZXingCpp; bounded decode worker drops frames when busy (carousel makes drops free). Per decode: CRC → symbol dedupe bitset by `(sessionTag, symbolId)` → incremental LT peeling decoder. Live overlay: preview, green flash per accepted symbol, progress `uniqueSymbols / K` with ETA, focus/exposure hints driven by decode-rate telemetry. Completion screen shows filename, sizes, plaintext SHA-256, session GUID, receipt hash.

## Transactional Semantics

- **Dedupe/journal (SQLite, WAL):** `transfers(session_guid PK, sender_key_id, counter, plaintext_sha256, filename, size, received_utc, status)` + `key_watermarks(key_id PK, counter)`. Re-send of same session GUID or same plaintext hash from same sender → recorded as duplicate, not re-materialized.
- **Atomicity:** all verification in memory / `quarantine\.staging\{guid}.tmp`; after final hash: `Flush(flushToDisk: true)` → rename into quarantine → SQLite transaction commits journal + audit record. A crash leaves either nothing visible or a complete journaled file.
- Sender persists its monotonic counter in a DPAPI-protected state file.

## Honest Throughput Expectations

- V30-L ≈ 1370 B/frame, V40-L ≈ 2953 B/frame, minus ~20 B overhead.
- **MVP, single lane, ordinary webcam:** ~15–25 unique frames/s ⇒ **~25–70 KB/s**. A 200 KB XML transaction: 5–15 s. 64 MB: 20–45 min (works, but the pain point).
- **Phase 2 tuned (60 fps camera, locked exposure/manual focus, 2–4 lanes, V40-L):** **100–400 KB/s** ⇒ 64 MB in ~4–10 min.
- Tuning knobs by impact: lanes → camera fps → QR version → ECC level → symbol size.

## Implementation Phases

**Phase 1 — MVP (crypto from day one, never a later phase):**
1. `QrDiode.Core`: frame format + span parser; LT codec with property tests (round-trips at ≤1.10× K with up to 50% random loss); crypto envelope + key-store abstraction (CNG + DPAPI backends); manifest sign/verify; full lossy-loopback pipeline test.
2. `KeyCeremony`: keygen (TPM-preferred), bundle export/import, fingerprint words.
3. Sender app: payload picker, pipeline, ring-buffer renderer, fullscreen carousel, fps control, budget/stop, receipt screen.
4. Receiver app: FlashCap → ZXingCpp loop, LT collection UI, full verification chain, SQLite journal + watermarks, quarantine, hash-chained audit, receipt screen.
5. End-to-end bench: two machines + real webcam, 1 MB and 64 MB transfers, record baseline KB/s.

**Phase 2 — Throughput:** multi-lane rendering (2×1 → 2×2, lane ID folded into symbolId space) + per-lane decode regions; 60 fps + manual exposure/focus via UVC controls; QR version auto-selection by payload size; benchmark matrix; optional Rust `raptorq` FFI spike behind the codec interface if LT overhead proves material at 64 MB.

**Phase 3 — Hardening & ops:** fuzz frame/manifest parsers (SharpFuzz, corpus from bench captures); key rotation + revocation tooling and runbook; ops docs (self-contained OT publish, receiver least-privilege setup script, audit verification tool); negative-path integration tests (tampered manifest, spliced ciphertext, replayed session, zip bomb, XXE).

## Critical Files (to be created)

- `src/QrDiode.Core/Fountain/LtEncoder.cs`, `LtDecoder.cs` — the in-house systematic LT codec
- `src/QrDiode.Core/Framing/FrameParser.cs` — span-based wire format; the primary attack surface
- `src/QrDiode.Core/Crypto/Envelope.cs` — ECDH+HKDF+AES-GCM seal/open, ECDSA signing, AAD binding
- `src/QrDiode.Receiver/Capture/DecodePipeline.cs` — FlashCap → ZXingCpp zero-copy decode loop
- `src/QrDiode.Sender/Rendering/CarouselRenderer.cs` — ring-buffered fullscreen carousel

## Verification

1. **Unit/property tests (no hardware):** `dotnet test` — LT codec round-trips under shuffle + 50% loss; frame parser rejects every malformed corpus entry without allocation; crypto envelope negative tests (wrong key, tampered AAD, spliced ciphertext, replayed counter).
2. **Loopback integration:** encode a file → render QR frames to in-memory bitmaps → decode with ZXingCpp from bitmaps → full receiver pipeline → byte-identical file + journal row (still no camera needed).
3. **Physical end-to-end:** run Sender fullscreen on one machine, Receiver + webcam on another; transfer a 200 KB XML and a 64 MB file; confirm receipt hashes match on both screens, duplicate re-send is deduped, and the audit chains verify.
4. **Security negative paths:** replay a recorded session (must reject), present an unprovisioned sender key (must drop before parsing), send an XXE XML and an over-declared Brotli payload (must fail closed and audit).

## As-built notes (Phase 1 delivery)

Measured on the development machine (software only — the physical screen→camera hop is excluded):

| Stage | Measured |
|---|---|
| QR generation, V30-L 1370 B frame | ~1,140 codes/s (0.9 ms each) |
| ZXingCpp native decode, clean V30 image | ~370 decodes/s (2.7 ms each) |
| SendSession.Create for 64 MB (hash+compress+encrypt+sign) | ~0.4 s |
| LT coded-frame generation at K=49,711 | ~52,000 frames/s |
| Entire receive pipeline for 64 MB at 5% loss | ~1.1 s CPU |

Conclusion: software costs are negligible at any realistic display rate; the optical channel is the only bottleneck, exactly as designed.

Deviations from the design above, all minor:

1. **Manifest frame layout** gained a 2-byte body-length prefix (header + bodyLen + body + signature + CRC) since the filename makes the body variable-length.
2. **Fingerprints** are eight hex groups (`3F2A-91CC-…`) rather than a PGP word list — easier to compare over the phone without a transcription-error-prone 512-word table. Word list remains a Phase 3 nicety.
3. **Receiver capture path** converts FlashCap's transcoded DIB to a reusable luminance plane (one pass, ~1 ms at 720p) instead of the zero-copy YUY2 path. At 370 decodes/s of headroom this is not a bottleneck; zero-copy is a Phase 2 optimization.
4. **Journal commit semantics**: the anti-replay watermark and a `verified` journal row commit transactionally at verification time; the row is promoted to `stored` (or `duplicate`) after atomic file materialization. A crash in between is visible to the operator as a `verified` row with no file.
5. **Bench** is a plain console harness rather than BenchmarkDotNet — adequate for stage-level numbers.

Remaining Phase 1 item: the two-machine physical end-to-end run (real webcam) to baseline actual optical KB/s. Phases 2 (multi-lane, camera tuning) and 3 (fuzzing, rotation runbook, ops hardening) are unchanged.
