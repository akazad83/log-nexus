using System.Diagnostics;
using Net.Codecrete.QrCodeGenerator;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using ZXingCpp;

// Software-only throughput benchmark: measures every stage of the pipeline except the
// physical screen→camera hop, so the optical channel is the only unknown left.

Console.WriteLine("QrDiode software bench (no camera involved)\n");

const int SymbolSize = 1350;
const int FrameSize = SymbolSize + 20; // wire overhead

// ---- 1. QR generation rate (sender side, V30-L) ----
{
    var payload = new byte[FrameSize];
    Random.Shared.NextBytes(payload);
    var sw = Stopwatch.StartNew();
    int n = 200;
    for (int i = 0; i < n; i++)
    {
        payload[0] = (byte)i;
        var segs = new List<DataSegment> { DataSegment.MakeSegment(DataSegmentMode.Binary, new ArraySegment<byte>(payload)) };
        _ = QrCode.EncodeSegments(segs, QrCode.Ecc.Low, 30, 30, false);
    }
    sw.Stop();
    double perSec = n / sw.Elapsed.TotalSeconds;
    Console.WriteLine($"QR generation (V30-L, {FrameSize} B): {perSec:0} codes/s  ({sw.Elapsed.TotalMilliseconds / n:0.00} ms each)");
}

// ---- 2. ZXing decode rate on a clean V30 luminance image ----
{
    var payload = new byte[FrameSize];
    Random.Shared.NextBytes(payload);
    var segs = new List<DataSegment> { DataSegment.MakeSegment(DataSegmentMode.Binary, new ArraySegment<byte>(payload)) };
    var qr = QrCode.EncodeSegments(segs, QrCode.Ecc.Low, 30, 30, false);

    const int scale = 4, quiet = 8;
    int dim = (qr.Size + quiet * 2) * scale;
    var image = new byte[dim * dim];
    Array.Fill(image, (byte)255);
    for (int y = 0; y < qr.Size; y++)
        for (int x = 0; x < qr.Size; x++)
            if (qr.GetModule(x, y))
                for (int dy = 0; dy < scale; dy++)
                    for (int dx = 0; dx < scale; dx++)
                        image[((y + quiet) * scale + dy) * dim + (x + quiet) * scale + dx] = 0;

    var options = new ReaderOptions { Formats = BarcodeFormat.QRCode, TryHarder = false, TryRotate = false, TryInvert = false };
    var sw = Stopwatch.StartNew();
    int n = 200;
    for (int i = 0; i < n; i++)
    {
        var view = new ImageView(image, dim, dim, ImageFormat.Lum);
        var results = BarcodeReader.Read(view, options);
        if (results.Length != 1) throw new InvalidOperationException("decode failed");
    }
    sw.Stop();
    Console.WriteLine($"ZXingCpp decode (V30 @ {dim}px):        {n / sw.Elapsed.TotalSeconds:0} decodes/s  ({sw.Elapsed.TotalMilliseconds / n:0.00} ms each)");
}

// ---- 3. Full sender session creation for 64 MB (hash+compress+encrypt+sign) ----
byte[] big = new byte[64 * 1024 * 1024];
Random.Shared.NextBytes(big); // worst case: incompressible
using var sender = new EphemeralEndpointKeys();
using var receiver = new EphemeralEndpointKeys();
using var receiverPeer = PublicKeyBundle.FromKeys("bench", receiver).ToPeerKeys();

SendSession session;
{
    var sw = Stopwatch.StartNew();
    session = SendSession.Create(big, "bench.bin", ContentKind.File, sender, receiverPeer, 1);
    sw.Stop();
    Console.WriteLine($"SendSession.Create (64 MB random):     {sw.Elapsed.TotalSeconds:0.0} s  (K={session.K})");
}

// ---- 4. LT symbol generation rate at 64 MB scale ----
{
    var sw = Stopwatch.StartNew();
    int n = 2000;
    uint start = (uint)session.K; // coded symbols (the expensive kind)
    for (uint i = 0; i < n; i++)
        _ = session.GetDataFrame(start + i);
    sw.Stop();
    Console.WriteLine($"LT coded-frame generation (K={session.K}): {n / sw.Elapsed.TotalSeconds:0} frames/s");
}

// ---- 5. LT decode wall-clock for 64 MB (systematic + 5% loss) ----
{
    var trust = new InMemoryTrustStore();
    trust.Add(PublicKeyBundle.FromKeys("ot", sender).ToPeerKeys());
    var engine = new ReceiveEngine(trust, new InMemoryReplayGuard(), receiver);
    var rng = new Random(1);
    var sw = Stopwatch.StartNew();
    long frames = 0;
    foreach (var frame in session.Carousel())
    {
        if (rng.NextDouble() < 0.05) continue;
        frames++;
        if (engine.Feed(frame) == FeedResult.Completed) break;
    }
    sw.Stop();
    if (engine.Completed is null) throw new InvalidOperationException("bench decode failed");
    Console.WriteLine($"Receive pipeline (64 MB, 5% loss):     {sw.Elapsed.TotalSeconds:0.0} s CPU-side for {frames} frames");
}

// ---- 6. Projections ----
Console.WriteLine();
Console.WriteLine("Projected optical throughput (payload bytes/s = fps × symbolSize, before LT overhead):");
foreach (int fps in new[] { 10, 15, 20, 30 })
    Console.WriteLine($"  {fps,2} unique frames/s → {fps * SymbolSize / 1024.0,6:0.0} KB/s → 64 MB in {64 * 1024.0 * 1024 / (fps * SymbolSize) / 60,5:0.0} min");
Console.WriteLine("\nThe physical screen→camera hop is the bottleneck; run the two-machine test to measure it.");
