using QrDiode.Core.Fountain;
using Xunit;

namespace QrDiode.Core.Tests;

public class FountainTests
{
    [Theory]
    [InlineData(17, 1350)]        // K = 1
    [InlineData(1350, 1350)]      // exactly one symbol
    [InlineData(1351, 1350)]      // K = 2, one padded byte
    [InlineData(50_000, 1350)]    // K = 38
    [InlineData(1_000_000, 1350)] // K = 741
    [InlineData(4096, 64)]        // small symbols, K = 64
    public void RoundTrip_NoLoss_SystematicOnly(int payloadSize, int symbolSize)
    {
        byte[] payload = MakePayload(payloadSize);
        var encoder = new LtEncoder(payload, symbolSize, sessionSeed: 42);
        var decoder = new LtDecoder(payloadSize, symbolSize, sessionSeed: 42);

        var buf = new byte[symbolSize];
        for (uint i = 0; i < encoder.K && !decoder.IsComplete; i++)
        {
            encoder.GenerateSymbol(i, buf);
            decoder.AddSymbol(i, buf);
        }

        Assert.True(decoder.IsComplete);
        Assert.Equal(payload, decoder.Assemble());
    }

    [Theory]
    [InlineData(200_000, 1350, 0.3, 1)]
    [InlineData(200_000, 1350, 0.5, 2)]
    [InlineData(50_000, 512, 0.3, 3)]
    [InlineData(1_000_000, 1350, 0.4, 4)]
    public void RoundTrip_WithLoss_CodedSymbolsRecover(int payloadSize, int symbolSize, double lossRate, int seed)
    {
        byte[] payload = MakePayload(payloadSize, seed);
        ulong sessionSeed = (ulong)(seed * 7919 + 1);
        var encoder = new LtEncoder(payload, symbolSize, sessionSeed);
        var decoder = new LtDecoder(payloadSize, symbolSize, sessionSeed);
        var rng = new Random(seed);

        var buf = new byte[symbolSize];
        uint symbolId = 0;
        long fed = 0;
        long cap = 20L * encoder.K; // far beyond any sane overhead — a miss means a real bug

        while (!decoder.IsComplete && symbolId < cap)
        {
            encoder.GenerateSymbol(symbolId, buf);
            if (rng.NextDouble() >= lossRate)
            {
                decoder.AddSymbol(symbolId, buf);
                fed++;
            }
            symbolId++;
        }

        Assert.True(decoder.IsComplete, $"Decoder incomplete after {symbolId} generated / {fed} fed symbols (K={encoder.K}).");
        Assert.Equal(payload, decoder.Assemble());

        // Overhead sanity. LT overhead is proportionally worse at small K (robust soliton
        // asymptotics), so allow a flat allowance on top of the percentage.
        Assert.True(decoder.UniqueSymbolsReceived <= encoder.K * 1.35 + 60,
            $"Excessive overhead: {decoder.UniqueSymbolsReceived} symbols for K={encoder.K}.");
    }

    [Fact]
    public void RoundTrip_ShuffledOutOfOrder()
    {
        const int payloadSize = 300_000;
        const int symbolSize = 1350;
        byte[] payload = MakePayload(payloadSize, 9);
        var encoder = new LtEncoder(payload, symbolSize, 777);
        var decoder = new LtDecoder(payloadSize, symbolSize, 777);

        int total = (int)(encoder.K * 1.6);
        var ids = Enumerable.Range(0, total).Select(i => (uint)i).ToArray();
        var rng = new Random(123);
        rng.Shuffle(ids);

        var buf = new byte[symbolSize];
        foreach (uint id in ids)
        {
            if (decoder.IsComplete) break;
            encoder.GenerateSymbol(id, buf);
            decoder.AddSymbol(id, buf);
        }

        Assert.True(decoder.IsComplete);
        Assert.Equal(payload, decoder.Assemble());
    }

    [Fact]
    public void DuplicateSymbols_AreIgnored()
    {
        byte[] payload = MakePayload(10_000);
        var encoder = new LtEncoder(payload, 512, 5);
        var decoder = new LtDecoder(10_000, 512, 5);

        var buf = new byte[512];
        encoder.GenerateSymbol(0, buf);
        Assert.True(decoder.AddSymbol(0, buf));
        Assert.False(decoder.AddSymbol(0, buf)); // duplicate
        Assert.Equal(1, decoder.UniqueSymbolsReceived);
    }

    [Fact]
    public void NeighborDerivation_IsDeterministic()
    {
        var soliton = new RobustSoliton(1000);
        var a = LtCode.GetNeighbors(123456789UL, 5000, soliton);
        var b = LtCode.GetNeighbors(123456789UL, 5000, soliton);
        Assert.Equal(a, b);
        Assert.Equal(a.Length, a.Distinct().Count()); // all distinct
        Assert.All(a, n => Assert.InRange(n, 0, 999));

        var c = LtCode.GetNeighbors(987654321UL, 5000, soliton);
        Assert.NotEqual(a, c); // different seed → different set (overwhelmingly)
    }

    private static byte[] MakePayload(int size, int seed = 1)
    {
        var payload = new byte[size];
        new Random(seed).NextBytes(payload);
        return payload;
    }
}
