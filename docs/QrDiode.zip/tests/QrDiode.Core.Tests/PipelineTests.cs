using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

public class PipelineTests : IDisposable
{
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public PipelineTests()
    {
        _trust.Add(ToPeer("ot-sender", _sender));
        _receiverPeer = ToPeer("it-receiver", _receiver);
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    private static PeerPublicKeys ToPeer(string name, EphemeralEndpointKeys keys)
        => PublicKeyBundle.FromKeys(name, keys).ToPeerKeys();

    [Theory]
    [InlineData(100, ContentKind.File)]        // K = 1
    [InlineData(200_000, ContentKind.File)]
    [InlineData(2_000_000, ContentKind.File)]
    public void Loopback_Lossless_CompletesAndMatches(int size, ContentKind kind)
    {
        byte[] payload = new byte[size];
        new Random(size).NextBytes(payload);

        var session = SendSession.Create(payload, "data.bin", kind, _sender, _receiverPeer, counter: 1);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        FeedAll(session, engine, lossRate: 0, seed: 1);

        Assert.NotNull(engine.Completed);
        Assert.Equal(payload, engine.Completed!.Plaintext);
        Assert.Equal(session.ReceiptHash, engine.Completed.ReceiptHash);
    }

    [Fact]
    public void Loopback_Lossy_Shuffled_Completes()
    {
        byte[] payload = Encoding.UTF8.GetBytes("<batch>" + new string('x', 400_000) + "</batch>");
        var session = SendSession.Create(payload, "report.xml", ContentKind.Xml, _sender, _receiverPeer, counter: 2);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        FeedAll(session, engine, lossRate: 0.35, seed: 42);

        Assert.NotNull(engine.Completed);
        Assert.Equal(payload, engine.Completed!.Plaintext);
    }

    [Fact]
    public void UnknownSenderKey_IsRejected_BeforeAnyPayloadProcessing()
    {
        using var rogueSender = new EphemeralEndpointKeys(); // NOT in the trust store
        var session = SendSession.Create(new byte[1000], "x.bin", ContentKind.File, rogueSender, _receiverPeer, counter: 1);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        var result = engine.Feed(session.ManifestFrame);

        Assert.Equal(FeedResult.Rejected, result);
        Assert.Contains("Unknown sender key", engine.LastRejection);
        Assert.Null(engine.ActiveManifest);
    }

    [Fact]
    public void TamperedManifest_SignatureFails()
    {
        var session = SendSession.Create(new byte[5000], "x.bin", ContentKind.File, _sender, _receiverPeer, counter: 1);

        // Flip one byte inside the manifest body (inside the declared plaintext hash),
        // then re-fix the frame CRC so only the signature stands in the way.
        byte[] frame = (byte[])session.ManifestFrame.Clone();
        frame[FrameFormat.HeaderSize + 2 + 170] ^= 0x01;
        FixCrc(frame);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        var result = engine.Feed(frame);

        Assert.Equal(FeedResult.Rejected, result);
        Assert.Contains("signature", engine.LastRejection, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ReplayedSession_IsRejected()
    {
        byte[] payload = new byte[10_000];
        var session = SendSession.Create(payload, "x.bin", ContentKind.File, _sender, _receiverPeer, counter: 5);
        var guard = new InMemoryReplayGuard();

        var engine1 = new ReceiveEngine(_trust, guard, _receiver);
        FeedAll(session, engine1, 0, 1);
        Assert.NotNull(engine1.Completed);

        // Same captured stream fed again (fresh engine, shared guard = same receiver machine).
        var engine2 = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Rejected, engine2.Feed(session.ManifestFrame));
        Assert.Contains("Replay", engine2.LastRejection);

        // A stale counter is rejected even with a fresh session id.
        var stale = SendSession.Create(payload, "y.bin", ContentKind.File, _sender, _receiverPeer, counter: 4);
        var engine3 = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Rejected, engine3.Feed(stale.ManifestFrame));
        Assert.Contains("StaleCounter", engine3.LastRejection);
    }

    [Fact]
    public void ManifestForDifferentReceiver_IsRejected()
    {
        using var otherReceiver = new EphemeralEndpointKeys();
        using var otherPeer = ToPeer("other-recv", otherReceiver);

        // Encrypted to some OTHER receiver's key — our receiver must refuse it up front.
        var session = SendSession.Create(new byte[1000], "x.bin", ContentKind.File, _sender, otherPeer, counter: 1);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        Assert.Equal(FeedResult.Rejected, engine.Feed(session.ManifestFrame));
        Assert.Contains("different receiver", engine.LastRejection);
    }

    [Fact]
    public void XxePayload_FailsContentGate()
    {
        byte[] xxe = Encoding.UTF8.GetBytes(
            """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///c:/windows/win.ini">]><foo>&xxe;</foo>""");
        var session = SendSession.Create(xxe, "evil.xml", ContentKind.Xml, _sender, _receiverPeer, counter: 1);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        FeedAll(session, engine, 0, 1);

        Assert.Null(engine.Completed);
        Assert.Contains("Content gate", engine.LastRejection);
    }

    [Fact]
    public void ValidXmlAndJson_PassContentGate()
    {
        var guard = new InMemoryReplayGuard();

        byte[] xml = Encoding.UTF8.GetBytes("""<?xml version="1.0"?><batch id="7"><item qty="2">valve</item></batch>""");
        var s1 = SendSession.Create(xml, "batch.xml", ContentKind.Xml, _sender, _receiverPeer, counter: 1);
        var e1 = new ReceiveEngine(_trust, guard, _receiver);
        FeedAll(s1, e1, 0, 1);
        Assert.NotNull(e1.Completed);

        byte[] json = Encoding.UTF8.GetBytes("""{"batch": 7, "items": [{"name": "valve", "qty": 2}]}""");
        var s2 = SendSession.Create(json, "batch.json", ContentKind.Json, _sender, _receiverPeer, counter: 2);
        var e2 = new ReceiveEngine(_trust, guard, _receiver);
        FeedAll(s2, e2, 0, 1);
        Assert.NotNull(e2.Completed);
    }

    [Fact]
    public void LateJoin_MissesEarlyFrames_StillCompletes()
    {
        byte[] payload = new byte[100_000];
        new Random(11).NextBytes(payload);
        var session = SendSession.Create(payload, "x.bin", ContentKind.File, _sender, _receiverPeer, counter: 1);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        int skip = session.K / 2 + 5; // receiver joins mid-carousel
        int fed = 0;
        foreach (var frame in session.Carousel())
        {
            if (fed++ < skip) continue;
            if (engine.Feed(frame) == FeedResult.Completed) break;
            Assert.True(fed < 100_000, "Never completed.");
        }

        Assert.NotNull(engine.Completed);
        Assert.Equal(payload, engine.Completed!.Plaintext);
    }

    [Fact]
    public void CompressionRoundTrip_HighlyCompressibleXml()
    {
        // 1 MB of repetitive XML should travel as a small fraction of its size.
        byte[] xml = Encoding.UTF8.GetBytes("<log>" + string.Concat(
            Enumerable.Range(0, 20_000).Select(i => $"<entry seq=\"{i}\" level=\"INFO\">pump ok</entry>")) + "</log>");
        var session = SendSession.Create(xml, "log.xml", ContentKind.Xml, _sender, _receiverPeer, counter: 1);

        Assert.Equal(CompressionAlg.Brotli, session.Manifest.Compression);
        Assert.True(session.Manifest.CompressedSize < xml.Length / 10);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        FeedAll(session, engine, 0, 1);
        Assert.NotNull(engine.Completed);
        Assert.Equal(xml, engine.Completed!.Plaintext);
    }

    private static void FeedAll(SendSession session, ReceiveEngine engine, double lossRate, int seed)
    {
        var rng = new Random(seed);
        long cap = 500_000;
        foreach (var frame in session.Carousel())
        {
            if (--cap <= 0) break;
            if (lossRate > 0 && rng.NextDouble() < lossRate) continue;
            var result = engine.Feed(frame);
            if (result == FeedResult.Completed) break;
            // Post-decode rejection resets the session; stop feeding so tests can assert on LastRejection.
            if (result == FeedResult.Rejected && engine.ActiveManifest is null) break;
        }
    }

    private static void FixCrc(byte[] frame)
    {
        uint crc = System.IO.Hashing.Crc32.HashToUInt32(frame.AsSpan(0, frame.Length - 4));
        System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(frame.Length - 4), crc);
    }
}
