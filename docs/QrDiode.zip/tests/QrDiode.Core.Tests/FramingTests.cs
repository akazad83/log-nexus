using QrDiode.Core.Framing;
using Xunit;

namespace QrDiode.Core.Tests;

public class FramingTests
{
    private static readonly byte[] Tag = [1, 2, 3, 4, 5, 6, 7, 8];

    [Fact]
    public void DataFrame_RoundTrips()
    {
        byte[] payload = new byte[1350];
        new Random(1).NextBytes(payload);

        byte[] frame = FrameWriter.WriteDataFrame(Tag, 0xDEADBEEF, payload);
        Assert.True(FrameParser.TryParse(frame, out var parsed, out var error));
        Assert.Equal(FrameParseError.None, error);
        Assert.Equal(FrameType.DataSymbol, parsed.Type);
        Assert.Equal(0xDEADBEEFu, parsed.SymbolId);
        Assert.True(parsed.SessionTag.SequenceEqual(Tag));
        Assert.True(parsed.Payload.SequenceEqual(payload));
    }

    [Fact]
    public void ManifestFrame_RoundTrips()
    {
        byte[] body = new byte[240];
        byte[] sig = new byte[64];
        new Random(2).NextBytes(body);
        new Random(3).NextBytes(sig);

        byte[] frame = FrameWriter.WriteManifestFrame(Tag, body, sig);
        Assert.True(FrameParser.TryParse(frame, out var parsed, out _));
        Assert.Equal(FrameType.Manifest, parsed.Type);
        Assert.True(parsed.Payload.SequenceEqual(body));
        Assert.True(parsed.Signature.SequenceEqual(sig));
    }

    [Fact]
    public void SingleBitFlip_AnywhereInFrame_IsRejected()
    {
        byte[] payload = new byte[64];
        new Random(4).NextBytes(payload);
        byte[] original = FrameWriter.WriteDataFrame(Tag, 7, payload);

        for (int byteIdx = 0; byteIdx < original.Length; byteIdx++)
        {
            byte[] tampered = (byte[])original.Clone();
            tampered[byteIdx] ^= 0x01;
            bool ok = FrameParser.TryParse(tampered, out _, out _);
            Assert.False(ok, $"Bit flip at byte {byteIdx} was not rejected.");
        }
    }

    [Theory]
    [InlineData(0)]
    [InlineData(5)]
    [InlineData(16)] // header + crc but no content
    public void TooShortFrames_AreRejected(int length)
    {
        Assert.False(FrameParser.TryParse(new byte[length], out _, out var error));
        Assert.Equal(FrameParseError.TooShort, error);
    }

    [Fact]
    public void OversizedFrame_IsRejected()
    {
        Assert.False(FrameParser.TryParse(new byte[FrameFormat.MaxFrameSize + 1], out _, out var error));
        Assert.Equal(FrameParseError.TooLong, error);
    }

    [Fact]
    public void WrongMagic_WrongVersion_WrongType_AreRejected()
    {
        byte[] frame = FrameWriter.WriteDataFrame(Tag, 1, new byte[32]);

        byte[] badMagic = (byte[])frame.Clone();
        badMagic[0] = 0x00;
        Assert.False(FrameParser.TryParse(badMagic, out _, out var e1));
        Assert.Equal(FrameParseError.BadMagic, e1);

        // Version/type live under the CRC, so corrupting them trips BadVersion/BadType only
        // if we recompute the CRC — build frames manually to exercise those paths.
        byte[] badVersion = (byte[])frame.Clone();
        badVersion[2] = 0x7F;
        FixCrc(badVersion);
        Assert.False(FrameParser.TryParse(badVersion, out _, out var e2));
        Assert.Equal(FrameParseError.BadVersion, e2);

        byte[] badType = (byte[])frame.Clone();
        badType[3] = 0x77;
        FixCrc(badType);
        Assert.False(FrameParser.TryParse(badType, out _, out var e3));
        Assert.Equal(FrameParseError.BadType, e3);
    }

    [Fact]
    public void RandomGarbage_NeverParses()
    {
        var rng = new Random(99);
        for (int i = 0; i < 10_000; i++)
        {
            byte[] garbage = new byte[rng.Next(1, 300)];
            rng.NextBytes(garbage);
            Assert.False(FrameParser.TryParse(garbage, out _, out _));
        }
    }

    private static void FixCrc(byte[] frame)
    {
        uint crc = System.IO.Hashing.Crc32.HashToUInt32(frame.AsSpan(0, frame.Length - 4));
        System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(frame.Length - 4), crc);
    }
}
