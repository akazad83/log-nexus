using Net.Codecrete.QrCodeGenerator;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;
using ZXingCpp;

namespace QrDiode.Core.Tests;

/// <summary>
/// End-to-end through the actual optical layer, minus the camera: every frame is rendered to a
/// real QR code image (Net.Codecrete), decoded back with ZXingCpp, and fed to the ReceiveEngine.
/// This proves the sender's QR generation and the receiver's decoding agree on raw byte mode.
/// </summary>
public class OpticalLoopbackTests
{
    [Fact]
    public void QrRenderDecode_SingleFrame_ByteExact()
    {
        byte[] payload = new byte[800];
        new Random(3).NextBytes(payload);

        var qr = QrCode.EncodeBinary(payload, QrCode.Ecc.Low);
        byte[] decoded = RenderAndDecode(qr);

        Assert.Equal(payload, decoded);
    }

    [Fact]
    public void SenderEncodePath_FixedVersionBinarySegment_DecodesByteExact()
    {
        // Mirrors QrDiode.Sender.Rendering.QrFrameRenderer exactly: fixed version, ECC L,
        // raw binary segment, no ECI. Confirms a 1370-byte frame fits V30-L.
        byte[] frame = new byte[1370];
        new Random(5).NextBytes(frame);

        var segments = new List<DataSegment> { DataSegment.MakeSegment(DataSegmentMode.Binary, new ArraySegment<byte>(frame)) };
        var qr = QrCode.EncodeSegments(segments, QrCode.Ecc.Low, 30, 30, false);
        Assert.Equal(30, qr.Version);

        byte[] decoded = RenderAndDecode(qr);
        Assert.Equal(frame, decoded);
    }

    [Fact]
    public void FullPipeline_ThroughRealQrCodes_Completes()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var trust = new InMemoryTrustStore();
        trust.Add(PublicKeyBundle.FromKeys("ot", sender).ToPeerKeys());
        using var receiverPeer = PublicKeyBundle.FromKeys("it", receiver).ToPeerKeys();

        byte[] payload = new byte[40_000];
        new Random(17).NextBytes(payload);

        var session = SendSession.Create(payload, "sample.bin", ContentKind.File, sender, receiverPeer,
            counter: 1, new SendOptions { MaxSymbolSize = 1000 });
        var engine = new ReceiveEngine(trust, new InMemoryReplayGuard(), receiver);

        int fed = 0;
        foreach (var frame in session.Carousel())
        {
            Assert.True(fed++ < 500, "Optical loopback did not complete within the frame budget.");
            var qr = QrCode.EncodeBinary(frame, QrCode.Ecc.Low);
            byte[] decoded = RenderAndDecode(qr);
            if (engine.Feed(decoded) == FeedResult.Completed) break;
        }

        Assert.NotNull(engine.Completed);
        Assert.Equal(payload, engine.Completed!.Plaintext);
        Assert.Equal(session.ReceiptHash, engine.Completed.ReceiptHash);
    }

    /// <summary>Rasterizes a QR to a luminance image (scale 3, quiet zone 4) and decodes it with ZXingCpp.</summary>
    private static byte[] RenderAndDecode(QrCode qr)
    {
        const int scale = 3;
        const int quiet = 4;
        int modules = qr.Size;
        int dim = (modules + quiet * 2) * scale;

        var image = new byte[dim * dim];
        Array.Fill(image, (byte)255); // white

        for (int y = 0; y < modules; y++)
        {
            for (int x = 0; x < modules; x++)
            {
                if (!qr.GetModule(x, y)) continue;
                int px = (x + quiet) * scale;
                int py = (y + quiet) * scale;
                for (int dy = 0; dy < scale; dy++)
                {
                    int rowStart = (py + dy) * dim + px;
                    for (int dx = 0; dx < scale; dx++)
                        image[rowStart + dx] = 0; // black
                }
            }
        }

        var view = new ImageView(image, dim, dim, ImageFormat.Lum);
        var options = new ReaderOptions { Formats = BarcodeFormat.QRCode, IsPure = true, TryRotate = false, TryInvert = false };
        var results = BarcodeReader.Read(view, options);

        Assert.Single(results);
        return results[0].Bytes;
    }
}
