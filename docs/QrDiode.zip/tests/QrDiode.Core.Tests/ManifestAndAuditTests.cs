using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

public class ManifestAndAuditTests
{
    private static TransferManifest MakeManifest(EphemeralEndpointKeys sender, EphemeralEndpointKeys receiver) => new()
    {
        SessionId = Guid.NewGuid(),
        TimestampUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        Counter = 42,
        SenderSigningKeyId = sender.SigningKeyId,
        ReceiverAgreementKeyId = receiver.AgreementKeyId,
        Salt = new byte[32],
        Nonce = new byte[12],
        SymbolSize = 1350,
        SourceSymbolCount = 8,
        LtSeed = 999,
        RedundancyHint = 3,
        OriginalSize = 20_000,
        CompressedSize = 10_000,
        CiphertextSize = 10_016,
        Compression = CompressionAlg.Brotli,
        CiphertextSha256 = new byte[32],
        PlaintextSha256 = new byte[32],
        ContentType = ContentKind.Xml,
        Filename = "batch-042.xml",
    };

    [Fact]
    public void Manifest_SerializeParse_RoundTrips()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        Assert.True(TransferManifest.TryParse(body, out var parsed, out var error), error);

        Assert.Equal(manifest.SessionId, parsed!.SessionId);
        Assert.Equal(manifest.Counter, parsed.Counter);
        Assert.Equal(manifest.Filename, parsed.Filename);
        Assert.Equal(manifest.SymbolSize, parsed.SymbolSize);
        Assert.Equal(manifest.SourceSymbolCount, parsed.SourceSymbolCount);
        Assert.Equal(manifest.Compression, parsed.Compression);
        Assert.Equal(manifest.ContentType, parsed.ContentType);
        Assert.Equal(manifest.CiphertextSize, parsed.CiphertextSize);
    }

    [Fact]
    public void Manifest_SignVerify_DetectsTamper()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        byte[] sig = manifest.Sign(sender.SigningKey, body);
        Assert.Equal(64, sig.Length);
        Assert.True(TransferManifest.VerifySignature(sender.SigningKey, body, sig));

        byte[] tampered = (byte[])body.Clone();
        tampered[24] ^= 0x01; // counter field
        Assert.False(TransferManifest.VerifySignature(sender.SigningKey, tampered, sig));

        using var otherKey = new EphemeralEndpointKeys();
        Assert.False(TransferManifest.VerifySignature(otherKey.SigningKey, body, sig));
    }

    [Theory]
    [InlineData(108, 0L)]                     // original size = 0
    [InlineData(108, -5L)]                    // negative size
    [InlineData(108, 200L * 1024 * 1024)]     // beyond envelope
    public void Manifest_InsaneSizes_AreRejected(int offset, long value)
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();
        System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(body.AsSpan(offset), value);

        Assert.False(TransferManifest.TryParse(body, out _, out _));
    }

    [Fact]
    public void Manifest_TruncatedOrPadded_IsRejected()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();

        Assert.False(TransferManifest.TryParse(body.AsSpan(0, body.Length - 1), out _, out _));
        Assert.False(TransferManifest.TryParse(body.Concat(new byte[1]).ToArray(), out _, out _));
        Assert.False(TransferManifest.TryParse(ReadOnlySpan<byte>.Empty, out _, out _));
    }

    [Fact]
    public void ReplayGuard_TimestampWindow_Enforced()
    {
        var clock = new FakeTimeProvider(DateTimeOffset.UtcNow);
        var guard = new InMemoryReplayGuard(clock);
        byte[] keyId = new byte[8];

        long fresh = clock.GetUtcNow().ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.Fresh, guard.Check(keyId, Guid.NewGuid(), 1, fresh));

        long stale = clock.GetUtcNow().AddDays(-3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), 1, stale));

        long future = clock.GetUtcNow().AddDays(3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), 1, future));
    }

    [Fact]
    public void AuditLog_ChainVerifies_AndDetectsTamper()
    {
        string path = Path.Combine(Path.GetTempPath(), $"qrdiode-audit-{Guid.NewGuid():N}.jsonl");
        try
        {
            var log = new AuditLog(path);
            log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "abc", ["file"] = "x.xml" });
            log.Append("transfer.rejected", new Dictionary<string, string> { ["reason"] = "replay" });
            log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "def" });

            Assert.Equal(-1, AuditLog.Verify(path)); // intact

            // Tamper with the middle record.
            var lines = File.ReadAllLines(path);
            lines[1] = lines[1].Replace("replay", "REPLAY");
            File.WriteAllLines(path, lines);

            Assert.Equal(1, AuditLog.Verify(path)); // chain broken at record 1
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void AuditLog_SurvivesReopen_ChainContinues()
    {
        string path = Path.Combine(Path.GetTempPath(), $"qrdiode-audit-{Guid.NewGuid():N}.jsonl");
        try
        {
            new AuditLog(path).Append("a", new Dictionary<string, string>());
            new AuditLog(path).Append("b", new Dictionary<string, string>()); // reopened process
            Assert.Equal(-1, AuditLog.Verify(path));
        }
        finally
        {
            File.Delete(path);
        }
    }

    private sealed class FakeTimeProvider(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }
}
