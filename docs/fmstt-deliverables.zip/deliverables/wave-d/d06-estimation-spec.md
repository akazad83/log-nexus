# Estimation Worksheet — Spec & Source of Truth
**Deliverable #6 — Wave D: Estimation & Resourcing**
**Status:** Phase 1 baseline. Companion: [d05 resource plan](d05-resource-plan-spec.md), [d05 brutal-honesty memo](d05-brutal-honesty-memo.md).
**Output:** `build/06-estimation-worksheet.xlsx` — generated from data baked into [generate_wave_d_xlsx.py](generate_wave_d_xlsx.py).

---

## 1. Purpose

Bottom-up three-point estimation, **by epic**, calibrated against the [d01 master plan](../wave-b/d01-master-plan-spec.md) WBS. The d01 WBS is the task-level skeleton; this worksheet is where epics are honestly sized, named risks are converted into bounded ranges, and confidence is reported.

This is the artifact that drives **d05 resource sizing** and the **d02 timeline narrative** ranges. Treat the numbers here as the working-level commitment; sponsor-level commitment lives in d02.

---

## 2. Method

### 2.1 What three-point estimates include
- Engineering work (design, code, code review, refactor)
- Refinement and story authoring
- Unit and integration testing
- Defect remediation against the same epic
- Telemetry and audit wiring
- Documentation updates within the epic's scope

### 2.2 What they **exclude**
- Program management overhead (governance, status reporting, risk-register maintenance) — sized as continuous overhead in [d05](d05-resource-plan-spec.md)
- Vendor liaison and procurement (DEP-01, DEP-02 etc) — sized in d05 always-on
- Ongoing security operations (SIEM tuning, baseline maintenance) — sized in d05 always-on
- Operator-organization time (operator SMEs, trainers, district leads) — see d05 §Operator hours
- Cross-Epic integration effort that doesn't belong to a single Epic — captured as separate Integration epics

### 2.3 Best / Likely / Worst
- **Best**: everything goes right; named risks do not materialize; dependencies arrive early or on time.
- **Likely**: central bet. The number you'd commit if forced.
- **Worst**: named risks materialize; dependencies slip into the worst-case window.

These are **not** equivalent to PERT (mean = (best + 4×likely + worst)/6). The team treats Likely as the planning number and uses the spread to sense-check confidence.

### 2.4 Confidence rating
- **High** — work is well-known, similar to past deliveries, clear path
- **Medium** — known shape, some unknowns, plausible path
- **Low** — material uncertainty in approach, dependencies, or domain knowledge

Low-confidence epics should be the first targets for **spike-driven de-risking** in early sprints. A program with too many Low-confidence epics is shipping a guess.

### 2.5 Person-days, not calendar days
All numbers are **person-days at the epic owner role's loading**. Calendar duration emerges from the d05 ramp curve.

### 2.6 Story-count and points-total are sanity checks, not estimates
- Story count is the BA's reasonable expectation given the epic scope.
- Points total is `story_count × avg_points_per_story` (~4 for this domain).
- Person-days approximation: `points × 1.5–2.5` depending on workstream (BE=1.8, FE=1.6, INT=2.5, DATA=2.0, SEC=2.0).
- If the bottom-up days estimate diverges by more than ~30% from the points-derived approximation, flag for review.

---

## 3. Worksheet structure

Eight sheets, in this order:

| # | Sheet | Purpose |
|---|---|---|
| 1 | `README` | How to read and edit the workbook; method summary |
| 2 | `Estimates` | Main sheet: one row per epic with three-point estimate, confidence, refs |
| 3 | `Rollups` | Pivoted sums: by phase, by category, by workstream, by confidence |
| 4 | `Method` | Estimation method; what's included/excluded; three-point definition |
| 5 | `Velocity` | Points-to-days conversion; team-velocity calibration approach |
| 6 | `Assumptions` | Mirror of d01 assumption register, plus d06-specific assumptions |
| 7 | `Risks` | Mirror of d01 risk register (read-only here; the source of truth is d01) |
| 8 | `Confidence Legend` | Definition of confidence bands |

---

## 4. Epic categories (for rollups)

| Category | Meaning |
|---|---|
| `DESIGN` | Phase 1 detailed design work — not feature delivery |
| `DELIVERY-MVP` | P2a + P2b feature delivery for the MVP scope |
| `DELIVERY-P3` | P3 incremental build feature delivery |
| `DELIVERY-OPS` | P4 + P5 + P6 — Full UAT, cutover, hypercare |

The `AO` (always-on) workstreams from d01 are **not** in d06 — they appear in d05 as continuous resource overhead. A program plan that estimates always-on work as fixed-scope epics is lying to itself.

---

## 5. Roll-up targets (sanity checks)

After the workbook is regenerated, the `Rollups` sheet should reflect:

| Category | Likely person-days | Notes |
|---|---|---|
| DESIGN | ~450–500 | P1 detailed design |
| DELIVERY-MVP | ~1300–1400 | Bumps slightly above d01 sum due to integration overhead honest pricing |
| DELIVERY-P3 | ~1300–1400 | Same — integration overhead between waves |
| DELIVERY-OPS | ~850–1000 | UAT + cutover + hypercare; deliberately conservative on hypercare |
| **Total Likely** | **~4000–4300** | vs d01 WBS direct sum (~3580); 12–20% honest delta |

The honest delta between d01 WBS task sums and d06 epic estimates is the **value** of the bottom-up estimation. If d06 came in at exactly d01 WBS sum, the BA didn't actually re-estimate — they retyped.

---

## 6. Open estimation questions (decide at Wave D review)

1. **Inclusion of operator-organization time.** Default: excluded from d06 (lives in d05). Confirm.
2. **Confidence-band granularity.** Default: 3 bands. Some PMs prefer 5. The spec stays at 3 — over-precision in confidence is theater.
3. **Should we publish PERT means as a separate column?** Default: **no.** Likely is the working number; PERT mean would create a phantom fourth estimate the team would then argue about.
4. **Re-estimation cadence.** Default: re-baseline at the end of each sprint planning cycle for the next two sprints; full re-baseline at MS-04, MS-08, MS-10, MS-13.

---

## 7. What this worksheet refuses to do

- **No "T-shirt sizes."** This program is past the point where S/M/L/XL gets us anywhere — we have phase-level commitments and named risks; that means real numbers.
- **No "buffer column."** Buffer hides in worst-case estimates honestly; a separate buffer column lets PMs lie to themselves about commitment.
- **No epic-level estimate without at least one named risk or assumption.** If you can't name something that could change the number, the number is wrong.
- **No sprint-level estimates here.** Sprint-level estimation is points; that's a refinement-cycle artifact, not a program plan artifact. They serve different audiences.
