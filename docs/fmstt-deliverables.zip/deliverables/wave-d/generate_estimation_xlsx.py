"""
generate_estimation_xlsx.py
Generates 06-estimation-worksheet.xlsx from data baked into this script.

Source-of-truth markdown: d06-estimation-spec.md
Re-run after editing data structures below.

Usage:
    python generate_estimation_xlsx.py [--output PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _xlsx_helpers import (  # noqa: E402
    BORDER_ALL,
    CATEGORY_COLORS,
    CONFIDENCE_COLORS,
    HEADER_BG,
    PHASE_COLORS,
    fill,
    freeze_top,
    set_widths,
    title_cell,
    write_headers,
    write_row,
)

# --------------------------------------------------------------------------
# Data: Estimates
# --------------------------------------------------------------------------

ESTIMATE_HEADERS = [
    "Epic ID", "Title", "Category", "Phase", "Workstreams",
    "Best (days)", "Likely (days)", "Worst (days)", "Confidence",
    "Story Count", "Points Total", "Risk Refs", "Assumption Refs",
    "WBS Refs", "Notes",
]

# (id, title, category, phase, workstreams, best, likely, worst, confidence,
#  story_count, points, risk_refs, assumption_refs, wbs_refs, notes)
ESTIMATE_ROWS = [
    # ----- DESIGN (P1) -----
    ("EPIC-D-01", "Wave A foundations + bounded-context detailed design",                "DESIGN", "P1", "ARCH,SEC,DATA",       50,  80, 130, "High",   12, 50, "R-001,R-004",      "A-007",       "P1.01,P1.02,P1.03,P1.06", "Wave A delivered; ratification + bounded-context detailed design"),
    ("EPIC-D-02", "Backlog engineering pipeline + templates",                            "DESIGN", "P1", "BA",                  15,  25,  40, "High",    8, 30, "",                 "",            "P1.05",                    "Wave C deliverable"),
    ("EPIC-D-03", "Operator UX co-design workshops",                                     "DESIGN", "P1", "CHG,BA",              25,  40,  70, "Low",    10, 35, "R-002,R-008",      "A-005",       "P1.07",                    "Per district, per workflow step"),
    ("EPIC-D-04", "SCADA integration contract spec + XA21 trace recording",              "DESIGN", "P1", "INT,ARCH",            20,  40,  80, "Low",     8, 28, "R-003,R-012",      "A-004",       "P1.08,P1.09",              "Vendor-driven for trace recording"),
    ("EPIC-D-05", "4GL hidden business rules walk-through",                              "DESIGN", "P1", "BA",                  30,  60, 120, "Low",    15, 50, "R-001",            "",            "P1.15",                    "Hidden cost; explicitly funded"),
    ("EPIC-D-06", "Wave D estimation + Wave E engineering specs + Wave F catalog",       "DESIGN", "P1", "PM,ARCH,DATA,DEVOPS,QA", 70, 100, 150, "Medium", 20, 60, "",              "A-002",       "P1.10,P1.11,P1.12,P1.13,P1.14,P1.21", ""),
    ("EPIC-D-07", "NERC CIP impact rating + ESP/EAP design ratification",                "DESIGN", "P1", "SEC,ARCH",            20,  40,  80, "Medium",  6, 24, "R-004",            "A-007",       "P1.04",                    "First 30 days"),
    ("EPIC-D-08", "Pre-prod infra dependency readiness (CA, PAM, SIEM)",                 "DESIGN", "P1", "SEC,DEVOPS",          28,  47,  95, "Medium", 10, 36, "R-009",            "A-009",       "P1.16,P1.17,P1.18",         "DEP-02/03/04 path"),
    ("EPIC-D-09", "Reference-data sync mechanism design",                                "DESIGN", "P1", "INT,ARCH",             8,  12,  20, "Medium",  5, 16, "R-011",            "",            "P1.19",                    "Asset Mgmt source-of-truth"),
    ("EPIC-D-10", "Detailed Design Gate (MS-04) + change-mgmt comms baseline",           "DESIGN", "P1", "PM,CHG",               7,  11,  20, "High",    4, 12, "R-008",            "",            "P1.20,P1.22",              ""),

    # ----- DELIVERY-MVP (P2a + P2b) -----
    ("EPIC-M-01", "Switching Card module — full 8-step workflow (transmission MVP)",     "DELIVERY-MVP", "P2a", "BE,FE",         180, 270, 410, "Medium", 60, 240, "R-001",          "A-004",       "P2a.04,P2a.05,P2a.06,P2a.07,P2a.08,P2a.17", "MVP spine"),
    ("EPIC-M-02", "Tagging & Clearance state machine + UI",                              "DELIVERY-MVP", "P2a", "BE,FE",          60,  90, 140, "Medium", 20,  80, "R-001",          "",            "P2a.09,P2a.10",            ""),
    ("EPIC-M-03", "Authorization module + UI",                                           "DELIVERY-MVP", "P2a", "BE,FE",          50,  70, 110, "Medium", 18,  65, "",               "",            "P2a.11,P2a.12",            ""),
    ("EPIC-M-04", "Field Coordination + Rapid Restore handoff (DMZ adapter + module)",   "DELIVERY-MVP", "P2a", "BE,INT",         50,  75, 120, "Low",    15,  60, "R-003",          "",            "P2a.13,P2a.14",            ""),
    ("EPIC-M-05", "Audit module — full audit stream wired across MVP workflow",          "DELIVERY-MVP", "P2a", "BE,DATA",        50,  75, 120, "Medium", 15,  60, "R-007",          "",            "P2a.15,P2a.18",            "Ledger + chain hash; NFR-07 carrier"),
    ("EPIC-M-06", "SCADA/XA21 DMZ wrapper — read + write paths",                         "DELIVERY-MVP", "P2a", "INT,SEC",       110, 170, 280, "Low",    22, 100, "R-003,R-012",    "A-004",       "P2a.02,P2a.03",            "Highest-leverage MVP epic"),
    ("EPIC-M-07", "Reference Data sync from Asset Mgmt (initial + delta)",               "DELIVERY-MVP", "P2a", "BE,INT",         25,  35,  60, "Medium",  8,  30, "R-011",          "",            "P2a.16",                   ""),
    ("EPIC-M-08", "SQL schema baseline + AG sync replica + DMZ async replica",           "DELIVERY-MVP", "P2a", "DATA,DEVOPS",    60,  95, 160, "Medium", 12,  50, "R-005,R-006",    "A-006",       "P2a.18,P2a.19,P2a.20",      ""),
    ("EPIC-M-09", "mTLS + cert lifecycle + SIEM (CIP-007 R4) wiring",                    "DELIVERY-MVP", "P2a", "SEC,DEVOPS",     50,  75, 130, "Medium", 12,  45, "R-004,R-009",    "A-007,A-009", "P2a.21,P2a.22",             ""),
    ("EPIC-M-10", "Sprint 0 + environments + CI/CD baseline",                            "DELIVERY-MVP", "P2a", "DEVOPS,SEC",     40,  60, 110, "Medium", 12,  50, "R-009",          "A-009",       "P2a.01",                    "Foundation for all P2a work"),
    ("EPIC-M-11", "Storm test scenario + execution + tuning (MS-06)",                    "DELIVERY-MVP", "P2a", "QA,INT",         50,  80, 140, "Low",    12,  50, "R-003,R-005,R-007", "",         "P2a.23,P2a.24",             "Critical milestone"),
    ("EPIC-M-12", "Performance baseline + Operator UAT prep",                            "DELIVERY-MVP", "P2a", "QA",             30,  45,  75, "Medium",  8,  30, "",               "",            "P2a.25,P2a.26",             ""),
    ("EPIC-M-13", "NERC CIP rehearsal in pre-prod (MS-07)",                              "DELIVERY-MVP", "P2a", "SEC,QA",         15,  25,  50, "Medium",  5,  15, "R-004",          "A-007",       "P2a.27",                    ""),
    ("EPIC-M-14", "MVP UAT cycles 1-3 + defect remediation",                             "DELIVERY-MVP", "P2b", "CHG,BE,FE",     100, 150, 250, "Low",    30, 120, "R-002,R-008",    "A-005",       "P2b.01,P2b.02,P2b.03,P2b.04,P2b.05", "Most leveraged phase"),
    ("EPIC-M-15", "MVP storm rerun + CIP audit walkthrough + Operator Approval Gate",    "DELIVERY-MVP", "P2b", "QA,SEC,PM",      15,  30,  60, "High",    5,  20, "R-008",          "A-005",       "P2b.06,P2b.07,P2b.08",      "MS-08 — CRITICAL gate"),

    # ----- DELIVERY-P3 (Incremental Build) -----
    ("EPIC-P3-01", "Distribution workflow end-to-end (Wave 1)",                          "DELIVERY-P3", "P3", "ARCH,BE,FE",      80, 130, 200, "Medium", 30, 120, "R-001",          "",            "P3.W1",                     "First post-MVP wave"),
    ("EPIC-P3-02", "Dielectric workflow end-to-end (Wave 2 part 1)",                     "DELIVERY-P3", "P3", "ARCH,BE,FE",      40,  65, 100, "Medium", 15,  60, "R-001",          "",            "P3.W2 (half)",              ""),
    ("EPIC-P3-03", "Steam workflow end-to-end (Wave 2 part 2)",                          "DELIVERY-P3", "P3", "ARCH,BE,FE",      40,  65, 100, "Medium", 15,  60, "R-001",          "",            "P3.W2 (half)",              ""),
    ("EPIC-P3-04", "Monitor apps batch 1 (10–15 apps, Wave 3a)",                         "DELIVERY-P3", "P3", "BE,FE,INT",      130, 200, 290, "Low",    60, 200, "R-001",          "",            "P3.W3a",                    "Hidden-rules risk concentration"),
    ("EPIC-P3-05", "Monitor apps batch 2 (10–15 apps, Wave 3b)",                         "DELIVERY-P3", "P3", "BE,FE,INT",      130, 200, 290, "Low",    60, 200, "R-001",          "",            "P3.W3b",                    "MS-09 at end"),
    ("EPIC-P3-06", "Integration coverage — GIS/WMS/Notification (Wave 4)",               "DELIVERY-P3", "P3", "INT,BE",          65, 100, 160, "Medium", 25,  90, "R-011",          "",            "P3.W4",                     ""),
    ("EPIC-P3-07", "CorpNET reporting tier (Wave 5)",                                    "DELIVERY-P3", "P3", "FE,BE,DATA",      55,  90, 140, "Medium", 20,  75, "",               "",            "P3.W5",                     ""),
    ("EPIC-P3-08", "Data-migration cutover-rehearsal scripts (Wave 6)",                  "DELIVERY-P3", "P3", "DATA,QA",         55,  90, 160, "Low",    20,  75, "R-006",          "A-006",       "P3.W6",                     ""),
    ("EPIC-P3-09", "Per-wave UAT cycles (rolling)",                                      "DELIVERY-P3", "P3", "CHG,QA",          90, 140, 220, "Medium", 35, 130, "R-002",          "A-005",       "P3.U1",                     ""),
    ("EPIC-P3-10", "Per-wave defect remediation (rolling)",                              "DELIVERY-P3", "P3", "BE,FE",           90, 140, 220, "Medium", 30, 120, "",               "",            "P3.D1",                     ""),
    ("EPIC-P3-11", "Per-wave NERC CIP control verification",                             "DELIVERY-P3", "P3", "SEC",             35,  55,  95, "Medium", 12,  45, "R-004",          "A-007",       "P3.S1",                     ""),
    ("EPIC-P3-12", "Operator training rolling rollout",                                  "DELIVERY-P3", "P3", "CHG",             45,  70, 120, "Medium", 15,  55, "R-002,R-008",    "A-005",       "P3.M1",                     ""),

    # ----- DELIVERY-OPS (P4 + P5 + P6) -----
    ("EPIC-OPS-01", "End-to-end integration UAT + defect remediation",                   "DELIVERY-OPS", "P4", "QA,CHG,BE,FE",    70, 120, 200, "Medium", 25, 100, "R-011",          "",            "P4.01",                    "MS-10"),
    ("EPIC-OPS-02", "DR drill + 72h soak + NERC CIP pre-cutover audit",                  "DELIVERY-OPS", "P4", "DEVOPS,QA,SEC",   40,  60, 100, "Medium", 12,  45, "R-005",          "A-007",       "P4.02,P4.03,P4.04",         ""),
    ("EPIC-OPS-03", "Cutover playbook dry-runs #1 + #2 (with rollback)",                 "DELIVERY-OPS", "P4", "PM,QA,DEVOPS",    25,  50,  90, "Medium", 10,  35, "R-010",          "A-008",       "P4.05,P4.06",               "MS-11"),
    ("EPIC-OPS-04", "District-by-district cutover execution (4 districts)",              "DELIVERY-OPS", "P5", "PM,CHG,QA,DATA", 200, 320, 540, "Low",    40, 200, "R-010,R-012",    "A-008",       "P5.D1P,P5.D1C,P5.D2P,P5.D2C,P5.D3P,P5.D3C,P5.D4P,P5.D4C", "MS-12, MS-13"),
    ("EPIC-OPS-05", "Final reconciliation + Ingres legacy decommissioning gate (MS-14)", "DELIVERY-OPS", "P5", "DATA,SEC",        25,  40,  75, "Medium",  8,  30, "R-006",          "",            "P5.LR,P5.LD",               ""),
    ("EPIC-OPS-06", "24/7 hypercare desk + defect remediation sprints",                  "DELIVERY-OPS", "P6", "PM,BE,FE",       150, 220, 350, "Medium", 50, 200, "",               "",            "P6.01,P6.02",               "Defect-rate-driven"),
    ("EPIC-OPS-07", "Knowledge transfer to ops team + ops metrics review",               "DELIVERY-OPS", "P6", "CHG,PM",          50,  80, 130, "Medium", 18,  70, "R-002",          "A-005",       "P6.03,P6.04",               ""),
    ("EPIC-OPS-08", "Program close gate (MS-15)",                                        "DELIVERY-OPS", "P6", "PM",               5,   8,  15, "High",    3,  10, "",               "",            "P6.05",                     ""),
]

# --------------------------------------------------------------------------
# Data: Method
# --------------------------------------------------------------------------

METHOD_PAIRS = [
    ("Method", "Three-point estimation per Epic"),
    ("Best", "Everything goes right; named risks do not materialize"),
    ("Likely", "Central bet — the planning number"),
    ("Worst", "Named risks materialize"),
    ("Unit", "Person-days at the owner-role's loading"),
    ("Calendar", "Calendar duration emerges from d05 ramp curve"),
    ("PERT mean published?", "No — Likely is the working number; PERT mean would create a phantom number"),
    ("",""),
    ("Included in estimates", "Engineering, refinement, code review, testing, defect remediation, telemetry/audit wiring, story-scoped documentation"),
    ("Excluded from estimates", "Program management (sized in d05), vendor liaison (sized in d05), ongoing security ops (sized in d05), operator-org time (operator org's budget)"),
    ("",""),
    ("Re-estimation cadence", "Per-sprint for upcoming 2 sprints; full re-baseline at MS-04, MS-08, MS-10, MS-13"),
    ("Confidence rating", "3 bands: High / Medium / Low (over-precision in confidence is theater)"),
]

# --------------------------------------------------------------------------
# Data: Velocity
# --------------------------------------------------------------------------

VELOCITY_HEADERS = ["Workstream", "Days per point (Best)", "Days per point (Likely)", "Days per point (Worst)", "Notes"]
VELOCITY_ROWS = [
    ("BE",     1.2, 1.8, 2.6, "Standard .NET work; well-understood domain"),
    ("FE",     1.0, 1.6, 2.4, "Angular work; well-understood domain"),
    ("DATA",   1.4, 2.0, 2.8, "Schema + migration; reconciliation overhead"),
    ("INT",    1.8, 2.5, 3.6, "OT integration; vendor-dependent"),
    ("SEC",    1.4, 2.0, 3.0, "NERC CIP control verification adds overhead"),
    ("DEVOPS", 1.2, 1.8, 2.6, "Pipeline + infra"),
    ("QA",     1.2, 1.8, 2.6, "Test automation; storm/perf adds overhead"),
    ("BA",     1.0, 1.5, 2.2, "Backlog authoring; 4GL walk is heavier"),
    ("CHG",    1.2, 1.8, 2.6, "Operator engagement; non-linear"),
    ("ARCH",   1.6, 2.2, 3.0, "Cross-cutting design; review cycles"),
    ("PM",     0.8, 1.2, 1.6, "Coordination; sprint cadence"),
]

# --------------------------------------------------------------------------
# Data: Confidence Legend
# --------------------------------------------------------------------------

CONFIDENCE_HEADERS = ["Band", "Definition", "Color"]
CONFIDENCE_ROWS = [
    ("High",   "Work is well-known, similar to past deliveries, clear path",         "green"),
    ("Medium", "Known shape, some unknowns, plausible path",                          "yellow"),
    ("Low",    "Material uncertainty in approach, dependencies, or domain knowledge", "red"),
]

# --------------------------------------------------------------------------
# Data: Assumptions and Risks (mirrored from d01 — read-only)
# --------------------------------------------------------------------------

ASSUMPTION_HEADERS = ["Assumption ID", "Assumption", "Source"]
ASSUMPTION_ROWS = [
    ("A-001", "Team: ~8–12 blended squad with named skill mix; 70% onshore",                                              "User default 2026-04-28"),
    ("A-002", "Budget: $15–25M total program, capped T&M, ±15% sponsor tolerance",                                         "User default 2026-04-28"),
    ("A-003", "Phase 1 Detailed Design 4–6 mo; MVP build+UAT 6–9 mo; full cutover 24–30 mo from T0",                       "User default 2026-04-28"),
    ("A-004", "XA21 frozen for the modernization window; legacy SOAP wrapped at DMZ only",                                 "User default 2026-04-28"),
    ("A-005", "4 ops × 2 districts × 8 hrs/wk in P1, scaling to 16 hrs/wk in MVP UAT, with shift-coverage backfill funded","User default 2026-04-28"),
    ("A-006", "~25–50K cards/yr, ~50–200 audit events/card, 300–800 GB live + 2–4 TB archive, 7-yr online retention",      "User default 2026-04-28"),
    ("A-007", "Core BCS = Medium Impact; CIP-005/007/010/011/013 in scope",                                                 "User default 2026-04-28"),
    ("A-008", "Phased district-by-district cutover with 4–6 wk per-district parallel run; 8-wk enterprise cap",            "User default 2026-04-28"),
    ("A-009", "Existing utility-standard reverse proxy/WAF, internal CA, PAM tooling, SIEM available",                     "Wave A architecture default"),
    ("A-010", "On-prem AD authoritative for OpNET; Entra ID for CorpNET; one-way attribute sync exists",                    "Wave A architecture default"),
    ("A-D-01","Per-workstream points-to-days conversion is calibrated from past delivery; revise after sprint 4",          "d06 Velocity sheet"),
    ("A-D-02","Bottom-up Likely sum can exceed d01 WBS task sum by 12–20% due to integration overhead pricing",            "d06 Method"),
]

RISK_HEADERS = ["Risk ID", "Title", "Score"]
RISK_ROWS = [
    ("R-001", "Hidden business rules embedded in OpenRoad 4GL code", 9),
    ("R-002", "Operator SME availability shortfall against committed hours", 9),
    ("R-003", "SCADA/XA21 wrapper protocol fidelity defects under load", 6),
    ("R-004", "NERC CIP impact rating debate delays P1 gate", 6),
    ("R-005", "AG sync replica IPSec performance regression", 4),
    ("R-006", "Ingres → SQL Server semantic-loss surprises during reconciliation", 6),
    ("R-007", "Ledger Audit write overhead exceeds budget under storm load", 4),
    ("R-008", "Operator change-management resistance erodes MVP approval", 6),
    ("R-009", "Internal CA / mTLS tooling vendor delay blocks pre-prod", 4),
    ("R-010", "Per-district parallel-run defect rate blows the 8-week enterprise cap", 9),
    ("R-011", "Reference-data drift from Asset Mgmt corrupts switching decisions", 6),
    ("R-012", "XA21 vendor change calendar conflicts with cutover window", 3),
]

# --------------------------------------------------------------------------
# Sheet builders
# --------------------------------------------------------------------------

def build_readme(wb: Workbook):
    ws = wb.create_sheet("README")
    set_widths(ws, [26, 110])
    title_cell(ws, 1, 1, "Estimation Worksheet — d06", span=2)
    pairs = [
        ("Wave", "D — Estimation & Resourcing"),
        ("Source of truth", "d06-estimation-spec.md"),
        ("Generated by", "generate_estimation_xlsx.py"),
        ("Companion", "d05-resource-plan.xlsx, d05-brutal-honesty-memo.docx"),
        ("", ""),
        ("How to read", ""),
        ("Estimates", "One row per Epic with three-point estimate; the working source"),
        ("Rollups", "Pivoted sums by phase, category, workstream, confidence"),
        ("Method", "What's included/excluded; three-point definition"),
        ("Velocity", "Points-to-days conversion baseline per workstream"),
        ("Assumptions / Risks", "Mirror of d01; read-only here"),
        ("Confidence Legend", "3 bands"),
    ]
    for i, (k, v) in enumerate(pairs, start=3):
        a = ws.cell(row=i, column=1, value=k); a.alignment = Alignment(vertical="top", wrap_text=True)
        b = ws.cell(row=i, column=2, value=v); b.alignment = Alignment(vertical="top", wrap_text=True)
        if k in ("How to read",):
            a.font = Font(bold=True, size=12, color=HEADER_BG)
        elif k:
            a.font = Font(bold=True)


def build_estimates(wb: Workbook):
    ws = wb.create_sheet("Estimates")
    write_headers(ws, ESTIMATE_HEADERS)
    for i, row in enumerate(ESTIMATE_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        cat = row[2]
        phase = row[3]
        conf = row[8]
        ws.cell(row=i, column=3).fill = fill(CATEGORY_COLORS.get(cat, "FFFFFF"))
        ws.cell(row=i, column=4).fill = fill(PHASE_COLORS.get(phase, "FFFFFF"))
        ws.cell(row=i, column=9).fill = fill(CONFIDENCE_COLORS.get(conf, "FFFFFF"))
        ws.row_dimensions[i].height = 38
    set_widths(ws, [12, 56, 16, 6, 24, 8, 8, 8, 11, 11, 11, 18, 18, 28, 36])
    freeze_top(ws, "C2")
    ws.auto_filter.ref = ws.dimensions


def build_rollups(wb: Workbook):
    ws = wb.create_sheet("Rollups")
    title_cell(ws, 1, 1, "Roll-ups", span=5)

    # Helper: aggregate
    def agg(key_idx):
        out = {}
        for r in ESTIMATE_ROWS:
            key = r[key_idx]
            if key not in out:
                out[key] = [0, 0, 0, 0]  # best, likely, worst, count
            out[key][0] += r[5]
            out[key][1] += r[6]
            out[key][2] += r[7]
            out[key][3] += 1
        return out

    sections = [
        ("By Phase",       agg(3), PHASE_COLORS),
        ("By Category",    agg(2), CATEGORY_COLORS),
        ("By Confidence",  agg(8), CONFIDENCE_COLORS),
    ]

    row = 3
    for title, data, color_map in sections:
        ws.cell(row=row, column=1, value=title).font = Font(bold=True, size=13, color=HEADER_BG)
        row += 1
        write_headers(ws, ["Key", "Epics", "Best (days)", "Likely (days)", "Worst (days)"], row=row)
        row += 1
        sorted_keys = sorted(data.keys())
        for k in sorted_keys:
            best, likely, worst, count = data[k]
            cells = [k, count, best, likely, worst]
            write_row(ws, row, cells)
            ws.cell(row=row, column=1).fill = fill(color_map.get(k, "FFFFFF"))
            row += 1
        # Total row
        tot_best = sum(d[0] for d in data.values())
        tot_likely = sum(d[1] for d in data.values())
        tot_worst = sum(d[2] for d in data.values())
        tot_count = sum(d[3] for d in data.values())
        write_row(ws, row, ["TOTAL", tot_count, tot_best, tot_likely, tot_worst])
        for c in range(1, 6):
            ws.cell(row=row, column=c).font = Font(bold=True)
            ws.cell(row=row, column=c).fill = fill("D9E1F2")
        row += 2

    # By workstream — need to split comma-separated workstreams
    ws.cell(row=row, column=1, value="By Workstream (epic counted in each)").font = Font(bold=True, size=13, color=HEADER_BG)
    row += 1
    write_headers(ws, ["Workstream", "Epics (touched)", "Best (days, attributed evenly)", "Likely (days, attributed evenly)", "Worst (days, attributed evenly)"], row=row)
    row += 1
    ws_agg = {}
    for r in ESTIMATE_ROWS:
        wss = [w.strip() for w in r[4].split(",") if w.strip()]
        if not wss:
            continue
        share = 1.0 / len(wss)
        for w in wss:
            if w not in ws_agg:
                ws_agg[w] = [0.0, 0.0, 0.0, 0]
            ws_agg[w][0] += r[5] * share
            ws_agg[w][1] += r[6] * share
            ws_agg[w][2] += r[7] * share
            ws_agg[w][3] += 1
    for k in sorted(ws_agg.keys()):
        best, likely, worst, count = ws_agg[k]
        write_row(ws, row, [k, count, round(best, 1), round(likely, 1), round(worst, 1)])
        row += 1

    set_widths(ws, [22, 14, 18, 18, 18])


def build_method(wb: Workbook):
    ws = wb.create_sheet("Method")
    set_widths(ws, [30, 100])
    title_cell(ws, 1, 1, "Estimation Method", span=2)
    for i, (k, v) in enumerate(METHOD_PAIRS, start=3):
        a = ws.cell(row=i, column=1, value=k); a.alignment = Alignment(vertical="top", wrap_text=True)
        b = ws.cell(row=i, column=2, value=v); b.alignment = Alignment(vertical="top", wrap_text=True)
        if k:
            a.font = Font(bold=True)


def build_velocity(wb: Workbook):
    ws = wb.create_sheet("Velocity")
    write_headers(ws, VELOCITY_HEADERS)
    for i, row in enumerate(VELOCITY_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        ws.row_dimensions[i].height = 24
    set_widths(ws, [14, 22, 22, 22, 60])
    freeze_top(ws)


def build_confidence(wb: Workbook):
    ws = wb.create_sheet("Confidence Legend")
    write_headers(ws, CONFIDENCE_HEADERS)
    for i, row in enumerate(CONFIDENCE_ROWS, start=2):
        write_row(ws, i, row)
        ws.cell(row=i, column=1).fill = fill(CONFIDENCE_COLORS.get(row[0], "FFFFFF"))
        ws.row_dimensions[i].height = 22
    set_widths(ws, [12, 80, 12])


def build_assumptions(wb: Workbook):
    ws = wb.create_sheet("Assumptions")
    write_headers(ws, ASSUMPTION_HEADERS)
    for i, row in enumerate(ASSUMPTION_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        ws.row_dimensions[i].height = 32
    set_widths(ws, [12, 90, 28])
    freeze_top(ws)


def build_risks(wb: Workbook):
    ws = wb.create_sheet("Risks")
    write_headers(ws, RISK_HEADERS)
    score_colors = {9: "FFC7CE", 6: "FFD9B3", 4: "FFEB9C", 3: "FFFFCC", 1: "C6EFCE"}
    for i, row in enumerate(RISK_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        ws.cell(row=i, column=3).fill = fill(score_colors.get(row[2], "FFFFFF"))
        ws.cell(row=i, column=3).font = Font(bold=True)
        ws.cell(row=i, column=3).alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[i].height = 22
    set_widths(ws, [10, 80, 8])
    freeze_top(ws)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default=str(HERE / "build" / "06-estimation-worksheet.xlsx"),
    )
    args = parser.parse_args()

    wb = Workbook()
    wb.remove(wb.active)

    build_readme(wb)
    build_estimates(wb)
    build_rollups(wb)
    build_method(wb)
    build_velocity(wb)
    build_confidence(wb)
    build_assumptions(wb)
    build_risks(wb)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes; {len(wb.sheetnames)} sheets)")


if __name__ == "__main__":
    main()
