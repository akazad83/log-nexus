"""
generate_resource_plan_xlsx.py
Generates 05-resource-plan.xlsx from data baked into this script.

Source-of-truth markdown: d05-resource-plan-spec.md
Companion: d05-brutal-honesty-memo.docx (rendered separately)

Usage:
    python generate_resource_plan_xlsx.py [--output PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _xlsx_helpers import (  # noqa: E402
    BORDER_ALL,
    HEADER_BG,
    PHASE_COLORS,
    fill,
    freeze_top,
    set_widths,
    title_cell,
    write_headers,
    write_row,
)

# --------------------------------------------------------------------------
# Phase durations (likely months) and loaded rates (placeholders)
# --------------------------------------------------------------------------

PHASE_MONTHS = {"P1": 5.0, "P2a": 7.5, "P2b": 2.5, "P3": 9.0, "P4": 3.0, "P5": 3.5, "P6": 4.0}
PHASE_ORDER = ["P1", "P2a", "P2b", "P3", "P4", "P5", "P6"]

RATE_ONSHORE = 22000   # USD per FTE per month — PLACEHOLDER
RATE_OFFSHORE = 10000  # USD per FTE per month — PLACEHOLDER
ONSHORE_DEFAULT_SHARE = 0.70

# --------------------------------------------------------------------------
# Roles
# --------------------------------------------------------------------------

ROLE_HEADERS = ["Code", "Role", "Mode", "Onshore default", "Notes"]

# (code, role, mode, onshore_default, notes, fully_onshore_only)
ROLES = [
    ("SP",   "Sponsor",                       "Executive",   "Onshore",       "Fractional; gate sign-off",                          True),
    ("PD",   "Program Director",              "Lead",        "Onshore",       "PM/SM dual function; full-time",                     True),
    ("SM",   "Scrum Master",                  "Lead",        "Onshore",       "Sprint discipline; DoR/DoD gating",                  True),
    ("SA",   "Solution Architect",            "Lead",        "Onshore",       "Cross-cutting tech authority — KEY PERSON",          True),
    ("TLB",  "Tech Lead — Backend",           "Lead+IC",     "Onshore",       "Owns hot path — KEY PERSON",                         True),
    ("BED",  "Backend Developer",             "IC",          "Mixed (70/30)", ".NET",                                                False),
    ("TLF",  "Tech Lead — Frontend",          "Lead+IC",     "Onshore",       "Owns operator UX fidelity",                          True),
    ("FED",  "Frontend Developer",            "IC",          "Mixed (70/30)", "Angular",                                             False),
    ("DBA",  "DBA Lead",                      "Lead+IC",     "Onshore",       "Schema, AG, migration — KEY PERSON",                 True),
    ("DBE",  "DBA Engineer",                  "IC",          "Mixed",         "Migration scripts, partitioning",                    False),
    ("INTL", "Integration Lead",              "Lead",        "Onshore",       "XA21 vendor liaison — CRITICAL KEY PERSON",          True),
    ("INTE", "Integration Engineer",          "IC",          "Mixed",         "DMZ adapters",                                        False),
    ("CIPL", "CIP Compliance Lead",           "Lead",        "Onshore",       "NERC CIP — CRITICAL KEY PERSON",                     True),
    ("SEE",  "Security Engineer",             "IC",          "Onshore",       "mTLS, SIEM, baseline",                               True),
    ("DOL",  "DevOps Lead",                   "Lead",        "Onshore",       "CI/CD, environments",                                 True),
    ("DOE",  "DevOps Engineer",               "IC",          "Mixed",         "Pipelines, infra-as-code",                           False),
    ("TL",   "Test Lead",                     "Lead+IC",     "Onshore",       "Strategy; storm/perf",                               True),
    ("QAE",  "QA Engineer",                   "IC",          "Mixed",         "Test automation",                                     False),
    ("BAL",  "BA Lead",                       "Lead+IC",     "Onshore",       "Backlog engineering, 4GL walk — KEY PERSON",         True),
    ("BAA",  "BA / Domain Analyst",           "IC",          "Mixed",         "Story authoring",                                     False),
    ("CHL",  "Change Lead",                   "Lead",        "Onshore",       "Operator engagement, training",                       True),
    ("TR",   "Trainer (operator)",            "IC",          "Onshore",       "Hands-on training delivery",                          True),
    ("OSL",  "Operator SME Lead",             "(operator org)", "Onshore",   "Senior district operator — CRITICAL (operator org)", True),
]

# --------------------------------------------------------------------------
# Phase ramp (FTE per role per phase)
# --------------------------------------------------------------------------

# Order of phases: P1, P2a, P2b, P3, P4, P5, P6
RAMP = {
    "SP":   (0.1, 0.1, 0.2, 0.1, 0.2, 0.3, 0.1),
    "PD":   (1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.7),
    "SM":   (0.5, 1.0, 1.0, 1.0, 0.7, 0.5, 0.3),
    "SA":   (1.0, 1.0, 0.7, 0.5, 0.5, 0.5, 0.2),
    "TLB":  (0.5, 1.0, 1.0, 1.0, 0.7, 0.5, 0.5),
    "BED":  (0.5, 4.0, 3.0, 4.0, 1.0, 0.5, 1.0),
    "TLF":  (0.5, 1.0, 1.0, 1.0, 0.7, 0.3, 0.3),
    "FED":  (0.0, 2.0, 1.5, 2.5, 0.5, 0.0, 0.5),
    "DBA":  (0.7, 1.0, 0.5, 0.7, 0.5, 0.7, 0.3),
    "DBE":  (0.0, 1.0, 0.5, 0.7, 0.3, 0.5, 0.0),
    "INTL": (0.7, 0.7, 0.5, 0.5, 0.3, 0.3, 0.2),
    "INTE": (0.0, 1.5, 1.0, 1.5, 0.3, 0.3, 0.2),
    "CIPL": (0.5, 0.5, 0.5, 0.4, 0.5, 0.7, 0.3),
    "SEE":  (0.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.2),
    "DOL":  (0.5, 0.5, 0.4, 0.4, 0.5, 0.5, 0.3),
    "DOE":  (0.5, 1.0, 0.5, 0.7, 0.5, 0.7, 0.3),
    "TL":   (0.5, 1.0, 1.0, 0.7, 1.0, 0.7, 0.3),
    "QAE":  (0.0, 2.0, 2.5, 2.0, 1.5, 1.0, 0.5),
    "BAL":  (1.0, 1.0, 0.7, 0.5, 0.3, 0.2, 0.0),
    "BAA":  (1.0, 1.5, 1.0, 1.0, 0.3, 0.2, 0.0),
    "CHL":  (0.5, 0.5, 0.7, 0.5, 0.5, 0.7, 0.5),
    "TR":   (0.0, 0.0, 0.5, 0.5, 0.3, 1.0, 0.5),
    "OSL":  (0.2, 0.2, 0.4, 0.2, 0.3, 0.5, 0.2),  # operator org — informational only
}

# --------------------------------------------------------------------------
# Skills matrix
# --------------------------------------------------------------------------

SKILLS = [
    ".NET 8/9", "Angular LTS", "SQL Server EE", "Ingres/OpenRoad",
    "SCADA/OT", "NERC CIP", "AD/Kerberos/mTLS", "Azure DevOps/GitHub",
    "IIS / on-prem ops", "OpenTel/SIEM", "Test automation",
    "BPMN/workflow", "Utility ops domain", "Change mgmt OT",
]

# Per-role skills marking; tuple aligned with SKILLS
def _sk(*marks):
    assert len(marks) == len(SKILLS), f"expected {len(SKILLS)} marks, got {len(marks)}"
    return marks

SKILL_MARKS = {
    "SP":   _sk("—","—","—","—","—","—","—","—","—","—","—","—","W","—"),
    "PD":   _sk("W","W","W","—","W","W","W","W","W","W","W","W","S","S"),
    "SM":   _sk("W","W","—","—","—","—","—","W","—","—","W","W","—","W"),
    "SA":   _sk("R","R","R","S","R","R","R","S","R","R","S","S","S","W"),
    "TLB":  _sk("R","W","R","W","W","W","S","S","S","S","S","W","W","—"),
    "BED":  _sk("R","W","S","—","—","—","S","S","W","W","S","W","—","—"),
    "TLF":  _sk("W","R","W","—","—","—","W","S","W","W","S","W","W","—"),
    "FED":  _sk("—","R","—","—","—","—","—","S","—","W","S","W","—","—"),
    "DBA":  _sk("W","—","R","S","—","S","S","W","W","S","W","—","W","—"),
    "DBE":  _sk("—","—","R","W","—","W","W","W","W","W","W","—","—","—"),
    "INTL": _sk("S","—","W","W","R","S","S","W","W","W","S","S","S","—"),
    "INTE": _sk("R","—","W","—","S","W","S","S","W","W","S","S","W","—"),
    "CIPL": _sk("W","—","W","—","W","R","S","W","W","S","W","—","W","S"),
    "SEE":  _sk("W","—","W","—","W","S","R","S","S","S","W","—","—","—"),
    "DOL":  _sk("S","W","W","—","—","S","S","R","R","S","S","—","—","—"),
    "DOE":  _sk("W","W","W","—","—","W","W","R","R","S","W","—","—","—"),
    "TL":   _sk("S","S","W","—","W","S","W","S","W","S","R","S","S","S"),
    "QAE":  _sk("W","W","—","—","—","W","—","S","—","W","R","W","W","—"),
    "BAL":  _sk("—","—","W","S","W","S","—","W","—","W","W","R","R","S"),
    "BAA":  _sk("—","—","—","W","W","W","—","W","—","—","W","S","S","W"),
    "CHL":  _sk("—","—","—","—","W","W","—","—","—","—","—","S","S","R"),
    "TR":   _sk("—","—","—","—","—","W","—","—","—","—","—","W","S","R"),
    "OSL":  _sk("—","—","—","—","S","W","—","—","—","—","—","S","R","S"),
}

SKILL_COLORS = {
    "R": ("1F4E78", "FFFFFF"),
    "S": ("4472C4", "FFFFFF"),
    "W": ("D9E1F2", "404040"),
    "—": ("FFFFFF", "BFBFBF"),
}

# --------------------------------------------------------------------------
# Key-person risk
# --------------------------------------------------------------------------

KEY_PERSON_HEADERS = ["Role", "Why key", "Mitigation", "Trigger event"]
KEY_PERSON_ROWS = [
    ("Solution Architect",
     "Cross-cutting authority over .NET + Angular + SCADA + NERC CIP boundary; rare combo",
     "Document architectural decisions in d07/d09/d10; pair with TLB on key reviews; 2-week vacation buffer",
     "SA out >5 days unexpectedly"),
    ("Integration Lead",
     "XA21 vendor relationship; OT integration depth",
     "Cross-train Integration Engineer; quarterly vendor re-engagement",
     "INTL out >3 days during P2a–P2b"),
    ("CIP Compliance Lead",
     "Walks the CIP Senior Manager and external auditors; relationship-driven",
     "Cross-train Security Engineer; document walkthrough scripts",
     "CIPL out within 2 weeks of MS-07 or MS-13"),
    ("BA Lead",
     "Reads OpenRoad 4GL; owns hidden-rules walk-through (P1.15)",
     "Recruit second 4GL-fluent BA Analyst; checkpoint walk findings weekly",
     "BAL out >5 days during P1.15"),
    ("Operator SME Lead (operator org)",
     "District trust; UAT sign-off; cannot be substituted by program",
     "Operator org names a backup SME at program start; backup attends every other UAT cycle",
     "OSL unavailable or rotated by operator org"),
    ("DBA Lead",
     "Ingres knowledge bonus; AG + temporal + ledger experience",
     "Cross-train DBA Engineer on Ingres; document migration decisions per-table",
     "DBA out during reconciliation pass (P5.LR)"),
    ("Tech Lead — Backend",
     "Hot path quality; storm-test analysis",
     "Pair with Solution Architect; cross-train senior BED",
     "TLB out during MS-06 storm test prep"),
]

# --------------------------------------------------------------------------
# Onshore / offshore mix
# --------------------------------------------------------------------------

ONSHORE_HEADERS = ["Role", "Default mix", "Reasoning"]
ONSHORE_ROWS = [
    ("Sponsor",                       "Onshore-only", "Executive presence; cannot offshore"),
    ("Program Director",              "Onshore-only", "Stakeholder presence; cannot offshore"),
    ("Scrum Master",                  "Onshore-only", "Sprint cadence with onshore team and operator demos"),
    ("Solution Architect",            "Onshore-only", "Operator demos; CIP walkthroughs; vendor reviews"),
    ("Tech Lead — Backend",           "Onshore-preferred", "Operator demos; can have offshore backup"),
    ("Backend Developer",             "70/30 mixed", "Build-and-test against AC; mixable"),
    ("Tech Lead — Frontend",          "Onshore-preferred", "Operator UX co-design; can have offshore backup"),
    ("Frontend Developer",            "70/30 mixed", "Build-and-test against AC; mixable"),
    ("DBA Lead",                      "Onshore-only", "Migration walk-throughs; reconciliation sign-off"),
    ("DBA Engineer",                  "Mixed", "Scripts and partitioning; mixable"),
    ("Integration Lead",              "Onshore-only", "XA21 vendor relationship requires onshore presence"),
    ("Integration Engineer",          "Mixed", "Adapter implementation; mixable"),
    ("CIP Compliance Lead",           "Onshore-only", "Auditor relationship; CIP walkthroughs require onshore presence"),
    ("Security Engineer",             "Onshore-only", "ESP/SIEM tuning with on-prem infra"),
    ("DevOps Lead",                   "Onshore-only", "On-prem IIS; CIP-010 baseline ownership"),
    ("DevOps Engineer",               "Mixed", "Pipeline and infra; mixable"),
    ("Test Lead",                     "Onshore-only", "Storm/perf with onshore team; UAT facilitation"),
    ("QA Engineer",                   "Mixed", "Test automation; mixable"),
    ("BA Lead",                       "Onshore-only", "Operator co-design; 4GL walk; cannot offshore"),
    ("BA / Domain Analyst",           "Mixed", "Story authoring; mixable for non-co-design work"),
    ("Change Lead",                   "Onshore-only", "Operator engagement requires onshore presence"),
    ("Trainer (operator)",            "Onshore-only", "Hands-on training requires onshore presence"),
    ("Operator SME Lead (operator org)", "Onshore-only", "Operator-org employee"),
]

# --------------------------------------------------------------------------
# Operator-org hours (separate budget, demand on operator org)
# --------------------------------------------------------------------------

OPERATOR_HEADERS = ["Phase", "Operator hrs/wk per pilot district", "# districts engaged", "Total operator hrs/wk"]
OPERATOR_ROWS = [
    ("P1",   8,  2, 16),
    ("P2a",  10, 2, 20),
    ("P2b",  16, 2, 32),
    ("P3",   10, 4, 40),
    ("P4",   12, 4, 48),
    ("P5",   20, 4, 80),
    ("P6",   6,  4, 24),
]

# --------------------------------------------------------------------------
# Sheet builders
# --------------------------------------------------------------------------

def build_readme(wb: Workbook):
    ws = wb.create_sheet("README")
    set_widths(ws, [26, 110])
    title_cell(ws, 1, 1, "Resource Plan — d05", span=2)
    pairs = [
        ("Wave", "D — Estimation & Resourcing"),
        ("Source of truth", "d05-resource-plan-spec.md"),
        ("Generated by", "generate_resource_plan_xlsx.py"),
        ("Companion docs", "d05-brutal-honesty-memo.docx, d06-estimation-worksheet.xlsx"),
        ("", ""),
        ("How to read", ""),
        ("Roles", "23 roles; Mode = Lead / IC / Lead+IC / Executive"),
        ("Phase Ramp", "FTE per role per phase. Column totals = squad size by phase"),
        ("Skills Matrix", "Required (R) / Strong (S) / Working (W) / Not applicable (—)"),
        ("Key-Person Risk", "Critical roles + mitigation + trigger events"),
        ("Onshore/Offshore", "Per-role default mix and reasoning"),
        ("Operator Org Hours", "Demand on operator org — NOT a program-paid cost"),
        ("Cost Sketch", "PLACEHOLDER rates; replaced by program finance before any commitment"),
    ]
    for i, (k, v) in enumerate(pairs, start=3):
        a = ws.cell(row=i, column=1, value=k); a.alignment = Alignment(vertical="top", wrap_text=True)
        b = ws.cell(row=i, column=2, value=v); b.alignment = Alignment(vertical="top", wrap_text=True)
        if k == "How to read":
            a.font = Font(bold=True, size=12, color=HEADER_BG)
        elif k:
            a.font = Font(bold=True)


def build_roles(wb: Workbook):
    ws = wb.create_sheet("Roles")
    write_headers(ws, ROLE_HEADERS)
    for i, row in enumerate(ROLES, start=2):
        write_row(ws, i, row[:5], wrap=True)
        if "CRITICAL" in row[4]:
            ws.cell(row=i, column=5).fill = fill("FFC7CE")
        elif "KEY PERSON" in row[4]:
            ws.cell(row=i, column=5).fill = fill("FFEB9C")
        ws.row_dimensions[i].height = 22
    set_widths(ws, [10, 32, 14, 18, 60])
    freeze_top(ws)


def build_phase_ramp(wb: Workbook):
    ws = wb.create_sheet("Phase Ramp")
    headers = ["Code", "Role"] + PHASE_ORDER + ["Person-months"]
    write_headers(ws, headers)
    program_pm = 0.0
    for i, role in enumerate(ROLES, start=2):
        code = role[0]
        ramp = RAMP[code]
        row = [code, role[1]] + list(ramp)
        person_months = sum(f * PHASE_MONTHS[p] for f, p in zip(ramp, PHASE_ORDER))
        if code != "OSL":
            program_pm += person_months
        row.append(round(person_months, 1))
        write_row(ws, i, row)
        ws.row_dimensions[i].height = 22
        # color phase columns
        for j, p in enumerate(PHASE_ORDER):
            ws.cell(row=i, column=3 + j).fill = fill(PHASE_COLORS.get(p, "FFFFFF"))
            ws.cell(row=i, column=3 + j).alignment = Alignment(horizontal="center")

    # Totals row
    total_row_idx = len(ROLES) + 2
    totals = ["TOTAL", "Squad size (excl OSL)"]
    for p in PHASE_ORDER:
        s = sum(RAMP[r[0]][PHASE_ORDER.index(p)] for r in ROLES if r[0] != "OSL")
        totals.append(round(s, 1))
    totals.append(round(program_pm, 1))
    write_row(ws, total_row_idx, totals)
    for c in range(1, len(totals) + 1):
        ws.cell(row=total_row_idx, column=c).font = Font(bold=True)
        ws.cell(row=total_row_idx, column=c).fill = fill("D9E1F2")

    # Months row at bottom
    months_row_idx = total_row_idx + 1
    months_row = ["", "Phase duration (months, likely)"] + [PHASE_MONTHS[p] for p in PHASE_ORDER] + [""]
    write_row(ws, months_row_idx, months_row)
    for c in range(1, len(months_row) + 1):
        ws.cell(row=months_row_idx, column=c).font = Font(italic=True)

    widths = [10, 32] + [9] * len(PHASE_ORDER) + [16]
    set_widths(ws, widths)
    freeze_top(ws, "C2")


def build_skills_matrix(wb: Workbook):
    ws = wb.create_sheet("Skills Matrix")
    headers = ["Code", "Role"] + SKILLS
    write_headers(ws, headers)
    for i, role in enumerate(ROLES, start=2):
        code = role[0]
        marks = SKILL_MARKS[code]
        row = [code, role[1]] + list(marks)
        write_row(ws, i, row)
        for j, m in enumerate(marks):
            cell = ws.cell(row=i, column=3 + j)
            bg, fg = SKILL_COLORS[m]
            cell.fill = fill(bg)
            cell.font = Font(color=fg, bold=(m == "R"))
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[i].height = 22

    # Legend below
    base = len(ROLES) + 4
    ws.cell(row=base, column=1, value="Legend").font = Font(bold=True, size=12, color=HEADER_BG)
    legend = [
        ("R", "Required"),
        ("S", "Strong (preferred for senior holders)"),
        ("W", "Working knowledge (helpful, not essential)"),
        ("—", "Not applicable"),
    ]
    for k, (mark, desc) in enumerate(legend):
        c1 = ws.cell(row=base + 1 + k, column=1, value=mark)
        bg, fg = SKILL_COLORS[mark]
        c1.fill = fill(bg)
        c1.font = Font(color=fg, bold=True)
        c1.alignment = Alignment(horizontal="center")
        ws.cell(row=base + 1 + k, column=2, value=desc)

    widths = [10, 32] + [14] * len(SKILLS)
    set_widths(ws, widths)
    freeze_top(ws, "C2")


def build_key_person(wb: Workbook):
    ws = wb.create_sheet("Key-Person Risk")
    write_headers(ws, KEY_PERSON_HEADERS)
    for i, row in enumerate(KEY_PERSON_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        if "CRITICAL" in row[1] or "operator org" in row[1] or "auditor" in row[1].lower():
            ws.cell(row=i, column=1).fill = fill("FFC7CE")
        else:
            ws.cell(row=i, column=1).fill = fill("FFEB9C")
        ws.row_dimensions[i].height = 50
    set_widths(ws, [28, 60, 60, 32])
    freeze_top(ws)


def build_onshore(wb: Workbook):
    ws = wb.create_sheet("Onshore-Offshore Mix")
    write_headers(ws, ONSHORE_HEADERS)
    for i, row in enumerate(ONSHORE_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        if row[1] == "Onshore-only":
            ws.cell(row=i, column=2).fill = fill("E2EFDA")
        elif "Mixed" in row[1]:
            ws.cell(row=i, column=2).fill = fill("FFF2CC")
        ws.row_dimensions[i].height = 28
    set_widths(ws, [32, 22, 80])
    freeze_top(ws)


def build_operator_hours(wb: Workbook):
    ws = wb.create_sheet("Operator Org Hours")
    write_headers(ws, OPERATOR_HEADERS)
    for i, row in enumerate(OPERATOR_ROWS, start=2):
        write_row(ws, i, row)
        ws.cell(row=i, column=1).fill = fill(PHASE_COLORS.get(row[0], "FFFFFF"))
        ws.row_dimensions[i].height = 24

    base = len(OPERATOR_ROWS) + 4
    ws.cell(row=base, column=1, value="Note").font = Font(bold=True, size=12, color=HEADER_BG)
    note = ("These hours are a DEMAND on the operator organization, not a program cost. "
            "They are real only if shift-coverage backfill is funded by the operator org (DEP-07 in d01). "
            "Brutal-honesty memo §3.1 names this as the single biggest swing factor in the entire program.")
    nc = ws.cell(row=base + 1, column=1, value=note)
    ws.merge_cells(start_row=base + 1, start_column=1, end_row=base + 1, end_column=4)
    nc.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[base + 1].height = 60

    set_widths(ws, [10, 36, 22, 22])
    freeze_top(ws)


def build_cost_sketch(wb: Workbook):
    ws = wb.create_sheet("Cost Sketch")
    title_cell(ws, 1, 1, "Cost Sketch — placeholder rates; NOT BUDGET", span=5)

    # Show the rate parameters
    ws.cell(row=3, column=1, value="Parameters (PLACEHOLDER)").font = Font(bold=True, size=12, color=HEADER_BG)
    params = [
        ("Onshore loaded rate (USD/FTE/month)",   RATE_ONSHORE),
        ("Offshore loaded rate (USD/FTE/month)",  RATE_OFFSHORE),
        ("Onshore default share",                  ONSHORE_DEFAULT_SHARE),
    ]
    for i, (k, v) in enumerate(params, start=4):
        ws.cell(row=i, column=1, value=k)
        ws.cell(row=i, column=2, value=v)
        ws.cell(row=i, column=1).font = Font(bold=True)

    headers_row = len(params) + 5
    write_headers(ws, ["Phase", "Months", "Squad FTE (excl OSL)", "Indicative cost (USD)", "Cumulative (USD)"], row=headers_row)

    cum = 0
    onshore_only_codes = {r[0] for r in ROLES if r[5]}
    for i, p in enumerate(PHASE_ORDER, start=headers_row + 1):
        squad_fte = sum(RAMP[r[0]][PHASE_ORDER.index(p)] for r in ROLES if r[0] != "OSL")
        # Cost = sum across roles of (FTE × months × loaded_rate)
        phase_cost = 0
        for role in ROLES:
            code = role[0]
            if code == "OSL":
                continue
            fte = RAMP[code][PHASE_ORDER.index(p)]
            months = PHASE_MONTHS[p]
            if code in onshore_only_codes:
                rate = RATE_ONSHORE
            else:
                rate = ONSHORE_DEFAULT_SHARE * RATE_ONSHORE + (1 - ONSHORE_DEFAULT_SHARE) * RATE_OFFSHORE
            phase_cost += fte * months * rate
        cum += phase_cost
        write_row(ws, i, [p, PHASE_MONTHS[p], round(squad_fte, 1), round(phase_cost), round(cum)])
        ws.cell(row=i, column=1).fill = fill(PHASE_COLORS.get(p, "FFFFFF"))

    # Total row
    total_row = headers_row + len(PHASE_ORDER) + 1
    write_row(ws, total_row, ["TOTAL", round(sum(PHASE_MONTHS.values()), 1), "", round(cum), ""])
    for c in range(1, 6):
        ws.cell(row=total_row, column=c).font = Font(bold=True)
        ws.cell(row=total_row, column=c).fill = fill("D9E1F2")

    # Caveat
    base = total_row + 3
    ws.cell(row=base, column=1, value="Caveat").font = Font(bold=True, size=12, color="C00000")
    caveat = ("This sketch uses placeholder loaded rates. Replace RATE_ONSHORE and RATE_OFFSHORE in "
              "generate_resource_plan_xlsx.py with the program-finance-supplied actuals before "
              "publishing any number to the sponsor or to procurement. The cost sketch is calibration, "
              "not commitment.")
    cc = ws.cell(row=base + 1, column=1, value=caveat)
    ws.merge_cells(start_row=base + 1, start_column=1, end_row=base + 1, end_column=5)
    cc.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[base + 1].height = 60

    set_widths(ws, [16, 12, 22, 22, 22])


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default=str(HERE / "build" / "05-resource-plan.xlsx"),
    )
    args = parser.parse_args()

    wb = Workbook()
    wb.remove(wb.active)

    build_readme(wb)
    build_roles(wb)
    build_phase_ramp(wb)
    build_skills_matrix(wb)
    build_key_person(wb)
    build_onshore(wb)
    build_operator_hours(wb)
    build_cost_sketch(wb)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes; {len(wb.sheetnames)} sheets)")


if __name__ == "__main__":
    main()
