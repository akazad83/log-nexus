"""
generate_brutal_honesty_memo_docx.py
Renders d05-brutal-honesty-memo.md to docx using the shared deliverables/_md2docx.py.

Usage:
    python generate_brutal_honesty_memo_docx.py [--input PATH] [--output PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _md2docx import render_file  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input",  default=str(HERE / "d05-brutal-honesty-memo.md"))
    parser.add_argument("--output", default=str(HERE / "build" / "05-brutal-honesty-memo.docx"))
    args = parser.parse_args()

    inp = Path(args.input)
    out = Path(args.output)
    render_file(inp, out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
