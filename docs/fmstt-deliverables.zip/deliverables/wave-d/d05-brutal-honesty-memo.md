# Resource Plan — Brutal-Honesty Memo
**Deliverable #5 (companion) — Wave D: Estimation & Resourcing**
**Status:** Phase 1 baseline. Companion to [d05 resource plan workbook](d05-resource-plan-spec.md) and [d06 estimation worksheet](d06-estimation-spec.md).
**Output:** `build/05-brutal-honesty-memo.docx` (rendered from this markdown).

---

## 1. Audience and tone

This memo is for the **Sponsor**, the **Program Director**, and the **operator-org leadership** who will commit operator-SME time. It is deliberately blunter than the workbook because workbooks read as commitments; this memo is the conversation that should happen before commitments are made.

If you only read one section, read **§3 — Where the estimates are most likely wrong**.

---

## 2. What the resource plan is, and what it isn't

The [d05 resource plan workbook](d05-resource-plan-spec.md) names ~23 roles, a phase ramp totaling ~546 person-months, and a cost sketch using placeholder loaded rates. The [d06 estimation worksheet](d06-estimation-spec.md) names ~45 epics totaling ~4,000–4,300 likely person-days of feature delivery.

**The plan is a defensible baseline, not a forecast.** It tells you the shape of what the program will need, calibrated against the ratified defaults (project memory, 2026-04-28). It does not tell you the schedule will hold. Schedules in regulated OT modernization don't hold without active management; they require explicit re-baselining at every gate.

---

## 3. Where the estimates are most likely wrong

Ranked by leverage on cost and schedule.

### 3.1 Operator SME availability vs. committed hours
**Most likely failure mode in the entire plan.**

The plan assumes operators deliver 8 hrs/wk in P1, 16 hrs/wk in P2b UAT, and 20 hrs/wk per district during P5 cutover. These hours are paper unless **shift-coverage backfill is funded** (DEP-07 in d01) by the operator organization.

**What "wrong" looks like:** operators show up to UAT cycle 1 having read the materials in the parking lot. Defects logged are surface-level. Cycle 2 finds the deeper issues that cycle 1 should have. Cycle 3 becomes mandatory; P2b extends 4–6 weeks; MS-08 slips; sponsor visibility rises sharply.

**Cost when it goes wrong:** ~+4 to +6 weeks at P2b plus ~+4 to +8 weeks at P5 → **8 to 14 weeks added to MS-13**, and the program close goes from 2029-02-15 likely to 2029-05-15 likely.

**Early signal:** sprint 4 demo attendance by operator SMEs falls below the 2-per-district baseline.
**Action when triggered:** escalate to Sponsor and operator-org leadership immediately. Stop sprint demos until backfill is funded; do not proceed on the fiction that hours will materialize next sprint.

### 3.2 Integration Lead loading during MVP
Plan: 0.7 FTE through P2a-P2b. **Almost certainly insufficient.**

The XA21 wrapper is the single highest-risk integration. Storm-test failures (R-003) typically surface in week 8–12 of P2a and require immediate, deep, full-attention response from the Integration Lead. Routine work continues regardless. 0.7 FTE absorbs ~1 week of crisis before backlogging everything else.

**Cost when it goes wrong:** wrapper defect remediation extends 2–4 weeks; storm-test re-runs (R-007) extend another 1–2 weeks; **MS-06 slips 3–6 weeks**, and MS-08 follows.

**Early signal:** Integration Lead's sprint commitments slip by ≥30% in any single sprint between sprint 6 and sprint 12 of P2a.
**Action when triggered:** add a second Integration Engineer onshore for the duration of P2a. Do not try to "catch up" with offshore; XA21 work needs vendor-phone-call latency.

### 3.3 BA Lead loading on the 4GL hidden-rules walk
Plan: P1.15 likely 60 person-days, worst 120. The 60-day baseline is **optimistic for a code base that has 20+ years of accreted patches**.

**What "wrong" looks like:** the BA finishes the first pass at 60 days having identified 60% of the embedded business rules. The other 40% surface during P2a as story rework, P2b UAT defects, and worst-case as P3 monitor-app defects. Each surprise is a 1–3-day rework spike across the affected stories.

**Cost when it goes wrong:** 30–60 additional person-days of rework in P2a/P3, distributed across owners — roughly **+2 to +4 weeks at MS-08**.

**Early signal:** during P1.15, the BA reports the rate of new-rule discovery is not slowing by week 6. (You expect a logarithmic curve; if it's still linear, you haven't found the bottom.)
**Action when triggered:** extend P1.15 to 120 days from the start, and add a second BA Analyst with OpenRoad-fluency. Don't ration this: the cheapest day to find a hidden rule is in P1.

### 3.4 CIP Compliance Lead in P5
Plan: 0.7 FTE during cutover. **Light.**

Cutover is when CIP-005 R1 (ESP boundary), CIP-007 R1/R3/R4 (ports/anti-malware/event monitoring), CIP-010 R1 (baseline configuration), and CIP-013 R1 (supply chain) all matter at once, with auditor visibility. The CIP Compliance Lead is the program's relationship to the CIP Senior Manager and to external auditors. 0.7 FTE means they are time-sharing with P3 verification work that is still rolling in.

**Cost when it goes wrong:** a single CIP finding during a cutover dry-run forces a 2–4-week remediation pass. **MS-11 slips, then MS-12, then MS-13 by 4–8 weeks.**

**Early signal:** any auditor-visible question that the CIP Lead can't answer in <24h; or a CIP-001 R1 baseline drift identified during dry-run.
**Action when triggered:** raise CIPL to 1.0 FTE for P5 and pull in fractional second CIP-fluent reviewer. The cost of the role is dwarfed by the cost of the slip.

### 3.5 Hypercare staffing assumes a defect rate we have not yet observed
Plan: P6 hypercare runs 4 months at 7 FTE.

The defect rate during hypercare drives both the duration and the staffing. The plan assumes defect rates fall off cleanly at week 4–6 post-final-cutover. **This is observed in healthy programs and not observed in unhealthy ones.** We don't know which we are until we are in P6.

**Cost when it goes wrong:** if defect rate is 2x planned, hypercare extends 4–6 additional weeks at the same staffing level (defects don't fix faster with more people; they fix faster with the *right* people). **Program close moves from 2029-02-15 to 2029-04-30 or later.**

**Early signal:** week-2 P6 defect intake exceeds week-1 by more than 20%. The intake should fall, not rise.
**Action when triggered:** extend P6 by an additional 4–8 weeks at current staffing. **Do not add headcount beyond a single experienced engineer per affected workstream** — onboarding cost in hypercare exceeds throughput gain.

---

## 4. Where the plan is robust

It's worth naming the parts that hold up to scrutiny:

- **Backend developer headcount in P3 is appropriately slack** to absorb 4GL surprises mid-incremental-build. We won't run thin on capacity here even if §3.3 materializes.
- **DevOps loading is correctly heavy in P2a sprint 0** and intentionally lighter in P3. Once the pipeline is built, it does not need a constant 1.0 FTE.
- **DBA loading in P5 is appropriately heavy** for cutover-rehearsal scripts and the final reconciliation pass. We are not under-investing in the data-integrity check at the most regulated moment.
- **Test Lead ramp into P2b is correctly aggressive** — 1.0 FTE through UAT is right; this is one of the few places where leaning *more* than the data suggests is justified by the criticality of MS-08.
- **The 23-role breakdown is honest** about the difference between Lead and IC capacity. Programs that conflate these always under-staff ICs and overload Leads.

---

## 5. What signals trigger a full plan re-baseline

These are explicit triggers for the Program Director to convene a full re-plan, not "monitor and adjust":

| Trigger | Re-baseline scope |
|---|---|
| CIP Senior Manager rules **High Impact** for the in-scope BCS | Whole program; +20–35% delivery cost |
| CIP Senior Manager rules **Low Impact** | Whole program; -10–15% cost reduction available |
| Sprint 4 velocity below 70% of planned | P2a duration estimate |
| Sprint 8: SCADA wrapper still failing storm test | P2a duration estimate; INTL staffing |
| MVP UAT cycle 1 returns >100 medium-or-major defects | P2b duration; possibly MVP scope reduction |
| District 1 cutover defects >25 medium or any P1 | P5 cadence; per-district parallel-run window |
| CIP Compliance Lead departs unexpectedly | Whole program; CIP-related milestones at risk |
| Operator SME Lead replaced by operator org without warning | P2b and P5 staffing; possibly milestone slip |
| Sponsor budget envelope reduced > 10% | Scope reduction conversation, not just compression |

These are written so the Program Director can defend re-planning as policy rather than reactivity. **The cheapest plan-update is the one done immediately when a trigger fires; the most expensive is the one done at the next quarterly review when actuals have already drifted.**

---

## 6. The numbers a sponsor briefing should use

If you brief the sponsor with the numbers in d05 + d06, anchor them with these caveats:

- **Headline:** ~546 person-months of program staffing; ~4,000–4,300 likely person-days of feature delivery (the rest is leadership, governance, ramp, slack, and overhead — this 2.6× ratio is normal).
- **Cost basis:** with the deliberately-conservative placeholder rates in the workbook ($22k/FTE/month onshore, $10k/FTE/month offshore), the cost sketch totals to roughly **$11.8M** at central-case staffing. Actual utility-grade loaded rates for regulated OT modernization are typically 30–50% higher, which lands the central case at **~$15–18M**, inside the A-002 envelope of $15–25M. **Program finance must replace the placeholder rates with actuals** before any number is committed to the sponsor or to procurement.
- **The number least likely to hold:** P6 hypercare staffing duration. The number most likely to hold: P1 design effort.
- **The single biggest ask of the operator organization:** the shift-coverage backfill (DEP-07). If you only get one operator-org commitment in writing, get this one.

---

## 7. What this memo refuses to say

- **No "right-sizing" recommendation in advance.** Re-baselining without a triggered signal is a tax on focus.
- **No staffing reduction recommendation to fit a tighter envelope.** If the budget envelope shrinks, the conversation is *scope* (which features survive MVP), not staffing density. Reducing headcount on a fixed scope to hit a budget always extends the schedule by more than the cost saving.
- **No headcount addition recommendation to compress.** Adding people to compress is the most reliably-failed move in regulated OT modernization. If MS-08 needs to move, it moves; you don't pull it in by adding bodies.
- **No assumption that tools (AI assistants, code generators) materially change these numbers.** They might over a 30-month program. They also might not. The plan does not bet on it; if it pays off, that's a positive variance.

---

## 8. Restated, in three sentences

**The plan stands behind the central estimates.** Where it is most likely to be wrong is named in §3, ranked by leverage. The single most leveraged thing the Sponsor and the operator organization can do *now* — before any code is written — is fund the shift-coverage backfill so the operator-SME hours in d05 §8 are real and not paper.
