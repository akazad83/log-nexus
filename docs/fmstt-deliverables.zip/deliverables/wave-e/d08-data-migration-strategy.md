# Data Migration Strategy
**Deliverable #8 — Wave E: Engineering & Operations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave E review gate.
**Cross-refs:** [d09 — Database Design Principles](../wave-a/d09-database-design-principles.md) · [d10 — Network & Boundary Design](../wave-a/d10-network-boundary-design.md) · [d11 — Test Strategy + Cutover Playbook Outline](d11-test-strategy.md)
**Output:** this `.md` is canonical; `build/08-data-migration-strategy.docx` is the rendered governance copy.

---

## 1. Purpose

Defines how data moves from **Actian Ingres (legacy)** to **SQL Server 2025 EE (target)** with **zero unplanned outage**, **full audit-trail continuity**, and **operator-acceptable parallel-run mechanics**. This is the most regulatorily-sensitive workstream after the SCADA boundary; it is not an ETL project.

Reads d09 §8 as the type-mapping baseline. Reads d11 for reconciliation testing. Owned by the **DBA Lead** with sign-off from **Data Owner**, **CIP Compliance Lead**, and **Operator SME Lead** at every gate.

This strategy is **opinionated** about what won't work on a regulated OT migration:
- "Big-bang" Ingres-to-SQL cutover — wrong; we go district-by-district (A-008).
- "ETL tool magic" (e.g., off-the-shelf migration vendor solving everything) — wrong; the 4GL business-rule embeddedness means you own the transformation logic in your code, not in vendor mappings.
- "Just freeze writes for the cutover weekend" — operationally unacceptable; switching does not pause.

---

## 2. Migration phases

| Phase | Name | Purpose | Owner | Gate |
|---|---|---|---|---|
| MZ-1 | Schema baseline | Build target schema from d09 principles; validate against representative source tables | DBA Lead | DBA Lead approval per schema |
| MZ-2 | Initial bulk load | One-time full extract from Ingres → target staging, then load → target | DBA Lead | Reconciliation pass per table (§5) |
| MZ-3 | Delta sync mechanism | Periodic delta extraction Ingres → target (Source CDC where supported, else change-table polling) | DBA Lead | RPO target met; drift alerts wired |
| MZ-4 | Reconciliation tooling | Per-table row count + hash + sampled deep-equality, daily during parallel run | DBA Lead | Tooling produces clean pass on synthetic divergence test |
| MZ-5 | Parallel run (per district) | Both systems write; reconciliation runs daily; new system shadow → primary | Program Director + Operator SME Lead | 7 consecutive days clean reconciliation per district |
| MZ-6 | District cutover | Switch operators to new system as primary; legacy continues as shadow for 24-48h | Program Director | Per-district cutover gate (MS-12) |
| MZ-7 | Final reconciliation + decommission | After all districts cut over, full reconciliation; legacy frozen; archive snapshot | DBA Lead + Sponsor | MS-14 |

---

## 3. What migration tooling DOES and DOES NOT do

### 3.1 Does
- Move table data from Ingres → SQL Server with documented type mapping (per d09 §8.2).
- Validate row counts, hashes, and deep-equality sampling.
- Maintain delta-sync mechanism during parallel run.
- Produce reconciliation reports for sign-off.
- Emit audit events for every migration action (CIP-007 R4).

### 3.2 Does not
- **Extract embedded business logic from OpenRoad 4GL code.** That is the BA Lead's P1.15 walk-through workstream, not data migration. Logic is reimplemented in the modular monolith.
- **Decide the type mapping.** That is in d09 §8.2 and is per-column-reviewed by the DBA Lead.
- **Recreate Ingres history-table semantics.** Existing history rows migrate into the new temporal tables' `_History` shadow with synthetic version transitions; subsequent history is system-managed.
- **Move SCADA real-time state.** XA21 is untouched; switching state from XA21 flows through the DMZ wrapper, not through migration.
- **Migrate operator credentials.** AD identities flow from existing on-prem AD; no credential migration needed.

---

## 4. ETL architecture

### 4.1 Data flow (high-level)

```
Ingres (source)
  │  ODBC pull, scheduled
  ▼
Migration host (OpNET, .NET 8/9 console worker)
  │  Validate types, transform per d09 §8.2 rules, hash
  ▼
SQL Server 2025 staging schema (target DB)
  │  Reconciliation runs against staging
  ▼
SQL Server target schemas (per bounded context)
  │  Audit event 'DataMigrated' emitted for every batch
  ▼
Audit.AuditEvent (with ledger chain hash continuity)
```

### 4.2 Tooling choices

| Concern | Choice | Rationale |
|---|---|---|
| Source pull | .NET 8/9 + Ingres ODBC driver | Custom over off-the-shelf; lets us own the transformation logic, audit emission, and CIP-controlled boundary. SSIS rejected — too opaque for CIP-013 supply-chain review and harder to instrument for audit. |
| Target load | SQL Server bulk insert (`SqlBulkCopy`) into staging, then transactional move into target | Bulk insert is fastest into staging; transactional move keeps target clean if a batch fails |
| Orchestration | SQL Agent for scheduled jobs + .NET console worker for transformations | Standard utility-team tooling; CIP-010 baseline well-understood |
| Reconciliation | Custom .NET tool; reports to a `Migration.ReconciliationRun` table | Auditable; deterministic; testable in CI |
| CDC on source | Use Ingres native CDC if supported; else periodic delta extraction with a `LastModifiedAt` column (where present) or full-table delta where it isn't | Ingres CDC support is version-dependent; confirm in MZ-1 |
| CDC on target | Native SQL Server CDC (after MZ-2) for downstream consumers | Standard |

### 4.3 What runs in OpNET vs DMZ

The migration tooling runs **inside OpNET only**. It pulls from the Ingres source (also OpNET) and writes to SQL Server (OpNET primary). The async replica in the DMZ is **read-only and is fed by AG**, not by migration tooling — migration writes never cross the EAP.

This is non-negotiable: cross-EAP migration paths violate d10 §3.2 ("OpNET-pulls-only").

---

## 5. Reconciliation methodology

Three-tier verification per migrated table. **All three must pass before the table is approved for parallel-run.**

### 5.1 Tier 1 — Row-count match (exact)
```
SELECT COUNT(*) FROM source_table  ==  SELECT COUNT(*) FROM target_table
```
Any non-zero difference is a fail. No tolerance.

### 5.2 Tier 2 — Hash check on business columns (exact)
- Define a deterministic projection of business columns per table (e.g., for `SwitchingCard`: `(card_id, district_id, state, created_at, last_modified_at)`).
- Compute SHA-256 over rows ordered by surrogate key.
- Source hash and target hash must match exactly.
- **Excluded from hash:** surrogate keys (mapped, not preserved), audit timestamps if regenerated, computed columns.

### 5.3 Tier 3 — Sampled deep-equality (configurable %)
- Sample N% of rows (default 5%, configurable up to 100% for high-risk tables).
- Random uniform sample by stratified `district_id`.
- For each sampled row, compare every migrated column.
- Any mismatch is logged with row identifier and column.
- Fail threshold: any single mismatch on tier 3 → tier 1+2 must be re-run; if tier 1+2 still pass, the deep-equality mismatch is a defect in the migration code.

### 5.4 Sign-off chain per table
1. DBA Lead approves the table's type mapping (one-time, per d09 §8.2).
2. DBA Lead approves the migration script for the table (per script).
3. **Data Owner** signs off on tier 1+2+3 results.
4. **CIP Compliance Lead** signs off if the table contains BCSI (per CIP-011 R1).
5. **Operator SME Lead** signs off if the table backs an operator-visible screen.

Per-table sign-off is captured in a `Migration.SignOff` table with timestamp, role, and approver name. This is the audit trail.

---

## 6. Parallel-run strategy

### 6.1 Mechanics
Per A-008 (ratified default): **4–6 weeks per district** of dual-running, with 8-week enterprise-wide cap on dual-entry.

```
Per-district timeline
══════════════════════
Week 0-1: Shadow mode
  - New system: read-only; pulls from delta sync
  - Operators continue on legacy
  - Reconciliation runs daily
  - Defects logged but not blocking

Week 1-3: Dual-write mode
  - Both systems accept writes
  - Operators have access to both screens (their choice which to use)
  - Reconciliation runs daily
  - Discrepancies investigated within 24h
  - Operator-SME daily check-in

Week 3-4 (or 5-6): Primary-on-new mode
  - New system is primary; legacy continues to receive a mirrored write stream
  - Operators trained to use new system
  - Reconciliation continues
  - Cutover gate (MS-12) reviewed at end of week 3
```

### 6.2 What "dual-write" actually means
The operator decides at the screen level which system records their action. The other system receives the same action via reconciliation feedback loop:

- Operator submits De-energize on new system → recorded in target → reconciliation tooling within 60 seconds writes to legacy via Ingres ODBC.
- Operator submits De-energize on legacy → recorded in source → next delta sync within 5 minutes writes to target.

This requires **idempotent inserts on both sides** keyed on the same business identifier (the card-step-action tuple). Idempotency is a hard requirement; without it, reconciliation produces duplicates.

### 6.3 Discrepancy handling
- **Immediate alert:** any reconciliation mismatch during dual-write is a SIEM alert + operator-screen banner.
- **Investigation SLA:** ≤4h during business hours, ≤24h overnight.
- **Resolution path:** DBA + Tech Lead — Backend joint debug; root-cause in target; legacy is treated as ground truth during parallel run.
- **Threshold for cutover delay:** more than 3 unresolved mismatches in a 7-day window blocks the cutover gate for that district.

---

## 7. Cutover and post-cutover

### 7.1 Cutover sequence (per district)

The full sequence is in [d11 §9 cutover playbook outline](d11-test-strategy.md#9-cutover-playbook-outline). Migration's part:

1. **T-7 days:** dry-run reconciliation with frozen test data; sign-off chain rehearsed.
2. **T-2 days:** final reconciliation; data-owner sign-off captured.
3. **T-0 (cutover weekend):**
   - 18:00 Friday: legacy writes paused for 30 minutes (planned operator quiet window).
   - Final delta sync runs; reconciliation passes.
   - DNS or routing change shifts operator workstations to new system.
   - 18:30 Friday: operations resume on new system as primary; legacy continues to receive mirrored writes.
4. **T+1 day:** operator-SME walkthrough; storm-test re-run; any P1 defect triggers rollback evaluation.
5. **T+7 days:** legacy moved to read-only; mirrored writes stop.
6. **T+14 days:** legacy database snapshotted and archived.

### 7.2 Rollback decision tree

| Trigger (within 24-48h post-cutover) | Action |
|---|---|
| Operator reports inability to complete a workflow step (P1 bug not workaroundable) | **Rollback to legacy.** Mirrored writes have kept legacy current. |
| Audit-event gap >0 detected | **Rollback to legacy.** NFR-07 breach is a regulatory failure, not a defect. |
| CIP control breach detected (CIP-005 R1, CIP-007 R4) | **Rollback to legacy.** CIP Senior Manager engaged immediately. |
| Reconciliation mismatch >0.1% on any table | **Rollback to legacy.** Investigate before re-cutover. |
| Performance degradation >50% on operator-perceived path | **Hold on new; investigate within 4h.** Rollback decision after triage. |

After 48h, **forward-fix is the only option**. Mirrored writes are stopped; legacy data has drifted; rollback would require a reverse migration that is itself riskier than fixing forward.

### 7.3 Final reconciliation (MS-14, after all districts)
- One-time full reconciliation across all bounded contexts.
- Tier 1+2+3 on every migrated table (no sampling — 100% deep-equality on the final pass).
- Sponsor + Auditor + DBA Lead sign-off.
- Legacy frozen (write-blocked at the database level).
- Archive snapshot retained per CIP-009 R2 (encrypted, off-site, 10-year minimum).

---

## 8. Migration-specific risks (in addition to d01 risk register)

| ID | Title | P | I | Mitigation |
|---|---|---|---|---|
| MZ-R-01 | Ingres → SQL semantic loss surprises during reconciliation (alias of R-006) | H | M | Type-mapping decision register (d09 §8.2); per-table sign-off chain |
| MZ-R-02 | Reference-data drift between source and target during long parallel run (alias of R-011) | M | H | Daily reconciliation; drift alert; treat refdata as a regulated integration |
| MZ-R-03 | CDC lag exceeds RPO during high-volume periods | M | M | Sized for 10x peak (storm-aligned); fall back to micro-batch (1-min) if CDC saturates |
| MZ-R-04 | Idempotency-key collision in dual-write mode produces silent duplicates | M | H | Composite key = `(card_id, step_id, action_id, source_system)`; uniqueness enforced at target |
| MZ-R-05 | OpenRoad ODBC driver instability on target host | L | M | Dual-source connectivity; pre-prod soak testing |
| MZ-R-06 | Migration host CIP-010 baseline drift between deploys | M | M | Migration host is on the regular CI/CD baseline (d12); same controls as application hosts |

---

## 9. Volume and timing assumptions

Per A-006 (ratified default):
- ~25–50K cards/year — over a 20-year history that's ~500K–1M cards
- ~50–200 audit events per card → 25M–200M audit rows historically
- 300–800 GB live + 2–4 TB archive

**Initial bulk load expectation:** 24–72 hours for the live data set, executed over a planned 4-day window in pre-prod first, then again per environment. Archive data migrates in parallel without urgency.

**Delta sync target:** RPO ≤5 minutes during normal operations. Best-effort under storm; storm-condition RPO may relax to ≤30 min as long as the dual-write path is intact and reconciliation catches up within 1 hour.

These are **estimates**; the MZ-1 phase profiles actual volumes against current Ingres state and confirms.

---

## 10. Open migration questions (decide at Wave E review)

1. **Ingres CDC support.** If the source Ingres version supports change-data-capture, MZ-3 uses it. Otherwise we use periodic delta extraction. **Confirm with DBA Lead in week 1 of P1.**
2. **Reconciliation tooling host.** Default: dedicated migration host in OpNET. Alternative: run alongside the application monolith. Defaulting to dedicated for cleaner CIP-010 baseline.
3. **Archive storage target.** Default: existing utility cold-storage tier, encrypted. Confirm.
4. **Whether to migrate the audit history at all.** Default: **yes** — full audit history into temporal `_History` shadow. Alternative: archive legacy audit separately and start fresh in target. Default chosen because regulatory queries reach back 7+ years.
5. **Operator-screen behavior during dual-write.** Default: operator chooses which system; reconciliation feeds the other. Alternative: forced-mirror via single screen with mode toggle. Default is more honest about parallel run; some operators may prefer the toggle.

---

## 11. What this strategy refuses to do

- **No big-bang cutover.** Period.
- **No "freeze writes for the cutover weekend."** Switching does not pause; the cutover sequence in §7.1 is built around a 30-minute planned quiet window, not a freeze.
- **No off-the-shelf migration vendor.** The transformation logic must be reviewable for CIP-013 (supply chain) and the team must own it. We don't hand a regulated migration to a black-box tool.
- **No "we'll skip reconciliation on small tables."** Every migrated table goes through tier 1+2+3. The cost of a missed mismatch is higher than the cost of running the tool.
- **No "rollback by truncating target."** Rollback is sequence-orchestrated (§7.2). Truncate-and-reload is not rollback; it is a second migration.
- **No audit gap during migration.** Every migration action emits an audit event into the same chain as production traffic. The audit chain is continuous through migration.
