"""
generate_wave_e_docx.py
Renders d08 (data migration strategy) and d11 (test strategy + cutover playbook outline)
to docx using the shared deliverables/_md2docx.py renderer.

d12 (DevOps blueprint) is delivered as .md only per Section 6 of the prompt.

Usage:
    python generate_wave_e_docx.py
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _md2docx import render_file  # noqa: E402

JOBS = [
    ("d08-data-migration-strategy.md",        "08-data-migration-strategy.docx"),
    ("d11-test-strategy.md",                   "11-test-strategy.docx"),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-dir", default=str(HERE / "build"))
    args = parser.parse_args()

    build_dir = Path(args.build_dir)
    build_dir.mkdir(parents=True, exist_ok=True)

    for in_name, out_name in JOBS:
        inp = HERE / in_name
        out = build_dir / out_name
        render_file(inp, out)
        print(f"Wrote {out} ({out.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
