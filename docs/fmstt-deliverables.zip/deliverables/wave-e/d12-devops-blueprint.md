# DevOps / CI/CD Blueprint
**Deliverable #12 — Wave E: Engineering & Operations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave E review gate.
**Cross-refs:** [d07 — Architecture Outline](../wave-a/d07-architecture-outline.md) · [d10 — Network & Boundary Design](../wave-a/d10-network-boundary-design.md) · [d11 — Test Strategy](d11-test-strategy.md)

---

## 1. Purpose

Defines pipeline stages, environment topology, branching strategy, release gates, on-prem IIS deployment patterns, secrets handling, and rollback. Every decision here is **NERC CIP-aware by default**: if a control breaks, we don't ship.

This blueprint is **opinionated** about what doesn't fit a regulated OT modernization:
- "GitFlow with long-lived develop/release branches" — wrong; the merge complexity becomes a CIP-010 baseline-tracking nightmare.
- "Deploy from any branch with a flag" — wrong; deployments must be from signed, tagged, reproducible builds.
- "Self-service production deploys" — wrong; production deploys are change-controlled with CIP-010 baseline diff.
- "Dev environments inside the ESP" — wrong; Dev is excluded from the ESP per d07 §8.

---

## 2. Environment topology

| Environment | Zone presence | Purpose | CIP-010 baseline? |
|---|---|---|---|
| **Dev** | OpNET-equivalent (developer machines + shared dev sandbox); no XA21, mocked SCADA | Developer inner loop | No (out of ESP) |
| **SIT** | OpNET + DMZ + CorpNET (scaled-down) | Integration testing with mocked-or-staged XA21 | Yes |
| **Pre-Prod** | OpNET + DMZ + CorpNET (production-equivalent) | Performance, NERC CIP rehearsal, cutover rehearsal, operator UAT | Yes |
| **Prod** | Full | Production | Yes |

Dev environment runs without CIP-010 controls **because it is outside the ESP**. Anything Dev produces must pass through SIT before reaching the ESP. Developers do not RDP to OpNET hosts; they push code, the pipeline deploys.

---

## 3. Build pipeline stages

### 3.1 PR pipeline (every commit on a feature branch)

```
1. Lint               (.NET analyzers + Angular ESLint + markdown lint)
2. Unit tests         (xUnit; coverage gate 80% for changed code, 60% baseline)
3. Build              (Release configuration; produce self-contained artifact)
4. Security scan      (SAST via SonarQube or equivalent; dep scan via OWASP DC or Snyk)
5. Container scan     (if any container artifacts; we mostly don't — IIS-deployed)
6. Audit-event lint   (custom: every state-mutating handler must call IAuditEventEmitter)
7. CIP-impact tag     (custom: PRs that touch ESP-relevant files require CIPL review label)
```

PR cannot merge until all stages pass and reviewers approve. Reviewers include:
- ≥1 engineer (mandatory)
- DBA Lead if `**/*.sql` or `**/Migrations/**` changes
- CIP Compliance Lead if `cip-relevant` label set or ESP-relevant files touched
- Integration Lead if `src/Integration/**` or DMZ adapter files touched

### 3.2 Main branch pipeline (every merge to main)

```
1. Full integration tests       (cross-module within OpNET-equivalent containers)
2. Contract tests               (against XA21 trace; against Asset Mgmt staging)
3. Build artifact               (versioned, semver from tag)
4. Sign artifact                (CIP-013 R1: artifacts signed with internal CA cert)
5. Publish to artifact registry (Nexus / Azure Artifacts)
6. Deploy to Dev                (automatic)
7. Smoke test in Dev            (post-deploy)
```

If any stage fails, main is not blocked but the artifact is not published. Subsequent commits do not stack — a fix-forward rebuild is required.

### 3.3 Release pipeline (deploy to SIT/Pre-Prod/Prod)

Each higher environment has explicit gates:

| Environment | Trigger | Gates | Approver |
|---|---|---|---|
| SIT | Auto on green main pipeline | Smoke + integration regression | DevOps Lead (auto) |
| Pre-Prod | Manual trigger from a tagged release | SIT regression pass + CIP-010 baseline diff (clean) + storm/perf budget pass | DevOps Lead + Tech Lead — Backend |
| Prod | Manual trigger from a tagged release with change ticket | Pre-Prod soak pass + CIP-010 baseline diff (clean) + change-control approval + Security Engineer review | Program Director + CIP Compliance Lead |

**Production deploys never happen on a Friday or before a holiday.** Standard utility-ops discipline.

---

## 4. Branching strategy

**Trunk-based development** with short-lived feature branches.

| Branch | Lifetime | Notes |
|---|---|---|
| `main` | Permanent | Always green. Always deployable to Dev. Tag here for release. |
| `feature/<id>-<slug>` | ≤3 days typical | Branch from main; PR back to main; squash-merged |
| `release/<semver>` | Created at tag time, kept for ~1 release window | For hotfixes only; cherry-pick to main and forward |
| `hotfix/<id>-<slug>` | ≤1 day | Branch from `release/*`; PR back to release; cherry-pick to main |

**No long-lived `develop` branch.** Trunk-based is mandatory: long-lived branches become CIP-010 baseline divergence over time.

### 4.1 Tagging
- Release tags: `v<major>.<minor>.<patch>` semver.
- Patch increments on hotfix; minor on feature releases; major rarely (program lifecycle).
- Tags are signed with the team's signing key (CIP-013 R1).

### 4.2 Code ownership
- `CODEOWNERS` file enforces required reviewers per path:
  - `src/Database/**` and `**/*.sql` → DBA Lead
  - `src/Integration/**` → Integration Lead
  - `src/Audit/**` → DBA Lead + CIP Compliance Lead (audit pipeline is regulated)
  - `infra/**` → DevOps Lead
  - `.github/workflows/**` or `azure-pipelines/**` → DevOps Lead + Security Engineer

---

## 5. On-prem IIS deployment patterns

### 5.1 Artifact shape
- .NET 8/9 self-contained publish (no framework dependency on the IIS host).
- Single zip per service per environment, signed.
- Angular SPA: precompiled, hashed assets, single static-asset zip.

### 5.2 Deploy mechanism
- PowerShell-based deployment driven by the pipeline (Web Deploy considered and rejected — opaque, harder to audit for CIP-010).
- Deploy script:
  1. Stage artifact onto target host (over WinRM with managed service account).
  2. Verify signature against internal CA.
  3. Stop traffic to current app pool (drain via DMZ proxy weight = 0).
  4. Swap binaries (atomic rename of versioned folder).
  5. Restart app pool.
  6. Smoke probe `/health` endpoint with mTLS.
  7. Restore traffic weight = 100.
  8. Emit deploy event to SIEM.

### 5.3 Parallel app pools (poor man's blue/green)
For OpNET API tier with a single host (or HA pair):
- Two app pools running side-by-side: `SwitchingOrderApi-Blue` and `SwitchingOrderApi-Green`.
- IIS URL Rewrite or local reverse proxy sends traffic to whichever is "active."
- Deploy to inactive pool, validate, then swap.
- Operator-perceived downtime: <5 seconds during swap (within d07 §9 RTO).

### 5.4 Static asset deployment (Angular)
- Hashed asset filenames + `Cache-Control: max-age=31536000, immutable`.
- HTML shell: `Cache-Control: no-store`.
- Deploy is just an atomic folder swap; no service restart needed.

### 5.5 Database migrations
- Schema changes via DDL scripts (DB-11 in d09: schema is owned by DBAs, not EF migrations).
- Migrations are part of the artifact but **deployed separately** by the DBA Lead, not the application deploy step.
- Pre-deploy snapshot (SQL Server snapshot or full backup verified) before any DDL.
- Migrations are idempotent and version-stamped in `dbo.SchemaVersion` table.

---

## 6. Secrets management

### 6.1 Where secrets live
- **HashiCorp Vault** on-prem (assumed standard utility tooling; confirm A-009).
- One Vault instance per zone: OpNET-Vault and CorpNET-Vault. **No shared secrets across the EAP.**
- DMZ services pull from OpNET-Vault via mTLS-authenticated egress (allowed because DMZ is part of the trust boundary for OT secrets).

### 6.2 What's a secret
- Database connection strings (per environment, per service)
- mTLS client certificates (managed by internal CA, rotated automatically)
- API keys for external integrations (Asset Mgmt, GIS, Notification)
- Encryption keys (TDE master key wrapped by HSM-backed Vault)
- Service account credentials (gMSAs preferred where supported; fallback to managed accounts)

### 6.3 What's NOT a secret
- Endpoint URLs (config; not sensitive on its own)
- Feature flags (config)
- Logging levels (config)
- Public certificate roots (distributed via standard cert distribution)

### 6.4 Build-time vs deploy-time
- **Secrets are NEVER embedded in build artifacts.** Period.
- The pipeline retrieves secrets at deploy time via the deploy host's Vault token (short-lived, role-scoped).
- Application reads secrets at startup from a Vault agent sidecar or directly via Vault SDK with workload identity.

### 6.5 Rotation
- mTLS certs: 90-day rotation, automated.
- Database connection passwords (where used): 90-day, automated rotation in coordination with DBA Lead.
- API keys: per-service rotation policy; default 180 days.
- Encryption keys: annual rotation with documented re-encryption procedure.

---

## 7. Rollback

### 7.1 Application rollback
- Roll back to previous tagged artifact: redeploy.
- RTO target: <15 minutes for app rollback (per d07 §9).
- Rollback is the same pipeline as deploy; only the artifact version changes.

### 7.2 Schema rollback
- **Schema rollback is fundamentally different from app rollback** — it can lose data.
- Every migration ships with a paired rollback script. The rollback script is **tested in pre-prod** as part of the migration's PR.
- Rollback is DBA-Lead-owned, not pipeline-automated.
- Pre-deploy snapshot is the safety net.
- For schema changes that are not safely reversible (column drops, irreversible data transformations), the migration is gated by an explicit "no-rollback" approval from Program Director + DBA Lead before deploy.

### 7.3 Cutover-window rollback
See [d08 §7.2](d08-data-migration-strategy.md#72-rollback-decision-tree) for the per-district cutover rollback decision tree.

### 7.4 Forward-fix vs rollback
The default for production defects is **forward-fix**, not rollback. Rollback is reserved for:
- Data corruption (active or imminent)
- Audit gap (NFR-07 breach)
- Safety-relevant defect (per d04 bug template §7)
- CIP control breach
- Performance regression >50% on operator-perceived path

For everything else, hotfix and re-deploy. Rollback churn is itself a CIP-010 baseline event.

---

## 8. NERC CIP integration with DevOps

### 8.1 CIP-007 R3 — malicious code prevention
- Build-pipeline scans artifacts with two independent scanners.
- Endpoint AV on every deploy host.
- Signed artifacts + signature verification at deploy time.

### 8.2 CIP-007 R4 — security event monitoring
- Every pipeline action that touches an in-scope environment emits a SIEM event:
  - Deploy started
  - Deploy succeeded / failed
  - Schema migration applied
  - Secret retrieved
  - Configuration changed
- SIEM events are tagged with environment, actor (pipeline service principal), commit hash, artifact version.

### 8.3 CIP-010 R1 — baseline configuration
- Pipeline produces a **baseline manifest** for each deploy: file list with hashes, configured ports, services, accounts.
- Per-deploy diff against the prior baseline is captured in the deploy log.
- Deploy gate to Pre-Prod/Prod requires the diff to be expected (annotated by the deploy ticket).

### 8.4 CIP-010 R3 — vulnerability assessment
- Annual active scan of in-scope environments by Security Engineer.
- Pipeline-driven scan on every deploy: SAST + dependency scan + secrets-in-code scan.
- Pre-cutover scan in Pre-Prod (in d11 §7.5).

### 8.5 CIP-013 R1 — supply chain
- All third-party dependencies reviewed before introduction (vendor risk assessment).
- Build artifacts signed with internal CA cert.
- Vendor SBOM tracked per release.

---

## 9. Tooling stack (default; confirm at Wave E review)

| Concern | Default | Notes |
|---|---|---|
| CI server | Azure DevOps Server (on-prem) **or** GitHub Enterprise Server | A-009 candidates. Confirm. |
| Artifact registry | Azure Artifacts (if Azure DevOps) **or** Nexus on-prem | |
| Secrets | HashiCorp Vault on-prem | A-009 |
| IaC | Terraform for infra; PowerShell DSC for IIS configuration | Terraform avoided for IIS itself (poor fit) |
| Container registry | Not used at scale (IIS deploy, not containers) | Optional for build-pipeline tooling only |
| Static analysis | SonarQube on-prem | |
| Dependency scan | OWASP Dependency-Check **or** Snyk (on-prem) | |
| Test execution | xUnit + Playwright (E2E) + k6 (perf) | k6 for load and storm; Playwright for operator-walkthrough automation |
| Monitoring | Prometheus + Grafana + Serilog → SIEM | Per d07 §7 |
| Tracing | OpenTelemetry → Tempo or Jaeger on-prem | |

---

## 10. Pipeline-as-code

All pipelines live in source control under `infra/pipelines/`. Pipeline changes follow the same PR review path as application changes:
- DevOps Lead is required reviewer.
- Security Engineer is required reviewer for changes to deploy gates, signing steps, or scan steps.
- CIP Compliance Lead is required reviewer for changes to anything touching CIP-010 baseline emission.

**Pipelines are CIP-relevant code.** They have the same review discipline as application code.

---

## 11. Open DevOps questions (decide at Wave E review)

1. **CI server choice** — Azure DevOps Server vs GitHub Enterprise. Default Azure DevOps unless utility standardizes on GitHub.
2. **Vault clustering** — single Vault per zone vs HA pair. Default HA pair given criticality.
3. **Secret backend for legacy interop** — if any legacy components need DB connection strings, where do they read from? Default: configuration-as-code with Vault references; legacy adapters retire with their host system.
4. **Pipeline runner location** — runners in OpNET vs in DMZ for sandbox isolation. Default: in OpNET for ESP-resident services (with restricted egress); in CorpNET for CorpNET-resident services. **Never** a single runner pool spanning the EAP.
5. **Approval mechanism** — manual gate vs ServiceNow change ticket. Default: ServiceNow change ticket for Pre-Prod/Prod (matches utility-ops standards).

---

## 12. What this blueprint refuses to do

- **No GitFlow** (long-lived develop/release branches). Trunk-based or fail.
- **No self-service production deploy.** Production is change-controlled.
- **No secrets in source control.** Pre-commit hook + secret scanner enforce.
- **No dev environment inside the ESP.** Period.
- **No "we'll deploy to prod and watch the logs."** Every prod deploy has a rollback procedure ready and an approver awake.
- **No bypassing CIP-010 baseline diff.** The diff is the evidence; skipping it is a CIP finding waiting to happen.
- **No "infrastructure changes through the GUI."** All infra changes are through pipeline-driven IaC. The pipeline is the audit trail.
- **No auto-merge bots that bypass code-owner review.** Even Dependabot PRs go through normal review for in-scope dependencies.
