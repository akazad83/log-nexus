# Test Strategy + Cutover Playbook Outline
**Deliverable #11 — Wave E: Engineering & Operations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave E review gate.
**Cross-refs:** [d07 — Architecture](../wave-a/d07-architecture-outline.md) · [d08 — Data Migration Strategy](d08-data-migration-strategy.md) · [d10 — Network & Boundary Design](../wave-a/d10-network-boundary-design.md) · [d12 — DevOps Blueprint](d12-devops-blueprint.md)
**Output:** this `.md` is canonical; `build/11-test-strategy.docx` is the rendered governance copy.

---

## 1. Purpose

Defines the test types, their commitments per phase, the storm-test approach, NERC CIP testing, operator-in-the-loop discipline, and a cutover playbook outline that the team will expand into the live playbook during P4 dry-runs.

This strategy is **opinionated** about what doesn't fit a regulated, safety-adjacent program:

- "We'll add tests later" — wrong; tests are part of DoD, not optional.
- "The team will fix flaky tests when they have time" — wrong; flaky tests are P2 bugs.
- "Manual UAT will catch the rest" — wrong; operators are not regression suites.
- "Storm test once at the end" — wrong; storm test is a per-sprint gate from sprint 8 onward.
- "Cutover playbook gets written when we get to cutover" — wrong; the outline is here, the playbook is rehearsed twice (MS-11) before any district sees it.

---

## 2. Test types and where they live

| Type | Owner | When | Tool default | NFR linkage |
|---|---|---|---|---|
| Unit | Devs | Every PR | xUnit (.NET); Jest/Karma (Angular) | Per-AC verification |
| Integration | Devs + QA | Every PR (subset), nightly (full) | xUnit + Testcontainers; Playwright for cross-tier | Per-AC verification |
| Contract | Integration team | Every PR (when adapters change), pre-deploy | Custom; recorded XA21 trace; staged Asset Mgmt | NFR-related to integration boundary |
| Performance | QA | Per-sprint (smoke); per-milestone (full) | k6 or NBomber | NFR-01 latency, NFR-04 throughput |
| Security | Security Eng + DevOps | Every PR (SAST/dep); annually (active) | SonarQube + OWASP DC; NESSUS for active | CIP-007 R3, CIP-010 R3 |
| Storm | QA + Integration | Per-milestone from MS-06 onward; per-sprint from sprint 8 | Custom load harness (k6 + recorded XA21 trace) | NFR-04 throughput, NFR-07 audit completeness |
| Operator-in-the-loop | Change Lead + QA | Every sprint demo + UAT cycles | Manual; recorded for evidence | Parity claim (d04 user story) |
| UAT | Change Lead + QA + Operator SMEs | P2b cycles 1-3; per-wave in P3; full in P4 | Manual + Playwright recordings | All ACs, parity claims |
| Regression | DevOps + QA | Every deploy | Playwright + xUnit suites | Stable baseline |
| Disaster Recovery | DevOps + DBA | Quarterly + pre-cutover | Live drill in Pre-Prod | CIP-009 R3 |
| CIP control | CIP Lead + Security Eng | Per deploy (baseline diff); per milestone (walkthrough) | Custom + auditor-style walkthroughs | NFR-12 + per-control NFRs |

---

## 3. Test environments

Per [d12 §2](d12-devops-blueprint.md#2-environment-topology). Quick reference:

- **Dev**: unit + dev-loop integration only. No XA21. Synthetic data.
- **SIT**: integration + contract + smoke perf. Mocked-or-staged XA21. Synthetic data.
- **Pre-Prod**: full perf, storm, security, CIP rehearsal, DR drill, UAT, cutover dry-runs. Production-equivalent. **Anonymized prod-shape data.**
- **Prod**: smoke and post-deploy verification only. No load tests in prod.

---

## 4. Test data strategy

### 4.1 Tiers
| Environment | Data source | Approval to use |
|---|---|---|
| Dev | Synthetic generators | None needed |
| SIT | Synthetic generators with realistic distributions | None needed |
| Pre-Prod | Anonymized prod-shape data | Data Owner + CIP Compliance Lead (CIP-011) |
| Prod | Production data | (production) |

### 4.2 Anonymization rules
- All BCSI columns masked to `XXXX` patterns preserving format.
- Operator names → synthetic names from a generator
- Card numbers → preserved (not BCSI; required for traceability)
- Geographic identifiers (substations, feeders) → preserved if non-BCSI per data-owner ruling; otherwise tokenized
- Timestamps → preserved (load-pattern fidelity matters for storm tests)

### 4.3 Refresh cadence
- Dev/SIT synthetic data refreshed on demand.
- Pre-Prod anonymized data refreshed monthly (and before any major UAT cycle).
- **Never copy prod data to lower environments without an explicit, dated, signed approval.**

### 4.4 Why this matters
Test data quality directly affects parity verification. UAT defects that surface only on real-data shapes are the worst kind: they invalidate cycles 1 and 2 if discovered in cycle 3. The anonymized refresh into Pre-Prod is the cheapest insurance against this.

---

## 5. Operator-in-the-loop testing

This is the program's load-bearing test discipline. Without it, parity is unverified.

### 5.1 Sprint demo
- **Every sprint.** No exceptions.
- Operator SME present (per d03 §10.1).
- Demo is the operator clicking through, not a slide deck.
- Stories not demoed do not pass DoD.

### 5.2 UAT cycles (P2b)
- **Cycle 1**: District A operators run transmission MVP scenarios end-to-end. Defect intake captured per [d04 bug template](../wave-c/d04-templates/bug-template.md).
- **Cycle 2**: District B operators run the same scenarios after cycle-1 defects are remediated.
- **Cycle 3**: Regression cycle, both districts.
- Each cycle: 2 weeks of preparation + 1 week of execution + remediation in parallel.

### 5.3 Per-wave UAT (P3)
Rolling per-wave UAT cycles. Same discipline, smaller scope per wave:
- Wave 1 (distribution): District A + B operators
- Wave 2 (dielectric, steam): subject-matter operator group per workflow type
- Wave 3 (monitor apps): SME per monitor app
- Wave 4 (integrations): Integration test with downstream system owners
- Wave 5 (CorpNET reporting): corporate user UAT
- Wave 6 (cutover scripts): DBA + Operator SMEs

### 5.4 Full integration UAT (P4)
- Cross-system end-to-end scenarios.
- 4-week duration (12 weeks likely range; defect-rate-driven).
- All districts represented.
- Includes degraded-mode scenarios (per NFR-03).

### 5.5 Cutover dry-runs (P4)
Two dry-runs, both with operators present:
- **Dry-run #1:** happy-path cutover sequence. Every step rehearsed.
- **Dry-run #2:** with a triggered rollback. Whichever rollback condition the team picks (DBA-Lead choice), execute it.

Both dry-runs end with a written debrief and a signed-off list of corrections to the playbook.

---

## 6. Storm test strategy

The single highest-leverage technical test in the program.

### 6.1 What it tests
- Throughput under sustained load (1000 SCADA events/min for 30 min).
- Audit completeness under load (NFR-07).
- Latency P95 holds (NFR-01).
- AG sync replica keeps up (NFR-related to RPO).
- DMZ gateway fails gracefully under burst (10× target).
- Operator screens remain interactive during storm.

### 6.2 Composition
- Recorded XA21 SOAP trace replayed at controlled rate (DEP-01).
- 50 simulated operator-action sequences interleaved.
- 4-district load distribution.
- Asset Mgmt sync pulse during storm (catches refdata-drift edge cases).

### 6.3 Cadence
- **Sprint 8 onward (P2a):** smoke storm test (10-min, 500 events/min) per sprint as part of the deploy gate.
- **MS-06:** full storm test (30-min, 1000 events/min). Pass/fail gate.
- **MS-07:** storm test re-run with operators in the loop and CIP rehearsal.
- **P3 sub-wave gates:** smoke storm test per wave to catch regressions.
- **P4 full UAT:** full storm + soak (72h continuous load).
- **P5 cutover dry-runs:** per-district storm rehearsal to validate per-district capacity.

### 6.4 What "fail" looks like
- Any P95 latency >2× target on operator-perceived path → fail.
- Any audit-event loss → fail. Hard rule.
- Any chain-hash discontinuity → fail.
- Operator screen unresponsive >5 seconds → fail.
- AG sync replica falls >1 minute behind → fail.
- DMZ gateway crashes under burst (vs queues with backpressure) → fail.

A storm-test failure blocks the milestone gate. No exceptions.

---

## 7. NERC CIP testing

### 7.1 Per-PR
- SAST + dep scan in pipeline.
- CIP-impact label triggers CIP Compliance Lead review.

### 7.2 Per-deploy
- CIP-010 baseline diff produced and attached to deploy log.
- SIEM ingest verification (events from new code reach SIEM with correct enrichment).

### 7.3 Per-sprint (in pre-prod)
- Smoke walkthrough of CIP-007 R4 event coverage on the sprint's new functionality.

### 7.4 Per-milestone
- **MS-06 (storm test):** CIP-007 R4 verification under load — events arrive, are correctly correlated, are time-aligned within 50ms.
- **MS-07 (CIP rehearsal):** auditor-style walkthrough of CIP-005 R1, CIP-005 R2, CIP-007 R1/R3/R4/R5, CIP-010 R1, CIP-011 R1.
- **MS-10 (full UAT):** walkthrough of CIP-009 R1/R2/R3 (recovery plans, drills, restore tests).
- **MS-11 (cutover dry-run #2):** walkthrough of CIP-013 R1 supply chain controls applied to release artifacts.

### 7.5 Per-cutover (per district)
- CIP-005 R1 ESP boundary verification before traffic shift.
- CIP-007 R4 event flow verification 1 hour into cutover.
- CIP-010 R1 baseline confirmed against expected manifest.

### 7.6 Annual
- CIP-010 R3 active vulnerability assessment.
- Penetration test of operator-facing surfaces (preferred external).

---

## 8. Per-phase test commitments

| Phase | Primary test commitments |
|---|---|
| P1 | Test strategy ratified; test framework choices made; test data anonymization tooling stood up |
| P2a | Unit + integration in CI; contract tests against XA21 trace; storm-test harness built; smoke storm test from sprint 8 |
| P2b | UAT cycles 1–3; defect remediation; storm rerun; CIP audit walkthrough |
| P3 | Per-wave UAT; per-wave storm smoke; per-wave CIP control verification; rolling regression |
| P4 | Full integration UAT; 72h soak; storm + perf; DR drill; CIP pre-cutover audit; cutover dry-runs ×2 |
| P5 | Per-district pre-cutover storm smoke; reconciliation testing; cutover sequence verification |
| P6 | Hypercare regression; defect-rate trend monitoring |

---

## 9. Cutover playbook outline

This section is the **outline** for the live playbook. The live playbook is built and rehearsed during P4 (per [d01 P4.05/P4.06](../wave-b/d01-master-plan-spec.md)). What follows is the structure that playbook will fill in.

### 9.1 Pre-cutover checklist

#### T-30 days
- [ ] All P1/P2 bugs against MVP scope closed
- [ ] Reconciliation passes 7 consecutive days for the target district
- [ ] CIP Compliance Lead has reviewed cutover plan
- [ ] Operator SME Lead has briefed district operators on the day-of sequence
- [ ] Sponsor + CIP Senior Manager + Operator SME Lead have signed the go-no-go memo
- [ ] Vendor (XA21) confirms no maintenance windows touching cutover weekend
- [ ] DR site has current backup; restore verified

#### T-7 days
- [ ] Final reconciliation run (tier 1+2+3)
- [ ] Data Owner sign-off on reconciliation
- [ ] All deploy artifacts signed and staged
- [ ] Rollback artifacts staged and verified
- [ ] CIP-010 baseline manifest captured for both source and target environments
- [ ] On-call rotation confirmed: Tech Lead — Backend, DBA, Integration Lead, CIP Lead, DevOps Lead, Operator SME Lead
- [ ] Comms plan distributed: who calls whom for each rollback decision

#### T-2 days
- [ ] Final-final reconciliation (signed by Data Owner)
- [ ] DBA snapshot of source DB taken
- [ ] DBA snapshot of target DB taken
- [ ] Storm-smoke run in Pre-Prod (last regression check)
- [ ] Operator SME Lead confirms district staffing for cutover weekend
- [ ] War room booked; conference bridge tested

#### T-1 day
- [ ] All hands on call for go-no-go
- [ ] Sponsor signs final go authorization
- [ ] Pipeline jobs queued and ready

### 9.2 Cutover sequence (T-0)

Times are illustrative; replace with actuals during dry-runs.

```
Friday 17:00  - War room opens; roll-call
Friday 18:00  - Begin operator quiet window (30 min planned)
Friday 18:05  - Final delta sync from Ingres
Friday 18:15  - Reconciliation pass; expected clean
Friday 18:25  - DBA Lead: confirm snapshot on source
Friday 18:30  - GO/NO-GO checkpoint #1 (after reconciliation)
Friday 18:35  - DNS/routing change; operator workstations point to new system
Friday 18:40  - Smoke check: operator opens a card; storm-event ingest verified
Friday 18:45  - GO/NO-GO checkpoint #2 (after smoke)
Friday 19:00  - Operator workflow resumes; new system is primary
Friday 19:30  - First-hour SIEM event verification (CIP-007 R4)
Saturday 06:00 - 12-hour status check; on-call retro
Saturday 18:00 - 24-hour status check; rollback decision window narrows
Sunday  18:00 - 48-hour status check; rollback window closes
Sunday  20:00 - GO/NO-GO checkpoint #3 (decision: lock cutover, stop legacy mirroring next week)
```

### 9.3 GO/NO-GO checkpoint criteria

At each checkpoint, **all** of these must be GO; any NO-GO triggers the rollback decision tree.

| Criterion | GO if | NO-GO if |
|---|---|---|
| Reconciliation status | Tier 1+2+3 passed within last 30 min | Any tier failed |
| Audit chain continuity | Chain hash verified; zero gaps | Any gap |
| SCADA wrapper health | Read + write paths green; storm smoke passed | Any error rate above baseline |
| Operator screen latency | P95 within budget | P95 >2× budget |
| SIEM event flow | All expected event types arriving | Any missing event type |
| AG sync replica | Lag <1 min | Lag >2 min |
| Operator confidence | SME Lead reports confidence | SME Lead expresses concern |

### 9.4 Rollback decision tree

See [d08 §7.2](d08-data-migration-strategy.md#72-rollback-decision-tree).

### 9.5 Post-cutover verification

#### T+1 hour
- Storm smoke (5-min, 500 events/min) — pass required
- Operator walkthrough of one full card lifecycle — pass required
- Audit chain verification — pass required
- CIP-007 R4 SIEM ingest verification — pass required

#### T+24 hours
- 24-hour metrics review (rate, errors, latency, audit completeness)
- Operator-SME sit-down with the on-call team
- Defect intake review

#### T+7 days
- Legacy mirror writes stopped
- Legacy DB set read-only
- Operator-SME debrief; lessons learned captured for next district

#### T+14 days
- Legacy DB snapshotted; archive created per CIP-009 R2
- Defect-rate trend reviewed; if intake hasn't fallen, hypercare staffing adjusted

### 9.6 What stays static; what gets rehearsed

**Static (in this outline):** the GO/NO-GO criteria; the rollback decision tree; the post-cutover verification structure.

**Rehearsed (in P4 dry-runs):** the actual times; the actual on-call names; the actual war-room logistics; the per-district variations.

The dry-runs produce two artifacts:
1. The signed-off live playbook for District 1.
2. A list of variations for Districts 2-4 (which are not identical — staffing, time zones, operator habits differ).

---

## 10. Open testing questions (decide at Wave E review)

1. **Test automation tool for E2E** — Playwright vs Cypress vs Selenium. Default Playwright (best Angular support, .NET integration).
2. **Load tool** — k6 vs NBomber. Default k6 (broader ecosystem; first-class storm scenario support).
3. **Anonymization tooling** — bespoke vs vendor (e.g., Delphix). Default bespoke for CIP-013 supply-chain simplicity.
4. **Cutover war-room location** — physical vs virtual. Default hybrid: core team physical at the OpNET-resident war room; extended team on conference bridge.
5. **Penetration test vendor** — confirm utility-standard procurement path.

---

## 11. What this strategy refuses to do

- **No "we'll skip the storm test this sprint to make velocity."** Sprint 8 onward, smoke storm is a deploy gate.
- **No "we'll do UAT once at the end."** UAT is per-wave from P2b through P5.
- **No "production smoke is enough."** Pre-Prod soak (72h) is mandatory before every milestone gate.
- **No "the operator will catch defects in production hypercare."** That's an admission of UAT failure, not a strategy.
- **No "we'll add observability if the test fails."** Observability is part of every story's DoD (per d03 §7.3); tests verify it, they don't add it.
- **No "the cutover playbook will be improvised."** It is built, signed, and rehearsed twice before any district sees it.
