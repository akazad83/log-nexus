"""
_xlsx_helpers.py
Shared openpyxl rendering helpers used by Wave D onward.

Wave-B's generate_master_plan_xlsx.py keeps its own copy of these helpers so
that delivered artifact stays self-contained. Wave-D and later import here.
"""

from __future__ import annotations

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

HEADER_BG = "1F4E78"
HEADER_FG = "FFFFFF"

THIN = Side(style="thin", color="A6A6A6")
MEDIUM = Side(style="medium", color="404040")
BORDER_ALL = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CONFIDENCE_COLORS = {
    "High":   "C6EFCE",
    "Medium": "FFEB9C",
    "Low":    "FFC7CE",
}

CATEGORY_COLORS = {
    "DESIGN":        "DDEBF7",
    "DELIVERY-MVP":  "E2EFDA",
    "DELIVERY-P3":   "FFF2CC",
    "DELIVERY-OPS":  "F8CBAD",
}

PHASE_COLORS = {
    "P0":  "BFBFBF",
    "P1":  "DDEBF7",
    "P2a": "E2EFDA",
    "P2b": "C6EFCE",
    "P3":  "FFF2CC",
    "P4":  "FCE4D6",
    "P5":  "F8CBAD",
    "P6":  "E4DFEC",
    "AO":  "D9E1F2",
}


def fill(hex_rgb: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_rgb)


def header_style(cell):
    cell.font = Font(bold=True, color=HEADER_FG, size=11)
    cell.fill = fill(HEADER_BG)
    cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    cell.border = Border(bottom=MEDIUM, left=THIN, right=THIN, top=THIN)


def write_row(ws: Worksheet, row_idx: int, values, wrap=False):
    for col_idx, v in enumerate(values, 1):
        c = ws.cell(row=row_idx, column=col_idx, value=v)
        c.alignment = Alignment(vertical="top", wrap_text=wrap)
        c.border = BORDER_ALL


def write_headers(ws: Worksheet, headers, row=1, height=32):
    for col_idx, h in enumerate(headers, 1):
        c = ws.cell(row=row, column=col_idx, value=h)
        header_style(c)
    ws.row_dimensions[row].height = height


def set_widths(ws: Worksheet, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def freeze_top(ws: Worksheet, panes="A2"):
    ws.freeze_panes = panes


def title_cell(ws: Worksheet, row: int, col: int, text: str, span: int = 1, size: int = 16):
    cell = ws.cell(row=row, column=col, value=text)
    cell.font = Font(bold=True, size=size, color=HEADER_BG)
    if span > 1:
        ws.merge_cells(
            start_row=row, start_column=col,
            end_row=row, end_column=col + span - 1,
        )
    ws.row_dimensions[row].height = max(28, size + 12)
