"""
generate_pipeline_guide_docx.py
Renders d03 (and optionally the d04 template set) to docx using the shared
deliverables/_md2docx.py renderer.

Usage:
    python generate_pipeline_guide_docx.py                # default: d03 only
    python generate_pipeline_guide_docx.py --bundle-templates  # d03 + all d04 templates concatenated

Outputs:
    build/03-backlog-pipeline-guide.docx
    build/04-templates-bundle.docx  (only with --bundle-templates)
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _md2docx import render_file, render_files  # noqa: E402


TEMPLATE_ORDER = [
    "epic-template.md",
    "user-story-template.md",
    "acceptance-criteria-template.md",
    "task-template.md",
    "spike-template.md",
    "bug-template.md",
    "nfr-template.md",
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(HERE / "d03-backlog-pipeline-guide.md"))
    parser.add_argument("--output", default=str(HERE / "build" / "03-backlog-pipeline-guide.docx"))
    parser.add_argument(
        "--bundle-templates",
        action="store_true",
        help="Also produce a single docx containing all d04 templates concatenated.",
    )
    parser.add_argument(
        "--templates-output",
        default=str(HERE / "build" / "04-templates-bundle.docx"),
    )
    args = parser.parse_args()

    inp = Path(args.input)
    out = Path(args.output)
    render_file(inp, out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes)")

    if args.bundle_templates:
        template_dir = HERE / "d04-templates"
        templates = [template_dir / name for name in TEMPLATE_ORDER]
        missing = [str(t) for t in templates if not t.exists()]
        if missing:
            raise FileNotFoundError(f"Missing template files: {missing}")
        bundle_out = Path(args.templates_output)
        render_files(templates, bundle_out)
        print(f"Wrote {bundle_out} ({bundle_out.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
