# Backlog Engineering Pipeline Guide
**Deliverable #3 — Wave C: Backlog Engineering**
**Status:** Phase 1 baseline. Companion: [d04 templates](d04-templates/).
**Output:** this `.md` is the canonical version; `build/03-backlog-pipeline-guide.docx` is the rendered governance copy.

---

## 1. Purpose

This guide is the **operating manual** for everyone who touches the backlog: BAs, Scrum Masters, Tech Leads, the Test Lead, and the Operator SMEs who validate stories. It is not a reference deck — it is followed.

It defines:

1. The pipeline from feature catalog (Phase 0 output) all the way down to a coded task.
2. **Translation rules** at every level.
3. **Story-splitting heuristics** specific to switching/clearance workflows.
4. **Definition of Ready** and **Definition of Done** with regulated/safety-adjacent additions.
5. How **NERC CIP, audit, and operator-safety** requirements get woven into every story (not bolted on at the end).
6. Estimation conventions, refinement cadence, and traceability mechanics.

It is brutally specific because backlog-engineering theater is the most expensive failure mode on regulated programs. The team will build whatever the backlog says. The backlog says whatever the BA writes. The BA writes whatever this guide tells them to.

---

## 2. The pipeline at a glance

```
Feature Catalog (Phase 0 output, fixed)
        │
        ▼
   ┌─────────┐         outcome-shaped, sponsor-visible, ~quarter-scale
   │  Epic   │         <= 1 quarter, 6-15 stories
   └────┬────┘
        ▼
   ┌─────────┐         outcome-shaped, vertical slice, ~sprint-scale
   │  Story  │         <= 1 sprint, 3-13 points
   └────┬────┘
        │   (each story has 1+ AC; AC may include NFR addendum)
        ▼
   ┌─────────┐         testable, Gherkin (functional) + table (non-functional)
   │   AC    │
   └────┬────┘
        │
        ▼
   ┌─────────┐         developer-shaped, hours-scale
   │  Task   │         < 1 day each
   └─────────┘

  Side artifacts (any level):
    • Spike — bounded research; output is a decision, not code
    • Bug — defect against an accepted behavior
    • NFR — cross-cutting requirement; linked from many stories
```

**Hard rule:** every story is a vertical slice through the architecture. A story that ends at "API done" without UI, or ends at "UI done" without API, is wrong. The architecture (d07) is layered; the backlog is not.

---

## 3. Levels — definition, scope, and lifecycle

### 3.1 Feature (input, fixed)

- Comes from Phase 0 feature catalog. Not authored here. Not edited here.
- Maps 1-to-many to Epics.
- Identified as `FC-NN` and traced through every downstream artifact.

### 3.2 Epic — `EPIC-NN`

- A **business outcome** scoped at roughly one quarter.
- Has a measurable success criterion that the **Sponsor** would recognize as done.
- Is **not** a technical layer ("Backend API") or an architectural component ("DMZ Gateway"). Those are workstreams; this is an outcome.
- Sized by counting stories and rough complexity, not by point-summing.

**Examples — good vs bad:**

| Bad (do not write these) | Good |
|---|---|
| "Build the Switching Card module" | "Operator can drive a transmission switching card from SCADA event to closure on the new system" |
| "Migrate to SQL Server" | "All MVP-scope switching cards persist with full audit trail and pass reconciliation against legacy" |
| "Add NERC CIP controls" | "Pre-prod environment passes CIP-007 R4 walkthrough with auditor sign-off" |

### 3.3 User Story — `US-NN`

- A **vertical slice** of operator-visible value.
- Sized to fit in **one sprint** (≤13 points; 13 means split).
- Written in `As a / I want / So that` form, with the role drawn from a closed list:
  - District Operator
  - Field Crew (Rapid Restore)
  - Supervisor
  - Auditor
  - System (only for SCADA-event-driven creation; rare)
- Carries a **labels** array including any of: `transmission`, `distribution`, `dielectric`, `steam`, `scada`, `audit`, `cip-relevant`, `parity-critical`, `storm-path`.

**Identity rule:** a story names the **smallest operator-visible behavior change**. "Operator can see the De-energize step status" is a story. "Operator can use the new system" is not.

### 3.4 Acceptance Criteria — `AC-NN-N`

- Functional ACs in **Gherkin** (Given/When/Then). One scenario per AC.
- Non-functional addendum is a small **table**, not prose:

```
| Aspect       | Criterion                                              |
| ------------ | ------------------------------------------------------ |
| Latency      | P95 < 200ms on operator-perceived path                 |
| Audit        | AuditEvent type 'CardCreated' emitted with Card.id     |
| Security     | Action requires AD role 'DistrictOperator'; mTLS used  |
| Availability | Operates with Asset Mgmt sync degraded (cached refdata)|
```

- The functional Gherkin tells the dev what to build. The NFR addendum tells the test team how to measure it.

### 3.5 Task — `TASK-NN`

- Developer-shaped, < 1 day, owned by one person.
- One task = one PR, ideally.
- Tasks are not estimated in points; they are estimated in hours when useful, otherwise just listed.

### 3.6 Side artifacts

- **Spike** — bounded research; **3-day timebox max**, extension only with written justification. Output is a decision posted in the spike ticket.
- **Bug** — defect against an accepted behavior. Priority P1–P4. Bugs are not point-estimated.
- **NFR** — cross-cutting non-functional requirement. NFRs are referenced from many stories and verified separately. See `d04-templates/nfr-template.md`.

---

## 4. Translation rules — how to refine downward

### 4.1 Feature → Epic

For each feature:
1. State the operator outcome in one sentence (no nouns about systems).
2. Identify the Sponsor-visible success criterion.
3. Identify which workflow types are affected (transmission / distribution / dielectric / steam) — usually all four; treat each as a separate Epic if the workflow logic differs materially.
4. List 6–15 candidate stories. If more than 15, split the Epic. If fewer than 6, you have a Story, not an Epic.

### 4.2 Epic → Stories

Apply the **eight story-splitting heuristics** in §5 below. Pick whichever one gives you the smallest set of vertical slices that each independently deliver operator-visible value.

### 4.3 Story → Acceptance Criteria

For every story, write at least:
- **One happy-path** scenario in Gherkin.
- **One exception/error scenario** in Gherkin.
- **One audit AC**: the audit events that must be emitted.
- **One security AC**: who is allowed to do this and how authorization is enforced.
- **NFR addendum** if any of latency, throughput, availability targets are touched.

If you cannot write at least one happy + one error + audit + security AC, you do not have a story. You have an idea.

### 4.4 Acceptance Criteria → Tasks

The tasks decomposition is the dev's call (BA does not write tasks). The DoR check is whether the story's AC is *decomposable* into ≤1-day tasks.

---

## 5. Story-splitting heuristics for switching/clearance workflows

When an Epic produces a story too big for one sprint, split it using one of these patterns. Each is illustrated with the **8-step switching workflow**: Notify → Create → De-energize → Tag → Authorize → Execute → Test → Restore → Close.

### 5.1 By workflow step (preferred default)
The single most useful pattern for this domain. Treat each of the 9 workflow events as a vertical slice.

> **Example:** "Operator can run a transmission switching card end-to-end" splits into nine stories: one per workflow event. Each story delivers operator-visible value because each step has its own UI, audit, and authorization profile.

### 5.2 By role
Same workflow, different actors.

> **Example:** "De-energize step recorded" splits into "Operator initiates de-energize" and "Field crew confirms de-energize via Rapid Restore."

### 5.3 By trigger source
SCADA-event-driven vs manual vs scheduled.

> **Example:** "Switching card created" splits into "auto-create from SCADA event" and "manual create by operator."

### 5.4 By workflow type
Transmission, distribution, dielectric, steam.

> **Example:** "Tagging step works" splits into one story per workflow type — they share infrastructure but the rules differ. **MVP rule: pick one (transmission) and defer the others to P3 sub-waves.**

### 5.5 By happy path → exception path
Build the happy path first, exception second.

> **Example:** "Authorize step works" splits into "single-approver happy path" and "approver-unavailable timeout escalation".

### 5.6 By data dimension
Single device → feeder → substation → district.

> **Example:** "Reference data sync works" splits into "single device sync" then "feeder-level sync" then "full district sync".

### 5.7 By integration boundary
Each integration adapter is a slice.

> **Example:** "Operator screen reflects field state" splits into "Rapid Restore handoff" and "XA21 ack receipt" and "Asset Mgmt refdata refresh."

### 5.8 By regulatory dimension
Capture, authorization, ESP-traversal each as their own slice when the scope warrants.

> **Example:** "Switching card persisted" splits into "card row written" and "audit event chain written" and "ledger verification job runs nightly".

**Heuristic to pick a heuristic:** in the switching domain, **§5.1 (by workflow step) and §5.4 (by workflow type) compose** to give the cleanest sprint plan. Default to those unless a story doesn't yield to them.

---

## 6. Definition of Ready (DoR)

A story is **Ready** when **every** box is checked. No exceptions. Stories that aren't Ready do not enter sprint planning.

### 6.1 Story-level DoR

- [ ] Title is in As-a/I-want/So-that form
- [ ] Linked to Epic and to original Feature catalog ID
- [ ] At least one happy-path AC, one exception-path AC, one audit AC, one security AC
- [ ] NFR refs identified (`NFR-NN, NFR-NN`)
- [ ] Operator SME has reviewed (where UX-affecting)
- [ ] Dependencies (other stories, integrations, refdata) enumerated
- [ ] CIP impact assessed: scoped Y/N; if Y, controls X/Y/Z noted on story
- [ ] Labels set (workflow type, scada, audit, cip-relevant, etc.)
- [ ] Estimate is ≤8 points; if 13, has been split
- [ ] INVEST self-check passes (each letter)

### 6.2 What "Operator SME has reviewed" means

The Operator SME has spent ≥15 minutes with the BA, looked at wireframes or mockups, and said one of: "this matches how we work today", "this is different but acceptable because Y", or "this is wrong because Z." Recorded as a comment on the story with date and SME name. This is the parity check.

### 6.3 What "CIP impact assessed" means

The BA has answered three questions:
1. Does this story write to or modify a BES Cyber System Information row? (CIP-011 R1)
2. Does this story expose a new port, service, or endpoint? (CIP-007 R1)
3. Does this story change baseline configuration? (CIP-010 R1)

Answers are noted on the story. If any answer is yes, the **CIP Compliance Lead** is added as a reviewer before the story is Ready.

---

## 7. Definition of Done (DoD)

A story is **Done** when **every** box is checked. Done is a conversation between dev, QA, and the operator SME — it is not a developer's self-declaration.

### 7.1 Story-level DoD

- [ ] All AC verified by automated tests (unit + integration where applicable)
- [ ] Audit events emitted for the story's actions and verified in audit stream
- [ ] NFRs referenced by the story verified per their verification method
- [ ] CIP-relevant controls verified (where CIP-scoped)
- [ ] Code merged to main with passing CI (lint, build, unit, integration, security scan)
- [ ] Operator-walkthrough demo completed in SIT or higher with operator SME present
- [ ] Telemetry verified (logs structured, metrics emitted, traces propagated)
- [ ] Documentation updated (operator-facing if UX changes; runbook if ops-affecting)
- [ ] No P1/P2 bugs open against this story

### 7.2 What "operator-walkthrough demo completed" means

The story is shown to an operator SME executing the actual workflow. Not a screenshot. Not a video. The operator does the click-through. If the operator says "this isn't right" the story is not Done — it goes back into refinement.

### 7.3 What "telemetry verified" means

A grep against the structured log stream during the demo confirms every state change emits a log line with required enrichment fields (`traceId`, `correlationId`, `cardId`, etc.). Not optional. The audit stream is regulatory; ops logs are operational; both are checked.

---

## 8. NERC CIP, audit, and safety as first-class backlog content

These are **never** "non-functional bolt-ons." They live in the backlog as ordinary work items.

### 8.1 The audit thread

- Every story that mutates state writes at least one audit event.
- The audit event type is from the controlled vocabulary (~80 actions; see d09 §4.2).
- The audit AC is a required AC, not optional.
- Audit completeness is verified per story, not as a "test pass at end of MVP."

### 8.2 The CIP thread

- Stories with CIP impact (Y on any of the three §6.3 questions) get reviewed by the CIP Compliance Lead before Ready, and verified against CIP controls before Done.
- We do **not** create a separate "CIP backlog." That pattern always leads to CIP work being deferred and then crammed in pre-MS-07. Instead, CIP is a property of stories that have it.

### 8.3 The safety thread

- Stories that affect operator-safety state (de-energize, tag, authorize) require an extra reviewer: a **second operator SME**, not the same one who reviewed for parity.
- The reviewer's mandate: "could this misbehave in a way that injures a crew or causes a cascading outage?"
- If yes, the story does not progress until the failure mode is in an exception-path AC.

### 8.4 The parity thread

- Every story carries one of three parity claims:
  - **Strict parity** — must behave the same as legacy.
  - **Justified deviation** — behaves differently because [stated reason], approved by the operator SME with name + date.
  - **Net new** — beyond parity, justified as new business value.
- Stories with no parity claim are not Ready.

---

## 9. Estimation conventions

- **Story points** in Fibonacci: 1, 2, 3, 5, 8, 13.
- **13 means split.** A 13-point story is a smell, not a destination.
- **Spikes** are not pointed; they are timeboxed in days (max 3, extension only with justification).
- **Bugs** are not pointed; they have priority and an SLA-style time-to-fix expectation.
- **NFRs** are not pointed; they are work-tracked alongside the stories that reference them.

**Three-point estimates are reserved for Wave D (d06 estimation worksheet).** Sprint-level estimation is points; program-level estimation is three-point days. They serve different audiences and don't cross-pollinate.

**Velocity is observed, not assumed.** First three sprints set the baseline; targets only become commitments after sprint 4. Sponsor commitments based on team velocity before sprint 4 are theater.

---

## 10. Refinement cadence and roles

### 10.1 Cadence

- **Sprint length:** 2 weeks.
- **Refinement sessions:** 2 per sprint, 90 minutes each. Mid-sprint refinement covers stories for the *next* sprint.
- **Sprint planning:** end of refinement, 2 hours.
- **Daily standup:** 15 minutes, walking the board not the people.
- **Demo:** end of sprint, **operator SME present.** No SME, no demo.
- **Retro:** end of sprint, after demo, 60 minutes.

### 10.2 Roles in refinement

| Role | Responsibility in refinement |
|---|---|
| BA Lead | Brings stories. Authors AC. Owns DoR check. |
| Tech Lead — Backend / Frontend | Sizes stories. Identifies tasks. Flags dependencies. |
| Test Lead | Authors NFR addendum. Identifies test types per AC. |
| DBA Lead | Reviews stories that touch schema or migration. |
| CIP Compliance Lead | Reviews stories with CIP impact. Approves CIP AC. |
| Integration Lead | Reviews stories that touch the DMZ gateway or SCADA. |
| Operator SME | Validates parity claim. Owns the parity threshold. |
| Scrum Master / Program Director | Holds DoR/DoD discipline. Refuses to accept "ready-ish." |

### 10.3 The Scrum Master's job in refinement

The Scrum Master is the only person with the standing to say "this story is not Ready" and stop the sprint planning. **If they don't say no, no one will.** This is the single most common failure mode in regulated programs: stories enter sprints half-baked because the Scrum Master accepted them to keep cadence.

---

## 11. Acceptance & traceability

### 11.1 The traceability chain

Every code change traces back to:

```
PR  →  Task  →  Story  →  AC  →  Epic  →  Feature (Phase 0 catalog ID)
                ↓
              NFRs
              Risks
              Audit events
              CIP controls
```

This isn't optional. NERC CIP audits ask "which controls is this code change verifying?" and "what feature catalog item does this story implement?" The traceability chain is the answer.

### 11.2 Tooling expectations

- The backlog tool (Azure DevOps, Jira, or whichever the program adopts) MUST support:
  - Hierarchy: Feature → Epic → Story → Task
  - Linking: Story ↔ AC, Story ↔ NFR, Story ↔ Risk, Story ↔ CIP control
  - Custom fields: parity claim, CIP impact (Y/N + controls), audit-event type, workflow type
- If the tool can't, we don't use it. **Backlog hygiene is more important than tool preference.**

### 11.3 Linking back to the master plan

- Every Epic has a target milestone (`MS-NN`) from the d01 master plan.
- Every Story has a target sprint.
- Every Story with `cip-relevant: yes` is auto-tagged for inclusion in the per-wave NERC CIP control verification (P3.S1 in d01).

---

## 12. Templates inventory

Each template is a markdown file in [d04-templates/](d04-templates/). Use the provided templates verbatim — do not invent your own structure for stories, AC, or any of the rest. Consistency is the point.

| Artifact | Template |
|---|---|
| Epic | [epic-template.md](d04-templates/epic-template.md) |
| User Story (with INVEST checklist) | [user-story-template.md](d04-templates/user-story-template.md) |
| Acceptance Criteria (Gherkin + NFR addendum) | [acceptance-criteria-template.md](d04-templates/acceptance-criteria-template.md) |
| Task | [task-template.md](d04-templates/task-template.md) |
| Spike | [spike-template.md](d04-templates/spike-template.md) |
| Bug | [bug-template.md](d04-templates/bug-template.md) |
| NFR (latency, audit, security, availability) | [d04-templates/nfr-template.md](d04-templates/nfr-template.md) |

---

## 13. What this guide refuses to do

- **No "epic of epics"** ("themes," "initiatives," etc.). Two levels above stories is enough; more becomes a tax.
- **No "story of stories"** (sub-tasks become tasks; tasks become hours; we don't add intermediate fictional layers).
- **No estimating in time at the story level.** Points or skip estimating; never both.
- **No "spikes that produce code."** A spike that produces production code was a story; it just wasn't a Ready one.
- **No "non-functional epic."** NFRs are first-class but they are not epics. They are properties of the stories that touch them.
- **No story that bypasses the operator SME.** Even backend-only stories that have no UI have an operational impact, and the SME's "yeah, that's fine" is required for DoR.
- **No "we'll add the audit event later."** Audit is part of every state-mutating story's AC. Adding it later is how we end up with audit gaps that fail an MS-07 walkthrough.
