---
type: task
id: TASK-NNN
title: <imperative phrase: "Add ...", "Wire ...", "Refactor ...">
story: US-NNN
status: To Do | In Progress | Blocked | Done
estimate_hours: <int, optional>
owner: <single name>
---

# TASK-NNN: <imperative phrase>

> **Authoring rules:**
> - Tasks are owned by **one** person at a time. Move ownership explicitly; don't co-own.
> - One task ≈ one PR.
> - If a task is going to take more than a day, split it.
> - Tasks are not point-estimated. Hours are optional and only useful when an owner needs them.

## Description
What is being implemented or done. Two or three sentences max — the parent story carries the *why*; this task carries the *what*.

## Definition of Done for this task
- [ ] Code merged with passing CI (unit + lint + build + security scan)
- [ ] Reviewed by at least one other engineer
- [ ] (If schema-touching) DBA Lead approval
- [ ] (If CIP-relevant) CIP Compliance Lead notified
- [ ] (If integration-touching) Integration Lead notified
- [ ] No regressions introduced (existing tests still pass)

## Notes
- Affected files / modules: <list>
- Tests added: <list>
- Telemetry added: <list>

---

## Worked example

```markdown
---
type: task
id: TASK-2241
title: Add 'CardStepDeEnergized' audit event emission on Switching Card service
story: US-014
status: To Do
estimate_hours: 4
owner: a.kumar
---

# TASK-2241: Add 'CardStepDeEnergized' audit event emission on Switching Card service

## Description
Wire the audit emission into the Switching Card module's de-energize handler. Use the existing `IAuditEventEmitter` from the Audit module; populate cardId, breakerId, actorUserId, and operator-supplied reason. Cover both success and rejection paths (reason field differentiates).

## Definition of Done for this task
- [x] Unit test asserts emission on success path
- [x] Unit test asserts emission on rejection path
- [x] Integration test verifies the row lands in `Audit.AuditEvent` with correct fields
- [x] Code merged to main; CI green
- [x] Reviewed by Tech Lead — Backend
- [x] DBA Lead acked the audit-row format

## Notes
- Affected files: `src/SwitchingCard/Handlers/DeEnergizeHandler.cs`, `src/SwitchingCard.Tests/...`
- Tests added: `DeEnergizeHandler_Success_EmitsAudit`, `DeEnergizeHandler_Rejected_EmitsAudit`
- Telemetry: metric `switching_deenergize_total` already in place; no change here
```
