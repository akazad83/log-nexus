---
type: acceptance_criteria
id: AC-NNN-N
title: <criterion title>
story: US-NNN
status: Draft | Approved | Verified
verified_by_test_ids: [T-NNN]
test_types: [unit | integration | contract | uat | storm | security]
---

# AC-NNN-N: <criterion title>

> **Authoring rule:** one AC = one Gherkin scenario. If you want a second scenario, write a second AC. Do not stuff multiple Givens or alternative paths into one AC; it makes traceability and test mapping ambiguous.

## 1. Functional (Gherkin)

**Scenario:** <descriptive name>

**Given** <preconditions, including system state and actor context>
**And** <additional preconditions if needed>
**When** <the operator action or the triggering event>
**Then** <the expected observable result>
**And** <additional expectations if needed>

## 2. Non-functional addendum (where applicable — omit rows that don't apply)

| Aspect       | Criterion |
| ------------ | --------- |
| Latency      | P95 < <N>ms server-side; P99 < <N>ms |
| Throughput   | Sustained <N> ops/sec without P95 degradation |
| Availability | Operates with <named upstream> degraded; surfaces <visible state> to operator |
| Audit        | AuditEvent type '<name>' emitted with fields <list>; chain-hash verified |
| Security     | Action requires AD role '<role>'; mTLS used end-to-end; logged to SIEM |
| CIP control  | Verified against CIP-<NNN> R<N>; evidence in <walkthrough log> |
| Telemetry    | Log line emitted with <required fields>; metric '<name>' incremented |

## 3. Verification
- **Test ID(s):** T-NNN, T-NNN
- **Test type(s):** <unit | integration | contract | UAT | storm | security>
- **Verified by:** <name> / <date>
- **Evidence:** <link to test run, audit log query, walkthrough notes>

---

## Worked examples

### Example 1: Happy-path AC (functional + audit + security)

```markdown
---
type: acceptance_criteria
id: AC-014-1
title: Operator de-energizes an active transmission card — happy path
story: US-014
status: Approved
verified_by_test_ids: [T-2014]
test_types: [integration, uat]
---

# AC-014-1: Operator de-energizes an active transmission card — happy path

## 1. Functional (Gherkin)

**Scenario:** District operator de-energizes a breaker on an active transmission card

**Given** a transmission switching card C-1042 is in state 'Open' with the Notify and Create steps complete
**And** the operator is authenticated as a member of AD group 'DistrictOperator-Region5'
**And** breaker BKR-501 is on the card and is currently 'Closed' in last-known-XA21 state
**When** the operator clicks 'De-energize' for BKR-501 with reason 'Storm response — feeder F-12'
**Then** the card state advances from 'Open' to 'DeEnergized'
**And** an AuditEvent of type 'CardStepDeEnergized' is written with cardId=C-1042, breakerId=BKR-501, actorUserId, reason
**And** the Tag step becomes available on the operator screen within 200ms of the click

## 2. Non-functional addendum

| Aspect | Criterion |
| ------ | --------- |
| Latency | P95 < 200ms server-side; P99 < 500ms |
| Audit | AuditEvent type 'CardStepDeEnergized' emitted with cardId, breakerId, actorUserId, reason; chain-hash verified |
| Security | Action requires AD role 'DistrictOperator-RegionN'; mTLS used end-to-end; SIEM event 'switching.deEnergize.success' emitted |
| Telemetry | Log line with traceId, correlationId, cardId, breakerId; metric 'switching_deenergize_total' incremented |
```

### Example 2: Exception-path AC

```markdown
---
type: acceptance_criteria
id: AC-014-2
title: De-energize rejected when card is not in 'Open' state
story: US-014
status: Approved
verified_by_test_ids: [T-2014b]
test_types: [integration]
---

# AC-014-2: De-energize rejected when card is not in 'Open' state

## 1. Functional (Gherkin)

**Scenario:** Operator attempts de-energize on a closed card

**Given** a transmission switching card C-1042 is in state 'Closed'
**And** the operator is authenticated as a member of AD group 'DistrictOperator-Region5'
**When** the operator clicks 'De-energize' for any breaker on the card
**Then** the system rejects the action with HTTP 409 Conflict
**And** the operator screen shows the error: "Cannot de-energize on a closed card. Open a new card to record additional state changes."
**And** an AuditEvent of type 'CardStepDeEnergizeRejected' is written with cardId, attemptedBreakerId, actorUserId, reason='card-not-open'
**And** no card state mutation occurs

## 2. Non-functional addendum

| Aspect | Criterion |
| ------ | --------- |
| Audit | AuditEvent type 'CardStepDeEnergizeRejected' emitted; rejected actions are still audited |
| Security | Same role + mTLS enforcement as success path; rejection logged to SIEM |
```

### Example 3: NFR-only AC (used for storm-path verification)

```markdown
---
type: acceptance_criteria
id: AC-014-NF
title: De-energize maintains storm-path performance
story: US-014
status: Approved
verified_by_test_ids: [T-STORM-014]
test_types: [storm]
---

# AC-014-NF: De-energize maintains storm-path performance

## 1. Functional (Gherkin)

**Scenario:** Storm-load condition with de-energize actions interleaved

**Given** the storm-test harness drives 1000 SCADA breaker-trip events per minute for 30 minutes
**And** during the storm, 50 operator-initiated de-energize actions are issued
**When** the storm completes
**Then** all de-energize actions complete with P95 server-side latency < 200ms
**And** zero de-energize audit events are missing
**And** zero card state inconsistencies are observable post-storm

## 2. Non-functional addendum

| Aspect | Criterion |
| ------ | --------- |
| Throughput | 1000 events/min sustained for 30 min, no degradation in operator-action P95 |
| Audit | Zero loss across full storm window; chain-hash verifies clean |
| Availability | OpNET tier remains 100% available throughout |
```
