---
type: user_story
id: US-NNN
title: <one-line title>
epic: EPIC-NN
status: New | Ready | In Progress | In Review | Done
points: <1 | 2 | 3 | 5 | 8 | 13>
sprint: <S-NN or unscheduled>
labels: [transmission | distribution | dielectric | steam, scada, audit, cip-relevant, parity-critical, storm-path, ui, backend, integration]
parity_claim: strict | justified-deviation | net-new
parity_approver: <operator SME name> / <date>
cip_impact: yes | no
cip_controls: [CIP-005 R1, CIP-007 R4, ...]   # populate only if cip_impact is yes
---

# US-NNN: <title>

**As a** <District Operator | Field Crew | Supervisor | Auditor | System>
**I want** <action>
**So that** <outcome>

## Context
2-4 sentences. Why this story now? What does the operator (or other actor) experience today vs after?

## Acceptance criteria
At least four ACs:
- AC-NNN-1 (happy path) — link
- AC-NNN-2 (exception path) — link
- AC-NNN-3 (audit) — link
- AC-NNN-4 (security/authorization) — link

NFR addendum scope:
- NFR-NN (latency)
- NFR-NN (audit completeness)

## Notes & dependencies
- Depends on US-NNN
- Touches integrations: <XA21 | Rapid Restore | Asset Mgmt | GIS | Notification>
- Schema impact: <none | new column | new table | partition change>
- Touches the storm-path: yes | no

## INVEST self-check
- [ ] **I**ndependent — can be developed without forced ordering against unrelated stories
- [ ] **N**egotiable — title and AC describe outcome, not implementation
- [ ] **V**aluable — operator-visible (or auditor-visible) value within this story
- [ ] **E**stimable — team can size with confidence; not blocked on a spike
- [ ] **S**mall — fits in one sprint, ≤8 points (13 means split)
- [ ] **T**estable — at least one Gherkin scenario per AC

## DoR checks (BA owns; SM gates)
- [ ] Linked to Epic and to original Feature catalog ID(s)
- [ ] Happy + exception + audit + security AC drafted
- [ ] NFR refs identified
- [ ] Operator SME has reviewed (date + name in the story)
- [ ] CIP impact assessed; CIP Compliance Lead reviewed if cip_impact = yes
- [ ] Dependencies enumerated
- [ ] Estimate ≤8 points (or split before sprint planning)
- [ ] INVEST checklist passes

## DoD checks (Tech Lead + QA + Operator SME)
- [ ] All AC verified by automated tests (unit + integration as appropriate)
- [ ] Audit events emitted and verified in audit stream
- [ ] NFRs verified per their verification method
- [ ] CIP-relevant controls verified (where applicable)
- [ ] Code merged to main with passing CI (lint, build, unit, integration, security scan)
- [ ] Operator-walkthrough demo with operator SME completed in SIT or higher
- [ ] Telemetry verified (logs structured + enriched, metrics emitted, traces propagated)
- [ ] Documentation updated (operator-facing if UX changes; runbook if ops-affecting)
- [ ] No P1/P2 bugs open against this story

---

## Worked example (workflow-step slice for transmission)

```markdown
---
type: user_story
id: US-014
title: Operator de-energizes a transmission breaker on the active card
epic: EPIC-01
status: Ready
points: 5
sprint: S-07
labels: [transmission, scada, audit, cip-relevant, parity-critical, storm-path, ui, backend]
parity_claim: strict
parity_approver: J. Reyes / 2026-09-12
cip_impact: yes
cip_controls: [CIP-007 R4]
---

# US-014: Operator de-energizes a transmission breaker on the active card

**As a** District Operator
**I want** to record the de-energize step on an active transmission switching card with the breaker reference and a timestamp
**So that** the next workflow step (Tag) is unblocked and the audit trail captures who de-energized which device when

## Context
Today (legacy), the operator records de-energize as step 3 of 8 on the switching card screen; the system stamps user, time, and the affected breaker, and unlocks the Tag step. We must preserve this exactly. Storm-path: yes — this can run during a multi-circuit cascade.

## Acceptance criteria
- AC-014-1 (happy) — operator clicks De-energize on an open card; system advances state and emits event
- AC-014-2 (exception) — card is not in the right state; system rejects with operator-readable error
- AC-014-3 (audit) — AuditEvent type 'CardStepDeEnergized' emitted with cardId, breakerId, actorUserId
- AC-014-4 (security) — action requires AD role 'DistrictOperator'; mTLS enforced

NFR refs:
- NFR-01 (operator latency P95 <200ms server-side)
- NFR-07 (audit completeness)
- NFR-12 (CIP-007 R4 coverage)
```
