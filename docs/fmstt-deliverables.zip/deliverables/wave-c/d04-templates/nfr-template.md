---
type: nfr
id: NFR-NN
title: <descriptive name>
category: latency | throughput | availability | audit | security | observability | usability | recoverability | scalability | maintainability
status: Draft | Approved | Baselined | Verified
critical_path: yes | no   # yes if breach blocks MS-06, MS-07, MS-08, MS-10, or MS-13
linked_stories: [US-NNN, US-NNN]
linked_controls: [CIP-007 R4, ISO 25010-Performance Efficiency, ...]
owner: <workstream lead>
verification_method: unit | integration | load | storm | dashboard | audit-query | walkthrough | automated-monitor
verification_frequency: per-story | per-sprint | per-milestone | continuous
---

# NFR-NN: <descriptive name>

> **Authoring rules:**
> - One NFR = one quantitative target. If you have two targets, write two NFRs.
> - The target must be **measurable with a defined method**. "Fast" is not an NFR; "P95 server-side latency < 200ms measured by load test T-LOAD-01" is.
> - NFRs are owned by a workstream lead, not the BA.
> - Verification frequency is explicit. NFRs that are "verified once at MVP" are not NFRs — they are MVP exit criteria.

## 1. Statement
A single sentence describing the requirement. Plain English, no implementation.

## 2. Quantitative target
The number(s) or condition(s) that define pass/fail. State both nominal and degraded-mode targets if relevant.

## 3. Verification method
How we measure. Specific test, specific dashboard, specific audit query, specific walkthrough script.

## 4. Verification frequency
How often the NFR is re-verified. Per-story is for properties verified during DoD; per-sprint for soak-style; per-milestone for gate verification; continuous for production monitoring.

## 5. Failure mode
What we do if the NFR fails verification. Block the milestone? Open a bug? Open a Spike? Trigger a rollback?

## 6. Trade-offs
What does this NFR cost? What is gained? Names the implementation cost or operational cost so the team can revisit if priorities shift.

## 7. Related risks (from d01 risk register)
- R-NNN — relevance

## 8. Linked stories
- US-NNN
- US-NNN

## 9. History
| Date | Change | Owner |
|------|--------|-------|
| <date> | Drafted | <name> |
| <date> | Approved at sprint planning | <name> |
| <date> | Baseline measured: <result> | <name> |

---

## Worked examples — one per category

### Example 1: Latency

```markdown
---
type: nfr
id: NFR-01
title: Operator-perceived latency on the hot operator path
category: latency
status: Approved
critical_path: yes
linked_stories: [US-007, US-014, US-018, ...]
linked_controls: [ISO 25010-Performance Efficiency]
owner: Solution Architect
verification_method: load
verification_frequency: per-sprint
---

# NFR-01: Operator-perceived latency on the hot operator path

## 1. Statement
Operator actions on the active card screen complete fast enough that operators do not perceive the new system as slower than the legacy system.

## 2. Quantitative target
- Read operations: P95 server-side < 50ms; P99 < 150ms
- Single-card writes (de-energize, tag, authorize, etc.): P95 server-side < 200ms; P99 < 500ms
- Storm-condition: same targets hold under 1000 events/min sustained for 30 min

## 3. Verification method
Automated load test T-LOAD-01 in pre-prod, run on every sprint demo build. Storm verification by T-STORM-01 on every milestone gate.

## 4. Verification frequency
Per-sprint for nominal; per-milestone for storm.

## 5. Failure mode
Block sprint demo if NFR fails. Open a P1 bug. Trigger an architecture review if it fails twice consecutively.

## 6. Trade-offs
Drives Dapper-on-hot-path (AD-10 in d07), AG sync replica (DB-07 in d09), and disciplined Query Store maintenance.
```

### Example 2: Audit (completeness)

```markdown
---
type: nfr
id: NFR-07
title: Audit completeness across all state-mutating workflow actions
category: audit
status: Baselined
critical_path: yes
linked_stories: [most stories with state mutation]
linked_controls: [CIP-007 R4]
owner: DBA Lead
verification_method: audit-query
verification_frequency: continuous
---

# NFR-07: Audit completeness across all state-mutating workflow actions

## 1. Statement
Every action that mutates switching workflow state emits exactly one audit event. No loss; no duplication.

## 2. Quantitative target
- Loss rate: 0
- Duplication rate: 0 (idempotency at the audit emitter level)
- Chain-hash verification: passes nightly job; zero gaps in chain across any 7-day window

## 3. Verification method
- Automated reconciliation between application-emitted action log and `Audit.AuditEvent` table on every sprint build
- Nightly chain-hash verification job in pre-prod and prod
- Storm-test reconciliation per MS-06

## 4. Verification frequency
Continuous in production; per-sprint in pre-prod.

## 5. Failure mode
Any non-zero loss is a P1 bug. Block the next milestone. Trigger an architecture review.

## 6. Trade-offs
Drives ledger updatable tables for Audit (DB-04), per-row chain-hash (decided in SPIKE-031), nightly verification job. ~10-15% write overhead on audit.

## 7. Related risks
- R-007 — ledger overhead under storm load
```

### Example 3: Security (NERC CIP)

```markdown
---
type: nfr
id: NFR-12
title: CIP-007 R4 security event coverage
category: security
status: Approved
critical_path: yes
linked_stories: [stories with cip_impact: yes]
linked_controls: [CIP-007 R4]
owner: CIP Compliance Lead
verification_method: walkthrough
verification_frequency: per-milestone
---

# NFR-12: CIP-007 R4 security event coverage

## 1. Statement
All authentication, authorization, administrative, and ESP-traversal events emit log lines to the SIEM with sufficient detail for CIP-007 R4 monitoring.

## 2. Quantitative target
Auditor walkthrough at MS-07 confirms:
- Every login (success and failure) is in SIEM with user, source IP, outcome, timestamp
- Every role grant/revoke is in SIEM
- Every cross-EAP API call (OpNET → DMZ) is in SIEM with target service, source service, mTLS status
- Every administrative action is in SIEM with actor and target
- Time correlation: NTP-aligned across all sources within 50ms

## 3. Verification method
Pre-cutover NERC CIP audit walkthrough (P4.04) plus storm-test SIEM ingest verification (P2a.27).

## 4. Verification frequency
Per-milestone (MS-07, MS-10).

## 5. Failure mode
Block the milestone gate. CIP Compliance Lead engages directly with CIP Senior Manager.

## 6. Trade-offs
Drives the structured-logging contract, the OpNET SIEM retention policy, and the redacted-summary mirror to CorpNET (d07 §7.1, d10 §3.2).
```

### Example 4: Availability (degraded-mode)

```markdown
---
type: nfr
id: NFR-03
title: Operator workflow availability under upstream-degraded conditions
category: availability
status: Approved
critical_path: yes
linked_stories: [US-016, US-017, US-018]
linked_controls: [internal SLO]
owner: Solution Architect
verification_method: integration
verification_frequency: per-sprint
---

# NFR-03: Operator workflow availability under upstream-degraded conditions

## 1. Statement
Operators can continue running the switching workflow when individual upstream integrations are degraded, with explicit operator-visible indicators of degraded mode.

## 2. Quantitative target
- SCADA wrapper down: card creation falls back to manual; existing cards continue; banner indicates "SCADA event ingest degraded"
- Asset Mgmt sync down: cached refdata used; banner indicates "Reference data may be stale (last sync N min ago)"
- Notification service down: outbound notifications queue; no operator workflow impact; banner indicates "Outbound notifications delayed"
- Authorization service down: workflow stops at the Authorize step; **no fallback** (safety > availability per d10 §4.3)

## 3. Verification method
Per-integration chaos drill (kill the integration, run the workflow) executed in SIT every sprint.

## 4. Verification frequency
Per-sprint.

## 5. Failure mode
Any unexpected hard failure (workflow blocks where banner is required) is a P1 bug.
```
