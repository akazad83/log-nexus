---
type: spike
id: SPIKE-NNN
title: <the question, phrased as a question>
status: Open | In Progress | Closed (decided) | Closed (revealed wrong question)
timebox_days: <max 3; extension only with written justification>
owner: <single name>
sprint: <S-NN>
blocks: [US-NNN, US-NNN]
---

# SPIKE-NNN: <the question>

> **Authoring rules:**
> - Title is a question, not a statement.
> - Timebox is **3 days max**. If you need more, the spike is too broad — split it or accept the partial answer.
> - **Spikes never produce production code.** If they do, it was a story.
> - Output is a written decision posted as a comment on this ticket.

## 1. Decision needed
The specific, decision-shaped question this spike answers. One sentence. Avoid "explore", "investigate" — those produce open-ended notes that don't unblock anything. State the decision the team will make at the end.

## 2. Why now
What downstream work is blocked, and which sprint slot it sits in.

## 3. Approach
What we'll do to answer the question. Bullet list, ≤5 items. Specific.

## 4. Output
Always one of:
- A **decision record** with the choice made and the reason
- A **recommendation** with options and trade-offs (when the decision properly belongs to a different role/forum)
- A **write-up of why the question was wrong** (the second-most-useful spike outcome)

## 5. Stop conditions
- Timebox elapsed
- Question answered with confidence
- Question revealed as the wrong question

## 6. Decision (filled in at close)
- **Decision:**
- **Rationale:**
- **Implications for backlog:** stories opened, stories rewritten, stories cancelled

---

## Worked example

```markdown
---
type: spike
id: SPIKE-031
title: Should the Audit module batch chain-hash computation, or compute per-row?
status: Closed (decided)
timebox_days: 3
owner: m.chen
sprint: S-09
blocks: [US-021, US-022, US-024]
---

# SPIKE-031: Should the Audit module batch chain-hash computation, or compute per-row?

## 1. Decision needed
At what granularity does the audit chain-hash get computed: per-row at insert, or in a 1-second windowed batch?

## 2. Why now
US-021/022/024 all hit the audit hot path. R-007 in d01 names ledger-audit overhead as a risk. We need to decide before US-021 enters refinement so the API contract is settled.

## 3. Approach
- Build a benchmark harness inserting 1000 rows/sec sustained for 5 minutes
- Run two configurations: per-row hash, 1-second batch
- Measure: P95 insert latency, audit gap risk if the service crashes mid-batch
- Sanity-check chain integrity in both configurations

## 4. Output
Decision record (this ticket).

## 5. Stop conditions
- Timebox elapsed (3 days)
- One configuration is conclusively better on both perf and integrity
- Both configurations fail to meet NFR-07 (audit completeness) — escalate

## 6. Decision
- **Decision:** Per-row hash.
- **Rationale:** P95 insert latency is 14ms (per-row) vs 11ms (batch); batch saves 3ms but risks loss of up to 1 second of audit on crash, which fails NFR-07. The 3ms is well under our NFR-01 budget and not worth the integrity risk.
- **Implications for backlog:**
  - US-021/022/024 proceed with per-row
  - SPIKE-031 closed
  - NFR-07 amended with explicit "no batched audit" clause
```
