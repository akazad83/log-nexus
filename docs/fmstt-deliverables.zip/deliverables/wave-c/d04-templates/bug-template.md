---
type: bug
id: BUG-NNN
title: <one-line summary describing observable symptom>
priority: P1 | P2 | P3 | P4
status: New | Triaged | In Progress | Fixed | Verified | Closed
detected_in: dev | sit | pre-prod | prod | uat
detected_during: sprint-N | uat-cycle-N | storm-test | dr-drill | demo
operator_visible: yes | no
audit_relevant: yes | no
cip_relevant: yes | no
safety_relevant: yes | no
related_stories: [US-NNN]
related_risks: [R-NNN]
target_fix: sprint-N | hotfix | next-release
---

# BUG-NNN: <one-line summary>

> **Authoring rules:**
> - Title describes the **observable symptom**, not the suspected cause.
> - Priority is set at triage, not by the reporter.
> - **Audit-relevant bugs and safety-relevant bugs are P1 by default** unless explicitly downgraded with rationale.

## 1. Steps to reproduce
1. ...
2. ...
3. ...

## 2. Expected
What should happen.

## 3. Actual
What happens instead.

## 4. Logs / correlation IDs
- traceId: ...
- correlationId: ...
- cardId (if applicable): ...
- relevant log lines: ...

## 5. Operator impact
What the operator sees and what they cannot do. State whether a workaround exists.

## 6. Audit impact
**Required for any bug that touches the audit pipeline.** Identify whether audit events are missing, incorrect, duplicated, or out-of-order. If yes, the bug is automatically P1.

## 7. Safety impact
**Required for any bug touching de-energize, tag, authorize, or breaker-close paths.** Could this bug cause an injury or a cascading outage? If yes, the bug is automatically P1 and gets a second operator-SME reviewer (per d03 §8.3).

## 8. CIP impact
**Required for any bug touching authentication, authorization, audit logging, or ESP boundary behavior.** Identify the CIP control(s) affected.

## 9. Workaround
Is there one? What does the operator do today to work around it?

## 10. Triage notes
- **Priority rationale:** <why this priority>
- **Remediation owner:** <name>
- **Target fix:** <sprint or release>
- **Discovered:** <how — operator report, automated test, monitoring alert, audit reconciliation>

## 11. Resolution (filled in at close)
- **Root cause:** <one paragraph>
- **Fix:** <PR link>
- **Verification:** <test ID, walkthrough date>
- **Follow-ups:** <other bugs filed, NFRs amended, retro topic>

---

## Priority guide

| Priority | Operator-visible severity | Examples |
|---|---|---|
| **P1** | Blocks operator workflow OR threatens safety OR audit gap OR CIP gap | Cannot complete de-energize; audit event lost; auth bypass |
| **P2** | Significant degradation but workaround exists | Card list fails to refresh after 30s; manual refresh works |
| **P3** | Minor functional defect or visible polish issue | Tooltip shows wrong device label; log message has typo |
| **P4** | Cosmetic or non-functional polish only | Spacing on error toast; help text wording |

> Rule: any bug discovered during a UAT cycle that an operator describes with words like "I can't" or "I'd have to" is at minimum P2 by definition. The reporter doesn't get to declare it P3 because it has a workaround they can technically perform.

---

## Worked example

```markdown
---
type: bug
id: BUG-409
title: De-energize on storm-path drops audit event ~1 in 10000 under load
priority: P1
status: Triaged
detected_in: pre-prod
detected_during: storm-test
operator_visible: no
audit_relevant: yes
cip_relevant: yes
safety_relevant: no
related_stories: [US-014]
related_risks: [R-007]
target_fix: sprint-15
---

# BUG-409: De-energize on storm-path drops audit event ~1 in 10000 under load

## 1. Steps to reproduce
1. Run storm-test harness at 1000 events/min sustained
2. Interleave 50 operator de-energize actions
3. Reconcile audit stream against expected emissions

## 2. Expected
Every operator de-energize emits exactly one 'CardStepDeEnergized' audit event.

## 3. Actual
~1 in 10000 actions show no audit event. Card state advances correctly; only the audit row is missing. Chain-hash continuity is intact (so the missing event isn't visible from chain validation alone — only via per-action reconciliation).

## 4. Logs / correlation IDs
- Reproducible with traceId 0x9e2f... in the storm-test run logs
- Correlation: in dropped cases, the audit emit task fired a TimeoutException to the message bridge

## 5. Operator impact
None visible — the workflow completes normally. The defect is invisible to the operator and only surfaces in audit reconciliation.

## 6. Audit impact
Audit gap. NFR-07 (audit completeness) violated. P1 mandatory.

## 7. Safety impact
None directly — card state is consistent, breaker state is consistent. The audit gap could however blind a post-incident investigation. Treated as P1 by audit-impact rule.

## 8. CIP impact
CIP-007 R4 — audit completeness. Auditor walkthrough would surface this.

## 9. Workaround
None. The reconciliation job will flag the gap; operations can manually create a corrective audit row, but that's a stopgap, not a fix.

## 10. Triage notes
- **Priority rationale:** Audit gap = P1 by rule
- **Remediation owner:** Tech Lead — Backend
- **Target fix:** sprint 15
- **Discovered:** automated reconciliation against storm-test emit log
```
