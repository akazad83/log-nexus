---
type: epic
id: EPIC-NN
title: <one-line outcome statement>
status: Discovery | Refinement | Active | Done | Cancelled
owner: <Tech Lead or Solution Architect>
target_milestone: MS-NN
feature_catalog_refs: [FC-NN, FC-NN]
workflow_types: [transmission | distribution | dielectric | steam]
parity_class: strict | mixed | net-new
---

# EPIC-NN: <descriptive title>

> **Naming rule:** title is a Sponsor-recognizable outcome. Not a system name, not a layer ("backend"), not a workstream.

## 1. Why
The user-visible problem this Epic addresses, in 2-4 sentences. State the operator outcome (or auditor outcome, or sponsor outcome) explicitly. Anchor to the original feature catalog item(s).

## 2. What
The outcome we expect to see. Not a solution. Avoid implementation nouns where possible.

## 3. Out of scope
Bullet list of things this Epic does **not** cover, especially adjacent capabilities that an unwary reader might assume are in scope.

## 4. Success criteria
Measurable outcomes the Sponsor would recognize:

- <metric or behavior with a number>
- <metric or behavior>
- <metric or behavior>

## 5. NFR refs
- NFR-NN
- NFR-NN

## 6. Risks (from d01 risk register)
- R-NNN — <one-line restatement of relevance>

## 7. Stories
Linked downstream stories. Updated as refinement progresses.

- US-NNN — <title>
- US-NNN — <title>

## 8. Parity claim summary
Across the stories in this Epic:

- **Strict-parity stories:** N
- **Justified-deviation stories:** N
- **Net-new stories:** N

If non-zero deviations or net-new, summarize each with the operator-SME approver and date.

## 9. CIP impact
- **Scoped:** Yes / No
- **Controls touched:** CIP-005 R1, CIP-007 R4, CIP-010 R1, ... (where applicable)
- **CIP Compliance Lead approval:** name / date / link to walkthrough notes

## 10. Cross-Epic dependencies
Other Epics that must reach a checkpoint before stories in this Epic can complete.

---

## Worked example (transmission switching, MVP-scope)

```markdown
---
type: epic
id: EPIC-01
title: Operator runs an end-to-end transmission switching card on the new system
status: Refinement
owner: Solution Architect
target_milestone: MS-08
feature_catalog_refs: [FC-12, FC-13, FC-14]
workflow_types: [transmission]
parity_class: strict
---

# EPIC-01: Operator runs an end-to-end transmission switching card on the new system

## 1. Why
District operators today drive transmission switching from SCADA event to closure on the legacy system. Modernization succeeds only if the operator can do the same workflow on the new stack with no degradation in mental-model fit. This is the MVP gate (MS-08).

## 2. What
A district operator can take a transmission breaker-trip event from XA21 through all 8 workflow steps to closure on the new system, with operator-SME approval that UX matches legacy mental model and storm-load behavior matches MS-06.

## 3. Out of scope
- Distribution, dielectric, steam workflows (P3 sub-waves)
- Reporting tier in CorpNET (Wave 5)
- Field crew Rapid Restore screen redesign (out per project scope)

## 4. Success criteria
- Operator-SME approval recorded for all 9 workflow events
- Storm test (MS-06) passes 1000 events/min sustained for 30 min
- CIP rehearsal (MS-07) passes
- Audit completeness verified — zero missing events on the workflow path

## 5. NFR refs
- NFR-01 (operator latency P95)
- NFR-04 (storm throughput)
- NFR-07 (audit completeness)
- NFR-12 (CIP-007 R4 event coverage)

## 6. Risks
- R-001 — hidden 4GL business rules surface during the workflow state machine
- R-003 — SCADA wrapper protocol fidelity
- R-008 — operator change-management resistance
```
