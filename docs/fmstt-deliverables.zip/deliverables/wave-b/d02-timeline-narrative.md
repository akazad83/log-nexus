# Phase & Milestone Timeline — Brutal-Honesty Narrative
**Deliverable #2 — Wave B: Planning Backbone**
**Status:** Phase 1 baseline. Companion to [d01 master plan workbook](d01-master-plan-spec.md).
**Output:** `02-timeline-narrative.docx` (generated from this markdown by [generate_timeline_narrative_docx.py](generate_timeline_narrative_docx.py)).

---

## 1. Why this document exists, and what it refuses to do

A timeline that gives a single date per milestone is a fiction in regulated, safety-adjacent OT modernization. The goal of this narrative is to:

- State **ranges**, not point estimates.
- For each phase, name the **drivers of variance** — the specific things that move the date forward or backward.
- Identify the **five highest-leverage swing factors** for the program as a whole.
- Give a **bet-on number** for the central case, with the caveat clear.

What this document refuses to do:

- Pretend that aggressive dates are achievable just because the sponsor wants them.
- Hide buffer in task durations rather than naming it as a risk reserve.
- Smooth dependencies that aren't yet committed (XA21 vendor calendar, internal CA team, CIP Senior Manager signoff) as if they are already locked.

If a date in this document conflicts with a date elsewhere in the plan, **this document is wrong** — fix it. The workbook is the operational source of truth.

---

## 2. Anchors and program envelope

| Anchor | Value | Source |
|---|---|---|
| `T0` (Phase 1 start) | 2026-05-01 | Day after Wave A ratification, assumed within review window |
| Program envelope | 24–30 months from 2026-04-28 | Ratified default, A-003 |
| Earliest credible end | 2028-04-28 | Lower bound of envelope |
| Latest credible end | 2028-10-28 | Upper bound of envelope |
| Central bet for program close | 2028-12-15 | Includes Hypercare; ~32 months from `T0` |

**Note the gap.** The ratified envelope says 24–30 months and the central bet is ~32. That is intentional. The 24–30 figure is "build + cutover"; my central bet adds 3–4 months of Hypercare, because closing the program before Hypercare is the way you discover defects in production while operators are most loaded. Hypercare is non-negotiable on safety-critical OT; if the sponsor demands a "go-live = program close" framing, that's a governance risk to flag in the Wave D resource memo.

---

## 3. Phase-by-phase ranges

For each phase: **Best — Likely — Worst**, in calendar duration. Best assumes everything goes right; Worst assumes the named drivers materialize. Likely is what I'd bet on if forced.

### 3.1 Phase 0 — Discovery
**Status: complete.** No estimate to give.

### 3.2 Phase 1 — Detailed Design

| Best | Likely | Worst |
|---|---|---|
| 4 mo (16 wk) | 5 mo (22 wk) | 7 mo (30 wk) |

**What pushes toward Best:**
- Wave A foundations ratified within 2 weeks of delivery.
- CIP impact rating confirmed Medium quickly; no debate.
- Operator SMEs deliver their committed 8 hrs/wk on time.
- The BA Lead is in seat from `T0`.

**What pushes toward Worst:**
- The CIP rating debate with the CIP Senior Manager runs 6+ weeks. (R-004.)
- Hidden 4GL business rules surface during bounded-context detailed design and force backlog rework. (R-001.)
- XA21 SOAP trace recording from the vendor takes >8 weeks to procure. (DEP-01.)

**My bet:** 5 months. This phase is unusually well-scoped because Phase 0 is genuinely complete; the risk is operator availability and CIP scoping, both of which are organizational, not technical.

### 3.3 Phase 2a — MVP Build

| Best | Likely | Worst |
|---|---|---|
| 6 mo (26 wk) | 7.5 mo (32 wk) | 10 mo (43 wk) |

**Scope of MVP:** one core app, one workflow type (transmission switching), one or two pilot districts, the full 8-step workflow vertically. Not all six core apps. Not all districts. The "MVP" word matters.

**What pushes toward Best:**
- Pre-prod environments are stood up by week 4 (DEP-02 on time).
- mTLS rollout is unblocked (DEP-03 on time).
- The team's first SCADA wrapper integration test passes within ~10 weeks of `T0a` (Phase 2a start).
- Operator SMEs continue at committed cadence.

**What pushes toward Worst:**
- SCADA wrapper protocol fidelity defects surface late. (R-003.)
- Storm test fails first attempt and re-architecture is needed in the message bridge. (R-007.)
- AG sync replica IPSec performance regresses under load. (R-005.)

**My bet:** 7.5 months. The MVP build is the place where most utility modernization programs spend their hidden budget — not on the workflow code, on the SCADA-and-storm work.

### 3.4 Phase 2b — MVP UAT & Operator Approval Gate

| Best | Likely | Worst |
|---|---|---|
| 6 wk | 10 wk | 16 wk |

**This is the most leveraged phase in the entire program.** Failing here doesn't just slip the schedule — it threatens the program's funding because operator approval is the MVP gate the sponsor will use to decide whether to continue.

**What pushes toward Best:**
- UAT cycle 1 returns ≤30 medium-or-major defects (industry-typical for first vertical slice on a parity-with-legacy modernization is 50–100).
- Operators perceive UX as faithful to the legacy mental model from cycle 1.
- Storm test re-run passes with operators in the loop.

**What pushes toward Worst:**
- UAT cycle 1 returns >100 defects, mostly UX-fidelity rather than functional. (R-008.)
- Operator change-management resistance hardens — driven by either UX miss or political dynamics inside the operator org.
- A regression in cycle 2 forces a third UAT cycle. The third cycle is the worst-case path; it adds 4+ weeks.

**My bet:** 10 weeks. With the brutal-honesty caveat that this phase has the widest variance in the entire plan; if you only over-invest in one area, over-invest in operator co-design during Phase 1 to compress this phase.

### 3.5 Phase 3 — Incremental Build

| Best | Likely | Worst |
|---|---|---|
| 7 mo (30 wk) | 9 mo (39 wk) | 13 mo (56 wk) |

**Sub-waves:**
- W1: distribution workflow (uses MVP foundations, ~6 wk)
- W2: dielectric + steam workflows (~6 wk)
- W3: monitor apps batch 1 — 10–15 apps, mostly thin wrappers around existing data, ~10 wk
- W4: monitor apps batch 2 — 10–15 apps, ~10 wk
- W5: full integration coverage (GIS, WMS, Notification, etc.), ~6 wk
- W6: CorpNET reporting tier, ~4 wk
- W7: data-migration cutover-rehearsal scripts, ~6 wk

Sub-waves overlap; the duration above is the critical-path total, not the sum.

**What pushes toward Best:**
- The MVP foundations are genuinely reusable (architecture decisions in d07 actually held up).
- Monitor apps turn out to be repetitive and benefit from a code-gen approach by mid-W3.
- The team grew at the planned rate through Phase 2.

**What pushes toward Worst:**
- Monitor apps turn out to have hidden business logic the inventory missed. (R-001 again.)
- Reference-data drift (R-011) corrupts Wave 1 distribution testing and forces a rework of the reference-sync mechanism mid-W3.
- The team didn't grow as planned, or grew with the wrong skill mix.

**My bet:** 9 months. The 30–35 monitor apps are individually small but cumulatively large; they are also the place where the legacy team's tribal knowledge is most concentrated.

### 3.6 Phase 4 — Full UAT

| Best | Likely | Worst |
|---|---|---|
| 8 wk | 12 wk | 18 wk |

**What pushes toward Best:**
- Integration UAT finds <10 cross-system regressions.
- Cutover dry-run #1 succeeds; dry-run #2 (with rollback) is procedural.
- 72-hour soak passes without intervention.

**What pushes toward Worst:**
- A cross-system regression (typically reference-data-driven) requires schema adjustments. (R-011.)
- DR drill exposes a backup-restore gap. (CIP-009 R3 finding.)

**My bet:** 12 weeks.

### 3.7 Phase 5 — Cutover (district-by-district)

| Best | Likely | Worst |
|---|---|---|
| 10 wk | 14 wk | 22 wk |

**Per-district mechanics:** 4 districts assumed. Per-district parallel run 4–6 weeks (A-008). Districts overlap to keep enterprise-wide dual-entry within the 8-week cap. Cutover execution per district is a single weekend window. Hypercare for the just-cut district runs 2 weeks post-cutover, then the next district begins.

```
       wk 1   2   3   4   5   6   7   8   9   10  11  12  13  14
D1     [parallel run────][cut][hyper]
D2          [parallel run────][cut][hyper]
D3                    [parallel run────][cut][hyper]
D4                              [parallel run────][cut][hyper]
                          ↑ enterprise-wide cap window (≤8 wk overlap)
```

**What pushes toward Best:**
- D1 cutover defect rate ≤5 minor; no rollback.
- Operators are confident enough by D2 that the parallel-run window for D2/D3 can be compressed.

**What pushes toward Worst:**
- D1 cutover hits an unexpected reference-data inconsistency or audit reconciliation gap that wasn't caught in Phase 4. (R-010.)
- D2 cannot start until D1 stabilizes; cascade through D3, D4.
- A vendor-side XA21 change calendar conflict forces a 2-week pause. (R-012.)

**My bet:** 14 weeks. The 22-week worst case is what blows the 30-month envelope and forces the conversation about scope reduction or program extension.

### 3.8 Phase 6 — Hypercare

| Best | Likely | Worst |
|---|---|---|
| 12 wk | 16 wk | 24 wk |

**What pushes toward Best:**
- Defect rate falls off cleanly week 4–6 post-final-cutover.
- Knowledge transfer to ops team completes by week 8.

**What pushes toward Worst:**
- A latent issue surfaces in one of the storm scenarios that didn't occur in Phase 4 or in early Hypercare.
- Knowledge transfer drags because ops team availability competes with operational duties.

**My bet:** 16 weeks.

---

## 4. Top 5 swing factors for the whole program

Ranked by leverage on the end date.

### 4.1 Operator SME availability versus committed hours
**Impact if poor:** can shift the entire program by 4–8 weeks per phase, compounding.
**Why:** parity with legacy is the constraint; only the operators can validate parity; if they aren't there, UAT cycles re-run.
**Mitigation:** explicit sponsor-level commitment to shift-coverage backfill (DEP-07), measured weekly.
**Honest read:** this is the swing factor most likely to be under-managed because it depends on an organization the program doesn't directly control.

### 4.2 CIP impact rating outcome
**Impact if Medium → High escalation:** 20–35% delivery cost increase, 6–10 weeks added across the program.
**Impact if Medium → Low de-escalation:** 10–15% cost reduction, 3–4 weeks compressed.
**Why:** drives ESP boundary controls, baseline-config burden, IRA path.
**Mitigation:** get a written ruling from the CIP Senior Manager in the first 30 days of `T0`.

### 4.3 SCADA/XA21 wrapper protocol fidelity
**Impact if poor:** can cause MVP gate failure (MS-08), which is unrecoverable on the planned timeline.
**Why:** any fidelity defect is operator-visible in seconds and erodes trust.
**Mitigation:** disproportionate investment in contract testing against a recorded XA21 trace; ringfence the SCADA wrapper team from other work.

### 4.4 Hidden business rules in legacy 4GL code
**Impact if widespread:** can add 8–12 weeks to Phase 2a/3 cumulatively; corrupts UAT cycles when discovered late.
**Why:** OpenRoad code carries 20+ years of accreted patches; the feature catalog inventories features but rarely captures embedded rules.
**Mitigation:** a 4GL code-walk workstream alongside detailed design, staffed by someone who actually reads OpenRoad.

### 4.5 Reference-data drift from Asset Mgmt
**Impact if poor:** can corrupt switching decisions in production; in a safety-critical context this is catastrophic, not merely a defect.
**Why:** reference data drives device identity, district scope, breaker capability — getting this wrong has blast radius beyond the application.
**Mitigation:** treat the reference-data sync as a regulated integration; reconcile daily; alert on drift.

---

## 5. The number to bet on

If forced to pick a single program close date with no buffer for uncomfortable conversations: **2028-12-15** (program close, post-Hypercare).

If you must give the sponsor a target that is achievable with focus and luck: **2028-10-15**.

If you must give the sponsor a target that fits inside their 24–30 month envelope with no Hypercare: **2028-08-01** for "all districts cut over" and 2028-12-15 for "program closed". This is the reconciliation the sponsor conversation needs.

The dates above assume `T0 = 2026-05-01`. Each week of slippage to `T0` (Wave A ratification, CIP rating, operator-SME backfill commitment, internal CA / PAM tooling readiness) translates approximately 1:1 to the end date.

---

## 6. What to do with this document

- **Sponsor briefing:** §5 only. Bring the workbook for follow-ups.
- **Steering committee monthly:** §3 and §4 — phase ranges and swing factors. Update §3 ranges as actuals come in.
- **Delivery team weekly:** the workbook, not this narrative. This narrative is for governance.
- **CIP Senior Manager:** §4.2 — the rating outcome conversation should happen first.
- **Operator SME Lead:** §3.4 and §4.1 — Phase 2b is yours to win or lose; over-invest in Phase 1 co-design to compress it.
