# Master Project Plan — Spec & Source of Truth
**Deliverable #1 — Wave B: Planning Backbone**
**Status:** Phase 1 baseline. Workbook generated from this spec via [generate_master_plan_xlsx.py](generate_master_plan_xlsx.py).
**Output:** `01-master-plan.xlsx` — multi-sheet workbook.
**Cross-refs:** [d02 — Timeline Narrative](d02-timeline-narrative.md) · [Wave A foundations](../wave-a/)

---

## 1. Purpose

This document is the **human-readable, diff-able source of truth** for the master plan workbook. The Python generator is mechanical — edit this spec and the `.py` script's data structures together, then regenerate. Do not edit the `.xlsx` by hand and expect it to survive.

The workbook is a **template plus a populated baseline**. The baseline reflects the ratified defaults from the engagement (project memory, 2026-04-28). A delivery team picks this up and extends — they do not build from a blank workbook.

---

## 2. Workbook structure

Twelve sheets, in this order:

| # | Sheet | Purpose |
|---|---|---|
| 1 | `README` | How to read and edit the workbook; change log |
| 2 | `WBS` | Full work breakdown — every task with owner, RACI key, three-point duration, dependencies, status, risk + assumption refs |
| 3 | `Phases` | Phase definitions with entry/exit criteria and gate owners |
| 4 | `Timeline` | Phase- and milestone-level Gantt-style view (text-rendered: start/end/range) |
| 5 | `Milestones` | Major milestones with target dates and named drivers of variance |
| 6 | `Workstreams` | Workstream definitions and lead role |
| 7 | `Dependencies` | Cross-task and external dependencies (e.g., XA21 vendor, internal CA team) |
| 8 | `Risks` | Risk register pre-loaded with Wave A risks |
| 9 | `Assumptions` | Assumption register with the 8 ratified defaults |
| 10 | `RACI` | Role × major-deliverable matrix |
| 11 | `Roles` | Role glossary (one line per role) |
| 12 | `Status Legend` | Status values, colors, definitions |

**No "Resources" sheet here** — that lives in d05 (Wave D resource plan). Cross-reference only.
**No "Cost" sheet here** — owned by program finance, not the delivery plan.

---

## 3. Sheet schemas (column definitions)

### 3.1 `WBS`

| Column | Type | Notes |
|---|---|---|
| ID | string | e.g., `P1.05` — phase prefix + ordinal; immutable once issued |
| Phase | string | `P0..P6` or `AO` (always-on) |
| Workstream | string | One of: ARCH, BE, FE, DATA, INT, SEC, DEVOPS, QA, BA, CHG, PM |
| Task | string | Imperative phrase ≤120 chars |
| Owner Role | string | From `Roles` sheet |
| Best (days) | int | Optimistic — everything goes right |
| Likely (days) | int | Three-point central estimate |
| Worst (days) | int | Pessimistic — known risks materialize |
| Confidence | string | High / Medium / Low — based on similarity to past work |
| Dependencies | string | Comma-separated WBS IDs and/or external dep IDs from `Dependencies` |
| Risk Refs | string | Comma-separated risk IDs from `Risks` |
| Assumption Refs | string | Comma-separated assumption IDs from `Assumptions` |
| Status | string | Not Started / In Progress / Blocked / Complete / Deferred |
| % Complete | int | 0..100 |
| Notes | string | Free text |

Days are **person-days** at the owner role's loading. Calendar duration is computed in d05 (Wave D) when team size is fixed.

### 3.2 `Phases`

| Column | Notes |
|---|---|
| Phase ID | `P0..P6`, `AO` |
| Phase Name | |
| Entry Criteria | Bullet list (text) |
| Exit Criteria | Bullet list (text) |
| Gate Owner | Role from `Roles` |
| Gate Type | Sponsor / Operator / CIP / Technical |
| Earliest Start | Date or "T0+Nd" notation |
| Earliest Finish | Range expression (e.g., `T0+120d..T0+180d`) |
| Notes | |

### 3.3 `Timeline`

Renders the phase plan textually because Excel charts don't survive diffs. Columns:

| Column | Notes |
|---|---|
| Item ID | Phase or milestone ID |
| Item | |
| Start (best) | Calendar date |
| Start (likely) | Calendar date |
| Start (worst) | Calendar date |
| Finish (best) | Calendar date |
| Finish (likely) | Calendar date |
| Finish (worst) | Calendar date |
| Duration (likely, weeks) | int |
| Critical Path? | Y/N |
| Drivers of Variance | Free text |

Anchor: `T0 = 2026-05-01` (start of Phase 1 immediately after Wave A ratification).

### 3.4 `Milestones`

| Column | Notes |
|---|---|
| Milestone ID | `MS-NN` |
| Milestone | |
| Target (likely) | Date |
| Range | `±N weeks` |
| Phase | Phase ID |
| Gate? | Y/N |
| Drivers of Variance | Free text |

### 3.5 `Workstreams`

| Column | Notes |
|---|---|
| Code | ARCH, BE, FE, DATA, INT, SEC, DEVOPS, QA, BA, CHG, PM |
| Name | |
| Lead Role | From `Roles` |
| Scope | Free text |
| Key Deliverables | Free text |

### 3.6 `Dependencies`

| Column | Notes |
|---|---|
| Dep ID | `DEP-NN` |
| Type | Internal / External / Vendor / Regulatory |
| From | WBS ID or "External" |
| To | WBS ID |
| Description | |
| Owner | Who chases it |
| Risk if late | Free text |

### 3.7 `Risks`

| Column | Notes |
|---|---|
| Risk ID | `R-NNN` |
| Title | |
| Category | Technical / Schedule / People / Vendor / Regulatory / Operational |
| Probability | High / Medium / Low |
| Impact | High / Medium / Low |
| Score | P × I (HH=9, HM/MH=6, MM/HL/LH=4, ML/LM=3, LL=1) |
| Mitigation | Free text |
| Contingency | Free text |
| Owner | |
| Status | Open / Mitigated / Closed / Realized |

### 3.8 `Assumptions`

| Column | Notes |
|---|---|
| Assumption ID | `A-NNN` |
| Assumption | |
| Source | Where it came from (e.g., "user default 2026-04-28") |
| Validation | What would prove or disprove it |
| If Wrong | Impact if assumption fails |
| Owner | Who validates |
| Status | Pending / Validated / Invalidated |

### 3.9 `RACI`

Wide format. Rows = major deliverables (one per Wave A–F artifact, plus per-phase gates and major workstream milestones). Columns = roles. Cell values = R / A / C / I (single letter, dominant assignment if multiple apply — true RACI doesn't split letters).

### 3.10 `Roles`

| Column | Notes |
|---|---|
| Role | Short title |
| Description | One line |
| FTE in MVP | Decimal |
| FTE in Incremental Build | Decimal |
| Skills required | Free text |

(FTE detail is owned in d05; what's here is the program-level shape only.)

### 3.11 `Status Legend`

Static reference — values and meanings.

---

## 4. Pre-loaded baseline content

### 4.1 Phases (with Wave A → F mapping)

| ID | Phase | Wave |
|---|---|---|
| P0 | Discovery | (complete) |
| P1 | Detailed Design | A, B, C, D, E (deliverables 7,9,10 / 1,2 / 3,4 / 5,6 / 8,11,12,13) |
| P2a | MVP Build | (execution) |
| P2b | MVP UAT & Operator Approval Gate | (execution) — **critical gate** |
| P3 | Incremental Build (waves of remaining apps) | (execution) |
| P4 | Full UAT | (execution) |
| P5 | Cutover (district-by-district) | (execution) |
| P6 | Hypercare | (execution) |
| AO | Always-on (governance, security, change mgmt, vendor mgmt) | (cross-cutting) |

### 4.2 Workstreams

| Code | Name | Lead Role |
|---|---|---|
| ARCH | Architecture | Solution Architect |
| BE | Backend (.NET) | Tech Lead — Backend |
| FE | Frontend (Angular) | Tech Lead — Frontend |
| DATA | Database & Migration | DBA Lead |
| INT | Integration & SCADA | Integration Lead |
| SEC | Security & NERC CIP | CIP Compliance Lead |
| DEVOPS | DevOps & Infra | DevOps Lead |
| QA | Test & Quality | Test Lead |
| BA | Business Analysis & Backlog | BA Lead |
| CHG | Change Mgmt & Operator Engagement | Change Lead |
| PM | Program Management | Program Director |

### 4.3 Milestones (likely dates against `T0 = 2026-05-01`)

| ID | Milestone | Target | Range | Gate? |
|---|---|---|---|---|
| MS-01 | Wave A foundations ratified | 2026-05-15 | ±2 wk | Y (Technical) |
| MS-02 | Backlog engineering pipeline live | 2026-07-01 | ±2 wk | N |
| MS-03 | Estimation worksheet baselined | 2026-07-15 | ±3 wk | N |
| MS-04 | Detailed Design Gate | 2026-10-15 | ±4 wk | Y (Sponsor + CIP + Operator SME) |
| MS-05 | MVP feature-complete in Pre-Prod | 2027-03-15 | ±6 wk | N |
| MS-06 | MVP storm test passed | 2027-04-15 | ±4 wk | Y (Technical) |
| MS-07 | MVP NERC CIP rehearsal passed | 2027-05-15 | ±4 wk | Y (CIP) |
| MS-08 | **MVP Operator Approval Gate** | 2027-07-30 | ±6 wk | Y (Operator SME — **critical**) |
| MS-09 | Incremental Build Wave 3 complete (monitors) | 2028-01-15 | ±6 wk | N |
| MS-10 | Full UAT pass | 2028-04-15 | ±6 wk | Y (Sponsor) |
| MS-11 | Cutover dry-run #2 (with rollback) passed | 2028-05-15 | ±4 wk | Y (Technical + CIP) |
| MS-12 | District 1 cutover complete | 2028-06-15 | ±4 wk | Y (Sponsor + CIP + Ops) |
| MS-13 | All districts cut over | 2028-10-30 | ±6 wk | Y (Sponsor) |
| MS-14 | Ingres legacy decommissioned | 2028-12-15 | ±6 wk | Y (Sponsor + Audit) |
| MS-15 | Program close (post-Hypercare) | 2029-02-15 | ±6 wk | Y (Sponsor) |

MS-13 (all districts cut over) at 2028-10-30 sits at the upper bound of the **24–30 month** ratified envelope from 2026-04-28. MS-15 (program close, post-Hypercare) at 2029-02-15 is roughly 2.5 months past the envelope — this overrun is intentional and explicitly flagged in [d02 §5](d02-timeline-narrative.md). Closing the program before Hypercare is the way you discover defects in production; on safety-critical OT, it is non-negotiable.

### 4.4 Pre-loaded risks (Wave A surfaced)

| ID | Title | P | I | Score |
|---|---|---|---|---|
| R-001 | Hidden business rules embedded in OpenRoad 4GL code | H | H | 9 |
| R-002 | Operator SME availability shortfall against committed hours | H | H | 9 |
| R-003 | SCADA/XA21 wrapper protocol fidelity defects under load | H | M | 6 |
| R-004 | NERC CIP impact rating debate delays P1 gate | M | H | 6 |
| R-005 | AG sync replica IPSec performance regression | M | M | 4 |
| R-006 | Ingres → SQL Server semantic-loss surprises during reconciliation | H | M | 6 |
| R-007 | Ledger Audit write overhead exceeds budget under storm load | M | M | 4 |
| R-008 | Operator change-management resistance erodes MVP approval | H | M | 6 |
| R-009 | Internal CA / mTLS tooling vendor delay blocks pre-prod | M | M | 4 |
| R-010 | Per-district parallel-run defect rate blows the 8-week enterprise cap | H | H | 9 |
| R-011 | Reference-data drift from Asset Mgmt corrupts switching decisions | M | H | 6 |
| R-012 | XA21 vendor change calendar conflicts with cutover window | L | H | 3 |

### 4.5 Pre-loaded assumptions (8 ratified defaults)

| ID | Assumption | Source |
|---|---|---|
| A-001 | Team: ~8–12 blended squad with named skill mix; 70% onshore | User default 2026-04-28 |
| A-002 | Budget: $15–25M total program, capped T&M, ±15% sponsor tolerance | User default 2026-04-28 |
| A-003 | Phase 1 Detailed Design 4–6 mo; MVP build+UAT 6–9 mo; full cutover 24–30 mo from T0 | User default 2026-04-28 |
| A-004 | XA21 frozen for the modernization window; legacy SOAP wrapped at DMZ only | User default 2026-04-28 |
| A-005 | 4 operators × 2 districts × 8 hrs/wk in P1, scaling to 16 hrs/wk in MVP UAT, with shift-coverage backfill funded | User default 2026-04-28 |
| A-006 | ~25–50K cards/yr, ~50–200 audit events/card, 300–800 GB live + 2–4 TB archive, 7-yr online retention | User default 2026-04-28 |
| A-007 | Core BCS = Medium Impact; CIP-005/007/010/011/013 in scope | User default 2026-04-28 |
| A-008 | Phased district-by-district cutover with 4–6 wk per-district parallel run; 8-wk enterprise cap on dual-entry | User default 2026-04-28 |
| A-009 | Existing utility-standard reverse proxy/WAF, internal CA, PAM tooling, SIEM available | Wave A architecture default |
| A-010 | On-prem AD authoritative for OpNET; Entra ID for CorpNET; one-way attribute sync exists | Wave A architecture default |

### 4.6 Pre-loaded external dependencies

| Dep ID | Type | Description | Risk if late |
|---|---|---|---|
| DEP-01 | Vendor | XA21 SOAP trace export + recorded session for contract testing | Storm test cannot validate; MS-06 slips |
| DEP-02 | Internal | Internal CA mTLS issuance pipeline available in Pre-Prod | Pre-prod environment delayed; P2a slips |
| DEP-03 | Internal | PAM tooling configured for DMZ jump server | CIP-005 R2 control gap; cannot pass MS-07 |
| DEP-04 | Internal | SIEM ingestion pipeline accepting OpNET sources | CIP-007 R4 control gap; cannot pass MS-07 |
| DEP-05 | Vendor | Asset Mgmt API access for reference-data sync | Reference-data flow degraded; affects MVP correctness |
| DEP-06 | Internal | DR site provisioned with encrypted backup target | CIP-009 R2 control gap; cannot pass MS-10 |
| DEP-07 | Operator org | Shift-coverage backfill funded so committed SME hours are real | Hits R-002 directly; MVP UAT slips |
| DEP-08 | Regulatory | CIP Senior Manager confirms BCS impact rating | If Low, descope CIP-010 baseline burden; if High, replan |

---

## 5. WBS baseline (representative — extend in flight)

The full populated WBS lives in the generator script's `WBS_ROWS` data structure. Rough breakdown:

| Phase | # of WBS rows in baseline | Days (likely sum) | Notes |
|---|---|---|---|
| P0 | 4 | 0 | All complete; listed for traceability |
| P1 | ~22 | ~600 person-days | Spans Waves A–F |
| P2a | ~26 | ~1500 person-days | MVP build — vertical-slice through 8-step workflow |
| P2b | ~7 | ~250 person-days | UAT cycles + defect remediation + gate |
| P3 | ~12 | ~2200 person-days | 7 sub-waves (3 workflow types + 2 monitor batches + reporting + migration scripts) |
| P4 | ~6 | ~350 person-days | Integration UAT + soak + dry-runs |
| P5 | ~10 | ~600 person-days | Per-district cutover + decom |
| P6 | ~5 | ~400 person-days | Hypercare |
| AO | ~6 | (continuous, sized in d05) | Governance, security, vendor, change |

**Brutal honesty: this baseline is a defensible skeleton. A populated production plan will land at 300–500 rows once the BA Lead expands per-epic, and the day totals will move ±25%.** That movement is the point of d06 (estimation worksheet, Wave D).

---

## 6. Open workbook decisions

Decide at Wave B review:

1. **Calendar dates vs T0+Nd notation in `Timeline`.** Default: both. The likely-date column drives operational planning; the T0+Nd column survives slips without rewriting the workbook.
2. **Critical-path computation.** Default: manually flagged in `Timeline`. Excel auto-computation is unreliable across diffs. If you need a true computed CP, export to MS Project or smart-Gantt-tool when the team picks one.
3. **Status colors.** Default: red/yellow/green for status; orange for Blocked. Confirm at review.
4. **Confidence-rating scheme.** Default: 3-band High/Medium/Low. Alternative: 5-band with numeric. Defaulting to 3-band — over-precision in confidence is theater.
