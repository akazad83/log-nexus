"""
generate_timeline_narrative_docx.py
Renders d02-timeline-narrative.md to 02-timeline-narrative.docx.

Source-of-truth markdown: d02-timeline-narrative.md
Re-run after editing the markdown.

Usage:
    python generate_timeline_narrative_docx.py [--input PATH] [--output PATH]

Markdown subset supported:
    # H1 .. ###### H6
    **bold**, *italic*, `code`
    GitHub-flavored tables
    - bulleted lists
    horizontal rules (---)
    fenced code blocks (```)
"""

import argparse
import re
from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

# --------------------------------------------------------------------------
# Style configuration
# --------------------------------------------------------------------------

ACCENT = RGBColor(0x1F, 0x4E, 0x78)
MUTED  = RGBColor(0x40, 0x40, 0x40)

HEADING_SIZES = {1: 22, 2: 16, 3: 13, 4: 12, 5: 11, 6: 10}

BODY_FONT = "Calibri"
CODE_FONT = "Consolas"

# --------------------------------------------------------------------------
# Inline parsing
# --------------------------------------------------------------------------

INLINE_RE = re.compile(r"(\*\*[^*\n]+\*\*|\*[^*\n]+\*|`[^`\n]+`)")

def parse_inline(text):
    """Yield (text, bold, italic, code) for each chunk."""
    pos = 0
    for m in INLINE_RE.finditer(text):
        if m.start() > pos:
            yield (text[pos:m.start()], False, False, False)
        tok = m.group()
        if tok.startswith("**"):
            yield (tok[2:-2], True, False, False)
        elif tok.startswith("*"):
            yield (tok[1:-1], False, True, False)
        elif tok.startswith("`"):
            yield (tok[1:-1], False, False, True)
        pos = m.end()
    if pos < len(text):
        yield (text[pos:], False, False, False)

def add_runs(paragraph, text):
    for chunk, bold, italic, code in parse_inline(text):
        run = paragraph.add_run(chunk)
        if bold:
            run.bold = True
        if italic:
            run.italic = True
        if code:
            run.font.name = CODE_FONT
            run.font.size = Pt(10)
            run.font.color.rgb = MUTED
        else:
            run.font.name = BODY_FONT

# --------------------------------------------------------------------------
# Block rendering
# --------------------------------------------------------------------------

def add_heading(doc, level, text):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(HEADING_SIZES.get(level, 11))
    run.font.name = BODY_FONT
    if level <= 2:
        run.font.color.rgb = ACCENT
    p.paragraph_format.space_before = Pt(12 if level <= 2 else 8)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True

def add_body_paragraph(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    add_runs(p, text)

def add_bullet(doc, text, indent=0):
    p = doc.add_paragraph(style="List Bullet")
    if indent:
        p.paragraph_format.left_indent = Inches(0.25 * indent)
    add_runs(p, text)

def add_horizontal_rule(doc):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "808080")
    pBdr.append(bottom)
    pPr.append(pBdr)

def add_code_block(doc, lines):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.space_after = Pt(8)
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "F2F2F2")
    pPr.append(shd)
    text = "\n".join(lines)
    run = p.add_run(text)
    run.font.name = CODE_FONT
    run.font.size = Pt(9)
    run.font.color.rgb = MUTED

def add_table(doc, header, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(header))
    table.style = "Light Grid Accent 1"
    table.autofit = True
    # Header
    for j, cell_text in enumerate(header):
        cell = table.rows[0].cells[j]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(cell_text)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = BODY_FONT
        # shade header
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "1F4E78")
        tcPr.append(shd)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    # Body
    for i, row in enumerate(rows, start=1):
        for j, cell_text in enumerate(row):
            cell = table.rows[i].cells[j]
            cell.text = ""
            p = cell.paragraphs[0]
            add_runs(p, cell_text)
            for run in p.runs:
                if run.font.name is None:
                    run.font.name = BODY_FONT
            cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP

# --------------------------------------------------------------------------
# Markdown parsing
# --------------------------------------------------------------------------

def split_table_row(line):
    """Split a markdown table row into cells, ignoring leading/trailing pipes."""
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]

def is_table_separator(line):
    s = line.strip()
    if not s.startswith("|"):
        return False
    cells = split_table_row(s)
    return all(re.fullmatch(r":?-+:?", c) for c in cells if c)

def render_markdown(md_path: Path, doc: Document):
    text = md_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        # Skip blank lines (paragraph separators are handled by space_after)
        if not stripped:
            i += 1
            continue

        # Fenced code block
        if stripped.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            add_code_block(doc, buf)
            i += 1  # skip closing fence
            continue

        # Horizontal rule
        if re.fullmatch(r"-{3,}|_{3,}|\*{3,}", stripped):
            add_horizontal_rule(doc)
            i += 1
            continue

        # Heading
        m = re.match(r"^(#{1,6})\s+(.*)", stripped)
        if m:
            level = len(m.group(1))
            add_heading(doc, level, m.group(2))
            i += 1
            continue

        # Table: header line followed by separator
        if stripped.startswith("|") and i + 1 < n and is_table_separator(lines[i + 1]):
            header = split_table_row(stripped)
            i += 2  # skip header + separator
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append(split_table_row(lines[i]))
                i += 1
            add_table(doc, header, rows)
            continue

        # Bulleted list
        if re.match(r"^\s*[-*]\s+", line):
            indent = (len(line) - len(line.lstrip())) // 2
            content = re.sub(r"^\s*[-*]\s+", "", line)
            add_bullet(doc, content, indent=indent)
            i += 1
            continue

        # Numbered list (treat as bullets for simplicity)
        if re.match(r"^\s*\d+\.\s+", line):
            content = re.sub(r"^\s*\d+\.\s+", "", line)
            p = doc.add_paragraph(style="List Number")
            add_runs(p, content)
            i += 1
            continue

        # Default: body paragraph (gather contiguous lines until blank/special)
        buf = [stripped]
        i += 1
        while i < n:
            nxt = lines[i]
            if (
                not nxt.strip()
                or nxt.strip().startswith("#")
                or nxt.strip().startswith("|")
                or nxt.strip().startswith("```")
                or re.match(r"^\s*[-*]\s+", nxt)
                or re.match(r"^\s*\d+\.\s+", nxt)
                or re.fullmatch(r"-{3,}|_{3,}|\*{3,}", nxt.strip())
            ):
                break
            buf.append(nxt.strip())
            i += 1
        add_body_paragraph(doc, " ".join(buf))

# --------------------------------------------------------------------------
# Document setup
# --------------------------------------------------------------------------

def configure_doc(doc: Document):
    section = doc.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    style = doc.styles["Normal"]
    style.font.name = BODY_FONT
    style.font.size = Pt(11)


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Render the timeline narrative docx.")
    parser.add_argument("--input", default=str(here / "d02-timeline-narrative.md"))
    parser.add_argument("--output", default=str(here / "build" / "02-timeline-narrative.docx"))
    args = parser.parse_args()

    md = Path(args.input)
    out = Path(args.output)

    doc = Document()
    configure_doc(doc)
    render_markdown(md, doc)

    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
