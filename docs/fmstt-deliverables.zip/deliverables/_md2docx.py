"""
_md2docx.py
Shared markdown-to-docx renderer used by Wave C onward.

Subset of markdown supported:
    # H1 .. ###### H6
    **bold**, *italic*, `code`
    GitHub-flavored tables
    - bulleted lists (single level)
    1. numbered lists
    horizontal rules (---)
    fenced code blocks (```)
    YAML frontmatter (--- ... ---) at top of file is rendered as a labeled metadata block

Wave-B's generate_timeline_narrative_docx.py keeps its own copy of this renderer
intentionally so that delivered artifact stays self-contained. Wave-C and later
import from this module.
"""

from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ACCENT = RGBColor(0x1F, 0x4E, 0x78)
MUTED  = RGBColor(0x40, 0x40, 0x40)

HEADING_SIZES = {1: 22, 2: 16, 3: 13, 4: 12, 5: 11, 6: 10}
BODY_FONT = "Calibri"
CODE_FONT = "Consolas"

INLINE_RE = re.compile(r"(\*\*[^*\n]+\*\*|\*[^*\n]+\*|`[^`\n]+`)")


def parse_inline(text):
    pos = 0
    for m in INLINE_RE.finditer(text):
        if m.start() > pos:
            yield (text[pos:m.start()], False, False, False)
        tok = m.group()
        if tok.startswith("**"):
            yield (tok[2:-2], True, False, False)
        elif tok.startswith("*"):
            yield (tok[1:-1], False, True, False)
        elif tok.startswith("`"):
            yield (tok[1:-1], False, False, True)
        pos = m.end()
    if pos < len(text):
        yield (text[pos:], False, False, False)


def add_runs(paragraph, text):
    for chunk, bold, italic, code in parse_inline(text):
        run = paragraph.add_run(chunk)
        if bold:
            run.bold = True
        if italic:
            run.italic = True
        if code:
            run.font.name = CODE_FONT
            run.font.size = Pt(10)
            run.font.color.rgb = MUTED
        else:
            run.font.name = BODY_FONT


def add_heading(doc, level, text):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(HEADING_SIZES.get(level, 11))
    run.font.name = BODY_FONT
    if level <= 2:
        run.font.color.rgb = ACCENT
    p.paragraph_format.space_before = Pt(12 if level <= 2 else 8)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True


def add_body_paragraph(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    add_runs(p, text)


def add_bullet(doc, text, indent=0):
    p = doc.add_paragraph(style="List Bullet")
    if indent:
        p.paragraph_format.left_indent = Inches(0.25 * indent)
    add_runs(p, text)


def add_horizontal_rule(doc):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "808080")
    pBdr.append(bottom)
    pPr.append(pBdr)


def add_code_block(doc, lines):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.space_after = Pt(8)
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "F2F2F2")
    pPr.append(shd)
    text = "\n".join(lines)
    run = p.add_run(text)
    run.font.name = CODE_FONT
    run.font.size = Pt(9)
    run.font.color.rgb = MUTED


def add_frontmatter(doc, pairs):
    """Render a YAML frontmatter block as a labeled mini-table."""
    if not pairs:
        return
    table = doc.add_table(rows=len(pairs), cols=2)
    table.autofit = True
    for i, (k, v) in enumerate(pairs):
        a = table.rows[i].cells[0]
        b = table.rows[i].cells[1]
        a.text = ""
        b.text = ""
        ar = a.paragraphs[0].add_run(str(k))
        ar.bold = True
        ar.font.name = BODY_FONT
        ar.font.size = Pt(10)
        ar.font.color.rgb = MUTED
        br = b.paragraphs[0].add_run(str(v))
        br.font.name = BODY_FONT
        br.font.size = Pt(10)
        for cell in (a, b):
            tcPr = cell._tc.get_or_add_tcPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear")
            shd.set(qn("w:color"), "auto")
            shd.set(qn("w:fill"), "F8F8F8")
            tcPr.append(shd)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_table(doc, header, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(header))
    table.style = "Light Grid Accent 1"
    table.autofit = True
    for j, cell_text in enumerate(header):
        cell = table.rows[0].cells[j]
        cell.text = ""
        run = cell.paragraphs[0].add_run(cell_text)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = BODY_FONT
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "1F4E78")
        tcPr.append(shd)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    for i, row in enumerate(rows, start=1):
        for j, cell_text in enumerate(row):
            cell = table.rows[i].cells[j]
            cell.text = ""
            add_runs(cell.paragraphs[0], cell_text)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP


def split_table_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def is_table_separator(line):
    s = line.strip()
    if not s.startswith("|"):
        return False
    cells = split_table_row(s)
    return all(re.fullmatch(r":?-+:?", c) for c in cells if c)


def parse_frontmatter(lines):
    """If lines start with '---', collect frontmatter pairs and return (pairs, remaining_lines)."""
    if not lines or lines[0].strip() != "---":
        return [], lines
    pairs = []
    i = 1
    while i < len(lines) and lines[i].strip() != "---":
        line = lines[i]
        if ":" in line:
            k, _, v = line.partition(":")
            pairs.append((k.strip(), v.strip()))
        i += 1
    if i < len(lines):
        return pairs, lines[i + 1:]
    return [], lines


def render_markdown_text(text: str, doc: Document):
    lines = text.splitlines()
    fm, lines = parse_frontmatter(lines)
    if fm:
        add_frontmatter(doc, fm)

    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        if stripped.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            add_code_block(doc, buf)
            i += 1
            continue

        if re.fullmatch(r"-{3,}|_{3,}|\*{3,}", stripped):
            add_horizontal_rule(doc)
            i += 1
            continue

        m = re.match(r"^(#{1,6})\s+(.*)", stripped)
        if m:
            add_heading(doc, len(m.group(1)), m.group(2))
            i += 1
            continue

        if stripped.startswith("|") and i + 1 < n and is_table_separator(lines[i + 1]):
            header = split_table_row(stripped)
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append(split_table_row(lines[i]))
                i += 1
            add_table(doc, header, rows)
            continue

        if re.match(r"^\s*[-*]\s+", line):
            indent = (len(line) - len(line.lstrip())) // 2
            content = re.sub(r"^\s*[-*]\s+", "", line)
            add_bullet(doc, content, indent=indent)
            i += 1
            continue

        if re.match(r"^\s*\d+\.\s+", line):
            content = re.sub(r"^\s*\d+\.\s+", "", line)
            p = doc.add_paragraph(style="List Number")
            add_runs(p, content)
            i += 1
            continue

        buf = [stripped]
        i += 1
        while i < n:
            nxt = lines[i]
            if (
                not nxt.strip()
                or nxt.strip().startswith("#")
                or nxt.strip().startswith("|")
                or nxt.strip().startswith("```")
                or re.match(r"^\s*[-*]\s+", nxt)
                or re.match(r"^\s*\d+\.\s+", nxt)
                or re.fullmatch(r"-{3,}|_{3,}|\*{3,}", nxt.strip())
            ):
                break
            buf.append(nxt.strip())
            i += 1
        add_body_paragraph(doc, " ".join(buf))


def configure_doc(doc: Document):
    section = doc.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    style = doc.styles["Normal"]
    style.font.name = BODY_FONT
    style.font.size = Pt(11)


def render_file(input_path: Path, output_path: Path) -> None:
    doc = Document()
    configure_doc(doc)
    render_markdown_text(input_path.read_text(encoding="utf-8"), doc)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)


def render_files(inputs: list[Path], output_path: Path) -> None:
    """Concatenate multiple markdown files into one docx with section breaks."""
    doc = Document()
    configure_doc(doc)
    for idx, p in enumerate(inputs):
        if idx > 0:
            doc.add_page_break()
        render_markdown_text(p.read_text(encoding="utf-8"), doc)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)
