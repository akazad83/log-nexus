# Detailed Technical Architecture Outline
**Deliverable #7 — Wave A: Foundations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave A review gate.
**Cross-refs:** [d09 — Database Design Principles](d09-database-design-principles.md) · [d10 — Network & Boundary Design](d10-network-boundary-design.md)

---

## 1. Purpose & Scope

Fixes the application-tier architecture for the modernized switching order management suite. **Opinionated**: alternatives are listed only where the trade-off is real and non-trivial; choices forced by NERC CIP, OT-zone integrity, or operator-mental-model constraints are stated as decisions, not options.

This document does **not** specify network controls (see d10) or the data model (see d09). It does specify how the application tiers compose across OpNET/DMZ/CorpNET, where integrations land, how identity flows, and how the system is observed.

---

## 2. Architectural decisions (already made)

These are not up for debate without explicit override; each is justified inline.

| ID | Decision | Rationale |
|---|---|---|
| AD-01 | **Modular monolith** for the core switching application, not microservices | One product, one deployable, one DB. ~12-person team. Microservices buy distribution problems we don't have. NERC CIP-010 baseline-config burden multiplies per service. We split by bounded context inside the monolith and revisit only if a context proves to need independent scaling. |
| AD-02 | **Angular SPA, no SSR** | Internal operator tool on managed workstations. SSR adds an OpNET-resident node process and a CIP-007 R4 audit surface for zero benefit. |
| AD-03 | **REST + AMQP** as the integration substrate; gRPC explicitly out | Team skill alignment, ops familiarity, schema tooling maturity. gRPC adds load-balancer and observability complexity without throughput need. |
| AD-04 | **RabbitMQ** for asynchronous messaging | On-prem maturity, mTLS, AMQP 0.9.1 well-understood. Kafka is overkill and a heavier CIP-010 footprint. SQL Server Service Broker considered and rejected — operational tooling and dead-letter ergonomics weaker. |
| AD-05 | **Bounded contexts (initial cut):** Switching Card, Clearance/Tagging, Authorization, Field Coordination, Audit, Reference Data, Notification | Mirrors the 8-step operator workflow. Each context = a SQL schema, a module in the monolith, a folder root in the Angular app. |
| AD-06 | **Identity is split at the OpNET/CorpNET boundary** | OpNET-side identity = on-prem AD only. CorpNET reporting = Entra ID with one-way attribute sync. No real-time federation across the ESP. (See §6.) |
| AD-07 | **Read-only reporting tier in CorpNET reads from a DMZ-resident replica**, not from OpNET directly | Preserves ESP ingress/egress posture. (See d10.) |
| AD-08 | **All SCADA/XA21 traffic terminates at the DMZ gateway**, never at OpNET app services directly | Single integration choke point, single set of CIP-005 R1 logs, no app-tier coupling to vendor protocol drift. |
| AD-09 | **No event sourcing as primary persistence model** | The audit table is the immutable record (see d09). Event sourcing as primary persistence complicates parity and increases operator-comprehension cost. |
| AD-10 | **EF Core for OLTP data access**, Dapper for hot-path queries (SCADA event ingest, audit insert) | EF for productivity, Dapper for predictable plans on the workflows that must not regress under storm load. |

---

## 3. Logical architecture

### 3.1 Tier diagram (text)

```
┌─────────────────────── CorpNET (Purdue L4, outside ESP) ────────────────────────┐
│  • Reporting Web (Angular SPA, IIS)                                              │
│  • Reporting API (.NET 8/9, IIS) — read-only                                     │
│  • Entra ID (corporate SSO)                                                      │
│  • SIEM forwarder, Grafana mirror, ServiceNow, Power BI                          │
└────────────────────────────────┬─────────────────────────────────────────────────┘
                                 │  HTTPS only · allowlist · mTLS where service-to-service
┌────────────────────────────────▼──────── DMZ (Purdue L3.5, EAP) ─────────────────┐
│  • Integration Gateway (.NET 8/9 minimal API, IIS) — protocol translation only   │
│  • Message Bridge (RabbitMQ shovel + protocol adapters)                          │
│  • SQL Server async replica (read-only, reporting source)                        │
│  • Reverse proxy / WAF (single-vendor stack)                                     │
│  • SCADA SOAP wrappers (legacy XA21 endpoints, untouched)                        │
│  • Jump server (CIP-005 R2 Intermediate System for IRA)                          │
└────────────────────────────────┬─────────────────────────────────────────────────┘
                                 │  HTTPS · mTLS · OpNET-originated outbound only (see d10)
┌────────────────────────────────▼──────── OpNET (Purdue L3, ESP) ─────────────────┐
│  • Operator Web (Angular SPA, IIS)                                               │
│  • Switching Order API (.NET 8/9 modular monolith, IIS)                          │
│      ├── Switching Card module                                                   │
│      ├── Clearance/Tagging module                                                │
│      ├── Authorization module                                                    │
│      ├── Field Coordination module                                               │
│      ├── Audit module                                                            │
│      ├── Reference Data module                                                   │
│      └── Notification module                                                     │
│  • RabbitMQ (3-node cluster, mTLS, mirrored queues)                              │
│  • SQL Server 2025 EE primary + sync replica (Always On AG)                      │
│  • On-prem AD (Kerberos, integrated auth)                                        │
│  • SIEM, Grafana, internal CA                                                    │
│  • XA21 SCADA · Rapid Restore connector · operator workstations (untouched OT)   │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Bounded-context map

| Context | Responsibility | Primary entities | Notable integrations |
|---|---|---|---|
| Switching Card | Lifecycle of switching cards from creation (auto from SCADA event or manual) through close | `Card`, `CardStep`, `CardState` | XA21 event ingest, GIS for asset lookup |
| Clearance/Tagging | De-energize, tag, isolate; persistent tag state | `Tag`, `Clearance`, `TagState` | Asset Mgmt, GIS |
| Authorization | Approval workflow, multi-party hold-off | `Authorization`, `Hold`, `Approver` | AD, HR for role validation |
| Field Coordination | Hand-off to/from Rapid Restore; field crew acks | `FieldOrder`, `CrewAssignment` | Rapid Restore, Notification |
| Audit | Immutable record of every switching action | `AuditEvent`, `AuditChain` | Written-to by all contexts |
| Reference Data | Substations, feeders, breakers, devices, crews, roles | (mastered in Asset Mgmt; cached locally) | Asset Mgmt (source of truth), GIS |
| Notification | Outbound alerts (SMS, email, paging) | `NotificationRequest` | Corporate notification service via DMZ |

### 3.3 Component sizing (indicative, validated in Pre-Prod load test)

- **OpNET API**: 1 IIS app pool per environment; 2 instances behind WLBS for failover. Sustained 200 ops/sec, peak 1000 (storm).
- **OpNET Web**: static SPA assets behind IIS; gzip + brotli; immutable hashed assets.
- **DMZ Gateway**: 2 instances active/active; sized for 5x peak XA21 volume.
- **RabbitMQ**: 3-node OpNET cluster; queues mirrored. DMZ shovel for cross-zone only.
- **SQL Server**: AG with sync replica in OpNET, async in DMZ for reporting reads.

---

## 4. Cross-zone interaction patterns

### 4.1 Pattern A — Inbound SCADA event (storm path, hot)
1. XA21 emits breaker-trip via existing SOAP endpoint (legacy, untouched).
2. DMZ SCADA wrapper receives, normalizes to JSON, drops to RabbitMQ shovel.
3. OpNET Switching Card module consumes from broker; creates card.
4. Audit event written.
5. Operator Web pushes update via SignalR (OpNET-internal only).

**Latency budget:** P95 end-to-end < 2 seconds from SCADA emit to operator screen.

### 4.2 Pattern B — Outbound breaker-close instruction (cold but safety-critical)
1. Operator authorizes close in OpNET Web.
2. Switching Card module emits `CloseInstruction` event.
3. RabbitMQ shovel routes to DMZ.
4. DMZ SCADA wrapper translates to legacy SOAP call to XA21.
5. ACK returns through reverse path.
6. Audit captures both emit and ACK with end-to-end correlation ID.

**Reliability:** at-least-once delivery; idempotency key = `(cardId, stepId, instructionId)` tuple.

### 4.3 Pattern C — Reporting read (CorpNET, cool)
1. Corporate user authenticates to Reporting Web via Entra ID.
2. Reporting API queries the DMZ-resident async replica.
3. No write path. No real-time guarantee. SLA: data ≤30 seconds stale.

### 4.4 Pattern D — Field Coordination (Rapid Restore)
1. Field crew acks step on Rapid Restore (untouched mobile app).
2. Rapid Restore posts to DMZ Gateway adapter.
3. DMZ adapter writes to RabbitMQ.
4. OpNET Field Coordination consumes, updates card state.
5. Operator UI updates via SignalR.

### 4.5 Pattern E — Reference data sync (cold, batch)
- Asset Mgmt is the source of truth.
- Nightly delta sync via DMZ to OpNET reference cache.
- Manual refresh from ops console for emergency updates.

---

## 5. SCADA boundary

The XA21 boundary is the **single highest-risk integration** in the program.

- **No XA21 changes during the modernization window** (per project default). All adaptation happens in the DMZ wrapper. Vendor change request only on regression.
- **Wrapper is dumb.** Translation only. No business logic. Retry policy: bounded N retries with exponential backoff and DLQ. Nothing cleverer.
- **All XA21-bound calls are idempotent at the wrapper layer.** Idempotency key generated by the application; preserved end-to-end.
- **Storm scenarios are the design point**, not steady state. Sizing, queueing, backpressure all sized for a 10x burst (multi-circuit lockout cascade). If we don't pass a storm test in pre-prod, we don't go live.

**Risk flag:** any defect in XA21-wrapper protocol fidelity is a parity failure visible to operators in seconds. Disproportionate investment in contract tests against a recorded XA21 trace is justified and budgeted (see Wave D estimation).

---

## 6. Identity & access

### 6.1 OpNET identity
- **On-prem AD** is authoritative.
- Integrated Windows Authentication (Negotiate/Kerberos) from operator workstations to OpNET API.
- Application authorization via AD groups mapped to application roles in a config table (not hardcoded). RBAC, not ABAC; the workflow doesn't need attribute richness.
- Service-to-service inside OpNET: gMSA where supported; otherwise long-lived domain accounts with rotation procedures.
- All authentication events emitted to SIEM (CIP-007 R4).

### 6.2 CorpNET identity
- **Entra ID** is authoritative for corporate users.
- Reporting Web uses OIDC (auth code + PKCE).
- One-way attribute sync (AD → Entra ID via existing AD Connect, not real-time) gives consistent role identity across zones without crossing the ESP at runtime.

### 6.3 Service identity at the DMZ
- mTLS for all OpNET↔DMZ and DMZ↔CorpNET service-to-service calls.
- Certificates issued from on-prem internal CA; automated rotation via on-prem cert tooling.
- No long-lived bearer tokens cross the ESP.

### 6.4 Privileged access
- All interactive remote access to OpNET goes through the DMZ Intermediate System (CIP-005 R2). No direct RDP/SSH from CorpNET.
- Just-in-time elevation via existing PAM tooling (assumed; confirm — see d10 §7).

---

## 7. Observability

### 7.1 Logging
- **Structured JSON logs** via Serilog from every .NET service.
- Enrichment: `traceId`, `spanId`, `correlationId`, `userId` (where authorized), `cardId` where present.
- Logs ship to a SIEM in OpNET (CIP-007 R4 boundary; no raw log egress to CorpNET).
- A redacted, summarized stream is published to CorpNET for ops dashboards.

### 7.2 Metrics
- **OpenTelemetry SDK** in every service. Prometheus scrape on OpNET; Grafana on OpNET.
- Mirror summary to CorpNET Grafana via the DMZ.
- Golden signals per service: rate, errors, duration. Plus business metrics: `cards_per_minute`, `time_to_de_energize_seconds`, `time_to_restore_seconds`.

### 7.3 Tracing
- W3C Trace Context propagation across the gateway.
- OpenTelemetry traces sampled at 100% for SCADA-event hot path, 10% elsewhere, 100% for any error.

### 7.4 Audit (separate from operational logging)
- Every switching action writes an immutable audit row (see d09 §4).
- Audit storage is the regulatory record. Operational logs are not.

---

## 8. Deployment topology

| Environment | Zone presence | Purpose |
|---|---|---|
| Dev | OpNET-equivalent only (developer machines + shared dev sandbox) | Inner loop, no XA21, mock SCADA |
| SIT | OpNET + DMZ + CorpNET (scaled-down) | Integration testing with mocked-or-staged XA21 |
| Pre-Prod | OpNET + DMZ + CorpNET (production-equivalent) | Performance, NERC CIP rehearsal, cutover rehearsal, operator UAT |
| Prod | Full | Production |

CIP-010 baseline configs maintained for SIT, Pre-Prod, and Prod. Dev is excluded from the ESP.

---

## 9. Critical non-functionals

| NFR | Target | Notes |
|---|---|---|
| Operator-facing latency P95 | <200ms read, <500ms write | Beyond which operators perceive lag versus the legacy app |
| Storm throughput | 1000 SCADA events/min sustained for 30 min | Multi-circuit cascade scenario |
| Availability of OpNET tier | 99.9% measured monthly during operating hours; planned outage windows excluded | Outages are operationally significant, not just SLA-significant |
| Audit completeness | 100% — no acceptable loss | Regulatory; CIP-007 R4 |
| RPO (data) | ≤1 minute | AG sync replica |
| RTO (OpNET tier) | ≤15 min app failover; ≤2 hr full-DC failover | Acceptable based on operator manual workaround |
| MTTR for DMZ gateway | ≤5 minutes | Active/active HA |

---

## 10. What this architecture refuses to do

- **No microservices.** Already covered (AD-01).
- **No event sourcing as primary persistence.** AD-09.
- **No cloud anything.** Confirmed out of scope.
- **No GraphQL.** REST suffices; team skill alignment.
- **No service mesh.** mTLS handled by IIS + cert tooling; mesh adds zone-crossing complexity.
- **No frontend micro-frontends.** One Angular app per zone, Nx monorepo.
- **No workflow engine** (Camunda, Elsa, etc.). The switching workflow is finite and well-known; explicit state-machine code is more auditable than a configurable BPMN engine.

---

## 11. Open architectural questions (decision before Wave D)

1. **Reverse-proxy / WAF vendor.** Default: existing utility-standard appliance. Confirm.
2. **PAM tooling for CIP-005 R2.** Default: existing utility tooling. Confirm.
3. **SIEM destination and retention floor.** Default: existing utility SIEM. Confirm.
4. **Internal CA for mTLS.** Default: existing utility internal CA. Confirm.
5. **CIP impact rating for the in-scope BCS.** Default: Medium. Confirm with CIP Senior Manager — Low changes the cost basis materially.

---

## 12. Open trade-offs flagged for the team

- **Always On AG sync replica** in OpNET vs simpler log-shipping: AG wins on RPO but adds licensing cost (SQL Server EE per replica) and baseline-config burden. Cost named in d09 §11.
- **RabbitMQ vs SQL Server Service Broker:** RabbitMQ wins on tooling and ecosystem; Service Broker wins if the operator team will only support SQL-resident infrastructure. If pushed back at the Wave A review gate, fallback is Service Broker.
- **SignalR vs polling for operator UI updates:** SignalR wins on UX; adds a long-lived connection profile through IIS. Mitigation: WebSocket only, no fallback transports — fallback transports complicate the IIS module surface and CIP-007 R1 baseline.
- **Dapper vs EF Core on hot path:** Hybrid (AD-10) is right; the cost is two data-access idioms in the codebase, mitigated by clearly bounded use (hot path only).
