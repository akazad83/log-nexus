# Network & Boundary Design
**Deliverable #10 — Wave A: Foundations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave A review gate.
**Cross-refs:** [d07 — Architecture Outline](d07-architecture-outline.md) · [d09 — Database Design Principles](d09-database-design-principles.md)

---

## 1. Purpose & Scope

Defines the zone topology, allowed protocols, gateway behavior, and NERC CIP-relevant network controls for the modernized switching order management suite. Does **not** specify firewall vendor SKUs (delivered in Wave E DevOps blueprint) or application-layer security (in d07 §6).

---

## 2. Zone topology

The OpNET / DMZ / CorpNET split is **fixed** (per project constraints). Mapping to the Purdue Reference Model:

| Zone | Purdue Level | NERC CIP role | Hosts |
|---|---|---|---|
| **OpNET** | L3 | Electronic Security Perimeter (ESP) for Medium Impact BCS | Switching Order API, Operator Web, RabbitMQ cluster, SQL Server primary + sync replica, AD, SIEM, Grafana, internal CA, XA21 SCADA, Rapid Restore connector, operator workstations |
| **DMZ** | L3.5 | Intermediate System for IRA (CIP-005 R2); Electronic Access Point (EAP) | Integration Gateway, Message Bridge, async DB replica, reverse proxy/WAF, SCADA SOAP wrappers, jump server |
| **CorpNET** | L4 | Outside ESP | Reporting Web/API, Entra ID, ServiceNow, Power BI, corporate SIEM forwarder, end-user workstations |

**No direct OpNET ↔ CorpNET path exists. Anywhere. At any layer. Period.** This is the load-bearing constraint of the design and is enforced at the firewall, not in application code.

---

## 3. Allowed protocols (default-deny baseline; the table is the allowlist)

### 3.1 OpNET internal (within ESP)

| From | To | Protocol | Port | Auth | Notes |
|---|---|---|---|---|---|
| Operator workstation | Operator Web (IIS) | HTTPS | 443 | Kerberos | Workstation cert pinning at IIS |
| Operator Web | Switching Order API | HTTPS | 443 | Kerberos | Same-zone |
| Switching Order API | SQL Server primary | TDS | 1433 | gMSA / Kerberos | TLS required |
| Switching Order API | RabbitMQ | AMQP/TLS | 5671 | mTLS | mTLS, not just TLS |
| Switching Order API | SIEM | Syslog/TLS | 6514 | mTLS | Audit + ops |
| RabbitMQ ↔ RabbitMQ peer | (cluster) | AMQP/TLS | 5671 | mTLS | Cluster traffic |
| AD | Domain members | Kerberos / LDAPS | 88 / 636 | n/a | Standard AD plumbing |

### 3.2 OpNET ↔ DMZ (ESP boundary — the EAP)

| From | To | Protocol | Port | Auth | Notes |
|---|---|---|---|---|---|
| Switching Order API | DMZ Gateway | HTTPS | 443 | mTLS | **OpNET-originated outbound** |
| OpNET RabbitMQ | DMZ RabbitMQ shovel | AMQP/TLS | 5671 | mTLS | Shovel runs in DMZ; OpNET is the source of truth for OT traffic |
| SQL Server primary | DMZ async replica | TDS over IPSec | 1433 | gMSA + IPSec | AG endpoint; encryption mandatory |
| OpNET SIEM forwarder | DMZ logging egress | Syslog/TLS | 6514 | mTLS | Redacted summary stream only |

**No DMZ-originated connections to OpNET.** Inbound to OpNET is forbidden at the EAP. Anything that looks like inbound to OpNET (e.g., XA21 events, Rapid Restore acks) is implemented as DMZ-publish-to-queue → OpNET-pull. **Non-negotiable.**

### 3.3 DMZ ↔ CorpNET

| From | To | Protocol | Port | Auth | Notes |
|---|---|---|---|---|---|
| Reporting API (CorpNET) | DMZ async DB replica | TDS over IPSec | 1433 | gMSA + IPSec | Read-only |
| CorpNET SIEM forwarder | DMZ syslog egress | Syslog/TLS | 6514 | mTLS | Mirror of redacted ops summary |
| ServiceNow / corporate ticketing | DMZ webhook receiver | HTTPS | 443 | OAuth 2.0 client credentials | If ITSM integration is in scope |

### 3.4 DMZ ↔ external (asset, GIS, WMS, notification, XA21)

| From | To | Protocol | Port | Auth | Notes |
|---|---|---|---|---|---|
| DMZ Gateway | XA21 (legacy) | SOAP/HTTPS | per vendor | Vendor-defined (likely cert) | Wrap unchanged |
| DMZ Gateway | Asset Mgmt | HTTPS REST | 443 | OAuth 2.0 | Reference data sync |
| DMZ Gateway | GIS | HTTPS REST | 443 | OAuth 2.0 | Per-call lookup |
| DMZ Gateway | Notification (SMS / email) | HTTPS REST | 443 | OAuth 2.0 | Outbound only |
| DMZ Gateway | Rapid Restore | HTTPS REST | 443 | OAuth 2.0 | Field hand-off |

### 3.5 Privileged access (CIP-005 R2)

| From | To | Path | Notes |
|---|---|---|---|
| Admin workstation (CorpNET) | DMZ jump server | RDP/SSH over MFA | PAM tooling required; session recording mandatory |
| DMZ jump server | OpNET admin endpoints | RDP/SSH over Kerberos | Time-bound elevation; full session log to SIEM |

---

## 4. Gateway (DMZ) behavior

### 4.1 What the gateway does
- **Protocol translation only.** SOAP↔REST, AMQP↔HTTP, etc.
- **Schema validation** on every inbound message. Reject on first violation. No "be liberal in what you accept."
- **Authentication enforcement** at every hop (mTLS in/out, OAuth where target supports it).
- **Allowlist of operations** — only the operations explicitly enumerated in d07 §4 are routed; all others are 403.
- **Rate limiting and concurrency caps** per source, sized for a 10x storm burst.
- **Idempotency key passthrough.** The gateway does not generate idempotency keys; it propagates them.

### 4.2 What the gateway does NOT do
- **No business logic.** If the gateway needs to know what a switching card is, the design is wrong.
- **No state caching of switching state.** Stateless except for connection pools and an idempotency dedup window (≤60s).
- **No operator UI.** None. Ever.
- **No persistent storage** beyond ephemeral logs and the dedup window.
- **No long-running orchestration.** Saga state lives in OpNET.

### 4.3 Failure modes
- **Fail-closed at the EAP for OT-relevant integrations; fail-open for non-OT integrations.**
  - SCADA wrapper down → OpNET continues on local card state; operators notified that SCADA event ingest is degraded.
  - Asset-mgmt sync down → OpNET uses last-known cached reference data; operators notified.
  - Notification service down → outbound alerts queued; operators notified.
- **No degraded mode that bypasses authorization.** If authorization can't be reached, the workflow stops at that step. **Safety > availability.**

---

## 5. NERC CIP control mapping

| Standard | Requirement | Where addressed |
|---|---|---|
| CIP-002 R1 | BCS impact rating | Assumed Medium per project default; confirm with CIP Senior Manager. Drives applicability of CIP-005/007/010/011/013. |
| CIP-005 R1 | ESP definition | OpNET = ESP. EAP = DMZ boundary. Documented in §2–§3. |
| CIP-005 R2 | Interactive Remote Access via Intermediate System | DMZ jump server, MFA, session recording. §3.5. |
| CIP-007 R1 | Ports/services minimization | Default-deny matrix in §3. Each app's listening surface enumerated in d07 §3. |
| CIP-007 R3 | Malicious code prevention | Endpoint AV on every OpNET/DMZ host. Build-pipeline scanning. (DevOps blueprint, Wave E.) |
| CIP-007 R4 | Security event monitoring | SIEM in OpNET; all auth + access + admin events. §3.1, d07 §7.1. |
| CIP-007 R5 | System access controls | AD-backed RBAC, gMSA service identities, password/cert rotation. d07 §6. |
| CIP-010 R1 | Baseline configuration | Per-environment baselines for SIT/Pre-Prod/Prod. (DevOps blueprint.) |
| CIP-010 R3 | Vulnerability assessment | Pre-deployment scan + annual active scan. (Test strategy.) |
| CIP-011 R1 | BES Cyber System Information protection | Encryption at rest (TDE) + in transit (TLS 1.3 / mTLS). d09 §8. |
| CIP-013 R1 | Supply chain | Vendor risk assessment for any new hardware/software (RabbitMQ, WAF, etc.). Pre-procurement gate. |

**Brutal-honesty note:** the difference between Low and Medium impact rating is roughly a 20–35% delivery-cost delta on this footprint. We default to Medium per project context. If your CIP Senior Manager rules **Low**, retire the CIP-010 baseline burden and the CIP-005 R2 IRA controls — but get it in writing, dated, and signed.

---

## 6. Trade-offs and named costs

| Trade-off | Choice | Cost named |
|---|---|---|
| Single-vendor firewall stack vs heterogeneous | Single-vendor | Vendor lock-in, but operator team already trained on it; CIP-010 baseline simpler |
| DMZ gateway active/active vs active/passive | Active/active | Higher infra cost (2x); but no failover-window operator visibility issue |
| AG sync vs async replica between OpNET and DMZ | **Async to DMZ** | Reporting can be ≤30s stale; sync replication across the EAP would cement OT state changes to a DMZ replica's availability and is wrong |
| IPSec for AG endpoint vs TDS-over-TLS only | IPSec | Belt-and-braces — TDS-over-TLS is enough cryptographically; IPSec adds CIP-007 defense-in-depth at modest perf cost |
| Allow inbound DMZ→OpNET on a narrow allowlist vs strict OpNET-pulls-only | **OpNET-pulls-only** | Higher latency for some patterns; eliminates an entire class of EAP findings |

---

## 7. Open network questions (decision before Wave E)

1. **Reverse-proxy / WAF vendor.** Default: existing utility-standard appliance. Confirm.
2. **Internal CA** for mTLS issuance and rotation. Default: existing internal CA. Confirm.
3. **PAM tooling** for CIP-005 R2 jump-server access. Default: existing PAM. Confirm.
4. **SIEM destination and retention floor.** Default: existing utility SIEM, 7-year retention online for CIP-007 R4 events.
5. **NTP source for ESP devices.** CIP-007 R4 requires accurate clocks for log correlation. Default: existing GPS-disciplined NTP appliance in OpNET.

---

## 8. What this design refuses to do

- **No port exceptions for "just for testing."** Every port allowed in prod is allowed by design; no temporary holes.
- **No shared service accounts spanning the EAP.** gMSAs in OpNET stay in OpNET. CorpNET service principals stay in CorpNET.
- **No "expose this just for the dashboard."** CorpNET dashboards read from the DMZ replica, not from OpNET. If a metric isn't worth a DMZ summarization step, it isn't worth showing in CorpNET.
- **No Python/PowerShell scripts crossing the EAP at runtime.** Cross-zone work is HTTP API calls or queue messages. Period.
- **No "vendor backdoor" remote support tunnels** into OpNET. Vendor work happens through the same CIP-005 R2 IRA path or it doesn't happen at all.
