# Database Design Principles
**Deliverable #9 — Wave A: Foundations**
**Status:** Phase 1 baseline. Subject to ratification at the Wave A review gate.
**Cross-refs:** [d07 — Architecture Outline](d07-architecture-outline.md) · [d10 — Network & Boundary Design](d10-network-boundary-design.md)

---

## 1. Purpose & Scope

Fixes the SQL Server 2025 EE design stance for the modernized switching order management suite. Covers normalization, partitioning, indexing, audit/temporal, performance targets, and the migration semantic-fidelity bar. Does **not** cover ETL mechanics (delivered in d08, Wave E) or specific schema content (delivered iteratively per epic from Wave C onward).

---

## 2. Database stance (decisions already made)

| ID | Decision | Rationale |
|---|---|---|
| DB-01 | **One database per app, schema per bounded context** | Modular monolith → one DB. Schemas (`SwitchingCard`, `Tagging`, `Authorization`, `Field`, `Audit`, `Reference`, `Notification`) give bounded-context isolation without operational fragmentation |
| DB-02 | **3NF for transactional, denormalized star/snowflake for reporting** | OT writes need normalization for integrity; reporting tier in DMZ replica gets dimensional views (indexed views or scheduled materializations) |
| DB-03 | **System-versioned temporal tables** for every entity in switching workflow | SQL Server 2025-native, zero application code, every state change captured. Replaces the legacy Ingres "history table" pattern |
| DB-04 | **Ledger tables (updatable) for the Audit schema only** | Cryptographic immutability where it matters (regulatory record); not on operational tables (perf cost) |
| DB-05 | **bigint identity** for surrogate keys, not GUIDs | On-prem, single primary, no merge replication. GUIDs add 2.5x index size and pointless complexity. Operators reference card numbers (human-readable); we keep `CardNumber` as a separate natural-ish key |
| DB-06 | **Time-partitioned** `SwitchingCard.Card`, `Audit.AuditEvent`, `Audit.AuditChain` by `EventMonth` | Sliding-window retention; fast reload of older partitions to cold storage; query plan stability |
| DB-07 | **Always On AG**: sync replica in OpNET (RPO ≤1 min), async replica in DMZ (read-only reporting) | RPO + zone separation. License cost named in §11 |
| DB-08 | **TDE + TLS 1.3 mandatory**; column-level encryption only where data classification requires it | Defense in depth, CIP-011 R1. Always Encrypted not used (perf cost, query restrictions, low marginal value over TDE+TLS for this footprint) |
| DB-09 | **Read replicas are read-only**, accessed only via the Reporting API | Application code never reads from primary for reporting. Forced by infrastructure (different connection strings per service) |
| DB-10 | **Reference data is cached locally**, sourced from Asset Mgmt nightly with manual refresh | Asset Mgmt is the source of truth; we don't dual-master |
| DB-11 | **Schema is owned by DBAs in DDL scripts under version control**; EF Core migrations are *applied*, not authoritative | The schema is too important to be a side effect of C# class definitions |

---

## 3. Normalization stance

- **Operational schemas** (`SwitchingCard`, `Tagging`, `Authorization`, `Field`, `Notification`): 3NF strict. No "wide tables for convenience." Reporting denormalization happens in views, not tables.
- **Reference schema**: snapshot of authoritative reference data, normalized. ETag-based delta sync for change detection.
- **Audit schema**: append-only, denormalized intentionally — each event carries enough context to be self-describing in a regulatory review without joins.
- **Reporting (DMZ replica)**: indexed views and a small set of materialized views for known dashboard patterns. Star-schema only if a dashboard genuinely needs it; we don't pre-build a warehouse.

---

## 4. Audit & temporal model

### 4.1 Two layers, distinct purposes

| Layer | Storage | Purpose | Write path |
|---|---|---|---|
| **Temporal history** | System-versioned temporal tables | "What did this row look like at time T?" | Automatic, by SQL Server, on every UPDATE/DELETE |
| **Audit event stream** | `Audit.AuditEvent` (ledger updatable) + `Audit.AuditChain` (cryptographic chain) | "Who did what, when, why?" — regulatory record | Explicit by application, every state change |

These are **not redundant.** Temporal answers "what was the state"; audit answers "who caused the state and what was the intent." Both are required.

### 4.2 Audit event schema (logical)

```
Audit.AuditEvent
├── EventId          bigint identity, PK
├── EventTimestamp   datetime2(7), UTC, indexed; partitioning column on EventMonth
├── ActorUserId      varchar(100)        — AD SID for human, gMSA name for service
├── ActorRole        varchar(64)         — resolved at write time, not later
├── Action           varchar(64)         — controlled vocabulary (~80 values)
├── EntityType       varchar(64)         — e.g., 'SwitchingCard', 'Tag'
├── EntityId         bigint              — soft FK; entities live in other schemas
├── CorrelationId    uniqueidentifier    — W3C trace ID
├── Payload          nvarchar(max), JSON — the diff, not the full state
├── Reason           nvarchar(500)       — operator-supplied where workflow requires
└── ChainHash        binary(32)          — SHA-256 of (PrevHash || RowContent)
```

The ledger feature ensures any tampering with `Audit.AuditEvent` is detectable; `ChainHash` provides app-level continuity even if the ledger feature is later relaxed (or unavailable in a downgraded edition).

### 4.3 What we DO NOT do
- **No event sourcing** as the primary persistence model (covered in d07 AD-09).
- **No "audit table per entity"** — we had this in legacy and it produced inconsistent coverage. Single audit stream, controlled vocabulary, enforced at the data-access layer.
- **No PII in audit `Payload`** — actor identity is minimal (SID, role); operator-supplied reasons are reviewed for PII at ingestion.

---

## 5. Partitioning strategy

| Table | Partition column | Window | Purpose |
|---|---|---|---|
| `SwitchingCard.Card` | `CreatedMonth` (computed) | Monthly | Long-tail queries; cold partitions move to slower storage |
| `Audit.AuditEvent` | `EventMonth` (computed) | Monthly | 7-year online retention → 84 partitions; sliding-window archive |
| `Audit.AuditChain` | `EventMonth` (computed) | Monthly | Pairs with `AuditEvent` partitions |
| `Tagging.Tag` | (not partitioned initially) | n/a | Volume too low to justify; revisit at 5-year mark |

**Sliding-window mechanics:**
- New partition created automatically by SQL Agent job on the 1st of each month.
- Oldest partition older than retention floor switched out to archive DB.
- Archive DB lives on slower storage in OpNET; queries to archive go through a separate connection string and surface a "slow path" warning to operators.

---

## 6. Indexing strategy

### 6.1 Defaults
- **Clustered index on the natural read pattern** for each table — usually `(EntityKey, EventTimestamp)` for time-series, `(CardId)` for entity tables.
- **Filtered indexes on hot statuses** — e.g., `WHERE State IN ('Open','InProgress')` for `SwitchingCard.Card`. Operational set is tiny relative to total volume; filtered indexes stay cache-resident.
- **Covering indexes on the top 10 operator queries.** Identified during Phase 1 detailed design from the legacy Ingres workload trace.
- **No "just-in-case" indexes.** Every index has a query that justifies it, named in the index extended property.

### 6.2 What we don't do
- **No columnstore on transactional tables** — wrong workload shape.
- **Columnstore in the DMZ replica** for reporting-only large fact tables — yes, where a real reporting query benefits.
- **No hypothetical indexes** — recommend through Query Store, validate, then add.

### 6.3 Index governance
- Monthly review of unused indexes via `sys.dm_db_index_usage_stats`.
- Drop with prejudice — every retained unused index is a write tax.

---

## 7. Performance targets

| Operation | Target P95 | Driver |
|---|---|---|
| Single-card read (operator screen open) | <50ms server-side | Operator perception of "instant" |
| Card list filtered by district + state | <150ms server-side | Dashboard refresh |
| Audit insert | <20ms server-side | On the hot SCADA event path; must not back up the queue |
| SCADA event → card creation | <200ms DB time end-to-end | Within the 2s end-to-end budget (d07 §9) |
| Reporting query (CorpNET) | <3s server-side | Dashboard tolerance |
| Storm: 1000 events/min sustained | No P95 degradation on transactional path | Multi-circuit cascade |

### 7.1 How we hold the line
- Query Store enabled; regression alerts on plan changes for the top 50 queries by frequency.
- `sp_WhoIsActive`-equivalent automated capture during pre-prod load tests.
- DBA gate: any new index, view, or schema change reviewed against the perf test suite before merge to main.

---

## 8. Migration semantic fidelity (Ingres → SQL Server 2025)

Detailed strategy is delivered in **d08** (Wave E). Principles set here:

### 8.1 Hard rules
- **No silent semantic loss.** Every Ingres column type maps to a SQL Server type with a documented decision and (if downcast) a flagged risk.
- **Ingres "history" semantics are replaced**, not preserved literally. Existing history rows migrate into the new temporal table's `_History` shadow with a synthetic version transition; further history is captured by the system.
- **Ingres business rules embedded in 4GL code are extracted into application code or check constraints before migration**, not after. Brutal: the cost of finding hidden business rules in OpenRoad is the **second-largest hidden cost on this program** (after operator SME availability).

### 8.2 Type mapping defaults

| Ingres | SQL Server 2025 | Notes |
|---|---|---|
| `INTEGER1/2/4` | `tinyint`/`smallint`/`int` | Direct |
| `INTEGER8` | `bigint` | Direct |
| `DECIMAL(p,s)` | `decimal(p,s)` | Direct |
| `MONEY` | `decimal(19,4)` | Avoid SQL Server `money` (rounding gotchas) |
| `FLOAT` | `float` | Direct, but flag — `decimal` preferred for any value with semantic precision |
| `CHAR(n)` | `char(n)` | Trailing-space semantics differ; verify per column |
| `VARCHAR(n)` | `varchar(n)` | Direct; default collation `Latin1_General_100_CI_AS_SC` unless workflow needs case sensitivity |
| `NCHAR/NVARCHAR` | `nchar/nvarchar` | Direct |
| `DATE` | `date` | Drop trailing time component if always 00:00 |
| `INGRESDATE` | `datetime2(0)` | Resolution; flag any column with sub-second use |
| `LONG VARCHAR` | `varchar(max)` | Verify size distribution; consider FILESTREAM for large blobs |
| `OBJECT_KEY/TABLE_KEY` | `bigint identity` | Surrogate replacement; preserve original as natural key only if referenced externally |

### 8.3 Reconciliation
Every migrated table has:
- **Row count check** (source vs target) — exact match required.
- **Hash check** on a deterministic projection of business columns — exact match required.
- **Sampled deep-equality** on N% of rows.
- **Sign-off** by data owner before parallel-run begins.

---

## 9. Concurrency and isolation

- **Default isolation: READ COMMITTED SNAPSHOT** (RCSI). Avoids reader/writer blocking on a hot OT path.
- **Snapshot isolation** enabled for explicit long-running reports.
- **Optimistic concurrency** on entity updates via a `RowVersion` (`rowversion`) column. Last-write-wins is unacceptable for switching state; conflicting updates surface as an HTTP 409 to the operator with a guided merge flow.
- **No `NOLOCK` / `READ UNCOMMITTED` hints in application code. Ever.** Code review gate.

---

## 10. Backup, recovery, retention

| Concern | Approach | Target |
|---|---|---|
| Full backup | Daily | RPO ≤24h baseline |
| Differential | Every 6h | RPO ≤6h baseline |
| Transaction log | Every 5 min | RPO ≤5 min (AG sync replica brings effective RPO to ≤1 min) |
| Backup integrity | Weekly `RESTORE VERIFYONLY` in pre-prod | CIP-009 R1 |
| Off-site copy | Daily encrypted copy to DR site | CIP-009 R2 |
| Retention floor | 7 years online for transactional + audit; ≥10 years archive | Per project default; NERC CIP minimum is shorter |
| Test restore | Quarterly full-restore drill in pre-prod | CIP-009 R3 |

---

## 11. Cost-named trade-offs

| Trade-off | Choice | Cost named |
|---|---|---|
| AG sync replica in OpNET | Yes | SQL Server 2025 EE per replica + storage. Justified by RPO ≤1 min on safety-critical workflow |
| Ledger tables on Audit schema | Yes | ~10–15% write overhead on audit; full-table cryptographic verification job nightly. Justified by regulatory record integrity |
| Temporal tables on every operational entity | Yes | ~5% write overhead, ~2x storage on history (compressed). Justified by replacing manual history infrastructure from legacy |
| `bigint` PK vs `int` | bigint everywhere | 2x PK index size for forward-safety. Cheap insurance |
| Always Encrypted | No | Avoided perf cost and query restrictions; TDE + TLS suffices for current data classification. Revisit if classification changes |
| In-Memory OLTP for hot path | No | Workload doesn't justify the operational complexity at this volume |

---

## 12. Open database questions (decision before Wave E)

1. **Collation default.** `Latin1_General_100_CI_AS_SC` is recommended; confirm with data owner that no workflow requires case sensitivity.
2. **TempDB sizing.** Sized for 8x typical concurrency; revisit after first storm test.
3. **Resource Governor pools.** Default: separate pool for reporting connections only. Revisit if hot path competes with reporting.
4. **Maintenance window.** Default: weekly 2-hour window, off-shift; index maintenance and stats update.
5. **Data classification register.** Required input from CIP Senior Manager before column-level encryption decisions are final.

---

## 13. What this design refuses to do

- **No ORM-driven schema generation as the source of truth** (DB-11).
- **No triggers for business logic.** Triggers used only for the temporal-table pattern (which is system-managed). Application invariants live in application code.
- **No cross-schema FKs.** Bounded-context isolation. Cross-context references are by ID only; integrity is enforced at the application layer via integration events.
- **No `sysadmin` connections from application code.** Application accounts have least-privilege, scoped to their schema.
- **No SQL CLR.** Operational complexity, security review burden, no benefit for this workload.
