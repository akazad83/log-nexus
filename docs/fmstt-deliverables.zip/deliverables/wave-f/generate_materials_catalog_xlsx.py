"""
generate_materials_catalog_xlsx.py
Generates 13-materials-catalog.xlsx — the index of every deliverable across Waves A–E.

Source-of-truth markdown: d13-materials-catalog-spec.md
Re-run after adding, removing, or materially changing any deliverable.

Usage:
    python generate_materials_catalog_xlsx.py [--output PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

HERE = Path(__file__).resolve().parent
DELIVERABLES_ROOT = HERE.parent
sys.path.insert(0, str(DELIVERABLES_ROOT))

from _xlsx_helpers import (  # noqa: E402
    HEADER_BG,
    PHASE_COLORS,
    fill,
    freeze_top,
    set_widths,
    title_cell,
    write_headers,
    write_row,
)

WAVE_COLORS = {
    "A": "DDEBF7",
    "B": "E2EFDA",
    "C": "FFF2CC",
    "D": "FCE4D6",
    "E": "F8CBAD",
    "F": "E4DFEC",
    "shared": "D9D9D9",
}

# --------------------------------------------------------------------------
# Documents
# --------------------------------------------------------------------------

DOCUMENTS_HEADERS = [
    "ID", "Name", "Wave", "Type", "Owner", "Markdown source",
    "DOCX output", "XLSX output", "Purpose", "Stage of use",
]

# (id, name, wave, type, owner, md, docx, xlsx, purpose, stage)
DOCUMENTS = [
    # Wave A
    ("d07", "Architecture Outline",                              "A", "Design",
     "Solution Architect",
     "wave-a/d07-architecture-outline.md", "", "",
     "Application-tier architecture; bounded contexts; cross-zone interaction patterns; identity; observability",
     "P1 (ratification); referenced through P2a-P6"),
    ("d09", "Database Design Principles",                        "A", "Design",
     "DBA Lead",
     "wave-a/d09-database-design-principles.md", "", "",
     "Schema stance; partitioning; audit/temporal; performance targets; Ingres→SQL type mapping",
     "P1 (ratification); referenced through P2a-P6"),
    ("d10", "Network & Boundary Design",                         "A", "Design",
     "CIP Compliance Lead",
     "wave-a/d10-network-boundary-design.md", "", "",
     "Zone topology; protocol allowlist; gateway behavior; NERC CIP control mapping",
     "P1 (ratification); referenced through P2a-P6"),
    # Wave B
    ("d01-spec", "Master Plan Workbook Spec",                    "B", "Plan",
     "Program Director",
     "wave-b/d01-master-plan-spec.md", "", "wave-b/build/01-master-plan.xlsx",
     "Source of truth describing the master plan workbook structure",
     "P1 onward (regenerated as plan evolves)"),
    ("d01", "Master Plan Workbook",                              "B", "Plan",
     "Program Director",
     "", "", "wave-b/build/01-master-plan.xlsx",
     "12 sheets: WBS (101 rows), Phases, Timeline, Milestones, Workstreams, Dependencies, Risks, Assumptions, RACI, Roles",
     "Operational source of truth for the program plan"),
    ("d02", "Timeline Narrative",                                "B", "Plan",
     "Program Director",
     "wave-b/d02-timeline-narrative.md",
     "wave-b/build/02-timeline-narrative.docx", "",
     "Brutal-honesty per-phase ranges; top-5 swing factors; bet-on number for program close",
     "Sponsor briefing; steering committee monthly review"),
    # Wave C
    ("d03", "Backlog Engineering Pipeline Guide",                "C", "Backlog",
     "BA Lead",
     "wave-c/d03-backlog-pipeline-guide.md",
     "wave-c/build/03-backlog-pipeline-guide.docx", "",
     "Pipeline rules; story-splitting heuristics keyed to switching workflow; DoR/DoD; CIP/audit threading",
     "P1 ratification; followed every sprint through P6"),
    ("d04-epic", "Epic Template",                                "C", "Template",
     "BA Lead",
     "wave-c/d04-templates/epic-template.md", "", "",
     "Authoring template for Epics; includes worked example",
     "Per Epic, P1 onward"),
    ("d04-story", "User Story Template",                         "C", "Template",
     "BA Lead",
     "wave-c/d04-templates/user-story-template.md", "", "",
     "Authoring template for User Stories with INVEST + DoR + DoD checklists",
     "Per Story, P1 onward"),
    ("d04-ac", "Acceptance Criteria Template",                   "C", "Template",
     "BA Lead",
     "wave-c/d04-templates/acceptance-criteria-template.md", "", "",
     "Gherkin functional + non-functional addendum; happy/exception/NFR-only examples",
     "Per AC, P1 onward"),
    ("d04-task", "Task Template",                                "C", "Template",
     "Tech Lead — Backend",
     "wave-c/d04-templates/task-template.md", "", "",
     "Developer-shaped <1-day tasks with DoD per task",
     "Per Task, P1 onward"),
    ("d04-spike", "Spike Template",                              "C", "Template",
     "Solution Architect",
     "wave-c/d04-templates/spike-template.md", "", "",
     "Bounded research; 3-day timebox; outputs a decision",
     "Per Spike, P1 onward"),
    ("d04-bug", "Bug Template",                                  "C", "Template",
     "Test Lead",
     "wave-c/d04-templates/bug-template.md", "", "",
     "Defect template with priority guide; audit/safety/CIP impact required fields",
     "Per defect, P2a onward"),
    ("d04-nfr", "NFR Template",                                  "C", "Template",
     "Solution Architect",
     "wave-c/d04-templates/nfr-template.md", "", "",
     "Non-functional requirement template; categories with worked examples",
     "Per NFR, P1 onward"),
    ("d04-bundle", "Templates Bundle (rendered)",                "C", "Template",
     "BA Lead",
     "", "wave-c/build/04-templates-bundle.docx", "",
     "All 7 templates concatenated for governance review",
     "Wave C ratification; on demand"),
    # Wave D
    ("d06-spec", "Estimation Worksheet Spec",                    "D", "Estimation",
     "Program Director",
     "wave-d/d06-estimation-spec.md", "", "wave-d/build/06-estimation-worksheet.xlsx",
     "Method, structure, roll-up targets for the estimation worksheet",
     "P1 baseline; re-baselined per gate"),
    ("d06", "Estimation Worksheet",                              "D", "Estimation",
     "Program Director",
     "", "", "wave-d/build/06-estimation-worksheet.xlsx",
     "45 epics × three-point estimates; rollups by phase/category/workstream/confidence",
     "Drives d05 sizing; sponsor commitments; sprint planning"),
    ("d05-spec", "Resource Plan Workbook Spec",                  "D", "Resource",
     "Program Director",
     "wave-d/d05-resource-plan-spec.md", "", "wave-d/build/05-resource-plan.xlsx",
     "Source of truth for the resource plan workbook structure",
     "P1 baseline; re-baselined per gate"),
    ("d05", "Resource Plan Workbook",                            "D", "Resource",
     "Program Director",
     "", "", "wave-d/build/05-resource-plan.xlsx",
     "23 roles × 7-phase ramp; skills matrix; key-person risk; on/off-shore mix; cost sketch",
     "Staffing manager + program finance reference"),
    ("d05-memo", "Brutal-Honesty Memo",                          "D", "Resource",
     "Program Director",
     "wave-d/d05-brutal-honesty-memo.md",
     "wave-d/build/05-brutal-honesty-memo.docx", "",
     "Top-5 places estimates are most likely wrong; named triggers; what the plan refuses to do",
     "Sponsor briefing companion to d05/d06"),
    # Wave E
    ("d08", "Data Migration Strategy",                           "E", "Engineering",
     "DBA Lead",
     "wave-e/d08-data-migration-strategy.md",
     "wave-e/build/08-data-migration-strategy.docx", "",
     "7-phase Ingres→SQL migration; tier 1+2+3 reconciliation; per-district parallel-run mechanics",
     "P1 ratification; executed P2a-P5"),
    ("d12", "DevOps & CI/CD Blueprint",                          "E", "Engineering",
     "DevOps Lead",
     "wave-e/d12-devops-blueprint.md", "", "",
     "Pipeline stages; trunk-based branching; on-prem IIS deploy; secrets; rollback; CIP integration",
     "P1 ratification; executed P2a-P6"),
    ("d11", "Test Strategy + Cutover Playbook Outline",          "E", "Engineering",
     "Test Lead",
     "wave-e/d11-test-strategy.md",
     "wave-e/build/11-test-strategy.docx", "",
     "11 test types; per-phase commitments; storm-test cadence; cutover playbook outline",
     "P1 ratification; executed P2a-P6; cutover playbook expanded in P4 dry-runs"),
    # Wave F
    ("d13-spec", "Materials Catalog Spec",                       "F", "Catalog",
     "Program Director",
     "wave-f/d13-materials-catalog-spec.md", "", "wave-f/build/13-materials-catalog.xlsx",
     "Source of truth describing this catalog",
     "Wave F gate; regenerated when deliverables change"),
    ("d13", "Materials & Templates Catalog",                     "F", "Catalog",
     "Program Director",
     "", "", "wave-f/build/13-materials-catalog.xlsx",
     "Index of every deliverable, template, checklist, generator, register, and decision",
     "Onboarding; auditor evidence walk; navigation"),
]

# --------------------------------------------------------------------------
# Templates
# --------------------------------------------------------------------------

TEMPLATES_HEADERS = ["Template", "Path", "When to use", "Owner", "Required checklists"]
TEMPLATES = [
    ("Epic",               "wave-c/d04-templates/epic-template.md",
     "Authoring a new Epic in P1+", "BA Lead", "Outcome statement; Sponsor-recognizable success criterion"),
    ("User Story (INVEST)","wave-c/d04-templates/user-story-template.md",
     "Authoring a new Story in P1+", "BA Lead", "INVEST self-check; DoR; DoD"),
    ("Acceptance Criteria","wave-c/d04-templates/acceptance-criteria-template.md",
     "Per Story; min 4 AC (happy/exception/audit/security)", "BA Lead", "Gherkin scenarios; NFR addendum where applicable"),
    ("Task",               "wave-c/d04-templates/task-template.md",
     "Decomposing a Story into <1-day units", "Tech Leads", "Per-task DoD"),
    ("Spike",              "wave-c/d04-templates/spike-template.md",
     "Bounded research; 3-day timebox", "Solution Architect", "Decision shape; stop conditions"),
    ("Bug",                "wave-c/d04-templates/bug-template.md",
     "Reporting a defect against accepted behavior", "Test Lead",
     "Audit/safety/CIP impact assessment; priority guide"),
    ("NFR",                "wave-c/d04-templates/nfr-template.md",
     "Defining a non-functional requirement", "Solution Architect",
     "Quantitative target; verification method + frequency; failure mode"),
]

# --------------------------------------------------------------------------
# Checklists (embedded across deliverables)
# --------------------------------------------------------------------------

CHECKLISTS_HEADERS = ["Name", "Source", "When to apply", "Owner", "Type"]
CHECKLISTS = [
    ("Story Definition of Ready (DoR)",                "d03 §6.1", "Before sprint planning", "BA Lead + SM", "Backlog"),
    ("Story Definition of Done (DoD)",                 "d03 §7.1", "Before story closes",   "Tech Lead + QA + Operator SME", "Backlog"),
    ("CIP impact assessment (3 questions)",            "d03 §6.3", "Story DoR check",       "BA Lead",   "Compliance"),
    ("INVEST self-check",                              "d04-story",  "Story authoring",      "BA Lead",   "Backlog"),
    ("Bug priority guide",                             "d04-bug",    "Defect triage",        "Test Lead", "Quality"),
    ("Tier 1+2+3 reconciliation",                      "d08 §5",     "Per migrated table",   "DBA Lead",  "Migration"),
    ("Migration sign-off chain (per table)",           "d08 §5.4",   "Before parallel run",  "DBA Lead + Data Owner + CIP + SME", "Migration"),
    ("Cutover T-30 day checklist",                     "d11 §9.1",   "30 days before per-district cutover", "Program Director", "Cutover"),
    ("Cutover T-7 day checklist",                      "d11 §9.1",   "7 days before",        "Program Director", "Cutover"),
    ("Cutover T-2 day checklist",                      "d11 §9.1",   "2 days before",        "Program Director", "Cutover"),
    ("Cutover T-1 day checklist",                      "d11 §9.1",   "Day before",           "Program Director", "Cutover"),
    ("Cutover GO/NO-GO checkpoint",                    "d11 §9.3",   "At each go-no-go gate during cutover", "Sponsor + CIP + SME", "Cutover"),
    ("Cutover rollback decision tree",                 "d08 §7.2",   "When a trigger fires", "Program Director + DBA + CIP", "Cutover"),
    ("Post-cutover T+1h verification",                 "d11 §9.5",   "1 hour post-cutover",  "Tech Lead + DBA",  "Cutover"),
    ("Post-cutover T+24h verification",                "d11 §9.5",   "24 hours post-cutover","Program Director", "Cutover"),
    ("Post-cutover T+7d verification",                 "d11 §9.5",   "7 days post-cutover",  "Program Director", "Cutover"),
    ("Post-cutover T+14d verification",                "d11 §9.5",   "14 days post-cutover", "DBA Lead",         "Cutover"),
    ("CI pipeline gates",                              "d12 §3",     "Every PR + merge",     "DevOps Lead",      "DevOps"),
    ("Storm test pass criteria",                       "d11 §6.4",   "Per storm test run",   "Test Lead + Integration Lead", "Test"),
]

# --------------------------------------------------------------------------
# Workbooks (xlsx artifacts)
# --------------------------------------------------------------------------

WORKBOOKS_HEADERS = ["Deliverable", "Path", "Source spec", "Generator script", "Sheet count", "Purpose"]
WORKBOOKS = [
    ("d01 Master Plan",
     "wave-b/build/01-master-plan.xlsx",
     "wave-b/d01-master-plan-spec.md",
     "wave-b/generate_master_plan_xlsx.py",
     12, "WBS, phases, timeline, milestones, workstreams, dependencies, risks, assumptions, RACI, roles, status legend"),
    ("d05 Resource Plan",
     "wave-d/build/05-resource-plan.xlsx",
     "wave-d/d05-resource-plan-spec.md",
     "wave-d/generate_resource_plan_xlsx.py",
     8, "23 roles × 7-phase ramp; skills matrix; key-person risk; on/off-shore mix; operator-org hours; cost sketch"),
    ("d06 Estimation Worksheet",
     "wave-d/build/06-estimation-worksheet.xlsx",
     "wave-d/d06-estimation-spec.md",
     "wave-d/generate_estimation_xlsx.py",
     8, "45 epics × three-point estimates; rollups; method; velocity; assumptions; risks; confidence legend"),
    ("d13 Materials Catalog",
     "wave-f/build/13-materials-catalog.xlsx",
     "wave-f/d13-materials-catalog-spec.md",
     "wave-f/generate_materials_catalog_xlsx.py",
     10, "This workbook"),
]

# --------------------------------------------------------------------------
# Generator scripts
# --------------------------------------------------------------------------

GENERATORS_HEADERS = ["Script", "Wave", "Produces", "Inputs", "When to run"]
GENERATORS = [
    ("wave-b/generate_master_plan_xlsx.py",            "B", "build/01-master-plan.xlsx",
     "Hardcoded data + d01 spec",
     "Whenever WBS, phases, milestones, risks, assumptions change"),
    ("wave-b/generate_timeline_narrative_docx.py",     "B", "build/02-timeline-narrative.docx",
     "d02-timeline-narrative.md",
     "Whenever the timeline narrative is edited"),
    ("wave-c/generate_pipeline_guide_docx.py",         "C", "build/03-backlog-pipeline-guide.docx (+ optional 04-templates-bundle.docx)",
     "d03 + d04 templates",
     "Whenever the pipeline guide or templates change"),
    ("wave-d/generate_estimation_xlsx.py",             "D", "build/06-estimation-worksheet.xlsx",
     "Hardcoded epic data + d06 spec",
     "Per gate re-baseline (MS-04, MS-08, MS-10, MS-13)"),
    ("wave-d/generate_resource_plan_xlsx.py",          "D", "build/05-resource-plan.xlsx",
     "Hardcoded ramp + skills + d05 spec",
     "When ramp shape, roles, or rates change"),
    ("wave-d/generate_brutal_honesty_memo_docx.py",    "D", "build/05-brutal-honesty-memo.docx",
     "d05-brutal-honesty-memo.md",
     "When memo is edited"),
    ("wave-e/generate_wave_e_docx.py",                 "E", "build/08-data-migration-strategy.docx + build/11-test-strategy.docx",
     "d08 + d11 markdown",
     "When either source markdown changes"),
    ("wave-f/generate_materials_catalog_xlsx.py",      "F", "build/13-materials-catalog.xlsx",
     "Hardcoded inventory + d13 spec",
     "When any deliverable is added, removed, or materially changed"),
    ("_md2docx.py",                                    "shared", "(library; renders any markdown to docx)",
     "n/a",
     "Imported by Wave-C onward generators"),
    ("_xlsx_helpers.py",                               "shared", "(library; openpyxl helpers)",
     "n/a",
     "Imported by Wave-D onward generators"),
]

# --------------------------------------------------------------------------
# Reference Registers
# --------------------------------------------------------------------------

REGISTERS_HEADERS = ["Register", "Where it lives", "Owner", "Update cadence", "Notes"]
REGISTERS = [
    ("Risk register",                  "d01 'Risks' sheet (12 risks pre-loaded from Wave A); mirrored in d06 'Risks' read-only",
     "Program Director", "Per-sprint review; immediate when realized", "P, I, score H/M/L"),
    ("Assumption register",            "d01 'Assumptions' sheet (10 ratified defaults); +2 d06-specific in d06 'Assumptions' sheet",
     "Program Director", "Validated as actuals come in", "Source = ratified default 2026-04-28"),
    ("Dependency register",            "d01 'Dependencies' sheet (8 external dependencies)",
     "Program Director", "Weekly chase; immediate when slipping", "DEP-01..DEP-08"),
    ("Role register",                  "d01 'Roles' sheet (13 leadership roles); fuller version in d05 'Roles' sheet (23 roles inc ICs)",
     "Program Director", "When team shape changes", "d05 is authoritative for staffing"),
    ("Workstream register",            "d01 'Workstreams' sheet (11 workstreams)",
     "Program Director", "Stable through P1; revisit at MS-04", "ARCH, BE, FE, DATA, INT, SEC, DEVOPS, QA, BA, CHG, PM"),
    ("Phase register",                 "d01 'Phases' sheet (9 phases including AO)",
     "Program Director", "Stable; revisit at gates", "P0..P6 + AO"),
    ("Milestone register",             "d01 'Milestones' sheet (15 milestones)",
     "Program Director", "Re-dated at every gate per d02 ranges", "MS-01..MS-15"),
    ("Architectural Decisions",        "d07 §2 'Architectural decisions (already made)' (AD-01..AD-10)",
     "Solution Architect", "Immutable; superseded by new ADs only", "Modular monolith, REST+AMQP, etc"),
    ("Database Decisions",             "d09 §2 'Database stance' (DB-01..DB-11)",
     "DBA Lead", "Immutable; superseded by new DBs only", "Schema-per-context, temporal, ledger audit"),
    ("Type-mapping register (Ingres→SQL)", "d09 §8.2 + per-table sign-offs in Migration.SignOff (target table)",
     "DBA Lead", "Per-table at MZ-1; immutable post sign-off", "12 mapping rules + per-column overrides"),
]

# --------------------------------------------------------------------------
# Decision Records
# --------------------------------------------------------------------------

DECISIONS_HEADERS = ["ID", "Decision", "Source", "Owner"]
DECISIONS = [
    # Wave A — Architecture
    ("AD-01", "Modular monolith for the core switching app, not microservices",                          "d07 §2", "Solution Architect"),
    ("AD-02", "Angular SPA, no SSR",                                                                      "d07 §2", "Solution Architect"),
    ("AD-03", "REST + AMQP integration substrate; gRPC out",                                              "d07 §2", "Solution Architect"),
    ("AD-04", "RabbitMQ for async messaging",                                                              "d07 §2", "Solution Architect"),
    ("AD-05", "7 bounded contexts: Switching Card / Tagging / Authorization / Field / Audit / Reference / Notification", "d07 §2", "Solution Architect"),
    ("AD-06", "Identity split at the OpNET/CorpNET boundary; AD on OpNET, Entra ID on CorpNET",          "d07 §2", "Solution Architect"),
    ("AD-07", "CorpNET reporting reads from DMZ-resident replica, not from OpNET directly",              "d07 §2", "Solution Architect"),
    ("AD-08", "All SCADA/XA21 traffic terminates at the DMZ gateway",                                     "d07 §2", "Solution Architect"),
    ("AD-09", "No event sourcing as primary persistence model",                                           "d07 §2", "Solution Architect"),
    ("AD-10", "EF Core for OLTP, Dapper for hot-path queries",                                            "d07 §2", "Solution Architect"),
    # Wave A — Database
    ("DB-01", "One DB per app, schema per bounded context",                                               "d09 §2", "DBA Lead"),
    ("DB-02", "3NF for transactional, denormalized views in DMZ replica for reporting",                   "d09 §2", "DBA Lead"),
    ("DB-03", "System-versioned temporal tables on every operational entity",                             "d09 §2", "DBA Lead"),
    ("DB-04", "Ledger updatable tables on the Audit schema only",                                          "d09 §2", "DBA Lead"),
    ("DB-05", "bigint identity surrogate keys, not GUIDs",                                                 "d09 §2", "DBA Lead"),
    ("DB-06", "Time-partitioned SwitchingCard, AuditEvent, AuditChain by EventMonth",                     "d09 §2", "DBA Lead"),
    ("DB-07", "Always On AG sync replica in OpNET, async replica in DMZ",                                 "d09 §2", "DBA Lead"),
    ("DB-08", "TDE + TLS 1.3 mandatory; Always Encrypted not used",                                       "d09 §2", "DBA Lead"),
    ("DB-09", "Read replicas read-only via Reporting API only",                                            "d09 §2", "DBA Lead"),
    ("DB-10", "Reference data cached locally; Asset Mgmt is source of truth",                              "d09 §2", "DBA Lead"),
    ("DB-11", "Schema owned by DBAs in DDL scripts under version control; EF migrations applied not authoritative", "d09 §2", "DBA Lead"),
    # Wave A — Network/CIP
    ("NET-01","OpNET = ESP for Medium Impact BCS; OpNET-pulls-only at the EAP",                          "d10 §2-3", "CIP Compliance Lead"),
    ("NET-02","No DMZ-originated connections to OpNET; inbound forbidden at the EAP",                     "d10 §3.2", "CIP Compliance Lead"),
    ("NET-03","No direct OpNET ↔ CorpNET path at any layer",                                              "d10 §2",   "CIP Compliance Lead"),
    ("NET-04","Default Medium Impact BCS rating; CIP-005/007/010/011/013 in scope",                       "d10 §5",   "CIP Compliance Lead"),
    ("NET-05","DMZ gateway is dumb (translation only); no business logic; no state caching",              "d10 §4",   "Integration Lead"),
    ("NET-06","Fail-closed at EAP for OT integrations; fail-open for non-OT",                             "d10 §4.3", "Solution Architect"),
    # Wave D — Resource
    ("RES-01","23-role staffing model; ~564 person-months total across program",                          "d05 §3-4", "Program Director"),
    ("RES-02","70/30 onshore/offshore default; onshore-only for Lead/SA/CIPL/INTL/OSL/BAL",                "d05 §7",   "Program Director"),
    ("RES-03","7 critical key-person flags with named mitigation and triggers",                            "d05 §6",   "Program Director"),
    # Wave D — Estimation
    ("EST-01","Three-point estimation by Epic; Likely is the working number; PERT mean not published",     "d06 §2",   "Program Director"),
    ("EST-02","45 epics across DESIGN/DELIVERY-MVP/DELIVERY-P3/DELIVERY-OPS; ~4,043 likely person-days",   "d06 §5",   "Program Director"),
    # Wave E — Migration
    ("MIG-01","Per-district phased cutover; no big-bang",                                                  "d08 §1",    "DBA Lead"),
    ("MIG-02","Custom .NET migration tooling (not off-the-shelf vendor)",                                  "d08 §4.2",  "DBA Lead"),
    ("MIG-03","Tier 1+2+3 reconciliation per migrated table",                                              "d08 §5",    "DBA Lead"),
    ("MIG-04","48-hour rollback window post-cutover; forward-fix only thereafter",                         "d08 §7",    "Program Director"),
    # Wave E — DevOps
    ("DEV-01","Trunk-based branching; no GitFlow; no long-lived develop/release",                          "d12 §4",    "DevOps Lead"),
    ("DEV-02","Production deploys are change-controlled with CIP-010 baseline diff",                        "d12 §3.3",  "DevOps Lead"),
    ("DEV-03","Vault-rooted secrets per zone; no shared secrets across the EAP",                           "d12 §6",    "DevOps Lead"),
    ("DEV-04","Parallel app pools (Blue/Green) for IIS deploys",                                           "d12 §5.3",  "DevOps Lead"),
    ("DEV-05","Default forward-fix; rollback reserved for data corruption / audit gap / safety / CIP / >50% perf",  "d12 §7.4", "DevOps Lead"),
    # Wave E — Test
    ("TST-01","Storm test as per-sprint deploy gate from sprint 8 onward",                                  "d11 §6.3",  "Test Lead"),
    ("TST-02","Cutover playbook rehearsed twice (MS-11) before any district sees it",                      "d11 §9.6",  "Program Director"),
    ("TST-03","Anonymized prod-shape data in Pre-Prod; never raw prod in lower envs",                       "d11 §4",    "Test Lead"),
    ("TST-04","Operator-walkthrough demo mandatory at every sprint demo + UAT",                             "d11 §5",    "Change Lead"),
]

# --------------------------------------------------------------------------
# Stage Map
# --------------------------------------------------------------------------

STAGE_HEADERS = ["Phase", "Phase name", "Produced in this phase", "Consumed in this phase"]
STAGE_ROWS = [
    ("P0",  "Discovery (complete)",
     "Feature catalog, functional requirements, business rules (inputs to P1)",
     ""),
    ("P1",  "Detailed Design",
     "All Wave A–F deliverables baselined: d07/d09/d10 (architecture); d01/d02 (plan); d03/d04 (backlog); d05/d06 (estimation/resource); d08/d11/d12 (engineering); d13 (catalog)",
     "P0 outputs"),
    ("P2a", "MVP Build",
     "Production code per d04 templates and d03 pipeline; storm test scenarios",
     "d07, d09, d10, d03, d04, d11 (storm test cadence), d12 (CI/CD), d08 (schema baseline)"),
    ("P2b", "MVP UAT & Operator Approval",
     "UAT defect remediation; operator approval evidence",
     "d11 (UAT cycles), d04 bug template, d03 DoR/DoD, d08 reconciliation tooling"),
    ("P3",  "Incremental Build",
     "Production code for distribution/dielectric/steam workflows; monitor apps; integrations; reporting tier; cutover-rehearsal scripts",
     "All Wave A-E artifacts; d11 per-wave UAT discipline"),
    ("P4",  "Full UAT",
     "Live cutover playbook (expanded from d11 §9 outline); DR drill evidence",
     "d11 (full UAT + dry-runs), d12 (env baselines), d08 (reconciliation final dry-run)"),
    ("P5",  "Cutover (district-by-district)",
     "Per-district cutover evidence; final reconciliation; legacy decommission gate",
     "d08 §6-7, d11 §9 cutover playbook, d12 (rollback)"),
    ("P6",  "Hypercare",
     "Defect remediation; KT to ops team; program close evidence",
     "d11 hypercare commitments, d04 bug template"),
    ("AO",  "Always-on (cross-cutting)",
     "Risk register updates, vendor liaison logs, governance cadence, CIP compliance ongoing",
     "d01 risk/assumption/dependency registers"),
]

# --------------------------------------------------------------------------
# Sheet builders
# --------------------------------------------------------------------------

def build_readme(wb: Workbook):
    ws = wb.create_sheet("README")
    set_widths(ws, [26, 110])
    title_cell(ws, 1, 1, "Materials & Templates Catalog — d13", span=2)
    pairs = [
        ("Wave",                  "F — Catalog"),
        ("Source of truth",       "d13-materials-catalog-spec.md"),
        ("Generated by",          "generate_materials_catalog_xlsx.py"),
        ("Indexes",               "Every deliverable, template, checklist, generator, register, and decision across Waves A-E"),
        ("",""),
        ("How to read",           ""),
        ("Program Summary",       "Per-wave totals and headline numbers"),
        ("Documents",             "Every .md and rendered output with paths and purpose"),
        ("Templates",             "The 7 d04 reusable templates with usage notes"),
        ("Checklists",            "Every checklist embedded in the deliverables"),
        ("Workbooks",             "The generated xlsx workbooks"),
        ("Generator Scripts",     "Every Python script with what it produces"),
        ("Reference Registers",   "Pointers to risk, assumption, dependency, role, milestone registers"),
        ("Decision Records",      "Every named decision (AD/DB/NET/RES/EST/MIG/DEV/TST)"),
        ("Stage Map",             "Per-phase view: deliverables produced and consumed"),
        ("",""),
        ("Maintenance rule",      "Regenerate whenever any deliverable is added, removed, or materially changed"),
    ]
    for i, (k, v) in enumerate(pairs, start=3):
        a = ws.cell(row=i, column=1, value=k); a.alignment = Alignment(vertical="top", wrap_text=True)
        b = ws.cell(row=i, column=2, value=v); b.alignment = Alignment(vertical="top", wrap_text=True)
        if k == "How to read":
            a.font = Font(bold=True, size=12, color=HEADER_BG)
        elif k:
            a.font = Font(bold=True)


def build_program_summary(wb: Workbook):
    ws = wb.create_sheet("Program Summary")
    set_widths(ws, [16, 60, 12, 12, 12, 12])
    title_cell(ws, 1, 1, "Program Summary — by Wave", span=6)
    write_headers(ws, ["Wave", "Theme", "Documents", "Templates", "Workbooks", "Generators"], row=3)
    by_wave = {}
    for d in DOCUMENTS:
        wave = d[2]
        by_wave.setdefault(wave, {"docs": 0, "templates": 0})
        if d[3] == "Template":
            by_wave[wave]["templates"] += 1
        else:
            by_wave[wave]["docs"] += 1
    workbooks_per_wave = {"B": 1, "D": 2, "F": 1}
    generators_per_wave = {}
    for g in GENERATORS:
        w = g[1]
        generators_per_wave[w] = generators_per_wave.get(w, 0) + 1
    themes = {
        "A": "Foundations (Architecture, Database, Network/CIP)",
        "B": "Planning Backbone (Master Plan, Timeline)",
        "C": "Backlog Engineering (Pipeline + 7 Templates)",
        "D": "Estimation & Resourcing (Estimates, Resource Plan, Brutal-Honesty Memo)",
        "E": "Engineering & Operations (Migration, DevOps, Test + Cutover Playbook Outline)",
        "F": "Catalog (this workbook)",
    }
    row = 4
    for wave in ["A", "B", "C", "D", "E", "F"]:
        agg = by_wave.get(wave, {"docs": 0, "templates": 0})
        cells = [wave, themes.get(wave, ""),
                 agg["docs"], agg["templates"],
                 workbooks_per_wave.get(wave, 0),
                 generators_per_wave.get(wave, 0)]
        write_row(ws, row, cells)
        ws.cell(row=row, column=1).fill = fill(WAVE_COLORS.get(wave, "FFFFFF"))
        ws.cell(row=row, column=1).font = Font(bold=True)
        ws.row_dimensions[row].height = 24
        row += 1

    # Headline numbers below
    row += 2
    ws.cell(row=row, column=1, value="Headline numbers").font = Font(bold=True, size=13, color=HEADER_BG)
    row += 1
    headlines = [
        ("Total documents (md/docx)",                str(len([d for d in DOCUMENTS if d[3] != "Template"]))),
        ("Total templates",                          str(len(TEMPLATES))),
        ("Total workbooks (xlsx)",                    str(len(WORKBOOKS))),
        ("Total generator scripts",                  str(len(GENERATORS))),
        ("Total checklists indexed",                 str(len(CHECKLISTS))),
        ("Total decisions recorded",                 str(len(DECISIONS))),
        ("Total reference registers",                str(len(REGISTERS))),
        ("Master plan WBS rows (d01)",               "101"),
        ("Estimation epics (d06)",                   "45"),
        ("Likely person-days (d06)",                 "4,043"),
        ("Person-months program-staffed (d05)",      "~564"),
        ("Risks (d01)",                              "12"),
        ("Assumptions (d01)",                        "10"),
        ("External dependencies (d01)",              "8"),
        ("Milestones (d01)",                         "15"),
    ]
    for k, v in headlines:
        a = ws.cell(row=row, column=1, value=k); a.font = Font(bold=True)
        ws.cell(row=row, column=2, value=v)
        row += 1


def build_documents(wb: Workbook):
    ws = wb.create_sheet("Documents")
    write_headers(ws, DOCUMENTS_HEADERS)
    for i, row in enumerate(DOCUMENTS, start=2):
        write_row(ws, i, row, wrap=True)
        wave = row[2]
        ws.cell(row=i, column=3).fill = fill(WAVE_COLORS.get(wave, "FFFFFF"))
        ws.cell(row=i, column=3).font = Font(bold=True)
        ws.row_dimensions[i].height = 38
    set_widths(ws, [11, 38, 6, 12, 22, 38, 38, 38, 60, 30])
    freeze_top(ws, "C2")
    ws.auto_filter.ref = ws.dimensions


def build_templates(wb: Workbook):
    ws = wb.create_sheet("Templates")
    write_headers(ws, TEMPLATES_HEADERS)
    for i, row in enumerate(TEMPLATES, start=2):
        write_row(ws, i, row, wrap=True)
        ws.row_dimensions[i].height = 32
    set_widths(ws, [22, 42, 32, 22, 38])
    freeze_top(ws)


def build_checklists(wb: Workbook):
    ws = wb.create_sheet("Checklists")
    write_headers(ws, CHECKLISTS_HEADERS)
    for i, row in enumerate(CHECKLISTS, start=2):
        write_row(ws, i, row, wrap=True)
        # Color by type
        type_colors = {"Backlog": "DDEBF7", "Compliance": "FCE4D6", "Quality": "FFF2CC",
                       "Migration": "E4DFEC", "Cutover": "FFC7CE", "DevOps": "E2EFDA", "Test": "F8CBAD"}
        ws.cell(row=i, column=5).fill = fill(type_colors.get(row[4], "FFFFFF"))
        ws.row_dimensions[i].height = 24
    set_widths(ws, [38, 14, 38, 32, 14])
    freeze_top(ws)


def build_workbooks(wb: Workbook):
    ws = wb.create_sheet("Workbooks")
    write_headers(ws, WORKBOOKS_HEADERS)
    for i, row in enumerate(WORKBOOKS, start=2):
        write_row(ws, i, row, wrap=True)
        ws.row_dimensions[i].height = 36
    set_widths(ws, [24, 38, 38, 42, 12, 60])
    freeze_top(ws)


def build_generators(wb: Workbook):
    ws = wb.create_sheet("Generator Scripts")
    write_headers(ws, GENERATORS_HEADERS)
    for i, row in enumerate(GENERATORS, start=2):
        write_row(ws, i, row, wrap=True)
        wave = row[1]
        ws.cell(row=i, column=2).fill = fill(WAVE_COLORS.get(wave, "FFFFFF"))
        ws.row_dimensions[i].height = 28
    set_widths(ws, [42, 8, 60, 30, 42])
    freeze_top(ws)


def build_registers(wb: Workbook):
    ws = wb.create_sheet("Reference Registers")
    write_headers(ws, REGISTERS_HEADERS)
    for i, row in enumerate(REGISTERS, start=2):
        write_row(ws, i, row, wrap=True)
        ws.row_dimensions[i].height = 36
    set_widths(ws, [28, 60, 22, 32, 38])
    freeze_top(ws)


def build_decisions(wb: Workbook):
    ws = wb.create_sheet("Decision Records")
    write_headers(ws, DECISIONS_HEADERS)
    prefix_colors = {
        "AD":  "DDEBF7",
        "DB":  "DDEBF7",
        "NET": "DDEBF7",
        "RES": "FCE4D6",
        "EST": "FCE4D6",
        "MIG": "F8CBAD",
        "DEV": "F8CBAD",
        "TST": "F8CBAD",
    }
    for i, row in enumerate(DECISIONS, start=2):
        write_row(ws, i, row, wrap=True)
        prefix = row[0].split("-")[0]
        ws.cell(row=i, column=1).fill = fill(prefix_colors.get(prefix, "FFFFFF"))
        ws.cell(row=i, column=1).font = Font(bold=True)
        ws.row_dimensions[i].height = 26
    set_widths(ws, [10, 80, 14, 24])
    freeze_top(ws)
    ws.auto_filter.ref = ws.dimensions


def build_stage_map(wb: Workbook):
    ws = wb.create_sheet("Stage Map")
    write_headers(ws, STAGE_HEADERS)
    for i, row in enumerate(STAGE_ROWS, start=2):
        write_row(ws, i, row, wrap=True)
        phase = row[0]
        ws.cell(row=i, column=1).fill = fill(PHASE_COLORS.get(phase, "FFFFFF"))
        ws.cell(row=i, column=1).font = Font(bold=True)
        ws.row_dimensions[i].height = 70
    set_widths(ws, [8, 32, 70, 40])
    freeze_top(ws)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default=str(HERE / "build" / "13-materials-catalog.xlsx"),
    )
    args = parser.parse_args()

    wb = Workbook()
    wb.remove(wb.active)

    build_readme(wb)
    build_program_summary(wb)
    build_documents(wb)
    build_templates(wb)
    build_checklists(wb)
    build_workbooks(wb)
    build_generators(wb)
    build_registers(wb)
    build_decisions(wb)
    build_stage_map(wb)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"Wrote {out} ({out.stat().st_size:,} bytes; {len(wb.sheetnames)} sheets)")


if __name__ == "__main__":
    main()
