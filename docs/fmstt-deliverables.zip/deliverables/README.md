# Deliverables — FMS Switching Order Modernization

Phase 1 baseline. Complete planning + execution package for the modernization program scoped in [enhanced_prompt.md](../enhanced_prompt.md).

---

## Start here

- **[wave-f/build/13-materials-catalog.xlsx](wave-f/build/13-materials-catalog.xlsx)** — index of every deliverable, template, checklist, generator, register, and decision. **Open this first.**
- **[wave-b/d02-timeline-narrative.md](wave-b/d02-timeline-narrative.md)** — sponsor-facing brutal-honesty narrative.
- **[wave-d/d05-brutal-honesty-memo.md](wave-d/d05-brutal-honesty-memo.md)** — top-5 places estimates are most likely wrong, with named triggers.

---

## Wave structure

| Wave | Theme | Path |
|---|---|---|
| **A** | Foundations (Architecture / Database / Network-CIP) | [wave-a/](wave-a/) |
| **B** | Planning Backbone (Master Plan + Timeline Narrative) | [wave-b/](wave-b/) |
| **C** | Backlog Engineering (Pipeline Guide + 7 Templates) | [wave-c/](wave-c/) |
| **D** | Estimation & Resourcing (Estimates / Resource Plan / Brutal-Honesty Memo) | [wave-d/](wave-d/) |
| **E** | Engineering & Operations (Migration / DevOps / Test + Cutover) | [wave-e/](wave-e/) |
| **F** | Catalog (Materials & Templates Index) | [wave-f/](wave-f/) |

---

## Per-role quick start

Read these first based on what you own:

| Role | Read first | Then |
|---|---|---|
| **Sponsor** | [d02 timeline narrative](wave-b/d02-timeline-narrative.md) §5 + [d05 memo](wave-d/d05-brutal-honesty-memo.md) §3, §6 | The d13 catalog Documents sheet |
| **Program Director / Scrum Master** | [d01 master plan workbook](wave-b/build/01-master-plan.xlsx) WBS + Risks + Dependencies | [d05 memo](wave-d/d05-brutal-honesty-memo.md) §5 (re-baseline triggers) |
| **Solution Architect** | [d07 architecture](wave-a/d07-architecture-outline.md) + [d09 database](wave-a/d09-database-design-principles.md) + [d10 network/CIP](wave-a/d10-network-boundary-design.md) | d13 Decision Records sheet (45 named decisions) |
| **CIP Compliance Lead / CIP Senior Manager** | [d10 §5 CIP control mapping](wave-a/d10-network-boundary-design.md) + [d11 §7 CIP testing](wave-e/d11-test-strategy.md) | A-007 (impact rating) — get a written ruling first |
| **DBA Lead** | [d09 database](wave-a/d09-database-design-principles.md) + [d08 migration](wave-e/d08-data-migration-strategy.md) | d09 §8 type-mapping; confirm Ingres CDC support in week 1 |
| **Integration Lead** | [d07 §4 cross-zone patterns](wave-a/d07-architecture-outline.md) + [d10 §3 protocol allowlist](wave-a/d10-network-boundary-design.md) | DEP-01 — start XA21 SOAP trace recording immediately |
| **DevOps Lead** | [d12 DevOps blueprint](wave-e/d12-devops-blueprint.md) | DEP-02/03/04 — internal CA / PAM / SIEM readiness path |
| **Test Lead** | [d11 test strategy + cutover playbook outline](wave-e/d11-test-strategy.md) | d11 §6 storm-test cadence; build harness during P1 |
| **BA Lead** | [d03 backlog pipeline guide](wave-c/d03-backlog-pipeline-guide.md) + the 7 [d04 templates](wave-c/d04-templates/) | P1.15 — start the OpenRoad 4GL hidden-rules walk-through |
| **Change Lead** | [d03 §6.2, §10](wave-c/d03-backlog-pipeline-guide.md) + [d11 §5](wave-e/d11-test-strategy.md) | DEP-07 — get shift-coverage backfill funded in writing |
| **Operator SME Lead** | [d02 timeline narrative](wave-b/d02-timeline-narrative.md) §3.4 + §4.1 | P1.07 operator UX co-design schedule |

---

## Numbers

- **45 epics** with three-point estimates → ~**4,043 likely person-days**
- **101 WBS rows** across 9 phases (P0 → P6 + AO)
- **23 roles** × 7-phase ramp → **~564 program-staffed person-months**
- **15 milestones** anchored at `T0 = 2026-05-01`
- **12 risks**, **10 assumptions**, **8 external dependencies** in the registers
- **45 named decisions** (architecture / database / network / resource / estimation / migration / devops / test)
- **24–30 month** ratified envelope; central bet for program close: **2029-02-15** (post-Hypercare)

---

## What this package gives the delivery team

Concrete day-one starting points by phase:

- **Day 1 of P1 (Detailed Design):** Wave A foundations ratify-or-amend session; CIP impact rating ruling kicked off (A-007); operator SME backfill commitment chased (DEP-07); BA Lead starts the OpenRoad 4GL hidden-rules walk-through (P1.15).
- **Day 1 of P2a (MVP Build):** d04 templates wired into the backlog tool; CI pipeline from [d12](wave-e/d12-devops-blueprint.md) §3 stood up; storm-test harness from [d11](wave-e/d11-test-strategy.md) §6 starts construction; Wave A architecture decisions are the contract.
- **Before MS-06 (storm test pass):** the storm-test pass criteria in [d11](wave-e/d11-test-strategy.md) §6.4 are the gate — non-negotiable.
- **Before MS-07 (NERC CIP rehearsal):** auditor-style walkthrough of [d10](wave-a/d10-network-boundary-design.md) §5 control mapping; per-PR CIP-impact discipline ([d03](wave-c/d03-backlog-pipeline-guide.md) §8.2) must be in habit, not just policy.
- **Before MS-08 (MVP Operator Approval — CRITICAL):** operator SMEs have run cycles 1–3 ([d11](wave-e/d11-test-strategy.md) §5.2); parity claims per story ([d04 user-story template](wave-c/d04-templates/user-story-template.md)) reviewed and signed by named SMEs.
- **Before MS-11 (cutover dry-run #2):** live cutover playbook expanded from the [d11 §9 outline](wave-e/d11-test-strategy.md#9-cutover-playbook-outline); both dry-runs done with operators in the loop.
- **MS-12 onward (per-district cutover):** [d11 §9](wave-e/d11-test-strategy.md#9-cutover-playbook-outline) GO/NO-GO checklist; [d08 §7.2](wave-e/d08-data-migration-strategy.md#72-rollback-decision-tree) rollback decision tree.
- **For the auditor / CIP Senior Manager at any time:** [build/13-materials-catalog.xlsx](wave-f/build/13-materials-catalog.xlsx) — Decision Records sheet + Reference Registers sheet are the evidence walk.

---

## Open decisions across waves (TBD before relevant phase)

These are flagged in each deliverable's "Open questions" section. Consolidated for triage:

| ID | Decision | Owner | Required by |
|---|---|---|---|
| A-007 | NERC CIP impact rating (Medium / Low / High) | CIP Senior Manager | First 30 days of P1 |
| A-009 | Existing utility infra confirmed available: WAF, internal CA, PAM, SIEM | DevOps Lead | P1 week 4 |
| DEP-01 | XA21 SOAP trace export from vendor | Integration Lead | P1 week 8 |
| DEP-07 | Shift-coverage backfill funded for operator SMEs | Sponsor + operator org | Before sprint 1 of P2a |
| Q-d07-1 | Reverse proxy / WAF vendor | DevOps Lead | Before Wave D estimation finalized |
| Q-d09-1 | Default DB collation (`Latin1_General_100_CI_AS_SC`) | DBA Lead + Data Owner | Before P2a sprint 0 |
| Q-d09-5 | Data classification register for column-level encryption | CIP Senior Manager | Before MS-07 |
| Q-d12-1 | CI server (Azure DevOps Server vs GitHub Enterprise) | DevOps Lead | P1 week 6 |
| Q-d08-1 | Ingres CDC support (native vs periodic delta) | DBA Lead | P1 week 1 |
| Q-d11-1 | E2E automation tool (Playwright default) | Test Lead | P1 week 4 |
| Q-d11-5 | Pen-test vendor procurement | Security Engineer + procurement | Before MS-10 |

---

## What this package deliberately does NOT include

- **No vision / executive sales deck.** Sponsor briefing uses [d02](wave-b/d02-timeline-narrative.md) §5 plus the d01 workbook directly.
- **No standalone risk-register file.** Risks are a column in the d01 master plan; mirroring elsewhere creates duplicate sources of truth.
- **No standalone RACI document.** RACI is a sheet in d01.
- **No "vision-of-the-future" UX wireframes.** Operator UX is co-designed in P1.07 with the actual SMEs, not pre-baked here.
- **No specific tool selections** for ADO/Jira/Confluence/Vault vendor — these are Wave E "open questions" awaiting infra confirmation.
- **No production-shape budget numbers.** The cost sketch in [d05](wave-d/build/05-resource-plan.xlsx) uses placeholder rates; program finance replaces them.
- **No detailed cutover playbook.** [d11 §9](wave-e/d11-test-strategy.md#9-cutover-playbook-outline) is an outline; the live playbook is built and rehearsed during P4 dry-runs (MS-11), per program design.
- **No ADR repo separate from d13.** Decisions live in the d13 Decision Records sheet plus the source documents that introduced them.
- **No "NERC CIP work breakdown" as a standalone artifact.** CIP is woven through every story's DoR/DoD ([d03](wave-c/d03-backlog-pipeline-guide.md) §8.2) and verified per-deliverable, not crammed in pre-MS-07.

---

## What this package does NOT yet contain (TBD as P1 progresses)

- **Final XA21 protocol contract** — depends on DEP-01 SOAP trace recording
- **Live cutover playbook (per district)** — built during P4 dry-runs (MS-11)
- **Per-table type-mapping decisions** — per-table sign-offs accumulate during MZ-1
- **Concrete sprint cadence and team-name assignments** — set when the team is staffed
- **Vendor risk assessments** (CIP-013 R1) — done as each new dependency is introduced
- **Penetration test report** — annual + pre-cutover (Wave E §7.6)
- **DR drill evidence** (CIP-009 R3) — quarterly + pre-cutover

---

## How to regenerate binaries

Each wave has a `requirements.txt` and one or more `generate_*.py` scripts. From any wave directory:

```bash
pip install -r requirements.txt
python generate_<thing>.py
```

Outputs go to `<wave>/build/`.

### Source-of-truth principle

- **Markdown sources at the wave root are canonical.** They are version-controlled, diff-able, and the only thing reviewers should edit.
- **Binaries in `build/` are regenerated.** Hand-editing the `.xlsx` or `.docx` works once and is silently overwritten on the next regeneration. **Don't.**
- **Workbook data structures live in the Python scripts.** Edit the Python data lists and regenerate; the xlsx is a render of that data.
- **The d13 catalog is regenerated whenever any deliverable is added, removed, or materially changed.** This is its only freshness guarantee.

---

## Shared infrastructure

- **[_md2docx.py](_md2docx.py)** — markdown→docx renderer (used by Wave-C onward).
- **[_xlsx_helpers.py](_xlsx_helpers.py)** — openpyxl rendering helpers (used by Wave-D onward).

Wave-B's generators keep self-contained copies of their renderers (so that delivered artifact stays self-contained); Wave-C and later import from these shared modules.

---

## Recommended handoff prompt for the delivery team

When a delivery team picks this package up, ask them to start with this exact prompt before sprint 1:

> Open [deliverables/wave-f/build/13-materials-catalog.xlsx](wave-f/build/13-materials-catalog.xlsx). Read the **Decision Records** sheet end-to-end (45 named decisions). Then open [deliverables/wave-d/d05-brutal-honesty-memo.md](wave-d/d05-brutal-honesty-memo.md) §3 (top-5 places estimates are most likely wrong). For every decision and every named risk, the team confirms or pushes back **in writing** before P1 sprint 1 starts. Disagreement is fine; silent acceptance is not.

The point of the prompt is not to ratify everything — it is to ensure no decision passes silently into execution. A program where the delivery team has not actively engaged with the foundation is a program that will surface foundation disagreements during P2a and lose 4–8 weeks to re-litigation.
