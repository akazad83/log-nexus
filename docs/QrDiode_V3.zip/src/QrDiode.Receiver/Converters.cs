using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace QrDiode.Receiver;

/// <summary>
/// Turns the payload catalogue's colour strings into brushes. The catalogue lives in Core so both
/// apps show the same tile for the same event type; Core cannot hand out WPF brushes itself.
/// </summary>
public sealed class HexBrushConverter : IValueConverter
{
    private static readonly Dictionary<string, SolidColorBrush> Cache = [];

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not string hex || hex.Length == 0) return Brushes.Transparent;
        lock (Cache)
        {
            if (Cache.TryGetValue(hex, out var cached)) return cached;
            var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)!);
            brush.Freeze();
            Cache[hex] = brush;
            return brush;
        }
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
