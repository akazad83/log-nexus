using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using QrDiode.Core.Presentation;
using QrDiode.Receiver.Inbox;
using QrDiode.Receiver.Storage;
using QrDiode.Ui;

namespace QrDiode.Receiver;

/// <summary>
/// The Archive tab: the receiver's memory of everything it has judged, backed by the payload store
/// on disk and the journal's index. The live tab answers "is the beam working"; this one answers
/// "what came through, was it real, and is it still intact" — long after the camera was switched
/// off, with no back-channel to ask the sender anything.
/// </summary>
public partial class MainWindow
{
    /// <summary>Read cap for the archive viewer. An operator asked for this file, so it is generous.</summary>
    private const int ArchiveViewBytes = 1024 * 1024;

    private readonly ObservableCollection<ArchiveRecord> _archive = [];
    private ArchiveRecord? _archiveSelected;
    private byte[]? _archiveBytes;
    private PayloadText _archiveText = PayloadText.Empty;

    private void InitArchive()
    {
        ArchiveList.ItemsSource = _archive;
        ShowStorageSettings();
        LoadArchive();
    }

    // ═══════════════════ where the bytes live ═══════════════════

    private void ShowStorageSettings()
    {
        StorageRootBox.Text = _store.Root;
        DateFoldersCheck.IsChecked = _store.OrganizeByDate;
        SidecarCheck.IsChecked = _store.WriteSidecar;

        string layout = _store.OrganizeByDate ? @"\yyyy-MM-dd\<session>_<name>" : @"\<session>_<name>";
        StorageNoteText.Text = "writes land at …" + layout +
                               (_store.WriteSidecar ? "  +  .meta.json" : "");
    }

    private void ChangeStorage_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog
        {
            Title = "Choose where received payloads are stored",
            InitialDirectory = Directory.Exists(_store.Root) ? _store.Root : "",
        };
        if (dialog.ShowDialog() != true) return;

        string previous = _store.Root;
        _settings.StorageRoot = dialog.FolderName;
        _store.Apply(_settings);

        try
        {
            _store.EnsureReady();
        }
        catch (Exception ex)
        {
            // A store that cannot be written to is worse than the old one: roll straight back.
            _settings.StorageRoot = previous;
            _store.Apply(_settings);
            ShowStorageSettings();
            ShowError($"“{dialog.FolderName}” is not writable ({ex.Message}) — the store is still {previous}.");
            return;
        }

        PersistStorageSettings("storage.root_changed", previous);
        HideError();
    }

    private void StorageOption_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        _settings.OrganizeByDate = DateFoldersCheck.IsChecked == true;
        _settings.WriteSidecar = SidecarCheck.IsChecked == true;
        _store.Apply(_settings);
        PersistStorageSettings("storage.layout_changed", null);
    }

    private void PersistStorageSettings(string auditEvent, string? previousRoot)
    {
        try
        {
            _settings.Save();
        }
        catch (Exception ex)
        {
            ShowError($"Could not save the storage settings: {ex.Message}");
        }

        var fields = new Dictionary<string, string>
        {
            ["root"] = _store.Root,
            ["organizeByDate"] = _store.OrganizeByDate.ToString(),
            ["sidecars"] = _store.WriteSidecar.ToString(),
        };
        if (previousRoot is not null) fields["previousRoot"] = previousRoot;
        _audit.Append(auditEvent, fields);

        ShowStorageSettings();
    }

    private void OpenStorage_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Directory.CreateDirectory(_store.Root);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{_store.Root}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ShowError($"Could not open the store: {ex.Message}");
        }
    }

    // ═══════════════════ index + query ═══════════════════

    /// <summary>Every judged arrival is written to the index — stored, duplicate, rejected alike.</summary>
    private void IndexArrival(InboxEntry entry)
    {
        try
        {
            _journal.IndexArrival(new ArchiveRecord
            {
                Id = 0,
                ReceivedUtc = entry.ArrivedAt.ToUniversalTime(),
                Outcome = entry.Outcome,
                Filename = entry.Name,
                Size = entry.Size,
                ContentType = entry.ContentType,
                SessionId = entry.SessionId,
                SenderKeyId = entry.SenderKeyId,
                Counter = entry.Counter,
                Sha256 = entry.PlaintextSha256 ?? "",
                Receipt = entry.Receipt,
                StoredPath = entry.StoredPath,
                Reason = entry.Reason,
                Seconds = entry.Seconds,
                Snippet = entry.Snippet,
            });
        }
        catch (Exception ex)
        {
            // The payload is already on disk and in the audit log; an index write that fails must
            // not take a good transfer down with it.
            ShowError($"Payload stored, but the archive index rejected the row: {ex.Message}");
        }
    }

    private void ReloadArchive_Click(object sender, RoutedEventArgs e) => LoadArchive();

    /// <summary>Serves both the search box's TextChanged and the filter trays' Checked.</summary>
    private void ArchiveFilter_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) LoadArchive();
    }

    private void Tab_Changed(object sender, SelectionChangedEventArgs e)
    {
        // Only react to the tab strip itself; the lists inside the tabs bubble their own events.
        if (!_ready || !ReferenceEquals(e.OriginalSource, MainTabs)) return;
        if (MainTabs.SelectedIndex == 1) LoadArchive();
    }

    private ArchiveQuery CurrentQuery() => new(
        Search: ArchiveSearchBox.Text.Trim(),
        Outcome:
            ArchiveOk.IsChecked == true ? InboxOutcome.Verified :
            ArchiveDup.IsChecked == true ? InboxOutcome.Duplicate :
            ArchiveBad.IsChecked == true ? InboxOutcome.Rejected : null,
        SinceUtc:
            RangeToday.IsChecked == true ? DateTime.Now.Date.ToUniversalTime() :
            Range7.IsChecked == true ? DateTime.UtcNow.AddDays(-7) :
            Range30.IsChecked == true ? DateTime.UtcNow.AddDays(-30) : null);

    private void LoadArchive()
    {
        var query = CurrentQuery();
        long selectedId = _archiveSelected?.Id ?? 0;

        try
        {
            _archive.Clear();
            foreach (var record in _journal.QueryArchive(query)) _archive.Add(record);

            var totals = _journal.QueryTotals(query);
            ArchiveCountText.Text = $"{_archive.Count:N0} shown · {totals.Arrivals:N0} in range";
            ArchiveOkText.Text = $"✔ {totals.Verified:N0}";
            ArchiveDupText.Text = $"◎ {totals.Duplicates:N0}";
            ArchiveBadText.Text = $"✖ {totals.Rejected:N0}";
            ArchiveBytesText.Text = FormatBytes(totals.StoredBytes) + " stored";

            var tallies = _journal.QueryTypeTallies(query);
            TallyList.ItemsSource = tallies;
            TallyEmptyText.Visibility = tallies.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }
        catch (Exception ex)
        {
            ShowError($"Could not read the archive index: {ex.Message}");
            return;
        }

        ArchiveEmpty.Visibility = _archive.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        if (_archive.Count == 0) ExplainEmptyArchive();

        // Keep the operator's place across a reload rather than snapping back to the newest row.
        var keep = _archive.FirstOrDefault(r => r.Id == selectedId);
        if (keep is not null) ArchiveList.SelectedItem = keep;
        else RenderArchiveDetail(null);
    }

    /// <summary>
    /// An empty list next to a full folder is the one confusing case: payloads received before the
    /// index existed are on disk but not in it. Say so rather than implying nothing ever arrived.
    /// </summary>
    private void ExplainEmptyArchive()
    {
        int onDisk = 0;
        try
        {
            if (Directory.Exists(_store.Root))
            {
                onDisk = Directory.EnumerateFiles(_store.Root, "*", SearchOption.AllDirectories)
                    .Where(f => !f.EndsWith(PayloadStore.SidecarSuffix, StringComparison.OrdinalIgnoreCase))
                    .Take(200).Count();
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }

        bool filtered = ArchiveSearchBox.Text.Trim().Length > 0
                        || ArchiveAll.IsChecked != true
                        || RangeAll.IsChecked != true;

        ArchiveEmptyText.Text = filtered
            ? "No arrival matches this filter. Widen the range or clear the search."
            : onDisk > 0
                ? $"The store holds {onDisk}{(onDisk == 200 ? "+" : "")} file(s), but none of them are in the index — " +
                  "they were received before the archive existed. Everything received from now on is indexed here."
                : "Every arrival the receiver judges is indexed here — stored, duplicate or rejected — " +
                  "and stays after the app closes.";
    }

    private static string FormatBytes(long bytes) => bytes switch
    {
        < 1024 => $"{bytes:N0} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        < 1024 * 1024 * 1024 => $"{bytes / (1024.0 * 1024):0.#} MB",
        _ => $"{bytes / (1024.0 * 1024 * 1024):0.##} GB",
    };

    // ═══════════════════ selected record ═══════════════════

    private void Archive_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) RenderArchiveDetail(ArchiveList.SelectedItem as ArchiveRecord);
    }

    private void ArchiveViewMode_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) RenderArchivePayload();
    }

    private void RenderArchiveDetail(ArchiveRecord? record)
    {
        _archiveSelected = record;
        _archiveBytes = null;
        _archiveText = PayloadText.Empty;

        if (record is null)
        {
            SetPill(ArchiveOutcomePill, ArchiveOutcomeDetailText, "nothing selected", "PillIdle");
            ArchiveNameText.Text = "";
            ArchiveMetaText.Text = "Select an archived arrival to inspect it.";
            ArchiveCopyButton.IsEnabled = false;
            ArchiveExportButton.IsEnabled = false;
            ArchiveFolderButton.IsEnabled = false;
            VerifyFileButton.IsEnabled = false;
            SetIntegrity(IntegrityState.Unchecked, "integrity not checked");
            ArchiveViewer.Document = PayloadView.Message("Select an archived arrival to read its payload.");
            ArchiveNoteText.Text = "";
            return;
        }

        SetPill(ArchiveOutcomePill, ArchiveOutcomeDetailText, record.OutcomeLabel, record.Outcome switch
        {
            InboxOutcome.Verified => "PillOk",
            InboxOutcome.Duplicate => "PillWarn",
            _ => "PillBad",
        });
        ArchiveNameText.Text = $"{record.Filename} · {record.SizeLabel}";

        bool onDisk = record.HasFile;
        ArchiveCopyButton.IsEnabled = onDisk;
        ArchiveExportButton.IsEnabled = onDisk;
        ArchiveFolderButton.IsEnabled = onDisk;
        VerifyFileButton.IsEnabled = onDisk && record.Sha256.Length == 64;

        ArchiveMetaText.Text = string.Join('\n',
        [
            $"{record.DateLabel} {record.TimeLabel} · {record.MetaLine}",
            $"receipt {record.ReceiptGrouped} · sha256 {(record.Sha256.Length == 64 ? record.Sha256 : "—")}",
            record.StoredPath is { Length: > 0 } path
                ? (onDisk ? "stored  " + path : "indexed here, but the file is gone:  " + path)
                : record.Reason ?? "nothing was written",
        ]);

        SetIntegrity(onDisk ? record.Integrity : IntegrityState.Missing,
            onDisk ? record.IntegrityLabel : "— file is not on disk");
        RenderArchivePayload();
    }

    private void RenderArchivePayload()
    {
        var record = _archiveSelected;
        if (record is null) return;

        _archiveBytes ??= ReadStored(record);
        if (_archiveBytes is null)
        {
            ArchiveViewer.Document = PayloadView.Message(record.Outcome == InboxOutcome.Verified
                ? "The index has this payload, but the file is no longer in the store."
                : "Nothing was written for this arrival — the chain failed before any plaintext existed.");
            ArchiveNoteText.Text = "";
            _archiveText = PayloadText.Empty;
            return;
        }

        _archiveText =
            ArchiveViewHex.IsChecked == true ? PayloadFormatter.Hex(_archiveBytes) :
            ArchiveViewRaw.IsChecked == true ? PayloadFormatter.Raw(record.ContentType, _archiveBytes) :
            PayloadFormatter.Formatted(record.ContentType, _archiveBytes);

        ArchiveViewer.Document = PayloadView.Build(_archiveText);
        ArchiveNoteText.Text = record.Size > _archiveBytes.Length
            ? $"showing the first {_archiveBytes.Length / 1024} KB of {record.SizeLabel}"
            : $"read from {Path.GetFileName(record.StoredPath)}";
    }

    private byte[]? ReadStored(ArchiveRecord record)
    {
        if (record.StoredPath is not { Length: > 0 } path || !File.Exists(path)) return null;
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            int length = (int)Math.Min(stream.Length, ArchiveViewBytes);
            var buffer = new byte[length];
            stream.ReadExactly(buffer);
            return buffer;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    // ═══════════════════ actions ═══════════════════

    private void ArchiveCopy_Click(object sender, RoutedEventArgs e)
    {
        if (_archiveText.Text.Length == 0) return;
        try { Clipboard.SetText(_archiveText.Text); } catch (Exception) { /* clipboard busy */ }
    }

    private void ArchiveFolder_Click(object sender, RoutedEventArgs e)
    {
        if (_archiveSelected?.StoredPath is not { } path || !File.Exists(path)) return;
        try
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ShowError($"Could not open the store: {ex.Message}");
        }
    }

    /// <summary>Copies the payload out of the store. The store's own copy is never moved or altered.</summary>
    private void ArchiveExport_Click(object sender, RoutedEventArgs e)
    {
        if (_archiveSelected is not { StoredPath: { } source } record || !File.Exists(source)) return;

        var dialog = new SaveFileDialog
        {
            Title = "Export a copy of this payload",
            FileName = record.Filename,
            Filter = "Payload|*.*",
        };
        if (dialog.ShowDialog() != true) return;

        try
        {
            File.Copy(source, dialog.FileName, overwrite: true);
            _audit.Append("archive.exported", new Dictionary<string, string>
            {
                ["session"] = record.SessionId,
                ["from"] = source,
                ["to"] = dialog.FileName,
            });
            HideError();
        }
        catch (Exception ex)
        {
            ShowError($"Export failed: {ex.Message}");
        }
    }

    /// <summary>
    /// Re-hashes the stored file and compares it with the SHA-256 the sender signed. This is the
    /// only verification still available on this side of the diode after the fact — and it catches
    /// exactly the thing an archive is for: bytes changing while nobody was watching.
    /// </summary>
    private async void VerifyFile_Click(object sender, RoutedEventArgs e)
    {
        if (_archiveSelected is not { StoredPath: { } path } record) return;

        record.Integrity = IntegrityState.Checking;
        SetIntegrity(IntegrityState.Checking, record.IntegrityLabel);
        VerifyFileButton.IsEnabled = false;

        try
        {
            string actual = await Task.Run(() =>
            {
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                return Convert.ToHexString(SHA256.HashData(stream));
            });

            bool match = string.Equals(actual, record.Sha256, StringComparison.OrdinalIgnoreCase);
            record.Integrity = match ? IntegrityState.Intact : IntegrityState.Altered;
            record.IntegrityNote = actual;

            _audit.Append("archive.verified", new Dictionary<string, string>
            {
                ["session"] = record.SessionId,
                ["file"] = path,
                ["expected"] = record.Sha256,
                ["actual"] = actual,
                ["result"] = match ? "intact" : "altered",
            });

            SetIntegrity(record.Integrity, match
                ? record.IntegrityLabel
                : $"{record.IntegrityLabel} — on disk: {actual[..16]}…");
        }
        catch (Exception ex)
        {
            record.Integrity = File.Exists(path) ? IntegrityState.Unchecked : IntegrityState.Missing;
            SetIntegrity(record.Integrity, $"could not hash the file: {ex.Message}");
        }
        finally
        {
            VerifyFileButton.IsEnabled = record.HasFile && record.Sha256.Length == 64;
        }
    }

    private void SetIntegrity(IntegrityState state, string label) =>
        SetPill(IntegrityPill, IntegrityText, label, state switch
        {
            IntegrityState.Intact => "PillOk",
            IntegrityState.Altered => "PillBad",
            IntegrityState.Missing => "PillWarn",
            _ => "PillIdle",
        });
}
