using System.Buffers.Binary;
using System.IO;
using System.Windows.Media.Imaging;
using FlashCap;
using ZXingCpp;

namespace QrDiode.Receiver.Capture;

/// <summary>
/// Camera → luminance → ZXingCpp QR decode pipeline.
///
/// FlashCap transcodes YUV camera output to a DIB (BMP), but hands compressed formats through
/// untouched — and on most integrated webcams the fastest mode is MJPEG, so the raw frame is a
/// JPEG. Both are converted here to a reusable top-down luminance plane for the native decoder.
/// Frames arriving while a decode is in flight are dropped — the sender carousel makes drops free.
/// </summary>
public sealed class QrDecodePipeline : IAsyncDisposable
{
    private readonly ReaderOptions _readerOptions = new()
    {
        Formats = BarcodeFormat.QRCode,
        TryHarder = false,
        TryRotate = false,
        TryInvert = false,
        MaxNumberOfSymbols = 2,
    };

    private readonly Action<byte[]> _onQrPayload;
    private readonly Action<LumFrame>? _onPreview;
    private CaptureDevice? _device;
    private byte[] _lumBuffer = Array.Empty<byte>();
    private int _decodeBusy;

    public long FramesSeen;
    public long FramesDecoded;
    public long QrHits;
    /// <summary>Frames whose format we could not turn into luminance at all. Never silent.</summary>
    public long FramesUnreadable;

    public readonly record struct LumFrame(byte[] Pixels, int Width, int Height);

    public QrDecodePipeline(Action<byte[]> onQrPayload, Action<LumFrame>? onPreview = null)
    {
        _onQrPayload = onQrPayload;
        _onPreview = onPreview;
    }

    public static IReadOnlyList<(CaptureDeviceDescriptor Descriptor, VideoCharacteristics Characteristics)> EnumerateCameras()
    {
        var result = new List<(CaptureDeviceDescriptor, VideoCharacteristics)>();
        foreach (var descriptor in new CaptureDevices().EnumerateDescriptors())
        {
            var best = descriptor.Characteristics
                .Where(c => c.PixelFormat != PixelFormats.Unknown)
                .OrderByDescending(c => c.FramesPerSecond.Numerator / Math.Max(1.0, c.FramesPerSecond.Denominator))
                .ThenByDescending(c => Math.Min(c.Width * c.Height, 1280 * 720)) // prefer ≤720p at max fps
                .ThenBy(c => c.Width * c.Height)
                // All else equal, take an uncompressed mode: no JPEG decode per frame and no
                // compression artifacts on the module edges the decoder has to threshold.
                .ThenBy(c => c.PixelFormat is PixelFormats.JPEG or PixelFormats.PNG ? 1 : 0)
                .FirstOrDefault();
            if (best is not null)
                result.Add((descriptor, best));
        }
        return result;
    }

    public async Task StartAsync(CaptureDeviceDescriptor descriptor, VideoCharacteristics characteristics)
    {
        _device = await descriptor.OpenAsync(characteristics, OnPixelBuffer);
        await _device.StartAsync();
    }

    private void OnPixelBuffer(PixelBufferScope scope)
    {
        Interlocked.Increment(ref FramesSeen);

        // Drop the frame if a decode is already running.
        if (Interlocked.CompareExchange(ref _decodeBusy, 1, 0) != 0)
            return;

        try
        {
            var image = scope.Buffer.ReferImage();
            if (!TryToLuminance(image, out int width, out int height))
            {
                Interlocked.Increment(ref FramesUnreadable);
                return;
            }

            Interlocked.Increment(ref FramesDecoded);

            var view = new ImageView(_lumBuffer, width, height, ImageFormat.Lum);
            var barcodes = BarcodeReader.Read(view, _readerOptions);
            foreach (var barcode in barcodes)
            {
                byte[] payload = barcode.Bytes;
                if (payload.Length > 0)
                {
                    Interlocked.Increment(ref QrHits);
                    _onQrPayload(payload);
                }
            }

            if (_onPreview is not null)
            {
                // Hand the UI a copy so the reusable buffer can be overwritten immediately.
                var copy = new byte[width * height];
                Array.Copy(_lumBuffer, copy, copy.Length);
                _onPreview(new LumFrame(copy, width, height));
            }
        }
        finally
        {
            Volatile.Write(ref _decodeBusy, 0);
        }
    }

    /// <summary>
    /// Converts one camera frame into a top-down luminance plane in the reusable buffer,
    /// dispatching on what FlashCap actually handed us. Fails closed on anything unexpected.
    /// </summary>
    private bool TryToLuminance(ArraySegment<byte> frame, out int width, out int height)
    {
        width = 0;
        height = 0;
        var data = frame.AsSpan();
        if (data.Length < 4) return false;

        // 'BM' — FlashCap transcoded a YUV frame into a DIB for us.
        if (data[0] == 'B' && data[1] == 'M') return TryDibToLuminance(frame, out width, out height);

        // 0xFFD8 (JPEG) / PNG signature — a compressed mode FlashCap passes through untouched.
        // MJPEG is the fastest mode on most integrated webcams, so this is the common path.
        if (data[0] == 0xFF && data[1] == 0xD8) return TryCompressedToLuminance(frame, out width, out height);
        if (data[0] == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G')
            return TryCompressedToLuminance(frame, out width, out height);

        return false;
    }

    /// <summary>Decodes a JPEG/PNG frame through WIC and converts it straight to Gray8.</summary>
    private bool TryCompressedToLuminance(ArraySegment<byte> compressed, out int width, out int height)
    {
        width = 0;
        height = 0;
        try
        {
            using var stream = new MemoryStream(compressed.Array!, compressed.Offset, compressed.Count, writable: false);
            var decoder = BitmapDecoder.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
            if (decoder.Frames.Count == 0) return false;

            var gray = new FormatConvertedBitmap(decoder.Frames[0], System.Windows.Media.PixelFormats.Gray8, null, 0);
            width = gray.PixelWidth;
            height = gray.PixelHeight;
            if (width <= 0 || height <= 0) return false;

            if (_lumBuffer.Length != width * height)
                _lumBuffer = new byte[width * height];
            gray.CopyPixels(_lumBuffer, width, 0);
            return true;
        }
        catch (Exception)
        {
            // A torn or truncated frame is not worth a crash — the carousel will send another.
            return false;
        }
    }

    /// <summary>Converts a DIB (BMP, bottom-up BGR24/BGRA32) into the reusable luminance plane.</summary>
    private bool TryDibToLuminance(ArraySegment<byte> bmp, out int width, out int height)
    {
        width = 0;
        height = 0;
        var data = bmp.AsSpan();
        if (data.Length < 54) return false;

        int pixelOffset = BinaryPrimitives.ReadInt32LittleEndian(data[10..]);
        width = BinaryPrimitives.ReadInt32LittleEndian(data[18..]);
        int rawHeight = BinaryPrimitives.ReadInt32LittleEndian(data[22..]);
        int bpp = BinaryPrimitives.ReadUInt16LittleEndian(data[28..]);
        if (width <= 0 || rawHeight == 0 || (bpp != 24 && bpp != 32)) return false;

        bool bottomUp = rawHeight > 0;
        height = Math.Abs(rawHeight);
        int bytesPerPixel = bpp / 8;
        int stride = (width * bytesPerPixel + 3) & ~3;
        long needed = pixelOffset + (long)stride * height;
        if (pixelOffset < 54 || needed > data.Length) return false;

        if (_lumBuffer.Length != width * height)
            _lumBuffer = new byte[width * height];

        for (int y = 0; y < height; y++)
        {
            int srcRow = bottomUp ? height - 1 - y : y;
            var src = data.Slice(pixelOffset + srcRow * stride, width * bytesPerPixel);
            int dst = y * width;
            for (int x = 0; x < width; x++)
            {
                int p = x * bytesPerPixel;
                // Fast luma approximation: (B + 2G + R) / 4
                _lumBuffer[dst + x] = (byte)((src[p] + (src[p + 1] << 1) + src[p + 2]) >> 2);
            }
        }
        return true;
    }

    public async ValueTask DisposeAsync()
    {
        if (_device is not null)
        {
            try { await _device.StopAsync(); } catch (Exception) { /* device may already be gone */ }
            _device.Dispose();
            _device = null;
        }
    }
}
