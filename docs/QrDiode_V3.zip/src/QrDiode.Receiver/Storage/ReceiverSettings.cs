using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using QrDiode.Core;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// Operator preferences that outlive a run. Deliberately tiny and deliberately free of anything
/// security-relevant: nothing in here can weaken a check, only decide where verified bytes land
/// and how the archive is laid out on disk.
/// </summary>
public sealed class ReceiverSettings
{
    private static readonly JsonSerializerOptions Json = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
    };

    /// <summary>Root of the local payload store. Every verified payload is written under it.</summary>
    public string StorageRoot { get; set; } = QrDiodePaths.DefaultStorageDir;

    /// <summary>Group arrivals into <c>yyyy-MM-dd</c> folders — a day's traffic stays browsable.</summary>
    public bool OrganizeByDate { get; set; } = true;

    /// <summary>Write a <c>.meta.json</c> next to each payload so the folder is self-describing.</summary>
    public bool WriteSidecar { get; set; } = true;

    public static ReceiverSettings Load()
    {
        try
        {
            if (File.Exists(QrDiodePaths.ReceiverSettingsFile))
            {
                var loaded = JsonSerializer.Deserialize<ReceiverSettings>(
                    File.ReadAllText(QrDiodePaths.ReceiverSettingsFile), Json);
                if (loaded is not null)
                {
                    // A settings file that has been hand-edited into nonsense must not take the
                    // receiver down — fall back to the default root and carry on.
                    if (string.IsNullOrWhiteSpace(loaded.StorageRoot))
                        loaded.StorageRoot = QrDiodePaths.DefaultStorageDir;
                    return loaded;
                }
            }
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
            // Unreadable settings are not worth blocking a receive on.
        }
        return new ReceiverSettings();
    }

    public void Save()
    {
        Directory.CreateDirectory(QrDiodePaths.Root);
        File.WriteAllText(QrDiodePaths.ReceiverSettingsFile, JsonSerializer.Serialize(this, Json));
    }
}
