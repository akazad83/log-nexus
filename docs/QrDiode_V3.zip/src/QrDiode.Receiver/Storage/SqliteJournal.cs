using System.Globalization;
using System.Text;
using Microsoft.Data.Sqlite;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Receiver.Inbox;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// SQLite-backed (WAL) transfer journal + anti-replay store. One file, fully transactional.
/// Status flow: verified → stored (or duplicate). A 'verified' row without a quarantine file
/// indicates a crash between verification and materialization and is surfaced to the operator.
/// </summary>
public sealed class SqliteJournal : IReplayGuard, IDisposable
{
    private readonly SqliteConnection _connection;
    private readonly TimeProvider _clock;
    private readonly object _lock = new();

    /// <summary>
    /// Anti-replay timestamp tolerance. Settable because the journal outlives a run — the archive
    /// tab reads it while nothing is being received — but the receiver commits it at Start and
    /// locks the control for the duration, so it never moves under a session in flight.
    /// </summary>
    public TimeSpan ReplayWindow { get; set; }

    public SqliteJournal(string dbPath, TimeProvider? clock = null, TimeSpan? replayWindow = null)
    {
        _clock = clock ?? TimeProvider.System;
        ReplayWindow = replayWindow ?? TimeSpan.FromHours(48);
        _connection = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = dbPath,
            Mode = SqliteOpenMode.ReadWriteCreate,
        }.ToString());
        _connection.Open();

        Execute("PRAGMA journal_mode=WAL;");
        Execute("PRAGMA synchronous=FULL;");
        Execute("""
            CREATE TABLE IF NOT EXISTS transfers (
                session_guid     TEXT PRIMARY KEY,
                sender_key_id    TEXT NOT NULL,
                counter          INTEGER NOT NULL,
                plaintext_sha256 TEXT NOT NULL,
                filename         TEXT NOT NULL,
                size             INTEGER NOT NULL,
                received_utc     TEXT NOT NULL,
                status           TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_transfers_hash ON transfers(sender_key_id, plaintext_sha256);
            CREATE TABLE IF NOT EXISTS key_watermarks (
                key_id  TEXT PRIMARY KEY,
                counter INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS payload_index (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                received_utc  TEXT NOT NULL,
                outcome       TEXT NOT NULL,
                session_guid  TEXT NOT NULL,
                sender_key_id TEXT NOT NULL,
                counter       INTEGER NOT NULL,
                type_code     TEXT NOT NULL,
                type_name     TEXT NOT NULL,
                content_kind  INTEGER NOT NULL,
                filename      TEXT NOT NULL,
                size          INTEGER NOT NULL,
                sha256        TEXT NOT NULL,
                receipt       TEXT NOT NULL,
                stored_path   TEXT,
                reason        TEXT,
                seconds       REAL NOT NULL,
                snippet       TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS ix_payload_index_time ON payload_index(received_utc DESC);
            CREATE INDEX IF NOT EXISTS ix_payload_index_outcome ON payload_index(outcome, received_utc DESC);
            """);
    }

    public ReplayVerdict Check(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter, long timestampUnixMs)
    {
        lock (_lock)
        {
            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "SELECT 1 FROM transfers WHERE session_guid = $g";
                cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
                if (cmd.ExecuteScalar() is not null) return ReplayVerdict.DuplicateSession;
            }

            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "SELECT counter FROM key_watermarks WHERE key_id = $k";
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                if (cmd.ExecuteScalar() is long mark && counter <= (ulong)mark) return ReplayVerdict.StaleCounter;
            }

            long nowMs = _clock.GetUtcNow().ToUnixTimeMilliseconds();
            if (Math.Abs(nowMs - timestampUnixMs) > ReplayWindow.TotalMilliseconds) return ReplayVerdict.TimestampOutOfWindow;

            return ReplayVerdict.Fresh;
        }
    }

    public void Commit(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, ulong counter)
    {
        // The engine calls this at verification time; the row is completed by RecordTransfer.
        lock (_lock)
        {
            using var tx = _connection.BeginTransaction();
            using (var cmd = _connection.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = """
                    INSERT INTO key_watermarks(key_id, counter) VALUES ($k, $c)
                    ON CONFLICT(key_id) DO UPDATE SET counter = MAX(counter, excluded.counter);
                    """;
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                cmd.Parameters.AddWithValue("$c", unchecked((long)counter));
                cmd.ExecuteNonQuery();
            }
            using (var cmd = _connection.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = """
                    INSERT OR IGNORE INTO transfers(session_guid, sender_key_id, counter, plaintext_sha256, filename, size, received_utc, status)
                    VALUES ($g, $k, $c, '', '', 0, $t, 'verified');
                    """;
                cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
                cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
                cmd.Parameters.AddWithValue("$c", unchecked((long)counter));
                cmd.Parameters.AddWithValue("$t", _clock.GetUtcNow().ToString("O"));
                cmd.ExecuteNonQuery();
            }
            tx.Commit();
        }
    }

    /// <summary>True if this sender has already delivered a payload with this plaintext hash.</summary>
    public bool IsDuplicateContent(ReadOnlySpan<byte> senderSigningKeyId, ReadOnlySpan<byte> plaintextSha256)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = "SELECT 1 FROM transfers WHERE sender_key_id = $k AND plaintext_sha256 = $h AND status = 'stored'";
            cmd.Parameters.AddWithValue("$k", Convert.ToHexString(senderSigningKeyId));
            cmd.Parameters.AddWithValue("$h", Convert.ToHexString(plaintextSha256));
            return cmd.ExecuteScalar() is not null;
        }
    }

    /// <summary>Completes the journal row for a materialized (or deduplicated) transfer.</summary>
    public void RecordTransfer(Guid sessionId, ReadOnlySpan<byte> plaintextSha256, string filename, long size, string status)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = """
                UPDATE transfers SET plaintext_sha256 = $h, filename = $f, size = $s, status = $st
                WHERE session_guid = $g;
                """;
            cmd.Parameters.AddWithValue("$h", Convert.ToHexString(plaintextSha256));
            cmd.Parameters.AddWithValue("$f", filename);
            cmd.Parameters.AddWithValue("$s", size);
            cmd.Parameters.AddWithValue("$st", status);
            cmd.Parameters.AddWithValue("$g", sessionId.ToString("N"));
            cmd.ExecuteNonQuery();
        }
    }

    // ═══════════════════ archive index ═══════════════════

    /// <summary>
    /// Records one arrival — stored, duplicate, rejected or failed — for the archive browser.
    /// This is an index over what happened, not the payload itself: the bytes live in the payload
    /// store, and this row is what makes them findable months later.
    /// </summary>
    public long IndexArrival(ArchiveRecord record)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = """
                INSERT INTO payload_index(received_utc, outcome, session_guid, sender_key_id, counter,
                                          type_code, type_name, content_kind, filename, size, sha256,
                                          receipt, stored_path, reason, seconds, snippet)
                VALUES ($t, $o, $g, $k, $c, $tc, $tn, $ck, $f, $s, $h, $r, $p, $why, $sec, $snip);
                SELECT last_insert_rowid();
                """;
            cmd.Parameters.AddWithValue("$t", record.ReceivedUtc.ToString("O"));
            cmd.Parameters.AddWithValue("$o", ToStatus(record.Outcome));
            cmd.Parameters.AddWithValue("$g", record.SessionId);
            cmd.Parameters.AddWithValue("$k", record.SenderKeyId);
            cmd.Parameters.AddWithValue("$c", unchecked((long)record.Counter));
            cmd.Parameters.AddWithValue("$tc", record.Type.Code);
            cmd.Parameters.AddWithValue("$tn", record.Type.Name);
            cmd.Parameters.AddWithValue("$ck", (int)record.ContentType);
            cmd.Parameters.AddWithValue("$f", record.Filename);
            cmd.Parameters.AddWithValue("$s", record.Size);
            cmd.Parameters.AddWithValue("$h", record.Sha256);
            cmd.Parameters.AddWithValue("$r", record.Receipt);
            cmd.Parameters.AddWithValue("$p", (object?)record.StoredPath ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$why", (object?)record.Reason ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$sec", record.Seconds);
            cmd.Parameters.AddWithValue("$snip", record.Snippet);
            return cmd.ExecuteScalar() is long id ? id : 0;
        }
    }

    public IReadOnlyList<ArchiveRecord> QueryArchive(ArchiveQuery query)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            var sql = new StringBuilder("SELECT id, received_utc, outcome, session_guid, sender_key_id, counter, " +
                                        "content_kind, filename, size, sha256, receipt, stored_path, reason, seconds, " +
                                        "snippet FROM payload_index WHERE 1=1");
            AppendFilters(cmd, sql, query);
            sql.Append(" ORDER BY received_utc DESC, id DESC LIMIT $limit");
            cmd.Parameters.AddWithValue("$limit", Math.Clamp(query.Limit, 1, 20_000));
            cmd.CommandText = sql.ToString();

            var rows = new List<ArchiveRecord>();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                rows.Add(new ArchiveRecord
                {
                    Id = reader.GetInt64(0),
                    ReceivedUtc = ParseUtc(reader.GetString(1)),
                    Outcome = FromStatus(reader.GetString(2)),
                    SessionId = reader.GetString(3),
                    SenderKeyId = reader.GetString(4),
                    Counter = unchecked((ulong)reader.GetInt64(5)),
                    ContentType = (ContentKind)reader.GetInt32(6),
                    Filename = reader.GetString(7),
                    Size = reader.GetInt64(8),
                    Sha256 = reader.GetString(9),
                    Receipt = reader.GetString(10),
                    StoredPath = reader.IsDBNull(11) ? null : reader.GetString(11),
                    Reason = reader.IsDBNull(12) ? null : reader.GetString(12),
                    Seconds = reader.GetDouble(13),
                    Snippet = reader.IsDBNull(14) ? "" : reader.GetString(14),
                });
            }
            return rows;
        }
    }

    /// <summary>Totals over everything the filter matches, not just the page that got loaded.</summary>
    public ArchiveTotals QueryTotals(ArchiveQuery query)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            var sql = new StringBuilder("""
                SELECT COUNT(*),
                       SUM(outcome = 'verified'),
                       SUM(outcome = 'duplicate'),
                       SUM(outcome IN ('rejected','store_failed')),
                       SUM(CASE WHEN outcome = 'verified' THEN size ELSE 0 END),
                       MIN(received_utc), MAX(received_utc)
                FROM payload_index WHERE 1=1
                """);
            AppendFilters(cmd, sql, query with { Outcome = null });
            cmd.CommandText = sql.ToString();

            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) return new ArchiveTotals(0, 0, 0, 0, 0, null, null);

            return new ArchiveTotals(
                reader.GetInt32(0),
                reader.IsDBNull(1) ? 0 : reader.GetInt32(1),
                reader.IsDBNull(2) ? 0 : reader.GetInt32(2),
                reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                reader.IsDBNull(4) ? 0 : reader.GetInt64(4),
                reader.IsDBNull(5) ? null : ParseUtc(reader.GetString(5)),
                reader.IsDBNull(6) ? null : ParseUtc(reader.GetString(6)));
        }
    }

    /// <summary>What arrived, by payload type — the shape of the traffic this receiver sees.</summary>
    public IReadOnlyList<TypeTally> QueryTypeTallies(ArchiveQuery query)
    {
        lock (_lock)
        {
            using var cmd = _connection.CreateCommand();
            var sql = new StringBuilder("SELECT type_code, type_name, COUNT(*), " +
                                        "SUM(CASE WHEN outcome = 'verified' THEN size ELSE 0 END) " +
                                        "FROM payload_index WHERE 1=1");
            AppendFilters(cmd, sql, query);
            sql.Append(" GROUP BY type_code, type_name ORDER BY COUNT(*) DESC, type_code LIMIT 16");
            cmd.CommandText = sql.ToString();

            var tallies = new List<TypeTally>();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                tallies.Add(new TypeTally(
                    reader.GetString(0),
                    reader.GetString(1),
                    reader.GetInt32(2),
                    reader.IsDBNull(3) ? 0 : reader.GetInt64(3)));
            }
            return tallies;
        }
    }

    private static void AppendFilters(SqliteCommand cmd, StringBuilder sql, ArchiveQuery query)
    {
        if (query.SinceUtc is { } since)
        {
            sql.Append(" AND received_utc >= $since");
            cmd.Parameters.AddWithValue("$since", since.ToString("O"));
        }

        if (query.Outcome is { } outcome)
        {
            if (outcome is InboxOutcome.Rejected)
            {
                // "✖" on the filter tray means "did not land", which covers both ways that happens.
                sql.Append(" AND outcome IN ('rejected','store_failed')");
            }
            else
            {
                sql.Append(" AND outcome = $outcome");
                cmd.Parameters.AddWithValue("$outcome", ToStatus(outcome));
            }
        }

        if (query.Search is { Length: > 0 } search)
        {
            sql.Append(" AND (filename LIKE $q ESCAPE '\\' OR type_name LIKE $q ESCAPE '\\' " +
                       "OR type_code LIKE $q ESCAPE '\\' OR session_guid LIKE $q ESCAPE '\\' " +
                       "OR receipt LIKE $q ESCAPE '\\' OR sender_key_id LIKE $q ESCAPE '\\' " +
                       "OR snippet LIKE $q ESCAPE '\\' OR IFNULL(reason,'') LIKE $q ESCAPE '\\')");
            cmd.Parameters.AddWithValue("$q", "%" + EscapeLike(search) + "%");
        }
    }

    /// <summary>A search box is free text: <c>%</c> and <c>_</c> must match themselves, not glob.</summary>
    private static string EscapeLike(string value) =>
        value.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");

    /// <summary>Rows are written with round-trip "O" formatting; anything else is not a timestamp.</summary>
    private static DateTime ParseUtc(string value) =>
        DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var parsed)
            ? parsed.ToUniversalTime()
            : DateTime.UnixEpoch;

    private static string ToStatus(InboxOutcome outcome) => outcome switch
    {
        InboxOutcome.Verified => "verified",
        InboxOutcome.Duplicate => "duplicate",
        InboxOutcome.StoreFailed => "store_failed",
        _ => "rejected",
    };

    private static InboxOutcome FromStatus(string status) => status switch
    {
        "verified" => InboxOutcome.Verified,
        "duplicate" => InboxOutcome.Duplicate,
        "store_failed" => InboxOutcome.StoreFailed,
        _ => InboxOutcome.Rejected,
    };

    private void Execute(string sql)
    {
        using var cmd = _connection.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    public void Dispose() => _connection.Dispose();
}
