using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using QrDiode.Core.Manifest;
using QrDiode.Core.Simulation;
using QrDiode.Receiver.Inbox;

namespace QrDiode.Receiver.Storage;

/// <summary>Result of re-hashing a stored file against the hash the signed manifest carried.</summary>
public enum IntegrityState
{
    Unchecked,
    Checking,
    /// <summary>Bytes on disk still hash to what the sender signed.</summary>
    Intact,
    /// <summary>The file changed after it was written — the store has been tampered with.</summary>
    Altered,
    /// <summary>Indexed but no longer on disk: moved, archived off, or deleted.</summary>
    Missing,
}

/// <summary>
/// One row of the persistent archive — the journal's memory of an arrival, whether or not it
/// produced a file. Rejections are recorded too: "nothing was written" is itself evidence, and an
/// archive that only remembers successes cannot answer the question an incident asks of it.
/// </summary>
public sealed class ArchiveRecord : INotifyPropertyChanged
{
    private IntegrityState _integrity = IntegrityState.Unchecked;
    private string _integrityNote = "";

    public required long Id { get; init; }
    public required DateTime ReceivedUtc { get; init; }
    public required InboxOutcome Outcome { get; init; }
    public required string Filename { get; init; }
    public required long Size { get; init; }
    public ContentKind ContentType { get; init; }
    public string SessionId { get; init; } = "";
    public string SenderKeyId { get; init; } = "";
    public ulong Counter { get; init; }
    public string Sha256 { get; init; } = "";
    public string Receipt { get; init; } = "";
    public string? StoredPath { get; init; }
    public string? Reason { get; init; }
    public double Seconds { get; init; }

    /// <summary>One flattened line of the payload, kept in the index so the list stays readable
    /// without opening a single file.</summary>
    public string Snippet { get; init; } = "";

    public bool HasSnippet => Snippet.Length > 0;

    /// <summary>Resolved once: a virtualized list re-reads this binding on every scroll.</summary>
    public PayloadType Type => _type ??= PayloadCatalogue.ForFilename(Filename, ContentType);
    private PayloadType? _type;
    public DateTime ReceivedLocal => ReceivedUtc.ToLocalTime();
    public string DateLabel => ReceivedLocal.ToString("yyyy-MM-dd");
    public string TimeLabel => ReceivedLocal.ToString("HH:mm:ss");

    public string SizeLabel => Size switch
    {
        <= 0 => "—",
        < 1024 => $"{Size:N0} B",
        < 1024 * 1024 => $"{Size / 1024.0:0.#} KB",
        _ => $"{Size / (1024.0 * 1024):0.#} MB",
    };

    public string OutcomeLabel => Outcome switch
    {
        InboxOutcome.Verified => "✔ stored",
        InboxOutcome.Duplicate => "◎ duplicate",
        InboxOutcome.StoreFailed => "✖ not stored",
        _ => "✖ rejected",
    };

    public string MetaLine =>
        (SenderKeyId.Length >= 4 ? "sign " + Short(SenderKeyId) : "sender not established") +
        (SessionId.Length >= 8 ? $" · session {SessionId[..8]}…" : "") +
        (Counter > 0 ? $" · counter {Counter}" : "") +
        (Seconds > 0 ? $" · {Seconds:0.0} s" : "");

    public string ReceiptGrouped => Receipt.Length >= 16 ? InboxEntry.Grouped(Receipt[..16]) : "—";

    /// <summary>True once the payload exists as bytes an operator can open.</summary>
    public bool HasFile => StoredPath is { Length: > 0 } path && File.Exists(path);

    public IntegrityState Integrity
    {
        get => _integrity;
        set { if (_integrity != value) { _integrity = value; Raise(); Raise(nameof(IntegrityLabel)); } }
    }

    public string IntegrityNote
    {
        get => _integrityNote;
        set { if (_integrityNote != value) { _integrityNote = value; Raise(); } }
    }

    public string IntegrityLabel => Integrity switch
    {
        IntegrityState.Checking => "hashing…",
        IntegrityState.Intact => "✔ bytes match the signed hash",
        IntegrityState.Altered => "✖ file no longer matches the signed hash",
        IntegrityState.Missing => "— file is not on disk",
        _ => "integrity not checked",
    };

    public bool Matches(string query)
    {
        if (query.Length == 0) return true;
        return Filename.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Type.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Type.Code.Contains(query, StringComparison.OrdinalIgnoreCase)
            || SessionId.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Receipt.Contains(query, StringComparison.OrdinalIgnoreCase)
            || SenderKeyId.Contains(query, StringComparison.OrdinalIgnoreCase)
            || (Reason?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false);
    }

    private static string Short(string hex) => hex.Length <= 12 ? hex : $"{hex[..4]}…{hex[^4..]}";

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Raise([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

/// <summary>What the archive tab is currently asking the journal for.</summary>
public sealed record ArchiveQuery(
    string Search = "",
    InboxOutcome? Outcome = null,
    DateTime? SinceUtc = null,
    int Limit = 2000);

/// <summary>Headline numbers for the archive, computed in SQL rather than over the loaded page.</summary>
public sealed record ArchiveTotals(
    int Arrivals,
    int Verified,
    int Duplicates,
    int Rejected,
    long StoredBytes,
    DateTime? FirstUtc,
    DateTime? LastUtc);

/// <summary>One line of the per-type breakdown — what this camera actually sees, by volume.</summary>
public sealed record TypeTally(string Code, string Name, int Count, long Bytes)
{
    public string BytesLabel => Bytes switch
    {
        < 1024 => $"{Bytes:N0} B",
        < 1024 * 1024 => $"{Bytes / 1024.0:0.#} KB",
        _ => $"{Bytes / (1024.0 * 1024):0.#} MB",
    };
}
