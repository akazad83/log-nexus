﻿using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// The physical landing zone for verified payloads. One payload becomes one file plus, optionally,
/// one <c>.meta.json</c> sidecar, so the folder can be read by anything — a script, an AV scanner,
/// an auditor with Explorer — without this app or its journal.
///
/// Writes stay atomic: staging file + fsync, then rename into place. Staging lives inside the
/// configured root so the rename never crosses a volume boundary, which is the one thing that
/// would turn an atomic move back into a copy.
/// </summary>
public sealed class PayloadStore
{
    public const string SidecarSuffix = ".meta.json";
    private const string StagingFolder = ".staging";

    /// <summary>
    /// Longest stored name component we will produce, session prefix included.
    ///
    /// The manifest permits a 255-byte filename and the stored name carries a 33-character
    /// session prefix, so an uncapped name can reach 288 characters — past the 255-character
    /// NTFS component limit. <see cref="File.Move(string, string, bool)"/> then throws on a
    /// payload that has already passed every verification step, and on a one-way channel there
    /// is no way to ask for it again. The cap is set well below the limit so the full path has
    /// headroom too; transaction filenames are a fraction of it.
    /// </summary>
    public const int MaxStoredNameChars = 120;

    private const int SessionPrefixChars = 33;   // "{guid:N}_"
    private const int MaxExtensionChars = 16;
    private const int MaxFullPathChars = 259;    // classic MAX_PATH, minus the terminator

    private static readonly JsonSerializerOptions SidecarJson = new() { WriteIndented = true };
    private readonly object _lock = new();

    public PayloadStore(ReceiverSettings settings)
    {
        Root = settings.StorageRoot;
        OrganizeByDate = settings.OrganizeByDate;
        WriteSidecar = settings.WriteSidecar;
    }

    public string Root { get; private set; }
    public bool OrganizeByDate { get; private set; }
    public bool WriteSidecar { get; private set; }

    public string StagingDir => Path.Combine(Root, StagingFolder);

    public void Apply(ReceiverSettings settings)
    {
        lock (_lock)
        {
            Root = settings.StorageRoot;
            OrganizeByDate = settings.OrganizeByDate;
            WriteSidecar = settings.WriteSidecar;
        }
    }

    /// <summary>
    /// Creates the root and its staging folder, then proves the store is actually writable by
    /// round-tripping a probe file. Called before a run starts so a bad path fails at Start —
    /// not three payloads into a session with nowhere to put them.
    /// </summary>
    public void EnsureReady()
    {
        lock (_lock)
        {
            // A root deep enough that a worst-case payload name would not fit must fail here, for
            // the same reason the write probe exists: not three payloads into a session with
            // verified plaintext in hand and nowhere to put it.
            int worstCasePath = Root.Length
                + 1 + 10                     // "\yyyy-MM-dd" when OrganizeByDate is on
                + 1 + MaxStoredNameChars     // "\" + the stored name
                + SidecarSuffix.Length;
            if (worstCasePath > MaxFullPathChars)
                throw new PathTooLongException(
                    $"The store root is {Root.Length} characters long, which leaves no room for a payload " +
                    $"name (worst case {worstCasePath} characters, limit {MaxFullPathChars}). Choose a shorter folder.");

            Directory.CreateDirectory(Root);
            Directory.CreateDirectory(StagingDir);

            string probe = Path.Combine(StagingDir, $".probe-{Guid.NewGuid():N}");
            File.WriteAllBytes(probe, [0x71, 0x72]);
            File.Delete(probe);
        }
    }

    /// <summary>Writes one verified payload and returns the path it now lives at.</summary>
    public string Save(TransferManifest manifest, byte[] plaintext, string receipt, DateTime receivedLocal)
    {
        lock (_lock)
        {
            string folder = OrganizeByDate
                ? Path.Combine(Root, receivedLocal.ToString("yyyy-MM-dd"))
                : Root;
            Directory.CreateDirectory(folder);
            Directory.CreateDirectory(StagingDir);

            string finalName = $"{manifest.SessionId:N}_{SanitizeFilename(manifest.Filename)}";
            string stagingPath = Path.Combine(StagingDir, finalName + ".tmp");
            string finalPath = Path.Combine(folder, finalName);

            using (var stream = new FileStream(stagingPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(plaintext);
                stream.Flush(flushToDisk: true);
            }
            File.Move(stagingPath, finalPath, overwrite: false);

            // Hashed from the bytes we just wrote, not read off the manifest: the plaintext hash
            // is deliberately not a wire field (see CompletedTransfer.PlaintextSha256).
            if (WriteSidecar)
                TryWriteSidecar(finalPath, manifest, Convert.ToHexString(SHA256.HashData(plaintext)),
                    receipt, receivedLocal);
            return finalPath;
        }
    }

    /// <summary>
    /// The sidecar is a convenience, not a record — the journal and the audit log are. A failure
    /// to write it must never undo a payload that is already safely on disk.
    /// </summary>
    private static void TryWriteSidecar(string payloadPath, TransferManifest manifest, string plaintextSha256, string receipt, DateTime receivedLocal)
    {
        try
        {
            var meta = new
            {
                session = manifest.SessionId.ToString("N"),
                receivedLocal = receivedLocal.ToString("O"),
                receivedUtc = receivedLocal.ToUniversalTime().ToString("O"),
                sentUtc = DateTimeOffset.FromUnixTimeMilliseconds(manifest.TimestampUnixMs).UtcDateTime.ToString("O"),
                counter = manifest.Counter,
                filename = manifest.Filename,
                // The name on disk, which may be a truncation of the one above.
                storedName = Path.GetFileName(payloadPath),
                contentType = manifest.ContentType.ToString(),
                originalSize = manifest.OriginalSize,
                compressedSize = manifest.CompressedSize,
                ciphertextSize = manifest.CiphertextSize,
                compression = manifest.Compression.ToString(),
                senderSigningKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                receiverAgreementKeyId = KeyId.ToHex(manifest.ReceiverAgreementKeyId),
                plaintextSha256,
                ciphertextSha256 = Convert.ToHexString(manifest.CiphertextSha256),
                sourceSymbolCount = manifest.SourceSymbolCount,
                symbolSize = manifest.SymbolSize,
                receipt,
            };
            File.WriteAllText(payloadPath + SidecarSuffix, JsonSerializer.Serialize(meta, SidecarJson));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
        {
        }
    }

    /// <summary>
    /// Sender-supplied filenames are hostile input; nothing here may escape the store, and
    /// nothing here may produce a name the filesystem will refuse.
    ///
    /// Note that the session-GUID prefix applied by <see cref="Save"/> also means a stored name
    /// can never *be* a Windows reserved device name (CON, LPT1, …). That property is doing real
    /// work — if the prefix is ever dropped, this method has to grow a reserved-name check.
    /// </summary>
    public static string SanitizeFilename(string name)
        => SanitizeFilename(name, MaxStoredNameChars - SessionPrefixChars);

    private static string SanitizeFilename(string name, int maxChars)
    {
        maxChars = Math.Max(1, maxChars);

        var invalid = Path.GetInvalidFileNameChars();
        var chars = name.Select(c => invalid.Contains(c) ? '_' : c).ToArray();
        string safe = new string(chars).TrimStart('.').Trim();

        if (safe.Length == 0) return "payload.bin";
        if (safe.Length <= maxChars) return safe;

        // Truncate the stem and keep the extension: a stored payload should stay recognisably
        // .json or .xml. The untruncated name is still recorded in the sidecar and the journal,
        // so nothing is lost from the record — only from the name on disk.
        string ext = Path.GetExtension(safe);
        string stem = safe[..(safe.Length - ext.Length)];
        if (ext.Length > MaxExtensionChars) ext = ext[..MaxExtensionChars];

        int stemBudget = Math.Max(1, maxChars - ext.Length);
        return string.Concat(stem.AsSpan(0, Math.Min(stem.Length, stemBudget)), ext);
    }
}
