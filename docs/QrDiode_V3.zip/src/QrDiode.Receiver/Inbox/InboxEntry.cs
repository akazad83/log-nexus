using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using QrDiode.Core.Manifest;
using QrDiode.Core.Simulation;

namespace QrDiode.Receiver.Inbox;

public enum InboxOutcome
{
    /// <summary>The whole chain passed and the payload is in quarantine. The only green.</summary>
    Verified,
    Duplicate,
    Rejected,
    StoreFailed,
}

public enum ChainStatus { Passed, Failed, NotReached }

/// <summary>One step of the verification chain, as the operator reads it after the fact.</summary>
public sealed record ChainStep(string Step, ChainStatus Status, string Note)
{
    public string Icon => Status switch
    {
        ChainStatus.Passed => "✔",
        ChainStatus.Failed => "✖",
        _ => "—",
    };
}

/// <summary>
/// One arrival in the live inbox. Rejections are entries too — a rejection is a result, not an
/// absence of one, and the operator must be able to tell rejected from duplicate from failed at a
/// glance without reading the colour.
/// </summary>
public sealed class InboxEntry : INotifyPropertyChanged
{
    /// <summary>
    /// How much of a payload the live inbox keeps in memory for its viewer. The file in the
    /// payload store is always the real thing — this is only what the operator can look at
    /// without touching the disk.
    /// </summary>
    public const int PreviewBytes = 128 * 1024;

    /// <summary>Rows past this depth keep their metadata but drop their bytes; the store has them.</summary>
    public const int PreviewDepth = 60;

    private int _repeats = 1;
    private byte[]? _previewData;

    public required PayloadType Type { get; init; }
    public required string Name { get; init; }
    public required long Size { get; init; }
    public required DateTime ArrivedAt { get; init; }
    public required InboxOutcome Outcome { get; init; }
    public string SenderKeyShort { get; init; } = "";

    /// <summary>Full signing-key id. The row shows the short form; the archive indexes this one.</summary>
    public string SenderKeyId { get; init; } = "";
    public string SessionId { get; init; } = "";
    public string Receipt { get; init; } = "";
    public string? StoredPath { get; init; }
    public string? Reason { get; init; }
    public string? PlaintextSha256 { get; init; }
    public double Seconds { get; init; }
    public ContentKind ContentType { get; init; }
    public ulong Counter { get; init; }
    public IReadOnlyList<ChainStep> Chain { get; init; } = [];

    /// <summary>
    /// The decrypted payload, capped at <see cref="PreviewBytes"/>. Null once the row ages out of
    /// <see cref="PreviewDepth"/>, or for anything that never got decrypted — the viewer then falls
    /// back to <see cref="StoredPath"/>.
    /// </summary>
    public byte[]? PreviewData
    {
        get => _previewData;
        set { _previewData = value; Raise(); }
    }

    /// <summary>True when the payload was longer than the in-memory cap.</summary>
    public bool PreviewTruncated { get; init; }

    /// <summary>One flattened line of the payload itself, shown right in the row.</summary>
    public string Snippet { get; init; } = "";

    public bool HasSnippet => Snippet.Length > 0;

    /// <summary>True once the payload exists in the local store as bytes an operator can open.</summary>
    public bool HasFile => StoredPath is { Length: > 0 } path && File.Exists(path);

    /// <summary>Identical back-to-back rejections coalesce into one row rather than flooding the list.</summary>
    public int Repeats
    {
        get => _repeats;
        set { _repeats = value; Raise(); Raise(nameof(OutcomeLabel)); Raise(nameof(TimeLabel)); }
    }

    public string OutcomeLabel => Outcome switch
    {
        InboxOutcome.Verified => "✔ verified & stored",
        InboxOutcome.Duplicate => "◎ duplicate",
        InboxOutcome.StoreFailed => "✖ materialization failed",
        _ => "✖ rejected" + (ShortReason is { Length: > 0 } r ? " · " + r : ""),
    } + (Repeats > 1 ? $" ×{Repeats}" : "");

    /// <summary>The reason boiled down to what fits on a pill; the detail pane carries the rest.</summary>
    public string ShortReason
    {
        get
        {
            if (Reason is null) return "";
            int colon = Reason.LastIndexOf(": ", StringComparison.Ordinal);
            string tail = colon >= 0 ? Reason[(colon + 2)..] : Reason;
            return tail.Length <= 28 ? tail : tail[..27] + "…";
        }
    }

    public string TimeLabel => ArrivedAt.ToString("HH:mm:ss");
    public string SizeLabel => Size switch
    {
        < 1024 => $"{Size:N0} B",
        < 1024 * 1024 => $"{Size / 1024.0:0.#} KB",
        _ => $"{Size / (1024.0 * 1024):0.#} MB",
    };

    public string MetaLine =>
        $"{SenderKeyShort} · session {(SessionId.Length >= 8 ? SessionId[..8] : SessionId)}…" +
        (Seconds > 0 ? $" · {Seconds:0.0} s" : "");

    public string ReceiptGrouped => Receipt.Length >= 16 ? Grouped(Receipt[..16]) : "—";

    public static string Grouped(string hex) =>
        string.Join(' ', Enumerable.Range(0, (hex.Length + 3) / 4)
            .Select(i => hex.Substring(i * 4, Math.Min(4, hex.Length - i * 4))));

    /// <summary>Matches the search box against everything the operator might type.</summary>
    public bool Matches(string query)
    {
        if (query.Length == 0) return true;
        return Name.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Type.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Type.Code.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Receipt.Contains(query, StringComparison.OrdinalIgnoreCase)
            || SessionId.Contains(query, StringComparison.OrdinalIgnoreCase)
            || Snippet.Contains(query, StringComparison.OrdinalIgnoreCase)
            || (Reason?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Raise([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
