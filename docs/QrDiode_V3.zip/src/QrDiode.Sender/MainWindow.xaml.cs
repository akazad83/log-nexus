﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using Path = System.IO.Path;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Presentation;
using QrDiode.Core.Simulation;
using QrDiode.Sender.Transmit;
using QrDiode.Ui;

namespace QrDiode.Sender;

public partial class MainWindow : Window
{
    private CngEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    private readonly AuditLog _audit;
    private readonly LiveSource _source = new();
    private readonly TransmitEngine _engine;
    private StageWindow? _stage;
    private string? _lastReceipt;
    private QueueItem? _selected;
    private PayloadText _selectedText = PayloadText.Empty;
    private Guid _followedSession;
    /// <summary>XAML property setters raise Checked/ValueChanged while the tree is still half-built.</summary>
    private bool _ready;

    private sealed record ReceiverChoice(PeerPublicKeys Peer)
    {
        public string Label => $"{Peer.Name}   ·   kex {KeyId.ToHex(Peer.AgreementKeyId)}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "sender-audit.jsonl"));
        _engine = new TransmitEngine(_audit);
        QueueList.ItemsSource = _engine.Queue;

        _engine.Changed += OnEngineChanged;
        _engine.SessionEnded += OnSessionEnded;
        _engine.Queue.CollectionChanged += (_, _) => RefreshQueueChrome();

        _source.Emitted += payload => _engine.Enqueue(payload);
        _source.Tick += OnSourceTick;

        BuildTypeToggles();
        _ready = true;
        ReloadTrust();
        Interval_Changed(this, null!);
        Fps_Changed(this, null!);
        RenderDetail(null);
        RefreshEverything();
        RefreshDemoBanner();
    }

    // ═══════════════════ identity + trust ═══════════════════

    private void ReloadTrust()
    {
        _trust?.Dispose();
        _trust = new DirectoryTrustStore(QrDiodePaths.TrustDir);

        // Everyone in the trust store except ourselves is a valid destination.
        var choices = _trust.Peers
            .Where(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId))
            .Select(p => new ReceiverChoice(p))
            .ToList();
        ReceiverCombo.ItemsSource = choices;
        if (choices.Count > 0) ReceiverCombo.SelectedIndex = 0;

        SetPill(DestPill, DestPillText,
            choices.Count > 0 ? $"✔ {choices.Count} trusted" : "0 trusted",
            choices.Count > 0 ? "PillOk" : "PillIdle");
        DestNote.Text = choices.Count > 0
            ? "Manifests are addressed to this key only."
            : "Import the IT receiver’s bundle, or press ⚡ Demo setup on both apps.";

        SyncEngineIdentity();
    }

    private void ReloadTrust_Click(object sender, RoutedEventArgs e) => ReloadTrust();

    /// <summary>
    /// Shows the demo strip for as long as demo identities are in play. Driven by state rather than
    /// by the click that created it: the risk is a machine demoed once and later treated as
    /// provisioned, and a strip that only appears on click would not survive a restart.
    /// </summary>
    private void RefreshDemoBanner()
    {
        bool demo = DemoProvisioner.IsDemoEndpoint(EndpointNameBox.Text.Trim())
                    || DemoProvisioner.ArtifactsPresent();

        DemoStrip.Visibility = demo ? Visibility.Visible : Visibility.Collapsed;
        if (!demo) return;

        DemoStripTitle.Text = "⚡ DEMO IDENTITIES — BOTH PRIVATE KEYS ARE ON THIS MACHINE";
        if (string.IsNullOrWhiteSpace(DemoStripText.Text))
            DemoStripText.Text =
                "Full security is active — real ECDSA signatures, real AES-256-GCM, real anti-replay. " +
                "What is missing is separation: the receiver is trusting a sender whose signing key " +
                "lives on the same host. Run the KeyCeremony tool on two machines, then 'demo-clean', " +
                "before treating this as a provisioned link.";
    }

    private void Receiver_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) SyncEngineIdentity();
    }

    private void SyncEngineIdentity()
    {
        _engine.Keys = _keys;
        _engine.Receiver = (ReceiverCombo.SelectedItem as ReceiverChoice)?.Peer;
        RefreshEverything();
    }

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _keys?.Dispose();
            _keys = CngEndpointKeys.OpenOrCreate(EndpointNameBox.Text.Trim());
            KeyInfoText.Text = $"sign {KeyId.ToHex(_keys.SigningKeyId)} · kex {KeyId.ToHex(_keys.AgreementKeyId)}";
            SetPill(KeyStatusPill, KeyStatusPillText,
                _keys.IsTpmBacked ? "✔ TPM-backed" : "✔ software KSP", "PillOk");
            ReloadTrust();
            RefreshDemoBanner();
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            SetPill(KeyStatusPill, KeyStatusPillText, "✖ error", "PillBad");
            _keys = null;
            SyncEngineIdentity();
        }
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.OtEndpoint;
            OpenKeys_Click(sender, e);

            foreach (ReceiverChoice choice in ReceiverCombo.Items)
            {
                if (choice.Peer.Name == DemoProvisioner.ItEndpoint)
                {
                    ReceiverCombo.SelectedItem = choice;
                    break;
                }
            }

            DemoStripText.Text =
                $"ot fingerprint  {ids.OtFingerprint}\n" +
                $"it fingerprint  {ids.ItFingerprint}\n" +
                "Full security is active — real signatures, encryption and anti-replay. " +
                "Now press ⚡ Demo setup in the Receiver, then Start source here.";
            Log($"Demo keys ready — {DemoProvisioner.OtEndpoint} ⟶ {DemoProvisioner.ItEndpoint}.", "PillOk", "⚡");
            RefreshDemoBanner();
        }
        catch (Exception ex)
        {
            Log($"Demo setup failed: {ex.Message}", "PillBad", "✖");
        }
    }

    // ═══════════════════ source mode ═══════════════════

    private void Mode_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        bool live = LiveModeOption.IsChecked == true;
        LivePanel.Visibility = live ? Visibility.Visible : Visibility.Collapsed;
        ManualPanel.Visibility = live ? Visibility.Collapsed : Visibility.Visible;
        if (!live) _source.Pause();
        RefreshEverything();
    }

    private void BuildTypeToggles()
    {
        foreach (var type in PayloadCatalogue.All)
        {
            var toggle = new ToggleButton
            {
                Style = (Style)FindResource("ChipToggle"),
                Content = type.Name,
                Margin = new Thickness(0, 0, 4, 4),
                IsChecked = _source.Options.EnabledTypes.Contains(type.Name),
                ToolTip = $"{type.Code} · {type.Kind}",
                Tag = type,
            };
            toggle.Checked += TypeToggle_Changed;
            toggle.Unchecked += TypeToggle_Changed;
            TypeTogglePanel.Children.Add(toggle);
        }
    }

    private void TypeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready || sender is not ToggleButton { Tag: PayloadType type } toggle) return;
        if (toggle.IsChecked == true) _source.Options.EnabledTypes.Add(type.Name);
        else _source.Options.EnabledTypes.Remove(type.Name);
    }

    private void Interval_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;

        // The two handles cannot cross: max is clamped up to min.
        double min = Math.Round(MinIntervalSlider.Value);
        double max = Math.Max(min + 1, Math.Round(MaxIntervalSlider.Value));
        _source.Options.MinInterval = TimeSpan.FromSeconds(min);
        _source.Options.MaxInterval = TimeSpan.FromSeconds(max);
        _source.Options.Burstiness = BurstSlider.Value;

        MinIntervalText.Text = $"{min:0} s";
        MaxIntervalText.Text = $"{max:0} s";
        BurstNote.Text = BurstSlider.Value < 0.15
            ? $"Near-metronome — one payload every {min:0}–{max:0} s."
            : $"Bursts of 2–3, then a quiet {min:0}–{max:0} s.";
    }

    private void SourceRun_Click(object sender, RoutedEventArgs e)
    {
        if (_source.IsRunning)
        {
            _source.Pause();
            Log("Source paused. Queued payloads keep transmitting until the queue drains.", "PillWarn", "❙❙");
        }
        else
        {
            if (!_engine.CanTransmit)
            {
                Log("Open your keys and pick a destination first.", "PillBad", "✖");
                return;
            }
            _source.Start();
            // Starting the source is the operator saying "go" — the stage comes with it.
            if (_stage is null) OpenStage();
            Log("Source running — payloads will be queued and transmitted one session at a time.", "PillAccent", "⟶");
        }
        RefreshEverything();
    }

    private void SourceStop_Click(object sender, RoutedEventArgs e)
    {
        _source.Stop();
        Log("Source stopped.", "PillIdle", "■");
        RefreshEverything();
    }

    private void Inject_Click(object sender, RoutedEventArgs e)
    {
        if (LiveModeOption.IsChecked == true)
        {
            var payload = _source.InjectNow();
            if (payload is null)
            {
                Log("No payload types are enabled — nothing to emit.", "PillWarn", "⚠");
                return;
            }
            Log($"Injected {payload.Type.Name} ({payload.Size:N0} B) into the queue.", "PillAccent", "⟶");
        }
        else if (FileBox.Text.Length > 0 && File.Exists(FileBox.Text))
        {
            _engine.EnqueueFile(FileBox.Text);
            Log($"Queued {Path.GetFileName(FileBox.Text)}.", "PillAccent", "⟶");
        }
        else
        {
            Log("Pick a file to send first.", "PillWarn", "⚠");
        }
        RefreshEverything();
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Title = "Select payload to transmit" };
        if (dialog.ShowDialog() != true) return;

        var info = new FileInfo(dialog.FileName);
        if (info.Length == 0)
        {
            SetPill(PayloadPill, PayloadPillText, "✖ empty", "PillBad");
            Log("File is empty — nothing to transmit.", "PillBad", "✖");
            return;
        }
        if (info.Length > 64L * 1024 * 1024)
        {
            SetPill(PayloadPill, PayloadPillText, "✖ too large", "PillBad");
            Log($"That file is {info.Length / (1024.0 * 1024):0.0} MB — beyond the 64 MB design envelope. " +
                "Split it or send a summary.", "PillBad", "✖");
            return;
        }

        FileBox.Text = dialog.FileName;
        var type = PayloadCatalogue.ForFilename(Path.GetFileName(dialog.FileName), DetectKind(dialog.FileName));
        SetPill(PayloadPill, PayloadPillText, $"{type.Code} · {FormatSize(info.Length)}", "PillOutline");
        Log($"Ready — press “Inject one now” to queue {Path.GetFileName(dialog.FileName)}.", "PillAccent", "⟶");
    }

    private static Core.Manifest.ContentKind DetectKind(string path) =>
        Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".xml" => Core.Manifest.ContentKind.Xml,
            ".json" => Core.Manifest.ContentKind.Json,
            _ => Core.Manifest.ContentKind.File,
        };

    private static string FormatSize(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        _ => $"{bytes / (1024.0 * 1024):0.#} MB",
    };

    // ═══════════════════ stage ═══════════════════

    private void Stage_Click(object sender, RoutedEventArgs e)
    {
        if (_stage is null) OpenStage();
        else _stage.Close();
    }

    private void OpenStage()
    {
        if (!_engine.CanTransmit)
        {
            Log("Open your keys and pick a destination before opening the stage.", "PillBad", "✖");
            return;
        }

        _stage = new StageWindow(_engine)
        {
            Owner = this,
            ToggleSource = () => SourceRun_Click(this, new RoutedEventArgs()),
        };
        _stage.Closed += (_, _) =>
        {
            _stage = null;
            _engine.CloseStage();
            RefreshEverything();
        };
        _engine.OpenStage();
        _stage.Show();
        RefreshEverything();
    }

    private void Fps_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        _engine.Fps = FpsSlider.Value;
        FpsText.Text = $"{FpsSlider.Value:0}";
    }

    private void ClearHistory_Click(object sender, RoutedEventArgs e) => _engine.ClearHistory();

    private void CopyReceipt_Click(object sender, RoutedEventArgs e)
    {
        if (_lastReceipt is null) return;
        try { Clipboard.SetText(_lastReceipt); } catch (Exception) { /* clipboard busy — not worth an error */ }
    }

    // ═══════════════════ payload inspector ═══════════════════

    private void Queue_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) RenderDetail(QueueList.SelectedItem as QueueItem);
    }

    private void ViewMode_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) RenderPayload();
    }

    private void RenderDetail(QueueItem? item)
    {
        _selected = item;

        if (item is null)
        {
            DetailNameText.Text = "select a queue row";
            SetPill(DetailStatePill, DetailStateText, "—", "PillIdle");
            DetailMetaText.Text = "Nothing selected — pick a payload above to inspect the bytes that go on air.";
            CopyPayloadButton.IsEnabled = false;
            SavePayloadButton.IsEnabled = false;
            _selectedText = PayloadText.Empty;
            PayloadViewer.Document = PayloadView.Message("Select a payload to read it before it leaves.");
            return;
        }

        DetailNameText.Text = item.Filename;
        CopyPayloadButton.IsEnabled = true;
        SavePayloadButton.IsEnabled = true;
        UpdateDetailMeta();
        RenderPayload();
    }

    /// <summary>
    /// The metadata line ticks with the session — air time and loop count keep moving while a
    /// payload is up, and they are the only evidence of exposure a one-way link can offer.
    /// </summary>
    private void UpdateDetailMeta()
    {
        if (_selected is not { } item) return;

        SetPill(DetailStatePill, DetailStateText, item.StateLabel, item.State switch
        {
            QueueState.OnAir => "PillAccent",
            QueueState.Sent => "PillOk",
            QueueState.Skipped => "PillWarn",
            QueueState.Failed => "PillBad",
            _ => "PillIdle",
        });

        string first =
            $"{item.Size:N0} B · {item.Type.Kind.ToString().ToLowerInvariant()} · sha256 {item.Sha256Short}" +
            (_selectedText.Truncated ? $" · showing the first {PayloadFormatter.DefaultLimit / 1024} KB" : "");

        string second = item.State is QueueState.Queued
            ? "not encoded yet — session id, frame count and receipt appear when it goes on air"
            : $"session {item.SessionShort} · {item.KLabel} · loops {item.LoopLabel} · air {item.AirLabel}" +
              (item.Receipt.Length >= 16 ? $" · receipt {QueueItem.Grouped(item.Receipt[..16])}" : "");

        DetailMetaText.Text = item.Error is { Length: > 0 } error
            ? $"{first}\n{second}\n✖ {error}"
            : $"{first}\n{second}";
    }

    private void RenderPayload()
    {
        if (_selected is not { } item)
        {
            PayloadViewer.Document = PayloadView.Message("Select a payload to read it before it leaves.");
            return;
        }

        _selectedText =
            ViewHex.IsChecked == true ? PayloadFormatter.Hex(item.Bytes) :
            ViewRaw.IsChecked == true ? PayloadFormatter.Raw(item.Type.Kind, item.Bytes) :
            PayloadFormatter.Formatted(item.Type.Kind, item.Bytes);

        PayloadViewer.Document = PayloadView.Build(_selectedText);
        UpdateDetailMeta();
    }

    private void CopyPayload_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedText.Text.Length == 0) return;
        try { Clipboard.SetText(_selectedText.Text); } catch (Exception) { /* clipboard busy */ }
    }

    private void SavePayload_Click(object sender, RoutedEventArgs e)
    {
        if (_selected is not { } item) return;

        var dialog = new SaveFileDialog
        {
            Title = "Save a copy of this payload",
            FileName = item.Filename,
            Filter = "Payload|*.*",
        };
        if (dialog.ShowDialog() != true) return;

        try
        {
            File.WriteAllBytes(dialog.FileName, item.Bytes);
            Log($"Saved a copy of {item.Filename} to {dialog.FileName}.", "PillOk", "✔");
        }
        catch (Exception ex)
        {
            Log($"Could not save the payload: {ex.Message}", "PillBad", "✖");
        }
    }

    // ═══════════════════ live refresh ═══════════════════

    private void OnEngineChanged() => RefreshEverything();

    private void OnSessionEnded(QueueItem item)
    {
        if (item.State != QueueState.Sent) return;
        _lastReceipt = item.Receipt;
        CopyReceiptButton.IsEnabled = true;
        Log($"Session ended · {item.DisplayName} · {item.AirSeconds:0.0} s on air · " +
            $"receipt {QueueItem.Grouped(item.Receipt)} ← compare with the receiver’s screen",
            "PillOk", "✔");
    }

    private void OnSourceTick()
    {
        if (!_ready) return;
        DrawSparkline();
        RateText.Text = $"{_source.PerMinute:0.0}";

        if (_source.UntilNext is { } until)
        {
            SetPill(NextEmissionPill, NextEmissionText, $"next emission in {until.TotalSeconds:00} s", "PillAccent");
        }
        else
        {
            SetPill(NextEmissionPill, NextEmissionText,
                LiveModeOption.IsChecked == true ? "source paused" : "manual mode", "PillIdle");
        }

        // The stage drives the session clock, so the dashboard's live columns tick from here too.
        if (_engine.Current is { } current)
        {
            SessionCounterText.Text = $"session {current.SessionId:N}"[..15] + "…";
        }
        UpdateDetailMeta();
        RefreshQueueChrome();
    }

    /// <summary>Keeps the inspector on whatever is currently on air, unless the operator opted out.</summary>
    private void FollowOnAir()
    {
        if (FollowToggle.IsChecked != true) return;
        if (_engine.Current is not { } current || current.SessionId == _followedSession) return;

        _followedSession = current.SessionId;
        QueueList.SelectedItem = current;
    }

    private void RefreshEverything()
    {
        if (!_ready) return;

        bool haveKeys = _keys is not null;
        bool haveDest = ReceiverCombo.SelectedItem is not null;
        bool live = LiveModeOption.IsChecked == true;

        SetBadge(Step1Badge, haveKeys);
        SetBadge(Step2Badge, haveDest);
        SetBadge(Step3Badge, _source.IsRunning || _engine.Queue.Count > 0);
        SetBadge(Step4Badge, _engine.SentCount > 0);

        StageButton.IsEnabled = _engine.CanTransmit;
        StageButton.Content = _stage is null ? "Open QR stage" : "Close QR stage";

        SourceRunButton.Content = _source.IsRunning ? "❙❙ Pause source" : "● Start source";
        SourceRunButton.Style = (Style)FindResource(_source.IsRunning ? "ChipButtonOn" : "ChipButton");
        SourceRunButton.IsEnabled = live && _engine.CanTransmit;
        SourceStopButton.IsEnabled = _source.IsRunning;
        InjectButton.IsEnabled = _engine.CanTransmit;

        // Identity and destination lock while the source runs — the counter and manifests are
        // already committed to this pair.
        bool locked = _source.IsRunning || _engine.State is StageState.OnAir or StageState.Encoding;
        EndpointNameBox.IsEnabled = !locked;
        ReceiverCombo.IsEnabled = !locked;
        LiveModeOption.IsEnabled = !locked;
        ManualModeOption.IsEnabled = !locked;
        string lockHint = locked ? "Stop the source to change." : null!;
        EndpointNameBox.ToolTip = lockHint ?? "Name of this machine's key pair in Windows CNG";
        ReceiverCombo.ToolTip = lockHint;

        FollowOnAir();
        RefreshQueueChrome();
    }

    private void RefreshQueueChrome()
    {
        if (!_ready) return;
        QueueTallyText.Text =
            $"{_engine.QueuedCount} queued · {_engine.SentCount} sent" +
            (_engine.SkippedCount > 0 ? $" · {_engine.SkippedCount} skipped" : "");
        QueueEmpty.Visibility = _engine.Queue.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    /// <summary>Sparkline of emissions per bucket — plain Rectangles, redrawn on the source tick.</summary>
    private void DrawSparkline()
    {
        var hist = _source.Histogram;
        double width = Math.Max(60, Sparkline.ActualWidth);
        double slot = width / hist.Count;
        double barWidth = Math.Max(3, slot - 2);
        int peak = Math.Max(3, hist.Max());

        if (Sparkline.Children.Count != hist.Count)
        {
            Sparkline.Children.Clear();
            for (int i = 0; i < hist.Count; i++)
                Sparkline.Children.Add(new Rectangle { RadiusX = 1, RadiusY = 1 });
        }

        var idle = (Brush)FindResource("FieldBrush");
        var low = (Brush)FindResource("Accent600Brush");
        var high = (Brush)FindResource("Accent400Brush");

        for (int i = 0; i < hist.Count; i++)
        {
            var bar = (Rectangle)Sparkline.Children[i];
            double h = 4 + 42.0 * hist[i] / peak;
            bar.Width = barWidth;
            bar.Height = h;
            bar.Fill = hist[i] == 0 ? idle : hist[i] > peak / 2.0 ? high : low;
            Canvas.SetLeft(bar, i * slot);
            Canvas.SetTop(bar, 46 - h);
        }
    }

    // ═══════════════════ small helpers ═══════════════════

    private void Log(string message, string pillStyle, string glyph)
    {
        LogText.Text = message;
        SetPill(LogPill, LogPillText, glyph, pillStyle);
    }

    private void SetPill(Border pill, TextBlock text, string label, string styleKey)
    {
        text.Text = label;
        pill.Style = (Style)FindResource(styleKey);
    }

    private void SetBadge(Border badge, bool satisfied) =>
        badge.Background = (Brush)FindResource(satisfied ? "SuccessBrush" : "Accent500Brush");

    protected override void OnClosed(EventArgs e)
    {
        _source.Stop();
        _stage?.Close();
        _engine.Dispose();
        _keys?.Dispose();
        _trust?.Dispose();
        base.OnClosed(e);
    }
}
