using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Core.Simulation;
using QrDiode.Sender.Rendering;

namespace QrDiode.Sender.Transmit;

public enum StageState
{
    /// <summary>Stage open, nothing to send — the queue is empty or the source is paused.</summary>
    Idle,
    Encoding,
    OnAir,
    /// <summary>Deliberate silence between sessions so the receiver can finalize the last one.</summary>
    Gap,
    Stopped,
}

/// <summary>
/// Drains the payload queue one session at a time and paces the QR carousel.
///
/// There is no acknowledgement, so a session cannot end when the receiver is done — it ends when
/// it has had enough air time. The policy is "loop N× K frames <b>or</b> ≥ T seconds, whichever is
/// longer", then a fixed gap before the next manifest appears. Everything runs on the UI thread
/// except <see cref="SendSession.Create"/>, which is CPU-bound and goes to the thread pool.
/// </summary>
public sealed class TransmitEngine : IDisposable
{
    /// <summary>Queued payloads beyond this depth are dropped oldest-first, and said so.</summary>
    public const int MaxQueueDepth = 14;

    private readonly AuditLog _audit;
    private readonly CounterStore _counters = new(QrDiodePaths.CounterFile);
    private readonly Stopwatch _clock = Stopwatch.StartNew();

    private double _nextFrameDue;
    private double _sessionStart;
    private double _gapUntil;
    private long _framesShown;
    private long _framesPerLoop;
    private bool _encodeInFlight;

    public ObservableCollection<QueueItem> Queue { get; } = [];

    public IEndpointKeys? Keys { get; set; }
    public PeerPublicKeys? Receiver { get; set; }

    public double Fps { get; set; } = 15;
    public int LoopTarget { get; set; } = 3;
    public double MinAirSeconds { get; set; } = 6;
    public double GapSeconds { get; set; } = 1.5;

    public StageState State { get; private set; } = StageState.Stopped;
    public QueueItem? Current { get; private set; }
    public SendSession? Session { get; private set; }
    public CarouselPump? Pump { get; private set; }
    /// <summary>Bumped whenever <see cref="Pump"/> is replaced, so the stage knows to re-create its bitmap.</summary>
    public int SessionEpoch { get; private set; }

    public long FramesShown => _framesShown;
    public double ActualFps { get; private set; }
    public int SentCount { get; private set; }
    public int SkippedCount { get; private set; }

    public double AirSeconds =>
        State is StageState.OnAir ? _clock.Elapsed.TotalSeconds - _sessionStart : 0;
    public double GapRemaining =>
        State is StageState.Gap ? Math.Max(0, _gapUntil - _clock.Elapsed.TotalSeconds) : 0;
    public int QueuedCount => Queue.Count(q => q.State == QueueState.Queued);

    /// <summary>Raised whenever the dashboard's picture of the queue or session changed.</summary>
    public event Action? Changed;
    public event Action<QueueItem>? SessionEnded;

    public TransmitEngine(AuditLog audit) => _audit = audit;

    public bool CanTransmit => Keys is not null && Receiver is not null;

    // ═══════════════════ queue ═══════════════════

    public QueueItem Enqueue(PayloadType type, string filename, byte[] bytes)
    {
        var item = new QueueItem
        {
            Type = type,
            Filename = filename,
            Bytes = bytes,
            QueuedAt = DateTime.Now,
            LoopTarget = LoopTarget,
        };
        Queue.Insert(0, item);
        TrimQueue();
        Changed?.Invoke();
        return item;
    }

    public QueueItem Enqueue(GeneratedPayload payload) =>
        Enqueue(payload.Type, payload.Filename, payload.Bytes);

    /// <summary>
    /// Manual sends join the same queue and obey the same air-time policy, so the receiver cannot
    /// tell the two modes apart — one code path, one set of guarantees.
    /// </summary>
    public QueueItem EnqueueFile(string path)
    {
        byte[] bytes = File.ReadAllBytes(path);
        string name = Path.GetFileName(path);
        var kind = Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".xml" => ContentKind.Xml,
            ".json" => ContentKind.Json,
            _ => ContentKind.File,
        };
        var type = PayloadCatalogue.ForFilename(name, kind) with { Name = name };
        return Enqueue(type, name, bytes);
    }

    /// <summary>Oldest waiting payloads fall off the back rather than the queue growing without bound.</summary>
    private void TrimQueue()
    {
        var waiting = Queue.Where(q => q.State == QueueState.Queued).ToList();
        for (int i = MaxQueueDepth; i < waiting.Count; i++)
        {
            waiting[i].State = QueueState.Skipped;
            waiting[i].Error = "Air-time budget exhausted — the source outran the stage.";
            SkippedCount++;
        }

        // Keep the visible history bounded; the audit log is the permanent record. Only settled
        // rows are dropped — the oldest row is usually the one about to go on air.
        for (int i = Queue.Count - 1; i >= 0 && Queue.Count > 60; i--)
            if (Queue[i].State is QueueState.Sent or QueueState.Skipped or QueueState.Failed)
                Queue.RemoveAt(i);
    }

    public void ClearHistory()
    {
        for (int i = Queue.Count - 1; i >= 0; i--)
            if (Queue[i].State is QueueState.Sent or QueueState.Skipped or QueueState.Failed)
                Queue.RemoveAt(i);
        Changed?.Invoke();
    }

    // ═══════════════════ stage lifecycle ═══════════════════

    public void OpenStage()
    {
        if (State == StageState.Stopped) State = StageState.Idle;
        _clock.Restart();
        _nextFrameDue = 0;
        Changed?.Invoke();
    }

    public void CloseStage()
    {
        EndSession(QueueState.Skipped, "Stage closed before the air-time budget was met.");
        State = StageState.Stopped;
        Changed?.Invoke();
    }

    // ═══════════════════ frame pump ═══════════════════

    /// <summary>
    /// Called once per composition tick by the stage window. Advances the state machine and returns
    /// the next pixel buffer to blit, or null to hold the current frame.
    /// </summary>
    public byte[]? Advance()
    {
        double now = _clock.Elapsed.TotalSeconds;

        switch (State)
        {
            case StageState.Stopped:
                return null;

            case StageState.Gap:
                if (now < _gapUntil) return null;
                State = StageState.Idle;
                Changed?.Invoke();
                goto case StageState.Idle;

            case StageState.Idle:
                TryStartNext();
                return null;

            case StageState.Encoding:
                return null;

            case StageState.OnAir:
                return PumpFrame(now);
        }
        return null;
    }

    private byte[]? PumpFrame(double now)
    {
        if (Current is null || Session is null || Pump is null) return null;

        double air = now - _sessionStart;
        Current.AirSeconds = air;
        if (_framesPerLoop > 0)
            Current.LoopsDone = (int)Math.Min(Current.LoopTarget, _framesShown / _framesPerLoop);

        // Both conditions, not either: the loop count proves coverage of every source symbol,
        // the seconds floor protects tiny payloads whose K is a handful of frames.
        bool loopsDone = _framesPerLoop > 0 && _framesShown >= _framesPerLoop * Current.LoopTarget;
        if (loopsDone && air >= MinAirSeconds)
        {
            EndSession(QueueState.Sent, null);
            return null;
        }

        if (now < _nextFrameDue) return null;
        var buffer = Pump.TryTake();
        if (buffer is null) return null; // producer briefly behind — hold the current frame

        _nextFrameDue = now + 1.0 / Math.Clamp(Fps, 1, 60);
        _framesShown++;
        ActualFps = _framesShown / Math.Max(air, 0.001);
        return buffer;
    }

    public void Recycle(byte[] buffer) => Pump?.Recycle(buffer);

    // ═══════════════════ sessions ═══════════════════

    private void TryStartNext()
    {
        if (_encodeInFlight || !CanTransmit) return;

        var next = Queue.LastOrDefault(q => q.State == QueueState.Queued);
        if (next is null) return;

        _encodeInFlight = true;
        next.State = QueueState.Encoding;
        State = StageState.Encoding;
        Changed?.Invoke();
        _ = EncodeAndAirAsync(next);
    }

    private async Task EncodeAndAirAsync(QueueItem item)
    {
        try
        {
            var keys = Keys!;
            var peer = Receiver!;
            byte[] bytes = item.Bytes;
            string filename = item.Filename;
            ContentKind kind = item.Type.Kind;

            // The counter is reserved and durably flushed BEFORE the session exists, so a crash
            // can never hand the same value to two sessions.
            ulong counter = _counters.Next();
            var session = await Task.Run(() =>
                SendSession.Create(bytes, filename, kind, keys, peer, counter));

            // The stage may have been closed while we were encoding.
            if (State is StageState.Stopped)
            {
                item.State = QueueState.Skipped;
                item.Error = "Stage closed during encode.";
                SkippedCount++;
                return;
            }

            Pump?.Dispose();
            Pump = new CarouselPump(session);
            Session = session;
            Current = item;
            SessionEpoch++;

            item.SessionId = session.Manifest.SessionId;
            item.K = session.K;
            item.Receipt = session.ReceiptHash;
            item.State = QueueState.OnAir;

            _framesShown = 0;
            _framesPerLoop = (long)session.K * session.Options.Redundancy;
            _sessionStart = _clock.Elapsed.TotalSeconds;
            _nextFrameDue = 0;
            ActualFps = 0;
            State = StageState.OnAir;

            _audit.Append("send.started", new Dictionary<string, string>
            {
                ["session"] = session.Manifest.SessionId.ToString(),
                ["counter"] = counter.ToString(),
                ["file"] = filename,
                ["size"] = session.Manifest.OriginalSize.ToString(),
                ["receiver"] = peer.Name,
                ["receipt"] = session.ReceiptHash,
            });
        }
        catch (Exception ex)
        {
            item.State = QueueState.Failed;
            item.Error = ex.Message;
            State = StageState.Idle;
        }
        finally
        {
            _encodeInFlight = false;
            Changed?.Invoke();
        }
    }

    private void EndSession(QueueState outcome, string? error)
    {
        var item = Current;
        var session = Session;
        Pump?.Dispose();
        Pump = null;
        Session = null;
        Current = null;

        if (item is not null && item.State == QueueState.OnAir)
        {
            item.AirSeconds = _clock.Elapsed.TotalSeconds - _sessionStart;
            item.State = outcome;
            item.Error = error;
            if (outcome == QueueState.Sent) SentCount++; else SkippedCount++;

            if (session is not null)
                _audit.Append("send.stopped", new Dictionary<string, string>
                {
                    ["session"] = session.Manifest.SessionId.ToString(),
                    ["framesShown"] = _framesShown.ToString(),
                    ["airSeconds"] = item.AirSeconds.ToString("0.0"),
                    ["outcome"] = outcome.ToString(),
                    ["receipt"] = session.ReceiptHash,
                });

            SessionEnded?.Invoke(item);
        }

        if (State != StageState.Stopped)
        {
            _gapUntil = _clock.Elapsed.TotalSeconds + GapSeconds;
            State = StageState.Gap;
        }
        Changed?.Invoke();
    }

    /// <summary>Cuts the current session short; the queue keeps draining from the next one.</summary>
    public void SkipCurrent()
    {
        if (State == StageState.OnAir) EndSession(QueueState.Skipped, "Skipped by the operator.");
    }

    public void Dispose()
    {
        Pump?.Dispose();
        Pump = null;
    }
}
