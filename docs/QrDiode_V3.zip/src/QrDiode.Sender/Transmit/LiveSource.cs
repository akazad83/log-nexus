using System.Windows.Threading;
using QrDiode.Core.Simulation;

namespace QrDiode.Sender.Transmit;

/// <summary>
/// The plant-side event source. It does not tick like a metronome: it sleeps for a quiet interval
/// sampled from the operator's range, then sometimes drags one or two more emissions in behind it
/// within a second or two. Everything is adjustable while it runs.
/// </summary>
public sealed class LiveSource
{
    /// <summary>Seconds covered by one sparkline bar.</summary>
    private const double BucketSeconds = 2;
    private const int Buckets = 30;

    private readonly DispatcherTimer _timer;
    private readonly int[] _histogram = new int[Buckets];
    private DateTime _nextEmission = DateTime.MaxValue;
    private DateTime _bucketStart = DateTime.Now;

    public PayloadSimulator Simulator { get; }
    public SimulatorOptions Options => Simulator.Options;
    public bool IsRunning { get; private set; }

    public event Action<GeneratedPayload>? Emitted;
    /// <summary>Raised on every tick so the dashboard can redraw the countdown and sparkline.</summary>
    public event Action? Tick;

    public LiveSource()
    {
        Simulator = new PayloadSimulator();
        _timer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(200) };
        _timer.Tick += OnTick;
        _timer.Start();
    }

    /// <summary>Time until the next emission, or null while the source is paused.</summary>
    public TimeSpan? UntilNext =>
        IsRunning && _nextEmission != DateTime.MaxValue
            ? TimeSpan.FromSeconds(Math.Max(0, (_nextEmission - DateTime.Now).TotalSeconds))
            : null;

    /// <summary>Emissions per minute over the trailing 60 s window.</summary>
    public double PerMinute => _histogram.Sum() * (60.0 / (Buckets * BucketSeconds));

    public IReadOnlyList<int> Histogram => _histogram;

    public void Start()
    {
        IsRunning = true;
        ScheduleNext();
    }

    public void Pause()
    {
        IsRunning = false;
        _nextEmission = DateTime.MaxValue;
    }

    public void Stop()
    {
        Pause();
        Array.Clear(_histogram);
    }

    /// <summary>Operator override — emit right now without disturbing the schedule.</summary>
    public GeneratedPayload? InjectNow(PayloadType? type = null)
    {
        var payload = Simulator.Generate(type);
        if (payload is not null) Record(payload);
        return payload;
    }

    private void ScheduleNext() => _nextEmission = DateTime.Now + Simulator.NextDelay();

    private void OnTick(object? sender, EventArgs e)
    {
        RollBuckets();

        if (IsRunning && DateTime.Now >= _nextEmission)
        {
            var payload = Simulator.Generate();
            if (payload is not null) Record(payload);
            ScheduleNext();
        }

        Tick?.Invoke();
    }

    private void Record(GeneratedPayload payload)
    {
        _histogram[^1]++;
        Emitted?.Invoke(payload);
    }

    private void RollBuckets()
    {
        var now = DateTime.Now;
        while ((now - _bucketStart).TotalSeconds >= BucketSeconds)
        {
            Array.Copy(_histogram, 1, _histogram, 0, Buckets - 1);
            _histogram[^1] = 0;
            _bucketStart = _bucketStart.AddSeconds(BucketSeconds);
        }
    }
}
