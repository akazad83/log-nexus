using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using QrDiode.Core.Presentation;
using QrDiode.Core.Simulation;

namespace QrDiode.Sender.Transmit;

public enum QueueState
{
    Queued,
    Encoding,
    OnAir,
    Sent,
    /// <summary>The source outran the air time available — this payload never went out.</summary>
    Skipped,
    Failed,
}

/// <summary>
/// One payload's whole life on the sender. Air time and loop count are columns rather than
/// tooltips because, with no acknowledgement, exposure is the only evidence a payload got out.
/// </summary>
public sealed class QueueItem : INotifyPropertyChanged
{
    private QueueState _state = QueueState.Queued;
    private int _loopsDone;
    private double _airSeconds;
    private string _receipt = "";
    private string? _error;
    private string? _snippet;
    private string? _sha256;

    public required PayloadType Type { get; init; }
    public required string Filename { get; init; }
    public required byte[] Bytes { get; init; }
    public required DateTime QueuedAt { get; init; }
    public int LoopTarget { get; set; } = 3;
    public Guid SessionId { get; set; }
    public int K { get; set; }

    public string DisplayName => Type.Name;
    public int Size => Bytes.Length;

    /// <summary>
    /// The payload itself, flattened to one line. Computed once and cached: the queue is the only
    /// place an OT operator can see what is actually leaving the plant, and a name plus a byte
    /// count is not that.
    /// </summary>
    public string Snippet => _snippet ??= PayloadFormatter.Snippet(Type.Kind, Bytes);

    /// <summary>Hash of the plaintext — the value the receiver prints back after decrypting.</summary>
    public string Sha256 => _sha256 ??= Convert.ToHexString(SHA256.HashData(Bytes));

    public string Sha256Short => $"{Sha256[..4]}…{Sha256[^4..]}";
    public string TimeLabel => QueuedAt.ToString("HH:mm:ss");
    public string SessionShort => SessionId == Guid.Empty ? "—" : SessionId.ToString("N")[..8] + "…";
    public string KLabel => K > 0 ? $"{K} frames/loop" : "not encoded yet";

    public QueueState State
    {
        get => _state;
        set { if (_state != value) { _state = value; Raise(); Raise(nameof(StateLabel)); } }
    }

    public int LoopsDone
    {
        get => _loopsDone;
        set { if (_loopsDone != value) { _loopsDone = value; Raise(); Raise(nameof(LoopLabel)); } }
    }

    public double AirSeconds
    {
        get => _airSeconds;
        set { if (Math.Abs(_airSeconds - value) > 0.05) { _airSeconds = value; Raise(); Raise(nameof(AirLabel)); } }
    }

    public string Receipt
    {
        get => _receipt;
        set { if (_receipt != value) { _receipt = value; Raise(); Raise(nameof(ReceiptShort)); } }
    }

    public string? Error
    {
        get => _error;
        set { if (_error != value) { _error = value; Raise(); } }
    }

    public string StateLabel => State switch
    {
        QueueState.Queued => "queued",
        QueueState.Encoding => "encoding",
        QueueState.OnAir => "ON AIR",
        QueueState.Sent => "sent",
        QueueState.Skipped => "skipped",
        _ => "failed",
    };

    public string LoopLabel => State is QueueState.OnAir or QueueState.Sent ? $"{LoopsDone}/{LoopTarget}" : "—";
    public string AirLabel => AirSeconds > 0 ? $"{AirSeconds:0.0} s" : "—";

    /// <summary>The first two groups of the receipt — enough to read aloud and compare.</summary>
    public string ReceiptShort => Receipt.Length >= 16 ? Grouped(Receipt[..16]) : "—";

    public string SizeLabel => Size switch
    {
        < 1024 => $"{Size} B",
        < 1024 * 1024 => $"{Size / 1024.0:0.#} KB",
        _ => $"{Size / (1024.0 * 1024):0.#} MB",
    };

    /// <summary>Long hex is always grouped in fours — it exists to be spoken.</summary>
    public static string Grouped(string hex) =>
        string.Join(' ', Enumerable.Range(0, (hex.Length + 3) / 4)
            .Select(i => hex.Substring(i * 4, Math.Min(4, hex.Length - i * 4))));

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Raise([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
