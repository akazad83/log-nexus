using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using QrDiode.Sender.Transmit;

namespace QrDiode.Sender;

/// <summary>
/// The transmission surface: a picture frame around the QR and nothing more.
///
/// The window is deliberately ordinary — resizable, movable, never maximized, optionally on top —
/// because the operator sizes it to the camera's field of view. The QR keeps a pure white ground,
/// pure black modules, an integer module scale and its quiet zone at every size; all chrome lives
/// outside the white plate and the leftover pixels of the integer scale become extra white margin,
/// so the quiet zone only ever grows.
/// </summary>
public partial class StageWindow : Window
{
    private readonly TransmitEngine _engine;
    private WriteableBitmap? _bitmap;
    private int _bitmapEpoch = -1;
    private int _dim;
    private int _scale = 1;
    private double _hostWidth, _hostHeight;
    private readonly System.Diagnostics.Stopwatch _chrome = System.Diagnostics.Stopwatch.StartNew();
    private double _lastChrome = -1;

    /// <summary>Space asks the dashboard to pause or resume the source — the stage does not own it.</summary>
    public Action? ToggleSource { get; set; }

    public StageWindow(TransmitEngine engine)
    {
        InitializeComponent();
        _engine = engine;
        Loaded += OnLoaded;
        Closed += OnClosedInternal;
    }

    private void OnLoaded(object? sender, RoutedEventArgs e)
    {
        KeepDisplayAwake(true);
        CompositionTarget.Rendering += OnRendering;
    }

    // ═══════════════════ frame loop ═══════════════════

    private void OnRendering(object? sender, EventArgs e)
    {
        var buffer = _engine.Advance();
        if (buffer is not null)
        {
            EnsureBitmap();
            if (_bitmap is not null)
            {
                _bitmap.WritePixels(new Int32Rect(0, 0, _dim, _dim), buffer, _dim, 0);
                QrImage.Opacity = 1;
            }
            _engine.Recycle(buffer);
        }

        // The chrome ticks at ~12 Hz, not at the frame rate: it shares this thread with the
        // blit, and nothing outside the QR needs to move that fast.
        double now = _chrome.Elapsed.TotalSeconds;
        if (now - _lastChrome < 0.08) return;
        _lastChrome = now;
        RefreshChrome();
    }

    /// <summary>A new session usually means a new QR version, so the bitmap is rebuilt.</summary>
    private void EnsureBitmap()
    {
        var pump = _engine.Pump;
        if (pump is null) return;
        if (_bitmapEpoch == _engine.SessionEpoch && _bitmap is not null) return;

        _bitmapEpoch = _engine.SessionEpoch;
        _dim = pump.Renderer.PixelSize;
        _bitmap = new WriteableBitmap(_dim, _dim, 96, 96, PixelFormats.Gray8, null);
        QrImage.Source = _bitmap;
        ApplyIntegerScale();
    }

    // ═══════════════════ integer scale + size readout ═══════════════════

    private void QrHost_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        var host = (Border)sender;
        _hostWidth = Math.Max(0, e.NewSize.Width - host.Padding.Left - host.Padding.Right);
        _hostHeight = Math.Max(0, e.NewSize.Height - host.Padding.Top - host.Padding.Bottom);
        ApplyIntegerScale();
    }

    private void ApplyIntegerScale()
    {
        if (_dim <= 0 || _hostWidth <= 0 || _hostHeight <= 0) return;

        // floor(), never round: a fractional module scale is what turns crisp modules into grey mush.
        _scale = Math.Max(1, (int)Math.Floor(Math.Min(_hostWidth, _hostHeight) / _dim));
        QrImage.Width = _dim * _scale;
        QrImage.Height = _dim * _scale;
        UpdateSizeReadout();
    }

    /// <summary>Device pixels per module — what the camera actually sees, not layout units.</summary>
    private double DevicePixelsPerModule
    {
        get
        {
            double dpiScale = PresentationSource.FromVisual(this)?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;
            return _scale * dpiScale;
        }
    }

    private void UpdateSizeReadout()
    {
        if (_dim <= 0)
        {
            SizeReadout.Text = $"{ActualWidth:0}×{ActualHeight:0} · waiting for a payload";
            SetPill(CameraHintPill, CameraHintText, "no code on air", "PillIdle");
            return;
        }

        double perModule = DevicePixelsPerModule;
        int version = _engine.Pump?.Renderer.Version ?? 0;
        SizeReadout.Text = $"{ActualWidth:0}×{ActualHeight:0} · {perModule:0.#} px/module · QR v{version}";

        // Colour is never the only signal: the words carry it.
        if (perModule >= 4)
            SetPill(CameraHintPill, CameraHintText, "✔ good for 30–50 cm", "PillOk");
        else if (perModule >= 2)
            SetPill(CameraHintPill, CameraHintText, $"⚠ {perModule:0.#} px/module — move camera closer", "PillWarn");
        else
            SetPill(CameraHintPill, CameraHintText, $"✖ {perModule:0.#} px/module — will not decode", "PillBad");
    }

    // ═══════════════════ chrome ═══════════════════

    private void RefreshChrome()
    {
        var item = _engine.Current;

        switch (_engine.State)
        {
            case StageState.OnAir when item is not null:
                SetPill(AirPill, AirWord, "TRANSMITTING", "PillAccent");
                AirDot.Fill = (Brush)FindResource("Accent400Brush");
                Pulse(true);
                StandbyPlate.Visibility = Visibility.Collapsed;
                QrImage.Opacity = 1;
                TypeTile.Background = HexBrush(item.Type.TileBackground);
                TypeCode.Text = item.Type.Code;
                TypeCode.Foreground = HexBrush(item.Type.TileForeground);
                PayloadName.Text = item.DisplayName;
                PayloadSize.Text = item.SizeLabel;
                ReceiptText.Text = item.ReceiptShort;
                ReceiptText.Foreground = (Brush)FindResource("SuccessTextBrush");

                double loopProgress = item.LoopTarget > 0
                    ? Math.Clamp((double)item.LoopsDone / item.LoopTarget, 0, 1) : 0;
                LoopProgress.Value = loopProgress;
                TelemetryText.Text =
                    $"QR v{_engine.Pump?.Renderer.Version} · {_engine.Fps:0} fps ({_engine.ActualFps:0.0} actual) · " +
                    $"frame {_engine.FramesShown} · loop {item.LoopsDone}/{item.LoopTarget} · K={item.K}";
                NextText.Text = NextLabel();
                break;

            case StageState.Encoding:
                SetPill(AirPill, AirWord, "ENCODING", "PillOutline");
                AirDot.Fill = (Brush)FindResource("Accent400Brush");
                Pulse(true);
                ShowStandby("encoding", "hash → compress → encrypt → sign → fountain-encode");
                TelemetryText.Text = "preparing the next session — the white ground is held for the camera";
                NextText.Text = NextLabel();
                break;

            case StageState.Gap:
                SetPill(AirPill, AirWord, "STANDING BY", "PillWarn");
                AirDot.Fill = (Brush)FindResource("WarningBrush");
                Pulse(false);
                ShowStandby("standing by", $"next payload in {_engine.GapRemaining:0.0} s");
                TelemetryText.Text = $"between sessions · holding the white reference · gap {_engine.GapSeconds:0.#} s";
                NextText.Text = NextLabel();
                break;

            default:
                SetPill(AirPill, AirWord, _engine.QueuedCount > 0 ? "STANDING BY" : "IDLE", "PillIdle");
                AirDot.Fill = (Brush)FindResource("Neutral500Brush");
                Pulse(false);
                ShowStandby(_engine.QueuedCount > 0 ? "standing by" : "idle",
                    _engine.QueuedCount > 0
                        ? $"{_engine.QueuedCount} payload(s) waiting"
                        : "start the source, or inject one payload");
                TelemetryText.Text = "stage open · no payload on air · the QR ground stays white";
                NextText.Text = NextLabel();
                break;
        }
    }

    private string NextLabel()
    {
        int queued = _engine.QueuedCount;
        if (_engine.State == StageState.Gap) return $"next in {_engine.GapRemaining:0.0} s · {queued} queued";
        return queued > 0 ? $"{queued} queued" : "queue empty";
    }

    private void ShowStandby(string title, string sub)
    {
        StandbyPlate.Visibility = Visibility.Visible;
        StandbyTitle.Text = title;
        StandbySub.Text = sub;
        // The last frame is held at 35 % rather than cleared: the camera keeps a stable exposure
        // reference and the operator can see the gap is intentional, not a stall.
        if (_bitmap is not null) QrImage.Opacity = 0.35;
        ReceiptText.Foreground = (Brush)FindResource("MutedBrush");
        LoopProgress.Value = 0;
    }

    private bool _pulsing;
    private System.Windows.Media.Animation.Storyboard? _blink;

    private void Pulse(bool on)
    {
        if (on == _pulsing) return;
        _pulsing = on;
        _blink ??= (System.Windows.Media.Animation.Storyboard)FindResource("OnAirBlink");
        if (on)
        {
            _blink.Begin(AirDot, true);
        }
        else
        {
            _blink.Remove(AirDot);
            AirDot.Opacity = 1;
        }
    }

    // ═══════════════════ size presets and keys ═══════════════════

    private void Preset_Click(object sender, RoutedEventArgs e)
    {
        string tag = (string)((Button)sender).Tag;
        ApplyPreset(tag);
    }

    private void ApplyPreset(string tag)
    {
        var work = SystemParameters.WorkArea;
        switch (tag)
        {
            case "S": Width = 420; Height = 470; break;
            case "M": Width = 700; Height = 760; break;
            case "L": Width = 900; Height = Math.Min(980, work.Height - 40); break;
            case "F": // fit height without ever maximizing
                Height = work.Height - 40;
                Width = Math.Min(work.Width - 40, Height - 60);
                Top = work.Top + 20;
                break;
        }
        foreach (var (button, key) in new[] { (PresetS, "S"), (PresetM, "M"), (PresetL, "L"), (PresetFit, "F") })
            button.Style = (Style)FindResource(key == tag ? "ChipButtonOn" : "ChipButton");
    }

    private void Topmost_Changed(object sender, RoutedEventArgs e) => Topmost = TopmostToggle.IsChecked == true;

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
        switch (e.Key)
        {
            case Key.Escape:
                Close();
                break;
            case Key.Up:
                _engine.Fps = Math.Min(30, _engine.Fps + 1);
                break;
            case Key.Down:
                _engine.Fps = Math.Max(5, _engine.Fps - 1);
                break;
            case Key.OemPlus or Key.Add:
                ApplyPreset(Width < 600 ? "M" : "L");
                break;
            case Key.OemMinus or Key.Subtract:
                ApplyPreset(Width > 800 ? "M" : "S");
                break;
            case Key.T when ctrl:
                TopmostToggle.IsChecked = TopmostToggle.IsChecked != true;
                break;
            case Key.K when ctrl:
                _engine.SkipCurrent();
                break;
            case Key.C when ctrl:
                if (_engine.Current is { Receipt.Length: > 0 } item)
                    try { Clipboard.SetText(item.Receipt); } catch (Exception) { /* clipboard busy */ }
                break;
            case Key.Space:
                ToggleSource?.Invoke();
                break;
        }
    }

    // ═══════════════════ helpers ═══════════════════

    private static readonly HexBrushConverter Hex = new();
    private static Brush HexBrush(string hex) => (Brush)Hex.Convert(hex, typeof(Brush), null, null!);

    private void SetPill(Border pill, TextBlock text, string label, string styleKey)
    {
        text.Text = label;
        pill.Style = (Style)FindResource(styleKey);
    }

    private void OnClosedInternal(object? sender, EventArgs e)
    {
        CompositionTarget.Rendering -= OnRendering;
        KeepDisplayAwake(false);
    }

    private static void KeepDisplayAwake(bool on)
    {
        const uint ES_CONTINUOUS = 0x80000000;
        const uint ES_DISPLAY_REQUIRED = 0x00000002;
        const uint ES_SYSTEM_REQUIRED = 0x00000001;
        SetThreadExecutionState(on ? ES_CONTINUOUS | ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED : ES_CONTINUOUS);
    }

    [DllImport("kernel32.dll")]
    private static extern uint SetThreadExecutionState(uint esFlags);
}
