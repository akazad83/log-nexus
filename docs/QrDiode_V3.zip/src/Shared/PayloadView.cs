using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using QrDiode.Core.Presentation;

namespace QrDiode.Ui;

/// <summary>
/// Syntax colouring for the payload viewers. Compiled into both apps (linked source, one copy of
/// the rules) so a payload looks identical on the OT screen before it is sent and on the IT screen
/// after it arrives — the two windows are meant to be compared side by side.
///
/// Hues are four widely separated ones so they survive the common colour-vision deficiencies, and
/// punctuation stays deliberately dim so structure recedes behind content.
/// </summary>
public static partial class PayloadView
{
    private static readonly Brush KeyBrush = Frozen("#FFD2CEFD");
    private static readonly Brush StringBrush = Frozen("#FF8FD4E4");
    private static readonly Brush NumberBrush = Frozen("#FFE9C46A");
    private static readonly Brush LiteralBrush = Frozen("#FF86D6A4");
    private static readonly Brush PunctBrush = Frozen("#FF6E7285");
    private static readonly Brush PlainBrush = Frozen("#FFCFD3E5");
    private static readonly Brush CommentBrush = Frozen("#FF6E7285");
    private static readonly FontFamily Mono = new("Consolas, Cascadia Mono");

    /// <summary>Builds the viewer document for a rendered payload.</summary>
    public static FlowDocument Build(PayloadText payload)
    {
        var document = NewDocument();
        var paragraph = new Paragraph { Margin = new Thickness(0), LineHeight = 17 };
        paragraph.Inlines.AddRange(Highlight(payload.Text, payload.Kind));
        document.Blocks.Add(paragraph);
        return document;
    }

    /// <summary>A dim one-line document — "nothing selected", "no payload", and friends.</summary>
    public static FlowDocument Message(string message)
    {
        var document = NewDocument();
        document.Blocks.Add(new Paragraph(new Run(message))
        {
            Foreground = PunctBrush,
            Margin = new Thickness(0),
        });
        return document;
    }

    private static FlowDocument NewDocument() => new()
    {
        PageWidth = 2400,
        FontFamily = Mono,
        FontSize = 11.5,
        PagePadding = new Thickness(0),
    };

    public static IEnumerable<Inline> Highlight(string text, PayloadTextKind kind) => kind switch
    {
        PayloadTextKind.Json => Tokenize(text, JsonTokens(), JsonBrush),
        PayloadTextKind.Xml => Tokenize(text, XmlTokens(), XmlBrush),
        PayloadTextKind.Hex => HexRuns(text),
        _ => [new Run(text) { Foreground = PlainBrush }],
    };

    /// <summary>Walks one regex over the text, colouring matches and dimming everything between.</summary>
    private static IEnumerable<Inline> Tokenize(string text, Regex tokens, Func<Match, Brush> brushFor)
    {
        int last = 0;
        foreach (Match match in tokens.Matches(text))
        {
            if (match.Index > last)
                yield return new Run(text[last..match.Index]) { Foreground = PunctBrush };

            yield return new Run(match.Value) { Foreground = brushFor(match) };
            last = match.Index + match.Length;
        }
        if (last < text.Length)
            yield return new Run(text[last..]) { Foreground = PunctBrush };
    }

    /// <summary>The offset column recedes; the bytes and their ASCII gutter carry the content.</summary>
    private static IEnumerable<Inline> HexRuns(string text)
    {
        foreach (string line in text.Split('\n'))
        {
            if (line.Length == 0) continue;
            if (line.Length > 8)
            {
                yield return new Run(line[..8]) { Foreground = PunctBrush };
                yield return new Run(line[8..]) { Foreground = PlainBrush };
            }
            else
            {
                yield return new Run(line) { Foreground = PlainBrush };
            }
            yield return new LineBreak();
        }
    }

    // key · string · number · literal — punctuation falls through to the dim default.
    [GeneratedRegex("(\"(?:[^\"\\\\]|\\\\.)*\"\\s*:)|(\"(?:[^\"\\\\]|\\\\.)*\")|(-?\\d+\\.?\\d*(?:[eE][-+]?\\d+)?)|\\b(true|false|null)\\b")]
    private static partial Regex JsonTokens();

    private static Brush JsonBrush(Match match) =>
        match.Groups[1].Success ? KeyBrush :
        match.Groups[2].Success ? StringBrush :
        match.Groups[3].Success ? NumberBrush : LiteralBrush;

    // comment/declaration · element name · attribute value — the angle brackets stay dim.
    [GeneratedRegex("(<!--[\\s\\S]*?-->|<[?!][\\s\\S]*?>)|(</?[\\w:.\\-]+)|(\"[^\"]*\"|'[^']*')")]
    private static partial Regex XmlTokens();

    private static Brush XmlBrush(Match match) =>
        match.Groups[1].Success ? CommentBrush :
        match.Groups[2].Success ? KeyBrush : StringBrush;

    private static Brush Frozen(string hex)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)!);
        brush.Freeze();
        return brush;
    }
}
