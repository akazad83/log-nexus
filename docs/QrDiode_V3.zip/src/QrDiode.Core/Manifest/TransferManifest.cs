﻿using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Framing;

namespace QrDiode.Core.Manifest;

public enum ContentKind : byte
{
    File = 0,
    Xml = 1,
    Json = 2,
}

public enum CompressionAlg : byte
{
    None = 0,
    Brotli = 1,
}

/// <summary>
/// The transfer manifest: everything a receiver needs to reconstruct, decrypt and verify
/// one transfer. Serialized to a fixed binary layout and signed with the sender's ECDSA key.
/// </summary>
public sealed class TransferManifest
{
    public const int MaxFilenameBytes = 255;
    private const int FixedSize = 167; // bytes before the variable-length filename

    // ── Acceptance envelope ───────────────────────────────────────────────────────────────
    // These bounds are load-bearing for availability, not tidiness. Every field they guard
    // arrives in a *signed* manifest, so only a sender already in the trust store can reach
    // them — but the receiver constructs its LT decoder from them BEFORE the first data symbol
    // arrives, and that allocation scales with K (LtDecoder's source table plus RobustSoliton's
    // CDF, ~24 bytes per K). Left unbounded, a manifest declaring 128 MB at symbolSize 1 yields
    // K = 134 217 728 and allocates ~3.2 GB at the moment the manifest is accepted.

    /// <summary>
    /// Largest payload this build will accept. Far below what the optical channel can carry in
    /// practice — at roughly 20 KB/s, 16 MB is about 13 minutes of air time — so nothing usable
    /// is excluded. A transaction-only deployment should tighten this to ~1 MB.
    /// </summary>
    public const long MaxPayloadBytes = 16L * 1024 * 1024;

    /// <summary>
    /// Symbol-size floor, applied as <c>min(MinSymbolSize, ciphertextSize)</c>: a small payload
    /// legitimately produces <c>symbolSize == ciphertextSize</c>, which can be far below this.
    /// </summary>
    public const int MinSymbolSize = 256;

    /// <summary>
    /// Symbol-size ceiling, derived from what a frame can physically carry rather than from a
    /// sender-side option — a larger symbol could never be delivered by any frame we would parse.
    /// </summary>
    public const int MaxSymbolSize = FrameFormat.MaxFrameSize - FrameFormat.DataOverhead;

    /// <summary>
    /// Hard ceiling on K. Implied by <see cref="MaxPayloadBytes"/> and <see cref="MinSymbolSize"/>,
    /// but stated separately so that relaxing either of those cannot silently reopen the
    /// allocation-amplification path. At this bound the decoder's fixed tables are ~1.5 MB.
    /// </summary>
    public const int MaxSourceSymbols = 65_536;

    public required Guid SessionId { get; init; }
    public required long TimestampUnixMs { get; init; }
    public required ulong Counter { get; init; }
    public required byte[] SenderSigningKeyId { get; init; }      // 8
    public required byte[] ReceiverAgreementKeyId { get; init; }  // 8
    public required byte[] Salt { get; init; }                    // 32
    public required byte[] Nonce { get; init; }                   // 12
    public required ushort SymbolSize { get; init; }
    public required uint SourceSymbolCount { get; init; }         // K
    public required ulong LtSeed { get; init; }
    public required ushort RedundancyHint { get; init; }
    public required long OriginalSize { get; init; }
    public required long CompressedSize { get; init; }
    public required long CiphertextSize { get; init; }
    public required CompressionAlg Compression { get; init; }
    public required byte[] CiphertextSha256 { get; init; }        // 32
    public required ContentKind ContentType { get; init; }
    public required string Filename { get; init; }

    public byte[] SessionTag => SessionId.ToByteArray().AsSpan(0, 8).ToArray();

    public byte[] Serialize()
    {
        byte[] nameBytes = Encoding.UTF8.GetBytes(Filename);
        if (nameBytes.Length > MaxFilenameBytes)
            throw new InvalidOperationException("Filename exceeds 255 UTF-8 bytes.");

        var body = new byte[FixedSize + nameBytes.Length];
        var span = body.AsSpan();

        SessionId.TryWriteBytes(span[..16]);
        BinaryPrimitives.WriteInt64LittleEndian(span[16..], TimestampUnixMs);
        BinaryPrimitives.WriteUInt64LittleEndian(span[24..], Counter);
        Require(SenderSigningKeyId, KeyId.Size).CopyTo(span[32..]);
        Require(ReceiverAgreementKeyId, KeyId.Size).CopyTo(span[40..]);
        Require(Salt, Envelope.SaltSize).CopyTo(span[48..]);
        Require(Nonce, Envelope.NonceSize).CopyTo(span[80..]);
        BinaryPrimitives.WriteUInt16LittleEndian(span[92..], SymbolSize);
        BinaryPrimitives.WriteUInt32LittleEndian(span[94..], SourceSymbolCount);
        BinaryPrimitives.WriteUInt64LittleEndian(span[98..], LtSeed);
        BinaryPrimitives.WriteUInt16LittleEndian(span[106..], RedundancyHint);
        BinaryPrimitives.WriteInt64LittleEndian(span[108..], OriginalSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[116..], CompressedSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[124..], CiphertextSize);
        span[132] = (byte)Compression;
        Require(CiphertextSha256, 32).CopyTo(span[133..]);
        span[165] = (byte)ContentType;
        span[166] = (byte)nameBytes.Length;
        nameBytes.CopyTo(span[FixedSize..]);
        return body;
    }

    /// <summary>
    /// Parses a manifest body. Structural validation only — signature verification is the
    /// caller's job and MUST happen against these exact bytes before the result is trusted.
    /// </summary>
    public static bool TryParse(ReadOnlySpan<byte> body, out TransferManifest? manifest, out string error)
    {
        manifest = null;

        if (body.Length < FixedSize) { error = "Manifest body too short."; return false; }
        int nameLen = body[166];
        if (body.Length != FixedSize + nameLen) { error = "Manifest body length mismatch."; return false; }

        byte compression = body[132];
        if (compression > (byte)CompressionAlg.Brotli) { error = "Unknown compression algorithm."; return false; }
        byte contentType = body[165];
        if (contentType > (byte)ContentKind.Json) { error = "Unknown content type."; return false; }

        long originalSize = BinaryPrimitives.ReadInt64LittleEndian(body[108..]);
        long compressedSize = BinaryPrimitives.ReadInt64LittleEndian(body[116..]);
        long ciphertextSize = BinaryPrimitives.ReadInt64LittleEndian(body[124..]);
        ushort symbolSize = BinaryPrimitives.ReadUInt16LittleEndian(body[92..]);
        uint k = BinaryPrimitives.ReadUInt32LittleEndian(body[94..]);

        // Sanity bounds: fail-closed on anything outside the acceptance envelope declared above.
        if (originalSize <= 0 || originalSize > MaxPayloadBytes) { error = "Original size out of range."; return false; }
        if (compressedSize <= 0 || compressedSize > MaxPayloadBytes) { error = "Compressed size out of range."; return false; }
        if (ciphertextSize != compressedSize + Envelope.TagSize) { error = "Ciphertext size inconsistent."; return false; }
        if (compression == (byte)CompressionAlg.None && compressedSize != originalSize) { error = "Uncompressed size mismatch."; return false; }
        if (compression == (byte)CompressionAlg.Brotli && compressedSize > originalSize) { error = "Compressed larger than original."; return false; }

        // Floor is min(MinSymbolSize, ciphertextSize) so a small payload — whose entire ciphertext
        // may be under 256 bytes, giving symbolSize == ciphertextSize and K == 1 — still passes.
        // This also subsumes the old symbolSize == 0 check, so the division below cannot fault.
        if (symbolSize < Math.Min(MinSymbolSize, ciphertextSize)) { error = "Symbol size too small."; return false; }
        if (symbolSize > MaxSymbolSize) { error = "Symbol size too large."; return false; }

        long expectedK = (ciphertextSize + symbolSize - 1) / symbolSize;
        if (k == 0 || k != expectedK) { error = "Source symbol count inconsistent."; return false; }
        if (k > MaxSourceSymbols) { error = "Source symbol count too large."; return false; }

        string filename;
        try
        {
            filename = Encoding.UTF8.GetString(body.Slice(FixedSize, nameLen));
        }
        catch (ArgumentException) { error = "Invalid filename encoding."; return false; }

        manifest = new TransferManifest
        {
            SessionId = new Guid(body[..16]),
            TimestampUnixMs = BinaryPrimitives.ReadInt64LittleEndian(body[16..]),
            Counter = BinaryPrimitives.ReadUInt64LittleEndian(body[24..]),
            SenderSigningKeyId = body.Slice(32, KeyId.Size).ToArray(),
            ReceiverAgreementKeyId = body.Slice(40, KeyId.Size).ToArray(),
            Salt = body.Slice(48, Envelope.SaltSize).ToArray(),
            Nonce = body.Slice(80, Envelope.NonceSize).ToArray(),
            SymbolSize = symbolSize,
            SourceSymbolCount = k,
            LtSeed = BinaryPrimitives.ReadUInt64LittleEndian(body[98..]),
            RedundancyHint = BinaryPrimitives.ReadUInt16LittleEndian(body[106..]),
            OriginalSize = originalSize,
            CompressedSize = compressedSize,
            CiphertextSize = ciphertextSize,
            Compression = (CompressionAlg)compression,
            CiphertextSha256 = body.Slice(133, 32).ToArray(),
            ContentType = (ContentKind)contentType,
            Filename = filename,
        };
        error = "";
        return true;
    }

    public byte[] Sign(ECDsa signingKey, byte[] serializedBody)
        => signingKey.SignData(serializedBody, HashAlgorithmName.SHA256); // IEEE P1363: 64 bytes for P-256

    public static bool VerifySignature(ECDsa signingPublicKey, ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
        => signingPublicKey.VerifyData(body, signature, HashAlgorithmName.SHA256);

    /// <summary>Receipt hash: SHA-256 over body ‖ signature. Shown on both screens for comparison.</summary>
    public static string ReceiptHash(ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
    {
        var buf = new byte[body.Length + signature.Length];
        body.CopyTo(buf);
        signature.CopyTo(buf.AsSpan(body.Length));
        return Convert.ToHexString(SHA256.HashData(buf).AsSpan(0, 8));
    }

    private static byte[] Require(byte[] value, int length)
        => value.Length == length ? value : throw new InvalidOperationException($"Expected {length}-byte field, got {value.Length}.");
}
