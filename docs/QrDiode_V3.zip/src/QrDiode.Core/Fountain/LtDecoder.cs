namespace QrDiode.Core.Fountain;

/// <summary>
/// Incremental LT decoder using belief-propagation peeling. Symbols may arrive in any order,
/// duplicated, or not at all — the carousel guarantees more will come.
/// </summary>
public sealed class LtDecoder
{
    private sealed class CodedSymbol
    {
        public required HashSet<int> Remaining;
        public required byte[] Data;
    }

    private readonly int _symbolSize;
    private readonly long _payloadLength;
    private readonly ulong _sessionSeed;
    private readonly RobustSoliton _soliton;

    private readonly byte[]?[] _source;
    private readonly Dictionary<int, List<CodedSymbol>> _bySource = new();
    private readonly LinkedList<CodedSymbol> _buffered = new();
    private readonly HashSet<uint> _seenSymbolIds = new();
    private readonly Queue<uint> _seenOrder = new();

    public int K { get; }
    public int DecodedSourceCount { get; private set; }
    public int UniqueSymbolsReceived { get; private set; }
    public bool IsComplete => DecodedSourceCount == K;

    /// <summary>
    /// Ceiling on buffered coded symbols. Symbol IDs keep increasing across carousel loops, so
    /// without a cap both this list and the seen-ID set grow across the 32-bit ID space for as
    /// long as a session is on air — bounded only by how long someone points a camera at a screen.
    /// The floor of 1024 is far above what belief-propagation peeling actually needs: a systematic
    /// pass resolves source blocks directly, and deep buffering only happens under heavy loss.
    /// </summary>
    public int MaxBufferedSymbols { get; }

    /// <summary>Ceiling on retained symbol IDs. See <see cref="MaxBufferedSymbols"/>.</summary>
    public int MaxSeenSymbolIds { get; }

    /// <summary>
    /// Symbols dropped because <see cref="MaxBufferedSymbols"/> was reached. Surfaced rather than
    /// swallowed: a decode that silently discarded equations must not look like a clean one.
    /// </summary>
    public long BufferedEvictions { get; private set; }

    /// <summary>IDs dropped from the duplicate-suppression set because its cap was reached.</summary>
    public long SeenIdEvictions { get; private set; }

    public LtDecoder(long payloadLength, int symbolSize, ulong sessionSeed)
    {
        if (payloadLength <= 0) throw new ArgumentOutOfRangeException(nameof(payloadLength));
        _payloadLength = payloadLength;
        _symbolSize = symbolSize;
        _sessionSeed = sessionSeed;
        K = LtCode.SourceBlockCount(payloadLength, symbolSize);
        _soliton = new RobustSoliton(K);
        _source = new byte[]?[K];

        MaxBufferedSymbols = Math.Clamp(4 * K, 1024, 8192);
        MaxSeenSymbolIds = Math.Clamp(16 * K, 4096, 131_072);
    }

    /// <summary>Feeds one received symbol. Returns true if it advanced decoding (new + useful).</summary>
    public bool AddSymbol(uint symbolId, ReadOnlySpan<byte> payload)
    {
        if (IsComplete) return false;
        if (payload.Length != _symbolSize) return false;
        if (!MarkSeen(symbolId)) return false;

        if (symbolId < (uint)K)
        {
            Resolve((int)symbolId, payload.ToArray());
            return true;
        }

        var neighbors = LtCode.GetNeighbors(_sessionSeed, symbolId, _soliton);
        var remaining = new HashSet<int>(neighbors.Length);
        var data = payload.ToArray();

        foreach (int n in neighbors)
        {
            var src = _source[n];
            if (src is not null)
                Xor(data, src);
            else
                remaining.Add(n);
        }

        if (remaining.Count == 0)
            return false; // fully redundant

        if (remaining.Count == 1)
        {
            int only = remaining.First();
            Resolve(only, data);
            return true;
        }

        var coded = new CodedSymbol { Remaining = remaining, Data = data };
        _buffered.AddLast(coded);
        foreach (int n in remaining)
        {
            if (!_bySource.TryGetValue(n, out var list))
                _bySource[n] = list = new List<CodedSymbol>();
            list.Add(coded);
        }
        EvictBufferedIfNeeded();
        return true;
    }

    /// <summary>
    /// Records a symbol ID for duplicate suppression, evicting the oldest once the cap is reached.
    ///
    /// Evicting from a duplicate-suppression set sounds alarming and is not: peeling is idempotent
    /// over identical bytes, so a re-arriving symbol whose ID has been forgotten is simply
    /// re-reduced against the blocks already known and then either discarded as redundant or
    /// buffered again. It costs a little work, never correctness.
    /// </summary>
    private bool MarkSeen(uint symbolId)
    {
        if (!_seenSymbolIds.Add(symbolId)) return false;

        _seenOrder.Enqueue(symbolId);
        UniqueSymbolsReceived++;

        while (_seenOrder.Count > MaxSeenSymbolIds)
        {
            _seenSymbolIds.Remove(_seenOrder.Dequeue());
            SeenIdEvictions++;
        }
        return true;
    }

    private void EvictBufferedIfNeeded()
    {
        while (_buffered.Count > MaxBufferedSymbols)
        {
            var oldest = _buffered.First!.Value;
            _buffered.RemoveFirst();
            BufferedEvictions++;

            // The dependency edges have to go too. _bySource holds the same object, so dropping
            // it from the buffer alone would free nothing and the cap would achieve nothing.
            foreach (int n in oldest.Remaining)
            {
                if (!_bySource.TryGetValue(n, out var list)) continue;
                list.Remove(oldest);
                if (list.Count == 0) _bySource.Remove(n);
            }
            oldest.Remaining.Clear();
        }
    }

    private void Resolve(int sourceIndex, byte[] data)
    {
        if (_source[sourceIndex] is not null) return;

        var queue = new Queue<(int Index, byte[] Data)>();
        queue.Enqueue((sourceIndex, data));

        while (queue.Count > 0)
        {
            var (idx, resolved) = queue.Dequeue();
            if (_source[idx] is not null) continue;
            _source[idx] = resolved;
            DecodedSourceCount++;

            if (!_bySource.Remove(idx, out var dependents)) continue;
            foreach (var coded in dependents)
            {
                if (!coded.Remaining.Remove(idx)) continue;
                Xor(coded.Data, resolved);
                if (coded.Remaining.Count == 1)
                {
                    int only = coded.Remaining.First();
                    coded.Remaining.Clear();
                    if (_source[only] is null)
                        queue.Enqueue((only, coded.Data));
                }
            }
        }
    }

    /// <summary>Assembles the decoded payload. Only valid when <see cref="IsComplete"/>.</summary>
    public byte[] Assemble()
    {
        if (!IsComplete) throw new InvalidOperationException("Decoding is not complete.");
        var result = new byte[_payloadLength];
        for (int i = 0; i < K; i++)
        {
            long offset = (long)i * _symbolSize;
            int len = (int)Math.Min(_symbolSize, _payloadLength - offset);
            _source[i]!.AsSpan(0, len).CopyTo(result.AsSpan((int)offset, len));
        }
        return result;
    }

    private static void Xor(byte[] target, byte[] operand)
    {
        for (int i = 0; i < target.Length; i++)
            target[i] ^= operand[i];
    }
}
