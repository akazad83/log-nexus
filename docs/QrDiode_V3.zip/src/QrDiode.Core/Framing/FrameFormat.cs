﻿namespace QrDiode.Core.Framing;

/// <summary>
/// Wire format constants for QrDiode protocol v1. One QR code carries exactly one frame.
/// All integers are little-endian. Every frame ends with a CRC-32 over all preceding bytes.
/// </summary>
public static class FrameFormat
{
    public const byte Magic0 = 0x4F; // 'O'
    public const byte Magic1 = 0x44; // 'D'
    /// <summary>
    /// Bumped to 0x02 when the plaintext SHA-256 left the manifest. A v1 endpoint rejects a v2
    /// frame cleanly as <see cref="FrameParseError.BadVersion"/> rather than mis-slicing the
    /// shifted fields, which is why the bump is not optional for a field removal.
    /// </summary>
    public const byte ProtocolVersion = 0x02;

    public const byte TypeManifest = 0x01;
    public const byte TypeDataSymbol = 0x02;

    /// <summary>magic(2) + version(1) + type(1) + sessionTag(8)</summary>
    public const int HeaderSize = 12;
    public const int SessionTagOffset = 4;
    public const int SessionTagSize = 8;
    public const int CrcSize = 4;

    /// <summary>Data frame: header + symbolId(4) + payload + crc.</summary>
    public const int DataOverhead = HeaderSize + 4 + CrcSize;

    /// <summary>Manifest frame: header + bodyLen(2) + body + signature(64) + crc.</summary>
    public const int SignatureSize = 64;
    public const int ManifestOverhead = HeaderSize + 2 + SignatureSize + CrcSize;

    /// <summary>Hard upper bound on any frame we will parse (V40 QR byte capacity is 2953).</summary>
    public const int MaxFrameSize = 4096;
    public const int MinFrameSize = HeaderSize + CrcSize + 1;
}

public enum FrameType : byte
{
    Manifest = FrameFormat.TypeManifest,
    DataSymbol = FrameFormat.TypeDataSymbol,
}
