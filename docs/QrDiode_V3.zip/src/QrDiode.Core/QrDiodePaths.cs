namespace QrDiode.Core;

/// <summary>Well-known local paths shared by the Sender, Receiver and KeyCeremony tools.</summary>
public static class QrDiodePaths
{
    public static string Root { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "QrDiode");

    public static string TrustDir => Path.Combine(Root, "trust");
    public static string AuditDir => Path.Combine(Root, "audit");
    public static string QuarantineDir => Path.Combine(Root, "quarantine");
    public static string QuarantineStagingDir => Path.Combine(QuarantineDir, ".staging");
    public static string JournalDb => Path.Combine(Root, "journal.db");
    public static string CounterFile => Path.Combine(Root, "sender-counter.bin");

    /// <summary>Where the receiver keeps its operator preferences, storage root included.</summary>
    public static string ReceiverSettingsFile => Path.Combine(Root, "receiver-settings.json");

    /// <summary>
    /// Default landing zone for received payloads. The operator can point the receiver's storage
    /// anywhere (a scanned share, an evidence volume); this is only where it starts.
    /// </summary>
    public static string DefaultStorageDir => QuarantineDir;

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(Root);
        Directory.CreateDirectory(TrustDir);
        Directory.CreateDirectory(AuditDir);
        Directory.CreateDirectory(QuarantineDir);
        Directory.CreateDirectory(QuarantineStagingDir);
    }
}
