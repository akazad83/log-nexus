using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// One-click demo provisioning for single-machine evaluation. Creates BOTH endpoint key pairs
/// (demo-ot, demo-it) in Windows CNG and cross-trusts their public bundles locally.
///
/// IMPORTANT: this is a convenience for demos only in that both private keys live on the same
/// machine. Every security mechanism still runs at full strength — real ECDSA signatures,
/// real ECDH+AES-GCM encryption, real anti-replay. Nothing is stubbed or weakened.
/// For production, run the two-machine ceremony with the KeyCeremony tool instead.
/// </summary>
[SupportedOSPlatform("windows")]
public static class DemoProvisioner
{
    public const string OtEndpoint = "demo-ot";
    public const string ItEndpoint = "demo-it";

    public sealed record DemoIdentities(string OtFingerprint, string ItFingerprint);

    public static bool IsDemoEndpoint(string? endpointName) =>
        endpointName is OtEndpoint or ItEndpoint;

    /// <summary>
    /// True if demo bundles are sitting in the trust store, whether or not this run created them.
    ///
    /// The dangerous case is not the demo itself — it is a machine that was demoed once and is
    /// later treated as provisioned. That state survives a restart and looks identical to a real
    /// deployment, so it has to be detectable without relying on anyone remembering.
    /// </summary>
    public static bool ArtifactsPresent()
    {
        foreach (string name in new[] { OtEndpoint, ItEndpoint })
            if (File.Exists(Path.Combine(QrDiodePaths.TrustDir, $"{name}.json")))
                return true;
        return false;
    }

    public static DemoIdentities Provision()
    {
        QrDiodePaths.EnsureCreated();

        using var ot = CngEndpointKeys.OpenOrCreate(OtEndpoint);
        using var it = CngEndpointKeys.OpenOrCreate(ItEndpoint);

        var otBundle = PublicKeyBundle.FromKeys(OtEndpoint, ot);
        var itBundle = PublicKeyBundle.FromKeys(ItEndpoint, it);

        // Demo bundles are always refreshed; the interactive import path never overwrites.
        File.WriteAllText(Path.Combine(QrDiodePaths.TrustDir, $"{OtEndpoint}.json"), otBundle.ToJson());
        File.WriteAllText(Path.Combine(QrDiodePaths.TrustDir, $"{ItEndpoint}.json"), itBundle.ToJson());

        return new DemoIdentities(otBundle.Fingerprint(), itBundle.Fingerprint());
    }

    /// <summary>Removes demo keys and trust bundles (e.g. before production provisioning).</summary>
    public static void Remove()
    {
        CngEndpointKeys.Delete(OtEndpoint);
        CngEndpointKeys.Delete(ItEndpoint);
        foreach (var name in new[] { OtEndpoint, ItEndpoint })
        {
            string path = Path.Combine(QrDiodePaths.TrustDir, $"{name}.json");
            if (File.Exists(path)) File.Delete(path);
        }
    }
}
