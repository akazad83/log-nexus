﻿using System.IO.Compression;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

public enum FeedResult
{
    /// <summary>Not a valid frame, wrong session, or already-seen symbol. Safe to ignore.</summary>
    Ignored = 0,
    ManifestAccepted,
    SymbolAccepted,
    Completed,
    /// <summary>Frame or manifest actively rejected by a security check. See LastRejection.</summary>
    Rejected,
}

public sealed class CompletedTransfer
{
    public required TransferManifest Manifest { get; init; }
    public required byte[] Plaintext { get; init; }

    /// <summary>
    /// SHA-256 of the verified plaintext, computed here rather than read from the manifest.
    ///
    /// Consumers must take it from this property. The manifest is signed but not encrypted, so a
    /// plaintext hash carried on the wire is readable by anyone filming the screen — and for the
    /// small, structured payloads this system is built for, a hash of predictable content is an
    /// enumeration oracle rather than mere metadata. Computing it here is what allows the field
    /// to leave the wire format entirely.
    /// </summary>
    public required byte[] PlaintextSha256 { get; init; }

    public required string ReceiptHash { get; init; }
}

/// <summary>
/// Everything the UI needs to render one rejection as an inbox entry. The manifest is present only
/// for rejections that happened after the signature verified — before that there is nothing the
/// receiver is entitled to believe about the frame.
/// </summary>
public sealed record RejectionInfo(string Reason, TransferManifest? Manifest);

/// <summary>
/// Receiver-side engine. Feed raw QR payloads; the engine enforces the verification chain in
/// strict order and fails closed at every step:
/// CRC → signature → anti-replay → LT decode → ciphertext hash → AES-GCM → decompress cap →
/// plaintext size → content gate.
/// </summary>
public sealed class ReceiveEngine
{
    private readonly ITrustStore _trust;
    private readonly IReplayGuard _replayGuard;
    private readonly IEndpointKeys _receiverKeys;
    private readonly object _lock = new();

    /// <summary>
    /// Sessions this engine already reached a verdict on. The carousel keeps re-emitting a session's
    /// manifest for the rest of its air-time, so without this the receiver would re-verdict the same
    /// session every loop. Entries are only added once the manifest's signature has verified, so a
    /// forged frame can never suppress a legitimate session by squatting its id.
    /// </summary>
    private readonly HashSet<Guid> _settled = [];
    private readonly Queue<Guid> _settledOrder = new();

    /// <summary>
    /// Ceiling on remembered sessions. This set only has to outlive a session's air time — the
    /// journal is the durable anti-replay authority — so at roughly one session per ten seconds
    /// this is about eleven hours of history, far beyond the acceptance window that makes
    /// re-judging possible at all. Bounded so a long-running receiver cannot grow without limit.
    /// </summary>
    private const int MaxSettledSessions = 4096;

    private TransferManifest? _manifest;
    private byte[]? _manifestBody;
    private byte[]? _manifestSignature;
    private byte[] _sessionTag = Array.Empty<byte>();
    private LtDecoder? _decoder;
    private CompletedTransfer? _completed;

    public string LastRejection { get; private set; } = "";
    public RejectionInfo? LastRejectionInfo { get; private set; }
    public TransferManifest? ActiveManifest => _manifest;
    public CompletedTransfer? Completed => _completed;
    public int DecodedSourceCount => _decoder?.DecodedSourceCount ?? 0;
    public int K => _decoder?.K ?? 0;
    public int UniqueSymbolsReceived => _decoder?.UniqueSymbolsReceived ?? 0;
    public double Progress => _decoder is { K: > 0 } d ? (double)d.DecodedSourceCount / d.K : 0;

    /// <summary>
    /// Whether opaque (<see cref="ContentKind.File"/>) payloads are accepted. False means every
    /// payload that completes has been parsed by a hardened parser. Defaults to true so the demo's
    /// file-send path keeps working; a transaction-only deployment should pass false.
    /// </summary>
    public bool AllowOpaqueFiles { get; }

    public ReceiveEngine(ITrustStore trust, IReplayGuard replayGuard, IEndpointKeys receiverKeys,
        bool allowOpaqueFiles = true)
    {
        _trust = trust;
        _replayGuard = replayGuard;
        _receiverKeys = receiverKeys;
        AllowOpaqueFiles = allowOpaqueFiles;
    }

    /// <summary>
    /// Clears the in-flight session so the next manifest on the wire can be picked up. Sessions this
    /// engine already settled stay settled, so the tail of the just-finished carousel is ignored
    /// rather than re-judged. Call after handling <see cref="FeedResult.Completed"/> or a rejection.
    /// </summary>
    public void Reset()
    {
        lock (_lock)
        {
            if (_manifest is not null) Settle(_manifest.SessionId);
            _manifest = null;
            _manifestBody = null;
            _manifestSignature = null;
            _decoder = null;
            _sessionTag = Array.Empty<byte>();
            _completed = null;
        }
    }

    /// <summary>Feeds the raw byte payload of one decoded QR code.</summary>
    public FeedResult Feed(ReadOnlySpan<byte> qrPayload)
    {
        lock (_lock)
        {
            if (_completed is not null) return FeedResult.Ignored;

            if (!FrameParser.TryParse(qrPayload, out var frame, out _))
                return FeedResult.Ignored; // noise, misdecode, or tamper — CRC/structure said no

            return frame.Type switch
            {
                FrameType.Manifest => FeedManifest(frame),
                FrameType.DataSymbol => FeedSymbol(frame),
                _ => FeedResult.Ignored,
            };
        }
    }

    private FeedResult FeedManifest(ParsedFrame frame)
    {
        // Already locked onto a session? Ignore repeats of it, and ignore other sessions.
        if (_manifest is not null)
            return FeedResult.Ignored;

        // 1. Structural parse (no trust yet).
        if (!TransferManifest.TryParse(frame.Payload, out var candidate, out string parseError))
            return Reject($"Manifest parse: {parseError}");

        // 2. Signature: the sender must be in the trust store, and the signature must verify
        //    over the exact received body bytes. Nothing downstream runs on failure.
        var peer = _trust.FindBySigningKeyId(candidate!.SenderSigningKeyId);
        if (peer is null)
            return Reject($"Unknown sender key {KeyId.ToHex(candidate.SenderSigningKeyId)}");
        if (!TransferManifest.VerifySignature(peer.SigningPublicKey, frame.Payload, frame.Signature))
            return Reject("Manifest signature verification failed");

        // 3. This transfer must be addressed to us.
        if (!candidate.ReceiverAgreementKeyId.AsSpan().SequenceEqual(_receiverKeys.AgreementKeyId))
            return Reject("Manifest addressed to a different receiver key");

        // The signature has verified, so the session id is now something we may act on: if we have
        // already ruled on this session, the carousel is simply still playing it. Not a new event.
        if (_settled.Contains(candidate.SessionId))
            return FeedResult.Ignored;

        // 4. Anti-replay.
        var verdict = _replayGuard.Check(candidate.SenderSigningKeyId, candidate.SessionId, candidate.Counter, candidate.TimestampUnixMs);
        if (verdict != ReplayVerdict.Fresh)
        {
            Settle(candidate.SessionId);
            return Reject($"Replay check failed: {verdict}", candidate);
        }

        _manifest = candidate;
        _manifestBody = frame.Payload.ToArray();
        _manifestSignature = frame.Signature.ToArray();
        _sessionTag = candidate.SessionTag;
        _decoder = new LtDecoder(candidate.CiphertextSize, candidate.SymbolSize, candidate.LtSeed);
        return FeedResult.ManifestAccepted;
    }

    private FeedResult FeedSymbol(ParsedFrame frame)
    {
        // No verified manifest yet → we do not touch payload bytes at all. The carousel
        // re-emits everything, so dropping here costs time, never data.
        if (_manifest is null || _decoder is null)
            return FeedResult.Ignored;

        if (!frame.SessionTag.SequenceEqual(_sessionTag))
            return FeedResult.Ignored;
        if (frame.Payload.Length != _manifest.SymbolSize)
            return FeedResult.Ignored;

        bool advanced = _decoder.AddSymbol(frame.SymbolId, frame.Payload);
        if (!_decoder.IsComplete)
            return advanced ? FeedResult.SymbolAccepted : FeedResult.Ignored;

        return FinishTransfer();
    }

    private FeedResult FinishTransfer()
    {
        var manifest = _manifest!;
        byte[] ciphertext = _decoder!.Assemble();

        // 5. Ciphertext hash must match the signed manifest before we spend crypto on it.
        if (!SHA256.HashData(ciphertext).AsSpan().SequenceEqual(manifest.CiphertextSha256))
            return RejectAndReset("Ciphertext hash mismatch after decode");

        // 6. AES-GCM open with AAD rebuilt from the signed manifest.
        byte[] aad = Envelope.BuildAad(manifest.SessionId, manifest.Salt, manifest.Counter,
            manifest.SenderSigningKeyId, manifest.ReceiverAgreementKeyId);

        var peer = _trust.FindBySigningKeyId(manifest.SenderSigningKeyId)!;
        byte[] key = Envelope.DeriveKey(_receiverKeys.AgreementKey, peer.AgreementPublicKey.PublicKey, manifest.Salt, manifest.SessionId);
        byte[] compressed;
        try
        {
            compressed = Envelope.Open(ciphertext, key, manifest.Nonce, aad);
        }
        catch (CryptographicException)
        {
            return RejectAndReset("AES-GCM authentication failed");
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }

        // 7. Decompress with a hard output cap (zip-bomb guard).
        byte[] plaintext;
        if (manifest.Compression == CompressionAlg.Brotli)
        {
            if (!TryDecompressBrotli(compressed, manifest.OriginalSize, out plaintext))
                return RejectAndReset("Decompression failed or exceeded declared size");
        }
        else
        {
            plaintext = compressed;
        }

        // 8. Plaintext length must match the signed original size.
        //
        // There is deliberately no plaintext-hash comparison here: the hash is not carried on the
        // wire (see CompletedTransfer.PlaintextSha256 for why). Authenticity of these bytes is
        // already established by steps 5-7 - the signed ciphertext hash, the GCM tag under an AAD
        // rebuilt from the signed manifest, and a deterministic decompression hard-capped at this
        // same signed size. What is given up is a cross-check against a Brotli implementation bug.
        if (plaintext.LongLength != manifest.OriginalSize)
            return RejectAndReset("Plaintext size does not match the signed manifest");

        byte[] plaintextHash = SHA256.HashData(plaintext);

        // 9. Content gate.
        if (!ContentGate.Validate(manifest.ContentType, plaintext, AllowOpaqueFiles, out string gateError))
            return RejectAndReset($"Content gate: {gateError}");

        // Commit anti-replay state only for fully verified transfers.
        _replayGuard.Commit(manifest.SenderSigningKeyId, manifest.SessionId, manifest.Counter);

        _completed = new CompletedTransfer
        {
            Manifest = manifest,
            Plaintext = plaintext,
            PlaintextSha256 = plaintextHash,
            ReceiptHash = TransferManifest.ReceiptHash(_manifestBody!, _manifestSignature!),
        };
        return FeedResult.Completed;
    }

    private static bool TryDecompressBrotli(byte[] compressed, long declaredSize, out byte[] plaintext)
    {
        plaintext = Array.Empty<byte>();
        try
        {
            var output = new byte[declaredSize];
            using var input = new MemoryStream(compressed, writable: false);
            using var brotli = new BrotliStream(input, CompressionMode.Decompress);

            int total = 0;
            while (total < output.Length)
            {
                int read = brotli.Read(output, total, output.Length - total);
                if (read == 0) return false; // stream ended short of the declared size
                total += read;
            }
            // Anything beyond the declared size means the stream lies — fail closed.
            if (brotli.ReadByte() != -1) return false;
            plaintext = output;
            return true;
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException)
        {
            return false;
        }
    }

    /// <summary>Records a final verdict for a session, evicting the oldest once the cap is reached.</summary>
    private void Settle(Guid sessionId)
    {
        if (!_settled.Add(sessionId)) return;

        _settledOrder.Enqueue(sessionId);
        while (_settledOrder.Count > MaxSettledSessions)
            _settled.Remove(_settledOrder.Dequeue());
    }

    private FeedResult Reject(string reason, TransferManifest? manifest = null)
    {
        LastRejection = reason;
        LastRejectionInfo = new RejectionInfo(reason, manifest);
        return FeedResult.Rejected;
    }

    /// <summary>A post-decode failure poisons the whole session — reset so a re-send can start clean.</summary>
    private FeedResult RejectAndReset(string reason)
    {
        LastRejection = reason;
        LastRejectionInfo = new RejectionInfo(reason, _manifest);
        if (_manifest is not null) Settle(_manifest.SessionId);
        _manifest = null;
        _manifestBody = null;
        _manifestSignature = null;
        _decoder = null;
        _sessionTag = Array.Empty<byte>();
        return FeedResult.Rejected;
    }
}
