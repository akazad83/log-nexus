using System.Text.Json;
using System.Xml;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

/// <summary>
/// Receiver-side content validation, applied AFTER all cryptographic checks pass and BEFORE
/// the payload leaves quarantine staging. XML and JSON are structurally validated with
/// hardened parsers; opaque files are never interpreted.
/// </summary>
public static class ContentGate
{
    public const int MaxXmlDepth = 64;
    public const int MaxJsonDepth = 64;

    public static bool Validate(ContentKind kind, byte[] plaintext, out string error)
        => Validate(kind, plaintext, allowOpaqueFiles: true, out error);

    /// <summary>
    /// Validates one verified payload.
    ///
    /// <paramref name="allowOpaqueFiles"/> is the transaction-only switch. With it false, every
    /// payload that reaches the store has been parsed by a hardened parser — a simpler and stronger
    /// claim than "XML and JSON are validated, and anything else is trusted because the signature
    /// verified". It defaults to true so the demo's file-send path keeps working; a deployment that
    /// carries only JSON/XML transactions should pass false.
    /// </summary>
    public static bool Validate(ContentKind kind, byte[] plaintext, bool allowOpaqueFiles, out string error)
    {
        try
        {
            switch (kind)
            {
                case ContentKind.Xml:
                    return ValidateXml(plaintext, out error);
                case ContentKind.Json:
                    return ValidateJson(plaintext, out error);
                case ContentKind.File:
                    if (!allowOpaqueFiles)
                    {
                        error = "Opaque file payloads are not accepted by this receiver.";
                        return false;
                    }
                    error = "";
                    return true; // opaque bytes; integrity/authenticity already proven
                default:
                    error = "Unknown content kind.";
                    return false;
            }
        }
        catch (Exception ex)
        {
            // Fail closed on anything a hostile document manages to throw.
            error = $"Content validation error: {ex.GetType().Name}";
            return false;
        }
    }

    private static bool ValidateXml(byte[] data, out string error)
    {
        var settings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit, // XXE off, entirely
            XmlResolver = null,                     // no external resource resolution
            MaxCharactersFromEntities = 0,
            MaxCharactersInDocument = 256L * 1024 * 1024,
            IgnoreProcessingInstructions = false,
            CloseInput = true,
        };

        using var stream = new MemoryStream(data, writable: false);
        using var reader = XmlReader.Create(stream, settings);
        int depth = 0;
        try
        {
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && !reader.IsEmptyElement)
                {
                    depth = reader.Depth + 1;
                    if (depth > MaxXmlDepth) { error = "XML nesting too deep."; return false; }
                }
            }
        }
        catch (XmlException ex)
        {
            error = $"Malformed XML at line {ex.LineNumber}.";
            return false;
        }
        error = "";
        return true;
    }

    private static bool ValidateJson(byte[] data, out string error)
    {
        var options = new JsonReaderOptions
        {
            MaxDepth = MaxJsonDepth,
            AllowTrailingCommas = false,
            CommentHandling = JsonCommentHandling.Disallow,
        };
        try
        {
            var reader = new Utf8JsonReader(data, options);
            while (reader.Read()) { }
            error = "";
            return true;
        }
        catch (JsonException ex)
        {
            error = $"Malformed JSON at position {ex.BytePositionInLine}.";
            return false;
        }
    }
}
