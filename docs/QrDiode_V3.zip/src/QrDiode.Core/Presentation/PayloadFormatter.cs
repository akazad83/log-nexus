using System.Text;
using System.Text.Json;
using System.Xml;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Presentation;

/// <summary>How a payload is being shown, which decides both colouring and the monospace grid.</summary>
public enum PayloadTextKind
{
    Json,
    Xml,
    Plain,
    Hex,
}

/// <summary>A payload rendered for human eyes: capped, never re-encoded, never trusted.</summary>
public sealed record PayloadText(string Text, PayloadTextKind Kind, bool Truncated, long TotalBytes)
{
    public static readonly PayloadText Empty = new("", PayloadTextKind.Plain, false, 0);
}

/// <summary>
/// Turns payload bytes into something an operator can read on either side of the diode: the sender
/// shows what it is about to put on the wire, the receiver shows what actually arrived, and both
/// use this one implementation so the two screens can be compared line for line.
///
/// Nothing here is a security boundary — the receiver's <see cref="Pipeline.ContentGate"/> has
/// already run by the time a payload reaches a viewer — but the parsers are hardened anyway
/// (no DTDs, no external entities, depth-capped) because the sender formats *unvalidated* input.
/// </summary>
public static class PayloadFormatter
{
    /// <summary>Characters kept for a viewer. The file on disk is always the real thing.</summary>
    public const int DefaultLimit = 96 * 1024;

    /// <summary>Bytes rendered in a hex dump — 8 KB is 512 rows, well past what anyone scrolls.</summary>
    public const int DefaultHexBytes = 8 * 1024;

    private const int MaxDepth = 64;

    private static readonly UTF8Encoding StrictUtf8 = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);

    /// <summary>Pretty-printed view: JSON re-indented, XML re-indented, binary as a hex dump.</summary>
    public static PayloadText Formatted(ContentKind kind, byte[] payload, int limit = DefaultLimit)
    {
        ArgumentNullException.ThrowIfNull(payload);

        switch (kind)
        {
            case ContentKind.Json:
                return TryIndentJson(payload, out string json)
                    ? Cap(json, PayloadTextKind.Json, limit, payload.Length)
                    : Raw(kind, payload, limit);

            case ContentKind.Xml:
                return TryIndentXml(payload, out string xml)
                    ? Cap(xml, PayloadTextKind.Xml, limit, payload.Length)
                    : Raw(kind, payload, limit);

            default:
                return Raw(kind, payload, limit);
        }
    }

    /// <summary>Exactly what the bytes say — decoded as UTF-8, or dumped as hex when they are not text.</summary>
    public static PayloadText Raw(ContentKind kind, byte[] payload, int limit = DefaultLimit)
    {
        ArgumentNullException.ThrowIfNull(payload);

        if (!TryDecodeText(payload, out string text))
            return Hex(payload);

        var textKind = kind switch
        {
            ContentKind.Json => PayloadTextKind.Json,
            ContentKind.Xml => PayloadTextKind.Xml,
            _ => PayloadTextKind.Plain,
        };
        return Cap(text, textKind, limit, payload.Length);
    }

    /// <summary>Offset · 16 bytes · ASCII gutter. The last resort that always works.</summary>
    public static PayloadText Hex(byte[] payload, int maxBytes = DefaultHexBytes)
    {
        ArgumentNullException.ThrowIfNull(payload);

        int shown = Math.Min(payload.Length, maxBytes);
        var builder = new StringBuilder(shown / 16 * 78 + 64);

        for (int offset = 0; offset < shown; offset += 16)
        {
            int run = Math.Min(16, shown - offset);
            builder.Append(offset.ToString("x8")).Append("  ");

            for (int i = 0; i < 16; i++)
            {
                builder.Append(i < run ? payload[offset + i].ToString("x2") : "  ");
                builder.Append(i == 7 ? "  " : ' ');
            }

            builder.Append(' ');
            for (int i = 0; i < run; i++)
            {
                byte b = payload[offset + i];
                builder.Append(b is >= 0x20 and < 0x7F ? (char)b : '.');
            }
            builder.Append('\n');
        }

        return new PayloadText(builder.ToString(), PayloadTextKind.Hex, shown < payload.Length, payload.Length);
    }

    /// <summary>
    /// One dim line for a list row: whitespace collapsed, cut on a character boundary. Binary gets a
    /// shape description instead, because a row of mojibake tells the operator nothing.
    /// </summary>
    public static string Snippet(ContentKind kind, byte[] payload, int max = 140)
    {
        ArgumentNullException.ThrowIfNull(payload);
        if (payload.Length == 0) return "";

        // Decoding a 64 MB payload to build a 140-character snippet is pure waste; the first few
        // KB decide it either way. Cut on the last complete UTF-8 sequence so the probe cannot
        // fail on a character that merely straddles the boundary.
        int probe = SafeUtf8Prefix(payload, 4096);
        if (!TryDecodeText(payload.AsSpan(0, probe), out string text))
            return $"binary · {payload.Length:N0} bytes";

        return OneLine(text, max);
    }

    /// <summary>Collapses every run of whitespace so a multi-line payload fits one row.</summary>
    public static string OneLine(string text, int max)
    {
        var builder = new StringBuilder(Math.Min(text.Length, max + 1));
        bool space = false;

        foreach (char c in text)
        {
            if (char.IsWhiteSpace(c))
            {
                space = builder.Length > 0;
                continue;
            }
            if (space) { builder.Append(' '); space = false; }
            builder.Append(c);
            if (builder.Length > max) return string.Concat(builder.ToString(0, max), "…");
        }
        return builder.ToString();
    }

    // ═══════════════════ internals ═══════════════════

    private static PayloadText Cap(string text, PayloadTextKind kind, int limit, long totalBytes) =>
        text.Length <= limit
            ? new PayloadText(text, kind, false, totalBytes)
            : new PayloadText(text[..limit], kind, true, totalBytes);

    private static bool TryIndentJson(byte[] payload, out string text)
    {
        try
        {
            using var document = JsonDocument.Parse(payload, new JsonDocumentOptions { MaxDepth = MaxDepth });
            using var buffer = new MemoryStream(payload.Length + payload.Length / 2);
            using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Indented = true }))
                document.WriteTo(writer);
            text = Encoding.UTF8.GetString(buffer.GetBuffer(), 0, (int)buffer.Length);
            return true;
        }
        catch (Exception ex) when (ex is JsonException or ArgumentException)
        {
            text = "";
            return false;
        }
    }

    private static bool TryIndentXml(byte[] payload, out string text)
    {
        var readerSettings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit, // same hardening as the content gate
            XmlResolver = null,
            MaxCharactersFromEntities = 0,
            CloseInput = true,
        };

        try
        {
            using var input = new MemoryStream(payload, writable: false);
            using var reader = XmlReader.Create(input, readerSettings);
            var output = new StringWriter();
            using (var writer = XmlWriter.Create(output, new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                OmitXmlDeclaration = false,
                CheckCharacters = false,
            }))
            {
                writer.WriteNode(reader, defattr: false);
            }
            text = output.ToString();
            return text.Length > 0;
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            text = "";
            return false;
        }
    }

    private static bool TryDecodeText(ReadOnlySpan<byte> payload, out string text)
    {
        try
        {
            text = StrictUtf8.GetString(payload);
        }
        catch (DecoderFallbackException)
        {
            text = "";
            return false;
        }

        // Valid UTF-8 is not the same as readable: a PNG happens to decode cleanly often enough.
        int control = 0;
        foreach (char c in text)
            if (char.IsControl(c) && c is not ('\n' or '\r' or '\t'))
                control++;

        if (control > 0 && control * 100 > text.Length)
        {
            text = "";
            return false;
        }
        return true;
    }

    /// <summary>Length of the longest prefix of <paramref name="max"/> bytes that ends a UTF-8 sequence.</summary>
    private static int SafeUtf8Prefix(byte[] payload, int max)
    {
        if (payload.Length <= max) return payload.Length;
        int end = max;
        while (end > 0 && (payload[end] & 0xC0) == 0x80) end--; // step back over continuation bytes
        return end;
    }
}
