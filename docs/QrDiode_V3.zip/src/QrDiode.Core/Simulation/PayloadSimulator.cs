using System.Globalization;
using System.Text;
using System.Text.Json;

namespace QrDiode.Core.Simulation;

/// <summary>Emission behaviour of the live source. All of it is operator-adjustable while running.</summary>
public sealed class SimulatorOptions
{
    /// <summary>Shortest quiet gap between two emissions, outside a burst.</summary>
    public TimeSpan MinInterval { get; set; } = TimeSpan.FromSeconds(4);
    /// <summary>Longest quiet gap between two emissions.</summary>
    public TimeSpan MaxInterval { get; set; } = TimeSpan.FromSeconds(40);
    /// <summary>0 = a metronome, 1 = almost every emission drags 1–2 more in behind it.</summary>
    public double Burstiness { get; set; } = 0.64;
    /// <summary>Names of the enabled catalogue entries. An empty set stops emission.</summary>
    public HashSet<string> EnabledTypes { get; } =
        new(PayloadCatalogue.DefaultEnabled.Select(t => t.Name), StringComparer.OrdinalIgnoreCase);
}

/// <summary>One payload the source produced, ready to become a session.</summary>
public sealed record GeneratedPayload(PayloadType Type, string Filename, byte[] Bytes)
{
    public int Size => Bytes.Length;
}

/// <summary>
/// A plant system emitting events, not a demo loop. Emissions arrive in irregular bursts: a long
/// quiet gap sampled from [min, max], then — with probability <see cref="SimulatorOptions.Burstiness"/> —
/// one or two more within a second or two. Seedable so the behaviour is testable.
/// </summary>
public sealed class PayloadSimulator
{
    private static readonly string[] Skus =
        ["PLC-CTRL-2X", "VALVE-DN50", "SENS-TMP-11", "DRV-VFD-7K5", "BRG-6204-ZZ", "RLY-24V-4C"];
    private static readonly string[] Assets =
        ["LINE1-PUMP-03", "LINE1-CONV-02", "LINE2-MIX-01", "LINE1-FILL-04", "LINE2-CAP-06"];
    private static readonly string[] Operators = ["op-217", "op-104", "op-338", "op-052"];
    private static readonly string[] Locations = ["WH-A-07", "WH-A-12", "WH-B-03", "LINE1-BUF"];

    private readonly Random _random;
    private readonly TimeProvider _clock;
    private int _burstRemaining;

    public SimulatorOptions Options { get; }

    public PayloadSimulator(SimulatorOptions? options = null, int? seed = null, TimeProvider? clock = null)
    {
        Options = options ?? new SimulatorOptions();
        _random = seed is { } s ? new Random(s) : Random.Shared;
        _clock = clock ?? TimeProvider.System;
    }

    /// <summary>The enabled catalogue entries, in catalogue order.</summary>
    public IReadOnlyList<PayloadType> EnabledTypes =>
        PayloadCatalogue.All.Where(t => Options.EnabledTypes.Contains(t.Name)).ToArray();

    /// <summary>
    /// How long to wait before the next emission. Inside a burst this is a second or two; otherwise
    /// it is a quiet gap from the configured range, and it may open a new burst behind it.
    /// </summary>
    public TimeSpan NextDelay()
    {
        if (_burstRemaining > 0)
        {
            _burstRemaining--;
            return TimeSpan.FromSeconds(0.6 + _random.NextDouble() * 1.9);
        }

        double min = Math.Max(0.5, Options.MinInterval.TotalSeconds);
        double max = Math.Max(min, Options.MaxInterval.TotalSeconds);
        if (_random.NextDouble() < Math.Clamp(Options.Burstiness, 0, 1))
            _burstRemaining = _random.Next(1, 3); // this emission becomes a burst of 2 or 3

        return TimeSpan.FromSeconds(min + _random.NextDouble() * (max - min));
    }

    /// <summary>True while the next emission is one of a burst already in flight.</summary>
    public bool InBurst => _burstRemaining > 0;

    /// <summary>Generates one payload of the given type, or a random enabled one.</summary>
    public GeneratedPayload? Generate(PayloadType? type = null)
    {
        if (type is null)
        {
            var enabled = EnabledTypes;
            if (enabled.Count == 0) return null;
            type = enabled[_random.Next(enabled.Count)];
        }

        byte[] bytes = type.Kind == Manifest.ContentKind.Xml
            ? Encoding.UTF8.GetBytes(BuildXml())
            : JsonSerializer.SerializeToUtf8Bytes(BuildBody(type), JsonOptions);

        return new GeneratedPayload(type, type.Name + type.Extension, bytes);
    }

    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = false };

    private object BuildBody(PayloadType type)
    {
        string now = Timestamp(0);

        if (type == PayloadCatalogue.OrderCreated)
        {
            int lineCount = _random.Next(1, 4);
            var lines = Enumerable.Range(0, lineCount).Select(_ => new
            {
                sku = Pick(Skus),
                qty = _random.Next(1, 48),
                unitPrice = Math.Round(12 + _random.NextDouble() * 480, 2),
            }).ToArray();
            return new
            {
                @event = type.Name,
                orderId = $"ORD-2026-{_random.Next(100000, 999999)}",
                customerId = $"C-{_random.Next(1000, 9999)}",
                lines,
                currency = "EUR",
                total = Math.Round(lines.Sum(l => l.qty * l.unitPrice), 2),
                createdAt = now,
            };
        }

        if (type == PayloadCatalogue.SensorTelemetry)
            return new
            {
                @event = type.Name,
                assetId = Pick(Assets),
                ts = now,
                readings = new
                {
                    tempC = Math.Round(48 + _random.NextDouble() * 38, 1),
                    vibrationMm = Math.Round(_random.NextDouble() * 2.4, 2),
                    pressureBar = Math.Round(3 + _random.NextDouble() * 5, 1),
                },
                status = _random.NextDouble() < 0.85 ? "OK" : "WARN",
            };

        if (type == PayloadCatalogue.BatchCompleted)
            return new
            {
                @event = type.Name,
                batchId = $"B-20260816-{_random.Next(1, 40):00}",
                recipe = $"R-{_random.Next(100, 260)}",
                startedAt = Timestamp(-_random.Next(7000, 20000)),
                endedAt = now,
                goodUnits = _random.Next(400, 9000),
                scrapUnits = _random.Next(0, 60),
                @operator = Pick(Operators),
            };

        if (type == PayloadCatalogue.AlarmRaised)
            return new
            {
                @event = type.Name,
                alarmId = $"ALM-{_random.Next(1000, 9999)}",
                severity = Pick(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
                source = Pick(Assets),
                message = Pick(["Overcurrent detected", "Bearing temperature high",
                    "Pressure above setpoint", "Guard door opened during cycle", "Feed jam"]),
                ts = now,
            };

        if (type == PayloadCatalogue.InventoryAdjusted)
            return new
            {
                @event = type.Name,
                sku = Pick(Skus),
                delta = _random.Next(-90, 60),
                location = Pick(Locations),
                reason = Pick(["CONSUMED", "SCRAPPED", "CYCLE_COUNT", "RETURNED"]),
                ts = now,
            };

        if (type == PayloadCatalogue.ShipmentDispatched)
            return new
            {
                @event = type.Name,
                shipmentId = $"SHP-{_random.Next(100000, 999999)}",
                carrier = Pick(["DHL", "DSV", "KUEHNE", "GLS"]),
                trackingRef = Convert.ToHexString(RandomBytes(6)),
                pallets = _random.Next(1, 14),
                grossKg = Math.Round(40 + _random.NextDouble() * 1800, 1),
                dispatchedAt = now,
            };

        if (type == PayloadCatalogue.MaintenanceWorkorder)
            return new
            {
                @event = type.Name,
                workorderId = $"WO-{_random.Next(10000, 99999)}",
                assetId = Pick(Assets),
                kind = Pick(["PREVENTIVE", "CORRECTIVE", "INSPECTION"]),
                priority = _random.Next(1, 5),
                assignedTo = Pick(Operators),
                dueAt = Timestamp(_random.Next(3600, 200000)),
                createdAt = now,
            };

        if (type == PayloadCatalogue.QualityInspection)
            return new
            {
                @event = type.Name,
                inspectionId = $"QI-{_random.Next(10000, 99999)}",
                batchId = $"B-20260816-{_random.Next(1, 40):00}",
                sampled = _random.Next(5, 60),
                defects = _random.Next(0, 6),
                verdict = _random.NextDouble() < 0.9 ? "PASS" : "HOLD",
                inspector = Pick(Operators),
                ts = now,
            };

        if (type == PayloadCatalogue.ReportDaily)
        {
            // ~200 KB — the occasional heavyweight that shows the operator what a long
            // air-time actually looks like on the stage.
            var rows = Enumerable.Range(0, 1800).Select(i => new
            {
                assetId = Pick(Assets),
                hour = i % 24,
                producedUnits = _random.Next(0, 900),
                downtimeMin = Math.Round(_random.NextDouble() * 40, 1),
                oee = Math.Round(0.55 + _random.NextDouble() * 0.43, 4),
                note = Pick(["nominal", "changeover", "material starvation", "operator break", "cleaning"]),
            }).ToArray();
            return new { @event = type.Name, reportId = $"RPT-20260816-{_random.Next(1, 99):00}", generatedAt = now, rows };
        }

        return new { @event = type.Name, ts = now };
    }

    private string BuildXml()
    {
        var sb = new StringBuilder(4096);
        sb.Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<batch id=\"B-20260816-")
          .Append(_random.Next(1, 40).ToString("00", CultureInfo.InvariantCulture))
          .Append("\" recipe=\"R-").Append(_random.Next(100, 260)).Append("\">\n");
        sb.Append("  <completedAt>").Append(Timestamp(0)).Append("</completedAt>\n  <steps>\n");
        int steps = _random.Next(40, 90);
        for (int i = 0; i < steps; i++)
        {
            sb.Append("    <step seq=\"").Append(i + 1).Append("\" asset=\"").Append(Pick(Assets))
              .Append("\" durationS=\"").Append(_random.Next(5, 900)).Append("\">")
              .Append(Pick(["heat", "mix", "hold", "transfer", "cool", "sample"]))
              .Append("</step>\n");
        }
        sb.Append("  </steps>\n</batch>\n");
        return sb.ToString();
    }

    private string Timestamp(int offsetSeconds) =>
        _clock.GetUtcNow().AddSeconds(offsetSeconds).ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);

    private T Pick<T>(IReadOnlyList<T> items) => items[_random.Next(items.Count)];

    private byte[] RandomBytes(int n)
    {
        var b = new byte[n];
        _random.NextBytes(b);
        return b;
    }
}
