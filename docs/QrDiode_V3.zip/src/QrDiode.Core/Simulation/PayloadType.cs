using QrDiode.Core.Manifest;

namespace QrDiode.Core.Simulation;

/// <summary>
/// One kind of payload the live source can emit. The three-letter <see cref="Code"/> and its two
/// colours live here rather than in either app's theme on purpose: the sender's queue and the
/// receiver's inbox must show the *same* tile for the same event type, and the letters — not the
/// colour — carry the meaning (colour-blind safe).
/// </summary>
public sealed record PayloadType(
    string Name,
    string Code,
    ContentKind Kind,
    string TileBackground,
    string TileForeground)
{
    /// <summary>Filename the payload is transmitted under, e.g. <c>order.created.json</c>.</summary>
    public string Extension => Kind switch
    {
        ContentKind.Xml => ".xml",
        ContentKind.Json => ".json",
        _ => ".bin",
    };
}

/// <summary>The catalogue of payload shapes the simulator emits. Shapes mimic real API events.</summary>
public static class PayloadCatalogue
{
    public static readonly PayloadType OrderCreated =
        new("order.created", "ORD", ContentKind.Json, "#FF423A6A", "#FFE7E5FE");
    public static readonly PayloadType SensorTelemetry =
        new("sensor.telemetry", "TEL", ContentKind.Json, "#FF1F3F47", "#FFCFEFF5");
    public static readonly PayloadType BatchCompleted =
        new("batch.completed", "BCH", ContentKind.Json, "#FF3F424D", "#FFE4E7F5");
    public static readonly PayloadType AlarmRaised =
        new("alarm.raised", "ALM", ContentKind.Json, "#FF501E1F", "#FFFFCFCC");
    public static readonly PayloadType InventoryAdjusted =
        new("inventory.adjusted", "INV", ContentKind.Json, "#FF41300D", "#FFFCE5BB");
    public static readonly PayloadType ShipmentDispatched =
        new("shipment.dispatched", "SHP", ContentKind.Json, "#FF2B3A55", "#FFDBE6FF");
    public static readonly PayloadType MaintenanceWorkorder =
        new("maintenance.workorder", "MNT", ContentKind.Json, "#FF33304A", "#FFE2DFFF");
    public static readonly PayloadType QualityInspection =
        new("quality.inspection", "QUA", ContentKind.Json, "#FF2A3F36", "#FFD8F0E4");
    public static readonly PayloadType ReportDaily =
        new("report.daily", "RPT", ContentKind.Json, "#FF3A3550", "#FFE7E5FE");
    public static readonly PayloadType BatchXml =
        new("batch.xml", "XML", ContentKind.Xml, "#FF3F424D", "#FFCFD3E5");

    /// <summary>A manually browsed file that matches no catalogue entry.</summary>
    public static readonly PayloadType ManualFile =
        new("file", "FIL", ContentKind.File, "#FF3F424D", "#FFCFD3E5");

    public static IReadOnlyList<PayloadType> All { get; } =
    [
        OrderCreated, SensorTelemetry, BatchCompleted, AlarmRaised, InventoryAdjusted,
        ShipmentDispatched, MaintenanceWorkorder, QualityInspection, ReportDaily, BatchXml,
    ];

    /// <summary>The types enabled by default — everything except the two heavyweights.</summary>
    public static IReadOnlyList<PayloadType> DefaultEnabled { get; } =
        All.Where(t => t != ReportDaily && t != BatchXml).ToArray();

    public static PayloadType? Find(string name) =>
        All.FirstOrDefault(t => string.Equals(t.Name, name, StringComparison.OrdinalIgnoreCase));

    /// <summary>
    /// Resolves the tile for a payload the receiver only knows by filename — the receiver never
    /// runs the simulator, it just recognises what arrived.
    /// </summary>
    public static PayloadType ForFilename(string filename, ContentKind kind)
    {
        string stem = Path.GetFileNameWithoutExtension(filename);
        var match = Find(stem) ?? Find(filename);
        if (match is not null) return match;

        return kind switch
        {
            ContentKind.Xml => BatchXml with { Name = filename },
            ContentKind.Json => ManualFile with { Name = filename, Code = "JSN", Kind = ContentKind.Json },
            _ => ManualFile with { Name = filename },
        };
    }
}
