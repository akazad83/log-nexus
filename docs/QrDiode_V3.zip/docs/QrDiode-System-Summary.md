# Light Is the Only Wire

**QrDiode — moving plant transactions from the control network to the business network with nothing between them but a screen and a camera.**

---

## 1. The Story in One Page

Every industrial site runs two worlds that do not get along.

The first is the **control world**: the machines, valves, sensors and controllers that physically run the plant. Its governing rule is simple and absolute — nothing from outside may reach it. A compromised controller is not a data-loss event; it is a safety event.

The second is the **business world**: the systems that plan production, bill customers and report to regulators. It is hungry for exactly the data the first world produces — batch records, quality inspections, alarms, shipments.

The usual compromise is a firewall: a locked door between the two. But a door is still a door. It has rules, and rules have exceptions, and exceptions get configured by people at 2 a.m.

QrDiode removes the door entirely.

> 💡 **The idea in one sentence: the only thing that crosses between the two worlds is light.**

Picture a sealed observation window between a clean room and a corridor. Inside the clean room, a technician holds flashcards up to the glass, one after another, quickly. Outside in the corridor, a colleague photographs each card as it appears. Information moves. Nothing else does. The colleague outside cannot knock on the glass, cannot slide a note back, cannot ask for a card to be shown again — the glass is sealed and there is no channel in that direction to use.

That is the whole system. The control-side computer displays a fast-changing stream of QR codes on an ordinary monitor. The business-side computer watches that monitor through an ordinary webcam. There is no cable, no wireless link, no shared drive, no protocol. Neither application contains a single line of networking code. The one-way direction of travel is a property of physics, not a setting someone could change.

Two questions follow immediately, and the system answers both.

**"What if the camera misses one?"** It will — screens flicker, cameras blur, someone walks past. Because nothing can be re-requested, the sender never stops producing. It keeps generating fresh puzzle pieces of the same message, and *any* sufficiently large handful of them rebuilds the whole thing. A missed frame is not an error to be recovered from; it is simply a piece that was not needed.

**"Can't anyone with a phone just film the screen?"** They can film it, and they will get nothing. The data is sealed before it is ever drawn, addressed to one specific receiving computer, and signed so that the receiver can prove who produced it. A stranger's photograph yields scrambled bytes. Even a perfect recording, replayed later in front of the real camera, is recognised and refused.

> 🔒 **The guarantee: information can leave the control world, and nothing — not a command, not an acknowledgement, not a single bit — can travel back into it.**

---

## 2. System Architecture

The system is three programs and two machines. Everything the control side does happens on its own computer; everything the business side does happens on its own computer; and the only thing they share is a line of sight.

```mermaid
flowchart LR
    subgraph OT["🏭 OT ZONE — control network"]
        direction TB
        SRC["Plant event source<br/>XML / JSON transactions"]
        QUE["Session queue<br/>one payload at a time"]
        BLD["Session builder<br/>compress · seal · sign · fountain-encode"]
        REN["Frame renderer<br/>pre-renders QR images ahead of the screen"]
        STG["📺 Stage<br/>animated QR carousel"]
        OAUD["📜 Audit log<br/>+ send counter"]
        SRC --> QUE --> BLD --> REN --> STG
        BLD -.-> OAUD
    end

    subgraph GAP["✨ OPTICAL AIR GAP"]
        direction TB
        LIGHT["photons only<br/>no cable · no radio<br/>no acknowledgement"]
    end

    subgraph IT["🏢 IT ZONE — business network"]
        direction TB
        CAM["📷 Camera"]
        DEC["Decode pipeline<br/>camera frame → brightness image → frame bytes"]
        ENG["Verification engine<br/>ordered, fail-closed checks"]
        STORE["📁 Payload store"]
        JNL["🗄 Journal + archive index"]
        IAUD["📜 Audit log"]
        UI["Live inbox &amp; archive"]
        CAM --> DEC --> ENG --> STORE --> UI
        ENG -.-> JNL
        ENG -.-> IAUD
        JNL -.-> UI
    end

    subgraph KEY["🔑 One-time provisioning — offline, hand-carried"]
        direction TB
        KC["Key ceremony tool<br/>public key bundles<br/>on removable media"]
    end

    OT ==>|"displays"| GAP ==>|"is filmed by"| IT
    KEY -.->|"receiver's public keys"| OT
    KEY -.->|"sender's public keys"| IT

    classDef ot fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef gap fill:#F2F2F5,stroke:#9AA0A6,color:#33363B;
    classDef it fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    classDef key fill:#EDE6F7,stroke:#7A5EA8,color:#3A2A57;
    class SRC,QUE,BLD,REN,STG,OAUD ot;
    class LIGHT gap;
    class CAM,DEC,ENG,STORE,JNL,IAUD,UI it;
    class KC key;
    style OT fill:#FFF7EF,stroke:#E0A96D
    style GAP fill:#FAFAFC,stroke:#B7BCC4,stroke-dasharray:5 4
    style IT fill:#F0F6FD,stroke:#8FB8DE
    style KEY fill:#F8F5FD,stroke:#B49DD8,stroke-dasharray:5 4
```

*Figure 1 — The two zones and the single optical link between them.*

Everything in the warm zone runs on the control-network machine and everything in the cool zone runs on the business-network machine. The only solid arrows crossing the middle are the screen displaying and the camera filming; the dotted arrows at the bottom are the one-time key exchange, performed by hand on removable media before the system is ever used, and never touched again at runtime. Both applications share one common library, so the rules for framing, encoding and cryptography are written once and used identically by both sides.

| Where | What runs there | What it can touch |
|---|---|---|
| **OT machine** (control network) | Sender application | Its own private keys, the trust store, a send counter, an audit log, one screen |
| **The gap** | Nothing | — |
| **IT machine** (business network) | Receiver application | A camera, its own private keys, the trust store, the payload store, the journal, an audit log |
| **Either machine, once, offline** | Key ceremony tool | Creates that machine's key pair, exports its public half, imports the peer's |

Both applications are ordinary Windows desktop programs. Each keeps its own state in a private folder on its own machine — keys, trusted peers, logs, and on the receiving side the store of everything that has arrived. Nothing is shared between the two machines except what crosses the optical channel and what was carried across by hand at provisioning time.

The sending side can be driven two ways: a live source that emits realistic plant transactions on an irregular, bursty schedule, or an operator picking a file directly. Both feed the same queue and take the same path, so the receiving side cannot tell them apart — one code path, one set of guarantees.

---

## 3. The Transfer Process, End to End

Follow a single transaction — say a completed batch record, a few hundred bytes of JSON — from the moment the plant produces it to the moment it lands on the business-side disk.

```mermaid
sequenceDiagram
    autonumber
    participant P as 🏭 Plant source
    participant S as OT sender
    participant D as 📺 Stage
    participant C as 📷 Camera
    participant R as IT receiver
    participant Z as 📁 IT store

    P->>S: one XML / JSON transaction
    S->>S: compress — keep it only if it came out smaller
    S->>S: seal for the addressed receiver (encrypt + authenticate)
    S->>S: hash the sealed bytes into a manifest
    S->>S: sign the manifest
    S->>S: split sealed bytes into K blocks, prepare symbols

    loop Carousel — at least 9×K frames and at least 6 seconds
        S->>D: render one frame as a QR image
        D-->>C: light
        C->>R: decoded frame bytes
        alt manifest frame
            R->>R: checksum → structure → signature → addressed to us → anti-replay
        else data frame
            R->>R: fold the symbol into the decoder
        end
    end
    Note over D,C: nothing can travel this way — no acknowledgement exists

    R->>R: all K blocks solved → sealed bytes rebuilt
    R->>R: hash check → open the seal → decompress → size check → content gate
    R->>Z: atomic write, then journal row and audit record
    Note over S,R: both screens show the same 16-character receipt for operators to compare
```

*Figure 2 — One payload, from plant event to business-side file.*

The sending side prepares once and then repeats. The receiving side needs the manifest before it will look at anything else, which is why the manifest is the first frame shown and reappears regularly. Because there is no acknowledgement, the session cannot end when the receiver is finished — it ends when it has had enough air time, then pauses briefly so the receiver can finalise before the next one begins.

**The nine stages, in order.** *Intake* — a transaction enters the queue and is shown to the operator in full, so the control side can see exactly what is leaving. *Serialization* — the payload is compressed, and the compressed form is kept only if it is actually smaller. *Sealing* — the result is encrypted and authenticated for one specific receiving key. *Chunking* — the sealed bytes are cut into equal blocks. *Encoding* — those blocks become an endless supply of symbols. *Rendering* — each symbol becomes one frame and each frame becomes one QR image. *Capture* — the camera films the screen and a decoder reads the codes. *Reassembly* — symbols accumulate until the blocks can be solved. *Validation and handoff* — the rebuilt payload passes every remaining check and is written atomically into the business-side store, where any tool can read it.

### Operating parameters, as implemented

| Parameter | Value |
|---|---|
| Payload types carried | XML, JSON, and opaque files — XML and JSON are structurally parsed on arrival; opaque files are accepted without interpretation, and the receiver can be set to refuse them outright |
| Largest payload the receiver will accept | 16 MB |
| Compression | Applied; kept only when it produces a smaller result |
| Chunk (symbol) size | The smaller of 1350 bytes and the whole sealed payload |
| Blocks per payload (**K**) | Sealed size ÷ chunk size, rounded up; capped at 65 536 |
| Data frame on the wire | Symbol + 20 bytes of framing (marker, version, type, session tag, symbol number, checksum) |
| Manifest frame on the wire | Manifest body (167 bytes + filename) + 82 bytes (framing, length, 64-byte signature, checksum) |
| Largest frame the receiver will parse at all | 4096 bytes |
| QR encoding | Byte mode, **error-correction level L** |
| QR version | The smallest version that fits the session's largest frame — **version 27 (125×125 modules)** at the full chunk size, **version 10–11 (57–61 modules)** for a typical few-hundred-byte transaction |
| Quiet zone | 8 modules on every side, at minimum |
| Module scaling on screen | Whole-number only, so modules never blur into grey |
| Frame rate | **15 frames per second**, adjustable 5–30 while running |
| Data frames per carousel loop | 3 × K |
| Manifest repetition | First frame of every loop, then every 20th frame |
| Session ends when | 9 × K frames have been shown **and** at least 6 seconds have elapsed — whichever takes longer |
| Gap between sessions | 1.5 seconds |
| Timestamp acceptance window | ±15 minutes in the receiver's default strict mode; ±48 hours when relaxed |

A typical plant transaction of one to three hundred bytes compresses to roughly a hundred and fifty, seals to a little over that, and fits in a **single block** — so its QR code is small and the six-second floor, not the data volume, decides how long it stays on screen. A 200 KB daily report compresses to around 16 KB, which becomes 13 blocks at the full chunk size, a 125-module code, and 39 data frames per loop — about eight seconds on air.

> 💡 **Nothing is written to the business-side disk until every check has passed.** A payload that fails at any stage produces a recorded rejection, not a file.

---

## 4. QR Streaming, Frame by Frame

This is the part that surprises people: the sender does not transmit the message once. It transmits an unbounded stream *about* the message, and stops only when it has spent its budget of air time.

```mermaid
flowchart LR
    subgraph OTX["🏭 OT — one payload becomes an endless stream"]
        direction TB
        PL["Sealed payload"]
        BLK["Blocks B1 … BK<br/>equal size · last one padded"]
        SYS["🧩 Systematic symbols<br/>numbers 0 … K−1<br/>the blocks themselves"]
        COD["🧩 Coded symbols<br/>numbers K and up<br/>combinations of several blocks"]
        MAN["📄 Manifest frame<br/>signed description<br/>of this payload"]
        FR["Frames<br/>symbol + number<br/>+ session tag + checksum"]
        SCR["📺 One QR per frame<br/>15 per second"]
        PL --> BLK
        BLK --> SYS
        BLK --> COD
        SYS --> FR
        COD --> FR
        MAN --> FR
        FR --> SCR
    end

    subgraph CHAN["✨ OPTICAL CHANNEL"]
        direction TB
        SHOWN["each frame<br/>is shown once"]
        LOST["✖ blurred · glare ·<br/>someone walks past<br/>frame lost, never<br/>requested again"]
        CAM["📷 Camera"]
        SHOWN -.->|"unlucky"| LOST
        SHOWN ==>|"clean"| CAM
    end

    subgraph ITX["🏢 IT — the stream becomes one payload again"]
        direction TB
        DEC["Decode → frame bytes"]
        CHK{"checksum and<br/>session tag agree?"}
        DROP["ignored in silence"]
        COL["🧩 Symbol collector<br/>repeats recognised<br/>and skipped"]
        PEEL["Peeling decoder<br/>solves blocks the moment<br/>they become solvable"]
        PROG{"blocks solved<br/>k of K"}
        WAIT["keep watching — more symbols<br/>are already on the way"]
        DONE["✔ payload rebuilt"]
        DEC --> CHK
        CHK -->|"no"| DROP
        CHK -->|"yes"| COL --> PEEL --> PROG
        PROG -->|"k &lt; K"| WAIT
        PROG -->|"k = K"| DONE
    end

    OTX ==> CHAN ==> ITX

    classDef ot fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef gap fill:#F2F2F5,stroke:#9AA0A6,color:#33363B;
    classDef it fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    classDef bad fill:#FADBD8,stroke:#C0392B,color:#641E16;
    classDef good fill:#D5F5E3,stroke:#1E8449,color:#145A32;
    class PL,BLK,SYS,COD,MAN,FR,SCR ot;
    class SHOWN,CAM gap;
    class DEC,CHK,COL,PEEL,PROG,WAIT it;
    class LOST,DROP bad;
    class DONE good;
    style OTX fill:#FFF7EF,stroke:#E0A96D
    style CHAN fill:#FAFAFC,stroke:#B7BCC4,stroke-dasharray:5 4
    style ITX fill:#F0F6FD,stroke:#8FB8DE
```

*Figure 3 — A payload dissolving into frames on the left, reassembling on the right.*

Each frame is self-contained: it carries its own symbol number, a tag identifying which session it belongs to, and a checksum. The receiver therefore does not care what order frames arrive in, whether it saw the beginning, or how many it missed. A frame that fails its checksum, belongs to another session, or repeats one already seen is discarded without a word — the sender is producing more regardless.

The first pass through the loop sends the blocks themselves, in order. On a clean channel the payload is complete by the end of that pass and everything afterwards is pure insurance. When frames go missing, the coded symbols that follow fill the holes — not by resending specific blocks, but by supplying new combinations from which the missing ones can be worked out.

The stage helps the operator keep the channel clean: it reports how many screen pixels each QR module currently occupies, and says plainly whether that is comfortable, marginal, or too small to decode. It keeps a pure white background even between payloads, so the camera holds a stable exposure reference rather than hunting.

---

## 5. How Fountain Coding Works Here

**In plain language first.** Imagine you need to send someone a four-page document, but you can only hold pages up to a window, and they can never tell you what they saw. Sending page 1, page 2, page 3, page 4 is a bad plan — one blink and page 3 is gone forever, and you will never know.

So instead you produce an endless supply of *puzzle pieces*. Some are simply the pages. Others are blends: "pages 1 and 3 combined", "pages 2, 3 and 4 combined". You keep producing new ones for as long as you have time. The other side collects whatever it catches and, once it has caught enough pieces — roughly as many as there are pages, plus a modest margin — it can work backwards and recover all four pages. **Which** pieces it caught barely matters. That is a fountain: you drink from it until your glass is full, and it makes no difference which drops you got.

```mermaid
flowchart LR
    subgraph ENC["🧩 Encoding — an endless supply of symbols from K blocks"]
        direction TB
        BB["Blocks<br/>B1 · B2 · B3 · B4"]
        SYSL["🧩 symbol 0 = B1<br/>🧩 symbol 1 = B2<br/>🧩 symbol 2 = B3<br/>🧩 symbol 3 = B4<br/>— the blocks themselves —"]
        CODL["🧩 symbol 4 = B1 ⊕ B3<br/>🧩 symbol 5 = B2 ⊕ B3 ⊕ B4<br/>🧩 symbol 6 = B1 ⊕ B4<br/>🧩 … without end<br/>— combinations —"]
        BB --> SYSL
        BB --> CODL
    end

    subgraph CH["✨ OPTICAL CHANNEL"]
        direction TB
        CHN["📺 → 📷<br/>arbitrary frames vanish<br/>and are never repeated on request"]
    end

    subgraph DECD["🧩 Decoding — peeling"]
        direction TB
        D1["a symbol with one unknown block<br/>reveals that block outright"]
        D2["subtract every newly known block<br/>from the symbols still waiting"]
        D3["symbols that drop to one unknown<br/>reveal the next block — and so on"]
        D4["✔ all K blocks known<br/>payload rebuilt"]
        D1 --> D2 --> D3 --> D4
        D3 -.->|"cascades"| D2
    end

    ENC ==> CH ==> DECD

    classDef ot fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef gap fill:#F2F2F5,stroke:#9AA0A6,color:#33363B;
    classDef it fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    class BB,SYSL,CODL ot;
    class CHN gap;
    class D1,D2,D3,D4 it;
    style ENC fill:#FFF7EF,stroke:#E0A96D
    style CH fill:#FAFAFC,stroke:#B7BCC4,stroke-dasharray:5 4
    style DECD fill:#F0F6FD,stroke:#8FB8DE
```

*Figure 4 — Blocks become symbols; symbols become blocks again.*

**The scheme as implemented.** The sealed payload is cut into K equal blocks. Symbols numbered below K are *systematic* — each one is simply the corresponding block, sent verbatim, so a clean channel needs no reconstruction work at all. Symbols numbered K and above are combinations: a handful of blocks merged together by an exclusive-or, which is reversible arithmetic. How many blocks go into each combination is drawn from a distribution deliberately weighted towards small combinations — those are what let the decoder get started — with a controlled minority of large ones that mop up stragglers at the end.

**How both sides agree without talking.** This is the elegant part. Nothing in a frame describes which blocks went into its symbol. Instead, the manifest carries a random seed chosen for that session, and both sides run the *same* deterministic generator over the pair *(session seed, symbol number)*. The sender uses it to decide which blocks to combine; the receiver uses it to work out what it just received. The generator is a fixed algorithm rather than a platform-provided one, precisely so that both ends produce identical results. The saving is real: a symbol costs no descriptive overhead at all, only its four-byte number.

**How the receiver knows it has enough.** It does not count symbols; it counts *solved blocks*. Every arriving symbol is reduced against the blocks already known. If that leaves exactly one unknown, that block is now solved — and solving it may in turn reduce other waiting symbols to a single unknown, which cascades. When the count of solved blocks reaches K, the payload is complete, and the manifest's hash of the sealed bytes confirms it byte for byte. The operator sees this live as "blocks *k* of K".

**Overhead in practice.** Driving the implemented codec through the same symbol schedule the stage uses, with frames dropped at random:

| Frames lost in the channel | Unique symbols needed, relative to K |
|---|---|
| None | **1.00 ×** — the systematic pass alone completes the payload |
| 10 % | ≈ 1.1 – 1.4 × |
| 25 % | ≈ 1.2 – 1.35 × |
| 50 % | ≈ 1.25 – 1.35 × |

Single-block payloads — the common transactional case — need exactly one symbol regardless of loss; they simply wait for a clean frame.

> 💡 **The reception overhead is modest; the transmission redundancy is deliberately lavish.** A session shows at least nine times as many frames as it has blocks. On a one-way link, air time is the only currency available, and the system spends it freely rather than asking for anything back.

The decoder also refuses to grow without limit: the number of unsolved symbols it will hold and the number of symbol numbers it remembers are both capped, and anything it discards because of those caps is counted and reported rather than quietly forgotten — a decode that dropped equations must never look like a clean one.

---

## 6. Security Measures

The optical gap already prevents an attacker from reaching the control network. Everything in this section exists for the other risks: someone filming the screen, someone showing a *different* screen to the camera, someone replaying yesterday's recording, or a hostile document arriving in a legitimate-looking transfer.

**Integrity — the receiver can prove nothing changed on the way.** Every frame carries a checksum, so damaged frames are discarded before anything looks at their contents. The manifest carries a cryptographic hash of the sealed payload, and the receiver recomputes that hash from the bytes it actually rebuilt. The seal itself carries an authentication tag that fails if even one bit was altered. And after decompression, the payload must be exactly the length the sender declared and signed.

**Authenticity — every payload is signed, so the receiver can prove who sent it.** Each site's machines generate their own key pair, and the public halves are exchanged once, in person, on removable media. The manifest is signed with the sender's private key over the exact bytes transmitted. The receiver looks the sender up in its list of provisioned peers and verifies that signature **before it interprets a single payload byte**. An unrecognised sender, or a signature that does not verify, ends the transfer there.

**Confidentiality — what is on the screen is meaningless to anyone but the intended receiver.** Before anything is drawn, the payload is encrypted with a key derived fresh for that session from the sender's private key, the addressed receiver's public key, and a random salt. Only that specific receiver can derive the same key. Anyone photographing the monitor captures ciphertext. The manifest also names the receiving key it was prepared for, so a transfer addressed elsewhere is refused rather than attempted.

**Binding — a manifest and a payload cannot be mixed and matched.** The signature covers the manifest, the manifest carries the hash of the sealed payload, and the seal is cryptographically tied to the session identity, the send counter and both parties' key identities — values that the receiver reconstructs from the signed manifest. Splicing one transfer's description onto another transfer's data breaks both directions of that binding.

**Replay and injection resistance — a recording of yesterday cannot become today's data.** Three independent conditions must all hold: the session identifier must never have been seen before, the sender's send counter must be strictly higher than the highest that sender has ever used, and the timestamp must fall inside the acceptance window (fifteen minutes by default). The counter is reserved and written to disk *before* a session exists, so even a crash cannot hand the same number to two transfers, and it is stored under operating-system protection tied to the sending account. The receiver's record of what it has accepted is kept in a transactional local database that survives restarts.

**Input validation — hostile bytes are assumed, not hoped against.** The frame parser checks every length before reading anything, rejects malformed input without allocating memory or raising errors, and refuses anything larger than the maximum frame size. The manifest is bounds-checked field by field — declared sizes, block counts and chunk sizes must all be internally consistent and within fixed limits — before the receiver commits any memory on its behalf. Decompression is hard-capped at the signed original size, so a small payload cannot expand into a resource-exhaustion attack. XML is parsed with document-type definitions prohibited, external resource resolution disabled and nesting depth capped; JSON is parsed with the same depth cap and no tolerance for sloppy syntax. Filenames from the far side are treated as hostile: sanitised, length-limited, and prefixed with the session identifier so they cannot collide, escape the store, or impersonate a reserved system name.

**Idempotency — the same transaction cannot land twice.** If the same content arrives again from the same sender, it is recorded as a duplicate and nothing is written. Files are written to a staging area on the same volume, flushed to disk, and then renamed into place, so a crash leaves either nothing or a complete file — never half of one.

**Audit — every outcome is recorded, and the record resists editing.** Both machines keep an append-only log in which each entry embeds the hash of the entry before it, so removing or altering any line breaks the chain from that point onward; a verification routine reports exactly where. The business side additionally indexes every judged arrival — stored, duplicate **and rejected** — in a searchable archive, because an archive that only remembers successes cannot answer the questions an incident asks of it. Any stored file can be re-hashed on demand and compared against the hash recorded when it was verified, which is the only check still available once the camera is off.

**Operator-visible proof.** Each transfer produces a short receipt — sixteen characters derived from the signed manifest — displayed on both screens. Two operators reading it to each other over the phone confirm, out of band, that the thing that arrived is the thing that was sent.

> 🔒 **Every check fails closed.** There is no partial acceptance, no "warn and continue", and no path by which unverified bytes reach the business-side store.

The system also refuses to let a convenience become a hidden weakness: a one-click demonstration mode that provisions both identities on a single machine displays a permanent, state-driven banner on both applications explaining that full cryptography is active but machine separation is not — and that banner persists until the demonstration keys are removed, not merely until the window is closed.

---

## 7. The Security Mechanism, Step by Step

Here is the same material as an ordered procedure: what happens on the sending side for one payload, what happens on the receiving side, and what happens when something does not add up.

```mermaid
flowchart LR
    subgraph SND["🏭 Sender — the same order, every time"]
        direction TB
        A1["1 · reserve the next send counter<br/>written to disk before the session exists"]
        A2["2 · compress the payload"]
        A3["3 · derive a one-session key<br/>own private key + addressed receiver's public key + random salt"]
        A4["4 · seal the payload<br/>bound to session id, salt, counter, both key identities"]
        A5["5 · hash the sealed bytes"]
        A6["6 · assemble the manifest and sign it"]
        A7["7 · encode into symbols and go on air"]
        A1 --> A2 --> A3 --> A4 --> A5 --> A6 --> A7
    end

    subgraph RCV1["🏢 Receiver · first — may I believe any of this?"]
        direction TB
        B1{"1 · checksum and<br/>frame structure"}
        B2{"2 · sender present in<br/>the trust store?"}
        B3{"3 · signature valid over<br/>these exact bytes?"}
        B4{"4 · addressed to this<br/>receiver's key?"}
        B5{"5 · unseen session · counter above<br/>watermark · timestamp in window"}
        NO1["✖ stop — nothing is written<br/>reason recorded in the inbox,<br/>the archive and the audit log"]
        B1 --> B2 --> B3 --> B4 --> B5
        B1 -->|"no"| NO1
        B2 -->|"no"| NO1
        B3 -->|"no"| NO1
        B4 -->|"no"| NO1
        B5 -->|"no"| NO1
    end

    subgraph RCV2["🏢 Receiver · then — is the payload what was signed?"]
        direction TB
        B6{"6 · rebuilt bytes hash<br/>to the signed value?"}
        B7{"7 · seal opens under data rebuilt<br/>from the signed manifest?"}
        B8{"8 · decompresses to<br/>exactly the signed size?"}
        B9{"9 · content parses under<br/>hardened rules?"}
        OKK["✔ 10 · commit — replay record,<br/>atomic write, journal row, audit entry"]
        NO2["✖ stop — nothing is written<br/>reason recorded in the inbox,<br/>the archive and the audit log"]
        B6 --> B7 --> B8 --> B9 --> OKK
        B6 -->|"no"| NO2
        B7 -->|"no"| NO2
        B8 -->|"no"| NO2
        B9 -->|"no"| NO2
    end

    SND ==>|"📺 → 📷"| RCV1
    RCV1 ==>|"manifest accepted · symbols collected<br/>until all K blocks are solved"| RCV2

    classDef ot fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef it fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    classDef bad fill:#FADBD8,stroke:#C0392B,color:#641E16;
    classDef good fill:#D5F5E3,stroke:#1E8449,color:#145A32;
    class A1,A2,A3,A4,A5,A6,A7 ot;
    class B1,B2,B3,B4,B5,B6,B7,B8,B9 it;
    class NO1,NO2 bad;
    class OKK good;
    style SND fill:#FFF7EF,stroke:#E0A96D
    style RCV1 fill:#F0F6FD,stroke:#8FB8DE
    style RCV2 fill:#F0F6FD,stroke:#8FB8DE
```

*Figure 5 — The security sequence: the sender's fixed order on the left, the receiver's two gauntlets on the right, and the single exit taken by any failure.*

The sending order matters: the counter is committed to disk before the session exists, the payload is sealed before it is described, and the description is signed last so that the signature covers the hash of what was actually sealed. The receiving order matters more: cheap checks come first so that noise costs nothing, identity is established before any payload byte is interpreted, and the expensive cryptographic work happens only for a sender that has already proved who it is.

**Key and secret handling.** Each machine's private keys are created inside the operating system's key store, marked non-exportable, and placed in hardware-backed storage when the machine offers it. They never leave — no export path exists in the applications. Only public bundles travel, once, on removable media; when a bundle is imported, both sides read aloud an eight-group fingerprint of it and confirm they see the same value. Importing over an existing trusted peer is refused as a deliberate two-step, so a key can never be silently replaced. The per-session encryption key is derived in memory and wiped immediately after use. The sender's counter file is protected by the operating system under the sending account and written by a temp-then-rename sequence so a crash cannot leave it torn.

**When a check fails.** The response is the same at every step and it is always the same three things: nothing is written, the reason is recorded, and the session is closed out so the sender's continuing carousel is ignored rather than judged again. Failures before the signature verifies produce no claim about who sent anything, and the record says exactly that. Failures after it name the sender and session. On the operator's screen the whole chain is shown with each step marked passed, failed, or never reached — so the answer to "how far did it get?" is visible rather than inferred. Identical repeated rejections from a looping carousel are collapsed into a single row with a repeat count instead of flooding the inbox.

---

## 8. Glossary

| Term | Meaning |
|---|---|
| **OT** (operational technology) | The computers and controllers that physically run a plant — the control network. Its priority is safety and availability. |
| **IT** (information technology) | The business network: planning, reporting, billing. Its priority is information. |
| **Data diode** | A link that physically permits data to travel in one direction only. Here, that direction is enforced by a screen and a camera rather than by configuration. |
| **Air gap** | The absence of any electrical or network connection between two systems. In this system the air gap is real and the only thing crossing it is light. |
| **Fountain code** (erasure code) | A scheme that turns a message into an unlimited supply of symbols, any sufficiently large subset of which rebuilds the original. It replaces "ask again" with "keep producing". |
| **Symbol** | One puzzle piece: either a block of the payload verbatim, or a reversible combination of several blocks. |
| **Block** | One equal-sized slice of the sealed payload. The number of blocks is written **K**. |
| **Frame** | Everything carried by a single QR code: one symbol (or the manifest), its identifying numbers, and a checksum. |
| **QR error-correction level** | How much redundancy is built into a QR code itself, from L (lowest, most data) to H (highest, most damage tolerance). This system uses **L**, because the fountain layer already handles loss and the extra capacity buys larger payloads per frame. |
| **QR version** | A QR code's size, from 1 (21×21 modules) to 40 (177×177). Larger versions hold more data but need more camera resolution. |
| **Module** | One black or white square of a QR code — the smallest thing the camera has to resolve. |
| **Quiet zone** | The blank white margin around a QR code that lets a decoder find its edges. |
| **Manifest** | The signed description of one transfer: what it is, how big it is, how it was encoded, who it is from, and who it is for. |
| **Session** | One payload's complete journey, with its own identifier, its own encryption key and its own place on air. |
| **Carousel** | The sender's endless loop of frames for the current session. |
| **Stage** | The window on the control-side screen that displays the carousel and nothing else. |
| **Systematic symbol** | A symbol that *is* a block, sent as-is. On a clean channel these alone complete the transfer. |
| **Peeling** | The decoding technique: solve any symbol that has only one unknown block left, subtract the result everywhere, and repeat until every block is known. |
| **Trust store** | Each machine's list of peers whose public keys it has accepted, established once and offline. |
| **Receipt** | A short value derived from the signed manifest, shown on both screens so two operators can confirm by voice that the same transfer is on both sides. |
| **Payload store** | The folder on the business-side machine where verified payloads land, readable by any tool without this software. |
| **Journal** | The receiving side's transactional record of what it has accepted, which also enforces the anti-replay rules across restarts. |
| **Audit log** | The append-only, hash-chained record of events kept on both machines, in which any edit breaks the chain. |
