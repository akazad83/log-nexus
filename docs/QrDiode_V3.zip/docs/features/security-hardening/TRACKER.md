# Tracker · POC security hardening

**Plan:** [README.md](README.md) · **Source analysis:** [`docs/plan/01-DO-NOW.md`](../../plan/01-DO-NOW.md)

Legend: ⬜ not started · 🟨 in progress · ✅ done · ⛔ blocked · ⏸️ deferred by decision

---

## Status board

| Phase | Title | Wire change | Status | Tests | Notes |
|---|---|---|---|---|---|
| — | **Baseline** | — | ✅ | 75/75 | SDK 10.0.400, Release |
| P1 | Pin the build | no | ✅ | 75/75 | 6 lock files; solution builds 0 warnings |
| P2 | Bound the manifest envelope | no | ✅ | 80/80 | +5 tests; the K bound turned out to be reachable |
| P3 | Cap the stored filename | no | ✅ | 80/80 + 9/9 | new `QrDiode.Receiver.Tests` project |
| P4 | Bound growing collections | no | ✅ | 84/84 + 9/9 | first churn test failed for a real reason |
| P5 | Plaintext hash — consumers | no | ✅ | 84/84 + 9/9 | no behaviour change, as intended |
| P6 | Plaintext hash — wire removal | **yes** | ✅ | 85/85 + 9/9 | protocol version now `0x02` |
| P7 | Opaque-file switch | no | ✅ | 88/88 + 9/9 | defaults to allowed; demo unaffected |
| P8 | Demo banner | no | ✅ | 88/88 + 9/9 | **compiles; not visually verified** |

**Totals:** Core 88 passed · Receiver 9 passed · 0 failed · solution builds with 0 warnings.

**All eight phases complete.** Baseline was 75 tests; there are now 97 across two projects.

**One item outstanding:** P8's banner renders correctly only as far as the compiler is concerned. Someone has to run both apps and look at it.

---

## P1 · Pin the build ✅

- [x] `global.json` pinning the SDK band (10.0.400, `latestPatch`)
- [x] `Directory.Build.props` with `RestorePackagesWithLockFile` and `Deterministic`
- [x] `packages.lock.json` generated for all six projects
- [x] Solution builds clean — 0 warnings, 0 errors
- [x] Tests green (75/75, unchanged)

**Acceptance met:** the resolved graph — including the native `ZXingCpp`, `FlashCap` and `SQLitePCLRaw` blobs — is now hash-pinned, and a mismatched SDK band fails the restore instead of building differently.

**Deliberately not included:** `TreatWarningsAsErrors` and `AnalysisMode=All`. Both would produce a large diagnostic backlog on a WPF codebase for no security benefit.

---

## P2 · Bound the manifest sanity envelope ✅

- [x] Payload ceiling 128 MB → 16 MB (`MaxPayloadBytes`)
- [x] `K` upper bound — `MaxSourceSymbols` = 65 536
- [x] Symbol-size floor `min(256, ciphertextSize)`, which also subsumes the old `symbolSize == 0` check so the K division cannot fault
- [x] Symbol-size ceiling derived from `FrameFormat.MaxFrameSize - DataOverhead` (4076), not from a sender option
- [x] Test: `symbolSize = 1` with a large ciphertext is rejected
- [x] Test: `symbolSize` above frame capacity is rejected
- [x] Test: `K` beyond the ceiling is rejected
- [x] Test: a 1-byte payload still round-trips — the over-tightening guard
- [x] Test: payload beyond the envelope is rejected

**Acceptance met:** the ~3.2 GB allocation at manifest acceptance is unreachable; the decoder's fixed tables are now bounded at ~1.5 MB.

**Surprise worth recording:** the plan said the `K` bound was redundant belt-and-braces implied by the other two. It is not. A payload at exactly the 16 MB ceiling split at the 256-byte minimum symbol size yields K = 65 537 — one over. The bound fires, and there is now a test for it.

---

## P3 · Cap the stored filename ✅

- [x] `SanitizeFilename` truncates the stem and preserves the extension
- [x] Sidecar records both `filename` (original) and `storedName` (possibly truncated)
- [x] `EnsureReady` rejects a store root too deep for a worst-case name, at Start
- [x] Test: 255-character filename materialises successfully — the regression test for the bug
- [x] Test: extension preserved through truncation
- [x] Test: an ordinary transaction filename is untouched
- [x] Test: hostile names stay inside the store
- [x] Test: the GUID prefix still makes reserved device names unreachable

**Acceptance met:** no verified payload fails materialisation because of its name.

**Note:** `PathTooLongException` needed no explicit handling in `PayloadStore` — `HandleCompletion` already catches broadly and records `store_failed`. `EnsureReady` now catches the deep-root case earlier, which is the more useful place.

**Also:** this phase added `tests/QrDiode.Receiver.Tests`, the receiver's first test project — it previously had none. `UseWPF` is deliberately off there: the WPF implicit-using set drops `System.IO` to avoid `System.Windows.Shapes.Path` colliding with `System.IO.Path`, and every test in it is about paths.

---

## P4 · Bound growing collections ✅

- [x] `_buffered` is now a `LinkedList` capped at `clamp(4 × K, 1024, 8192)`, FIFO eviction, unregistered from `_bySource`
- [x] `_seenSymbolIds` capped at `clamp(16 × K, 4096, 131072)`, FIFO eviction
- [x] `_settled` capped at 4096 via a `Settle()` helper replacing three direct `.Add` sites
- [x] `BufferedEvictions` / `SeenIdEvictions` counters exposed
- [x] Test: adversarial symbol-ID churn holds both caps
- [x] Test: realistic loss (30–50 %) never evicts, across three payload shapes

**Acceptance met:** decoder memory is bounded regardless of input, and normal decoding is provably untouched.

**The churn test failed on first run, correctly.** The first version fed ordinary coded symbols and the decoder simply *completed* before the cap was reached — degree-1 symbols let peeling finish. The buffer only grows without bound when no degree-1 symbol ever arrives, which is exactly what a stream of arbitrary injected IDs looks like from the decoder's side. The test now filters those out. Recorded because a weaker assertion would have passed vacuously.

**Two things found while writing it:**
- `_buffered` was **never read** — only appended to. The live references are in `_bySource`, so the list's sole effect was keeping fully-resolved symbols alive after `_bySource` had dropped them. It is now the eviction queue, which gives it a purpose.
- Evicting from a duplicate-suppression set sounds wrong and is not: peeling is idempotent over identical bytes, so a re-arriving symbol whose ID was forgotten is simply re-reduced and then discarded or re-buffered. It costs work, never correctness. Documented at the method.

---

## P5 · Plaintext hash — consumer migration ✅

- [x] `CompletedTransfer.PlaintextSha256` computed once in `FinishTransfer`
- [x] All ten receiver consumers migrated: journal dedupe, journal row (×2), audit record, three inbox entries, chain display, sidecar
- [x] `VerifiedChain` takes the hash as a parameter rather than reading it off the manifest
- [x] Manifest field and its verification check left untouched
- [x] Tests green, no behaviour change

**Acceptance met:** P6 then touched no receiver code at all — which was the entire point of splitting the two.

---

## P6 · Plaintext hash — wire removal ✅

- [x] `FixedSize` 199 → 167; content kind 197→165, filename length 198→166, filename 199→167
- [x] `ProtocolVersion` 0x01 → 0x02
- [x] Step 8 reduced to the signed-length check, with the reasoning recorded at the call site
- [x] Sender no longer computes a plaintext hash for the manifest
- [x] UI chain step relabelled "Plaintext hash" → "Plaintext size", now showing size plus the locally computed hash
- [x] `docs/SECURITY_REVIEW.md` §3.1 layout table, header table and §3.4 step 8 corrected, with an amendment note
- [x] `docs/ARCHITECTURE.md` manifest field list corrected
- [x] Test: an end-to-end `SendSession` manifest frame contains no window equal to `SHA-256(plaintext)`

**Acceptance met:** the hash is off the wire and the chain still fails closed at every step.

**On the "v1 rejected as BadVersion" test:** not written. There is no v1 encoder left in the tree to produce a genuine v1 frame, and `FramingTests` already covers version rejection generically — the test would have asserted a constant against itself. The bump's purpose is documented at `FrameFormat.ProtocolVersion` instead.

**The honest cost, recorded so it is not forgotten:** a Brotli decompression bug producing wrong-but-correctly-sized output would no longer be caught. Everything else that guarded the plaintext still does — the signed ciphertext hash, the GCM tag under an AAD rebuilt from the signed manifest, and the hard-capped deterministic decode.

---

## P7 · Opaque-file switch ✅

- [x] `ContentGate.Validate` overload taking `allowOpaqueFiles`
- [x] `ReceiveEngine` takes it as an optional constructor argument, default `true`
- [x] Test: with it off, `ContentKind.File` is rejected with a specific reason
- [x] Test: with it on (the default), behaviour is unchanged
- [x] Test: with it off, JSON transactions still pass end to end

**Acceptance met:** the transaction-only profile is one argument away — `new ReceiveEngine(trust, journal, keys, allowOpaqueFiles: false)`.

**Deliberately not built:** a `policy.json`, a deployment-profile enum, or a settings-file field. One boolean carries the whole decision for a POC; the config machinery the first plan proposed would have been more code than the control it enforces.

---

## P8 · Demo banner ✅ — compiles, appearance unverified

- [x] `DemoProvisioner.IsDemoEndpoint()` and `DemoProvisioner.ArtifactsPresent()` — state-based detection
- [x] Receiver gained a banner row in XAML (root grid is now 3 rows: header / banner / tabs)
- [x] Receiver's `RefreshDemoBanner()` called at startup, after opening keys, and after demo setup
- [x] Sender's demo strip now driven by state, not by the click that created it
- [x] Sender's `RefreshDemoBanner()` called at startup and after opening keys
- [x] Root-grid row assignments verified programmatically: 0 / 1 / 2, no overlap

**Acceptance partially met.** The XAML compiles and the layout rows are correct, but **the WPF apps were not run, so the banner's appearance is unconfirmed.** That check needs a human.

**Why this rather than compiling the demo path out:** this is a demo tool — removing the demo path removes its purpose. The actual risk is a machine demoed once and later treated as provisioned, which is why detection reads the trust store and the endpoint name rather than whether anyone clicked the button this session. It survives a restart; a toast would not.

---

## Log

| Date | Phase | Entry |
|---|---|---|
| 2026-08-23 | — | Baseline captured: 75/75 pass, Release, SDK 10.0.400. |
| 2026-08-23 | P1 | `global.json` + `Directory.Build.props`; six lock files generated; solution builds 0 warnings. |
| 2026-08-23 | P2 | Acceptance envelope tightened. The K bound written off as redundant in the plan turned out to be reachable — test added. 80/80. |
| 2026-08-23 | P3 | Filename cap + start-time path-budget check. Added `QrDiode.Receiver.Tests`, the receiver's first test project. 9/9. |
| 2026-08-23 | P4 | Decoder caps. Churn test failed first run for a real reason; rewritten to withhold degree-1 symbols. Found `_buffered` was write-only. 84/84. |
| 2026-08-23 | P5 | Consumers migrated to `CompletedTransfer.PlaintextSha256`. No behaviour change. |
| 2026-08-23 | P6 | **Wire change.** Plaintext hash removed, protocol version → `0x02`. Docs corrected. 85/85. |
| 2026-08-23 | P7 | Opaque-file switch, default allowed. 88/88. |
| 2026-08-23 | P8 | Demo banner in both apps, state-driven. Compiles; visual check outstanding. |

---

## What to do next

1. **Run both apps and look at the banner** — the one unverified item above.
2. **Deploy receiver before sender.** P6 changed the wire format. A v1 sender against a v2 receiver fails silently: the receiver rejects every frame as `BadVersion` and there is no back-channel to say so. On a demo rig that is a two-minute gap; the order still matters.
3. **Decide on `allowOpaqueFiles`.** It defaults to `true` so the demo's file-send keeps working. For the transaction-only profile, pass `false` where `ReceiveEngine` is constructed in `MainWindow.Start_Click`.
4. **Consider tightening `MaxPayloadBytes`** from 16 MB to ~1 MB once you know the real transaction size distribution. One constant in `TransferManifest`.
5. Nothing else from [`docs/plan/03-IF-PRODUCTION.md`](../../plan/03-IF-PRODUCTION.md) until there is a deployment to plan for.
