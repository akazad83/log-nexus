# Feature · POC security hardening

**Source plan:** [`docs/plan/`](../../plan/) (revised 2026-08-23 for the POC / transaction-only scope)
**Scope:** the seven items in [`docs/plan/01-DO-NOW.md`](../../plan/01-DO-NOW.md), broken into eight independently shippable phases
**Tracker:** [TRACKER.md](TRACKER.md)

**Baseline before any change:** `dotnet test tests/QrDiode.Core.Tests -c Release` → **75 passed / 0 failed** (2026-08-23, SDK 10.0.400).

---

## How the phases are ordered

Two rules drove the ordering, not the severity of the findings:

1. **Zero-risk before risky.** Build pinning and receiver-only bounds land first, so that by the time the wire format changes, the build is reproducible and the test suite has already been exercised against several small commits.
2. **Split the one wire change in two.** The plaintext-hash removal (P6) is the only change that requires both endpoints to be rebuilt together. P5 does all the *consumer* rework with the field still on the wire — fully backward compatible, provably safe — so P6 is reduced to deleting a field and shifting three offsets.

Phases P1–P5 and P7–P8 are independently revertible. P6 is the one that is not.

---

## Phases

### P1 · Pin the build
**Files:** `global.json`, `Directory.Build.props`
**Why:** no SDK pin and no lock files today, so "it built on the demo laptop" is not a reproducible statement. The six dependencies include three native blobs (`ZXingCpp`, `FlashCap`, SQLite) that arrive unpinned from NuGet.
**Risk:** none. Additive; per-project properties still win.

### P2 · Bound the manifest sanity envelope
**Files:** `src/QrDiode.Core/Manifest/TransferManifest.cs`
**Why:** `TryParse` validates `K == ceil(ciphertextSize / symbolSize)` but never bounds `K`, and accepts `symbolSize = 1`. A signed manifest declaring 128 MB with `symbolSize = 1` makes `LtDecoder` + `RobustSoliton` allocate ~3.2 GB *at manifest acceptance*, before a single data symbol arrives.
**Change:** payload ceiling 128 MB → 16 MB; `K ≤ 16384`; symbol-size floor `min(256, ciphertextSize)`; symbol-size ceiling derived from the frame cap rather than a sender option.
**Risk:** low. 16 MB is ~13 minutes of air time at this channel's throughput, so nothing usable is excluded. Production transaction-only should tighten it further to ~1 MB.
**No wire change.**

### P3 · Cap the stored filename length
**Files:** `src/QrDiode.Receiver/Storage/PayloadStore.cs`
**Why:** a genuine bug, no attacker needed. `MaxFilenameBytes` is 255 and `SanitizeFilename` never shortens; the stored component gets a 33-character GUID prefix, so 255 + 33 = 288 exceeds the NTFS 255-character component limit. `File.Move` throws `PathTooLongException`, which is not handled at the store, and a fully verified payload lands as `store_failed` with no retry possible on a one-way channel.
**Risk:** low. Truncation is deterministic and the untruncated name is still recorded in the sidecar.
**No wire change.**

### P4 · Bound the collections that grow without limit
**Files:** `src/QrDiode.Core/Fountain/LtDecoder.cs`, `src/QrDiode.Core/Pipeline/ReceiveEngine.cs`
**Why:** `_seenSymbolIds` and `_buffered` grow across the 2³² symbol-ID space; `_settled` grows once per session for the life of the process.
**Risk:** the highest of the receiver-only phases, because eviction discards information a decoder might need. Mitigated by generous caps (`_buffered` at `max(4 × K, 1024)`) that a normal session never approaches, and by a test asserting a lossy loopback never evicts.
**No wire change.**

### P5 · Move the plaintext hash off the manifest (consumers)
**Files:** `src/QrDiode.Core/Pipeline/ReceiveEngine.cs`, `src/QrDiode.Receiver/**`
**Why:** preparation for P6. `CompletedTransfer` gains a locally computed `PlaintextSha256`; all ten receiver consumers read it from there instead of from the manifest.
**Risk:** none. The manifest field and its verification check are untouched, so behaviour is identical.
**No wire change.**

### P6 · Remove the plaintext hash from the wire
**Files:** `src/QrDiode.Core/Framing/FrameFormat.cs`, `src/QrDiode.Core/Manifest/TransferManifest.cs`, `src/QrDiode.Core/Pipeline/*`, `docs/SECURITY_REVIEW.md`
**Why:** the manifest is signed but not encrypted, so `SHA-256(plaintext)` is readable by anyone filming the screen. For small, structured, low-entropy transaction payloads that is a plaintext-recovery oracle, not just a metadata leak — an observer who knows the schema enumerates candidates and matches the hash. The field is redundant: plaintext authenticity already follows from the signed ciphertext hash, AES-GCM under an AAD rebuilt from the signed manifest, and the hard-capped deterministic Brotli decode.
**Change:** delete the 32-byte field at offset 165, shift the three fields after it, `FixedSize` 199 → 167, protocol version `0x01` → `0x02`.
**Risk:** the only breaking change. Both endpoints must be rebuilt; **receiver first** — between the two deployments nothing transfers and the sender cannot tell, because there is no back-channel.
**Honest cost:** a Brotli decompression bug producing wrong-but-correctly-sized output would no longer be caught. The length check against the signed `OriginalSize` remains.

### P7 · Make the opaque-file path an explicit choice
**Files:** `src/QrDiode.Core/Pipeline/ContentGate.cs` and its call site
**Why:** production will carry JSON/XML only. `ContentKind.File` passes through the gate uninterpreted, so today the honest statement is "XML and JSON are validated, everything else is trusted because the signature verified". A flag makes it "every payload that reaches the store has been parsed".
**Decision deferred to the operator:** the switch defaults to **allowed**, so the demo's file-send keeps working. Flip one boolean for the transaction-only profile.
**No wire change.**

### P8 · Make demo provisioning unmissable
**Files:** `src/QrDiode.Sender/MainWindow.*`, `src/QrDiode.Receiver/MainWindow.*`
**Why:** `DemoProvisioner` creates **both** endpoints' private keys on one machine and cross-trusts them. Every mechanism runs at full strength — nothing is stubbed — but the receiver is trusting a sender whose private key sits on the receiver. The apps look identical whether provisioned by demo or by ceremony. The risk is a demo instance mistaken for a real one.
**Change:** a persistent banner while demo identities are loaded — not a toast, not startup-only. The sender already has a demo strip; make it permanent and mirror it on the receiver, which today only logs once.
**Deliberately not doing:** compiling the demo path out. This is a demo tool; removing it removes the point.

---

## Out of scope

Everything in [`docs/plan/03-IF-PRODUCTION.md`](../../plan/03-IF-PRODUCTION.md): forward secrecy, per-symbol MACs, descriptor encryption, ACL hardening, keyed audit, capture sandboxing, PQC, SBOM/WDAC/Authenticode, delivery-gap detection, strict replay window. Each is listed there with the condition that would promote it.

---

## Definition of done for each phase

1. Code change made.
2. `dotnet build -c Release` clean for the whole solution.
3. `dotnet test tests/QrDiode.Core.Tests -c Release` green, with any new tests included.
4. [TRACKER.md](TRACKER.md) updated: status, test count, and a one-line note on anything that surprised me.
5. Documentation updated where the change invalidates it (P6 only).
