"""Renders docs/SYSTEM_SUMMARY.md to a styled DOCX.

Usage: python docs/generate_summary_docx.py
Requires: python-docx

Reuses the same rendering conventions as generate_docx.py (the security-review
generator) so the two document families look like one family.
"""
import re
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ACCENT = RGBColor(0x1F, 0x3A, 0x5F)      # dark steel blue
ACCENT_HEX = "1F3A5F"
CODE_COLOR = RGBColor(0x8B, 0x2F, 0x2F)
MUTED = RGBColor(0x55, 0x55, 0x55)

TOKEN = re.compile(r"(\*\*.+?\*\*|`[^`]+`|\*[^*\s][^*]*\*|\[[^\]]+\]\([^)]+\))")
LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def add_runs(par, text, bold=False, size=None):
    for piece in TOKEN.split(text):
        if not piece:
            continue
        if piece.startswith("**") and piece.endswith("**"):
            run = par.add_run(piece[2:-2])
            run.bold = True
        elif piece.startswith("`") and piece.endswith("`"):
            run = par.add_run(piece[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt((size or 10.5) - 1)
            run.font.color.rgb = CODE_COLOR
        elif piece.startswith("*") and piece.endswith("*") and len(piece) > 2:
            run = par.add_run(piece[1:-1])
            run.italic = True
        elif LINK.fullmatch(piece):
            run = par.add_run(LINK.fullmatch(piece).group(1))
            run.italic = True
        else:
            run = par.add_run(piece)
        if bold:
            run.bold = True
        if size and run.font.size is None:
            run.font.size = Pt(size)


def shade_cell(cell, hex_color):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_color)
    tc_pr.append(shd)


def add_field(par, instruction, placeholder=""):
    run = par.add_run()
    begin = OxmlElement("w:fldChar"); begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    sep = OxmlElement("w:fldChar"); sep.set(qn("w:fldCharType"), "separate")
    end = OxmlElement("w:fldChar"); end.set(qn("w:fldCharType"), "end")
    run._r.append(begin); run._r.append(instr); run._r.append(sep)
    if placeholder:
        t = OxmlElement("w:t"); t.text = placeholder
        run._r.append(t)
    run._r.append(end)


def style_document(doc):
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    for name, size in [("Heading 1", 15), ("Heading 2", 12.5), ("Heading 3", 11)]:
        st = doc.styles[name]
        st.font.name = "Calibri"
        st.font.size = Pt(size)
        st.font.color.rgb = ACCENT
        st.font.bold = True
    for section in doc.sections:
        section.left_margin = section.right_margin = Inches(0.9)
        footer_par = section.footer.paragraphs[0]
        footer_par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = footer_par.add_run(doc._footer_label + "  ·  page ")
        run.font.size = Pt(8); run.font.color.rgb = MUTED
        add_field(footer_par, "PAGE", "1")
        run = footer_par.add_run(" of ")
        run.font.size = Pt(8); run.font.color.rgb = MUTED
        add_field(footer_par, "NUMPAGES", "1")
        for r in footer_par.runs:
            r.font.size = Pt(8)
            r.font.color.rgb = MUTED


def cover(doc, title, subtitle, meta_rows):
    for _ in range(5):
        doc.add_paragraph()
    p = doc.add_paragraph()
    run = p.add_run(title)
    run.font.size = Pt(26); run.bold = True; run.font.color.rgb = ACCENT
    p = doc.add_paragraph()
    run = p.add_run(subtitle)
    run.font.size = Pt(13); run.font.color.rgb = MUTED
    doc.add_paragraph()
    table = doc.add_table(rows=len(meta_rows), cols=2)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, (k, v) in enumerate(meta_rows):
        c0, c1 = table.cell(i, 0), table.cell(i, 1)
        c0.text, c1.text = "", ""
        add_runs(c0.paragraphs[0], k, bold=True, size=9.5)
        add_runs(c1.paragraphs[0], v, size=9.5)
        shade_cell(c0, "EDF1F7")
        c0.width = Inches(1.7); c1.width = Inches(4.6)
    doc.add_page_break()
    p = doc.add_paragraph()
    run = p.add_run("Contents")
    run.font.size = Pt(15); run.bold = True; run.font.color.rgb = ACCENT
    toc_par = doc.add_paragraph()
    add_field(toc_par, 'TOC \\o "1-3" \\h \\z \\u',
              "Table of contents — in Word: select this line, press F9 (or right-click → Update Field).")
    doc.add_page_break()


def add_code_line(doc, raw):
    """One line of a fenced code block, rendered verbatim in monospace.

    Leading whitespace is preserved with non-breaking spaces — Word collapses runs of
    ordinary spaces, which would destroy the ASCII architecture/sequence diagrams.
    """
    par = doc.add_paragraph()
    pf = par.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.left_indent = Inches(0.2)
    text = raw.rstrip()
    indent = len(text) - len(text.lstrip(" "))
    run = par.add_run(" " * indent + text.lstrip(" ") if text else " ")
    run.font.name = "Consolas"
    run.font.size = Pt(8)
    run.font.color.rgb = CODE_COLOR


def flush_table(doc, rows):
    if not rows:
        return
    cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    cells = [r for r in cells if not all(re.fullmatch(r":?-{2,}:?", c or "---") for c in r)]
    if not cells:
        return
    ncols = max(len(r) for r in cells)
    table = doc.add_table(rows=len(cells), cols=ncols)
    table.style = "Table Grid"
    table.autofit = True
    for i, row in enumerate(cells):
        for j in range(ncols):
            text = row[j] if j < len(row) else ""
            cell = table.cell(i, j)
            cell.paragraphs[0].text = ""
            add_runs(cell.paragraphs[0], text, bold=(i == 0), size=8.5)
            if i == 0:
                shade_cell(cell, ACCENT_HEX)
                for run in cell.paragraphs[0].runs:
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            elif i % 2 == 0:
                shade_cell(cell, "F3F6FA")
            for par in cell.paragraphs:
                par.paragraph_format.space_after = Pt(2)
                par.paragraph_format.space_before = Pt(2)
    doc.add_paragraph()


def render(src, dst, title, subtitle, meta_rows, footer_label):
    doc = Document()
    doc._footer_label = footer_label
    style_document(doc)
    cover(doc, title, subtitle, meta_rows)

    with open(src, encoding="utf-8") as f:
        lines = f.read().splitlines()

    table_buf = []
    skipped_title = False
    in_code = False
    for line in lines:
        stripped = line.strip()

        if stripped.startswith("```"):
            flush_table(doc, table_buf)
            table_buf = []
            in_code = not in_code
            continue
        if in_code:
            add_code_line(doc, line)
            continue

        if stripped.startswith("|"):
            table_buf.append(stripped)
            continue
        flush_table(doc, table_buf)
        table_buf = []

        if not stripped or stripped == "---":
            continue
        if stripped.startswith("# ") and not skipped_title:
            skipped_title = True  # cover page already carries the title
            continue
        if stripped.startswith("## "):
            doc.add_heading(re.sub(r"[*`]", "", stripped[3:]), level=1)
        elif stripped.startswith("### "):
            h = doc.add_heading("", level=2)
            add_runs(h, stripped[4:].replace("**", ""))
            for run in h.runs:
                run.font.color.rgb = ACCENT
        elif stripped.startswith("> "):
            par = doc.add_paragraph()
            par.paragraph_format.left_indent = Inches(0.3)
            add_runs(par, stripped[2:])
            for run in par.runs:
                run.font.color.rgb = MUTED
                run.italic = True
        elif stripped.startswith("- "):
            par = doc.add_paragraph(style="List Bullet")
            add_runs(par, stripped[2:])
        elif re.match(r"^\d+\.\s", stripped):
            par = doc.add_paragraph(style="List Number")
            add_runs(par, re.sub(r"^\d+\.\s", "", stripped))
        elif stripped.startswith("**") and stripped.endswith("**") and stripped.count("**") == 2:
            par = doc.add_paragraph()
            add_runs(par, stripped)
        else:
            par = doc.add_paragraph()
            add_runs(par, stripped)

    flush_table(doc, table_buf)
    doc.save(dst)
    print("written", dst)


BASE = r"d:\WORKSPACE\qr-code\docs"

render(
    src=BASE + r"\SYSTEM_SUMMARY.md",
    dst=BASE + r"\SYSTEM_SUMMARY.docx",
    title="QrDiode — System Summary",
    subtitle="Workspace-grounded system summary · one-way optical data diode (OT → IT) over animated QR codes",
    meta_rows=[
        ("Scope", "Descriptive summary — architecture, transfer process, fountain coding, security"),
        ("Basis", "d:\\WORKSPACE\\qr-code as of 2026-08-23 — source, config, and docs only"),
        ("Audience", "Executives, product/ops stakeholders, and engineers"),
        ("Method", "Every claim cited to a workspace file; undocumented items marked as such"),
        ("Companions", "docs/ARCHITECTURE.md · docs/USER_GUIDE.md · docs/SECURITY_REVIEW_V3.md"),
    ],
    footer_label="QrDiode System Summary (2026-08-23)",
)
