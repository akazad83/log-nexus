# QrDiode — Security Design Summary

**Cryptographic construction, enforced controls and trust boundaries of the OT→IT optical transfer path.**
*Audience: security architects, reviewers and OT/IT infrastructure engineers.*

---

## 1. Scope and trust boundaries

QrDiode moves transactional payloads (XML, JSON, opaque files) from an OT host to an IT host across an optical air gap: the OT host renders fountain-coded frames as animated QR codes, the IT host films them. There is no network path and no back-channel — neither application contains networking code, and the only outward interfaces are a display, a camera and local disk.

The gap removes network reachability. The controls below address what remains: passive optical capture, active injection of a rogue QR stream into the camera's field of view, replay of a recorded stream, and hostile content inside a structurally valid transfer.

| Boundary | Trusted | Not trusted |
|---|---|---|
| OT host | Operator, local key store, local audit log | The payload's own content — formatted for display with hardened parsers |
| Optical channel | Nothing | Every photon: any party may film it, and any party may present a substitute stream to the camera |
| IT host | Local key store, trust store, journal, audit log | Every decoded frame, manifest field, filename and payload byte, until the full chain passes |
| Provisioning | One-time, out-of-band, human-verified exchange of public bundles on removable media | Any in-band key establishment — none exists |

---

## 2. Cryptographic and technology inventory

All primitives are in-box .NET / Windows implementations; no third-party cryptographic library is in the dependency graph. Naming a specification indicates provenance — it is not a claim of certification or compliance.

| Function | Primitive and parameters | Provenance |
|---|---|---|
| Manifest authenticity | **ECDSA over NIST P-256**, SHA-256; 64-byte raw `r‖s` | FIPS 186 family; IEEE 1363 encoding |
| Key agreement | **Static–static ECDH on P-256**; raw 32-byte secret | NIST SP 800-56A, C(0e, 2s) |
| Key derivation | **HKDF-SHA-256**; salt = 32 random bytes, info = `"QrDiode.v1" ‖ sessionId`, output 32 bytes | RFC 5869 |
| Payload confidentiality + integrity | **AES-256-GCM**; 12-byte nonce, 16-byte tag, 72-byte AAD | FIPS 197; NIST SP 800-38D |
| Hashing | **SHA-256** — ciphertext digest, receiver-side plaintext digest, key IDs, audit-chain links, receipt, bundle fingerprint | FIPS 180-4 |
| Frame error detection | **CRC-32** (reflected zlib/IEEE 802.3) over all preceding frame bytes | Non-cryptographic pre-filter, never a trust decision |
| Randomness | OS CSPRNG — session GUID, salt, nonce, fountain seed | .NET `RandomNumberGenerator` |
| Erasure-code PRNG | **splitmix64-seeded xoshiro256++**, deterministic across platforms | Not a security primitive: symbol degree/neighbour sets only, never key material |
| Private-key storage | **Windows CNG** named keys, `ExportPolicy = None`; **Platform Crypto Provider (TPM)** preferred, Software KSP fallback | Windows CNG / TPM |
| Local secret at rest | **DPAPI**, CurrentUser scope, app-specific entropy (send counter) | Windows DPAPI |
| Compression | **Brotli**, before encryption, kept only if smaller | RFC 7932 |
| Optical carrier | **QR Code**, byte mode, ECC level **L**, smallest version fitting the session's largest frame | ISO/IEC 18004 |
| Loss tolerance | **Systematic Luby-Transform fountain code**, robust soliton (c = 0.1, δ = 0.05) | LT codes; in-house implementation |
| Anti-replay store | **SQLite** (WAL, `synchronous = FULL`), transactional | — |

**Key management.** Each endpoint holds two long-term P-256 pairs — ECDSA signing and ECDH agreement — generated on the host that uses them, non-exportable, TPM-backed where available; no code path exports a private key. Public bundles (DER SubjectPublicKeyInfo, base64 in a strict JSON envelope) are hand-carried and imported; import prints an eight-group fingerprint, `SHA-256(signingSPKI ‖ agreementSPKI)` truncated to 16 bytes, for verbal comparison, and refuses to overwrite an existing entry so keys cannot be silently replaced. Peers are indexed by key ID = `SHA-256(SPKI)` truncated to 8 bytes — a lookup index that never substitutes for signature verification. The shared secret and derived AES key are zeroed after use; the sender's monotonic counter is DPAPI-protected, written temp-then-rename, and reserved **before** the session that uses it exists.

---

## 3. Per-transfer construction and binding

**Sender, fixed order:** reserve and persist the counter → Brotli-compress (keep the smaller form) → derive `K_s = HKDF-SHA256(ECDH(sender_priv, receiver_pub), salt, info)` → `AES-256-GCM(K_s, nonce, compressed, AAD)` → `SHA-256(ciphertext)` into the manifest → ECDSA-sign the serialized manifest body → LT-encode and render.

```mermaid
flowchart LR
    subgraph M["📄 Signed manifest body — 167 B + filename"]
        direction TB
        F1["sessionId (16) · timestamp (8) · counter (8)<br/>senderSigningKeyId (8) · receiverAgreementKeyId (8)"]
        F2["salt (32) · nonce (12)<br/>symbolSize · K · fountain seed · redundancy"]
        F3["sizes: original · compressed · ciphertext · alg<br/>contentType · filename (≤255 B)"]
        F4["SHA-256(ciphertext) — 32 B"]
    end

    SIG["🔏 ECDSA P-256<br/>64 B over the exact body bytes"]
    AAD["🔗 GCM AAD — 72 B<br/>sessionId ‖ salt ‖ counter<br/>‖ sigKeyId ‖ kexKeyId"]
    CT["🔒 AES-256-GCM<br/>ciphertext ‖ tag (16 B)"]

    M ==>|"signed as a whole"| SIG
    M ==>|"fields reconstruct"| AAD
    AAD ==>|"authenticates"| CT
    F4 -.->|"must equal SHA-256 of<br/>the reassembled bytes"| CT

    classDef man fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef sec fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    class F1,F2,F3,F4 man;
    class SIG,AAD,CT sec;
    style M fill:#FFF7EF,stroke:#E0A96D
```

*Figure 1 — The manifest is signed as a whole, its fields reconstruct the GCM associated data, and it carries the digest of the ciphertext it describes.*

The binding is two-directional and non-circular: a foreign manifest cannot be paired with a substituted ciphertext (the signed digest fails), and a foreign ciphertext cannot be opened under a borrowed manifest (the AAD, rebuilt from signed fields, fails the tag check).

**Receiver — strict order, nothing later runs until the earlier step passes:**

1. Frame structure and CRC-32 — span-based, allocation-free on rejection
2. Manifest structural parse against the acceptance envelope
3. Sender key ID present in the trust store
4. ECDSA verification over the exact received body bytes — **no payload byte is interpreted before this**
5. Manifest addressed to this receiver's agreement key ID
6. Anti-replay: unseen session GUID **∧** counter strictly above the per-sender-key watermark **∧** timestamp inside the acceptance window
7. LT decode to completion → `SHA-256(ciphertext)` equals the signed digest
8. AES-256-GCM open with AAD rebuilt from the signed manifest
9. Brotli decompression hard-capped at the signed original size, required to terminate exactly there
10. Plaintext length equals the signed original size
11. Content gate (§5)
12. Commit: anti-replay record and journal row transactionally, then atomic materialization, then audit entry

Every failure is terminal for that session: nothing is written, the reason is recorded in the operator inbox, the archive index and the audit log, and the session ID is settled so the sender's continuing carousel is ignored rather than re-judged.

---

## 4. How the layers combine

| Attack | Controls that apply | Result |
|---|---|---|
| Passive capture of the OT screen | AES-256-GCM under a key derivable only with the addressed receiver's agreement private key | Ciphertext only; manifest metadata stays observable (§6) |
| Rogue QR stream at the camera | Trust-store lookup by key ID → ECDSA verification before any payload interpretation | Unknown sender dropped and audited; the decoder is never constructed |
| Manifest spliced onto foreign ciphertext | Signed ciphertext digest + AAD rebuilt from signed fields | Digest mismatch or tag failure |
| Replay of a recorded stream | Session-GUID uniqueness ∧ per-key monotonic counter ∧ timestamp window, persisted transactionally | All three must pass |
| Forged or corrupted data symbols | Not individually authenticated; integrity is collective via signed digest and GCM tag | Cannot forge accepted content; can deny completion (availability only) |
| Malformed frames, parser abuse | Up-front length checks, fixed offsets, Try-pattern with no exceptions or allocation on reject, 4096-byte ceiling, protocol-version gate | Rejected at near-zero cost; version mismatch fails cleanly, never mis-slices |
| Allocation amplification via manifest fields | Envelope validated **before** decoder construction: payload ≤ 16 MiB, 256 ≤ symbolSize ≤ 4076, K ≤ 65 536, K = ⌈ciphertext/symbolSize⌉, ciphertext = compressed + 16 | No multi-gigabyte allocation is reachable |
| Unbounded decoder growth over long air time | Buffered symbols capped at clamp(4K, 1024, 8192); seen IDs at clamp(16K, 4096, 131072); evictions counted | Bounded memory; a decode that discarded equations cannot look clean |
| Decompression bomb | Output buffer sized to the signed original size; stream must end exactly there | Fails closed |
| XXE, entity expansion, deep nesting | `DtdProcessing.Prohibit`, `XmlResolver = null`, `MaxCharactersFromEntities = 0`, depth ≤ 64; JSON depth ≤ 64, comments and trailing commas rejected | Rejected after crypto verification, before storage |
| Path traversal, reserved names, long paths | Character sanitization, 120-char cap, session-GUID prefix, store-root path budget checked at start, `File.Move` without overwrite | Sender-supplied names cannot escape or collide |
| Duplicate delivery | Session-GUID dedupe plus per-sender plaintext-digest dedupe | Idempotent; journaled as duplicate, not re-materialized |
| Audit tampering | Append-only JSONL, each record embedding `SHA-256` of the previous; verifier returns the first broken index | Detectable and localized |
| Long-term key theft | Non-exportable CNG keys, TPM-backed where available; only public bundles leave a host | No export path in the applications |

Two ordering choices carry most of the weight. **Identity precedes interpretation:** the fountain decoder is not instantiated until a signature from a provisioned peer verifies over the exact bytes received, so the surface reachable by an unauthenticated party is only the frame parser and the manifest bounds check — both allocation-free and constant-shaped. **Cheap precedes expensive:** CRC-32 filters camera noise and misdecodes before any asymmetric operation is spent.

---

## 5. Supporting controls

**Capture and content.** The QR reader is configured narrowly — QR format only, no rotation, inversion or "try harder", at most two symbols per frame — and frames arriving while a decode is in flight are dropped rather than queued, bounding work per unit time. Structural validation runs after all cryptographic checks and before the payload leaves staging; opaque files are accepted without interpretation in the shipped receiver, and a constructor switch makes it refuse them outright. Payload viewers on both hosts format *unvalidated* input, so they reuse the same DTD-prohibited, depth-capped parser settings.

**Storage and evidence.** Verified plaintext is written to staging inside the store root (same volume, so the rename cannot degrade into a copy), flushed to disk, then renamed without overwrite; writability and path budget are proven at run start. The anti-replay watermark and a `verified` journal row commit transactionally at verification, and the row is promoted to `stored` or `duplicate` after materialization — so a crash in between is visible as a `verified` row with no file. Every judged arrival, rejections included, is indexed for search, and any stored file can be re-hashed against the digest recorded at verification. Each transfer yields a receipt, `SHA-256(manifest body ‖ signature)` truncated to 8 bytes, shown on both screens for out-of-band comparison. Demo provisioning (both identities on one host) raises a persistent, state-driven banner until those artifacts are removed from the trust store.

**Platform and supply chain.** Both applications target .NET 10 on Windows (WPF). The protocol core depends only on the BCL plus `System.IO.Hashing` and `System.Security.Cryptography.ProtectedData`; the receiver adds camera capture, a native QR decoder and SQLite, the sender a QR generator. Restore is lock-file-pinned with per-package content hashes and builds are deterministic — relevant because those three receiver dependencies ship native binaries. Camera capture and the QR decoder are also the only native components that process untrusted input; everything downstream of the decoded byte array is managed code.

---

## 6. Security-relevant properties and boundaries

Stated as facts about the current implementation, without recommendation.

- **No forward secrecy.** Key agreement is static–static; per-session separation comes from a random HKDF salt and the session GUID in the HKDF info, not from ephemeral keys. Compromise of a long-term agreement private key permits decryption of previously recorded sessions.
- **Metadata is signed but not encrypted.** Filename, content type, sizes, timestamp, counter and both key IDs are in the clear on screen, and because compression precedes encryption, ciphertext length reflects payload compressibility. The plaintext digest was deliberately removed from the wire (with a protocol-version bump, so older endpoints reject rather than mis-parse) because a digest of predictable transactional content is an enumeration oracle; the receiver computes it locally.
- **One message per key.** A random 12-byte nonce per session, under a key derived with a fresh random salt per session.
- **Data symbols carry no individual authentication.** Injected symbols matching a live session tag can prevent completion but cannot produce accepted content; a post-decode failure settles that session ID for the rest of the run, so recovery is a re-send under a new session — made safe by content-level deduplication.
- **Clock dependence.** The default strict acceptance window is ±15 minutes (±48 hours relaxed) and no time-sync path crosses the gap.
- **No revocation or expiry semantics.** Trust is removed by deleting a bundle; rotation is a new import, and counter watermarks are per key ID so rotation starts a fresh watermark.
- **Receiver default accepts opaque files**, so structural validation applies only to XML and JSON.
- **Single optical lane**, and **FIPS status is a platform property** — the primitives are in-box implementations; validated-mode operation depends on host configuration and is not asserted here.
