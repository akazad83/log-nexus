# 02 · Wire changes

Two sections. §1–§3 are the change I recommend now. §4–§5 are reference material for a decision you have not made.

---

## 1. The one change worth making: drop `PlaintextSha256`

Rationale and consumer analysis are in [01-DO-NOW.md](01-DO-NOW.md) D-1. This section is just the layout.

**Bump `FrameFormat.ProtocolVersion` to `0x02`** ([`FrameFormat.cs:11`](../../src/QrDiode.Core/Framing/FrameFormat.cs#L11)). Without the bump, a v1 receiver fed a v2 body would read `nameLen` from the wrong offset and *usually* reject on the length mismatch — but "usually" is not a protocol. With the bump it rejects cleanly at [`FrameParser.cs:46`](../../src/QrDiode.Core/Framing/FrameParser.cs#L46) as `BadVersion`.

### Manifest body v2

`TransferManifest.FixedSize`: **199 → 167**. Everything up to and including `CiphertextSha256` is unchanged; the three fields after it shift down by 32.

| Offset | Size | Field | Change |
|---|---|---|---|
| 0 | 16 | Session GUID | — |
| 16 | 8 | Timestamp (Unix ms) | — |
| 24 | 8 | Counter | — |
| 32 | 8 | Sender signing key ID | — |
| 40 | 8 | Receiver key-agreement key ID | — |
| 48 | 32 | HKDF salt | — |
| 80 | 12 | AES-GCM nonce | — |
| 92 | 2 | Symbol size | — |
| 94 | 4 | K | — |
| 98 | 8 | LT seed | — |
| 106 | 2 | Redundancy hint | — |
| 108 | 8 | Original size | — |
| 116 | 8 | Compressed size | — |
| 124 | 8 | Ciphertext size | — |
| 132 | 1 | Compression algorithm | — |
| 133 | 32 | SHA-256 of ciphertext | — |
| ~~165~~ | ~~32~~ | ~~SHA-256 of plaintext~~ | **removed** |
| 165 | 1 | Content kind | was 197 |
| 166 | 1 | Filename length | was 198 |
| 167 | ≤255 | Filename (UTF-8) | was 199 |

Manifest frame length stays `82 + bodyLen`, so `FrameFormat.ManifestOverhead` and the parser's length check ([`FrameParser.cs:77-78`](../../src/QrDiode.Core/Framing/FrameParser.cs#L77-L78)) are unchanged — they are already generic over `bodyLen`.

### Code changes

| File | Change |
|---|---|
| [`FrameFormat.cs:11`](../../src/QrDiode.Core/Framing/FrameFormat.cs#L11) | `ProtocolVersion = 0x02` |
| [`TransferManifest.cs:28`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L28) | `FixedSize = 167` |
| [`TransferManifest.cs:46`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L46) | delete the `PlaintextSha256` property |
| [`TransferManifest.cs:77-80`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L77-L80) | delete the write; shift `span[197]`→`span[165]`, `span[198]`→`span[166]` |
| [`TransferManifest.cs:93-99`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L93-L99) | `body[198]`→`body[166]`, `body[197]`→`body[165]` |
| [`TransferManifest.cs:143`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L143) | delete the parse |
| [`SendSession.cs:65`](../../src/QrDiode.Core/Pipeline/SendSession.cs#L65), [`:114`](../../src/QrDiode.Core/Pipeline/SendSession.cs#L114) | the local `plaintextHash` is no longer needed for the manifest |
| [`ReceiveEngine.cs:21-26`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L21-L26) | `CompletedTransfer` gains `PlaintextSha256` |
| [`ReceiveEngine.cs:220-223`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L220-L223) | compute the hash once, keep the `OriginalSize` length check, drop the comparison |
| receiver UI / store / journal | read the hash from `CompletedTransfer` instead of the manifest — 10 call sites, listed in [01-DO-NOW.md](01-DO-NOW.md) D-1 |

### What the verification chain looks like afterwards

Step 8 in `SECURITY_REVIEW.md` §3.4 ("SHA-256(plaintext) equals the signed hash") becomes a length check only. The chain still fails closed everywhere, and plaintext authenticity still follows from steps 5–7: the ciphertext hash is signed, GCM authenticates under an AAD rebuilt from the signed manifest, and Brotli output is hard-capped at the signed size.

**The honest loss:** a Brotli decompression bug producing wrong-but-correctly-sized output would no longer be caught. Weigh that against a hash oracle on the wire. If you would rather keep belt and braces, the alternative is to keep the plaintext hash but move it inside the encrypted payload — which is §4's descriptor work and much more expensive.

**Update your documentation too.** `SECURITY_REVIEW.md` §3.1 documents the 199-byte layout with `PlaintextSha256` at offset 165, and §3.4 step 8 describes the check. Both become wrong the moment this ships.

---

## 2. Also worth doing in the same commit

Since both ends are being rebuilt anyway, fold in the receiver-side bounds from [01-DO-NOW.md](01-DO-NOW.md) D-2. They need no wire change, but they touch the same parse function and shipping them together means one migration instead of two.

---

## 3. Upgrade order — receiver first

This matters even for a two-machine demo, because getting it backwards produces a failure that looks like a hardware problem.

```
1. Rebuild and deploy the RECEIVER.  It now rejects v1 frames as BadVersion.
2. Rebuild and deploy the SENDER.    It now emits v2.
3. Confirm one payload lands end to end.
```

Between steps 1 and 2 nothing transfers, and **the sender cannot tell** — there is no back-channel, so it will keep cycling its carousel happily while the receiver rejects every frame. On a demo rig that is a two-minute gap. On a deployed system it is why the order is a runbook step.

If you want to avoid the gap, have the receiver accept both versions for one release: dispatch on the version byte, keep the v1 parse path, and remove it later. For a POC that is probably not worth the extra code.

---

## 4. Reference: the fuller protocol v2 — **not recommended now**

Kept because if this POC ever productionises, `SECURITY_REVIEW_V2.md` §3 is the design you would build, and it has two problems that would cost someone a day to discover.

### 4.1 The key-derivation circularity (a real bug in the v2 spec)

`SECURITY_REVIEW_V2.md` §3 encrypts the manifest descriptor under the session key with `AAD = the public header`, and the natural implementation binds the key schedule to a hash of that header. **That cannot work:** the public header contains `ciphertextSha256`, which cannot be computed until the payload has been encrypted, which requires the payload key, which would require the header hash.

The fix is to split the header:

- **Region A — key establishment** (session GUID, timestamp, counter, both key IDs, salt, suite, ephemeral public key, KEM ciphertext). Fully determined before any encryption, so it can be hashed into HKDF.
- **Region B — coding and integrity** (nonce, symbol size, K, LT seed, redundancy, ciphertext size, ciphertext hash, descriptor length). Bound by the GCM AAD, which still covers the whole header.

Nothing ends up unbound; only the ordering of the binding changes.

### 4.2 The ephemeral public key is 65 bytes, not 33

`SECURITY_REVIEW_V2.md` §3 budgets a 33-byte compressed P-256 point. Compressed-point import is not reliably available on Windows CNG, and computing the decompression by hand means writing a modular square root — new hand-written crypto math in a project whose strongest supply-chain property is that it has none.

Carry the uncompressed X9.62 point (`0x04 ‖ X ‖ Y`) and pay the 32 bytes. Revised budget: a classic-suite v2 manifest frame is ~390 B typical, ~620 B worst case — comfortably inside the QR version the data frames already use ([`SendSession.cs:13`](../../src/QrDiode.Core/Pipeline/SendSession.cs#L13) notes V30-L at 1370 B), so manifest acquisition does not regress.

### 4.3 One requirement the v2 document does not state

In v1, every ECDH partner key comes from the offline-provisioned trust store. With an ephemeral share, the partner key arrives **on the wire**. P-256 has cofactor 1, so small-subgroup attacks do not apply, but invalid-curve attacks against the receiver's static key do.

In practice CNG validates the point when you import it, so the requirement is narrow: import through `ImportSubjectPublicKeyInfo` / `ImportParameters` and treat `CryptographicException` as a rejection. Do not switch to a raw-coordinate path that skips validation.

### 4.4 Post-quantum: recommended against

`SECURITY_REVIEW_V2.md` R-02c specifies hybrid ML-KEM-768. I repeated that recommendation in my first plan. **Withdrawing it.**

Harvest-now-decrypt-later is a threat when recorded ciphertext still has value once a cryptographically relevant quantum computer exists. Transaction records — a goods receipt, an asset reading, a batch confirmation — do not have that shelf life. The cost is concrete and immediate: a hybrid manifest is ~1.7 KB against ~390 B classic, which means a much denser manifest QR and measurably harder camera acquisition for the one frame a receiver must catch first.

If a customer's policy mandates a PQC roadmap, say it is on the roadmap, gated on the platform exposing validated ML-KEM. Do not build it into a POC.

---

## 5. Reference: everything else in the v2 register

Encrypted descriptor (R-01 in full), ephemeral-static key schedule (R-02a), receiver key rotation (R-02b), per-symbol HMACs (R-06a) — all sound, all disproportionate for a POC. They are listed with promotion conditions in [03-IF-PRODUCTION.md](03-IF-PRODUCTION.md).

The one thing to carry forward regardless of what you build: **there is no version negotiation on a one-way channel, and there never can be.** Every wire change is a coordinated deployment, receiver first. That constraint does not go away with more engineering.
