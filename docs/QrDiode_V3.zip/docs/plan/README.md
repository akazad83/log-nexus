# QrDiode — remediation plan (revised for the actual scope)

**Revised:** 2026-08-23, after being told the real context: this is a **POC built for demonstration**, and the production system will carry **transaction payloads (JSON/XML) only** — no file transfer.

**My first version of this plan was wrong-sized.** It planned a ~118 engineer-day programme with protocol redesign, process sandboxing, WDAC policies, service accounts and post-quantum cryptography. That is the plan for a commercial data-diode product going into a regulated OT environment. It is not the plan for a POC. This revision withdraws most of it.

---

## 1. Corrections to what I told you before

Stated plainly, because some of it was wrong and some was unsupported.

| What I said | The correction |
|---|---|
| "≈118 engineer-days", and per-item estimates like "5 d", "3 d" | **Invented.** I had no basis for any of those numbers. I have removed all day estimates and replaced them with rough sizes where I can defend them and nothing where I can't. |
| CI gates, SBOM diffing in CI, reproducible-build comparison in CI | **There is no CI, and no git repository** — I checked afterwards: `.git` does not exist in this workspace. I planned around infrastructure that isn't there without looking. Lock files still help without CI; the rest of that section assumed a pipeline you don't have. |
| Hybrid ML-KEM-768 post-quantum encapsulation (Phase 3) | **Withdrawn.** Harvest-now-decrypt-later is a threat when the recorded data still has value in 10+ years. Transaction records — a goods receipt, a batch reading — do not. I recommended this because the review document recommended it, not because I thought about your data. |
| "Compile demo provisioning out of production builds" (F-05) | **Backwards for your case.** You built this *as* a demo. Removing the demo path removes the product's current purpose. The real risk is a demo instance being mistaken for a real one — which is fixed by making the demo state unmissable, not by deleting it. |
| ".NET has no in-box point decompression" | **Overstated.** `ImportSubjectPublicKeyInfo` may accept a compressed point depending on platform; Windows CNG historically does not. My conclusion (carry the uncompressed 65-byte point) still holds, but the reason I gave was too absolute. |
| N-02, N-03, N-05 rated "Medium" | **Overrated for this context.** All three need either a valid signature from a key already in your trust store, or code already running on the machine. On a demo rig you control, that is not a threat — they are cheap robustness fixes, not findings. |
| "Invalid-curve validation is a hard requirement" | Real, but I made it a headline. CNG validates the point on import already. The actual requirement is one line: *don't switch to a raw-coordinate import path that skips it.* Only relevant if you ever do the ephemeral-key work at all. |
| `TreatWarningsAsErrors` + `AnalysisMode=All` | Would produce a large diagnostic backlog on a WPF codebase for very little security value. Not worth it here. |

**What I stand behind from the first version:**

- The five code defects (now renumbered D-1…D-5 in [01-DO-NOW.md](01-DO-NOW.md)) are real, with line-level evidence. Their *severity* was inflated; their *existence* was not.
- The key-derivation circularity in `SECURITY_REVIEW_V2.md` §3 is real and would have blocked anyone implementing that spec as written. Recorded in [02-WIRE-CHANGES.md](02-WIRE-CHANGES.md) §4.
- If you ever change the wire format, the receiver must be upgraded before the sender. That one is not negotiable and costs nothing to remember.

---

## 2. Honest assessment of where the POC actually stands

The v1 review's core judgement is correct and I am not walking it back: **the protocol design is genuinely good** — better than the norm for this class of tool. Signature-before-parse, AEAD with AAD binding the session identity, three-factor anti-replay from a transactional store, fail-closed at every step, no network API anywhere in `src/`, no third-party crypto. I verified all of that in source. For a POC, that is a strong starting position, and most of the v1 findings are about the *environment around* the protocol, not the protocol.

For a **demo**, the honest gap list is short:

1. **The plaintext SHA-256 is on the wire in the clear** ([`TransferManifest.cs:77`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L77)). This is the only field that can leak payload *content* rather than metadata, and for small structured transaction payloads that matters more than it does for files. It is also the cheapest thing on this list to fix, because it is redundant. This is my top recommendation.
2. **Several attacker-influenced allocations are unbounded** relative to your actual payload profile — a 128 MB envelope for payloads that are mostly single-digit KB. Six lines of bounds.
3. **The `File` content kind exists in a system that will never transfer files.** Dead weight that a reviewing architect will ask about.
4. **Three small code defects** that will bite in ordinary operation, not under attack.

For **production** — if this POC ever becomes a deployed system — the v1 and v2 review documents are the right reference and my first plan's content is roughly right in *substance*, just not in *urgency*. That material is summarised, not deleted, in [03-IF-PRODUCTION.md](03-IF-PRODUCTION.md).

---

## 3. Documents

| Document | What it is |
|---|---|
| [01-DO-NOW.md](01-DO-NOW.md) | The short list worth doing on the POC. Concrete, code-level, small. Roughly a week of work in total, most of it in hours not days. |
| [02-WIRE-CHANGES.md](02-WIRE-CHANGES.md) | The one wire change I recommend now (remove the plaintext hash), specified exactly. Plus the fuller protocol-v2 design kept as a reference for later, with the two corrections to the v2 review document. |
| [03-IF-PRODUCTION.md](03-IF-PRODUCTION.md) | Everything I withdrew, listed honestly with the condition that would make each one worth doing. No estimates, no schedule — it is a checklist for a decision you have not made yet. |

---

## 4. What I am explicitly recommending you do **not** do now

Because "comprehensive" was the wrong instinct and the honest advice is mostly subtraction:

- **Do not implement protocol v2 in full.** Encrypted descriptor, ephemeral ECDH, per-symbol MACs — all defensible for a product, all disproportionate for a POC. One 32-byte deletion gets you the bulk of the confidentiality benefit.
- **Do not sandbox the capture process.** It is weeks of work, it needs a NativeAOT spike that may fail, and the threat it addresses (a memory-safety bug in zxing-cpp, triggered by someone controlling what your camera sees) requires physical access to your demo rig.
- **Do not add service accounts, ACL hardening, trust-index MACs or journal tripwires.** These assume a hostile multi-user host. A demo laptop is not that.
- **Do not add post-quantum cryptography.** See §1.
- **Do not add WDAC/AppLocker, Authenticode signing, or SBOM tooling.** These are deployment controls for a system that has a deployment.
- **Do not add per-symbol HMACs.** They defend against someone shining a projector at your camera mid-session. Note the risk in your documentation; do not build the defence yet.

Each of these is genuinely the right thing to do *if and when* this becomes a deployed OT→IT gateway. None of them is the right thing to do to a POC.

---

## 5. One thing worth knowing about your documentation

`docs/SECURITY_REVIEW.md` and `docs/SECURITY_REVIEW_V2.md` are written as if this were a production system under external security review — v2 even addresses "external security reviewers" and commits to remediations as "engineering commitments". If those documents travel with the POC to a customer, they will set an expectation that the POC is a product.

That is a positioning question, not a technical one, and it is yours to make. But if the answer is "this is a POC", the reviews should say so in their scope line. Right now neither of them does, and v2's §5 closing statement ("suitable for pilot/controlled deployment only") is the closest either gets.
