# 01 · What is worth doing on the POC

Seven items. Every one is small, every one is justified by the code, and none of them assumes a threat model larger than "this is a demo that might be shown to a customer's security architect".

Rough total: a few days. Items 1 and 2 are most of the value.

---

## D-1 · Remove `PlaintextSha256` from the manifest — **highest value, low cost**

**The problem.** The manifest is signed but not encrypted, and it carries `SHA-256(plaintext)` in the clear at offset 165 ([`TransferManifest.cs:77`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L77), [`:143`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L143)). Anyone who can film the screen gets that hash.

For file transfer, that means "confirm whether a known document was sent". For **small structured transaction payloads it is potentially worse**: if an observer knows your message schema and the fields are drawn from small ranges, they can enumerate candidate payloads and match the hash — recovering the exact content of a message they could not decrypt.

**Be honest about when this actually bites.** It depends entirely on payload entropy:

- A payload with a millisecond timestamp plus a random reference (your simulator generates a 6-byte random `trackingRef`, [`PayloadSimulator.cs:182`](../../src/QrDiode.Core/Simulation/PayloadSimulator.cs#L182)) has ~48+ bits of unpredictability. Brute force is infeasible. **Not a problem.**
- A payload that is fully determined by known fields — a meter reading with a coarse timestamp, an asset ID from a fixed list, and a value from a small range — is enumerable in seconds. **That is plaintext recovery.**

Only you know which your production transactions look like. But the fix costs almost nothing, so the entropy question does not need answering.

**Why it is free to remove.** The plaintext hash is redundant for integrity. The chain already proves the plaintext is authentic without it:

```
signed manifest carries SHA-256(ciphertext)  →  ciphertext verified before decrypt
AES-256-GCM opens with AAD rebuilt from the signed manifest  →  compressed bytes authentic
Brotli decompression is deterministic and hard-capped at the signed OriginalSize
length check against OriginalSize survives
```

The only thing lost is a guard against a Brotli decompression bug producing wrong-but-plausible output. That is a real but negligible loss.

**Every consumer can compute it locally.** I checked all 17 usages: every one runs *after* decryption completes.

| Consumer | Where | Fix |
|---|---|---|
| Plaintext hash check | [`ReceiveEngine.cs:222`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L222) | delete the hash comparison, keep the `OriginalSize` length check |
| Content dedupe | [`MainWindow.xaml.cs:312`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L312) | `SHA256.HashData(completed.Plaintext)` |
| Journal row | [`MainWindow.xaml.cs:314`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L314), [`:350`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L350) | same locally computed value |
| Inbox / archive / audit / chain display | [`:336`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L336), [`:358`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L358), [`:380`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L380), [`:408`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L408), [`:488`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L488) | same |
| Sidecar JSON | [`PayloadStore.cs:116`](../../src/QrDiode.Receiver/Storage/PayloadStore.cs#L116) | same |

The cleanest shape: `CompletedTransfer` ([`ReceiveEngine.cs:21-26`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L21-L26)) gains a `PlaintextSha256` property computed once in `FinishTransfer`, and the UI reads it from there instead of from the manifest. That is a one-line addition and a find-and-replace.

**Cost:** it is a wire-format change — `FixedSize` drops 199 → 167 and the fields after offset 165 shift. Both ends must be updated together. See [02-WIRE-CHANGES.md](02-WIRE-CHANGES.md) §2 for the exact layout and §5 for the upgrade order.

**Test:** the existing loopback tests cover the round trip. Add one asserting that a captured manifest body contains no 32-byte window equal to `SHA-256(plaintext)`.

---

## D-2 · Tighten the manifest bounds to your real payload profile

**The problem.** `TransferManifest.TryParse` bounds payloads at 128 MB ([`TransferManifest.cs:108`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L108)) and validates that `K == ceil(ciphertextSize / symbolSize)` ([`:115-116`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L115-L116)), but never bounds `K` itself and accepts `symbolSize = 1`.

A manifest declaring `ciphertextSize = 128 MB, symbolSize = 1` gives `K = 134,217,728`. On acceptance, before a single data symbol arrives, [`ReceiveEngine.cs:156`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L156) constructs an `LtDecoder` which allocates `byte[]?[K]` ([`LtDecoder.cs:38`](../../src/QrDiode.Core/Fountain/LtDecoder.cs#L38)) plus a `RobustSoliton(K)` holding `double[K]` and a transient `double[K+1]` ([`RobustSoliton.cs:19`](../../src/QrDiode.Core/Fountain/RobustSoliton.cs#L19), [`:33`](../../src/QrDiode.Core/Fountain/RobustSoliton.cs#L33)) — about **3.2 GB**, plus two 134-million-iteration loops on the capture thread.

Separately, [`ReceiveEngine.cs:246`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L246) allocates `new byte[declaredSize]` before decompressing — up to 128 MB for a payload that might be 2 KB.

**Honest severity: low.** Both require a valid ECDSA signature from a key already in your trust store — i.e. a compromised sender, not an outsider. On a demo rig with two endpoints you provisioned, that is not a live threat. It is worth fixing because it is six lines, not because it is urgent.

**The real profile makes the fix obvious.** Your simulator produces small JSON/XML documents; the largest catalogue entry builds 1800 rows ([`PayloadSimulator.cs:218`](../../src/QrDiode.Core/Simulation/PayloadSimulator.cs#L218)) — hundreds of KB at most. The honest sender always uses `symbolSize = min(1350, ciphertextLength)` ([`SendSession.cs:93`](../../src/QrDiode.Core/Pipeline/SendSession.cs#L93)).

Add to the sanity envelope:

```csharp
const long maxPayload = 4L * 1024 * 1024;   // was 128 MB — set it to your real ceiling
const int  maxK       = 8192;               // 4 MB / 1350 ≈ 3100, so 8192 is generous

if (symbolSize < Math.Min(256, ciphertextSize)) { error = "Symbol size too small."; return false; }
if (symbolSize > 1350)                          { error = "Symbol size too large."; return false; }
if (k > maxK)                                   { error = "Source symbol count too large."; return false; }
```

The `Math.Min(256, ciphertextSize)` form matters: a tiny payload legitimately produces `symbolSize == ciphertextSize`, which may be well under 256. A flat floor would reject your smallest and most common transactions.

Optionally also grow the decompression buffer rather than pre-allocating `declaredSize`. Lower value; do it if you are in the file anyway.

**No wire change. No migration.** Pure receiver-side tightening.

**Test:** `symbolSize = 1` with a large declared ciphertext is rejected; a 1-byte payload still round-trips (this is the one that catches over-tightening).

---

## D-3 · Delete the `File` content kind from the production path

You will never transfer files. Right now `ContentGate.Validate` passes `ContentKind.File` through uninterpreted ([`ContentGate.cs:27-29`](../../src/QrDiode.Core/Pipeline/ContentGate.cs#L27-L29)), and `TransmitEngine.EnqueueFile` maps unknown extensions to it ([`TransmitEngine.cs:114-119`](../../src/QrDiode.Sender/Transmit/TransmitEngine.cs#L114-L119)).

Removing it means **every payload that reaches the store has been parsed by a hardened parser**. That is a materially simpler and more defensible statement than "XML and JSON are validated, and everything else is trusted because the signature verified", and it costs you nothing you will use.

Two honest options:

- **If the demo does not show file transfer:** delete the enum value and both branches. Simplest.
- **If the demo does show it:** keep the code, but make `File` rejected unless the app is running in demo mode. A single boolean, checked in `ContentGate.Validate`.

Either way, this removes the need for the "wire the store into AV/CDR scanning" recommendation in `SECURITY_REVIEW.md` §8 — that advice exists specifically for the opaque-file case.

---

## D-4 · Cap the sanitised filename length — **a real bug, not a hardening item**

`TransferManifest.MaxFilenameBytes` is 255 ([`TransferManifest.cs:27`](../../src/QrDiode.Core/Manifest/TransferManifest.cs#L27)). `SanitizeFilename` replaces invalid characters and trims, but never shortens ([`PayloadStore.cs:130-136`](../../src/QrDiode.Receiver/Storage/PayloadStore.cs#L130-L136)). The stored name then gets a 33-character GUID prefix ([`PayloadStore.cs:77`](../../src/QrDiode.Receiver/Storage/PayloadStore.cs#L77)):

```
255-character filename + 33-character prefix = 288 > NTFS's 255-character component limit
```

`File.Move` at [`PayloadStore.cs:86`](../../src/QrDiode.Receiver/Storage/PayloadStore.cs#L86) throws `PathTooLongException`, which is not in the caught set — so a fully verified payload lands as `store_failed`, and on a one-way channel there is no retry.

No attacker needed. A long export name from an OT historian will do it.

**Fix:** truncate the stem so the whole component stays under ~200 characters, keeping the extension; add `PathTooLongException` to the handled set as a backstop.

**Worth recording (verified, no change needed):** the GUID prefix means a stored name can never *be* a Windows reserved device name (`CON`, `LPT1`…). That property is load-bearing — if anyone ever removes the prefix, that class of bug opens up.

---

## D-5 · Bound the two collections that grow without limit

Three unbounded structures, all of which only matter in a long-running session or under deliberate injection:

| Structure | Where | Growth |
|---|---|---|
| `_seenSymbolIds` | [`LtDecoder.cs:23`](../../src/QrDiode.Core/Fountain/LtDecoder.cs#L23) | one entry per distinct symbol ID seen; the carousel keeps increasing IDs across loops |
| `_buffered` | [`LtDecoder.cs:22`](../../src/QrDiode.Core/Fountain/LtDecoder.cs#L22) | one entry per buffered coded symbol, each holding `symbolSize` bytes |
| `_settled` | [`ReceiveEngine.cs:54`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L54) | one GUID per session judged, for the life of the process |

**Honest severity: low, and mostly a stability item rather than a security one.** With D-2's `K ≤ 8192` cap in place, a normal session's decoder is small. `_settled` grows by one GUID per session — a demo running all day at one session per 10 seconds accumulates ~8,600 GUIDs, which is nothing. This is worth a cap because it is easy, not because it is dangerous.

Simple caps: `_buffered` at `min(4 × K, 4096)` with oldest-first eviction (**remembering to also remove the evicted symbol from every `_bySource[n]` list**, or the dependent lists leak); `_settled` as a bounded LRU. Count evictions and show them, so a truncated decode never looks like a clean one.

---

## D-6 · Pin the build

No `global.json`, no `packages.lock.json`, and **no git repository** in this workspace — I checked. That last one is worth saying out loud: right now there is no version history for a codebase whose security properties depend on nobody quietly changing them.

Two files, twenty minutes, useful with or without CI:

- **`global.json`** pinning the SDK band, so a different machine cannot silently produce a differently-compiled binary.
- **`packages.lock.json`** per project (`<RestorePackagesWithLockFile>true</RestorePackagesWithLockFile>`), so the six shipped dependencies — including the native `ZXingCpp`, `FlashCap` and SQLite blobs — are hash-pinned.

If the code is not under version control yet, `git init` is the higher-value five minutes.

**Not recommended now:** SBOM tooling, Authenticode signing, WDAC policies, reproducible-build verification. All of that is deployment work for a system with a deployment.

---

## D-7 · Make "this is a demo" impossible to miss

My first plan said to compile the demo provisioner out of production builds. For a product that is right. For **your** POC it is backwards — the demo path is the point.

The actual risk is different: `DemoProvisioner.Provision()` ([`DemoProvisioner.cs:22-37`](../../src/QrDiode.Core/Crypto/DemoProvisioner.cs#L22-L37)) creates **both** endpoints' private keys on **one machine** and cross-trusts them. Every cryptographic mechanism runs at full strength — nothing is stubbed, and the code comment says so honestly — but the receiver is trusting a sender whose private key is sitting on the receiver. A demo instance mistaken for a real one is a real deployment risk, and the mistake is easy to make because the app looks identical either way.

**Fix, in proportion:** when the loaded endpoint is `demo-ot` / `demo-it`, show a persistent, unmissable banner on both apps — not a toast that disappears, and not only at startup. The sender already shows a demo strip ([`MainWindow.xaml.cs:139-144`](../../src/QrDiode.Sender/MainWindow.xaml.cs#L139-L144)); make it permanent and mirror it on the receiver, which currently only logs a one-off message ([`MainWindow.xaml.cs:140-148`](../../src/QrDiode.Receiver/MainWindow.xaml.cs#L140-L148)).

That is the whole fix. No build configurations, no trust-store tripwires.

---

## Not on this list, and why

| Item | Why not |
|---|---|
| Strict 15-minute replay window (F-07) | The 48 h default is loose, but tightening it on two demo laptops that are not NTP-synced will cause rejections that look like optical faults. If you tighten it, watch the clock skew first. Change the default when you have time sync, not before. |
| Encrypting the filename and sizes (rest of F-01) | The filename is woven through the archive UI — `PayloadCatalogue.ForFilename` drives type classification and icons in five places. Encrypting it means the receive-progress ribbon can no longer name the payload until decode completes. Real UX cost, modest benefit for transaction filenames. Defer. |
| Forward secrecy / ephemeral ECDH (F-02) | Worth doing if this productionises. For a demo carrying transaction data, no. |
| Per-symbol MACs (F-06) | Defends against optical injection during a live session. Requires someone with a light source at your demo rig. |
| ACLs, service accounts, trust-index MAC, journal tripwire (F-03) | Assumes a hostile multi-user host. |
| Keyed audit / off-host shipping (F-04) | The existing hash chain is adequate for a POC. |
| Capture sandboxing (F-08) | Weeks of work, uncertain feasibility, threat needs physical access. |
| Delivery-gap detection (F-12) | Genuinely useful and not expensive — the receiver has the counter and never checks it. But it is an *operations* feature for a running system, not a POC gap. Do it when someone is depending on completeness. |

All of these are in [03-IF-PRODUCTION.md](03-IF-PRODUCTION.md) with the condition that would promote them.
