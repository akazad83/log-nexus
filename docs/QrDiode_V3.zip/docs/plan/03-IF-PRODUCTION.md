# 03 · If this becomes a production system

Everything I withdrew from the first plan, with the condition that would make each one worth doing. **No estimates and no schedule** — this is a checklist for a decision you have not made, not a programme.

The ordering is by what I would do first *if the decision were made*, which is not the same as the review documents' severity ordering.

---

## 1. First, before any code

**Decide the deployment model.** Almost every item below is conditional on questions the POC does not have to answer:

- Who administers the receiver host, and can an operator log on to it interactively?
- Is the optical corridor physically controlled (enclosed cabinet, locked room), or is it in an area where someone could film the screen or shine a light at the camera?
- What is the shelf life of a transaction's confidentiality — days, or years?
- Does anyone downstream depend on *every* transaction arriving, or is best-effort acceptable?
- Is there a compliance framework in play (IEC 62443 SL target, NIST 800-82), and at what level?

The v1 review's §8 deployment guidance is good and I am not going to restate it. What I will say is that **the physical control question dominates**: F-01 (filming the screen) and F-06 (injecting light) are both physical-access attacks, and an enclosed optical corridor removes both classes far more cheaply than the protocol work does.

---

## 2. Promotion conditions

| Item | v1 finding | Build it when |
|---|---|---|
| **Delivery-gap detection** — on accepting counter `c` with watermark `w`, flag `c > w + 1` | F-12 | Anyone depends on completeness. The receiver already has the counter and never checks it, so this is the cheapest real feature on the list. Watch for the first-contact case: a new receiver, or a sender that previously talked to a different one, will legitimately present a counter far above the (absent) watermark, and reporting that as "1,847 transfers lost" on day one trains operators to ignore the alarm. |
| **Strict replay window (15 min default)** | F-07 | Both zones have authenticated, monitored time. Not before — a tight window with unmonitored drift is an outage waiting to happen, and it will present as an optical fault. Instrument skew first: `SqliteJournal.Check` already computes `nowMs - timestampUnixMs` at [`SqliteJournal.cs:99-100`](../../src/QrDiode.Receiver/Storage/SqliteJournal.cs#L99-L100) and throws it away. |
| **Encrypt the manifest descriptor** (filename, sizes, content kind) | F-01 rest | Filenames or transfer cadence are themselves sensitive in your OT context. Costs: a protocol version, and the receive-progress ribbon can no longer name the payload before decode completes, because `PayloadCatalogue.ForFilename` drives type classification in five UI paths. |
| **Forward secrecy** (sender-ephemeral ECDH) | F-02a | Confidentiality must survive endpoint key compromise, or the data's value outlives the key's lifetime. Design notes in [02-WIRE-CHANGES.md](02-WIRE-CHANGES.md) §4. |
| **Receiver key rotation with overlap** | F-02b | You are running long enough for a static key's exposure window to matter. The key-ID mechanism already supports it; nothing uses it. Note that watermarks key off the *sender's signing* key ID ([`SqliteJournal.cs:94-96`](../../src/QrDiode.Receiver/Storage/SqliteJournal.cs#L94-L96)), so rotating the receiver's agreement key does not disturb anti-replay state. |
| **Per-symbol HMACs + re-arm on decode failure** | F-06 | The optical corridor is *not* physically controlled. Today an injected symbol with a valid CRC and the right session tag displaces the genuine one via the seen-ID set ([`LtDecoder.cs:46`](../../src/QrDiode.Core/Fountain/LtDecoder.cs#L46)), the hash check correctly fails, and `RejectAndReset` then settles the session permanently ([`ReceiveEngine.cs:280`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L280)) — so the rest of the genuine carousel is ignored. If you build this, note that `Commit` runs *after* the content gate ([`ReceiveEngine.cs:230`](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs#L230)), so re-arming is safe against the journal without any journal changes. |
| **ACLs + dedicated service accounts** | F-03 | The host has interactive users other than the operator, or is administered by a different team. **Read the counter warning in §3 before doing this one.** |
| **Trust-directory integrity check** | F-03 | Same condition. `DirectoryTrustStore` currently trusts whatever parses ([`TrustStore.cs:97-107`](../../src/QrDiode.Core/Crypto/TrustStore.cs#L97-L107)), so dropping a JSON file into `trust\` silently provisions a sender. |
| **Journal tripwire + watermark backup** | F-03 | You rely on anti-replay across restarts. Deleting `journal.db` today is undetectable — the constructor just `CREATE TABLE IF NOT EXISTS`es a fresh one. |
| **Audited, elevation-gated trust import** | F-03/F-10 | There is a real key ceremony with real operators. Add a `revoke` verb at the same time — today revocation is deleting a file in Explorer with no record. |
| **Keyed audit records + chain-head countersignature** | F-04 | Non-repudiation matters to someone other than you. The existing hash chain detects casual edits but not a rewrite-and-rehash. Note that the load-bearing part is **shipping records off-host**, not the HMAC: the HMAC key has to live somewhere the local admin can reach unless the TPM supports persisted HMAC keys, which varies. |
| **Content schema pinning** (XSD / JSON profile per sender) | R-14 | You have a stable transaction schema and want structural enforcement. Two cautions: turn off `ProcessSchemaLocation` and `ProcessInlineSchema` or you reintroduce the external-resource class that `DtdProcessing.Prohibit` closes; and .NET has no in-box JSON Schema validator, so full JSON Schema means a new third-party parser of hostile input inside the trust boundary. A small declarative structural profile over the existing `Utf8JsonReader` avoids that dependency. |
| **Capture/decode sandboxing** | F-08 | Production, with an attacker plausibly able to control what the camera sees. The exposure is real — up to 60 frames/second of attacker-controlled input parsed by native zxing-cpp and Windows WIC codecs *inside* the process that holds the trust store and the private key. Feasibility caveat: the strongest mitigation (Arbitrary Code Guard) is incompatible with JIT, so it needs a NativeAOT child, and whether FlashCap and ZXingCpp publish cleanly under NativeAOT is unknown — that spike comes first. |
| **Supply-chain attestation** (SBOM, Authenticode, WDAC) | F-09 | There is a release process and endpoints you do not personally build on. Lock files and an SDK pin are worth doing now ([01-DO-NOW.md](01-DO-NOW.md) D-6); the rest is deployment. |
| **CNG key-usage constraints** | F-10 | Re-provisioning is on the table anyway. Keys are created with `CngKeyUsages.AllUsages` ([`CngEndpointKeys.cs:66`](../../src/QrDiode.Core/Crypto/CngEndpointKeys.cs#L66)), and `OpenOrCreateKey` adopts a pre-existing key without checking its export policy ([`:57-61`](../../src/QrDiode.Core/Crypto/CngEndpointKeys.cs#L57-L61)). The export-policy assertion is worth adding on its own; the usage split cannot be applied to existing keys, so it needs new keys. |
| **`.staging` sweep + clipboard policy** | F-11 | Production. If materialisation fails between the fsync and the rename ([`PayloadStore.cs:81-86`](../../src/QrDiode.Receiver/Storage/PayloadStore.cs#L81-L86)), a full-plaintext `.tmp` stays there indefinitely. Cheap to fix whenever you are next in that file. |

---

## 3. Three traps to know about before you start

These are the things that will bite during a production hardening effort, in the order they will bite.

**The DPAPI counter and service accounts.** `CounterStore` protects `sender-counter.bin` under `DataProtectionScope.CurrentUser` ([`CounterStore.cs:46`](../../src/QrDiode.Core/Crypto/CounterStore.cs#L46), [`:55`](../../src/QrDiode.Core/Crypto/CounterStore.cs#L55)). Moving the sender to a dedicated service account — which is exactly what the F-03 remediation asks for — means the new account cannot decrypt it. `ProtectedData.Unprotect` throws, `Read()` does not catch it ([`:42-49`](../../src/QrDiode.Core/Crypto/CounterStore.cs#L42-L49)), and every send fails. Delete the file to "fix" it and `Read()` returns 0 ([`:44`](../../src/QrDiode.Core/Crypto/CounterStore.cs#L44)), counters restart at 1, and the receiver then rejects **every** transfer as `StaleCounter` — silently, with no back-channel to report it.

Migrate the counter to machine scope with an ACL, in the same change as the service accounts, and never set a counter below the receiver's current watermark.

**Restoring an old journal rolls watermarks backwards.** If you add the watermark-regression tripwire, a legitimate restore-from-backup will trip it. That is correct behaviour, and the runbook has to say so, or the first restore drill will be spent debugging the alarm.

**Private keys are deliberately not backupable.** CNG keys are created non-exportable ([`CngEndpointKeys.cs:65`](../../src/QrDiode.Core/Crypto/CngEndpointKeys.cs#L65)). "Back up everything" is the default instinct and here it would silently destroy the property the TPM provides. Loss of a private key means re-running the ceremony — that is intentional and needs to be written down where the backup procedure lives.

---

## 4. What no amount of this work fixes

Restating `SECURITY_REVIEW_V2.md` §5 because it is correct and worth keeping in front of you:

- **A compromised sender signs whatever it likes**, and the receiver will verify it perfectly and store it. Schema pinning bounds the blast radius to well-formed transactions; it cannot make them true.
- **Forward secrecy has a floor.** No return channel means no interactive ratchet. Receiver-key compromise decrypts the current rotation window, whatever you set it to.
- **Availability is jammable.** A hand over the lens denies the channel. Symbol MACs turn cheap invisible poisoning into obvious jamming — better detection, not prevention.
- **Traffic analysis survives.** Sizes, timing, cadence and key IDs stay visible. Padding on a ~20 KB/s channel is a poor trade.
- **Delivery is detectable, never recoverable.** Nothing can request a resend.
- **The ceremony is human.** Technical controls make a bad ceremony loud, not impossible.

None of these is a defect. They are properties of a one-way optical channel, and a design that pretends otherwise would be worse.
