# Sending Data IT → OT: The Option Space

**A methodical analysis of every way to move acknowledgements and transactional records back into the control zone, what each one actually costs, and which ones are defensible.**
*Decision-support document. Opinionated where the evidence supports an opinion.*

---

## 0. The one thing to understand before reading further

Today the system makes a **categorical** claim: *nothing can reach OT*. Not "nothing malicious", not "nothing unauthorised" — nothing. That claim survives every implementation bug in the codebase, because it is enforced by the absence of a path, not by the correctness of code.

The moment anything flows IT → OT, that claim becomes **conditional**: *only things that pass checks reach OT*. Conditional claims are only as good as the code that enforces them, and code has bugs.

That is the entire trade. Everything below is about buying back as much of the categorical property as possible while still getting what you need.

> **The risk inverts direction.** OT → IT is a *confidentiality* problem: the worst case is someone reads a batch record. IT → OT is an *integrity and safety* problem: the worst case is a forged production order or a poisoned setpoint reaching something that moves. The existing controls are tuned for the first problem. They are necessary but not sufficient for the second.

There is also a genuine argument **for** a return path that is easy to miss, and it is a security argument, not a convenience one. Three findings already on the register are unfixable without one:

| Finding | Why it is stuck today | What a return channel does |
|---|---|---|
| **F-02** — no forward secrecy | Static–static ECDH; no interactive ratchet is possible with one-way flow | A tiny, fixed-format ephemeral key share lifts the floor entirely |
| **F-06** — optical-injection DoS permanently settles a session | Nothing can ask for a re-send | Re-request, or simply "that failed, send it again" |
| **F-12** — silent delivery gaps | IT can detect a gap but cannot report it | Closes the loop |

So the honest framing is not "safe versus unsafe". It is: **a categorical property on one axis, traded for conditional improvements on three others.** Whether that is a good trade depends entirely on choices in §2 and §4, not on the transport in §3.

---

## 1. Three orthogonal decisions, not one

Most bad return-channel designs come from conflating these. They must be decided separately, and the risk is dominated by the first and third — **not** by the transport, which is what people usually argue about.

```mermaid
flowchart LR
    subgraph D1["① SEMANTICS — what is allowed to flow"]
        direction TB
        S0["S0 · nothing (today)"]
        S1["S1 · acknowledgement only<br/>fixed format, authority limited to<br/>'you may stop transmitting'"]
        S3["S3 · key-establishment only<br/>ephemeral DH share, no business data"]
        S2["S2 · ACK + selective repair requests<br/>IT can make OT do work"]
        S4["S4 · structured business records<br/>orders, schedules, specs"]
        S5["S5 · control commands / setpoints"]
        S0 --> S1 --> S3 --> S2 --> S4 --> S5
    end

    subgraph D2["② MEDIUM — what carries it"]
        direction TB
        M1["M1 · reverse QR optical lane"]
        M2["M2 · constrained optical ACK<br/>photodiode / fixed screen region"]
        M3["M3 · optocoupled one-way serial"]
        M4["M4 · commercial hardware diode"]
        M5["M5 · removable media"]
        M6["M6 · human transcription"]
    end

    subgraph D3["③ INGRESS — where it lands and who approves"]
        direction TB
        I0["I0 · same process as the OT sender"]
        I1["I1 · separate least-privilege process"]
        I2["I2 · dedicated OT landing host,<br/>not a control host"]
        I3["I3 · landing host + schema pinning"]
        I4["I4 · + human approval before<br/>anything reaches a controller"]
        I0 --> I1 --> I2 --> I3 --> I4
    end

    D1 ==>|"then choose"| D2 ==>|"then choose"| D3

    classDef safe fill:#D5F5E3,stroke:#1E8449,color:#145A32;
    classDef mid fill:#FCF3CF,stroke:#B7950B,color:#6E5B10;
    classDef hot fill:#FADBD8,stroke:#C0392B,color:#641E16;
    classDef neutral fill:#E9EDF2,stroke:#7F8C9A,color:#2C3540;
    class S0,S1,S3 safe;
    class S2 mid;
    class S4,S5 hot;
    class I0,I1 hot;
    class I2 mid;
    class I3,I4 safe;
    class M1,M2,M3,M4,M5,M6 neutral;
    style D1 fill:#FBFDFB,stroke:#9AB8A5
    style D2 fill:#F7F9FB,stroke:#A8B4C0
    style D3 fill:#FBFDFB,stroke:#9AB8A5
```

*Figure 1 — The three decisions. Green is defensible, amber needs justification, red needs a very good reason.*

A useful sanity check: **S1 + M2 + I1** is a small, boring, defensible system. **S4 + M1 + I0** — full business records over a reverse camera link, processed in the same process that drives the transmitter — is the worst combination available and is roughly what you get if you "just add a receiver to the sender app".

---

## 2. Decision ① — Semantics: what you actually allow back

This is the decision that matters most, so it comes first. Pick the *weakest* tier that meets the requirement.

### S0 — Nothing. Get the value without the channel.

**Before building any return path, note how much of the operational benefit is available with none.**

The manifest already carries a per-sender monotonic counter, and the IT journal already stores it. Missing counter values *are* missing transactions. IT can therefore compute, unaided, an exact list of what never arrived — this is F-12, already flagged as the cheapest real feature on the register. Pair it with an out-of-band re-request (a phone call, a ticket, a scheduled re-send of the gap list) and you have delivery assurance without a single new byte entering OT.

Watch the first-contact case already noted on the register: a fresh receiver, or a sender that previously talked to a different one, legitimately presents a counter far above an absent watermark. Reporting that as "1,847 transfers lost" on day one trains operators to ignore the alarm.

**Verdict: do this regardless of what else you choose.** It is the highest value-per-risk item in this entire document, and it is subtractive of nothing.

### S1 — Acknowledgement only

A fixed-format message whose *entire authority* is: **"the current session may stop early."** Not "re-send", not "change parameters", not "here is data".

That authority bound is what makes S1 safe, and it must be enforced structurally, not by convention:

- An ACK is accepted only for the session currently on air. ACKs for any other session are discarded without processing.
- An accepted ACK may only shorten air time. It cannot extend it, cannot alter redundancy, chunk size, or frame rate, cannot queue anything, cannot touch the filesystem.
- If the ACK channel is silent, behaviour is bit-for-bit identical to today's air-time policy.

**Worst case under total attacker control of the channel:** premature truncation. The payload does not arrive, IT's gap detection (S0) catches it, and it is re-sent. A bounded, detectable denial of service — not an integrity event.

**Payoff:** a transaction that currently occupies the stage for a 6-second floor could clear in well under a second. On a busy line that is the difference between a queue that drains and one that does not.

### S3 — Key establishment only

IT periodically publishes a signed **ephemeral** key share. OT uses it to derive session keys for subsequent transfers. No business data ever traverses the channel.

This closes F-02 — forward secrecy — with a small fixed-format message. The design notes already on file apply directly: carry the uncompressed X9.62 point (`0x04 ‖ X ‖ Y`, 65 bytes) rather than a compressed point, because compressed-point import is not reliable on CNG and hand-rolling the decompression means writing modular square roots into a project whose best supply-chain property is that it contains no hand-written crypto math. Import through `ImportSubjectPublicKeyInfo` and treat `CryptographicException` as rejection — with a share arriving on the wire rather than from the trust store, invalid-curve attacks against the static key become reachable, and point validation on import is what closes them.

**Verdict: the best security-per-byte on the entire list.** If you build any channel at all, carry this on it.

### S2 — ACK plus selective repair requests

IT asks OT to re-send specific blocks. This crosses a line: IT can now make OT *do work*, which is an amplification primitive and needs rate limits and a per-session repair budget.

**And for your actual workload it is nearly worthless.** Measured across the payload catalogue, a typical plant transaction is 130–200 bytes sealed and produces **K = 1** — a single block. There is nothing to selectively repair; "repair" and "re-send" are the same operation. Selective repair only starts paying at large K, which for this system means the occasional multi-hundred-kilobyte report.

**Verdict: skip it.** Add "re-send session X" (which is S1 plus a session ID) if you need recovery. Do not build block-level repair for K = 1 traffic.

### S4 — Structured business records IT → OT

This is the real ask, and it is a different system, not a feature. Production orders, schedules, recipes, quality specs and work orders are **instructions**: they change what the plant does. A forged or malformed one has physical consequences.

The minimum viable control set, all of which are required together:

1. **ECDSA-signed** by an IT identity provisioned specifically for sending *into* OT — a different key from the one IT uses to receive, so that authority can be revoked independently.
2. **No opaque payloads.** The content gate already has the switch for this (`allowOpaqueFiles: false`); with it set, every accepted payload has been through a hardened parser. Your "no files" constraint is a security asset — keep it as a hard invariant, not a default.
3. **Schema pinning** per sender and message type. Note the two cautions already on the register: for XSD, turn off `ProcessSchemaLocation` and `ProcessInlineSchema` or you reintroduce exactly the external-resource class that `DtdProcessing.Prohibit` closes; and .NET has no in-box JSON Schema validator, so "full JSON Schema" means adding a third-party parser of hostile input *inside* the trust boundary. A small declarative structural profile layered over the existing reader avoids that dependency and is the right call here.
4. **Semantic bounds, not just structural ones.** A schema says "well-shaped". It does not say "sane". `{"order":"WO-1","qty":1000000000}` is schema-valid. Range checks, effective-date windows, quantity ceilings and referential checks against known assets belong in the gate.
5. **Size caps far below the forward path.** 16 MiB is the OT → IT envelope. For ingress use tens of kilobytes, with the block-count ceiling reduced to match.
6. **Human approval before anything reaches a controller** (see §4).

### S5 — Control commands and setpoints

Out of scope for this architecture. If a setpoint must change from the business network, that is a control-systems integration problem with its own safety case, interlocks and independent protection layers — not something to tunnel over a QR link. **Say no to this one.**

---

## 3. Decision ② — Medium: what carries the bytes

Bandwidth figures below are grounded in the forward channel's measured behaviour (~15 frames/s, 1350-byte chunks) and standard rates for the other media.

### M1 — Reverse QR optical lane (IT monitor → OT camera)

Symmetric to what exists. Reuses essentially the entire protocol core.

- **Capacity:** ~20 KB/s theoretical; per-transaction latency dominated by the air-time floor, seconds.
- **Effort:** lowest of any option — the core is already direction-agnostic (see §5).
- **Attack surface added to OT:** a camera stack, an image codec path, a native QR decoder, the frame parser, the manifest parser, the fountain decoder, the envelope, the content gate.

That last line is the problem. **F-08 — native and OS-codec parsing of untrusted images, in-process — currently rates Medium on the IT side. The identical construct on the OT side rates High, because the blast radius is the protected zone.** You would be placing up to 60 frames per second of attacker-influenceable input in front of native `zxing-cpp` and Windows imaging codecs, running inside a process that holds OT private keys.

If you choose M1, the sandboxing work stops being a "when production" item and becomes a precondition — and the known feasibility caveat applies: the strongest mitigation is incompatible with JIT, so it needs a NativeAOT child process, and whether the capture and decode libraries publish cleanly under NativeAOT is unverified. **That spike comes before the decision, not after.**

**Verdict:** the most capable option and the worst surface trade. Bringing an entire image-processing stack into OT to carry a 90-byte acknowledgement is indefensible. Only consider M1 if you genuinely need S4 volume *and* have done the sandboxing work.

### M2 — Constrained optical acknowledgement

A dedicated indicator on the IT side — an LED, or a fixed patch of the IT screen — read by a photodiode or a fixed, cropped region of a simple sensor.

- **Capacity:** 10–200 bit/s realistically.
- **Latency:** an ~90-byte signed ACK at 100 bit/s is ~7 s — too slow. **The fix is to drop ECDSA for ACKs and use a symmetric MAC**: both endpoints already share an ECDH secret, so an 8-byte truncated MAC over (session ID, status, counter) is sound. That collapses the frame to roughly 30 bytes, ~2.5 s at 100 bit/s, well inside the session cadence. Non-repudiation is not a requirement for "I got it".
- **Attack surface added to OT:** a fixed-length bit frame with **no length fields at all**. This is a parser you can read in one sitting and fuzz exhaustively. No image codecs, no native decoders.
- **Cost:** a photodiode and a serial or optocoupled interface. Tens of dollars.

**Verdict: the best security-per-capability ratio on the list for S1 and S3.** The channel is *physically incapable* of carrying a business record, which is a far stronger guarantee than software that declines to.

### M3 — Optocoupled one-way serial

RS-232/RS-422 with the OT → IT conductor physically absent and an optocoupler for galvanic isolation.

- **Capacity:** 9.6–115.2 kbaud — ample for S1 through S4.
- **Attack surface added to OT:** a UART byte stream and your framing. No image codecs. Orders of magnitude smaller than M1.
- **Inspectability:** an auditor can *see* the missing wire. That is a rare and valuable property.
- **Caveats:** it is a physical connection, which some OT policies forbid outright — that is a policy question, not a technical one. Modern hosts need a USB-serial adapter, which reintroduces a USB device surface; pin it by device ID under application control policy, or use a real serial port.

**Verdict: the pragmatic winner if "no conductor at all" is not mandated.** It is the only option that handles S4 volume without an image stack.

### M4 — Commercial hardware data diode (IT → OT)

A purpose-built unidirectional gateway. Direction enforced in silicon, typically fibre.

- **Capacity:** far beyond anything needed here.
- **Cost:** significant capital and integration; usually requires a UDP-shaped protocol adaptation.
- **Important:** a diode enforces *direction*, not *safety*. It will faithfully deliver a forged production order. You still need everything in S4's control set. Buying a diode does not buy you a content policy.

**Verdict:** correct if budget exists, volumes are real, and an auditor needs a nameplate. Does not reduce the software work in §4.

### M5 — Removable media

Already the trusted path for the key ceremony.

- **Capacity:** unlimited; **latency:** hours.
- **Attack surface:** USB mass storage — historically the single most effective route into air-gapped plants. Mitigate with a scanning kiosk, write-once media, and a strict no-autorun, no-executable policy.

**Verdict:** acceptable for low-frequency S4 (a daily schedule drop). Useless for acknowledgement. Do not let it become an informal habit — the ceremony's discipline does not survive daily use.

### M6 — Human transcription

An operator reads a short code from the IT screen and types it into OT.

- **Capacity:** tens of characters per event.
- **Attack surface:** no automated ingress path whatsoever. The human is the gate — which means social engineering replaces protocol attack, and the input still lands in a parser.

**Verdict: the highest-assurance option available, and the correct default for anything that changes plant behaviour.** Do not dismiss it because it is unglamorous. "Operator confirms the receipt code and authorises re-send" is a complete, defensible solution to the acknowledgement problem at low transaction rates.

### Rejected media, and why

| Option | Why it is rejected |
|---|---|
| **Handheld barcode scanner into OT** | Enumerates as an HID keyboard. It can inject arbitrary keystrokes into whatever holds focus. This is a general-purpose code-execution primitive wearing a barcode costume. **Never.** |
| **Audio / ultrasonic** | Requires a microphone on the OT host — an eavesdropping device in a control room. The liability exceeds the channel's worth. |
| **Wi-Fi / BLE / NFC / IR remote** | Introduces an RF or IR attack surface reachable from outside the physical perimeter, which is precisely what the air gap exists to prevent. |
| **"Just open one firewall port"** | Defensible only if the diode was never actually required. If it was, this is not a return channel — it is the end of the architecture. Have that conversation explicitly rather than arriving here by increments. |

---

## 4. Decision ③ — Ingress: where it lands and who approves

For S1 and S3 this is a small question. For S4 it is *the* question, and it dominates every transport concern in §3.

```mermaid
flowchart LR
    subgraph OT["🏭 OT ZONE"]
        direction TB
        OTSEND["OT sender<br/>(existing)"]
        LAND["OT landing host<br/>not a control host<br/>least privilege · no network"]
        GATE["Ingress gate<br/>signature → replay →<br/>schema → semantic bounds"]
        HOLD["📋 Hold queue<br/>nothing auto-applies"]
        HUMAN["👤 Operator approval<br/>four-eyes for anything<br/>that changes behaviour"]
        CTRL["Control systems"]
        LAND --> GATE --> HOLD --> HUMAN
        HUMAN ==>|"explicit action"| CTRL
        GATE -.->|"ACK only:<br/>may shorten air time"| OTSEND
    end

    subgraph FWDL["✨ LINK 1 — one-way, existing"]
        direction TB
        FWD["📺 → 📷<br/>OT → IT optical<br/>transactions"]
    end

    subgraph REVL["✨ LINK 2 — one-way, new"]
        direction TB
        REV["💡 → ⚡<br/>IT → OT<br/>constrained ACK, or<br/>optocoupled serial"]
        KILL["🔌 physical kill switch<br/>degrades to today's behaviour"]
        KILL -.->|"cuts"| REV
    end

    subgraph IT["🏢 IT ZONE"]
        direction TB
        ITAPP["IT receiver<br/>(existing)"]
        ITSEND["IT egress signer<br/>separate key,<br/>authorised to send into OT"]
        ITAPP -.-> ITSEND
    end

    OT ==> FWDL ==> IT
    IT ==> REVL ==> OT

    classDef ot fill:#FBE3CD,stroke:#C97B2C,color:#4A2C10;
    classDef it fill:#D8E8FA,stroke:#2F6FB0,color:#12385E;
    classDef gap fill:#F2F2F5,stroke:#9AA0A6,color:#33363B;
    classDef human fill:#D5F5E3,stroke:#1E8449,color:#145A32;
    classDef danger fill:#FADBD8,stroke:#C0392B,color:#641E16;
    class LAND,GATE,HOLD,OTSEND ot;
    class ITAPP,ITSEND it;
    class FWD,REV,KILL gap;
    class HUMAN human;
    class CTRL danger;
    style OT fill:#FFF7EF,stroke:#E0A96D
    style IT fill:#F0F6FD,stroke:#8FB8DE
    style FWDL fill:#FAFAFC,stroke:#B7BCC4,stroke-dasharray:5 4
    style REVL fill:#FAFAFC,stroke:#B7BCC4,stroke-dasharray:5 4
```

*Figure 2 — Recommended target: two independent one-way links, a landing host that is not a control host, and a human between ingress and anything that moves.*

The rules that make this work:

**The landing host is not a control host.** Data arriving from IT lands somewhere that cannot write to a controller. Promotion from the landing zone into a control system is a separate, deliberate, logged act. If the ingress software is fully compromised, the attacker owns a host that can send email-shaped JSON to a hold queue — not a plant.

**The ingress process is minimal and unprivileged.** No network, no writes outside a spool directory and an append-only log, no ability to influence the forward transmitter beyond the single bounded ACK effect. Fuzz its parser — for a fixed-length ACK frame, exhaustively.

**Nothing auto-applies.** The hold queue exists so that a human sees every record before it has effect. Four-eyes for anything that changes setpoints, recipes or safety-relevant parameters.

**A physical kill switch, and a drill that uses it.** Because the return channel is non-load-bearing (see §5), you can cut it at any moment and lose only efficiency. Prove that in a drill; an untested degradation path is a rumour.

**Fixed optical geometry.** If the return path is optical, the OT sensor sees only a fixed, cropped region corresponding to the IT indicator. Everything outside that rectangle is discarded before decoding. Cheap, and it raises the bar for injection substantially.

**An enclosed optical corridor pays for both directions.** A light-tight, locked, tamper-evident enclosure containing both displays and both sensors closes F-01 (filming the OT screen) and F-06 (injecting light) at once — and the existing register already judges physical control to be the dominant question. If you are opening the cabinet to add a return path, do this in the same change. Use baffles or time-division so the two directions do not illuminate each other.

**Rejections on OT ingress are high-signal alerts.** On the IT side, decode failures are routine — that is what a camera pointed at a screen produces. On the OT side, a signature failure means someone is *actively trying*. Alert on it; do not bury it in a counter.

---

## 5. What the existing implementation already gives you

This is better than you might expect, and it changes the effort calculus.

**The protocol core is already direction-agnostic.** Framing, the fountain codec, the manifest, the crypto envelope, the trust store, the replay guard, the content gate and the audit log contain nothing that assumes OT is the sender. A reverse channel is the same core with the roles swapped.

**The key ceremony is already bidirectional.** Each endpoint generates *both* a signing pair and an agreement pair, and the ceremony has each side import the other's bundle. Both hosts already hold everything needed to authenticate and encrypt in the reverse direction. No new ceremony is required for S1/S3 — although §6 argues you should run one anyway.

**The "no files" constraint is already implemented.** The content gate takes a switch that refuses opaque payloads outright; with it set, every accepted payload has been parsed by a hardened parser.

**Frame types are extensible and fail closed.** The parser rejects unknown frame types cleanly rather than mis-slicing them, so adding an ACK type is a controlled change — though it is a wire change, and the existing runbook lesson applies: with no back-channel to report a mismatch, deployment order matters.

**What is missing:** an OT-side receive path and journal, an IT-side send counter for the reverse direction, schema pinning, semantic bounds, the hold queue and approval UI, and the policy layer. The cryptography is the part you already have.

---

## 6. Cryptographic specifics for a reverse channel

Six things that will be got wrong if they are not written down.

**1 · Domain-separate the two directions.** Static–static ECDH is symmetric: `ECDH(OT_priv, IT_pub)` and `ECDH(IT_priv, OT_pub)` produce the *same* shared secret. If both directions derive from it, the key schedule must include a direction label — for example `"QrDiode.v3|OT->IT"` versus `"QrDiode.v3|IT->OT"` in the HKDF info. The current info string carries a version and the session GUID but no direction. Random per-session GUIDs make a collision improbable, but reflection resistance should be structural, not probabilistic.

**2 · Better still, use separate key pairs per direction.** Then no secret is shared between the two channels at all, and IT's authority to *send into* OT can be revoked without disturbing its ability to *receive* — which matters, because those two authorities have wildly different risk profiles and should not share a revocation event.

**3 · Separate counter namespaces and separate replay state.** The IT side needs its own monotonic counter with the same "reserve and flush before the session exists" discipline; the OT side needs its own watermark store. Do not share either.

**4 · Use a MAC for acknowledgements, a signature for records.** ACKs need integrity and freshness, not non-repudiation — a truncated HMAC under a purpose-labelled key derived from the shared secret is smaller and faster, and on a 100 bit/s channel the 64 bytes you save are the difference between viable and not. Business records need non-repudiation; sign those.

**5 · Fixed-length frames with no length fields.** The ACK frame should have no variable-length component whatsoever, so the parser is a constant-shape check with no arithmetic on attacker-supplied lengths. This is the single highest-leverage design choice for the OT ingress surface.

**6 · Validate any key material that arrives on the wire.** For S3, the ephemeral share comes from the channel rather than the trust store. Import through the SPKI path so the platform validates the point, and treat a cryptographic exception as a rejection.

---

## 7. Comparison and recommendation

| Combination | Capability | New OT attack surface | Effort | Verdict |
|---|---|---|---|---|
| **S0** — gap detection, no channel | Know what was lost | **None** | Very low | **Do this first, always** |
| **S1 + M6** — human-confirmed ACK | Confirm receipt, authorise re-send | None automated | Very low | Excellent at low transaction rates |
| **S1/S3 + M2** — constrained optical | Early stop, forward secrecy | Tiny fixed-length parser | Low–medium | **Recommended for acknowledgement** |
| **S1/S3 + M3** — optocoupled serial | As above, with headroom | Small UART parser | Medium | **Recommended if a conductor is permitted** |
| **S4 + M3 + I3/I4** | Business records into OT | UART parser + schema/semantic gate | High | **The defensible way to do S4** |
| **S4 + M4 + I3/I4** | As above, high volume, nameplate | Same software; hardware-enforced direction | High + capital | Right when budget and audit demand it |
| **S4 + M5** — removable media | Daily batch | USB stack | Low | Acceptable for low frequency only |
| **Anything + M1** — reverse QR | Highest bandwidth without a wire | **Image codecs + native decoder in OT** | Low to build, high to secure | Only with sandboxing done first |
| **S5 — control commands** | — | — | — | **No** |
| **Any + I0** — same process as sender | — | Maximum | Low | **No** |

### What I would build, in order

1. **Delivery-gap detection on the IT side** (S0). No ingress, closes F-12, and it is the prerequisite for trusting any ACK scheme — because it is what catches a forged ACK that truncated a session.
2. **Decide the physical question before the protocol question.** An enclosed optical corridor with a kill switch is worth more than any amount of protocol work, and it is the precondition for doing the rest safely.
3. **A constrained ACK channel (S1 + M2), or serial (M3) if a conductor is allowed** — with the authority bound enforced structurally: *an accepted ACK may only shorten the current session.*
4. **Carry the ephemeral key share on the same channel (S3).** Closes F-02 for a handful of bytes. Best value on the list.
5. **Only then, if the business genuinely needs records flowing into OT: S4 over M3 or M4, landing on a dedicated host, schema-pinned, semantically bounded, human-approved.** Budget for this as a separate system with its own threat model and its own review — not as a sprint on the existing app.

### The invariant to hold on to

> **The return channel must never be load-bearing.** If it is dead, jammed, unplugged or deliberately cut, the forward path must behave exactly as it does today — same air-time policy, same guarantees, same throughput. Every efficiency it buys must be an optimisation, never a dependency.

Hold that line and the return channel stays something you can switch off during an incident. Lose it, and you have quietly made the control zone depend on the business zone — which is the failure mode this entire architecture exists to prevent.
