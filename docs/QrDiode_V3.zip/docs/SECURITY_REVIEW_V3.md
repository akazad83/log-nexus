# QrDiode — Security Review v3: As-Built Re-Assessment

**Target:** QrDiode one-way optical data diode (OT → IT) over animated QR codes, protocol **v2** (`FrameFormat.ProtocolVersion = 0x02`)
**Document version:** 3.0 — as-built white-box re-review with executed proof-of-concept exploitation
**Review date:** 2026-08-23
**Deployment profile assessed:** **transactional payloads only (XML / JSON). No file transfer.**
**Audience:** Security engineering, OT/IT architecture, external assessors

| Document control | |
|---|---|
| v1.0 · 2026-08-20 | As-built white-box review; findings F-01…F-13; 75/75 tests |
| v2.0 · 2026-08-20 | Target-state remediation register R-01…R-14; **all items OPEN** |
| **v3.0 · 2026-08-23** | **As-built re-review after hardening phases P1–P8. Verifies which R-items actually landed, retires closed ones, and reports four issues not present in v1/v2 — three of them proven by executed exploit code.** |
| Method | 100% of non-generated source read; both test suites executed (88/88 and 9/9 pass); runtime state and filesystem ACLs inspected on a live host; six exploit/behaviour scenarios executed against the real `ReceiveEngine` |
| Distribution | Internal + external security review |

---

## 1. Scope, method, and what is evidence

This document assesses the code **as it exists on 2026-08-23**, not as specified. Every claim falls into exactly one of three classes, and each is labelled:

- **[VERIFIED-CODE]** — read in source; file and line cited.
- **[VERIFIED-RUN]** — demonstrated by executing code on this host. Output is reproduced verbatim in §8 and Appendix A.
- **[ASSESSED]** — engineering judgement, reasoning stated so it can be disputed.

Nothing in this document is a projection of future work. Where v2 committed to a remediation that has not been built, this document says so and re-rates the underlying risk against the current tree.

**What was executed:**

| Activity | Result |
|---|---|
| `dotnet test tests/QrDiode.Core.Tests -c Release` | **88 passed, 0 failed** |
| `dotnet test tests/QrDiode.Receiver.Tests -c Release` | **9 passed, 0 failed** |
| ACL inspection of `%LocalAppData%\QrDiode\trust` | Interactive user holds `FullControl` |
| PoC harness against real `ReceiveEngine` (6 scenarios) | 4 exploitable/mismatched behaviours confirmed |

**Scope boundary.** The review covers `src/` and `tests/`. It does **not** cover: the Windows hosts, the physical optical corridor, the downstream IT system that consumes the payload store, or the human key ceremony. Those are named where they carry risk that the code cannot absorb.

---

## 2. Executive summary

QrDiode is a genuinely well-built piece of protocol engineering. The verification chain is ordered correctly and fails closed at every step; cryptography is BCL-only and correctly composed; there is no network code anywhere in the product; allocation is bounded against hostile manifests; and the test discipline is above what this class of tool normally carries. The hardening phases P1–P8 completed since v2 are real and verified.

That said, the v2 remediation register has landed **partially and unevenly**. Of fourteen committed items, **two are closed, six are partially closed, and six remain entirely open** (§4). The open set is not the cosmetic remainder — it contains the two items v2 itself flagged as "we would not go to production carrying" (host state protection, demo path), both of which are still open in their load-bearing parts.

The review also identifies **four issues not recorded in v1 or v2**. The most serious is not a theoretical weakness:

> **A single forged QR code — containing no cryptography, requiring no key material, and requiring no computation — permanently destroys a transfer in flight. The receiver correctly detects that something is wrong, then permanently refuses the genuine retransmission that the sender is still broadcasting. [VERIFIED-RUN]**

This is the collision of three individually reasonable design decisions: LT symbols carry no authenticator, the peeling decoder is first-write-wins, and a post-decode failure *settles* the session rather than re-arming it. v2 anticipated the general shape of this as R-06 and specified the fix; the fix was not built, and the practical cost is materially worse than v2's "Medium, availability" rating suggested.

### Posture verdict

| Dimension | Assessment |
|---|---|
| **Protocol design** | Strong. Above the state of practice for this class of tool. |
| **Cryptographic construction** | Sound. Correct primitives, correct composition, correct ordering. No forward secrecy (architectural), no PQC. |
| **Hostile-input handling** | Strong on the parsing path. Weak on the *availability* path (§8.3). |
| **Host / state protection** | **Weak.** The root of trust is a directory the operator's own account can rewrite. [VERIFIED-RUN] |
| **Channel integrity** | **Weak.** Symbols are unauthenticated; one frame denies a transfer. [VERIFIED-RUN] |
| **Metadata confidentiality** | **Weak.** Filename, sizes, type, counter, timestamps and key IDs are in the clear on screen. [VERIFIED-RUN] |
| **Operability / assurance** | Moderate. No CI, no signed builds, no delivery-gap detection, no counter-recovery procedure. |

**Bottom line.** The software is suitable for **controlled pilot** on a physically enclosed optical corridor with hardened endpoints. It is **not yet ready for unattended mission-critical production**, and the gap is concentrated in six specific, tractable engineering items (§9, P0 set) — not in the architecture, which is sound.

---

## 3. What changed since v2 — verified

Hardening phases P1–P8 were completed on 2026-08-23. Verified against source:

| Phase | Change | Verified |
|---|---|---|
| P1 | `global.json` SDK pin; `Directory.Build.props` with `RestorePackagesWithLockFile`, `Deterministic`; 7 lock files | ✔ [VERIFIED-CODE] — 7 `packages.lock.json` present with content hashes |
| P2 | Manifest acceptance envelope: `MaxPayloadBytes` 128 MB → 16 MB, `MaxSourceSymbols` = 65 536, symbol-size floor/ceiling | ✔ `TransferManifest.cs:44-63,140-155` |
| P3 | Stored-filename cap (`MaxStoredNameChars` = 120), start-time path-budget check | ✔ `PayloadStore.cs:33,77-84,172-195` |
| P4 | Decoder memory caps + eviction counters | ✔ `LtDecoder.cs:62-63,122-155`; `_settled` cap `ReceiveEngine.cs:75` |
| P5/P6 | **Wire change:** plaintext SHA-256 removed from the manifest; protocol version → `0x02` | ✔ `FrameFormat.cs:16`; `TransferManifest.cs` body is now 167 B fixed |
| P7 | `allowOpaqueFiles` switch on `ContentGate` / `ReceiveEngine` | ✔ mechanism exists — **but is not wired on** (§8.9) |
| P8 | State-driven demo banner in both apps | ✔ `DemoProvisioner.ArtifactsPresent()` — **detects, does not block** (§8.5) |

Separately verified as landed: **strict replay window is now the default** (`StrictModeCheck IsChecked="True"`, `MainWindow.xaml:346` → 15 minutes, `MainWindow.xaml.cs:251`). This closes v2's R-07.

---

## 4. v2 remediation register — actual status

Assessed against the current tree. This is the honest scorecard.

| ID | Committed in v2 | Status today | Evidence |
|---|---|---|---|
| R-01 | Encrypt manifest descriptor fields | 🟨 **~15% done** — only the plaintext hash left the wire (P6). Filename, content kind, original/compressed size, compression alg all still cleartext | §8.4, `TransferManifest.cs:65-83` |
| R-02 | Forward secrecy + PQC | ⬜ **OPEN** — still static-static ECDH, no ephemeral share, no ML-KEM | `Envelope.cs:35-50`, `SendSession.cs:80` |
| R-03 | Host state protection (ACLs, trust-index MAC, journal tripwire) | ⬜ **OPEN** — no ACL code, no MAC, no tripwire | §8.1 [VERIFIED-RUN] |
| R-04 | Keyed + off-host audit | ⬜ **OPEN** — chain is unkeyed SHA-256, local only | §8.6, `AuditLog.cs:26-56` |
| R-05 | Demo path out of production build | 🟨 **partial** — banner added (P8); demo code still compiled in, Start not blocked | §8.5 |
| R-06 | Authenticated symbols, conflict detection, re-arm-not-settle | 🟨 **~25% done** — only memory caps (P4). **(a) symbol MAC, (c) conflict detection and (d) re-arm are all OPEN — this is the gap exploited in §8.3** | §8.3 [VERIFIED-RUN] |
| R-07 | Strict replay window by default | ✅ **CLOSED** | `MainWindow.xaml:346` |
| R-08 | Sandboxed capture/decode | ⬜ **OPEN** — zxing-cpp and FlashCap run in-process | §8.7 |
| R-09 | Supply-chain pinning + attested builds | 🟨 **partial** — lock files and SDK pin done (P1); **no `RestoreLockedMode`, no NuGet.config, no signature verification, no SBOM, no CI, no Authenticode** | §8.12 [VERIFIED-RUN] |
| R-10 | Key-usage split, export-policy assertion | ⬜ **OPEN** — `CngKeyUsages.AllUsages`, no assertion on open | §8.2, `CngEndpointKeys.cs:66,57-61` |
| R-11 | Plaintext-residue hygiene | ⬜ **OPEN** — `.staging` never swept; clipboard export present in both apps | §8.13 |
| R-12 | Delivery-gap detection | ⬜ **OPEN** — counter gaps are silent | §8.10 |
| R-13 | Documentation-only items | 🟨 partial — recorded in code comments, not in an ops guide | `SqliteJournal.cs:120` |
| R-14 | Transactional-profile content pinning | 🟨 **~30% done** — `allowOpaqueFiles` exists but defaults true and is hard-wired true in the receiver; **no schema validation at all** | §8.9 [VERIFIED-RUN] |

**Closed: 1. Partial: 6. Open: 7.**

---

## 5. The transfer, bit by bit

This section describes exactly what happens to a byte from the moment an OT process emits it to the moment it lands in the IT payload store. All offsets verified against source.

### 5.1 Trust boundaries

```
┌── OT zone (Purdue L2/L3) ─────────┐   air gap    ┌── IT zone (L4 / DMZ) ──────────────┐
│                                   │  ░░░░░░░░░   │                                    │
│  live source / file               │  photons     │  webcam (FlashCap)                 │
│      ↓                            │   ──────▶    │      ↓  ← TB-1 hostile optical in  │
│  TransmitEngine                   │              │  luminance + zxing-cpp (native)    │
│      ↓                            │              │      ↓  ← TB-2 unverified bytes    │
│  SendSession.Create               │              │  ReceiveEngine (verification chain)│
│   compress→seal→sign→LT           │              │      ↓  ← TB-3 verified plaintext  │
│      ↓                            │              │  PayloadStore + SqliteJournal      │
│  CarouselPump → QrFrameRenderer   │              │      ↓  ← TB-4 UNGUARDED (§10.3)   │
│  StageWindow (screen)             │              │  downstream IT consumer            │
└───────────────────────────────────┘              └────────────────────────────────────┘
    Local state: CNG keys, DPAPI counter,              Local state: CNG keys, trust store,
    trust store, audit log                             journal.db, payload store, audit log
                                                       ↑ TB-5: user-writable (§8.1)
```

**TB-1** is the only inbound channel and it is physical. **TB-2** is the primary software attack surface. **TB-4 and TB-5 are the two boundaries with no enforcement**, and they are where §8's highest-rated findings live.

### 5.2 Sender pipeline — exact order

`SendSession.Create()` (`SendSession.cs:50-123`):

1. **Reject empty payload.** `plaintext.Length == 0` → `ArgumentException`.
2. **Compress.** Brotli, `SmallestSize` if ≤ 4 MiB else `Optimal`. If the result is not smaller, the plaintext is kept and `CompressionAlg.None` is recorded. *(Compress-then-encrypt — see §8.4 for the length side channel this creates.)*
3. **Generate session parameters.** `sessionId` = `Guid.NewGuid()` (v4, CSPRNG-backed on Windows); `salt` = 32 CSPRNG bytes; `nonce` = 12 CSPRNG bytes; `ltSeed` = 8 CSPRNG bytes. All via `RandomNumberGenerator`.
4. **Reserve the counter.** `CounterStore.Next()` — read, increment, write-temp, `Flush(flushToDisk: true)`, rename. **Durably flushed before the session exists**, so a crash cannot issue one counter twice. Persisted DPAPI `CurrentUser` with static entropy `"QrDiode.counter.v1"`.
5. **Build AAD** — 72 bytes, `Envelope.BuildAad()`:

   | Offset | Size | Field |
   |---|---|---|
   | 0 | 16 | `sessionId` (GUID bytes) |
   | 16 | 32 | `salt` |
   | 48 | 8 | `counter` (uint64 LE) |
   | 56 | 8 | `senderSigningKeyId` |
   | 64 | 8 | `receiverAgreementKeyId` |

6. **Key agreement.** `Z = ECDH-P256(sender_static_priv, receiver_static_pub)`, raw X-coordinate (32 B) via `DeriveRawSecretAgreement`.
7. **Key derivation.** `K_s = HKDF-SHA256(IKM = Z, salt = salt, info = "QrDiode.v1" ‖ sessionId, L = 32)`. Note the `info` label still reads `v1` — cosmetic, but it is a domain-separation label and should track the protocol version.
8. **Seal.** `ciphertext ‖ tag = AES-256-GCM(K_s, nonce, compressed, AAD)`, 128-bit tag. `Z` and `K_s` are zeroized with `CryptographicOperations.ZeroMemory`.
9. **Segment.** `symbolSize = min(1350, |ciphertext|)`; `K = ceil(|ciphertext| / symbolSize)`.
10. **Serialize + sign the manifest.** ECDSA P-256 / SHA-256, IEEE P1363 fixed-width `r‖s` (64 B).
11. **Receipt.** `SHA-256(body ‖ signature)`, first 8 bytes, hex → 16 characters, read aloud between operators. *(A 64-bit human-comparison convenience, not an authenticator — the signature is the authority.)*

### 5.3 Wire format — protocol v2

**Common header (12 B), all integers little-endian:**

| Offset | Size | Value |
|---|---|---|
| 0 | 1 | `0x4F` `'O'` |
| 1 | 1 | `0x44` `'D'` |
| 2 | 1 | `0x02` protocol version |
| 3 | 1 | frame type — `0x01` manifest, `0x02` data symbol |
| 4 | 8 | session tag = first 8 bytes of the session GUID |

**Data-symbol frame** — overhead 20 B:

| Offset | Size | Field |
|---|---|---|
| 0 | 12 | header (type `0x02`) |
| 12 | 4 | `symbolId` (uint32 LE) |
| 16 | *symbolSize* | symbol payload |
| *n−4* | 4 | CRC-32 over bytes `[0, n−4)` |

**Manifest frame** — overhead 82 B:

| Offset | Size | Field |
|---|---|---|
| 0 | 12 | header (type `0x01`) |
| 12 | 2 | `bodyLen` (uint16 LE) |
| 14 | *bodyLen* | manifest body (below) |
| 14+*bodyLen* | 64 | ECDSA P-256 signature, `r‖s` |
| *n−4* | 4 | CRC-32 |

**Manifest body** — 167 B fixed + filename:

| Offset | Size | Field | Confidentiality |
|---|---|---|---|
| 0 | 16 | `sessionId` | cleartext |
| 16 | 8 | `timestampUnixMs` (int64) | cleartext |
| 24 | 8 | `counter` (uint64) | cleartext |
| 32 | 8 | `senderSigningKeyId` | cleartext |
| 40 | 8 | `receiverAgreementKeyId` | cleartext |
| 48 | 32 | HKDF `salt` | cleartext (correct) |
| 80 | 12 | GCM `nonce` | cleartext (correct) |
| 92 | 2 | `symbolSize` | cleartext |
| 94 | 4 | `sourceSymbolCount` (K) | cleartext |
| 98 | 8 | `ltSeed` | cleartext |
| 106 | 2 | `redundancyHint` | cleartext |
| 108 | 8 | `originalSize` | **cleartext — leaks** |
| 116 | 8 | `compressedSize` | **cleartext — leaks (side channel)** |
| 124 | 8 | `ciphertextSize` | cleartext |
| 132 | 1 | `compression` (0 None / 1 Brotli) | **cleartext — leaks** |
| 133 | 32 | `SHA-256(ciphertext)` | cleartext (correct) |
| 165 | 1 | `contentKind` (0 File / 1 Xml / 2 Json) | **cleartext — leaks** |
| 166 | 1 | filename length | **cleartext — leaks** |
| 167 | ≤255 | filename (UTF-8) | **cleartext — leaks** |

Hard frame bounds: `MinFrameSize` = 17, `MaxFrameSize` = 4096 (`FrameFormat.cs:35-36`).

### 5.4 Optical layer

`QrFrameRenderer` picks the **smallest QR version that fits the largest frame in the session** at **ECC level L**, then holds that version for every frame — so the camera never re-acquires on a size change. Rendering is 1 byte/pixel Gray8, 1 pixel per module, with an 8-module quiet zone; `StageWindow` applies an *integer* scale so leftover pixels become extra white margin and the quiet zone only ever grows. `CarouselPump` pre-renders into a bounded channel (16 frames) with buffer recycling, so the UI thread only blits.

Pacing (`TransmitEngine`): operator-set 1–60 fps (default 15). A session ends on an **air-time policy**, not on success — `frames ≥ K × redundancy × loopTarget` **and** `airSeconds ≥ 6`, then a 1.5 s gap. There is no acknowledgement; there cannot be.

### 5.5 Receiver pipeline — the verification chain

`QrDecodePipeline` → `ReceiveEngine.Feed()`. Frames arriving while a decode is in flight are dropped (the carousel makes drops free).

Capture: FlashCap hands back either a DIB (`'BM'`, transcoded YUV) or a compressed frame (MJPEG/PNG, passed through). Both are converted to a top-down Gray8 plane — DIB via a hand-rolled `(B + 2G + R) >> 2` luma approximation, compressed via WIC `FormatConvertedBitmap`. Decode is zxing-cpp with `Formats = QRCode`, `TryHarder = false`, `TryRotate = false`, `TryInvert = false`, `MaxNumberOfSymbols = 2`.

Then, **in this exact order, failing closed at every step** (`ReceiveEngine.cs:129-304`):

| # | Step | Enforced by | On failure |
|---|---|---|---|
| 0 | Length bounds, magic, version, type, **CRC-32** | `FrameParser.TryParse` | `Ignored`, zero allocation |
| 1 | Manifest structural parse + acceptance envelope | `TransferManifest.TryParse` | `Rejected` |
| 2 | **Sender key in trust store** | `ITrustStore.FindBySigningKeyId` | `Rejected` |
| 3 | **ECDSA P-256 signature over the exact received body bytes** | `TransferManifest.VerifySignature` | `Rejected` |
| 4 | Addressed to this receiver's agreement key | constant-shape span compare | `Rejected` |
| 5 | Already-settled session? | `_settled` (post-signature only) | `Ignored` |
| 6 | **Anti-replay: session GUID ∧ counter > watermark ∧ \|now − ts\| ≤ window** | `SqliteJournal.Check` (WAL, `synchronous=FULL`) | `Rejected` + settle |
| — | *lock on; construct `LtDecoder`* | | |
| 7 | Symbol: session-tag match, exact length match | `FeedSymbol` | `Ignored` |
| 8 | **`SHA-256(ciphertext)` vs signed value** | `FinishTransfer` | `Rejected` + **settle** ⚠ |
| 9 | **AES-256-GCM open, AAD rebuilt from the signed manifest** | `Envelope.Open` | `Rejected` + settle |
| 10 | Brotli decompress, output hard-capped at signed `originalSize`, trailing-byte check | `TryDecompressBrotli` | `Rejected` + settle |
| 11 | Plaintext length == signed `originalSize` | `FinishTransfer` | `Rejected` + settle |
| 12 | **Content gate** — XXE-prohibited XML / depth-capped JSON | `ContentGate.Validate` | `Rejected` + settle |
| 13 | Commit anti-replay state | `SqliteJournal.Commit` | — |

Only then does the UI act: content-duplicate check by `(senderKeyId, SHA-256(plaintext))` → `PayloadStore.Save` (staging write + `fsync` + same-volume rename) → journal row + archive index row → hash-chained audit record.

**Steps 2–4 are ordered correctly and this matters:** no payload byte is interpreted, and no decoder is allocated, until an offline-provisioned signature has verified. That is the single most important property of the design and it holds.

⚠ **Step 8's "+ settle" is the defect exploited in §8.3.**

---

## 6. The fountain code, and why it is not an integrity mechanism

### 6.1 Construction

QrDiode uses an in-house **systematic LT (Luby Transform) code** — a rateless erasure code — because the channel has no return path and therefore no ACK, NAK, or retransmission request. The sender simply generates symbols forever; the receiver takes whatever the camera catches.

**Symbol generation** (`LtCode.GetNeighbors`, `LtEncoder`):

- `symbolId < K` → **systematic**: the symbol *is* source block `symbolId`, verbatim. On a clean channel the transfer therefore completes in exactly `K` frames, with zero coding overhead.
- `symbolId ≥ K` → **coded**:
  1. `mix = symbolId × 0x9E3779B97F4A7C15 ⊕ sessionSeed` — Fibonacci-hashing multiplier for domain separation, so adjacent symbol IDs get independent streams.
  2. `seed = SplitMix64(mix)` → seeds **xoshiro256++** (`DeterministicRandom`). Deliberately not `System.Random`: the algorithm must be a cross-version, cross-platform contract, because both endpoints must derive *identical* neighbour sets. This is correct and the reasoning is documented at the type.
  3. Degree `d` sampled from a **robust soliton distribution** (`c = 0.1`, `δ = 0.05`) by binary search over a precomputed CDF; clamped to `K`.
  4. `d` distinct neighbours in `[0, K)`: partial Fisher–Yates when `d > K/2` (avoids rejection stalls on dense symbols), otherwise rejection sampling into a `HashSet`. Index draws use **Lemire's unbiased bounded method** (`NextUInt32`) — no modulo bias.
  5. Symbol = XOR of those source blocks. The final block is zero-padded; XOR with zero is a no-op, so padding needs no special case.

**Decoding** (`LtDecoder`) is incremental **belief-propagation peeling**:

- A degree-1 symbol resolves its block immediately.
- Higher-degree symbols are XOR-reduced against already-known blocks. If the remaining set empties, the symbol is redundant and dropped; if exactly one remains, it resolves; otherwise it is buffered and indexed by every unresolved neighbour in `_bySource`.
- `Resolve` cascades: resolving a block reduces every dependent symbol, which may cascade further, driven by an explicit queue rather than recursion.

**Bounds (P4, verified):** buffered symbols ≤ `clamp(4K, 1024, 8192)`; retained symbol IDs ≤ `clamp(16K, 4096, 131072)`; both FIFO-evicting, with `BufferedEvictions` / `SeenIdEvictions` counters. Eviction from the duplicate-suppression set is safe because peeling is idempotent over identical bytes — a re-arriving forgotten symbol is simply re-reduced. This reasoning is correct and is documented at the method.

### 6.2 The security consequence

**Every input the code needs is public.** `ltSeed`, `K`, `symbolSize` and the session tag are all cleartext in the signed manifest, which is broadcast on screen every 20 frames. `LtCode.GetNeighbors` is a pure function of `(seed, symbolId, K)`. Therefore:

> **Anyone who can read the screen can construct symbols that the decoder will accept as valid.**

That is not a flaw in the fountain code — an erasure code is not supposed to provide integrity. The design intent is that integrity comes end-to-end, from `SHA-256(ciphertext)` in the signed manifest plus the GCM tag. And it does: **a poisoned decode can never produce accepted plaintext.** Confidentiality and authenticity are intact.

What is *not* intact is **availability of the transfer**, because of two further properties:

1. **`Resolve` is first-write-wins** (`LtDecoder.cs:159`): `if (_source[sourceIndex] is not null) return;`. The first symbol to claim a block owns it. A forged block therefore silently displaces the genuine one that arrives later.
2. **A post-decode failure settles the session** (`ReceiveEngine.cs:324-335`): `RejectAndReset` calls `Settle(sessionId)`, and `FeedManifest` then returns `Ignored` for that session forever.

Combined: one forged symbol poisons a block, the ciphertext hash correctly detects the corruption, and the receiver then permanently refuses the genuine carousel that is still playing. **The error detection is correct; the error recovery is inverted.** §8.3 demonstrates this.

### 6.3 Throughput

Software is not the bottleneck. With the systematic pass, a clean channel needs exactly `K` frames. Default redundancy is 3× per loop with a 3-loop target, i.e. up to 9× `K` frames of air time per session — deliberately generous because there is no feedback. At the default 1350-byte symbol size and 15 fps, the useful ceiling is roughly 20 KB/s; the screen→camera hop dominates entirely.

---

## 7. Controls that are implemented and working

Stated plainly so the finding list is not read as the whole picture. All verified in source and exercised by the test suites.

| Control | Implementation | Standard alignment |
|---|---|---|
| **Physical unidirectionality** | No network API anywhere in `src/` — verified by exhaustive search for `HttpClient`, `Socket`, `TcpClient`, `NetworkStream`, `HttpListener`, `UdpClient`, `NamedPipe`, `WebSocket`, `SerialPort`: **zero matches** | IEC 62443-3-3 FR 5 (RDF); NIST SP 800-82r3 unidirectional gateway pattern |
| **Confidentiality in transit** | AES-256-GCM, 128-bit tag, one message per key | SP 800-38D; SP 800-53r5 SC-8, SC-8(1), SC-13 |
| **Key establishment** | ECDH P-256, `DeriveRawSecretAgreement` → HKDF-SHA256 with per-session salt and session-bound `info` | SP 800-56A Rev. 3; RFC 5869; SC-12 |
| **Authenticity** | ECDSA P-256 / SHA-256, verified against an offline-provisioned trust store **before any payload byte is interpreted** | FIPS 186-5; SI-7, AU-10 |
| **Cryptographic binding** | GCM AAD carries session identity; the signed manifest carries `SHA-256(ciphertext)`. Manifest and ciphertext cannot be mixed and matched — covered by a negative test | SI-7 |
| **Anti-replay (three independent factors)** | Session GUID dedupe **∧** per-sender-key monotonic counter high-watermark **∧** ±15 min timestamp window, all in one transactional SQLite store (WAL, `synchronous=FULL`) | SC-23 |
| **Counter integrity** | Reserved and `fsync`-flushed *before* the session is created; DPAPI-protected at rest; write-temp-then-rename | — |
| **Key storage** | Non-exportable Windows CNG keys, Platform Crypto Provider (TPM) preferred with documented software fallback; only public bundles ever leave a host | IA-5, SC-12; IEC 62443-4-2 CR 1.5 |
| **Hostile-input parsing** | Span-based, allocation-free-on-reject frame parser; every length checked before every read; CRC-32 pre-filter | SI-10 |
| **Allocation-amplification defence** | Manifest acceptance envelope bounds payload (16 MiB), K (65 536), and symbol size before the decoder is built (P2) | SI-10 |
| **Zip-bomb defence** | Brotli output hard-capped at the *signed* original size, plus a trailing-byte check that fails closed if the stream over-runs | SI-10 |
| **XXE / entity expansion** | `DtdProcessing.Prohibit`, `XmlResolver = null`, `MaxCharactersFromEntities = 0` — in both the content gate **and** the sender-side formatter | SI-10; OWASP XXE |
| **JSON abuse** | `Utf8JsonReader`, `MaxDepth = 64`, comments and trailing commas disallowed | SI-10 |
| **Path traversal / reserved names** | Invalid characters replaced, leading dots stripped, length-capped with extension preserved; session-GUID prefix makes Windows device names structurally unreachable | SI-10 |
| **Atomic materialization** | Staging write + `fsync` + same-volume rename, `overwrite: false` | SI-7 |
| **Tamper-evident audit** | Append-only hash-chained JSONL both ends; rejections are first-class records; `AuditLog.Verify` returns the index of the first broken record | AU-2, AU-9 *(but see §8.6)* |
| **Post-hoc integrity proof** | Archive tab re-hashes bytes on disk against the signed hash — the only verification available after the fact on a one-way link | SI-7 |
| **Memory hygiene** | ECDH shared secret and session key zeroized in `finally` blocks | SC-28 (partial) |
| **Build determinism** | `Deterministic`, SDK pinned, 7 lock files with content hashes | SR-4 *(partial — see §8.12)* |

**Test depth (executed, 97 tests total).** Optical loopback through real rendered QR images; LT property tests under 30–50% loss and shuffling; parser bit-flip fuzzing; adversarial symbol-ID churn against the memory caps; crypto negative paths (tamper, wrong AAD, wrong recipient, replay, stale counter, wrong receiver); XXE and zip-bomb rejection; hostile-input formatting; back-to-back sessions on one engine; filename edge cases including 255-character names and reserved device names.

---

## 8. Findings

**Severity scale.** `Critical` — exploitable with no precondition, breaks a core guarantee. `High` — breaks a core guarantee under a realistic precondition (user-level code execution, or physical access to the optical corridor). `Medium` — meaningful weakening, or a guarantee that depends on an unenforced deployment assumption. `Low` — defence-in-depth, hygiene, or operability. `Info` — no security impact.

Each finding names the precondition explicitly. Severity is rated **for the stated transactional, mission-critical deployment profile**.

| ID | Title | Severity | v2 ref |
|---|---|---|---|
| F3-01 | Trust store is writable by any code running as the operator | **High** | R-03 (open) |
| F3-02 | CNG keys opened without export-policy or provider assertion | **High** | R-10 (open) |
| F3-03 | One unauthenticated QR frame permanently destroys a transfer | **High** | R-06a/c/d (open) |
| F3-04 | Manifest metadata broadcast in cleartext, plus a compression side channel | **High** | R-01 (mostly open) |
| F3-05 | Demo provisioning is reachable in the shipped build and does not block Start | Medium | R-05 (partial) |
| F3-06 | Audit chain is unkeyed, local-only, and unbounded | Medium | R-04 (open) |
| F3-07 | Native optical decoding runs in-process, unsandboxed | Medium | R-08 (open) |
| F3-08 | No forward secrecy; no post-quantum path | Medium | R-02 (open) |
| F3-09 | Transactional profile is not enforced; no schema validation | Medium | R-14 (partial) |
| F3-10 | Delivery gaps are silent | Medium | R-12 (open) |
| F3-11 | Sender counter loss permanently bricks the link, with no recovery tooling | Medium | **new** |
| F3-12 | Supply chain pinned but not enforced; no CI, no signed builds | Medium | R-09 (partial) |
| F3-13 | Plaintext residue: staging never swept, clipboard export, no at-rest encryption | Low | R-11 (open) |
| F3-14 | Sender accepts 64 MB; receiver rejects above 16 MB | Low | **new** |
| F3-15 | Trust bundles are unsigned and not curve-pinned | Low | **new** |
| F3-16 | Decoder degradation counters exist but are never surfaced | Low | **new** |
| F3-17 | `OpenOrCreate` silently mints a new identity on a typo | Info | — |

---

### F3-01 · Trust store is writable by any code running as the operator — **High**

**Precondition:** any code execution as the logged-on interactive user on the receiver host. No elevation required.

**[VERIFIED-RUN]** ACL inspection of the live state directory:

```
C:\Users\<user>\AppData\Local\QrDiode\trust
  NT AUTHORITY\SYSTEM        FullControl  Allow  (inherited)
  BUILTIN\Administrators     FullControl  Allow  (inherited)
  <MACHINE>\<user>           FullControl  Allow  (inherited)
```

**[VERIFIED-CODE]** `DirectoryTrustStore` (`TrustStore.cs:94-108`) enumerates `*.json` in that directory and imports every parseable bundle. There is no integrity check on the directory, no MAC over its contents, no signature on the bundles, and no allow-list of expected key IDs.

**Impact.** The receiver's entire authenticity guarantee reduces to "a JSON file in a user-writable folder." An attacker who drops `rogue.json` containing their own public keys becomes a trusted sender. From that moment the receiver will verify their signatures perfectly, accept their manifests, decrypt their payloads, pass them through the content gate, store them, and record them in the audit log as legitimately verified transfers from a trusted peer. **This is silent — every control downstream reports success, because from the code's point of view nothing is wrong.**

This is the single highest-leverage finding in the review: it defeats the root of trust using the weakest possible form of compromise, and it leaves no evidence distinguishable from normal operation.

**Remediation.**
1. Run the receiver under a dedicated non-interactive service account. ACL `%LocalAppData%\QrDiode\trust`, `journal.db`, `sender-counter.bin` and `receiver-settings.json` to that account (RW) and Administrators; **deny write to interactive operators**. The payload store stays operator-readable.
2. Maintain a **DPAPI machine-scope MAC over a trust-directory index** (bundle name + SPKI SHA-256 for each entry), written only by an elevated ceremony tool. Verify it at Start; refuse to start on mismatch, with an audited alarm.
3. Add a **journal tripwire**: if `journal.db` is absent or freshly initialized while trust bundles exist, treat it as a watermark-regression event — blocking, audited, requiring explicit acknowledgement.
4. Make every trust-store mutation an audited, countersigned ceremony record.

---

### F3-02 · CNG keys opened without export-policy or provider assertion — **High**

**Precondition:** code execution as the target user, *before* first key creation, on either host.

**[VERIFIED-CODE]** `CngEndpointKeys.OpenOrCreateKey` (`CngEndpointKeys.cs:55-84`):

```csharp
if (CngKey.Exists(name))
{
    var opened = CngKey.Open(name);
    return (opened, opened.Provider?.Provider == PlatformProvider);
}
```

Key names are deterministic and public: `QrDiode.{endpointName}.sign` and `QrDiode.{endpointName}.kex`. When a key already exists it is opened **unconditionally** — its export policy, provider and algorithm are never asserted. `ExportPolicy = CngExportPolicies.None` is applied only on the *creation* path.

**Impact.** An attacker who pre-creates an **exportable, software-KSP** key under the well-known name owns the sender's signing private key from the moment the operator first "opens" that endpoint. The app then uses the attacker's key believing it to be non-exportable and possibly TPM-backed. The UI pill will read `✔ software KSP` — indistinguishable from a legitimate machine without a TPM, which is a supported and unremarkable configuration.

Chained with F3-01 this yields end-to-end forgery: attacker-controlled sender key on one side, attacker-installed trust bundle on the other, and a receiver that reports every forged transfer as fully verified.

Separately, `KeyUsage = CngKeyUsages.AllUsages` (`CngEndpointKeys.cs:66`) is broader than needed. The practical risk is low — the signing and agreement keys are distinct CNG objects with distinct algorithms — but it contradicts least privilege and R-10.

**Remediation.**
1. On open, assert `ExportPolicy == CngExportPolicies.None`, the expected `CngAlgorithm`, and the expected provider. Refuse and raise an audited alarm otherwise.
2. Split usage at creation: `CngKeyUsages.Signing` for the ECDSA key, `CngKeyUsages.KeyAgreement` for the ECDH key.
3. Surface TPM-backing as a **policy requirement**, not a status pill: a production profile should refuse to run on the software KSP.
4. Bind the endpoint identity to the ceremony record so a substituted key produces a fingerprint mismatch at the next audit.

---

### F3-03 · One unauthenticated QR frame permanently destroys a transfer — **High**

**Precondition:** ability to present a QR code in the receiver camera's field of view during a session. In an open-room deployment this is trivial; in a properly enclosed optical corridor it requires physical access to the corridor, which reduces exposure but does not eliminate it (maintenance windows, insider access, a reflective surface).

**[VERIFIED-RUN].** Full harness in Appendix A. Verbatim output:

```
K = 90, symbolSize = 1350
engine verdict on the single forged frame: SymbolAccepted
outcome -> REJECTED: Ciphertext hash mismatch after decode
sender's carousel replayed in full afterwards, completes = False
CONTROL (no injection) completes = True
```

**Attack, in full.**

1. Read the session tag and symbol size off the screen — they are cleartext in every frame.
2. Emit **one** QR code containing a data frame with that session tag, `symbolId = K − 1` (a *systematic* ID), and 1350 bytes of `0xA5`. Append a correct CRC-32 — the algorithm is public and unkeyed.
3. Done. No key material, no cryptography, and **no search**: the systematic ID path (`LtDecoder.cs:73-77`) resolves the block directly.

**Mechanism.** The forged symbol resolves block `K−1` before the systematic pass reaches it. `Resolve` is first-write-wins, so when the genuine block `K−1` arrives it is silently discarded (`LtDecoder.cs:159`). The decode completes with one corrupt block. Step 8 correctly detects the corruption via the signed ciphertext hash — and then `RejectAndReset` **settles** the session (`ReceiveEngine.cs:328`). Every subsequent manifest for that session returns `Ignored` (`ReceiveEngine.cs:171-172`). The sender, having no feedback channel, keeps broadcasting the genuine carousel for the rest of its air-time budget into a receiver that will never look at it again.

A second variant was also verified: searching the public `ltSeed` for a **degree-1 coded symbol** targeting a chosen block took **88 trials** — microseconds — and produced the identical outcome. The systematic-ID variant is simply cheaper.

**Impact.** Surgical, silent, repeatable denial of individual transfers at a cost of one frame each. Against a mission-critical transactional link this is worse than jamming: jamming is loud and obviously physical, whereas this presents to the operator as an occasional "ciphertext hash mismatch," which reads like a marginal optical link rather than an attack. Combined with F3-10 (no gap detection), an attacker can suppress *chosen* transactions — say, every alarm event — while the link continues to look healthy.

**Remediation** (v2's R-06, now with the priority the evidence justifies):
1. **Re-arm instead of settle.** A post-decode failure should discard decoded state but keep the session *acceptable* while its manifest is still on air. This alone converts permanent denial into a self-healing delay, and it is a small, well-contained change.
2. **Per-symbol authenticator.** Append an 8-byte truncated HMAC-SHA256 over `symbolId ‖ payload`, keyed by `HKDF(K_s, info = "QrDiode.v2.symbol")`, verified before a symbol enters the decoder. Cost: 8 bytes in ~1370 (0.6%). This makes symbol forgery require the session key, i.e. impossible for an observer.
3. **Conflict detection.** Same `symbolId`, different bytes → discard both, increment a conflict counter, raise an operator alarm. This is a high-fidelity indicator of active optical attack and there is currently nothing like it.
4. Prefer the genuine systematic symbol on conflict, since systematic IDs are unambiguous.

*Note: (1) is worth shipping on its own even before (2), because it removes the permanence — which is what turns a recoverable glitch into an outage.*

---

### F3-04 · Manifest metadata broadcast in cleartext, plus a compression side channel — **High**

**Precondition:** line of sight to the OT screen, or any recording of it. No key material.

**[VERIFIED-RUN]** — parsing a manifest frame with no keys whatsoever:

```
filename       = LINE7-BATCH-2291-assay-result.json
contentKind    = Json
originalSize   = 53 B
compressedSize = 52 B          (compression ratio side channel)
counter        = 4
sessionId      = 928fa3a6-3955-4400-bac0-0d1cb562d6d6
senderKeyId    = DC55B8607D72061A
timestamp      = 2026-08-23T11:46:11.0180000+00:00
```

**Impact.**

- **Filenames are frequently the payload.** In OT contexts a filename routinely encodes line, batch, asset, shift and transaction type. `LINE7-BATCH-2291-assay-result.json` discloses essentially everything an adversary wants without breaking any cryptography.
- **`contentKind` + `originalSize` + `counter` + `timestamp`** together give a complete traffic-analysis picture: what kind of transaction, how big, how often, in what order, from which key.
- **Compress-then-encrypt with the compressed length published** is a length side channel of the CRIME/BREACH family. Where an adversary can influence part of a payload that also contains a secret, the compression ratio leaks information about the secret. For fixed-schema plant events the exploitable margin is narrow — but the channel is real, it is free to the attacker, and stating otherwise would be dishonest.

v2 identified this as R-01 and specified the fix. P6 delivered only the smallest part of it (removing the plaintext hash, which was the sharpest single leak — a hash-confirmation oracle against known documents). **The bulk of the descriptor is still on the wire.**

**Remediation.** Complete R-01: split the manifest into a public coding header (session ID, timestamp, counter, key IDs, salt, nonce, symbol size, K, LT seed, redundancy hint, ciphertext size and hash, descriptor length) and an **AEAD-encrypted descriptor** (filename, content kind, original size, compressed size, compression algorithm) sealed under the session key with the public header as AAD. Signature still covers public header ‖ descriptor ciphertext, and is still verified *before* decryption is attempted. Frame-budget arithmetic in v2 §3 shows this fits V30-L comfortably.

Interim mitigations available today at near-zero cost: transmit opaque filenames (`{counter}.json`) and carry the real name inside the payload; and pad payloads to fixed size buckets to blunt both `originalSize` and `compressedSize` analysis.

---

### F3-05 · Demo provisioning reachable in the shipped build — **Medium**

**[VERIFIED-CODE]** `DemoProvisioner` (`DemoProvisioner.cs`) is compiled unconditionally — there is no `#if DEMO`. `Provision()` creates **both** endpoints' private keys on one machine and writes both public bundles into the trust store with `File.WriteAllText`, which **always overwrites** (`DemoProvisioner.cs:50-52`). It is bound to a "⚡ Demo setup" button in both apps.

P8 added state-driven banners (`RefreshDemoBanner`, both apps) that persist across restarts and correctly key off `ArtifactsPresent()` rather than the click. That is a genuine improvement and the reasoning behind it is sound.

**What is still open is the load-bearing half:** the receiver **does not refuse to start** with demo bundles present. A single misplaced click on a production receiver installs a trusted sender whose private key sits on the same host, and the only consequence is a banner an operator can look past.

**Remediation.** Compile the demo path out under a build flag for release; and independently, refuse to Start (with an audited, blocking alarm) when `demo-ot` / `demo-it` bundles are present in a production profile. The two controls should be independent so neither is a single point of failure.

---

### F3-06 · Audit chain is unkeyed, local-only, and unbounded — **Medium**

**[VERIFIED-CODE]** `AuditLog` (`AuditLog.cs`) chains records with plain `SHA-256(previous record)`. There is no key, no signature, and no off-host copy.

- **Forgeable by anyone who can write the file.** The chain is deterministic and unkeyed, so an attacker with write access — which per F3-01 is any code running as the operator — can rewrite arbitrary history and recompute every hash. `AuditLog.Verify` will then report the chain intact. This gives tamper-*evidence* against accidental corruption only, not against an adversary. It does not meet AU-9's intent and it does not support AU-10 non-repudiation.
- **No rotation or retention.** `audit\*.jsonl` grows without bound, and `ReadLastHash` (`AuditLog.cs:91-109`) reads the **entire file** on every construction — i.e. on every app start. On a long-lived mission-critical receiver this is unbounded disk growth plus linearly-growing startup cost.

**Remediation.** (a) Chain-head **countersignature**: every N records and at Stop, sign the current head hash with the endpoint ECDSA key and write it into the chain. (b) **Ship audit records off-host** to a collector — the receiver host has a network even though the application must not; use an OS-level agent. Off-host shipping is the load-bearing control, because an attacker with code execution on the box can always forge *continuations*; what they must not be able to do is rewrite history that has already left. (c) Implement rotation with an explicit carry-over record binding each new file to the previous file's head hash, and index the head so startup is O(1).

---

### F3-07 · Native optical decoding runs in-process, unsandboxed — **Medium**

**[VERIFIED-CODE]** `QrDecodePipeline` runs FlashCap capture, luminance conversion and **native zxing-cpp** decoding inside the receiver process, which also holds the trust store, the CNG key handles, the journal and the payload store. This is the process's untrusted-input boundary (TB-1), and the parser is C++.

A memory-safety defect in zxing-cpp reachable from a crafted QR image is a direct path to code execution in the process that owns the verification chain. This is not hypothetical for barcode decoders as a class.

**Additionally [VERIFIED-CODE]:** `TryDibToLuminance` (`QrDecodePipeline.cs:171-207`) reads `width`, `rawHeight`, `bpp` and `pixelOffset` from the DIB header and validates `width > 0`, `rawHeight != 0`, `bpp ∈ {24,32}` and `pixelOffset + stride × height ≤ length` — but applies **no upper bound on dimensions**. For very large `width`, `stride = (width * bytesPerPixel + 3) & ~3` and `new byte[width * height]` overflow `int`, which can defeat the length check and then throw. `OnPixelBuffer` wraps the call in `try`/`finally`, **not** `try`/`catch`, so the exception escapes on a FlashCap callback thread. The compressed path (`TryCompressedToLuminance`) *is* correctly wrapped; the DIB path is not.

Reachability requires a malicious or malfunctioning camera driver rather than a crafted image, so this is defence-in-depth — but it is a free fix and the asymmetry with the compressed path looks like an oversight rather than a decision.

**Remediation.** Move capture, luminance conversion and decode into a **child process** with a restricted token / AppContainer: no network, no filesystem write outside its working set, job-object memory cap. The parent receives only decoded payload bytes (≤ 4096 B each) over a pipe, and the verification chain stays in the parent. Child crash → automatic restart + audit event; the carousel makes the lost frames free. Independently: bound DIB dimensions to a sane maximum, perform the arithmetic in `long`, and wrap the whole callback body in `try`/`catch`.

---

### F3-08 · No forward secrecy; no post-quantum path — **Medium**

**[VERIFIED-CODE]** `Envelope.DeriveKey` (`Envelope.cs:35-50`) performs **static-static** ECDH: the sender's long-term agreement key against the receiver's long-term agreement key. Per-session variation comes only from the salt and session ID in the HKDF, not from any ephemeral share.

**Impact.** An adversary who records the optical channel — trivially, with a camera — and later obtains **either** endpoint's static agreement private key can decrypt **every session ever recorded**, retroactively and completely. This is textbook harvest-now-decrypt-later, and an optical channel is unusually easy to record at scale. There is also no PQC path, so a future cryptographically-relevant quantum computer recovers the same archive.

**Assessment.** Partial forward secrecy is achievable **without** violating unidirectionality, and the gap between "none" and "partial" is large:

- A **per-session sender-ephemeral P-256 share** carried in the manifest (33 bytes compressed) with `secret = HKDF(ECDH(eph, recv_static) ‖ ECDH(send_static, recv_static))` removes sender-key compromise from the picture entirely. Authenticity still comes from ECDSA. This is cheap and should be considered mandatory.
- **Receiver-key rotation** on a defined cadence (90 days, with an overlap window via the existing key-ID mechanism) bounds the receiver-side exposure to one rotation period.
- **Hybrid ML-KEM-768** encapsulation concatenated into the HKDF IKM addresses the quantum archive risk, at the cost of ~1088 bytes of manifest — which pushes manifest frames from V30-L to V40-L and measurably degrades camera acquisition. That trade-off must be benchmarked, not assumed.

**Irreducible residue:** with no return channel there is no interactive ratchet, so compromise of the receiver's *current* keys always decrypts traffic within the active rotation window. That is an architectural floor, not a defect. Anyone whose threat model cannot accept it must shorten the rotation cadence.

Signatures should migrate to ML-DSA eventually, but the urgency is lower: signatures are verified at receive time, so a future quantum adversary can forge *new* traffic but cannot retroactively break the authenticity of *recorded* transfers. Claiming "quantum-safe" for a hybrid-KEM-only design would be wrong; the honest statement is that hybridization closes the confidentiality archive risk and leaves signature migration as roadmap.

---

### F3-09 · Transactional profile is not enforced; no schema validation — **Medium**

The stated deployment carries **XML/JSON transactions only, no files**. The code does not enforce that.

**[VERIFIED-CODE]** `MainWindow.xaml.cs:255` constructs `new ReceiveEngine(_trust, _journal, _keys)` — `allowOpaqueFiles` defaults to `true` (`ReceiveEngine.cs:101`). The P7 switch exists and is tested, but **it is not wired on, and there is no UI or settings control for it.** As shipped, the receiver accepts `ContentKind.File` — arbitrary opaque bytes, never parsed, written straight to the store. The sender's `EnqueueFile` and the README both still advertise file transfer.

**[VERIFIED-RUN]** Even with `allowOpaqueFiles: false`, the gate is well-formedness only:

```
S5: arbitrary-shaped JSON accepted under transactional profile = True
```

`{"totally":"unrelated","shape":[1,2,3]}` passes every check. `ContentGate` validates that XML and JSON *parse*; it does not validate that they are the transactions this link is supposed to carry.

**Impact.** The claim the architecture wants to make — "every payload that reaches the store has been parsed by a hardened parser and conforms to an expected transaction schema" — is currently false on both halves. A compromised or malfunctioning sender can put arbitrary bytes into the IT payload store, and whatever consumes that store (see §10.3) will receive them.

**Remediation.**
1. Pass `allowOpaqueFiles: false` in the receiver, and make it a deployment profile rather than a constructor default. Remove or gate the sender's file-send path. Correct the README.
2. Add **schema pinning**: a per-sender allow-list of expected XSD / JSON Schema documents, provisioned in the same ceremony as the trust bundles. Schema failure is a rejection like any other — audited and archived.
3. Tighten `MaxPayloadBytes` from 16 MiB to the real transaction distribution (~1 MiB) once measured. One constant.

*Schema validation constrains structure, not semantics. A compromised sender emitting well-formed lies is §10.1 and no receiver-side parser can fix it.*

---

### F3-10 · Delivery gaps are silent — **Medium**

**[VERIFIED-CODE]** The receiver enforces `counter > watermark` but never reports the *distance*. Accepting counter 900 when the watermark was 850 is indistinguishable from accepting 851. On a channel with no retransmission request, the counter sequence is the **only** evidence that anything was lost.

Losses are entirely plausible: the sender's `TrimQueue` silently drops queued payloads beyond depth 14 when the source outruns the stage (`TransmitEngine.cs:125-140`); a session can be skipped when the stage closes mid-encode; the camera can miss an entire session; and per F3-03 an attacker can suppress chosen transfers deliberately.

**Impact.** For a mission-critical transactional feed, silent loss is often worse than detected failure — downstream systems reconcile against an incomplete picture with no indication that it is incomplete.

**Remediation.** On accepting counter `c` against watermark `w`, if `c > w + 1` raise a first-class inbox, archive and audit event: "`c − w − 1` transfer(s) from key `k` never arrived." Make the sender's queue-trim events prominent UI alarms with a daily audited tally. Gaps become *detectable*, never *recoverable* — reconciliation stays an operations loop, and if the business process cannot tolerate that loop's latency, this medium is the wrong transport.

---

### F3-11 · Sender counter loss permanently bricks the link — **Medium** *(new)*

**[VERIFIED-RUN]:**

```
S6: counter 900 delivered = True
S6: after counter reset, verdict = Rejected: Replay check failed: StaleCounter
```

**Mechanism.** `CounterStore` persists to `%LocalAppData%\QrDiode\sender-counter.bin`, DPAPI-protected under **`DataProtectionScope.CurrentUser`**. If that file is lost, corrupted, or becomes undecryptable, `Read()` returns 0 and the next session is issued counter 1. The receiver's watermark is still at 900, so **every subsequent transfer is rejected as `StaleCounter`, permanently.**

Realistic triggers, none of which are attacks: user-profile rebuild or roaming-profile corruption; running the sender under a different Windows account (DPAPI `CurrentUser` cannot decrypt across users); disk restore from a backup predating recent sessions; OS reinstall.

**Impact.** Total, silent, one-way loss of the link. The sender shows healthy sessions going out; the receiver rejects everything. Because the channel is unidirectional, **the sender has no way to learn this** — the OT operator sees a working stage and a draining queue. Recovery requires either a full key rotation or a manual watermark reset on the IT side, and **neither procedure nor tooling exists**.

**Remediation.**
1. Protect the counter with `DataProtectionScope.LocalMachine` plus an ACL, so a profile change does not orphan it, and store a **backup copy** alongside the CNG key material.
2. On sender start, if the counter file is missing while the signing key exists, **refuse to transmit** and raise a blocking alarm — a fresh counter against an established key is precisely the state that bricks the link.
3. Provide an audited, two-person **watermark-reset tool** on the receiver, and document the procedure in the ops runbook.
4. Consider deriving the counter floor from a monotonic source (e.g. TPM monotonic counter) so it cannot regress.

---

### F3-12 · Supply chain pinned but not enforced — **Medium**

P1 was real: 7 `packages.lock.json` files with content hashes, SDK pinned via `global.json`, `Deterministic` on. Verified: the receiver's lock file pins 12 packages including the three with native blobs — `ZXingCpp 0.5.3`, `FlashCap 1.11.0`, `SQLitePCLRaw.bundle_e_sqlite3 3.0.5`, plus `Microsoft.Data.Sqlite 10.0.10`.

**[VERIFIED-RUN]** What is missing:

- **`RestoreLockedMode` is not set anywhere.** Lock files are therefore *advisory*: `dotnet restore` will happily resolve a different graph and silently rewrite them. The pin only holds if nobody restores with a changed dependency.
- **No `NuGet.config`** — no package source mapping, no upstream allow-list, no signature verification.
- **No CI pipeline of any kind** (no `.yml`/`.yaml` anywhere in the tree). Nothing enforces that tests pass, that the lock files are unchanged, or that the build is reproducible.
- **No SBOM, no Authenticode signing, no WDAC/AppLocker policy.**

**Impact.** The strongest current claim is "the graph was pinned at some point," not "the shipped binary is the reviewed code." For a mission-critical OT/IT boundary component, provenance from source to deployed binary is the assurance that matters most.

**Remediation.** Set `RestoreLockedMode=true` in CI (and `--locked-mode` in the pipeline). Add a `NuGet.config` with source mapping and `signatureValidationMode=require`. Stand up CI that builds, tests, verifies lock files are unchanged, emits a CycloneDX SBOM, and Authenticode-signs the output. Deploy WDAC/AppLocker on both endpoints allowing only the signed build. Monitor OSV/NVD for the three native dependencies specifically.

*Accepted residue: a poisoned upstream version that gets pinned is not addressed by pinning. Mitigation is dependency-diff review and the deliberately tiny dependency set — which is genuinely a strength here.*

---

### F3-13 · Plaintext residue — **Low**

Three distinct issues, all R-11:

- **Staging is never swept.** `PayloadStore.Save` writes `<staging>\<name>.tmp`, `fsync`s, then renames. If the process dies between those steps the `.tmp` file — **full decrypted plaintext** — remains indefinitely. Nothing sweeps `.staging` at Start or after a materialization failure.
- **Clipboard export is present in both apps** (`MainWindow.xaml.cs:742`, `MainWindow.Archive.cs:374`, sender `MainWindow.xaml.cs:457`), pushing payload content into a system-wide shared surface readable by any process on the desktop.
- **No application-level encryption at rest.** Payload files, `.meta.json` sidecars and `journal.db` are all cleartext. Note that `journal.db` stores a `snippet` column containing a **140-character extract of the decrypted payload** for every arrival — the archive index is not metadata-only.

**Remediation.** Sweep `.staging` at Start and after any failure. Add a production profile that removes clipboard export. Require BitLocker (or equivalent) as a documented deployment control and state explicitly that at-rest protection is environmental, not application-provided. Best-effort zeroization of plaintext buffers is worth doing but must be documented as best-effort — managed memory makes guarantees impossible and pretending otherwise would be dishonest.

---

### F3-14 · Sender accepts 64 MB; receiver rejects above 16 MB — **Low** *(new)*

**[VERIFIED-RUN]:**

```
S3: receiver MaxPayloadBytes = 16 MB
S3: sender encoded a 17 MB payload without complaint = True
S3: receiver verdict on its manifest = Rejected: Manifest parse: Original size out of range.
```

The sender's browse dialog enforces a 64 MB limit (`MainWindow.xaml.cs:298`); `SendSession.Create` enforces nothing; `TransferManifest.TryParse` rejects above 16 MiB. A payload between the two is encoded, queued, and broadcast for its full air-time budget — potentially tens of minutes — while the receiver rejects its manifest in microseconds. With no back-channel the OT operator sees a normal, healthy transmission.

**Remediation.** Enforce `TransferManifest.MaxPayloadBytes` at `SendSession.Create` and in the sender UI, from the shared constant. Fail fast and loudly at queue time.

---

### F3-15 · Trust bundles are unsigned and not curve-pinned — **Low** *(new)*

`PublicKeyBundle.Parse` validates the format string, the name length, and rejects unknown JSON members (good — strict deserialization is the right default). It does **not** verify that the imported keys are on **P-256**. `ToPeerKeys` calls `ECDsa.Create()` / `ECDiffieHellman.Create()` and imports whatever SPKI it is given, so a P-384 or P-521 bundle imports successfully. Because `FrameFormat.SignatureSize` is hard-coded to 64 bytes, such a peer can never verify anything — an availability failure discovered at transfer time rather than at import time.

Bundles are also unsigned by design; their authority is the ceremony record and the out-of-band fingerprint comparison. That is a defensible choice, but it is exactly what makes F3-01 so effective, and it should be stated as an explicit dependency rather than left implicit.

**Remediation.** Assert `ECCurve.NamedCurves.nistP256` at import and reject otherwise, with a clear message. Add a validity window to the bundle format (advisory) and make the ceremony record the authority, countersigned per R-03.

---

### F3-16 · Decoder degradation counters exist but are never surfaced — **Low** *(new)*

P4 added `BufferedEvictions` and `SeenIdEvictions` with the stated intent that "a decode that silently discarded equations must not look like a clean one" (`LtDecoder.cs:44-46`). The counters are correct and tested. **[VERIFIED-CODE]** they are read **only by tests** — no UI element, audit record or telemetry line reads either property. The intent is documented but not delivered: in production a cap-limited decode is still indistinguishable from a clean one.

**Remediation.** Surface both counters on the receiver's telemetry line and include them in the `receive.completed` / `receive.rejected` audit records. Sustained non-zero evictions are a strong indicator of either a badly degraded optical link or symbol-injection activity (F3-03) — it is a ready-made detection signal that is currently discarded.

---

### F3-17 · `OpenOrCreate` silently mints a new identity on a typo — **Info**

`CngEndpointKeys.OpenOrCreate` creates keys when the named endpoint does not exist. A mistyped endpoint name therefore silently produces a brand-new identity rather than an error. The system fails closed (the new key is in nobody's trust store, so nothing verifies), but the operator's feedback is "keys opened, ✔ software KSP" followed by unexplained rejections at the far end. Split the operations: an explicit `create` versus a default `open`, with open failing loudly on an unknown name.

---

## 9. Prioritized remediation roadmap

Ordered by risk reduction per unit of engineering effort, not by severity alone.

### P0 — before unattended mission-critical production

| # | Action | Closes | Effort |
|---|---|---|---|
| 1 | **Re-arm instead of settle** on post-decode failure | F3-03 (the permanence) | **Very low** — one call site |
| 2 | Wire `allowOpaqueFiles: false`; enforce `MaxPayloadBytes` sender-side | F3-09, F3-14 | **Very low** — two constants |
| 3 | Assert CNG export policy, provider and algorithm on open; split key usage | F3-02 | Low |
| 4 | ACL the state directory + trust-index MAC + journal tripwire; service accounts | F3-01 | Medium |
| 5 | Per-symbol HMAC + conflict detection + surface eviction counters | F3-03, F3-16 | Medium — wire change |
| 6 | Counter-loss guard: `LocalMachine` DPAPI, refuse-to-start on missing counter, watermark-reset tool | F3-11 | Low |
| 7 | Block Start on demo artifacts; compile demo path out of release | F3-05 | Low |

*Items 1, 2 and 6 are hours of work between them and remove the two failure modes most likely to cause a real production outage.*

### P1 — before the link is trusted without compensating controls

| # | Action | Closes |
|---|---|---|
| 8 | Encrypt the manifest descriptor (complete R-01); opaque filenames as an interim | F3-04 |
| 9 | Audit countersignature + off-host shipping + rotation | F3-06 |
| 10 | Delivery-gap detection and alarms | F3-10 |
| 11 | Sandbox capture/decode in a restricted child process; bound DIB dimensions; catch on the callback thread | F3-07 |
| 12 | CI with `RestoreLockedMode`, SBOM, Authenticode, WDAC; `NuGet.config` with source mapping | F3-12 |
| 13 | Schema pinning per sender | F3-09 |

### P2 — strategic

| # | Action | Closes |
|---|---|---|
| 14 | Sender-ephemeral ECDH + receiver key rotation cadence | F3-08 (majority) |
| 15 | Hybrid ML-KEM-768, **with a measured V40-L acquisition benchmark before committing** | F3-08 (quantum archive) |
| 16 | Staging sweep, production profile without clipboard, documented BitLocker requirement | F3-13 |
| 17 | Curve pinning, bundle validity window, explicit create-vs-open | F3-15, F3-17 |

---

## 10. Residual risk that no code change removes

Stated so it is not mistaken for something the roadmap will fix.

**10.1 The diode transports trust; it cannot manufacture it.** A compromised OT sender signs whatever it likes and the receiver will verify it perfectly. Schema pinning bounds the blast radius to well-formed transactional data; it cannot detect well-formed lies. Sender integrity is an endpoint-security problem (WDAC, attestation, EDR) and lives outside this codebase.

**10.2 Availability is jammable, permanently.** A stronger light source, a laser, or a hand over the lens denies the channel for as long as it is applied. F3-03's remediation converts *cheap, surgical, invisible* denial into *sustained, physical, obvious* jamming — a real improvement in detectability, not in prevention. The compensating control is a physically enclosed optical corridor, and it should be treated as mandatory rather than advisory.

**10.3 The security boundary ends at the payload store — and TB-4 is unguarded.** QrDiode writes verified plaintext into a folder. Whatever consumes that folder does so with **no authentication, no provenance check and no rate limit**, and by default it is a user-writable location. Every guarantee this review credits the protocol with evaporates if the downstream consumer trusts the folder rather than the journal. Under the stated transactional profile this is the most under-specified part of the whole system. The consumer should verify against the journal and audit chain, run in its own security context, and treat the store as untrusted input in its own right. Note also that `StorageRoot` is operator-settable to any path including a UNC share — audited, but not policy-constrained.

**10.4 Forward secrecy has an architectural floor.** With no return channel there is no interactive ratchet (§8.8).

**10.5 Delivery is detected, never guaranteed.** Nothing can request a resend. Completeness is an operations loop: gap alarm → human → OT re-send.

**10.6 The ceremony is the root of trust, and it is human.** Fingerprint comparison, rotation cadence, revocation discipline. Technical controls enforce what can be enforced; a rushed or socially-engineered ceremony still provisions the wrong key. Two-person rule and signed ceremony records are procedural, and they need auditing.

**10.7 Supply chain is minimized, not eliminated.** zxing-cpp is a native C++ parser of hostile input at the trust boundary, permanently. Sandboxing contains it; pinning constrains it; neither makes it memory-safe. A memory-safe decoder behind the same interface is the next structural step if this risk must shrink further.

**10.8 Controls decay.** ACLs drift, WDAC policies acquire exceptions, rotation slips, demo flags get re-enabled "temporarily" in a lab build that reaches production. Start-time self-checks make the likeliest drift loud; annual re-review against this document is part of the control set, not an optional extra.

---

## 11. Standards alignment

Stated conservatively. **Achieved levels are properties of the deployed system, not of this software.** The software's contribution is what is assessed here.

### IEC 62443-3-3 (system security requirements)

| FR | Supported today | With P0+P1 complete | Limiting factor |
|---|---|---|---|
| FR 1 — Identification & authentication control | SL 1 | SL 2, SL 3-capable | Hardware-backed non-exportable ceremony identities are SL 3-grade; **F3-01/F3-02 currently undermine them** |
| FR 2 — Use control | SL 1 | SL 2 | No RBAC in the apps; relies on host accounts (F3-01) |
| FR 3 — System integrity | SL 1–2 | SL 3-capable | Signed-before-parsed is excellent; **F3-03 (unauthenticated symbols) and F3-06 (unkeyed audit) are the blockers** |
| FR 4 — Data confidentiality | SL 1 | SL 2 | **F3-04** (cleartext metadata), F3-08 (no FS), F3-13 (no at-rest) |
| FR 5 — Restricted data flow | **SL 3-capable now** | SL 3–4 | Physically unidirectional conduit with no ACK path — the strongest property in the system |
| FR 6 — Timely response to events | SL 1 | SL 2 | F3-06 (local-only audit), F3-10 (silent gaps), F3-16 (discarded signals) |
| FR 7 — Resource availability | SL 1 | SL 2 (ceiling) | **F3-03**; and §10.2 — optical availability is SL 2 at best against an adjacent attacker |

**No SL 4 claim is made anywhere.** FR 7 is the ceiling-limited requirement and always will be.

Relevant also: **IEC 62443-4-1** (secure development lifecycle) — the practices are visibly present (threat-driven design, negative testing, documented decisions, a change tracker) but **not evidenced by a pipeline**: no CI, no SBOM, no signed release artifacts (F3-12). **IEC 62443-4-2** component requirements CR 1.5 (authenticator management), CR 3.1 (communication integrity), CR 3.4 (software integrity), CR 7.x (resource availability) map directly onto the finding set above.

### NIST SP 800-82r3 (OT security guide)

The architecture matches the guide's **unidirectional gateway** pattern, including the recommendation that the receiving host sit in a DMZ rather than in the trusted IT zone. Two of the guide's associated expectations are only partly met today: **authenticated, disciplined time synchronization in both zones** (the ±15 minute strict window makes this load-bearing — NTP failure becomes an availability event, which is the correct direction of failure but must be monitored), and **detective reconciliation for unacknowledged transfer** (F3-10). In Purdue terms the diode is the L3/L3.5 → L4 conduit; the payload store and its consumer belong in the DMZ, not in the enterprise zone (§10.3).

### NIST SP 800-53r5 control mapping

| Control | Status |
|---|---|
| SC-7(11) boundary protection / restrict incoming traffic | ✔ Physically enforced |
| SC-8, SC-8(1) transmission confidentiality & integrity | ✔ AES-256-GCM + ECDSA |
| SC-12 cryptographic key establishment | ✔ ECDH + HKDF; ⚠ no rotation cadence (F3-08) |
| SC-13 cryptographic protection | ✔ Approved primitives throughout |
| SC-23 session authenticity | ✔ Three-factor anti-replay |
| SC-28 protection of information at rest | ⚠ Keys and counter protected; **payloads and journal are not** (F3-13) |
| SI-7 software / information integrity | ✔ Strong in transit; ⚠ **F3-03** for delivery integrity |
| SI-10 information input validation | ✔ Strong; ⚠ well-formedness only, no schema (F3-09) |
| IA-5 authenticator management | ⚠ **F3-02** (no export-policy assertion), F3-01 |
| AC-3 access enforcement | ✖ **F3-01** — state directory not access-controlled |
| AU-2 auditable events | ✔ Comprehensive; rejections are first-class |
| AU-9 protection of audit information | ✖ **F3-06** — unkeyed, locally rewritable |
| AU-10 non-repudiation | ✖ **F3-06** — no countersignature |
| CM-14 signed components | ✖ **F3-12** — no Authenticode, no WDAC |
| SR-4 provenance / SR-11 component authenticity | ⚠ **F3-12** — pinned but not enforced; no SBOM |

### Cryptographic standards

All primitives are Windows CNG / .NET BCL one-shot calls, so the stack is operable on a FIPS-mode Windows host. AES-GCM per **SP 800-38D** (unique key per message, so the 96-bit random nonce carries no reuse risk). ECDH per **SP 800-56A Rev. 3**, correctly using the raw shared secret as HKDF input rather than as a key. HKDF per **RFC 5869** with proper salt and session-bound `info`. ECDSA per **FIPS 186-5**. **CNSA 2.0 / NIST IR 8547** direction is not yet followed — no ML-KEM, no ML-DSA (F3-08). If PQC is adopted, the implementation must use platform-validated primitives and must not vendor its own PQC arithmetic.

---

## 12. Verification matrix

How an independent assessor re-tests each finding.

| ID | Verification method |
|---|---|
| F3-01 | `(Get-Acl "$env:LOCALAPPDATA\QrDiode\trust").Access` — confirm the interactive user holds write. Then drop a bundle with your own keys and send a forged manifest; it verifies. |
| F3-02 | Pre-create an exportable CNG key named `QrDiode.<endpoint>.sign`; open the endpoint in the app; confirm it is used and the private key is exportable. |
| F3-03 | Run Appendix A. Expect `SymbolAccepted` → `Ciphertext hash mismatch` → `recovers = False` → `CONTROL = True`. |
| F3-04 | Parse a captured manifest frame offline with no keys; confirm filename, content kind and both sizes are readable. |
| F3-05 | Click ⚡ Demo setup on a receiver, restart it, press Start — confirm it starts. |
| F3-06 | Rewrite an `audit\*.jsonl` file, recompute the chain hashes, run `AuditLog.Verify` — confirm it returns −1 (intact). |
| F3-07 | Inspect the process token; confirm no AppContainer/restricted SIDs. Review `TryDibToLuminance` bounds against a synthetic DIB header with `width = 0x40000000`. |
| F3-08 | Confirm `Envelope.DeriveKey` takes only static keys; confirm a recorded session decrypts given either static agreement private key. |
| F3-09 | Send `{"totally":"unrelated"}` as `ContentKind.Json` with `allowOpaqueFiles: false` — it is accepted. Send a `.bin` to the shipped receiver — it is accepted. |
| F3-10 | Deliver counter 10, then counter 20; confirm no gap event anywhere in UI, journal or audit. |
| F3-11 | Deliver a session, delete `sender-counter.bin`, send again — expect permanent `StaleCounter`. |
| F3-12 | `Select-String -Pattern RestoreLockedMode` across the tree → no match. Confirm no `NuGet.config` and no CI definition exist. |
| F3-13 | Kill the receiver between staging write and rename; confirm a plaintext `.tmp` survives in `.staging`. Query `SELECT snippet FROM payload_index` — confirm payload content is present. |
| F3-14 | Queue a 17 MB file; confirm the sender airs it and the receiver rejects the manifest. |
| F3-15 | Import a P-384 bundle; confirm it is accepted at import and fails only at transfer time. |
| F3-16 | `Select-String -Pattern BufferedEvictions` → matches only in `LtDecoder.cs` and tests. |

**Suggested review order for the remediating diff:** F3-03 and F3-04 (wire protocol — deepest), then F3-01/F3-02/F3-05 (host trust), then the remainder.

---

## 13. Closing assessment

QrDiode's protocol design is sound and, in several respects, better than the state of practice: the verification chain is ordered the way it should be and fails closed at every step; the cryptographic composition is correct and uses no home-grown primitives; hostile-input parsing is careful and bounded; and the codebase documents *why* decisions were made in a way that made this review substantially faster and more reliable than it would otherwise have been. The hardening work in P1–P8 is real, verified, and in the case of P2 and P4 closed genuine allocation-amplification and unbounded-growth risks.

The problems are not architectural. They are a specific, tractable set of unfinished items — six of which were already identified and specified in v2 and then not built. Two of them are cheap enough to fix this week and remove the two most likely causes of a production outage: **re-arm instead of settle** (F3-03), and the **counter-loss guard** (F3-11).

The two findings that should govern the go/no-go decision are **F3-01** and **F3-03**. The first means the receiver's root of trust is a folder the operator's own account can rewrite, silently. The second means one QR code, costing nothing and requiring no knowledge, permanently destroys a transfer that the sender believes it delivered. Neither is exotic; both were demonstrated rather than argued.

**Recommendation: controlled pilot yes, unattended mission-critical production not yet.** Ship the P0 set — most of which is small — and the picture changes materially. The design deserves that finish.

---

## Appendix A — Proof-of-concept harness

Executed against the real `QrDiode.Core` assembly on 2026-08-23. No modifications were made to the product source. The harness references `src/QrDiode.Core/QrDiode.Core.csproj` directly.

```csharp
using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;

// Attacker capability: display a QR code in the receiver camera's field of view.
// Attacker knowledge:  ONLY what is printed in cleartext on the OT screen.
// Attacker key material: NONE.  Attacker computation: NONE.

using var senderKeys   = new EphemeralEndpointKeys();
using var receiverKeys = new EphemeralEndpointKeys();
var trust = new InMemoryTrustStore();
trust.Add(PublicKeyBundle.FromKeys("ot", senderKeys).ToPeerKeys());
using var receiverPeer = PublicKeyBundle.FromKeys("it", receiverKeys).ToPeerKeys();

var rng  = new Random(20260823);
var blob = new byte[120_000];
rng.NextBytes(blob);                      // incompressible -> realistic K, no degenerate case
byte[] payload = Encoding.UTF8.GetBytes(
    "{\"event\":\"batch-release\",\"blob\":\"" + Convert.ToBase64String(blob) + "\"}");

var session = SendSession.Create(payload, "LINE7-BATCH-2291.json", ContentKind.Json,
                                 senderKeys, receiverPeer, counter: 1);

// Read the session tag and symbol size off the screen. No keys involved.
FrameParser.TryParse(session.ManifestFrame, out var mf, out _);
TransferManifest.TryParse(mf.Payload, out var m, out _);
int k = (int)m.SourceSymbolCount;

// ONE forged frame: systematic id K-1, all 0xA5, valid CRC-32.
var garbage = new byte[m.SymbolSize];
Array.Fill(garbage, (byte)0xA5);
byte[] forged = FrameWriter.WriteDataFrame(m.SessionTag, (uint)(k - 1), garbage);

var engine = new ReceiveEngine(trust, new InMemoryReplayGuard(), receiverKeys,
                               allowOpaqueFiles: false);
bool injected = false;
foreach (var frame in session.Carousel())
{
    var r = engine.Feed(frame);
    if (r == FeedResult.ManifestAccepted && !injected)
    {
        Console.WriteLine($"engine verdict on the forged frame: {engine.Feed(forged)}");
        injected = true;
    }
    if (r == FeedResult.Completed) { Console.WriteLine("COMPLETED"); break; }
    if (r == FeedResult.Rejected)  { Console.WriteLine("REJECTED: " + engine.LastRejection); break; }
}

// The sender keeps broadcasting. Replay the entire genuine carousel.
engine.Reset();
bool recovered = false;
foreach (var frame in session.Carousel())
    if (engine.Feed(frame) == FeedResult.Completed) { recovered = true; break; }
Console.WriteLine($"genuine carousel replayed in full, completes = {recovered}");

// Control: identical session, no injection.
var control = new ReceiveEngine(trust, new InMemoryReplayGuard(), receiverKeys,
                                allowOpaqueFiles: false);
bool ok = false;
foreach (var frame in session.Carousel())
    if (control.Feed(frame) == FeedResult.Completed) { ok = true; break; }
Console.WriteLine($"CONTROL (no injection) completes = {ok}");
```

**Output (verbatim):**

```
K = 90, symbolSize = 1350
engine verdict on the single forged frame: SymbolAccepted
outcome -> REJECTED: Ciphertext hash mismatch after decode
sender's carousel replayed in full afterwards, completes = False
CONTROL (no injection) completes = True
```

*(Loop iteration caps elided from the listing for readability; the executed harness bounds every loop at 400 000 frames.)*

A second variant located a **degree-1 coded symbol** targeting a chosen block by searching the public `ltSeed` — **88 trials** — producing the identical outcome. The systematic-ID variant above is strictly cheaper and needs no search at all.

---

## Appendix B — Environment

| Item | Value |
|---|---|
| Review date | 2026-08-23 |
| Protocol version | v2 (`0x02`) |
| .NET SDK | 10.0.400 (pinned, `latestPatch`) |
| Target frameworks | `net10.0` (Core), `net10.0-windows` (Sender, Receiver) |
| Host OS | Windows 11 (10.0.26200) |
| Core tests | **88 passed / 0 failed** (Release) |
| Receiver tests | **9 passed / 0 failed** (Release) |
| Direct dependencies | `System.IO.Hashing 10.0.10`, `System.Security.Cryptography.ProtectedData 10.0.10`, `Net.Codecrete.QrCodeGenerator 3.1.0`, `FlashCap 1.11.0`, `ZXingCpp 0.5.3`, `Microsoft.Data.Sqlite 10.0.10`, `SQLitePCLRaw.bundle_e_sqlite3 3.0.5` |
| Lock files | 7, with content hashes (`RestoreLockedMode` **not** enforced) |
| Network code in `src/` | **none** — verified by exhaustive pattern search |

---

*End of v3 as-built re-assessment. Companions: `docs/SECURITY_REVIEW.md` (v1, as-built 2026-08-20), `docs/SECURITY_REVIEW_V2.md` (v2, target state 2026-08-20). Artifacts: `docs/SECURITY_REVIEW_V3.md`, `docs/SECURITY_REVIEW_V3.docx`.*
