# QrDiode — System Summary

> This summary is based solely on the contents of `d:\WORKSPACE\qr-code` as of 2026-08-23. It is descriptive: it reports what is implemented, configured, or documented in the workspace, and does not offer recommendations, gap analysis, or a security verdict. Every factual claim below is cited to a file in the workspace; where none exists, that is stated explicitly.

---

## 1. Executive Summary

QrDiode is a Windows desktop system that moves small transactional records — XML and JSON messages, typically well under a megabyte — out of an industrial (OT) network and into an office/IT network, without ever connecting the two networks (`docs/ARCHITECTURE.md:8-21`). Instead of a cable, the link is optical: a "Sender" application on the OT machine displays the data as a continuously looping, animated sequence of QR codes on an ordinary monitor; a "Receiver" application on a separate IT machine points a webcam at that screen, reads the codes, and reconstructs the original message (`docs/ARCHITECTURE.md:18,111-117`). There is no cable, Wi-Fi link, or software connection of any kind between the two machines — the review of the source tree found no network client or server code anywhere in `src/` (`docs/SECURITY_REVIEW_V3.md:312`).

Because light travels one way through a camera lens, the IT side has no way to talk back to the OT side — no acknowledgement, no "please resend," no handshake: true data-diode semantics (`docs/ARCHITECTURE.md:19`). The system targets organizations that need transactional data out of a control-system environment — plant events, batch records, sensor readings — while keeping that environment physically and electronically isolated from the corporate network (`docs/ARCHITECTURE.md:8-11,20`).

Plant/OT operators run the Sender and watch a queue of outgoing transactions; IT-side operators run the Receiver and watch an inbox plus a searchable archive of everything ever received (`docs/USER_GUIDE.md:37-72,206-221`). A one-time "key ceremony," run by both sides together, establishes the cryptographic trust that authenticates every transfer (`docs/USER_GUIDE.md:114-166`).

The system is built in C# on .NET 10, as two WPF desktop applications (`QrDiode.Sender`, `QrDiode.Receiver`) sharing a protocol library (`QrDiode.Core`) and a command-line key-provisioning tool (`QrDiode.KeyCeremony`) (`docs/ARCHITECTURE.md:38-56`).

---

## 2. System Architecture

### 2.1 Solution layout

The repository is a single .NET solution, `QrDiode.slnx`, with four source projects and three test/benchmark projects (`docs/ARCHITECTURE.md:38-56`; `src/QrDiode.Core`, `src/QrDiode.Sender`, `src/QrDiode.Receiver`, `src/QrDiode.KeyCeremony`, `src/Shared`, `tests/QrDiode.Core.Tests`, `tests/QrDiode.Receiver.Tests`, `tests/QrDiode.Bench`). `QrDiode.Core` is UI-agnostic and screen/camera-agnostic — it references only the .NET base class library plus two small NuGet packages (`src/QrDiode.Core/QrDiode.Core.csproj:10-11`: `System.IO.Hashing 10.0.10`, `System.Security.Cryptography.ProtectedData 10.0.10`) — and holds the wire format, the fountain codec, the cryptographic envelope, the manifest format, and the send/receive pipelines (`docs/ARCHITECTURE.md:42-47`). `src/Shared/PayloadView.cs` is compiled into both WPF apps as linked source (not a shared assembly), so the Sender and Receiver render a payload identically for side-by-side comparison (`src/QrDiode.Receiver/QrDiode.Receiver.csproj:7-11`, `src/QrDiode.Sender/QrDiode.Sender.csproj:7-11`).

### 2.2 Components and their libraries

| Side | Component | Responsibility | Key library (version) |
|---|---|---|---|
| OT | `QrDiode.Sender` | Live/manual payload source, session queue, QR stage window | `Net.Codecrete.QrCodeGenerator 3.1.0` (`src/QrDiode.Sender/QrDiode.Sender.csproj:14`) |
| OT/IT (shared) | `QrDiode.Core` | Framing, fountain codec, crypto, manifest, pipelines | BCL only (`src/QrDiode.Core/QrDiode.Core.csproj:10-11`) |
| IT | `QrDiode.Receiver` | Camera capture, QR decode, verification, storage, journal | `FlashCap 1.11.0`, `ZXingCpp 0.5.3`, `Microsoft.Data.Sqlite 10.0.10` (`src/QrDiode.Receiver/QrDiode.Receiver.csproj:14-17`) |
| Both | `QrDiode.KeyCeremony` | Offline key generation, bundle export/import, fingerprinting | Windows CNG via BCL (`src/QrDiode.KeyCeremony/Program.cs`) |

### 2.3 Runtime topology

Both apps are ordinary WPF desktop applications targeting `net10.0-windows` (`src/QrDiode.Sender/QrDiode.Sender.csproj:19-23`, `src/QrDiode.Receiver/QrDiode.Receiver.csproj:22-25`), launched independently on two separate physical machines in production (`docs/USER_GUIDE.md:118-126`) — one machine can play both roles for a single-machine demo, with the full cryptographic stack still active (`docs/USER_GUIDE.md:16-22`; `src/QrDiode.Core/Crypto/DemoProvisioner.cs:6-13`). Each app persists its own local state under `%LocalAppData%\QrDiode\` — CNG key handles, trust store, journal database, audit log, and (on the sender) a DPAPI-protected send counter (`src/QrDiode.Core/QrDiodePaths.cs:6-23`; `docs/USER_GUIDE.md:238-248`). Nothing is shared between the machines except what crosses the optical channel and what is carried once, out of band, during key provisioning (`docs/USER_GUIDE.md:149-159`).

### 2.4 Component and data-flow diagram

The diagram below is derived directly from the namespaces and call chain in `src/` (`docs/ARCHITECTURE.md:38-56`, confirmed by reading `src/QrDiode.Sender/Transmit/TransmitEngine.cs`, `src/QrDiode.Core/Pipeline/SendSession.cs`, `src/QrDiode.Sender/Rendering/CarouselPump.cs`, `src/QrDiode.Receiver/Capture/QrDecodePipeline.cs`, `src/QrDiode.Core/Pipeline/ReceiveEngine.cs`, `src/QrDiode.Receiver/Storage/PayloadStore.cs`).

```
  OT ZONE — QrDiode.Sender + QrDiode.Core            OPTICAL         IT ZONE — QrDiode.Receiver + QrDiode.Core
  ───────────────────────────────────────           BOUNDARY        ───────────────────────────────────────
  Live simulator / manual file                     (no wires,        Webcam (FlashCap)
  (Sender/Transmit/QueueItem.cs)                    no ACK)          (Receiver/Capture/QrDecodePipeline.cs)
           │                                                                   │
           ▼                                                                   ▼
  TransmitEngine                                                       QrDecodePipeline
  (Sender/Transmit/TransmitEngine.cs)                                  luminance plane → ZXingCpp
  air-time policy, one session at a time                               (Receiver/Capture/QrDecodePipeline.cs)
           │                                                                   │
           ▼                                                                   ▼
  SendSession.Create                                                   ReceiveEngine.Feed
  (Core/Pipeline/SendSession.cs)                                       (Core/Pipeline/ReceiveEngine.cs)
  compress → seal (Core/Crypto/Envelope.cs)                            CRC → signature → anti-replay →
  → sign manifest → LT-encode                                         LT decode → ciphertext hash →
  (Core/Fountain/LtEncoder.cs)                                        AES-GCM open → decompress →
           │                                                          content gate (Core/Pipeline/ContentGate.cs)
           ▼                                                                   │
  CarouselPump → QrFrameRenderer                                               ▼
  (Sender/Rendering/*.cs)                       ── photons ──►         PayloadStore + SqliteJournal
  Gray8 bitmap, fixed QR version, ECC L                                (Receiver/Storage/*.cs)
           │                                                                   │
           ▼                                                                   ▼
  StageWindow (WPF window, screen)                                     AuditLog (Core/Audit/AuditLog.cs)
```

The screen and the camera are the only two components that ever touch the same physical medium; every other box runs entirely inside one process on one machine. `QrDiode.Core` supplies the pipeline logic (`SendSession`, `ReceiveEngine`) used by both sides, so the framing, cryptography, and fountain-coding rules are defined once and shared, not re-implemented per side (`docs/ARCHITECTURE.md:42-47`).

---

## 3. Transfer Process, End to End

This section follows one XML/JSON payload from intake on the OT side to arrival on the IT side. Parameter values below are read directly from the default constructors in the code; several are operator-adjustable at runtime (noted where applicable).

### 3.1 Intake

A payload originates either from `PayloadSimulator`, which generates realistic plant-event JSON (`order.created`, `sensor.telemetry`, `alarm.raised`, and others) on an irregular, bursty schedule (`src/QrDiode.Core/Simulation/PayloadSimulator.cs:32-97`; default gap 4–40 s, burstiness 0.64, `PayloadSimulator.cs:11-15`), or from an operator-browsed file (`docs/USER_GUIDE.md:177-178`). Both converge on the same `TransmitEngine` queue (`src/QrDiode.Sender/Transmit/TransmitEngine.cs:87-122`), capped at 14 queued items before the oldest is dropped (`TransmitEngine.cs:36,125-133`).

### 3.2 Serialization, compression, encryption

`SendSession.Create` (`src/QrDiode.Core/Pipeline/SendSession.cs:50-123`):

1. The plaintext is compressed with Brotli, keeping whichever of the compressed or original bytes is smaller (`SendSession.cs:66-72`).
2. Fresh randomness is drawn for the session: a session GUID, a 32-byte HKDF salt, a 12-byte AES-GCM nonce, and an 8-byte fountain-code seed (`SendSession.cs:74-77`).
3. A shared key is derived via ECDH (sender's private agreement key × receiver's public agreement key) and HKDF-SHA256, and the compressed bytes are sealed with AES-256-GCM under a 72-byte associated-data (AAD) block built from the session identity (`SendSession.cs:79-89`; `src/QrDiode.Core/Crypto/Envelope.cs:18-50,52-59`). Full detail in §6.
4. The manifest is serialized (`src/QrDiode.Core/Manifest/TransferManifest.cs:86-115`) and signed with ECDSA P-256 (`TransferManifest.cs:189-190`; `SendSession.cs:117`).

### 3.3 Chunking (fountain-code segmentation)

The ciphertext is split into fixed-size symbols: `symbolSize = min(1350, ciphertextLength)` bytes, and `K = ⌈ciphertextLength / symbolSize⌉` symbols (`SendSession.cs:91-92`, `src/QrDiode.Core/Fountain/LtCode.cs:52-58`). The 1350-byte cap is chosen to fit inside QR Version 30 at error-correction level Low, which carries 1370 bytes in byte mode (`SendSession.cs:13`, comment). §4 covers how symbols beyond the first `K` are generated.

### 3.4 Framing (wire protocol v2)

Every QR code carries exactly one frame: a 12-byte header (2-byte magic `"OD"`, 1-byte protocol version `0x02`, 1-byte frame type, 8-byte session tag), a type-specific body, and a trailing 4-byte CRC-32 (`src/QrDiode.Core/Framing/FrameFormat.cs:9-36`; CRC via `System.IO.Hashing.Crc32`, `src/QrDiode.Core/Framing/FrameWriter.cs:2,49-53`). A data-symbol frame adds a 4-byte `symbolId` plus payload (20-byte overhead); a manifest frame adds a 2-byte body-length prefix, the body, and a 64-byte ECDSA signature (`r‖s`) (82-byte overhead) (`FrameFormat.cs:27-32`; `FrameWriter.cs:9-38`). The manifest body is 167 fixed bytes plus an up-to-255-byte filename (`TransferManifest.cs:29,44-63`), carrying session ID, timestamp, counter, both key IDs, HKDF salt, GCM nonce, `symbolSize`, `K`, fountain seed, size fields, ciphertext SHA-256, content type, and filename — all in cleartext (`TransferManifest.cs:65-83,86-115`). The parser enforces `MinFrameSize = 17` and `MaxFrameSize = 4096` bytes (`FrameFormat.cs:35-36`).

### 3.5 QR rendering

`QrFrameRenderer` selects, once per session, the smallest QR version (1–40) whose byte-mode capacity at error-correction level **Low** fits the largest frame that session will emit, and holds that version fixed for every frame in the session so the receiving camera never has to re-acquire on a size change (`src/QrDiode.Sender/Rendering/QrFrameRenderer.cs:19-44`, using `Net.Codecrete.QrCodeGenerator`). Frames render as 1-bit-per-module, 1-pixel-per-module Gray8 bitmaps with an 8-module quiet zone (`QrFrameRenderer.cs:12,46-66`). A background `CarouselPump` pre-renders frames into a bounded channel of 16 buffered bitmaps so the UI thread only blits (`src/QrDiode.Sender/Rendering/CarouselPump.cs:22,28-33`).

### 3.6 Pacing and the carousel

`SendSession.Carousel()` yields the manifest first, then re-emits it every 20 frames so a receiver that starts mid-transfer acquires it quickly (`SendSession.cs:16-17,138-158`; default `ManifestInterval = 20`). Each loop plays the systematic symbols `0..K-1` followed by `(Redundancy-1)×K` freshly generated coded symbols, with `Redundancy = 3` by default (`SendSession.cs:14-15`). `TransmitEngine` blits frames at an operator-adjustable rate, default 15 fps, clamped to the range 1–60 fps (`src/QrDiode.Sender/Transmit/TransmitEngine.cs:54,223`). Because there is no acknowledgement, a session does not end on success — it ends on an air-time policy: at least `LoopTarget × K` frames shown (`LoopTarget = 3` by default) **and** at least `MinAirSeconds = 6` seconds elapsed, whichever is longer, then a `GapSeconds = 1.5` second pause before the next manifest (`TransmitEngine.cs:55-57,201-227`).

### 3.7 Capture and decode

`QrDecodePipeline` opens the selected camera through `FlashCap`, converts each frame to a grayscale luminance plane (from a DIB or, on the common MJPEG path, via WIC), and hands it to native `ZXingCpp`, configured for `BarcodeFormat.QRCode` with `TryHarder`, `TryRotate`, and `TryInvert` all off (`src/QrDiode.Receiver/Capture/QrDecodePipeline.cs:19-26,68-140`). A frame is dropped if a decode is already in flight, which costs nothing because the carousel repeats (`QrDecodePipeline.cs:74-80`).

### 3.8 Reassembly, validation, and handoff

Each decoded frame is fed to `ReceiveEngine.Feed`, which runs the ordered verification chain detailed in §6, incrementally reassembling the ciphertext via the fountain decoder as data symbols arrive (`src/QrDiode.Core/Pipeline/ReceiveEngine.cs:190-207`). Once decoding is complete the engine checks the ciphertext hash, opens the AES-GCM envelope, decompresses with a hard cap at the manifest's declared original size, and validates content structure before the payload is considered `Completed` (`ReceiveEngine.cs:209-277`). The verified bytes are then written atomically — staging file, `fsync`, same-volume rename — into the configured local store, indexed in a SQLite journal, and recorded in the hash-chained audit log (`src/QrDiode.Receiver/Storage/PayloadStore.cs:96-124`; `docs/ARCHITECTURE.md:121-127`).

### 3.9 Sequence (one payload, condensed)

```
Plant event / file  →  TransmitEngine.Enqueue        (queued)
                    →  SendSession.Create             (compress·seal·sign·segment)
                    →  CarouselPump → QrFrameRenderer  (QR bitmaps)
                    →  StageWindow                     (on screen, looping)
   ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄  photons across the air gap  ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
                    →  QrDecodePipeline               (camera → luminance → ZXingCpp)
                    →  ReceiveEngine.Feed              (verification chain, §6)
                    →  PayloadStore.Save               (staging → fsync → rename)
                    →  SqliteJournal + AuditLog         (indexed, hash-chained)
```

---

## 4. How Fountain Coding Works Here

**Plain-language idea.** Because the optical link cannot send anything back, the sender cannot know which QR codes the camera actually caught — some are always missed to blur, glare, a bad angle, or timing. Rather than track and retransmit specific missing pieces (which would need a back-channel), the sender continuously produces a stream of encoded "symbols," each carrying a little information about the whole message, and the receiver keeps collecting symbols until it has gathered enough to reconstruct the message — regardless of *which* symbols those were or how many were missed. This is **fountain coding** (also erasure coding): like water from a fountain, the receiver can catch any cupful and eventually have enough, rather than needing one specific drop.

**The scheme implemented.** QrDiode uses an in-house, pure-C# **systematic Luby Transform (LT) code** (`src/QrDiode.Core/Fountain/LtCode.cs`, `LtEncoder.cs`, `LtDecoder.cs`, `RobustSoliton.cs`, `DeterministicRandom.cs`; described as such in `docs/SECURITY_REVIEW_V3.md:261-265` and `docs/ARCHITECTURE.md:29`). "Systematic" means the first `K` symbols (`symbolId < K`) are simply the original data blocks, sent verbatim and unmodified (`LtCode.cs:5-6`; `LtEncoder.cs:33-36`) — so on a clean optical channel the transfer completes in exactly `K` frames with no coding overhead at all. Symbols beyond `K` are "coded": each one is the bitwise XOR of a pseudo-randomly chosen subset of the original blocks (`LtEncoder.cs:38-49`).

**Degree distribution and seeding.** For each coded `symbolId`, both sides independently compute the same subset (its "neighbours") using only public values: a Fibonacci-hashing mix of `symbolId` and the session's `ltSeed` (`LtCode.cs:18`, constant `0x9E3779B97F4A7C15`), fed through `SplitMix64` to seed a **xoshiro256++** pseudo-random generator (`src/QrDiode.Core/Fountain/DeterministicRandom.cs:8-40`) — chosen deliberately over .NET's built-in `System.Random` because its algorithm is a fixed, documented, cross-platform contract, which both sides must reproduce identically (`DeterministicRandom.cs:4-7`). The number of neighbours ("degree") for a symbol is drawn from a **robust soliton distribution** with tuning constants `c = 0.1` and `δ = 0.05` (`src/QrDiode.Core/Fountain/RobustSoliton.cs:15,27-52`), by binary search over a precomputed cumulative distribution (`RobustSoliton.cs:55-66`). Neighbour indices are then chosen without modulo bias using Lemire-style rejection sampling, via partial Fisher–Yates for dense symbols or rejection sampling into a hash set for sparse ones (`LtCode.cs:22-49`; `DeterministicRandom.cs:46-58`).

**Decoding.** `LtDecoder` reconstructs the message with incremental belief-propagation "peeling": a degree-1 symbol resolves its block immediately; a higher-degree symbol is XOR-reduced against blocks already known, and if that leaves exactly one unknown block, it resolves too — a cascade driven by an explicit queue (`src/QrDiode.Core/Fountain/LtDecoder.cs:157-185`). Symbols may arrive in any order, duplicated, or not at all. The decoder tracks how many distinct source blocks it has recovered (`DecodedSourceCount`) against the total (`K`), and considers itself complete exactly when the two are equal (`LtDecoder.cs:26-29`). At that point `ReceiveEngine` proceeds to ciphertext-hash and AES-GCM verification (`src/QrDiode.Core/Pipeline/ReceiveEngine.cs:203-216`) — the fountain code's job ends the moment every source block is recovered; it makes no claim about whether those recovered bytes are authentic, which is what §5–§6 cover.

The decoder bounds its own memory: buffered (unresolved) coded symbols are capped at `clamp(4K, 1024, 8192)` and remembered symbol IDs at `clamp(16K, 4096, 131072)`, both evicted oldest-first once full (`LtDecoder.cs:38-63`).

---

## 5. Security Measures

QrDiode layers cryptography, anti-replay, and hostile-input handling on top of the physical one-way channel; none of these controls can be disabled from either application's UI (`docs/USER_GUIDE.md:252-265`). The table below lists controls found implemented in `src/`, distinguishing implemented behaviour from configuration defaults, and maps each to the relevant clause of a small set of OT-security frameworks — **NIST SP 800-82** (guide to OT security), **IEC 62443-3-3** (system security requirements), and **NIST SP 800-53** (control catalogue) — used here strictly as descriptive reference points, not as a claim of certification or compliance. These are the frameworks the workspace's own security-review documents use for the same purpose (`docs/SECURITY_REVIEW_V3.md:736-782`); the workspace contains no NERC CIP mapping — that lens is therefore not applied below ("Not found in workspace").

| Control (implemented) | Where | Framework reference (lens only) |
|---|---|---|
| No network code of any kind in `src/` | Verified by exhaustive search for socket/HTTP/named-pipe APIs (`docs/SECURITY_REVIEW_V3.md:312`) | NIST SP 800-82r3 unidirectional-gateway pattern; IEC 62443-3-3 FR 5 |
| Confidentiality: AES-256-GCM, one key per message | `src/QrDiode.Core/Crypto/Envelope.cs:52-59` | NIST SP 800-38D; SP 800-53 SC-8 |
| Key agreement: static-static ECDH P-256 → HKDF-SHA256 | `Envelope.cs:35-50` | NIST SP 800-56A Rev.3; RFC 5869; SC-12 |
| Authenticity: ECDSA P-256/SHA-256, verified before any payload byte is parsed | `TransferManifest.cs:189-193`; `ReceiveEngine.cs:157-172` | FIPS 186-5; SI-7 |
| Cryptographic binding of ciphertext to manifest via AAD + signed ciphertext hash | `Envelope.cs:18-33`; `TransferManifest.cs:80`; `ReceiveEngine.cs:214-220` | SI-7 |
| Anti-replay: session-GUID dedupe **and** per-key counter watermark **and** timestamp window | `src/QrDiode.Core/Pipeline/ReplayGuard.cs:39-58`; `src/QrDiode.Receiver/Storage/SqliteJournal.cs:81-104` (SQLite, WAL, `synchronous=FULL`, `SqliteJournal.cs:39-40`) | SC-23 |
| Key storage: non-exportable Windows CNG keys, TPM (Platform Crypto Provider) preferred, software KSP fallback | `src/QrDiode.Core/Crypto/CngEndpointKeys.cs:13,55-84` | IA-5, SC-12; IEC 62443-4-2 CR 1.5 |
| Counter durability: reserved and disk-flushed before a session exists, DPAPI-protected (`CurrentUser` scope) | `src/QrDiode.Core/Crypto/CounterStore.cs:26-65` | — |
| Hostile-frame parsing: span-based, fixed offsets, length-checked before read, allocation-free on reject | `src/QrDiode.Core/Framing/FrameParser.cs:39-91` | SI-10 |
| Manifest acceptance envelope bounding K, payload size, symbol size before the decoder is built | `TransferManifest.cs:39-63,140-155` | SI-10 |
| Zip-bomb guard: Brotli output hard-capped at the *signed* original size | `ReceiveEngine.cs:238-243,279-304` | SI-10 |
| XXE prevention: `DtdProcessing.Prohibit`, `XmlResolver = null`, `MaxCharactersFromEntities = 0` | `src/QrDiode.Core/Pipeline/ContentGate.cs:62-70` | SI-10; OWASP XXE |
| JSON depth cap (64), comments/trailing commas disallowed | `ContentGate.cs:15,97-102` | SI-10 |
| Filename sanitization, session-GUID-prefixed stored name | `src/QrDiode.Receiver/Storage/PayloadStore.cs:172-195` | SI-10 |
| Atomic materialization: staging write + `fsync` + same-volume rename | `PayloadStore.cs:96-124` | SI-7 |
| Tamper-evident audit log: append-only, hash-chained JSONL, both ends | `src/QrDiode.Core/Audit/AuditLog.cs:26-56,58-89` | AU-2, AU-9 |
| Post-hoc integrity check ("Verify bytes on disk" re-hash) | `docs/USER_GUIDE.md:215` | SI-7 |
| Memory hygiene: shared secret / session key zeroized after use | `Envelope.cs:47-49`; `SendSession.cs:85-89` | SC-28 |

**Implemented vs. documented — noted discrepancies.** `ReceiveEngine`'s `allowOpaqueFiles` parameter defaults to `true` (`src/QrDiode.Core/Pipeline/ReceiveEngine.cs:100-101`), and the Receiver constructs it without overriding that default (`_engine = new ReceiveEngine(_trust, _journal, _keys);`, `src/QrDiode.Receiver/MainWindow.xaml.cs:255`), so opaque `File`-type payloads (bytes the content gate never parses) are accepted at runtime. The workspace's own security documentation states the assessed deployment profile as "transactional payloads only (XML / JSON). No file transfer." (`docs/SECURITY_REVIEW_V3.md:6`) — code and documented profile disagree on file-type payloads, with no reconciling configuration found in `src/`. Separately, `docs/ARCHITECTURE.md:20` documents a payload ceiling of "up to ~64 MB files," matching the Sender's browse-dialog limit, while `TransferManifest.MaxPayloadBytes` enforces 16 MiB on the Receiver side (`TransferManifest.cs:39-44`) — both implemented, on opposite sides of the link, at different values.

A dedicated internal security-review series exists in the workspace (`docs/SECURITY_REVIEW.md`, `_V2.md`, `_V3.md`) assessing these and other controls against IEC 62443-3-3, NIST SP 800-82r3, and NIST SP 800-53r5 in detail (`docs/SECURITY_REVIEW_V3.md:736-782`); per this document's descriptive scope, their findings are not reproduced here.

---

## 6. Security Mechanism, Step by Step

**Sender, per payload (`SendSession.Create`, `src/QrDiode.Core/Pipeline/SendSession.cs:50-123`):**

1. Reject an empty payload outright (`SendSession.cs:61`).
2. Compress with Brotli; keep the smaller of compressed/original (`SendSession.cs:66-72`).
3. Generate session randomness via `RandomNumberGenerator`: session GUID, 32-byte salt, 12-byte nonce, 8-byte fountain seed (`SendSession.cs:74-77`).
4. Reserve and durably flush the sender's monotonic counter *before* the session exists, so a crash can never issue the same counter twice; stored DPAPI-protected under `DataProtectionScope.CurrentUser` (call site `src/QrDiode.Sender/Transmit/TransmitEngine.cs:259`; `src/QrDiode.Core/Crypto/CounterStore.cs:26-34,42-65`).
5. Build a 72-byte AAD from session GUID, salt, counter, and both endpoints' key IDs (`src/QrDiode.Core/Crypto/Envelope.cs:18-33`).
6. Derive the shared key: raw ECDH agreement (own private agreement key × peer's public agreement key), then `HKDF-SHA256(IKM=Z, salt, info="QrDiode.v1"‖sessionId)` (`Envelope.cs:35-50`).
7. Seal the compressed bytes with AES-256-GCM under that key, nonce, and AAD, producing ciphertext ‖ 16-byte tag; then zero the shared secret and the derived key (`Envelope.cs:52-59`; `SendSession.cs:81-89`).
8. Segment the ciphertext into `K` fixed-size symbols (§3.3) and hash it: `SHA-256(ciphertext)` goes into the manifest (`SendSession.cs:91-111`).
9. Serialize and sign the manifest with the sender's ECDSA P-256 signing key (`SendSession.cs:116-117`; `TransferManifest.cs:189-190`).
10. Compute the human-comparable receipt hash — the first 8 bytes of `SHA-256(body ‖ signature)`, shown on-screen for operators to compare (`TransferManifest.cs:195-202`).

**Receiver, per frame — the ordered, fail-closed verification chain (`ReceiveEngine.Feed`, `src/QrDiode.Core/Pipeline/ReceiveEngine.cs:128-277`):**

1. Frame structure and CRC-32 (`ReceiveEngine.cs:135-136`; parsing in `src/QrDiode.Core/Framing/FrameParser.cs:39-91`). Failure: frame ignored, no allocation.
2. Manifest fields parsed and checked against the acceptance envelope (`TransferManifest.cs:121-187`). Failure: `Rejected`.
3. Sender's signing key looked up in the local trust store (`ReceiveEngine.cs:159-161`; `src/QrDiode.Core/Crypto/TrustStore.cs:112-118`). Unknown key → `Rejected`, and no payload byte is interpreted.
4. ECDSA signature verified over the exact received manifest bytes (`ReceiveEngine.cs:162-163`; `TransferManifest.cs:192-193`). Only past this point is anything in the manifest treated as trustworthy.
5. Manifest's declared receiver key checked against this receiver's own agreement-key ID (`ReceiveEngine.cs:166-167`).
6. Anti-replay: unseen session GUID **and** counter above the per-sender-key watermark **and** timestamp inside the acceptance window — all three enforced together (`ReceiveEngine.cs:174-180`; `src/QrDiode.Core/Pipeline/ReplayGuard.cs:39-58`, or the SQLite-backed equivalent in `src/QrDiode.Receiver/Storage/SqliteJournal.cs:81-104`). Failure: `Rejected`.
7. Data symbols matched by session tag and exact length, fed to the fountain decoder (§4) until complete (`ReceiveEngine.cs:190-207`).
8. `SHA-256(ciphertext)` compared to the value in the signed manifest (`ReceiveEngine.cs:214-216`).
9. AES-256-GCM opened with the AAD rebuilt from the signed manifest fields; a tamper anywhere in ciphertext, nonce, or AAD causes an `AuthenticationTagMismatchException`, caught and treated as rejection (`ReceiveEngine.cs:218-236`).
10. Brotli decompressed with output hard-capped at the manifest's signed original size, plus a check that the stream does not continue beyond that size (`ReceiveEngine.cs:238-243,279-304`).
11. Plaintext length checked against the signed original size (`ReceiveEngine.cs:250-258`).
12. Content gate: hardened `XmlReader` (DTDs prohibited, no external resolver, depth-capped) for XML, or depth-capped `Utf8JsonReader` for JSON; opaque files pass through only if the constructor's `allowOpaqueFiles` flag is set (`ReceiveEngine.cs:262-264`; `src/QrDiode.Core/Pipeline/ContentGate.cs:29-58`).
13. Anti-replay state committed only for a fully verified transfer (`ReceiveEngine.cs:266-267`).

**On any failure**, the step's specific reason is recorded (`ReceiveEngine.cs:316-320`), and for a failure discovered after decoding (steps 8–12) the entire in-flight session state is cleared (`RejectAndReset`, `ReceiveEngine.cs:324-335`) so a subsequent manifest can be picked up fresh. A completed transfer is then written to disk (staging write, `fsync`, same-volume rename — `PayloadStore.cs:96-124`), indexed in the SQLite journal (`SqliteJournal.cs:106-138,179-209`), and recorded in the hash-chained audit log on both machines (`AuditLog.cs:26-56`; call sites in `src/QrDiode.Sender/Transmit/TransmitEngine.cs:290-298,330-337`).

**Key and secret handling.** Long-term signing (ECDSA P-256) and agreement (ECDH P-256) keys are generated and held as non-exportable named keys in Windows CNG — TPM-backed Platform Crypto Provider when available, else the software key-storage provider (`src/QrDiode.Core/Crypto/CngEndpointKeys.cs:34-40,55-84,65`). Only the public half of each pair ever leaves a machine, carried as a JSON bundle on removable media during the key ceremony (`docs/USER_GUIDE.md:128-159`; `src/QrDiode.KeyCeremony/Program.cs:59-73,75-107`), and both operators compare an 8-group hex fingerprint of the exchanged bundle out of band before trusting it (`Program.cs:70-71,100-106`; computed as `SHA256(signingSpki ‖ agreementSpki)`, `src/QrDiode.Core/Crypto/TrustStore.cs:60-69`). Per-session symmetric keys and the raw ECDH shared secret exist only in memory for one seal/open operation and are explicitly zeroed afterward with `CryptographicOperations.ZeroMemory` (`Envelope.cs:47-49`; `SendSession.cs:85-89`; `ReceiveEngine.cs:233-236`).

---

## 7. Glossary

- **OT (Operational Technology):** Industrial control systems and the equipment/networks that run a physical process — here, the "plant" side that only ever sends (`docs/ARCHITECTURE.md:8-10`).
- **IT (Information Technology):** The general-purpose business network and systems that consume the OT data on the receiving end (`docs/ARCHITECTURE.md:8-10`).
- **Data diode:** A one-way information transfer mechanism with no return path, physically or electronically. Here the diode is optical: a screen and a camera, with no cable between them (`docs/ARCHITECTURE.md:10,18-19`; no network code found, `docs/SECURITY_REVIEW_V3.md:312`).
- **Fountain coding (rateless erasure coding):** An encoding scheme that produces a potentially unlimited stream of symbols from a fixed message, such that a receiver can reconstruct the message from any sufficiently large subset of symbols it manages to catch — used here because a one-way optical link cannot ask for missing pieces by name (§4).
- **Erasure coding:** The general family fountain codes belong to — coding schemes designed for a channel that loses whole symbols (as opposed to bit-level corruption).
- **LT (Luby Transform) code:** The specific fountain code implemented, invented by Michael Luby; QrDiode's implementation is systematic and uses a robust soliton degree distribution (`src/QrDiode.Core/Fountain/LtCode.cs`, `RobustSoliton.cs:4`).
- **Systematic symbol:** A fountain-coded symbol that is the original source data verbatim, sent unmodified — QrDiode's first `K` symbols (`LtCode.cs:5-6`).
- **Coded symbol:** A fountain-coded symbol formed by XOR-combining several source blocks, used for symbols beyond the first `K` (`LtEncoder.cs:38-49`).
- **QR error-correction level:** One of four levels (L/M/Q/H) a QR code can be encoded at, trading data capacity against tolerance for partial damage/misreads. QrDiode always renders at level **Low (L)** (`src/QrDiode.Sender/Rendering/QrFrameRenderer.cs:35,53`).
- **Manifest:** The signed, per-session metadata frame (session ID, counter, key IDs, coding parameters, ciphertext hash, filename) that a receiver must verify before trusting anything else about a transfer (`src/QrDiode.Core/Manifest/TransferManifest.cs`).
- **Carousel:** The sender's infinite replay loop — systematic symbols, then coded symbols, with the manifest re-emitted every 20 frames — that continues until the air-time policy is satisfied (`SendSession.cs:133-158`; §3.6).
- **Key ceremony:** The offline, out-of-band process by which two endpoints exchange and verify each other's public keys via removable media and a voice-compared fingerprint, before any optical transfer is trusted (`docs/USER_GUIDE.md:114-166`; `src/QrDiode.KeyCeremony/Program.cs`).
- **Receipt hash:** An 8-byte (16 hex character) digest of the signed manifest, shown on both the Sender's stage and the Receiver's inbox, that operators compare as an end-to-end sanity check (`TransferManifest.cs:195-202`; `docs/USER_GUIDE.md:66-68`).
