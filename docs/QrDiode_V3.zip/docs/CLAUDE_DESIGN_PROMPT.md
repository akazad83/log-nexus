# QrDiode — Claude Design Prompt Template (UX/UI redesign, v2)

This file is a **copy-paste prompt template** for generating a creative UX/UI redesign of
QrDiode with Claude Design. It is grounded in the repository as built (Phase 1) — `README.md`,
`docs/ARCHITECTURE.md`, `docs/USER_GUIDE.md`, both WPF apps' XAML/code-behind, the shared
`Theme.xaml`, the KeyCeremony CLI and the Core pipeline's user-visible states — **plus the new
product direction** described in the "What changes" section below.

## How to use

1. Copy everything inside the `PROMPT` block into Claude Design.
2. Fill the `{{…}}` slots at the top. Leave the ground-truth sections as-is.
3. For focused sessions, append one of the **Task modules** at the end instead of the full task.

## What changes vs. the current build (v2 direction)

| Area | Today | v2 direction |
|---|---|---|
| Sender payload source | Operator browses one file, sends once | **Live source simulator**: the app randomly generates realistic JSON API-style payloads at intermittent, human-looking intervals and streams them one after another as separate sessions (manual file send stays as a second mode) |
| Sender transmission surface | Maximized, borderless, topmost fullscreen window | **Resizable, movable "QR stage" window** whose size the operator controls; the operator dashboard stays visible next to it |
| Receiver output | One result card per session | **Live inbox panel** on one side of the window listing every received JSON payload with a pretty-printed JSON viewer, verification badge and receipt |
| Visual identity | Functional dark utility theme | **Creative, distinctive, intuitive** — bold identity, still operator-grade |

---

## PROMPT

````text
# ROLE

You are a senior product designer with a strong visual voice, specialising in industrial /
OT security tooling and Windows desktop (WPF) apps. You design interfaces that are
memorable and intuitive without sacrificing operator trust or legibility.

# TASK

{{TASK — default: "Redesign the complete UX/UI of both QrDiode desktop apps (Sender + Receiver)
around the v2 direction below, as one coherent, creative design system with every screen and
state" | alternatives: see Task modules}}

Fidelity: {{FIDELITY — wireframe | mid-fi | hi-fi pixel mockups}}
Directions to explore before converging: {{N — e.g. 3}}
Theme latitude: {{THEME — "dark only (evolve current)" | "dark default + light variant" |
"open — propose the palette"}}
Deliverable format: {{e.g. "annotated screens per state + component sheet + token table +
motion notes + WPF-feasibility notes + copy deck"}}

# PRODUCT — what QrDiode is (ground truth, do not reinterpret)

QrDiode is a **one-way optical data diode**. It moves data (JSON / XML transactions, files up
to 64 MB) from an OT (industrial control) PC to an IT PC **with no network path at all**:

* The **Sender** app (OT side) encrypts → signs → fountain-encodes each payload and plays it as
  an **animated stream of QR codes** on the OT monitor.
* The **Receiver** app (IT side) watches that monitor through a **webcam**, decodes the QR
  frames, verifies the ECDSA signature, checks anti-replay, decrypts (AES-256-GCM), validates
  the content (XXE-safe XML / depth-capped JSON) and stores the payload in a quarantine folder
  with a SQLite journal and hash-chained audit log.
* **No back-channel, ever.** The receiver cannot ACK, retry or request anything. Fountain
  coding (Luby Transform) makes late joining and dropped frames harmless — the sender loops
  each payload's frames until it moves on; the receiver completes when it has enough symbols.
* **One payload = one session** with its own session ID, monotonic counter, manifest,
  signature and **receipt hash** shown on both screens for out-of-band comparison.
* Trust is established **offline** by a key ceremony (non-exportable CNG/TPM keys, public
  bundles on removable media, fingerprints `3F2A-91CC-07B1-…` compared by voice).
* **Security is always on and cannot be turned off anywhere in the UI.** The only security
  toggle is the receiver's **Strict mode** (replay window 48 h → 15 min). Every step
  **fails closed**.
* Both apps have **⚡ Demo setup** to provision demo keys on a single machine.

Mental model to express visually: *data becomes light, travels one way, nothing comes back,
every packet is checked, green is earned.*

# V2 DIRECTION — the new behaviours the design must serve

## 1. Sender: Live source simulator (primary mode) + manual file send (secondary mode)
* The Sender simulates a real production system: it **randomly generates JSON payloads that
  look like real application API payloads** (see "Payload catalogue" below) at
  **intermittent, irregular intervals** (e.g. bursts of 2–3 within seconds, then a quiet
  20–40 s; configurable min/max interval and burstiness). It behaves like a plant system
  emitting events, not a demo loop.
* Each generated payload is **queued**, then transmitted as its own session: encode → play
  frames for a bounded loop/time budget → advance to the next. Because there is no ACK the
  sender needs a visible **per-payload air-time policy** (e.g. "loop 3× K frames or ≥ 6 s,
  whichever is longer") and a **between-sessions gap** so the receiver can finalize.
* The operator can **start / pause / stop** the source, tweak rate/burstiness, **inject one
  payload now**, pick which payload types are enabled, and see the **queue** (queued →
  encoding → on air → sent, with receipt hash and air-time per item). Payloads keep flowing
  while the QR stage is running; the operator dashboard must remain usable.
* Manual mode (browse a file, send once) stays available and uses the same queue.

## 2. Sender: Resizable "QR stage" window (not maximized, not fullscreen)
* The transmission surface is a **normal, movable, resizable window** the operator sizes and
  positions manually (e.g. to fit the webcam's field of view or share a monitor with the
  dashboard). It must **never force Maximized/fullscreen**, may be optionally "keep on top",
  and must keep the QR **integer-scaled with quiet zone** at any size.
* Show a **size readout** (window px, module px, QR version, "camera-friendliness" hint —
  too small = poor decode) and offer **preset sizes** (e.g. S/M/L, "fit height") plus
  aspect lock. Keyboard: Esc stops the stage, ↑/↓ fps, ± resize presets — propose others.
* Chrome outside the QR may carry: on-air indicator, current payload name/type, session
  progress (loop count / frames), receipt hash, "next payload in …", fps. Everything is
  subordinate to the QR and must not touch its quiet zone or reduce its contrast.

## 3. Receiver: Live inbox / JSON viewer panel
* One **side** of the Receiver window becomes a **live inbox** of every payload received:
  newest on top, each entry showing type/name, size, arrival time, sender key ID (short),
  outcome badge (✔ verified & stored / ◎ duplicate / ✖ rejected: reason), receipt hash,
  and a **pretty-printed, syntax-highlighted JSON viewer** (collapsible tree or formatted
  text; XML/binary payloads shown as summary + hash).
* Include search/filter (type, outcome, time), an unread/new-arrival cue, a running tally
  (verified / duplicate / rejected), auto-follow toggle, copy/export of a payload, and a
  detail view that reveals the full verification chain for that session (signature ✔,
  replay ✔, ciphertext hash ✔, GCM ✔, plaintext hash ✔, content gate ✔, stored path).
* The **camera preview and lock-on indicator stay prominent** — the operator still aims a
  camera. Back-to-back sessions must read clearly: "session 14 completing → waiting for next
  manifest" without the operator touching anything.

# USERS & CONTEXT

* **OT operator (Sender)** — line technician on a locked-down Windows PC; starts the source,
  sizes/places the QR stage for the camera, watches the queue drain, reads receipts aloud.
* **IT operator (Receiver)** — aims a webcam 20–40 cm from the OT monitor, needs peripheral
  lock-on feedback, then reviews the inbox and compares receipts.
* **Security officer / auditor** — key ceremony, rotation/revocation, journal & audit review;
  wants unambiguous outcomes and copyable hashes.
* Environment: Windows 11, 1080p-class monitors, mouse + keyboard, glare, no internet.
  During demos both apps often run **side by side on one machine** with one webcam.

# PLATFORM & HARD CONSTRAINTS

* **WPF on .NET 10, Windows only.** Everything must be buildable with WPF primitives and
  ControlTemplates (Border/Grid/StackPanel/TextBlock/Button/TextBox/ComboBox/CheckBox/
  ProgressBar/Slider/Image/ListBox/TreeView/Popup, SolidColorBrush/LinearGradientBrush,
  simple Storyboards on Opacity/Color/Transform). No web fonts, no acrylic/blur dependence,
  no shader effects. Custom drawing via `WriteableBitmap`/`DrawingVisual` is fine.
* Fonts available: **Segoe UI / Segoe UI Variable** for UI; **Consolas / Cascadia Mono** for
  hashes, key IDs, JSON, telemetry. (You may propose one additional Windows-bundled face.)
* **The QR is sacred**: pure white background, pure black modules, integer scale, ~8-module
  quiet zone, nothing overlapping. Chrome lives outside it. This holds at any stage size.
* **Camera preview** must stay large and carry a **peripheral-vision lock indicator**
  (today: green border + "LOCKED — decoding" vs grey "SEARCHING").
* Never render success before the full verification chain passes. Success, duplicate,
  rejection and I/O failure must be distinguishable at a glance.
* Motion: purposeful and cheap (opacity, colour, small transforms); nothing that competes with
  the QR or the camera preview.
* Suggested minimums: Sender dashboard ≥ 720×640; QR stage minimum such that a V30 code stays
  ≥ 2 px/module; Receiver ≥ 1200×720 to host preview + controls + inbox.

# CURRENT DESIGN TOKENS (starting point — evolve freely, but keep semantics)

Palette: Bg #13131A · Card #1C1C26 · CardBorder #2C2C3A · Field #23232F ·
Accent #4F8EF7 / hover #6BA3FF · Text #ECECF2 · SubText #9AA3B2 ·
Success #3DDC84 · Danger #FF5C5C (DangerButton base #8A3A3A) · Warning #FFC857 ·
Disabled bg #2A2A36 / fg #666677 · translucent pills #33-tinted · stage bar #161620.
Type: H1 22 SemiBold · H2 14 SemiBold · Sub 12 · Mono 12 · buttons 13 SemiBold · pills 11.
Shape: cards r10 p16×12 1 px border · buttons/fields r7 · pills r9–10 · step badge 22 px
accent circle · progress h10–14 r5 · checkbox 18 px r5.
Components: Card, StepBadge, Primary/Ghost/Danger Button, TextBox, ComboBox (custom popup),
CheckBox, ProgressBar, Slider, Status pill, Result card, Lock pill + border.

Semantic rules to preserve: Accent = action/focus/progress · Success = verified/locked/TPM ·
Warning = duplicate/transient · Danger = rejected/error · SubText/grey = idle/unknown.

# SCREEN INVENTORY & STATES (design every state)

## A. Sender — dashboard
Header: identity mark + "QrDiode Sender" + chip "OT ⟶ IT · one-way optical" + tagline
"Encrypt → sign → fountain-encode → stream as animated QR. No network. No back-channel." +
"⚡ Demo setup".
Setup steps (can be a compact rail once done):
1. **My identity** — endpoint name (default `ot-line-1`) + "Open / create keys".
   Pill: `no keys` · `TPM-backed` · `software KSP` · `error`. Mono: `sign 1A2B… kex 9C8D…`.
2. **Destination** — trusted receiver picker (`it-recv-1 · kex 9C8D…`), reload, empty state.
3. **Source** — mode switch **Live simulator | Manual file**.
   *Simulator*: start/pause/stop, interval min–max, burstiness, payload-type toggles,
   "Inject one now", air-time policy, gap between sessions.
   *Manual*: path field + Browse…, pill `Json · 8.2 KB` / `Xml · 213 KB` / `File · 12.5 MB`,
   errors "File is empty…" / "…beyond the 64 MB design envelope."
4. **Transmit** — fps 5–30 (default 15), "Open QR stage" / "Stop", stage-size presets.
**Queue / stream panel** (always visible while running): rows with type icon, name, size,
state (queued · encoding · ON AIR · sent · skipped), loop count, air-time, receipt (short),
timestamps; sparkline/tally of payloads per minute; "next emission in 00:12".
Status/log strip: "Preparing session: hash → compress → encrypt → sign …", demo-ready block
with two fingerprints, "Session ended. receipt … ← compare with the receiver's screen",
"Failed to start: …".

## B. Sender — QR stage window (resizable)
QR centred on white; outer chrome (any side you choose) with: on-air dot + "TRANSMITTING",
payload label (`order.created · 3.1 KB`), `QR v24 · 15 fps (14.8 actual) · frame 812 ·
loop 2/3 · K=41`, receipt hash (grouped, readable from 2 m), "next: sensor.telemetry in 9 s",
size readout (`640×640 · 4 px/module · good for 30–50 cm`), preset size buttons, keep-on-top
toggle, "Esc stop · ↑↓ fps". States: idle/paused (no payload on air — what does the stage
show?), on air, between sessions (gap countdown), stopped. Show at least two window sizes.

## C. Receiver — main window
Header: identity mark + "QrDiode Receiver" + chip "OT ⟶ IT · verify everything, trust
nothing" + tagline "Camera → decode → signature → anti-replay → decrypt → validate →
quarantine. Fails closed at every step." + "⚡ Demo setup".
Regions: **camera preview** (idle overlay "open keys, pick a camera, press Start"; running:
greyscale feed + `SEARCHING` ↔ `LOCKED — decoding` pill/border), **controls** (identity,
camera `Logitech C920 — 1280×720@30` + refresh, security: `0/1 trusted senders` pill + Strict
mode checkbox + always-on note, receive: ● Start / ■ Stop, progress % bar,
`batch.xml (218,442 B) · blocks 120/157 · symbols 131 · session 0f8c…`, telemetry
`frames 1834 · analyzed 1790 · QR hits 612 · 29.8 analyzed/s · 10.2 hits/s`; controls
disabled while running; errors "Trust store is empty — import the OT sender's bundle
(KeyCeremony tool) or use ⚡ Demo setup on both apps." / "Camera enumeration failed: …" /
"Failed to start: …"), and the **live inbox** (section 3 above).
Session outcomes (appear as inbox entries and as a transient banner near the preview):
* ✔ **Verified & stored** — `name (bytes in s)`, `sha256 <64 hex>`, `receipt <hash> ← compare
  with the sender's screen`, `stored <path>`.
* ◎ **Duplicate detected** — "This exact content from this sender was already stored earlier.
  Nothing was written — idempotency guaranteed."
* ✖ **Rejected** — `Unknown sender key <id>` · `Manifest signature verification failed` ·
  `Manifest addressed to a different receiver key` · `Replay check failed: DuplicateSession |
  StaleCounter | TimestampOutOfWindow` · `Ciphertext hash mismatch after decode` ·
  `Decompression failed or exceeded declared size` · `Plaintext hash mismatch` · content-gate
  failure (XXE / depth / malformed).
* ✖ **Materialization failed** — file-system error.
Inbox states: empty ("no payloads yet — aim the camera at the OT stage"), streaming with new
arrivals, filtered, item selected with JSON viewer + verification-chain detail, many items
(virtualised list), rejected-item detail.

## D. Key ceremony (optional scope; today a CLI)
`init` (TPM vs Software KSP badge, signing/kex key IDs) · `export` (fingerprint + "verify out
of band") · `import` (fingerprint to compare) · `fingerprint` · `list` (empty "(none)") ·
`delete` · `demo` / `demo-clean`. Signature moment: **side-by-side fingerprint comparison for
reading aloud**; rotation overlap and revocation outcomes.

## E. Roadmap hooks (light touch)
Multi-lane 2×1 / 2×2 QR grid on the stage with per-lane lock indicators on the receiver;
camera exposure/focus controls; audit-log/journal viewer with chain-verification result.

# PAYLOAD CATALOGUE — realistic JSON the simulator emits (use these in mockups)

Give each type an icon/colour token; keep the shapes below (they mimic real API payloads).
* `order.created` — {"event":"order.created","orderId":"ORD-2026-081634","customerId":"C-4471",
  "lines":[{"sku":"PLC-CTRL-2X","qty":12,"unitPrice":149.5}],"currency":"EUR",
  "total":1794.0,"createdAt":"2026-08-16T09:41:07Z"}
* `sensor.telemetry` — {"event":"sensor.telemetry","assetId":"LINE1-PUMP-03","ts":"…",
  "readings":{"tempC":71.4,"vibrationMm":0.82,"pressureBar":6.1},"status":"OK"}
* `batch.completed` — {"event":"batch.completed","batchId":"B-20260816-07","recipe":"R-118",
  "startedAt":"…","endedAt":"…","goodUnits":4820,"scrapUnits":13,"operator":"op-217"}
* `alarm.raised` — {"event":"alarm.raised","alarmId":"ALM-9812","severity":"HIGH",
  "source":"LINE1-CONV-02","message":"Overcurrent detected","ts":"…"}
* `inventory.adjusted` — {"event":"inventory.adjusted","sku":"VALVE-DN50","delta":-24,
  "location":"WH-A-07","reason":"CONSUMED","ts":"…"}
* `shipment.dispatched`, `maintenance.workorder`, `quality.inspection` — same style,
  200 B – 6 KB each; occasionally a larger `report.daily` (~200 KB) or an XML `batch.xml`.

Other realistic strings: key ID 16 hex (`1A2B3C4D5E6F7A8B`); fingerprint eight hex groups;
session ID 32 lowercase hex; receipt/SHA-256 64 uppercase hex; endpoints `ot-line-1`,
`it-recv-1`, `demo-ot`, `demo-it`; paths `%LocalAppData%\QrDiode\quarantine\`, `journal.db`,
`audit\*.jsonl`, `trust\`; QR v20–v40; K tens to ~50,000; fps 5–30; hits/s 8–25.

# CREATIVE BRIEF

Be bold about identity, disciplined about function. Ideas you may explore (not mandatory):
* A visual metaphor of **light crossing a gap** — a beam / bridge motif connecting OT and IT,
  used consistently as the two apps' shared identity and as the on-air/lock indicator.
* A distinctive **"on air" language** for the stage and queue (broadcast-desk feel).
* An **inbox that feels alive**: arrivals slide in, verification steps light up in sequence,
  JSON is beautifully typeset with restrained syntax colours.
* **Payload-type iconography** shared by both apps so the operator recognises
  `alarm.raised` on the sender queue and in the receiver inbox instantly.
* Data-rich but calm dashboards: sparklines for emission rate and hits/s, big receipts.
Constraints on creativity: legibility at 1–2 m for lock state, progress and receipts; the QR
and preview stay untouched; colour is never the only signal; motion stays cheap and WPF-safe.

# DESIGN PRINCIPLES

1. **Earned green** — success only after full verification; "locked" only while decoding.
2. **Fail-closed shown proudly** — rejections are specific and calm; rejected ≠ duplicate ≠
   failed at a glance.
3. **Glanceable at distance** — the operator watches the camera or the other room.
4. **The queue is the story** — on the sender the operator must always know what's on air,
   what's next, and what's done; on the receiver, what arrived and whether it's trusted.
5. **Mono for anything you'd read aloud or compare**; group long hex.
6. **The QR is the product**; the stage is a picture frame around it.
7. **Two apps, one system** — siblings, instantly distinguishable (OT vs IT).
8. **Intuitive on first launch** — a first-time operator with only the ⚡ Demo button and no
   manual should reach a verified payload in the inbox within two minutes.

# ACCESSIBILITY

WCAG 2.2 AA contrast; every colour-coded status also carries an icon + word (✔ ◎ ✖ ● ■);
full keyboard operability with visible focus; nothing conveyed by colour alone; text scales
to 125 % without clipping; hashes/JSON selectable and copyable; JSON syntax colours
colour-blind safe.

# OUT OF SCOPE / DO NOT

* No network, cloud, sharing or back-channel features of any kind.
* No switch to disable signing, encryption or replay protection.
* No UI over the QR; no reduced QR contrast or quiet zone; no forced fullscreen/maximize.
* No invented security mechanisms beyond those listed.

# DELIVERABLES

1. {{N}} direction explorations → one recommended direction with rationale.
2. Screens for A–C (D/E if in scope) covering **every state above** plus empty, loading,
   disabled and error states not yet enumerated; the QR stage at ≥ 2 sizes.
3. Component sheet: existing components evolved + new ones (mode switch, queue row, air-time
   policy control, size preset group, inbox entry, JSON viewer, verification-chain list,
   payload-type badge, sparkline) with default/hover/pressed/focus/disabled states.
4. Token table (colour, type, spacing, radius, motion durations) diffed against current values.
5. Motion spec (what animates, duration, easing) — WPF Storyboard-feasible only.
6. WPF-feasibility notes per component (ControlTemplate vs code-behind vs custom drawing).
7. Copy deck: labels, helper texts, outcome messages, empty states — terse, operator-facing.
````

---

## Task modules (append one instead of the full task)

**M1 — Sender live source simulator + queue**
> Design only the Sender's Source step (Live simulator | Manual) and the queue/stream panel:
> emission controls (interval, burstiness, payload-type toggles, inject-now), air-time policy,
> queue rows through queued → encoding → ON AIR → sent, "next emission" countdown, rate
> sparkline. Show idle, running-burst, paused, and manual-file states.

**M2 — Resizable QR stage**
> Design the QR stage window at three sizes (small share-screen, medium, large) with its
> chrome: on-air, payload label, loop/frame progress, receipt hash readable from 2 m, next-
> payload countdown, size readout + presets, keep-on-top. Include idle, on air, between-sessions
> gap, and stopped states. QR area rules are absolute.

**M3 — Receiver live inbox + JSON viewer**
> Design the Receiver's inbox side panel and detail view: entry anatomy, outcome badges,
> filters/search, new-arrival cue, tally, auto-follow, JSON viewer (tree + raw), verification-
> chain detail, copy/export. Show empty, streaming, selected, rejected-detail, and 200-item
> states — while the camera preview and lock indicator stay prominent.

**M4 — Key ceremony GUI**
> Turn the KeyCeremony CLI into a small window in the same system, centred on voice fingerprint
> comparison and trust-store management (rotation overlap, revocation, tampered-bundle outcome).

**M5 — Design system & identity**
> Propose the visual identity (mark, palette, type, motion, payload-type iconography) and a
> WPF-implementable token/component spec both apps share, output as a spec translatable into
> `Theme.xaml`. Include the state matrix for pills, queue rows, inbox entries and result banners.

**M6 — First-run / demo journey**
> Design the ⚡ Demo experience end-to-end: Sender demo → start simulator → open stage →
> Receiver demo → aim camera → first verified payload appears in the inbox → compare receipts.
> Optimise for a first-time operator with no manual.
