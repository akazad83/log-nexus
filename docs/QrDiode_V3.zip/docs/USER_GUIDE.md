# QrDiode — Step-by-Step User Guide

This guide walks you from a fresh checkout to a completed, verified OT → IT transfer.
Two paths are covered:

- **Part A — 5-minute demo on one machine** (recommended first run; full security active)
- **Part B — production setup on two machines** (the real key ceremony)

Everything requires **Windows** and the **.NET 10 SDK**.

> Command note: `dotnet run` forwards trailing arguments to the tool directly — no `--`
> separator is needed (and Windows PowerShell 5.1 actually swallows `--`, so omit it).

---

## Part A · 5-Minute Demo (one machine, full security)

The demo uses one PC as both sides: the Sender plays the QR stream on your monitor and the
Receiver watches it through your webcam. **Nothing is weakened** — real ECDSA signatures,
real ECDH + AES-256-GCM encryption, and anti-replay all run exactly as in production. The
only demo concession is that both key pairs live on the same machine.

### Step 1 — Build

```powershell
cd d:\WORKSPACE\qr-code
dotnet build -c Release
```

### Step 2 — Launch both apps

```powershell
dotnet run --project src/QrDiode.Sender  -c Release     # window 1
dotnet run --project src/QrDiode.Receiver -c Release    # window 2
```

### Step 3 — One click on each side

1. In the **Sender**, click **⚡ Demo setup** (top-right).
   It provisions the `demo-ot` and `demo-it` key pairs in Windows CNG, cross-trusts their
   public bundles, opens the sender keys, and pre-selects `demo-it` as the destination.
2. In the **Receiver**, click **⚡ Demo setup**.
   It opens the `demo-it` keys. The security card should now show **1 trusted sender** (green).
3. Both apps display the same two key **fingerprints** — in a real deployment you would read
   these aloud between rooms; for the demo just eyeball that they match.

### Step 4 — Transfer something

1. **Receiver**: pick your webcam in *Camera*, leave **Strict mode** checked
   (15-minute replay window instead of 48 hours — the "stricter security" demo setting),
   press **● Start receiving**.
2. **Sender**: press **● Start source**. The live simulator begins emitting realistic JSON
   plant events (`order.created`, `sensor.telemetry`, `alarm.raised`, …) at irregular
   intervals, and the **QR stage** window opens with them. Each payload becomes its own
   session: *queued → encoding → ON AIR → sent*, visible in the queue table.
   *Impatient? Press **Inject one now** to emit immediately.*
3. Drag and size the QR stage so it suits the camera — it is a normal window, never
   fullscreen. Its size readout must read **✔ good for 30–50 cm**; if it says
   *move camera closer*, press **L** or drag the window bigger.
4. Point the webcam at the stage, 20–40 cm away, as square-on and steady as you can.
   The preview border and the pill in its corner turn **green ("LOCKED — decoding")** while
   codes are being read; the progress bar shows decoded blocks.
5. Each completed payload slides into the receiver's **inbox** (Live monitor tab) with a ✔
   badge, its verification chain, its **receipt hash** and the payload itself — each row
   carries a one-line preview, and the viewer below shows it **Formatted / Raw / Hex**. The
   sender keeps streaming the next one — you do not have to touch anything between payloads.
6. Compare the receipt on an inbox entry with the one on the sender's stage and queue row —
   **the two hashes matching is your end-to-end proof.**
7. Open the receiver's **Archive** tab: every arrival ever judged is listed there, read back
   from the local store and the journal — searchable, filterable by date and outcome, with the
   payload viewer, a per-type breakdown, and **Verify bytes on disk** to re-hash a stored file
   against the hash the sender signed.

Both apps show the payload, not just its name: select any row in the sender's queue to read
the exact bytes about to be encrypted (**Formatted / Raw / Hex**, with *Save a copy…*). The
sender is the last place a human can see plaintext — after that it is ciphertext on a screen.

Manual mode is still there: switch *Source* to **Manual file**, *Browse…* to any
XML/JSON/file up to 64 MB, and press **Inject one now**. It joins the same queue and obeys
the same air-time policy, so the receiver cannot tell the two modes apart.

The received file is in the receiver's **local store** — by default
`%LocalAppData%\QrDiode\quarantine\<yyyy-MM-dd>\<session>_<name>`, with a `.meta.json`
sidecar beside it — journaled in `%LocalAppData%\QrDiode\journal.db`, with hash-chained audit
logs in `%LocalAppData%\QrDiode\audit\`. Point the store anywhere you like with **Change…**
on the Archive tab.

### Step 5 — See the security actually working (optional but fun)

- **Replay attack**: send the same file again → the sender reserves a *new* counter and
  session, so it works. But close and re-open the Receiver, then feed it a *screen recording*
  of the previous transmission → rejected with `Replay check failed: DuplicateSession`.
- **Duplicate content**: send the same file twice normally → the second run completes but the
  inbox entry shows **◎ duplicate** and nothing is written twice (idempotency). Its
  verification chain shows every step green up to *Stored to the local store*, which reads
  *already stored — nothing written*.
- **Unknown sender**: run `demo-clean` then `demo` again in the KeyCeremony tool on the
  sender side only — the receiver now rejects with `Unknown sender key` until it re-trusts.
- **Tamper check**: `dotnet run --project src/QrDiode.KeyCeremony list` shows the trust
  store; edit any byte of a stored payload, then press **Verify bytes on disk** on that row in
  the **Archive** tab — it reads *✖ file no longer matches the signed hash* and prints what the
  bytes hash to now.

### Cleaning up demo keys

```powershell
dotnet run --project src/QrDiode.KeyCeremony demo-clean
```

Run this before provisioning a machine for production use.

---

## Part B · Production Setup (two machines)

### Overview

```
   OT machine (sender)                       IT machine (receiver)
   -------------------                       ---------------------
1. init ot-line-1                         1. init it-recv-1
2. export ot-line-1  -> ot.json  --+   +--  2. export it-recv-1 -> it.json
                                  |USB|
3. import it.json    <------------+   +-->  3. import ot.json
4. COMPARE FINGERPRINTS BY VOICE  <------>  (both sides read the same value aloud)
```

### Step 1 — Provision keys on each machine

On the **OT machine**:

```powershell
dotnet run --project src/QrDiode.KeyCeremony init ot-line-1
dotnet run --project src/QrDiode.KeyCeremony export ot-line-1 E:\ot-line-1.json
```

On the **IT machine**:

```powershell
dotnet run --project src/QrDiode.KeyCeremony init it-recv-1
dotnet run --project src/QrDiode.KeyCeremony export it-recv-1 E:\it-recv-1.json
```

Notes:
- Keys are created **non-exportable** in Windows CNG. If a TPM is present the tool uses the
  Platform Crypto Provider automatically (`init` prints which storage was used).
- Only **public** bundles are exported. Private keys never leave the machine, ever.

### Step 2 — Exchange bundles on removable media

Carry `ot-line-1.json` to the IT machine and `it-recv-1.json` to the OT machine
(USB stick, or any approved one-way media process).

```powershell
# On IT:
dotnet run --project src/QrDiode.KeyCeremony import E:\ot-line-1.json
# On OT:
dotnet run --project src/QrDiode.KeyCeremony import E:\it-recv-1.json
```

### Step 3 — Verify fingerprints (do not skip)

Each `import` prints a fingerprint like `3F2A-91CC-07B1-…`. The **exporting** operator runs
`fingerprint <bundle.json>` on their original file, and both operators compare the values
by phone or in person. **If they differ, someone tampered with the bundle in transit —
delete it immediately.** This step is what defeats a swapped-USB-stick attack.

### Step 4 — Daily operation

**Sender (OT):**
1. Launch `QrDiode.Sender` → *Step 1*: endpoint name `ot-line-1` → **Open / create keys**.
2. *Step 2*: pick the IT receiver from the destination list.
3. *Step 3*: choose the source.
   - **Live simulator** — emits JSON plant events on an irregular schedule. Set the interval
     range and burstiness, and enable only the payload types you want. `.json` and `.xml`
     are content-validated on arrival; anything else travels as opaque verified bytes.
   - **Manual file** — browse to one payload (64 MB max) and **Inject one now**.
4. *Step 4*: **Open QR stage**, then size and place the window for the camera.
   - `Esc` closes · `↑`/`↓` changes fps live (start at 15) · `+`/`−` cycles the size presets ·
     `Ctrl+T` keeps it on top · `Ctrl+K` skips the payload on air · `Ctrl+C` copies the receipt.
   - The stage shows what is on air, the QR version, loop count, **receipt hash** and a
     size readout in px/module. The queue table on the dashboard shows what is next and
     what is done, with the **air time** each payload actually got.

Because there is no acknowledgement, a session ends on an **air-time policy**, not on
success: *loop 3× K frames **or** ≥ 6 s, whichever is longer*, then a 1.5 s gap so the
receiver can finalize. Exposure is the only guarantee the sender has.

**Receiver (IT):**
1. Launch `QrDiode.Receiver` → *Step 1*: endpoint `it-recv-1` → **Open keys**.
2. *Step 2*: select the camera (the list pre-picks each camera's fastest mode).
3. *Step 3*: leave **Strict mode** on if OT and IT clocks are reasonably synchronized;
   turn it off only if clock drift between the environments can exceed minutes.
4. *Step 4*: **● Start receiving**, aim the camera at the OT screen.
   - Green border + **LOCKED** pill = codes are decoding; keep the camera steady.
   - Progress shows `blocks decoded / K`. Late joining and dropped frames are harmless —
     the carousel keeps looping until you have everything.
5. On completion the payload lands in the **inbox** (newest first) with its outcome badge,
   full verification chain, receipt and the payload itself. Back-to-back sessions need no
   intervention — the ribbon under the preview reads *session complete → waiting for the
   next manifest*.
6. **Compare the receipt hash with the sender's screen** (this is the operator-level
   end-to-end check), then collect the file from the local store — or use
   **Show in folder** on the selected entry.

### The Archive tab (IT)

Everything the receiver has judged is indexed on disk, so it survives closing the app:

| Control | What it does |
|---|---|
| **LOCAL STORE** + *Change…* | Where verified payloads are written. Any local or mapped folder; the receiver proves it is writable before a run starts and refuses to start if it is not. |
| **Date folders** / **Metadata sidecars** | Layout of the store: `<yyyy-MM-dd>\<session>_<name>`, and a `.meta.json` per payload carrying session, counter, key ids, both hashes and the receipt. |
| Search · date range · outcome | Query the index — filename, type, session, receipt, sender key, payload text or rejection reason. Rejections are indexed too: "nothing was written" is evidence. |
| **Verify bytes on disk** | Re-hashes the stored file and compares with the SHA-256 the sender signed. The one check still available months later, with no back-channel. |
| **Copy** / **Export…** / **Show in folder** | Take a copy out of the store; the store's own copy is never moved or altered. |
| **BY PAYLOAD TYPE** | Count and stored volume per event type in the current filter. |

Payloads received before this index existed are on disk but not listed — the empty state says
so. Everything received from then on is indexed.

### Camera tips (this is the whole bottleneck)

| Symptom | Fix |
|---|---|
| Pill stays "SEARCHING" | Move closer (QR should fill ~½ the frame height), square up the angle; check the stage's px/module readout is green |
| Hits/s very low | Kill reflections/glare on the monitor; increase monitor brightness; lower sender fps with `↓` |
| Progress stalls near 100% | Normal for a few seconds — the last blocks arrive via coded symbols; just wait |
| Blurry preview | Lock focus if your camera app allows it; avoid autofocus hunting |

### Key rotation & revocation

1. Provision a new endpoint (`init ot-line-2`), export/import/verify as above.
2. Both old and new sender keys can be trusted simultaneously during the overlap window.
3. Revoke by deleting the old bundle from `%LocalAppData%\QrDiode\trust\` on the receiver
   and `delete ot-line-1` on the sender.

### Where everything lives

| Path | Contents |
|---|---|
| `%LocalAppData%\QrDiode\trust\` | Imported public-key bundles (the trust store) |
| `%LocalAppData%\QrDiode\quarantine\` | Default local store: received, fully verified files (`<yyyy-MM-dd>\<session>_<name>` + `.meta.json`). Relocatable from the Archive tab |
| `%LocalAppData%\QrDiode\journal.db` | SQLite transfer journal + anti-replay watermarks + the archive index |
| `%LocalAppData%\QrDiode\receiver-settings.json` | Store location and layout (nothing security-relevant) |
| `%LocalAppData%\QrDiode\audit\*.jsonl` | Hash-chained audit logs (verify with `AuditLog.Verify`) |
| `%LocalAppData%\QrDiode\sender-counter.bin` | DPAPI-protected monotonic send counter |
| Windows CNG | Private keys (non-exportable, TPM when available) |

---

## Security cheat-sheet

What is **always on** (cannot be disabled anywhere in the UI):

| Layer | Mechanism |
|---|---|
| Authenticity | ECDSA P-256 signature verified **before any payload byte is parsed** |
| Confidentiality | AES-256-GCM, per-session key via static-static ECDH P-256 + HKDF-SHA256 |
| Anti-replay | Session GUID dedupe + per-key monotonic counter + timestamp window |
| Integrity | CRC-32 per frame → ciphertext SHA-256 → GCM tag → plaintext SHA-256 |
| Hostile input | XXE-prohibited XML, depth-capped JSON, decompression size cap, sanitized filenames |
| Traceability | Hash-chained audit logs both ends + matching receipt hashes |

What **Strict mode** adds: replay acceptance window shrinks 48 h → 15 min.

What the **demo** changes: nothing in the security stack — it only co-locates both key pairs
on one machine so you can evaluate without two PCs. Run `demo-clean` before going to production.
