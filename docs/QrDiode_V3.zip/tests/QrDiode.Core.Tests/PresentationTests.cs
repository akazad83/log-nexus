using System.Text;
using QrDiode.Core.Manifest;
using QrDiode.Core.Presentation;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// The payload viewers are the only place a human reads the data itself — on the OT side before it
/// is encrypted, on the IT side after it is verified. They format *hostile* input (the sender
/// formats whatever the plant produced; the receiver formats whatever arrived), so the interesting
/// cases here are the malformed ones: nothing may throw, and nothing may resolve.
/// </summary>
public class PresentationTests
{
    private static byte[] Utf8(string text) => Encoding.UTF8.GetBytes(text);

    [Fact]
    public void Json_IsIndented_AndKeepsEveryValue()
    {
        var result = PayloadFormatter.Formatted(ContentKind.Json, Utf8("""{"id":7,"tags":["a","b"],"ok":true}"""));

        Assert.Equal(PayloadTextKind.Json, result.Kind);
        Assert.False(result.Truncated);
        Assert.Contains("\n", result.Text);
        Assert.Contains("\"tags\"", result.Text);
        Assert.Contains("true", result.Text);
    }

    [Fact]
    public void MalformedJson_FallsBackToRawText_WithoutThrowing()
    {
        var result = PayloadFormatter.Formatted(ContentKind.Json, Utf8("{\"id\": 7, oops"));

        Assert.Equal(PayloadTextKind.Json, result.Kind);
        Assert.Contains("oops", result.Text);
    }

    [Fact]
    public void DeeplyNestedJson_IsRefusedByTheParser_AndShownRaw()
    {
        string deep = new string('[', 200) + new string(']', 200);
        var result = PayloadFormatter.Formatted(ContentKind.Json, Utf8(deep));

        // The indenting parser is depth-capped like the content gate; the text still gets shown.
        Assert.Equal(deep, result.Text);
    }

    [Fact]
    public void Xml_IsIndented()
    {
        var result = PayloadFormatter.Formatted(ContentKind.Xml, Utf8("<batch><item id=\"1\"/><item id=\"2\"/></batch>"));

        Assert.Equal(PayloadTextKind.Xml, result.Kind);
        Assert.Contains("\n  <item", result.Text);
    }

    [Fact]
    public void Xml_WithDoctype_IsNeverExpanded()
    {
        const string xxe = """
            <?xml version="1.0"?>
            <!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///c:/windows/win.ini">]>
            <foo>&xxe;</foo>
            """;

        var result = PayloadFormatter.Formatted(ContentKind.Xml, Utf8(xxe));

        // DTDs are prohibited, so indenting fails and the raw document is shown verbatim —
        // entity unexpanded, nothing fetched from disk.
        Assert.Contains("&xxe;", result.Text);
        Assert.Contains("<!DOCTYPE", result.Text);
        Assert.DoesNotContain("[fonts]", result.Text);
    }

    [Fact]
    public void BinaryPayload_BecomesAHexDump()
    {
        byte[] payload = [0x00, 0x01, 0x02, 0xFF, 0xFE, (byte)'A'];
        var result = PayloadFormatter.Formatted(ContentKind.File, payload);

        Assert.Equal(PayloadTextKind.Hex, result.Kind);
        Assert.StartsWith("00000000  00 01 02 ff fe 41", result.Text);
        Assert.Contains("....", result.Text);   // ASCII gutter, unprintables dotted
        Assert.EndsWith("A\n", result.Text);
    }

    [Fact]
    public void HexDump_MarksTruncationAndKeepsTheTotal()
    {
        byte[] payload = new byte[100];
        var result = PayloadFormatter.Hex(payload, maxBytes: 32);

        Assert.True(result.Truncated);
        Assert.Equal(100, result.TotalBytes);
        Assert.Equal(2, result.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length);
    }

    [Fact]
    public void TextFile_StaysText()
    {
        var result = PayloadFormatter.Formatted(ContentKind.File, Utf8("line one\nline two\ttabbed\n"));

        Assert.Equal(PayloadTextKind.Plain, result.Kind);
        Assert.Contains("line two", result.Text);
    }

    [Fact]
    public void OversizedPayload_IsCappedAndSaysSo()
    {
        var result = PayloadFormatter.Raw(ContentKind.File, Utf8(new string('x', 300_000)), limit: 1000);

        Assert.True(result.Truncated);
        Assert.Equal(1000, result.Text.Length);
        Assert.Equal(300_000, result.TotalBytes);
    }

    [Fact]
    public void Snippet_FlattensWhitespaceAndCuts()
    {
        string snippet = PayloadFormatter.Snippet(ContentKind.Json, Utf8("{\n  \"event\":  \"order.created\",\n  \"id\": 7\n}"), max: 24);

        Assert.Equal("{ \"event\": \"order.create…", snippet);
    }

    [Fact]
    public void Snippet_DescribesBinaryRatherThanShowingMojibake()
    {
        byte[] payload = [0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10];
        Assert.Equal("binary · 6 bytes", PayloadFormatter.Snippet(ContentKind.File, payload));
    }

    [Fact]
    public void Snippet_OfALargePayload_DoesNotDecodeTheWholeThing()
    {
        // A 64 MB payload must still produce a one-line snippet; the probe stops after a few KB.
        byte[] payload = Utf8("{\"head\":\"value\"," + new string('a', 8 * 1024 * 1024) + "}");
        string snippet = PayloadFormatter.Snippet(ContentKind.Json, payload, max: 20);

        Assert.Equal("{\"head\":\"value\",aaaa…", snippet);
    }

    [Fact]
    public void EmptyPayload_IsHandledEverywhere()
    {
        Assert.Equal("", PayloadFormatter.Snippet(ContentKind.Json, []));
        Assert.Equal("", PayloadFormatter.Hex([]).Text);
        Assert.Equal("", PayloadFormatter.Formatted(ContentKind.File, []).Text);
    }
}
