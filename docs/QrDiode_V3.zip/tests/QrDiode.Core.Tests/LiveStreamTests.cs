using System.Text;
using System.Text.Json;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Core.Simulation;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// v2 behaviour: a live source emitting session after session, and a receiver that has to survive
/// the sender's carousel still playing session N while session N+1 is on its way.
/// </summary>
public class LiveStreamTests : IDisposable
{
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public LiveStreamTests()
    {
        _trust.Add(PublicKeyBundle.FromKeys("ot-line-1", _sender).ToPeerKeys());
        _receiverPeer = PublicKeyBundle.FromKeys("it-recv-1", _receiver).ToPeerKeys();
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    // ═══════════════════ the simulator ═══════════════════

    [Fact]
    public void Simulator_EmitsContentGateCleanJson_ForEveryCatalogueType()
    {
        var simulator = new PayloadSimulator(seed: 7);

        foreach (var type in PayloadCatalogue.All)
        {
            var payload = simulator.Generate(type);
            Assert.NotNull(payload);
            Assert.Equal(type, payload!.Type);
            Assert.True(payload.Size > 0, $"{type.Name} produced no bytes.");

            // The receiver's content gate is the real judge of these payloads — if the simulator
            // can emit something the gate rejects, the demo breaks in the least obvious place.
            Assert.True(ContentGate.Validate(type.Kind, payload.Bytes, out string error), $"{type.Name}: {error}");

            if (type.Kind == ContentKind.Json)
            {
                using var document = JsonDocument.Parse(payload.Bytes);
                Assert.Equal(type.Name, document.RootElement.GetProperty("event").GetString());
            }
        }
    }

    [Fact]
    public void Simulator_ReportDaily_IsTheHeavyweight()
    {
        var simulator = new PayloadSimulator(seed: 3);
        var small = simulator.Generate(PayloadCatalogue.SensorTelemetry)!;
        var large = simulator.Generate(PayloadCatalogue.ReportDaily)!;

        Assert.InRange(small.Size, 100, 6 * 1024);
        Assert.InRange(large.Size, 100_000, 400_000);
    }

    [Fact]
    public void Simulator_DisabledTypes_AreNeverEmitted()
    {
        var options = new SimulatorOptions();
        options.EnabledTypes.Clear();
        options.EnabledTypes.Add(PayloadCatalogue.AlarmRaised.Name);
        var simulator = new PayloadSimulator(options, seed: 11);

        for (int i = 0; i < 50; i++)
            Assert.Equal(PayloadCatalogue.AlarmRaised, simulator.Generate()!.Type);

        options.EnabledTypes.Clear();
        Assert.Null(simulator.Generate()); // nothing enabled → nothing emitted, rather than a default
    }

    [Fact]
    public void Simulator_Delays_StayInRangeAndCluster()
    {
        var options = new SimulatorOptions
        {
            MinInterval = TimeSpan.FromSeconds(4),
            MaxInterval = TimeSpan.FromSeconds(40),
            Burstiness = 1.0, // every quiet gap opens a burst
        };
        var simulator = new PayloadSimulator(options, seed: 5);

        var delays = Enumerable.Range(0, 400).Select(_ => simulator.NextDelay().TotalSeconds).ToList();

        // Burst gaps are short; quiet gaps live inside the operator's range. Nothing in between.
        Assert.All(delays, d => Assert.True(d <= 40.001, $"{d}s exceeds the configured maximum."));
        Assert.Contains(delays, d => d < 3);
        Assert.Contains(delays, d => d >= 4);
        Assert.All(delays.Where(d => d >= 3), d => Assert.InRange(d, 4, 40.001));
    }

    [Fact]
    public void Simulator_Metronome_NeverBursts()
    {
        var options = new SimulatorOptions { MinInterval = TimeSpan.FromSeconds(10), Burstiness = 0 };
        var simulator = new PayloadSimulator(options, seed: 9);

        Assert.All(Enumerable.Range(0, 100).Select(_ => simulator.NextDelay().TotalSeconds),
            d => Assert.InRange(d, 10, 40.001));
    }

    // ═══════════════════ back-to-back sessions ═══════════════════

    [Fact]
    public void ThreeSessionsBackToBack_AllComplete_OnOneEngine()
    {
        var guard = new InMemoryReplayGuard();
        var engine = new ReceiveEngine(_trust, guard, _receiver);
        var simulator = new PayloadSimulator(seed: 21);

        var types = new[] { PayloadCatalogue.OrderCreated, PayloadCatalogue.AlarmRaised, PayloadCatalogue.BatchCompleted };
        for (ulong i = 0; i < 3; i++)
        {
            var payload = simulator.Generate(types[i])!;
            var session = SendSession.Create(payload.Bytes, payload.Filename, payload.Type.Kind,
                _sender, _receiverPeer, counter: i + 1);

            FeedUntilVerdict(session, engine);

            Assert.NotNull(engine.Completed);
            Assert.Equal(payload.Bytes, engine.Completed!.Plaintext);
            Assert.Equal(session.ReceiptHash, engine.Completed.ReceiptHash);

            engine.Reset(); // what the receiver does once it has handled the arrival
        }
    }

    [Fact]
    public void CarouselTail_AfterReset_IsIgnored_NotReJudged()
    {
        // The sender keeps playing a session for the rest of its air time. Once the receiver has
        // ruled on that session, the leftovers must be silence — not a replay rejection per loop.
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        byte[] payload = Encoding.UTF8.GetBytes("""{"event":"alarm.raised","severity":"HIGH"}""");
        var session = SendSession.Create(payload, "alarm.raised.json", ContentKind.Json, _sender, _receiverPeer, counter: 1);

        FeedUntilVerdict(session, engine);
        Assert.NotNull(engine.Completed);
        engine.Reset();

        int tail = 0;
        foreach (var frame in session.Carousel())
        {
            var result = engine.Feed(frame);
            Assert.Equal(FeedResult.Ignored, result);
            if (++tail > 400) break;
        }
        Assert.Null(engine.ActiveManifest);
    }

    [Fact]
    public void GenuineReplay_OnAFreshEngine_IsStillRejected()
    {
        // Reset() must not weaken anti-replay: the settled set is per engine instance, while the
        // replay guard is the durable authority across runs.
        var guard = new InMemoryReplayGuard();
        byte[] payload = Encoding.UTF8.GetBytes("""{"event":"order.created","orderId":"ORD-1"}""");
        var session = SendSession.Create(payload, "order.created.json", ContentKind.Json, _sender, _receiverPeer, counter: 1);

        var first = new ReceiveEngine(_trust, guard, _receiver);
        FeedUntilVerdict(session, first);
        Assert.NotNull(first.Completed);

        var second = new ReceiveEngine(_trust, guard, _receiver);
        FeedUntilVerdict(session, second);
        Assert.Null(second.Completed);
        Assert.Contains("Replay", second.LastRejection);
        Assert.NotNull(second.LastRejectionInfo);
        Assert.Equal(session.Manifest.SessionId, second.LastRejectionInfo!.Manifest!.SessionId);
    }

    [Fact]
    public void ReplayRejection_IsReportedOnce_NotEveryCarouselLoop()
    {
        var guard = new InMemoryReplayGuard();
        byte[] payload = Encoding.UTF8.GetBytes("""{"event":"order.created","orderId":"ORD-2"}""");
        var session = SendSession.Create(payload, "order.created.json", ContentKind.Json, _sender, _receiverPeer, counter: 1);

        var first = new ReceiveEngine(_trust, guard, _receiver);
        FeedUntilVerdict(session, first);

        var second = new ReceiveEngine(_trust, guard, _receiver);
        int rejections = 0, fed = 0;
        foreach (var frame in session.Carousel())
        {
            if (second.Feed(frame) == FeedResult.Rejected) rejections++;
            if (++fed > 500) break;
        }

        Assert.Equal(1, rejections);
    }

    [Fact]
    public void UnverifiedRejections_StillSurfaceEveryTime()
    {
        // A frame whose signature never verified must not be able to squat a session id and
        // silence a later, legitimate session with the same one.
        using var rogue = new EphemeralEndpointKeys();
        byte[] payload = new byte[800];
        var session = SendSession.Create(payload, "x.bin", ContentKind.File, rogue, _receiverPeer, counter: 1);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        int rejections = 0, fed = 0;
        foreach (var frame in session.Carousel())
        {
            if (engine.Feed(frame) == FeedResult.Rejected) rejections++;
            if (++fed > 200) break;
        }

        Assert.True(rejections > 1, "An untrusted sender must be re-reported, never silently settled.");
        Assert.Contains("Unknown sender key", engine.LastRejection);
        Assert.Null(engine.LastRejectionInfo!.Manifest); // nothing about it is trustworthy yet
    }

    private static void FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        long cap = 500_000;
        foreach (var frame in session.Carousel())
        {
            if (--cap <= 0) break;
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) break;
        }
    }
}
