﻿using System.Security.Cryptography;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

public class ManifestAndAuditTests
{
    private static TransferManifest MakeManifest(EphemeralEndpointKeys sender, EphemeralEndpointKeys receiver) => new()
    {
        SessionId = Guid.NewGuid(),
        TimestampUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        Counter = 42,
        SenderSigningKeyId = sender.SigningKeyId,
        ReceiverAgreementKeyId = receiver.AgreementKeyId,
        Salt = new byte[32],
        Nonce = new byte[12],
        SymbolSize = 1350,
        SourceSymbolCount = 8,
        LtSeed = 999,
        RedundancyHint = 3,
        OriginalSize = 20_000,
        CompressedSize = 10_000,
        CiphertextSize = 10_016,
        Compression = CompressionAlg.Brotli,
        CiphertextSha256 = new byte[32],
        ContentType = ContentKind.Xml,
        Filename = "batch-042.xml",
    };

    [Fact]
    public void Manifest_SerializeParse_RoundTrips()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        Assert.True(TransferManifest.TryParse(body, out var parsed, out var error), error);

        Assert.Equal(manifest.SessionId, parsed!.SessionId);
        Assert.Equal(manifest.Counter, parsed.Counter);
        Assert.Equal(manifest.Filename, parsed.Filename);
        Assert.Equal(manifest.SymbolSize, parsed.SymbolSize);
        Assert.Equal(manifest.SourceSymbolCount, parsed.SourceSymbolCount);
        Assert.Equal(manifest.Compression, parsed.Compression);
        Assert.Equal(manifest.ContentType, parsed.ContentType);
        Assert.Equal(manifest.CiphertextSize, parsed.CiphertextSize);
    }

    /// <summary>
    /// The manifest is signed but not encrypted, so every byte of it is readable by anyone who can
    /// film the screen. A hash of the plaintext is therefore an enumeration oracle over predictable
    /// payloads — and transaction messages are predictable. It must not appear on the wire in any
    /// form; the receiver computes it locally once the payload is decrypted.
    /// </summary>
    [Fact]
    public void Manifest_DoesNotCarryThePlaintextHash()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();

        // A real session, so the bytes under test are the ones that would actually go on screen.
        byte[] plaintext = """{"event":"goods-receipt","asset":"LINE1-PUMP-03","qty":47}"""u8.ToArray();
        var session = SendSession.Create(plaintext, "txn.json", ContentKind.Json,
            sender, ToPeer(receiver), counter: 1);

        byte[] plaintextHash = SHA256.HashData(plaintext);
        byte[] frame = session.ManifestFrame;

        for (int i = 0; i + plaintextHash.Length <= frame.Length; i++)
            Assert.False(frame.AsSpan(i, plaintextHash.Length).SequenceEqual(plaintextHash),
                $"the plaintext hash appears in the manifest frame at offset {i}");
    }

    private static PeerPublicKeys ToPeer(EphemeralEndpointKeys keys)
    {
        var sign = ECDsa.Create();
        sign.ImportSubjectPublicKeyInfo(keys.SigningKey.ExportSubjectPublicKeyInfo(), out _);
        var kex = ECDiffieHellman.Create();
        kex.ImportSubjectPublicKeyInfo(keys.AgreementKey.ExportSubjectPublicKeyInfo(), out _);

        return new PeerPublicKeys
        {
            Name = "receiver",
            SigningPublicKey = sign,
            AgreementPublicKey = kex,
            SigningKeyId = keys.SigningKeyId,
            AgreementKeyId = keys.AgreementKeyId,
        };
    }

    [Fact]
    public void Manifest_SignVerify_DetectsTamper()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        byte[] sig = manifest.Sign(sender.SigningKey, body);
        Assert.Equal(64, sig.Length);
        Assert.True(TransferManifest.VerifySignature(sender.SigningKey, body, sig));

        byte[] tampered = (byte[])body.Clone();
        tampered[24] ^= 0x01; // counter field
        Assert.False(TransferManifest.VerifySignature(sender.SigningKey, tampered, sig));

        using var otherKey = new EphemeralEndpointKeys();
        Assert.False(TransferManifest.VerifySignature(otherKey.SigningKey, body, sig));
    }

    [Theory]
    [InlineData(108, 0L)]                     // original size = 0
    [InlineData(108, -5L)]                    // negative size
    [InlineData(108, 200L * 1024 * 1024)]     // beyond envelope
    public void Manifest_InsaneSizes_AreRejected(int offset, long value)
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();
        System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(body.AsSpan(offset), value);

        Assert.False(TransferManifest.TryParse(body, out _, out _));
    }

    /// <summary>
    /// The receiver builds its LT decoder from these fields before the first data symbol arrives,
    /// and that allocation scales with K. Left unbounded, a signed manifest declaring a large
    /// ciphertext at symbolSize 1 produces a K in the millions and a multi-gigabyte allocation at
    /// the moment the manifest is accepted.
    /// </summary>
    [Fact]
    public void Manifest_SymbolSizeAmplification_IsRejected()
    {
        byte[] body = BuildBody(originalSize: 20_000, compressedSize: 10_000, symbolSize: 1);

        Assert.False(TransferManifest.TryParse(body, out _, out string error));
        Assert.Contains("Symbol size", error);
    }

    [Fact]
    public void Manifest_SymbolSizeAboveFrameCapacity_IsRejected()
    {
        // One byte more than any frame we would parse could ever deliver.
        byte[] body = BuildBody(originalSize: 20_000, compressedSize: 10_000,
            symbolSize: (ushort)(TransferManifest.MaxSymbolSize + 1));

        Assert.False(TransferManifest.TryParse(body, out _, out string error));
        Assert.Contains("Symbol size", error);
    }

    [Fact]
    public void Manifest_SourceSymbolCountBeyondCeiling_IsRejected()
    {
        // A payload at the envelope ceiling, split at the minimum symbol size, is the only way to
        // reach the K bound without also failing the K-consistency check.
        long max = TransferManifest.MaxPayloadBytes;
        byte[] body = BuildBody(originalSize: max, compressedSize: max,
            symbolSize: TransferManifest.MinSymbolSize, compression: CompressionAlg.None);

        Assert.False(TransferManifest.TryParse(body, out _, out string error));
        Assert.Contains("Source symbol count", error);
    }

    /// <summary>
    /// The floor is min(MinSymbolSize, ciphertextSize), not a flat minimum — a small transaction
    /// payload legitimately produces symbolSize == ciphertextSize, well under 256 bytes. This is
    /// the test that catches over-tightening the envelope.
    /// </summary>
    [Fact]
    public void Manifest_TinyPayload_StillAccepted()
    {
        // 1 byte of plaintext, stored uncompressed: ciphertext is that byte plus the GCM tag.
        byte[] body = BuildBody(originalSize: 1, compressedSize: 1,
            symbolSize: 1 + Envelope.TagSize, compression: CompressionAlg.None);

        Assert.True(TransferManifest.TryParse(body, out var parsed, out string error), error);
        Assert.Equal(1u, parsed!.SourceSymbolCount);
    }

    [Fact]
    public void Manifest_PayloadBeyondEnvelope_IsRejected()
    {
        long overCap = TransferManifest.MaxPayloadBytes + 1;
        byte[] body = BuildBody(originalSize: overCap, compressedSize: overCap,
            symbolSize: 1350, compression: CompressionAlg.None);

        Assert.False(TransferManifest.TryParse(body, out _, out _));
    }

    /// <summary>
    /// Serializes a manifest with the size/coding fields under test. K is derived so that the
    /// consistency check passes and the bound being exercised is the one that fires.
    /// </summary>
    private static byte[] BuildBody(long originalSize, long compressedSize, int symbolSize,
        CompressionAlg compression = CompressionAlg.Brotli)
    {
        long ciphertextSize = compressedSize + Envelope.TagSize;
        long k = (ciphertextSize + symbolSize - 1) / symbolSize;

        return new TransferManifest
        {
            SessionId = Guid.NewGuid(),
            TimestampUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            Counter = 1,
            SenderSigningKeyId = new byte[8],
            ReceiverAgreementKeyId = new byte[8],
            Salt = new byte[32],
            Nonce = new byte[12],
            SymbolSize = (ushort)symbolSize,
            SourceSymbolCount = (uint)k,
            LtSeed = 1,
            RedundancyHint = 3,
            OriginalSize = originalSize,
            CompressedSize = compressedSize,
            CiphertextSize = ciphertextSize,
            Compression = compression,
            CiphertextSha256 = new byte[32],
                ContentType = ContentKind.Json,
            Filename = "txn.json",
        }.Serialize();
    }

    [Fact]
    public void Manifest_TruncatedOrPadded_IsRejected()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();

        Assert.False(TransferManifest.TryParse(body.AsSpan(0, body.Length - 1), out _, out _));
        Assert.False(TransferManifest.TryParse(body.Concat(new byte[1]).ToArray(), out _, out _));
        Assert.False(TransferManifest.TryParse(ReadOnlySpan<byte>.Empty, out _, out _));
    }

    [Fact]
    public void ReplayGuard_TimestampWindow_Enforced()
    {
        var clock = new FakeTimeProvider(DateTimeOffset.UtcNow);
        var guard = new InMemoryReplayGuard(clock);
        byte[] keyId = new byte[8];

        long fresh = clock.GetUtcNow().ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.Fresh, guard.Check(keyId, Guid.NewGuid(), 1, fresh));

        long stale = clock.GetUtcNow().AddDays(-3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), 1, stale));

        long future = clock.GetUtcNow().AddDays(3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), 1, future));
    }

    [Fact]
    public void AuditLog_ChainVerifies_AndDetectsTamper()
    {
        string path = Path.Combine(Path.GetTempPath(), $"qrdiode-audit-{Guid.NewGuid():N}.jsonl");
        try
        {
            var log = new AuditLog(path);
            log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "abc", ["file"] = "x.xml" });
            log.Append("transfer.rejected", new Dictionary<string, string> { ["reason"] = "replay" });
            log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "def" });

            Assert.Equal(-1, AuditLog.Verify(path)); // intact

            // Tamper with the middle record.
            var lines = File.ReadAllLines(path);
            lines[1] = lines[1].Replace("replay", "REPLAY");
            File.WriteAllLines(path, lines);

            Assert.Equal(1, AuditLog.Verify(path)); // chain broken at record 1
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void AuditLog_SurvivesReopen_ChainContinues()
    {
        string path = Path.Combine(Path.GetTempPath(), $"qrdiode-audit-{Guid.NewGuid():N}.jsonl");
        try
        {
            new AuditLog(path).Append("a", new Dictionary<string, string>());
            new AuditLog(path).Append("b", new Dictionary<string, string>()); // reopened process
            Assert.Equal(-1, AuditLog.Verify(path));
        }
        finally
        {
            File.Delete(path);
        }
    }

    private sealed class FakeTimeProvider(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }
}
