﻿using QrDiode.Core.Manifest;
using QrDiode.Receiver.Storage;

namespace QrDiode.Receiver.Tests;

/// <summary>
/// The store is where a transfer stops being cryptography and starts being a file. Everything
/// here is about the one class of failure that is invisible until it happens: a payload that
/// passed every verification step and then could not be written down.
/// </summary>
public class PayloadStoreTests
{
    /// <summary>
    /// The manifest allows a 255-byte filename; the stored component adds a 33-character session
    /// prefix. Before the cap those summed to 288, past the NTFS component limit, and File.Move
    /// threw on a fully verified payload — with no way to ask the sender for it again.
    /// </summary>
    [Fact]
    public void Save_MaximumLengthFilename_StillMaterialises()
    {
        string root = NewRoot();
        try
        {
            var store = new PayloadStore(new ReceiverSettings
            {
                StorageRoot = root,
                OrganizeByDate = true,
                WriteSidecar = true,
            });
            store.EnsureReady();

            var manifest = MakeManifest(new string('x', 250) + ".json");
            byte[] plaintext = """{"txn":"ok"}"""u8.ToArray();

            string path = store.Save(manifest, plaintext, "A1B2C3D4", DateTime.Now);

            Assert.True(File.Exists(path));
            Assert.True(Path.GetFileName(path).Length <= PayloadStore.MaxStoredNameChars,
                $"stored component was {Path.GetFileName(path).Length} characters");
            Assert.Equal(plaintext, File.ReadAllBytes(path));
        }
        finally
        {
            Cleanup(root);
        }
    }

    [Fact]
    public void SanitizeFilename_Truncating_KeepsTheExtension()
    {
        string safe = PayloadStore.SanitizeFilename(new string('a', 250) + ".json");

        Assert.EndsWith(".json", safe);
        Assert.True(safe.Length + 33 <= PayloadStore.MaxStoredNameChars);
    }

    [Fact]
    public void SanitizeFilename_OrdinaryName_IsUntouched()
    {
        // Transaction filenames are a fraction of the budget; the cap must never disturb them.
        const string name = "goods-receipt-20260823-0012.json";
        Assert.Equal(name, PayloadStore.SanitizeFilename(name));
    }

    [Theory]
    [InlineData("../../etc/passwd", "json")]
    [InlineData("..\\..\\windows\\system32\\cfg", "json")]
    [InlineData("....", "json")]
    [InlineData("", "json")]
    public void SanitizeFilename_HostileNames_StayInsideTheStore(string hostile, string _)
    {
        string safe = PayloadStore.SanitizeFilename(hostile);

        Assert.DoesNotContain('/', safe);
        Assert.DoesNotContain('\\', safe);
        Assert.False(safe.StartsWith('.'));
        Assert.NotEmpty(safe);
    }

    /// <summary>
    /// Reserved device names are unreachable because Save prefixes the session GUID. That is a
    /// load-bearing property of the prefix, not a happy accident — this test fails if anyone
    /// removes it, which is the point.
    /// </summary>
    [Fact]
    public void Save_ReservedDeviceName_IsHarmless()
    {
        string root = NewRoot();
        try
        {
            var store = new PayloadStore(new ReceiverSettings
            {
                StorageRoot = root,
                OrganizeByDate = false,
                WriteSidecar = false,
            });
            store.EnsureReady();

            string path = store.Save(MakeManifest("CON"), [0x7b, 0x7d], "A1B2C3D4", DateTime.Now);

            Assert.True(File.Exists(path));
            Assert.NotEqual("CON", Path.GetFileName(path));
        }
        finally
        {
            Cleanup(root);
        }
    }

    [Fact]
    public void EnsureReady_RootTooDeepForAWorstCaseName_FailsAtStart()
    {
        var store = new PayloadStore(new ReceiverSettings
        {
            StorageRoot = Path.Combine(Path.GetTempPath(), new string('d', 160)),
        });

        Assert.Throws<PathTooLongException>(store.EnsureReady);
    }

    private static string NewRoot() =>
        Path.Combine(Path.GetTempPath(), $"qrd-{Guid.NewGuid():N}");

    private static void Cleanup(string root)
    {
        if (Directory.Exists(root)) Directory.Delete(root, recursive: true);
    }

    private static TransferManifest MakeManifest(string filename) => new()
    {
        SessionId = Guid.NewGuid(),
        TimestampUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        Counter = 1,
        SenderSigningKeyId = new byte[8],
        ReceiverAgreementKeyId = new byte[8],
        Salt = new byte[32],
        Nonce = new byte[12],
        SymbolSize = 1350,
        SourceSymbolCount = 1,
        LtSeed = 1,
        RedundancyHint = 3,
        OriginalSize = 12,
        CompressedSize = 12,
        CiphertextSize = 28,
        Compression = CompressionAlg.None,
        CiphertextSha256 = new byte[32],
        ContentType = ContentKind.Json,
        Filename = filename,
    };
}
